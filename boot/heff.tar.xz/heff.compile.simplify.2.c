// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknown(V, V);
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknown_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOne(V, V);
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOne_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emarkSafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo;
V g_heff_2ecompile_2esimplify_2emarkSafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2epushBudget_get(void);
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2esafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esafeAs_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especBodySize_get(void);
V g_heff_2ecompile_2esimplify_2especDepth_get(void);
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etouch(V, V, V);
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etouch_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s85178867x1278479365(V, V, V, V, V);
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a);
extern Clo g_list_2efoldl_24s85178867x1278479365_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2esimplify_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2esimplify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eletsOf_24dps(v_rest_243, v_body_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V v_x1_240, V v_body_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_body_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_a_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_a_246), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_body_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_body_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_e_27_243 = heff_field(v_x2_242, 0);
    V v_n_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24MkPair = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V rv_0 = v_n_244; V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24x2_242_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_243, v_t_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eknown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknown_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknown(V v_g_240, V v_s_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(v_g_240, heff_rfield(v_s_241, 2)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_241, 1)))) {
      V v_t_245 = heff_intSub(heff_take_field(v_s_241, 1), MK_INT(1LL));
      V v_t_246 = ({ V rv_1 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_243, v_t_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    } else {
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknown(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eflat_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eflat(V v_b_240) {
top: ;
  switch (heff_tag_of(v_b_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_b_240, 0);
    V v_b2_244 = heff_field(v_b_240, 1);
    V v_ru_24b_240_24ELam = heff_take_reuse_n(v_b_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2eflat(v_b2_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_ys_246 = heff_field(v_x2_245, 0);
      V v_b_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_243, v_ys_246));
      return heff_tag_at_n(v_ru_24b_240_24ELam, TAG_MkPair, 2, (V[]){v_t_248, v_b_247});
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  default: return heff_nomatch(v_b_240);
  }
}
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eflat(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_249, v_as_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_as_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EPrim: {
      V v_p_2424 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2425 = ({ V a_0 = heff_dup(v_p_2424); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
      return (g_heff_2ecompile_2esimplify_2eprimAppN(v_p_2424, v_as_241, v_t_2425));
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2elam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2epartialApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialApp(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_as_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2efewerThan(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialApp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_g_241; V b_1 = heff_get_n(v_s_240, 2, 9); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 2);
      V v_x_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      return heff_intLt(v_n_242, v_x_249);
    }
    case TAG_EApp: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_244, 0ULL, 4);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakesMore(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_248))) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2ecompile_2esimplify_2eelemStr(heff_dup(v_y_243), v_xs_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
    heff_drop(v_x1_244);
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_245), v_kinds_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eetaHead(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletFloat(V v_r_240, V v_x_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EGlobal: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELam: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EApp: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_242, 0);
    V v_a1_2411 = heff_field(v_a_242, 1);
    V v_a2_2412 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2412, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam0, 1, 3, (V[]){v_m_2413, v_y_2410, v_a1_2411});
  }
  case TAG_ERecord: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EProj: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ETag: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EMatch: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrim: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrimCall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ECall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EInt: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EStr: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EBytes: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFixed: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat32: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EAbandon: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFix: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a1_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a1_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_str0, 1, "p");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_str1, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshParams(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_take_field(v_s_241, 0)});
  V v_t_243 = (g_list_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_list_2efoldl_24s85178867x1278479365(((V)&g_heff_2ecompile_2esimplify_2efreshParams_str0), ((V)&g_heff_2ecompile_2esimplify_2efreshParams_str1), MK_INT(1LL), v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_247});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshParams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243) {
top: ;
  V v_a_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_247;
  if (heff_intLe_c(heff_dup(v_a_244), heff_dup(v_b_245))) {
    heff_drop(v_b_245);
    v_t_247 = v_a_244;
  } else {
    heff_drop(v_a_244);
    v_t_247 = v_b_245;
  }
  V v_t_248 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_247, heff_dup(v_xs_241)));
  V v_a_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2412;
  if (heff_intLe_c(heff_dup(v_a_249), heff_dup(v_b_2410))) {
    heff_drop(v_b_2410);
    v_t_2412 = v_a_249;
  } else {
    heff_drop(v_a_249);
    v_t_2412 = v_b_2410;
  }
  V v_t_2413 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2412, heff_dup(v_as_243)));
  V v_t_2414 = (g_heff_2ecompile_2esimplify_2ezipL(v_t_248, v_t_2413));
  V v_x_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_y_2419;
  if (heff_intLe_c(heff_dup(v_a_2416), heff_dup(v_b_2417))) {
    heff_drop(v_b_2417);
    v_y_2419 = v_a_2416;
  } else {
    heff_drop(v_a_2416);
    v_y_2419 = v_b_2417;
  }
  V v_t_2426;
  if (heff_intLt_c(v_y_2419, v_x_2415)) {
    V v_a_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2424;
    if (heff_intLe_c(heff_dup(v_a_2421), heff_dup(v_b_2422))) {
      heff_drop(v_b_2422);
      v_t_2424 = v_a_2421;
    } else {
      heff_drop(v_a_2421);
      v_t_2424 = v_b_2422;
    }
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2424, heff_dup(v_xs_241)));
    v_t_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2425, v_b_242});
  } else {
    v_t_2426 = v_b_242;
  }
  V v_t_2427 = ({ V a_0 = v_t_2414; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2427}));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2428, v_xs_241, v_as_243, v_r_240});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_a_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2436;
    if (heff_intLe_c(heff_dup(v_a_2433), heff_dup(v_b_2434))) {
      heff_drop(v_b_2434);
      v_t_2436 = v_a_2433;
    } else {
      heff_drop(v_a_2433);
      v_t_2436 = v_b_2434;
    }
    V v_t_2437 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2436, v_as_243));
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2431;
    heff_room[1] = v_t_2437;
    heff_room[2] = v_s_2432;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_248))) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2esimplify_2especBodySize_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especBodySize_st;
static V g_heff_2ecompile_2esimplify_2especBodySize_init(void) {
  return MK_INT(1200LL);
}
V g_heff_2ecompile_2esimplify_2especBodySize_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especBodySize_st)) return g_heff_2ecompile_2esimplify_2especBodySize_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especBodySize_val, &g_heff_2ecompile_2esimplify_2especBodySize_st, g_heff_2ecompile_2esimplify_2especBodySize_init);
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V v_all_240, V v_as_241, V v_x3_242, V v_i_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249;
    if ((heff_dup(v_st_245) == NTAG(TAG_True))) {
      heff_drop(v_st_245);
      V v_x3_247 = (g_heff_2ecompile_2esimplify_2enthE(heff_dup(v_i_243), v_as_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        v_t_249 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_240, v_x_248));
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
    } else {
      heff_drop(v_st_245);
      v_t_249 = NTAG(TAG_False);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_all_240;
    V t_1 = v_as_241;
    V t_2 = v_rest_246;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_cell_2410;
    v_all_240 = t_0;
    v_as_241 = t_1;
    v_x3_242 = t_2;
    v_i_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo_24dps(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V v_x1_240, V v_xs_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_xs_241);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_241, 0);
      V v_xs2_246 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_ms_244;
        V t_1 = v_xs2_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_xs2_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2echeap_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2echeap(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V a_1 = v_safe_240; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_safe_240); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_a_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V t_0 = v_safe_240;
      V t_1 = v_b_2412;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2417 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2414)));
    V v_t_2418 = (g_list_2emap(v_t_2416, v_t_2417));
    return ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    V t_0 = v_safe_240;
    V t_1 = v_e_2419;
    v_safe_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2426 = (g_list_2emap(v_t_2425, heff_dup(v_as_2424)));
    return ({ V a_0 = v_t_2426; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2426); r_; });
  }
  case TAG_EMatch: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2430 = heff_field(v_x2_241, 0);
    V v_as_2431 = heff_field(v_x2_241, 1);
    V v_x1_2432 = ({ V a_0 = heff_dup(v_p_2430); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2432) == NTAG(TAG_True))) {
      heff_drop(v_safe_240);
      heff_drop(v_x1_2432);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2432);
      V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
      V v_t_2434 = (g_list_2emap(v_t_2433, heff_dup(v_as_2431)));
      return ({ V a_0 = v_t_2434; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2434); r_; });
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2echeap(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2estripLams_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_e_241, 0);
    V v_b_246 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_247 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_245), v_as_247));
    V v_m_249 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_x_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_245));
    V v_y_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2415;
    if (heff_intLt_c(v_y_2411, v_x_2410)) {
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2413, v_ys_245));
      v_e_2415 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2414, v_b_246});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_245);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2415 = v_b_246;
    }
    V v_t_2416 = (g_map_2esize(v_m_249));
    if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
      heff_drop(v_m_249);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_2415);
    } else {
      V v_t_2418 = ({ V a_0 = v_m_249; V a_1 = v_e_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_249); r_; });
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2418);
    }
  }
  case TAG_EApp: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_e_241, 0);
    V v_a_2422 = heff_field(v_e_241, 1);
    V v_b_2423 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2424 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2421, v_a_2422, heff_hole()});
    V v_u_2425 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_zs_240;
    V t_1 = v_b_2423;
    V t_2 = v_cell_2424;
    v_zs_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2434 = heff_field(v_e_241, 0);
    V v_arms_2435 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0, 1, 1, (V[]){v_go_2436}), v_arms_2435));
    return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2434, v_t_2442}));
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args) {
  V v_x2_2437 = args[0];
  V v_go_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkArm: {
    V v_t_2438 = heff_field(v_x2_2437, 0);
    V v_vs_2439 = heff_field(v_x2_2437, 1);
    V v_b_2440 = heff_field(v_x2_2437, 2);
    V v_ru_24x2_2437_24MkArm = heff_take_reuse_n(v_x2_2437, 7ULL, 3);
    V v_t_2441 = heff_tr(heff_call(v_go_2436, 1, (V[]){v_b_2440}));
    return heff_tag_at_n(v_ru_24x2_2437_24MkArm, TAG_MkArm, 3, (V[]){v_t_2438, v_vs_2439, v_t_2441});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
Clo g_heff_2ecompile_2esimplify_2eownSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eownSt_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eownSt(V v_s_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 3, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 4, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 6, 7);
  V v_t_247 = ({ V rv_1 = MK_INT(4000LL); V rv_6 = heff_dup(g_map_2eempty_get()); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, MK_INT(0LL), v_t_246}); V rr_ = heff_rec_reuse_nf(v_s_240, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eownSt(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etouch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etouch_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etouch(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_k_243 = heff_take_field(v_s_242, 8);
  V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_v_241, heff_take_field(v_k_243, 0)));
  V v_k_245 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_t_244, heff_take_field(v_k_243, 1), heff_dup(heff_rfield(v_k_243, 2)), heff_take_field(v_k_243, 3), heff_take_field(v_k_243, 4)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_h_240, heff_get_n(v_k_243, 2, 5)});
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_nf(v_k_245, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_248 = ({ V rv_8 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etouch(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkSafeAs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkSafeAs(V v_x1_240, V v_h_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_241), NTAG(TAG_MkUnit), heff_take_field(v_p_242, 4)));
    V v_s_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 495ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(v_h_241, NTAG(TAG_MkUnit), heff_take_field(v_s_244, 3)));
    V v_t_246 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_244, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_246});
  } else {
    heff_drop(v_h_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_242});
  }
}
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2emarkSafeAs(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especDepth_get()), heff_dup(v_d_248))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_z_249});
  } else {
    V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eask(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 2ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_as_244));
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_246, 2, 3), v_t_2415));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 3, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2416, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}

static V g_heff_2ecompile_2esimplify_2epushBudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2epushBudget_st;
static V g_heff_2ecompile_2esimplify_2epushBudget_init(void) {
  return MK_INT(120LL);
}
V g_heff_2ecompile_2esimplify_2epushBudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2epushBudget_st)) return g_heff_2ecompile_2esimplify_2epushBudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2epushBudget_val, &g_heff_2ecompile_2esimplify_2epushBudget_st, g_heff_2ecompile_2esimplify_2epushBudget_init);
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c(v_k_245, heff_dup(v_l_240))) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, v_l_240, v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eothersPure(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = ({ V a_0 = v_f_246; V a_1 = v_s_248; V r_ = (g_heff_2ecompile_2esimplify_2eisPure(a_0, a_1)); heff_drop(v_f_246); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
      heff_drop(v_x_2410);
      heff_drop_cell(v_ru_24x2_249_24MkPair, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eothersPure(v_l_240, v_rest_244));
      V f_ = v_t_2412;
      args[0] = v_s_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_l_240);
      heff_drop(v_rest_244);
      heff_drop(v_x_2410);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2411});
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  V v_x2_244 = (g_heff_2ecompile_2esimplify_2emadeOne(heff_dup(v_h_241), v_s_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_x1_247 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_246), heff_dup(v_h_241)));
    V v_x2_2412;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nothing: {
      v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      break;
    }
    case TAG_Just: {
      V v_kc_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      V v_t_249 = heff_get_n(v_kc_248, 4, 5);
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
        break;
      }
      case TAG_Just: {
        V v_km_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_244_24MkPair, 2);
        V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_km_2410, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2412 = (g_heff_2ecompile_2esimplify_2emadeKept(v_km_2410, v_t_2411, v_s_246));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_m_2417;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_Nothing: {
        v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeFresh_clo), 2, (V[]){heff_dup(v_h_241), v_b0_242}));
        break;
      }
      case TAG_Just: {
        V v_b_2415 = heff_field(v_x_2413, 0);
        heff_take_n(v_x_2413, 1ULL, 1);
        heff_drop(v_b0_242);
        v_m_2417 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam0, 1, 1, (V[]){v_b_2415});
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2419)));
        V v_t_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
        V v_m_2423 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2422}));
        V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2420}));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_x_2419}), NTAG(TAG_Nil)});
          V v_x_2428 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2425, v_t_2427));
          return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2426});
        }
        default: return heff_nomatch(v_x2_2424);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args) {
  V v_s_2416 = args[0];
  V v_b_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_s_2416});
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_seen_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V v_t_248 = (g_map_2einsert_24s1341440536x470972936(v_x_243, NTAG(TAG_MkUnit), v_seen_240));
      V t_0 = v_t_248;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eoneDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneDef_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eoneDef(V v_d_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_MkPair: {
    V v_s_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24MkPair = heff_take_reuse_n(v_t_242, 2ULL, 2);
    V v_k_245 = heff_take_field(v_s_244, 8);
    V v_t_246 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_245, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_247 = ({ V rv_8 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_244, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_248 = heff_tag_at_n(v_ru_24t_242_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 2ULL, 2);
      V v_m_2411 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), heff_dup(heff_rfield(v_d_240, 2))));
      V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
        V v_m_2415 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2413));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2414}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          V v_x2_2419 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2417, v_s_2418));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_s_2421 = heff_field(v_x2_2419, 1);
            V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
            V v_x2_2422 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_d_240, 0)), heff_dup(v_x_2420), heff_dup(v_s_2421)));
            switch (heff_tag_of(v_x2_2422)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x2_2422, 1);
              heff_take_n(v_x2_2422, 2ULL, 2);
              V v_x2_2425 = (g_heff_2ecompile_2esimplify_2emarkSafe(heff_dup(heff_rfield(v_d_240, 0)), v_x_2420, v_s_2424));
              switch (heff_tag_of(v_x2_2425)) {
              case TAG_MkPair: {
                V v_s_2427 = heff_field(v_x2_2425, 1);
                heff_take_n(v_x2_2425, 2ULL, 2);
                V v_t_2428 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2420)));
                V v_t_2429 = (g_heff_2ecompile_2eir_2enubI(v_t_2428));
                V v_x2_2430 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2429, heff_dup(v_s_2427)));
                switch (heff_tag_of(v_x2_2430)) {
                case TAG_MkPair: {
                  V v_x_2431 = heff_field(v_x2_2430, 0);
                  V v_s_2432 = heff_field(v_x2_2430, 1);
                  heff_take_n(v_x2_2430, 3ULL, 2);
                  V v_t_2433 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), heff_dup(v_x_2420)});
                  V v_t_2434 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
                  V v_t_2435 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2431, v_t_2434));
                  V v_t_2436 = heff_get_n(heff_get_n(v_s_2421, 8, 9), 2, 5);
                  V v_t_2437 = (g_heff_2ecompile_2esimplify_2edoneOf(v_s_2427, v_d_240, v_x_2420, v_t_2436));
                  V v_t_2438 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
                  V v_x_2439 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_t_2438});
                  return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2439, v_s_2432});
                }
                default: return heff_nomatch(v_x2_2430);
                }
              }
              default: return heff_nomatch(v_x2_2425);
              }
            }
            default: return heff_nomatch(v_x2_2422);
            }
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneDef(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esafeAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esafeAs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esafeAs(V v_x1_240, V v_k_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_map_2einsert_24s1341440536x470972936(v_k_241, NTAG(TAG_MkUnit), heff_take_field(v_p_242, 3)));
    V v_t_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_244});
  } else {
    heff_drop(v_k_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_242});
  }
}
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esafeAs(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eoneDef(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_244 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_242, 0)), heff_dup(heff_rfield(v_sg_242, 0)), heff_get_n(v_sg_242, 1, 2), heff_dup(g_map_2eempty_get()), v_t_243, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get())});
  V v_x1_245 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_defs_241, v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_out_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    V v_t_248 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_246)));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_246)));
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_out_246));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = ({ V a_0 = heff_dup(v_st_247); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_249, heff_get_n(v_st_247, 0, 9), v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esgItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esgItem(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_d_242, 2))));
    return ({ V a_0 = v_acc_240; V a_1 = heff_dup(heff_rfield(v_d_242, 0)); V a_2 = v_t_243; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  }
  case TAG_Kept: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_t_246 = heff_dup(heff_rfield(v_k_244, 5));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), NTAG(TAG_MkUnit), heff_dup(heff_rfield(v_acc_240, 0))));
    } else {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(heff_rfield(v_acc_240, 0));
    }
    V v_t_249;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_244, 6)))) {
      v_t_249 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), heff_dup(heff_rfield(v_k_244, 6)), heff_get_n(v_acc_240, 1, 2)));
    } else {
      v_t_249 = heff_get_n(v_acc_240, 1, 2);
    }
    return heff_rec_n(2, shape_safe__total, (V[]){v_t_247, v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2esgItem(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyItems_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esimplifyItems(V v_n0_240, V v_sg_241, V v_vers_242, V v_kept_243, V v_items_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_items_244));
  V v_t_246 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_247 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_242, v_kept_243, NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
  V v_t_248 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_241, 0)), heff_dup(heff_rfield(v_sg_241, 0)), heff_get_n(v_sg_241, 1, 2), heff_dup(g_map_2eempty_get()), v_t_246, v_t_247});
  V v_x1_249 = heff_tr(heff_call(v_t_245, 1, (V[]){v_t_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_out_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 3ULL, 2);
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_2410)));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_2410)));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_out_2410));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = ({ V a_0 = heff_dup(v_st_2411); V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2417); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2413, heff_get_n(v_st_2411, 0, 9), v_t_2415, v_t_2418});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyItems(a[0], a[1], a[2], a[3], a[4]);
}