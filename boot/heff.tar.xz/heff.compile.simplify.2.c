// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_caps 9541544
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_deeper 611485124
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_e 319
#define LBL_env 310119
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_n 328
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_self 10021907
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_unrolled 706233391
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_deeper__env__self__at[] = {LBL_deeper, LBL_env, LBL_self, LBL_at};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enamesTag(V, V);
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enamesTag_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2easkedAs(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebuilds(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_clo;
V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo;
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ehandlerOf(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerOf_clo;
V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownCopy_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_clo;
V g_heff_2ecompile_2esimplify_2eposOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eposOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eposOf_clo;
V g_heff_2ecompile_2esimplify_2eposOf_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eposOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eposOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_clo;
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_clo;
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_clo;
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_clo;
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_clo;
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_clo;
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2etagGo_24dps(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2etagMarks(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagMarks_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etakenW(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etakenW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakenW_clo;
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_clo;
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2eunrollOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eunrollOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunrollOf_clo;
V g_heff_2ecompile_2esimplify_2evalueTag(V);
V g_heff_2ecompile_2esimplify_2evalueTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evalueTag_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2evarsW(V, V);
V g_heff_2ecompile_2esimplify_2evarsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsW_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_heff_2eelab_2eprimitive_2eprimArity(V);
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimArity_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1287822497x2111322144(V, V, V);
V g_list_2efoldl_24f1287822497x2111322144_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1287822497x2111322144_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1112048172x371485672(V);
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s418652630x628827683(V);
V g_list_2emap_24s418652630x628827683_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_prelude_2etraverse_24s672366786x467588702(V, V);
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s672366786x467588702_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebind_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebind(V v_m_240, V v_f_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_s_242}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    return heff_tail(v_f_241, 2, (V[]){v_x_244, v_s_245});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_240, v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2epartialIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialIn(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    V v_s_248 = v_s_240;
    V v_argv_249 = heff_dup(v_argv_247);
    V v_x3_2410 = heff_dup(v_f_246);
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_EVar: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      V v_s_2413 = heff_dup(v_s_248);
      V v_safe_2414 = heff_take_field(v_s_2413, 3);
      V v_total_2415 = heff_get_n(v_s_2413, 5, 10);
      V v_argv_2416 = v_argv_249;
      V v_t_2417 = heff_get_n(heff_get_n(v_s_248, 7, 10), 0, 7);
      HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_g_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2417); heff_drop(v_g_2412); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_x31_2421 = v_field_2420;
          switch (heff_tag_of(v_x31_2421)) {
          case TAG_EVar: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EGlobal: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ELam: {
            V v_xs_2424 = heff_field(v_x31_2421, 0);
            V v_ru_24x31_2421_24ELam = heff_take_reuse_n(v_x31_2421, 1ULL, 2);
            V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2416));
            V v_t_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2424; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
            if (heff_intLt_c(v_t_2426, v_t_2427)) {
              V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){v_safe_2414, v_total_2415}));
              V v_t_2429 = (g_list_2emap_24tok2(v_ru_24x31_2421_24ELam, v_t_2428, v_argv_2416));
              return ({ V a_0 = v_t_2429; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2429); r_; });
            } else {
              heff_drop(v_safe_2414);
              heff_drop(v_total_2415);
              heff_drop(v_argv_2416);
              heff_drop_cell(v_ru_24x31_2421_24ELam, 2);
              return NTAG(TAG_False);
            }
          }
          case TAG_EApp: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ELet: {
            heff_take_n(v_x31_2421, 0ULL, 3);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ERecord: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EProj: {
            heff_take_n(v_x31_2421, 0ULL, 4);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ETag: {
            heff_take_n(v_x31_2421, 0ULL, 3);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EMatch: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EPrim: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ECall: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EInt: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EFloat: {
            heff_take_nf(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EStr: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EBytes: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EFixed: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EFloat32: {
            heff_take_na(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EAbandon: {
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EBool: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_ESet: {
            heff_take_n(v_x31_2421, 0ULL, 3);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EValues: {
            heff_take_n(v_x31_2421, 0ULL, 1);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          case TAG_EFix: {
            heff_take_n(v_x31_2421, 0ULL, 2);
            heff_drop(v_safe_2414);
            heff_drop(v_total_2415);
            heff_drop(v_argv_2416);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x31_2421);
          }
        } else {
          heff_drop(v_safe_2414);
          heff_drop(v_total_2415);
          heff_drop(v_argv_2416);
          heff_drop(v_field_2420);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_2410, 0ULL, 3);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_2410, 0ULL, 4);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_2410, 0ULL, 3);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_x3_2410, 0ULL, 3);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_2410, 0ULL, 2);
      heff_drop_rec(v_s_248, 10);
      heff_drop(v_argv_249);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      V v_ru_24f_240_24EApp = heff_take_reuse_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_240_24EApp, v_bs_249, v_argv_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_argv_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EPrim: {
      V v_p_2425 = heff_field(v_f_240, 0);
      V v_ru_24f_240_24EPrim = heff_take_reuse_n(v_f_240, 1ULL, 1);
      V v_p_2426 = heff_dup(v_p_2425);
      V v_argv_2427 = v_argv_241;
      V v_n_2428 = ({ V a_0 = v_p_2425; V r_ = (g_heff_2eelab_2eprimitive_2eprimArity(a_0)); heff_drop(v_p_2425); r_; });
      V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2427));
      if (heff_intEq_c_lent(v_t_2429, v_n_2428, 1)) {
        heff_drop_cell(v_ru_24f_240_24EPrim, 1);
        heff_drop(v_n_2428);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2efoldPrim(v_p_2426, v_argv_2427);
      } else {
        V v_x_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2427));
        if (heff_intLt_c_lent(v_n_2428, v_x_2430, 2)) {
          heff_drop_cell(v_ru_24f_240_24EPrim, 1);
          V v_t_2431 = (g_list_2etake(heff_dup(v_n_2428), heff_dup(v_argv_2427)));
          V v_t_2432 = (g_heff_2ecompile_2esimplify_2efoldPrim(v_p_2426, v_t_2431));
          V v_t_2433 = ({ V a_0 = v_n_2428; V a_1 = v_argv_2427; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_argv_2427); r_; });
          return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2432, v_t_2433});
        } else {
          heff_drop(v_n_2428);
          return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24f_240_24EPrim, TAG_EPrim, 1, (V[]){v_p_2426}), v_argv_2427});
        }
      }
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EBool: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ESet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EValues: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_argv_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerOf(V v_all_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V a_0 = v_all_240; V a_1 = v_g_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x11_246 = v_field_245;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_EVar: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EGlobal: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          heff_take_n(v_x11_246, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          V v_fs_2416 = heff_field(v_x11_246, 0);
          heff_take_n(v_x11_246, 1ULL, 2);
          switch (heff_tag_of(v_fs_2416)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_t_2420 = (g_list_2emap_24s549405518x243689326(v_fs_2416));
            return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
          }
          default: return heff_nomatch(v_fs_2416);
          }
        }
        case TAG_EProj: {
          heff_take_n(v_x11_246, 0ULL, 4);
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          heff_take_n(v_x11_246, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          heff_take_nf(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          heff_take_na(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          heff_take_n(v_x11_246, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          heff_take_n(v_x11_246, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          heff_take_n(v_x11_246, 0ULL, 2);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x11_246);
        }
      } else {
        heff_drop(v_field_245);
        return NTAG(TAG_False);
      }
    }
  }
  default: {
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_e_241);
      heff_drop(v_t_2449);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2449);
      return ({ V a_0 = v_all_240; V a_1 = v_e_241; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_e_241); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V v_x_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_EApp: {
      V v_f_245 = heff_field(v_x41_243, 0);
      V v_argv_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24EApp = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2446;
      switch (heff_tag_of(v_f_245)) {
      case TAG_EVar: {
        V v_y_247 = heff_dup(heff_field(v_f_245, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_247, 2)) {
          v_t_2446 = heff_intAdd(v_n_241, MK_INT(1LL));
        } else {
          v_t_2446 = v_n_241;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ELam: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EApp: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ELet: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EProj: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ETag: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ECall: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EInt: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EStr: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EBool: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ESet: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EValues: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFix: {
        v_t_2446 = v_n_241;
        break;
      }
      default: heff_nomatch(v_f_245);
      }
      V v_t_2447 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_243_24EApp, v_argv_246, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2446;
      V t_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_f_245, v_t_2447});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_t_2448 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_243, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2448;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2evarsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsW_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_y_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_240});
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_245;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2evarsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2evarsW(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagsGiven_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etagsGiven(V v_x1_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_m_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      V v_t_2446;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ELam: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EApp: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ELet: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EProj: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ETag: {
        v_t_2446 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, heff_dup(v_x_243), heff_dup(v_a_245)));
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ECall: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EInt: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EStr: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EBool: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ESet: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EValues: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFix: {
        v_t_2446 = v_m_242;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V t_0 = v_xs_244;
      V t_1 = v_argv_246;
      V t_2 = v_t_2446;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etagsGiven(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprunedFor_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedFor_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eprunedFor(V v_known_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_241, 0);
    V v_argv_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_f_248));
    V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_lam0, 1, 1, (V[]){v_known_240}), v_argv_249));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, v_t_2412});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_241, 0);
    V v_a_2414 = heff_field(v_e_241, 1);
    V v_b_2415 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2414));
    V v_cell_2417 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_2415, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_ERecord: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2428 = heff_field(v_e_241, 0);
    V v_arms_2429 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2494 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_lam1, 1, 3, (V[]){v_known_240, heff_dup(v_arms_2429), heff_dup(v_sc_2428)}), v_arms_2429));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2428, v_t_2494});
  }
  case TAG_EPrim: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EBool: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ESet: {
    V v_xs_24108 = heff_field(v_e_241, 0);
    V v_a_24109 = heff_field(v_e_241, 1);
    V v_b_24110 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_24111 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_24109));
    V v_cell_24112 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_24108, v_t_24111, heff_hole()});
    V v_u_24113 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_24110, heff_dup(v_cell_24112), MK_INT(2LL)));
    heff_drop(v_u_24113);
    return v_cell_24112;
  }
  case TAG_EValues: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedFor(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2esimplify_2eprunedFor(v_known_240, v_a_2411));
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam1(V self, V *args) {
  V v_a_2430 = args[0];
  V v_known_240 = heff_env(self)[0];
  V v_arms_2429 = heff_env(self)[1];
  V v_sc_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_go_2431 = ((V)&g_heff_2ecompile_2esimplify_2eprunedFor_clo);
  V v_known_2432 = heff_dup(v_known_240);
  V v_arms_2433 = v_arms_2429;
  V v_x4_2473;
  switch (heff_tag_of(v_sc_2428)) {
  case TAG_EVar: {
    V v_x_2434 = heff_field(v_sc_2428, 0);
    V v_ru_24sc_2428_24EVar = heff_take_reuse_n(v_sc_2428, 1ULL, 1);
    v_x4_2473 = ({ V a_0 = v_ru_24sc_2428_24EVar; V a_1 = v_known_240; V a_2 = v_x_2434; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_known_240); heff_drop(v_x_2434); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_sc_2428, 0ULL, 4);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2473 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_sc_2428);
  }
  V v_x5_2474 = v_a_2430;
  switch (heff_tag_of(v_x4_2473)) {
  case TAG_Nothing: {
    heff_drop(v_arms_2433);
    switch (heff_tag_of(v_x5_2474)) {
    case TAG_MkArm: {
      V v_t2_2475 = heff_field(v_x5_2474, 0);
      V v_vs_2476 = heff_field(v_x5_2474, 1);
      V v_b_2477 = heff_field(v_x5_2474, 2);
      V v_ru_24x5_2474_24MkArm = heff_take_reuse_n(v_x5_2474, 7ULL, 3);
      V v_t_2478 = heff_tr(heff_call(v_go_2431, 2, (V[]){v_known_2432, v_b_2477}));
      return heff_tag_at_n(v_ru_24x5_2474_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2475, v_vs_2476, v_t_2478});
    }
    default: return heff_nomatch(v_x5_2474);
    }
  }
  case TAG_Just: {
    V v_x41_2479 = heff_field(v_x4_2473, 0);
    heff_take_n(v_x4_2473, 1ULL, 1);
    switch (heff_tag_of(v_x41_2479)) {
    case TAG_ETag: {
      V v_t_2480 = heff_field(v_x41_2479, 0);
      V v_argv_2481 = heff_field(v_x41_2479, 1);
      V v_ru_24x41_2479_24ETag = heff_take_reuse_n(v_x41_2479, 3ULL, 3);
      switch (heff_tag_of(v_x5_2474)) {
      case TAG_MkArm: {
        V v_t2_2483 = heff_field(v_x5_2474, 0);
        V v_vs_2484 = heff_field(v_x5_2474, 1);
        V v_b_2485 = heff_field(v_x5_2474, 2);
        heff_take_n(v_x5_2474, 7ULL, 3);
        if (heff_strEq_c_lent(v_t_2480, v_t2_2483, 0)) {
          heff_drop(v_arms_2433);
          heff_drop(v_t_2480);
          V v_t_2486 = ({ V a_0 = v_vs_2484; V a_1 = v_argv_2481; V a_2 = v_known_2432; V r_ = (g_heff_2ecompile_2esimplify_2etagsGiven(a_0, a_1, a_2)); heff_drop(v_argv_2481); r_; });
          V v_t_2487 = heff_tr(heff_call(v_go_2431, 2, (V[]){v_t_2486, v_b_2485}));
          return heff_tag_at_n(v_ru_24x41_2479_24ETag, TAG_MkArm, 3, (V[]){v_t2_2483, v_vs_2484, v_t_2487});
        } else {
          heff_drop(v_argv_2481);
          if (heff_strEq_c(heff_dup(v_t2_2483), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
            V v_x1_2488 = ({ V a_0 = v_t_2480; V a_1 = v_arms_2433; V r_ = (g_heff_2ecompile_2eir_2enamesTag(a_0, a_1)); heff_drop(v_t_2480); heff_drop(v_arms_2433); r_; });
            if (!(heff_dup(v_x1_2488) == NTAG(TAG_True))) {
              heff_drop(v_x1_2488);
              V v_t_2489 = heff_tr(heff_call(v_go_2431, 2, (V[]){v_known_2432, v_b_2485}));
              return heff_tag_at_n(v_ru_24x41_2479_24ETag, TAG_MkArm, 3, (V[]){v_t2_2483, v_vs_2484, v_t_2489});
            } else {
              heff_drop(v_go_2431);
              heff_drop(v_known_2432);
              heff_drop(v_b_2485);
              heff_drop(v_x1_2488);
              return heff_tag_at_n(v_ru_24x41_2479_24ETag, TAG_MkArm, 3, (V[]){v_t2_2483, v_vs_2484, NTAG(TAG_EAbandon)});
            }
          } else {
            heff_drop(v_go_2431);
            heff_drop(v_known_2432);
            heff_drop(v_arms_2433);
            heff_drop(v_t_2480);
            heff_drop(v_b_2485);
            return heff_tag_at_n(v_ru_24x41_2479_24ETag, TAG_MkArm, 3, (V[]){v_t2_2483, v_vs_2484, NTAG(TAG_EAbandon)});
          }
        }
      }
      default: return heff_nomatch(v_x5_2474);
      }
    }
    default: {
      heff_drop(v_arms_2433);
      heff_drop(v_x41_2479);
      switch (heff_tag_of(v_x5_2474)) {
      case TAG_MkArm: {
        V v_t2_2490 = heff_field(v_x5_2474, 0);
        V v_vs_2491 = heff_field(v_x5_2474, 1);
        V v_b_2492 = heff_field(v_x5_2474, 2);
        V v_ru_24x5_2474_24MkArm = heff_take_reuse_n(v_x5_2474, 7ULL, 3);
        V v_t_2493 = heff_tr(heff_call(v_go_2431, 2, (V[]){v_known_2432, v_b_2492}));
        return heff_tag_at_n(v_ru_24x5_2474_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2490, v_vs_2491, v_t_2493});
      }
      default: return heff_nomatch(v_x5_2474);
      }
    }
    }
  }
  default: return heff_nomatch(v_x4_2473);
  }
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V v_loop_240, V v_all_241, V v_back_242, V v_argv_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_loop_240);
    heff_drop(v_all_241);
    heff_drop(v_back_242);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_247 = heff_field(v_x5_244, 0);
    V v_rest_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2426;
    if ((heff_dup(v_st_247) == NTAG(TAG_True))) {
      heff_drop(v_st_247);
      HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), v_argv_243));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          V v_loop_2413 = heff_dup(v_loop_240);
          V v_kinds_2414 = heff_dup(v_all_241);
          V v_back_2415 = heff_dup(v_back_242);
          V v_e_2416 = v_x_2412;
          switch (heff_tag_of(v_e_2416)) {
          case TAG_EGlobal: {
            V v_g_2417 = heff_dup(heff_field(v_e_2416, 0));
            HeffT2 v_t_2418 = ({ V a_0 = v_kinds_2414; V a_1 = v_g_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_kinds_2414); heff_drop(v_g_2417); r_; });
            {
              V v_field_2420 = v_t_2418.f[1];
              int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
              if ((v_tag_2419 == ((int64_t)0ULL))) {
                heff_drop(v_loop_2413);
                heff_drop(v_back_2415);
                heff_drop_tag(v_e_2416, 1);
                V v_x_2421 = v_field_2420;
                heff_drop(v_x_2421);
                v_t_2426 = NTAG(TAG_True);
              } else {
                heff_drop(v_field_2420);
                if ((heff_dup(v_loop_2413) == NTAG(TAG_True))) {
                  heff_drop(v_loop_2413);
                  V v_t_2422 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_e_2416)));
                  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
                    heff_drop(v_back_2415);
                    heff_drop_tag(v_e_2416, 1);
                    heff_drop(v_t_2422);
                    v_t_2426 = NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2422);
                    v_t_2426 = heff_tr(heff_call(v_back_2415, 1, (V[]){v_e_2416}));
                  }
                } else {
                  heff_drop(v_loop_2413);
                  v_t_2426 = heff_tr(heff_call(v_back_2415, 1, (V[]){v_e_2416}));
                }
              }
            }
            break;
          }
          default: {
            heff_drop(v_kinds_2414);
            V v_t_2423 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_2416)));
            if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
              heff_drop(v_loop_2413);
              heff_drop(v_back_2415);
              heff_drop(v_e_2416);
              heff_drop(v_t_2423);
              v_t_2426 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2423);
              V v_t_2424 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_e_2416)));
              if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
                heff_drop(v_loop_2413);
                heff_drop(v_back_2415);
                heff_drop(v_e_2416);
                heff_drop(v_t_2424);
                v_t_2426 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2424);
                if ((heff_dup(v_loop_2413) == NTAG(TAG_True))) {
                  heff_drop(v_loop_2413);
                  V v_t_2425 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_e_2416)));
                  if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
                    heff_drop(v_back_2415);
                    heff_drop(v_e_2416);
                    heff_drop(v_t_2425);
                    v_t_2426 = NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2425);
                    v_t_2426 = heff_tr(heff_call(v_back_2415, 1, (V[]){v_e_2416}));
                  }
                } else {
                  heff_drop(v_loop_2413);
                  v_t_2426 = heff_tr(heff_call(v_back_2415, 1, (V[]){v_e_2416}));
                }
              }
            }
            break;
          }
          }
        } else {
          heff_drop(v_field_2411);
          v_t_2426 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_247);
      v_t_2426 = NTAG(TAG_False);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_loop_240;
    V t_1 = v_all_241;
    V t_2 = v_back_242;
    V t_3 = v_argv_243;
    V t_4 = v_rest_248;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2427;
    v_loop_240 = t_0;
    v_all_241 = t_1;
    v_back_242 = t_2;
    v_argv_243 = t_3;
    v_x5_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2emarkGo_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V v_x1_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_246, v_p_242}});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x2_241, 0);
      V v_argv_248 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_m_249 = v_m_244;
      V v_a_2410 = v_a_247;
      V v_s_2411 = v_p_242;
      V v_x2_2426;
      if ((heff_dup(v_m_249) == NTAG(TAG_True))) {
        heff_drop(v_m_249);
        V v_t_2412 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_2411, 0)});
        HeffT2 v_t_2413 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_2410, v_t_2412));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_e_2416 = v_field_2414;
          V v_st_2417 = v_field_2415;
          V v_vars_2418 = heff_take_field(v_st_2417, 2);
          V v_holes_2419 = heff_take_field(v_st_2417, 3);
          V v_n_2420 = heff_get_n(v_st_2417, 4, 5);
          V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_2418));
          V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_holes_2419));
          V v_x_2423 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_2416, v_t_2421, v_t_2422, v_n_2420});
          V v_t_2424 = ({ V rv_0 = heff_dup(heff_rfield(v_x_2423, 3)); V rr_ = heff_rec_reuse_nf(v_s_2411, 1022ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048572u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_x2_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2423, v_t_2424});
        }
      } else {
        heff_drop(v_m_249);
        V v_t_2425 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_2410, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_2411, 0))});
        v_x2_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_2425, v_s_2411});
      }
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        V v_s_2428 = heff_field(v_x2_2426, 1);
        V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
        V v_holes_2429 = heff_take_field(v_x_2427, 2);
        V v_e_2430 = heff_take_field(v_x_2427, 0);
        V v_vars_2431 = heff_get_n(v_x_2427, 1, 4);
        V v_m_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_argv_248}));
        V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2428}));
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_MkPair: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_s_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          V v_args_2436 = heff_take_field(v_x_2434, 0);
          V v_vars_2437 = heff_take_field(v_x_2434, 1);
          V v_holes_2438 = heff_get_n(v_x_2434, 2, 3);
          V v_hs_2439 = v_holes_2429;
          V v_t_2440 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_241_24Cons, v_vars_2431, v_vars_2437));
          V v_t_2441 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2426_24MkPair, v_hs_2439, v_holes_2438));
          V v_x_2442 = heff_rec_n(3, shape_args__vars__holes, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_2430, v_args_2436}), v_t_2440, v_t_2441});
          return ((HeffT2){{v_x_2442, v_s_2435}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2433)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2426)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2earityIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earityIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2earityIn(V v_all_240, V v_g_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_all_240, v_g_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_EVar: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_ELam: {
        V v_xs_248 = heff_field(v_it1_245, 0);
        heff_take_n(v_it1_245, 1ULL, 2);
        return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      }
      case TAG_EApp: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ELet: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EProj: {
        heff_take_n(v_it1_245, 0ULL, 4);
        return MK_INT(0LL);
      }
      case TAG_ETag: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ECall: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFloat: {
        heff_take_nf(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EStr: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EAbandon: {
        return MK_INT(0LL);
      }
      case TAG_EBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_ESet: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_EValues: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFix: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return MK_INT(0LL);
      }
      default: return heff_nomatch(v_it1_245);
      }
    } else {
      heff_drop(v_field_244);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2earityIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2easkedAs_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2easkedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedAs_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2easkedAs(V v_h_240, V v_kc_241, V v_b_242, V v_x4_243, V v_p_244) {
top: ;
  V v_depth_245 = heff_take_field(v_kc_241, 3);
  V v_safe_246 = heff_get_n(v_kc_241, 4, 6);
  if ((heff_dup(v_x4_243) == NTAG(TAG_True))) {
    HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_p_244));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_s_2411 = v_field_249;
      HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_240), v_x_2410, v_depth_245, v_s_2411));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        heff_drop(v_x_2415);
        V v_s_2416 = v_field_2414;
        V v_x1_2417 = v_safe_246;
        V v_h_2418 = v_h_240;
        V v_p_2419 = v_s_2416;
        V v_x2_2431;
        if ((heff_dup(v_x1_2417) == NTAG(TAG_True))) {
          heff_drop(v_x1_2417);
          V v_t_2420 = heff_take_field(v_p_2419, 0);
          V v_t_2421 = heff_take_field(v_p_2419, 1);
          V v_t_2422 = heff_take_field(v_p_2419, 2);
          V v_t_2423 = heff_take_field(v_p_2419, 3);
          V v_t_2424 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_p_2419, 4), heff_dup(v_h_2418), NTAG(TAG_MkUnit)));
          V v_t_2425 = heff_take_field(v_p_2419, 5);
          V v_t_2426 = heff_take_field(v_p_2419, 6);
          V v_t_2427 = heff_take_field(v_p_2419, 7);
          V v_t_2428 = heff_take_field(v_p_2419, 8);
          V v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2423, v_h_2418, NTAG(TAG_MkUnit)));
          V v_t_2430 = ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rv_2 = v_t_2422; V rv_3 = v_t_2429; V rv_4 = v_t_2424; V rv_5 = v_t_2425; V rv_6 = v_t_2426; V rv_7 = v_t_2427; V rv_8 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_p_2419, 512ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 786432u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
          v_x2_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2430});
        } else {
          heff_drop(v_x1_2417);
          heff_drop(v_h_2418);
          v_x2_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_2419});
        }
        switch (heff_tag_of(v_x2_2431)) {
        case TAG_MkPair: {
          V v_s_2433 = heff_field(v_x2_2431, 1);
          V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2433});
        }
        default: return heff_nomatch(v_x2_2431);
        }
      }
    }
  } else {
    heff_drop(v_b_242);
    heff_drop(v_depth_245);
    heff_drop(v_safe_246);
    HeffT2 v_t_2435 = (g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(heff_clo_n(g_heff_2ecompile_2esimplify_2easkedAs_lam0, 1, 1, (V[]){v_h_240}), v_p_244));
    {
      V v_field_2436 = v_t_2435.f[0];
      V v_field_2437 = v_t_2435.f[1];
      V v_x_2438 = v_field_2436;
      heff_drop(v_x_2438);
      V v_s_2439 = v_field_2437;
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2439});
    }
  }
}
V g_heff_2ecompile_2esimplify_2easkedAs_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2easkedAs(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2esimplify_2easkedAs_lam0(V self, V *args) {
  V v_m_2434 = args[0];
  V v_h_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_2434; V a_1 = v_h_240; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_h_240); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eposOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eposOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eposOf(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_argv_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_a_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      v_t_2444 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_245, 0));
      heff_drop(v_y_245);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_a_243, 0ULL, 3);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_a_243, 0ULL, 4);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_a_243, 0ULL, 3);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_a_243, 0ULL, 3);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_a_243, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_t_2444);
      V v_cell_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_241), heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2esimplify_2eposOf_24dps(v_x_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_argv_244, heff_dup(v_cell_2445)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    } else {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2444);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_argv_244;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eposOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eposOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2etagGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagGo_24dps_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2etagGo_24dps(V v_s_240, V v_g_241, V v_env_242, V v_b_243, V v_x5_244, V v_x6_245, V v_x7_246, V v_i_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    heff_drop(v_g_241);
    heff_drop(v_env_242);
    heff_drop(v_b_243);
    heff_drop(v_x6_245);
    heff_drop(v_x7_246);
    heff_drop(v_i_247);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_249 = heff_field(v_x5_244, 0);
    V v_sts_2410 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x6_245)) {
    case TAG_Nil: {
      heff_drop(v_s_240);
      heff_drop(v_g_241);
      heff_drop(v_env_242);
      heff_drop(v_b_243);
      heff_drop(v_x7_246);
      heff_drop(v_i_247);
      heff_drop(v_st_249);
      heff_drop(v_sts_2410);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x6_245, 0);
      V v_xs_2412 = heff_field(v_x6_245, 1);
      V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
      switch (heff_tag_of(v_x7_246)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_g_241);
        heff_drop(v_env_242);
        heff_drop(v_b_243);
        heff_drop(v_i_247);
        heff_drop(v_st_249);
        heff_drop(v_sts_2410);
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_x_2411);
        heff_drop(v_xs_2412);
        heff_drop_cell(v_ru_24x6_245_24Cons, 2);
        return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
      }
      case TAG_Cons: {
        V v_a_2413 = heff_field(v_x7_246, 0);
        V v_argv_2414 = heff_field(v_x7_246, 1);
        heff_take_n(v_x7_246, 3ULL, 2);
        V v_t_2418;
        if ((heff_dup(v_st_249) == NTAG(TAG_True))) {
          heff_drop(v_st_249);
          V v_t_2415 = (g_heff_2ecompile_2esimplify_2evalueTag(v_a_2413));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            V v_t_2416 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
            V v_x_2417 = ({ V a_0 = heff_dup(v_s_240); V a_1 = heff_rec_n(4, shape_deeper__env__self__at, (V[]){MK_INT(3LL), heff_dup(v_env_242), heff_dup(v_g_241), heff_dup(v_i_247)}); V a_2 = v_x_2411; V a_3 = MK_INT(0LL); V a_4 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2etakenW(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2411); r_; });
            v_t_2418 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2417, 1));
            heff_drop(v_x_2417);
          } else {
            heff_drop_cell(v_ru_24x5_244_24Cons, 2);
            heff_drop(v_x_2411);
            heff_drop(v_t_2415);
            v_t_2418 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_st_249);
          heff_drop_cell(v_ru_24x5_244_24Cons, 2);
          heff_drop(v_x_2411);
          heff_drop(v_a_2413);
          v_t_2418 = NTAG(TAG_False);
        }
        V v_cell_2419 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
        V v_u_2420 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2419));
        heff_drop(v_u_2420);
        V t_0 = v_s_240;
        V t_1 = v_g_241;
        V t_2 = v_env_242;
        V t_3 = v_b_243;
        V t_4 = v_sts_2410;
        V t_5 = v_xs_2412;
        V t_6 = v_argv_2414;
        V t_7 = heff_intAdd(v_i_247, MK_INT(1LL));
        V t_8 = v_cell_2419;
        v_s_240 = t_0;
        v_g_241 = t_1;
        v_env_242 = t_2;
        v_b_243 = t_3;
        v_x5_244 = t_4;
        v_x6_245 = t_5;
        v_x7_246 = t_6;
        v_i_247 = t_7;
        v_d_248 = t_8;
        goto top;
      }
      default: return heff_nomatch(v_x7_246);
      }
    }
    default: return heff_nomatch(v_x6_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2etagGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaWanted_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaWanted(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ELet: {
    V v_e_244 = heff_field(v_x2_241, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_244)));
    V v_t_2410;
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      V v_y_249 = v_field_247;
      v_t_2410 = v_y_249;
    }
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2ecapturing(v_t_2410));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_s_240);
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_244)));
      V v_t_2417;
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        heff_drop(v_x_2415);
        V v_y_2416 = v_field_2414;
        v_t_2417 = v_y_2416;
      }
      V v_x_2418 = ({ V a_0 = v_s_240; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2emissingOf(a_0, a_1)); heff_drop(v_t_2417); r_; });
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2418, 1));
      heff_drop(v_x_2418);
      return v_ret_24bool;
    }
  }
  default: {
    V v_x_2419 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2419, 1));
    heff_drop(v_x_2419);
    return v_ret_24bool;
  }
  }
}
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaWanted(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_argv_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emovesFirst_clo), 1, (V[]){heff_dup(v_s_240)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_argv_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(v_s_240, v_argv_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_242);
      heff_drop(v_argv_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ELam: {
      V v_xs_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_244), heff_dup(v_b_245)})));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x21_2410 = v_field_249;
            switch (heff_tag_of(v_x21_2410)) {
            case TAG_MkPair: {
              V v_argv_2411 = heff_field(v_x21_2410, 0);
              V v_f_2412 = heff_field(v_x21_2410, 1);
              V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
              V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, v_b_245}), v_argv_2411});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_f_2412})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2410)}});
            }
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_xs_244);
            heff_drop(v_b_245);
            heff_drop(v_field_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2414 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_rest_243)));
        V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_240}), v_rest_243});
          V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, v_b_245})});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
        } else {
          heff_drop(v_k_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_xs_244);
          heff_drop(v_b_245);
          heff_drop(v_t_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: {
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x21_242)));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(v_k_240, v_rest_243));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x21_2422 = v_field_2421;
            switch (heff_tag_of(v_x21_2422)) {
            case TAG_MkPair: {
              V v_argv_2423 = heff_field(v_x21_2422, 0);
              V v_f_2424 = heff_field(v_x21_2422, 1);
              V v_ru_24x21_2422_24MkPair = heff_take_reuse_n(v_x21_2422, 3ULL, 2);
              V v_t_2425 = heff_tag_at_n(v_ru_24x21_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_242, v_argv_2423}), v_f_2424});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x21_2422)}});
            }
          } else {
            heff_drop(v_x21_242);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_field_2421);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_k_240);
        heff_drop(v_x21_242);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2418);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V v_l_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_argv_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_x312_247 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_247)) {
      case TAG_EVar: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_x312_247, 0);
        heff_take_n(v_x312_247, 1ULL, 2);
        HeffT2 v_t_2419 = ({ V a_0 = v_l_240; V a_1 = v_fs_2417; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2efieldIn_24cpr(a_0, a_1)); heff_drop(v_fs_2417); r_; });
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x_2422 = v_field_2421;
            V v_t_2423 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_246, v_argv_241));
            V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_x_2422; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2423); r_; });
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2424});
          } else {
            heff_drop(v_argv_241);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_xs_246);
            heff_drop(v_field_2421);
            return NTAG(TAG_Nothing);
          }
        }
      }
      case TAG_EProj: {
        heff_take_n(v_x312_247, 0ULL, 4);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_take_nf(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_take_na(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBool: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ESet: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EValues: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x312_247);
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBool: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EValues: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ebuiltFieldOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_245, v_l_240, 1)) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, heff_dup(v_l_240), v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eothersPure(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_248 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_247), v_f_246));
  if ((heff_dup(v_x_248) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    V v_t_249 = ({ V a_0 = v_l_240; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2esimplify_2eothersPure(a_0, a_1)); heff_drop(v_l_240); r_; });
    V f_ = v_t_249;
    args[0] = v_s_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_l_240);
    heff_drop(v_rest_244);
    heff_drop(v_x_248);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_247});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_xs_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_key_240)}));
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_xs_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_244); r_; });
  V v_t_248;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_248 = v_s_242;
  } else {
    heff_drop(v_t_246);
    V v_d_247 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_242, 2), heff_dup(v_key_240), heff_dup(v_b_241)));
    v_t_248 = ({ V rv_2 = v_d_247; V rr_ = heff_rec_reuse_nf(v_s_242, 1019ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048527u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  V v_f_249 = (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_248));
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_249}});
}
Clo g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(V v_g_240, V v_xs_241, V v_b_242, V v_argv_243, V v_x6_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x6_244) == NTAG(TAG_True))) {
    V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
    V v_xs_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
    V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_xs_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_247); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2espec_2eusesOf(v_g_240, v_b_242));
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_241; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(v_t_2411, v_argv_243));
      return heff_tail(v_t_2412, 1, (V[]){v_z_245});
    } else {
      heff_drop(v_g_240);
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      heff_drop(v_t_249);
      V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_243});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_z_245});
    }
  } else {
    heff_drop(v_g_240);
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_245});
  }
}
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(V v_own_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_own_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_x1_247);
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_z_246});
  } else {
    heff_drop(v_x1_247);
    V v_x1_249 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_xs_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
      V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_g_241)}));
      V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_xs_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2411); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_x1_2414 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        if (!(heff_dup(v_x1_2414) == NTAG(TAG_True))) {
          heff_drop(v_own_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          heff_drop(v_x1_2414);
          V v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_z_246});
        } else {
          heff_drop(v_x1_2414);
          HeffT2 v_t_2416 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_x_2419 = v_field_2417;
            V v_s_2420 = v_field_2418;
            return (g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(v_own_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2419, v_s_2420));
          }
        }
      } else {
        heff_drop(v_t_2413);
        HeffT2 v_t_2421 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
        {
          V v_field_2422 = v_t_2421.f[0];
          V v_field_2423 = v_t_2421.f[1];
          V v_x_2424 = v_field_2422;
          V v_s_2425 = v_field_2423;
          return (g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(v_own_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2424, v_s_2425));
        }
      }
    }
    case TAG_Cons: {
      V v_ru_24x1_249_24Cons = heff_take_reuse_n(v_x1_249, 0ULL, 2);
      HeffT2 v_t_2428 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_s_2432 = v_field_2430;
        return (g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2(v_ru_24x1_249_24Cons, v_own_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2431, v_s_2432));
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(V v_lit_240, V v_g_241, V v_xs_242, V v_b_243, V v_as0_244, V v_z_245) {
top: ;
  V v_made_246 = (g_list_2ezipWith_24s528321443x971020870(v_as0_244, heff_dup(v_lit_240)));
  V v_t_247 = (g_heff_2ecompile_2esimplify_2etagMarks(heff_dup(v_z_245), heff_dup(v_g_241), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_lit_240)));
  V v_x2_248 = heff_tr(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(v_g_241, v_xs_242, v_b_243, v_lit_240, v_made_246, v_t_247, v_z_245));
  return v_x2_248;
}
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam17(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V v_f_240, V v_argv_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_241));
  if (heff_intEq_c(v_t_242, MK_INT(0LL))) {
    heff_drop(v_argv_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam0, 1, 1, (V[]){v_f_240});
  } else {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EGlobal: {
      V v_g_244 = heff_dup(heff_field(v_f_240, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam1, 1, 3, (V[]){v_argv_241, v_f_240, v_g_244});
    }
    case TAG_ELam: {
      V v_xs_24146 = heff_field(v_f_240, 0);
      V v_it2_24147 = heff_field(v_f_240, 1);
      V v_ru_24f_240_24ELam = heff_take_reuse_n(v_f_240, 3ULL, 2);
      switch (heff_tag_of(v_it2_24147)) {
      case TAG_ETag: {
        V v_t_24148 = heff_field(v_it2_24147, 0);
        V v_es_24149 = heff_field(v_it2_24147, 1);
        V v_ts_24150 = heff_field(v_it2_24147, 2);
        V v_ru_24it2_24147_24ETag = heff_take_reuse_n(v_it2_24147, 7ULL, 3);
        V v_t_24151 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24146));
        V v_t_24152 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_241));
        if (heff_intEq_c(v_t_24151, v_t_24152)) {
          V v_t_24153 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_24146, v_es_24149));
          if ((heff_dup(v_t_24153) == NTAG(TAG_True))) {
            heff_drop(v_xs_24146);
            heff_drop_cell(v_ru_24f_240_24ELam, 2);
            heff_drop(v_es_24149);
            heff_drop_cell(v_ru_24it2_24147_24ETag, 3);
            heff_drop(v_t_24153);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam5, 1, 3, (V[]){v_t_24148, v_argv_241, v_ts_24150});
          } else {
            heff_drop(v_t_24153);
            return (g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(v_ru_24f_240_24ELam, v_xs_24146, heff_tag_at_n(v_ru_24it2_24147_24ETag, TAG_ETag, 3, (V[]){v_t_24148, v_es_24149, v_ts_24150}), v_argv_241));
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(v_ru_24f_240_24ELam, v_xs_24146, heff_tag_at_n(v_ru_24it2_24147_24ETag, TAG_ETag, 3, (V[]){v_t_24148, v_es_24149, v_ts_24150}), v_argv_241));
        }
      }
      default: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(v_ru_24f_240_24ELam, v_xs_24146, v_it2_24147, v_argv_241));
      }
      }
    }
    case TAG_EApp: {
      V v_g_24155 = heff_field(v_f_240, 0);
      V v_bs_24156 = heff_field(v_f_240, 1);
      V v_ru_24f_240_24EApp = heff_take_reuse_n(v_f_240, 3ULL, 2);
      V v_argv_24157 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_240_24EApp, v_bs_24156, v_argv_241));
      V t_0 = v_g_24155;
      V t_1 = v_argv_24157;
      v_f_240 = t_0;
      v_argv_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_x_24158 = heff_field(v_f_240, 0);
      V v_a_24159 = heff_field(v_f_240, 1);
      V v_b_24160 = heff_field(v_f_240, 2);
      heff_take_n(v_f_240, 7ULL, 3);
      V v_m_24161 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_24160, v_argv_241));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam6, 1, 3, (V[]){v_m_24161, v_x_24158, v_a_24159});
    }
    case TAG_EProj: {
      V v_it1_24166 = heff_dup(heff_field(v_f_240, 0));
      V v_l_24167 = heff_dup(heff_field(v_f_240, 1));
      V v_sh_24168 = heff_dup(heff_field(v_f_240, 2));
      V v_t_24169 = heff_dup(heff_field(v_f_240, 3));
      switch (heff_tag_of(v_it1_24166)) {
      case TAG_EGlobal: {
        V v_g_24170 = heff_field(v_it1_24166, 0);
        heff_take_n(v_it1_24166, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam7, 1, 6, (V[]){v_g_24170, v_l_24167, v_f_240, v_argv_241, v_sh_24168, v_t_24169});
      }
      case TAG_EApp: {
        V v_it11_24200 = heff_field(v_it1_24166, 0);
        V v_bs_24201 = heff_field(v_it1_24166, 1);
        heff_take_n(v_it1_24166, 3ULL, 2);
        heff_drop(v_sh_24168);
        heff_drop(v_t_24169);
        switch (heff_tag_of(v_it11_24200)) {
        case TAG_EGlobal: {
          V v_g_24202 = heff_field(v_it11_24200, 0);
          heff_take_n(v_it11_24200, 1ULL, 1);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam9, 1, 5, (V[]){v_g_24202, v_bs_24201, v_argv_241, v_f_240, v_l_24167});
        }
        default: {
          heff_drop(v_l_24167);
          heff_drop(v_it11_24200);
          heff_drop(v_bs_24201);
          V v_x_24217 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam10, 1, 1, (V[]){v_x_24217});
        }
        }
      }
      default: {
        heff_drop(v_it1_24166);
        heff_drop(v_l_24167);
        heff_drop(v_sh_24168);
        heff_drop(v_t_24169);
        V v_x_24219 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam11, 1, 1, (V[]){v_x_24219});
      }
      }
    }
    case TAG_EMatch: {
      V v_s_24221 = heff_field(v_f_240, 0);
      V v_arms_24222 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam12, 1, 3, (V[]){v_argv_241, v_s_24221, v_arms_24222});
    }
    case TAG_EPrim: {
      V v_x_24234 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam15, 1, 1, (V[]){v_x_24234});
    }
    case TAG_ESet: {
      V v_xs_24236 = heff_field(v_f_240, 0);
      V v_a_24237 = heff_field(v_f_240, 1);
      V v_b_24238 = heff_field(v_f_240, 2);
      heff_take_n(v_f_240, 7ULL, 3);
      V v_m_24239 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_24238, v_argv_241));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam16, 1, 3, (V[]){v_m_24239, v_xs_24236, v_a_24237});
    }
    default: {
      V v_x_24244 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam17, 1, 1, (V[]){v_x_24244});
    }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_240, v_s_243});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_argv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_241, v_s_249});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam3(V self, V *args) {
  V v_s_2410 = args[0];
  V v_argv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_241, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam4(V self, V *args) {
  V v_s_2426 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_argv_2417 = heff_env(self)[1];
  V v_f_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_s_2426, 7)), 0, 7);
  V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_g_2416; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_t_2427); r_; });
  V v_t_2429 = (g_heff_2ecompile_2esimplify_2eunrollOf(heff_dup(v_s_2426), heff_dup(v_g_2416), v_argv_2417, v_t_2428));
  HeffT2 v_t_2430 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2429, v_s_2426));
  {
    V v_field_2431 = v_t_2430.f[0];
    V v_field_2432 = v_t_2430.f[1];
    V v_x_2433 = v_field_2431;
    V v_s_2434 = v_field_2432;
    V v_f_2435 = v_f_2415;
    V v_g_2436 = v_g_2416;
    V v_argv_2437 = v_argv_2417;
    V v_x5_2438 = v_x_2433;
    V v_p_2439 = v_s_2434;
    switch (heff_tag_of(v_x5_2438)) {
    case TAG_Nothing: {
      V v_f_2440 = v_f_2435;
      V v_g_2441 = v_g_2436;
      V v_argv_2442 = v_argv_2437;
      V v_s_2443 = v_p_2439;
      V v_kinds_2444 = heff_get_n(heff_dup(heff_rfield(v_s_2443, 7)), 1, 7);
      V v_argv_2445 = heff_dup(v_argv_2442);
      HeffT2 v_t_2446 = (g_heff_2ecompile_2esimplify_2eknownCopy_24cpr(heff_dup(v_s_2443), v_g_2441, heff_dup(v_argv_2442)));
      V v_t_2499;
      {
        V v_field_2448 = v_t_2446.f[1];
        int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
        if ((v_tag_2447 == ((int64_t)0ULL))) {
          V v_x31_2449 = v_field_2448;
          switch (heff_tag_of(v_x31_2449)) {
          case TAG_EVar: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ELam: {
            V v_xs_2452 = heff_field(v_x31_2449, 0);
            V v_b_2453 = heff_field(v_x31_2449, 1);
            V v_ru_24x31_2449_24ELam = heff_take_reuse_n(v_x31_2449, 3ULL, 2);
            V v_t_2454 = (g_heff_2ecompile_2esimplify_2etoldTo(heff_dup(v_b_2453), heff_dup(v_xs_2452), heff_dup(v_argv_2445)));
            if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
              heff_drop(v_kinds_2444);
              heff_drop(v_argv_2445);
              heff_drop(v_t_2454);
              v_t_2499 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2449_24ELam, TAG_ELam, 2, (V[]){v_xs_2452, v_b_2453})});
            } else {
              heff_drop(v_t_2454);
              V v_lit_2455 = heff_dup(v_xs_2452);
              V v_lit_2456 = heff_dup(v_b_2453);
              heff_drop(v_lit_2456);
              V v_kinds_2457 = v_kinds_2444;
              V v_argv_2458 = v_argv_2445;
              V v_x_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2458));
              V v_y_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_lit_2455));
              V v_t_2463;
              if (heff_intLt_c(v_y_2460, v_x_2459)) {
                V v_t_2461 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_lit_2455; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_lit_2455); r_; });
                V v_t_2462 = ({ V a_0 = v_t_2461; V a_1 = v_argv_2458; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_argv_2458); r_; });
                v_t_2463 = ({ V a_0 = v_kinds_2457; V a_1 = v_t_2462; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_kinds_2457); heff_drop(v_t_2462); r_; });
              } else {
                heff_drop(v_lit_2455);
                heff_drop(v_kinds_2457);
                heff_drop(v_argv_2458);
                v_t_2463 = NTAG(TAG_False);
              }
              if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
                heff_drop(v_t_2463);
                v_t_2499 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2449_24ELam, TAG_ELam, 2, (V[]){v_xs_2452, v_b_2453})});
              } else {
                heff_drop(v_xs_2452);
                heff_drop(v_b_2453);
                heff_drop_cell(v_ru_24x31_2449_24ELam, 2);
                heff_drop(v_t_2463);
                v_t_2499 = NTAG(TAG_Nothing);
              }
            }
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x31_2449, 0ULL, 3);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_x31_2449, 0ULL, 4);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_x31_2449, 0ULL, 3);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EAbandon: {
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_x31_2449, 0ULL, 3);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_x31_2449, 0ULL, 1);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_x31_2449, 0ULL, 2);
            heff_drop(v_kinds_2444);
            heff_drop(v_argv_2445);
            v_t_2499 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x31_2449);
          }
        } else {
          heff_drop(v_kinds_2444);
          heff_drop(v_argv_2445);
          heff_drop(v_field_2448);
          v_t_2499 = NTAG(TAG_Nothing);
        }
      }
      HeffT2 v_t_24100 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2499, heff_dup(v_s_2443)));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_x_24103 = v_field_24101;
        V v_s_24104 = v_field_24102;
        V v_more_24108;
        switch (heff_tag_of(v_x_24103)) {
        case TAG_Nothing: {
          heff_drop_rec(v_s_2443, 10);
          v_more_24108 = MK_INT(24LL);
          break;
        }
        case TAG_Just: {
          V v_b_24105 = heff_dup(heff_field(v_x_24103, 0));
          V v_t_24106 = heff_get_n(heff_get_n(v_s_2443, 7, 10), 1, 7);
          V v_t_24107 = ({ V a_0 = v_t_24106; V a_1 = v_b_24105; V a_2 = v_argv_2442; V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_24106); heff_drop(v_b_24105); r_; });
          if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
            heff_drop(v_t_24107);
            v_more_24108 = MK_INT(160LL);
          } else {
            heff_drop(v_t_24107);
            v_more_24108 = MK_INT(24LL);
          }
          break;
        }
        default: heff_nomatch(v_x_24103);
        }
        switch (heff_tag_of(v_x_24103)) {
        case TAG_Nothing: {
          heff_drop(v_more_24108);
          V v_x_24109 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_2440, v_argv_2442));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24109, v_s_24104});
        }
        case TAG_Just: {
          V v_b_24110 = heff_field(v_x_24103, 0);
          heff_take_n(v_x_24103, 1ULL, 1);
          V v_t_24111 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_2440, heff_dup(v_argv_2442)));
          V v_t_24112 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_24110, v_argv_2442));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(v_more_24108, v_t_24111, v_t_24112, v_s_24104));
        }
        default: return heff_nomatch(v_x_24103);
        }
      }
    }
    case TAG_Just: {
      V v_b_24113 = heff_field(v_x5_2438, 0);
      heff_take_n(v_x5_2438, 1ULL, 1);
      V v_g_24114 = v_g_2436;
      V v_s_24115 = v_p_2439;
      HeffT2 v_t_24116 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_s_24115, 9), v_g_24114));
      V v_t_24120;
      {
        V v_field_24118 = v_t_24116.f[1];
        int64_t v_tag_24117 = ((int64_t)v_t_24116.f[0]);
        if ((v_tag_24117 == ((int64_t)0ULL))) {
          V v_x_24119 = v_field_24118;
          v_t_24120 = v_x_24119;
        } else {
          heff_drop(v_field_24118);
          v_t_24120 = MK_INT(0LL);
        }
      }
      V v_u_24121 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_24115, 9), v_g_24114, heff_intAdd(v_t_24120, MK_INT(1LL))));
      V v_t_24122 = ({ V rv_9 = v_u_24121; V rr_ = heff_rec_reuse_nf(v_s_24115, 511ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 262143u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
      V v_x2_24123 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_24122});
      switch (heff_tag_of(v_x2_24123)) {
      case TAG_MkPair: {
        V v_s_24125 = heff_field(v_x2_24123, 1);
        V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 2ULL, 2);
        V v_orig_24126 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_2435, heff_dup(v_argv_2437)));
        V v_f_24127 = (g_heff_2ecompile_2esimplify_2eprunedCopy(v_b_24113, v_argv_2437));
        V v_m_24128 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_f_24127, v_argv_2437));
        return (g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(v_ru_24x2_24123_24MkPair, MK_INT(24LL), v_orig_24126, v_m_24128, v_s_24125));
      }
      default: return heff_nomatch(v_x2_24123);
      }
    }
    default: return heff_nomatch(v_x5_2438);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_list_2eany_24s756915015x218492736(v_argv_241));
  V v_m_2411;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_argv_241; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_m_2411 = (g_prelude_2etraverse_24s672366786x467588702(heff_dup(v_s_245), v_argv_241));
    } else {
      heff_drop(v_t_248);
      v_m_2411 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam2, 1, 1, (V[]){v_argv_241});
    }
  } else {
    heff_drop(v_t_246);
    v_m_2411 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam3, 1, 1, (V[]){v_argv_241});
  }
  V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){heff_dup(v_s_245)}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_f_2415 = v_f_240;
    V v_g_2416 = heff_dup(v_g_244);
    V v_argv_2417 = heff_dup(v_x_2413);
    HeffT2 v_t_2418 = ({ V b_0 = heff_get_n(v_s_245, 2, 10); V a_1 = v_g_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_m_24129;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x51_2421 = v_field_2420;
        switch (heff_tag_of(v_x51_2421)) {
        case TAG_ELam: {
          V v_xs_2422 = heff_field(v_x51_2421, 0);
          heff_take_n(v_x51_2421, 1ULL, 2);
          V v_t_2424 = (g_list_2emap_24s418652630x628827683(heff_dup(v_argv_2417)));
          V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2424); r_; });
          if (((heff_dup(v_t_2425) == NTAG(TAG_True)) && ({ V v_t_24246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2422)); int c_ = ({ V v_t_24247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2417)); int c_ = heff_intEq_c_lent(v_t_24246, v_t_24247, 0); heff_drop(v_t_24247); c_; }); heff_drop(v_t_24246); c_; }))) {
            heff_drop(v_xs_2422);
            heff_drop(v_t_2425);
            v_m_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_clo), 3, (V[]){v_f_2415, v_g_2416, v_argv_2417}));
          } else {
            heff_drop(v_xs_2422);
            heff_drop(v_t_2425);
            v_m_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_clo), 3, (V[]){v_f_2415, v_g_2416, v_argv_2417}));
          }
          break;
        }
        default: {
          heff_drop(v_x51_2421);
          v_m_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_clo), 3, (V[]){v_f_2415, v_g_2416, v_argv_2417}));
          break;
        }
        }
      } else {
        heff_drop(v_field_2420);
        v_m_24129 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam4, 1, 3, (V[]){v_g_2416, v_argv_2417, v_f_2415});
      }
    }
    V v_x2_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_s_2414}));
    switch (heff_tag_of(v_x2_24130)) {
    case TAG_MkPair: {
      V v_x_24131 = heff_field(v_x2_24130, 0);
      V v_s_24132 = heff_field(v_x2_24130, 1);
      heff_take_n(v_x2_24130, 3ULL, 2);
      V v_t_24133 = (g_heff_2ecompile_2esimplify_2estillCall(v_g_244, v_x_24131));
      if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
        heff_drop(v_x_24131);
        heff_drop(v_t_24133);
        V v_g_24134 = v_g_244;
        V v_argv_24135 = v_x_2413;
        V v_s_24136 = v_s_24132;
        V v_t_24137 = heff_get_n(heff_dup(heff_rfield(v_s_24136, 7)), 0, 7);
        HeffT2 v_t_24138 = ({ V a_0 = v_t_24137; V a_1 = v_g_24134; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_24137); r_; });
        {
          V v_field_24140 = v_t_24138.f[1];
          int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
          if ((v_tag_24139 == ((int64_t)0ULL))) {
            V v_it1_24141 = v_field_24140;
            switch (heff_tag_of(v_it1_24141)) {
            case TAG_ELam: {
              V v_xs_24142 = heff_field(v_it1_24141, 0);
              V v_b_24143 = heff_field(v_it1_24141, 1);
              heff_take_n(v_it1_24141, 3ULL, 2);
              return (g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2(v_ru_24x2_2412_24MkPair, v_g_24134, v_xs_24142, v_b_24143, v_argv_24135, v_s_24136));
            }
            default: {
              heff_drop(v_it1_24141);
              V v_x_24144 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24134}), v_argv_24135));
              return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_24144, v_s_24136});
            }
            }
          } else {
            heff_drop(v_field_24140);
            V v_x_24145 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24134}), v_argv_24135));
            return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_24145, v_s_24136});
          }
        }
      } else {
        heff_drop(v_g_244);
        heff_drop(v_x_2413);
        heff_drop(v_t_24133);
        return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_24131, v_s_24132});
      }
    }
    default: return heff_nomatch(v_x2_24130);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam5(V self, V *args) {
  V v_s_24154 = args[0];
  V v_t_24148 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ts_24150 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24148, v_argv_241, v_ts_24150}), v_s_24154});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam6(V self, V *args) {
  V v_s_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  V v_x_24158 = heff_env(self)[1];
  V v_a_24159 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24163 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_s_24162}));
  switch (heff_tag_of(v_x2_24163)) {
  case TAG_MkPair: {
    V v_x_24164 = heff_field(v_x2_24163, 0);
    V v_s_24165 = heff_field(v_x2_24163, 1);
    V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24158, v_a_24159, v_x_24164}), v_s_24165});
  }
  default: return heff_nomatch(v_x2_24163);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam8(V self, V *args) {
  V v_s_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_s_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_s_24197 = heff_field(v_x2_24195, 1);
    heff_take_n(v_x2_24195, 3ULL, 2);
    V v_f_24198 = (g_heff_2ecompile_2esimplify_2eprunedCopy(v_x_24196, v_argv_241));
    V v_t_24199 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_f_24198, v_argv_241));
    V f_ = v_t_24199;
    args[0] = v_s_24197;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam7(V self, V *args) {
  V v_s_24171 = args[0];
  V v_g_24170 = heff_env(self)[0];
  V v_l_24167 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_argv_241 = heff_env(self)[3];
  V v_sh_24168 = heff_env(self)[4];
  V v_t_24169 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24172 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_24171, 2), v_g_24170));
  HeffT2 v_t_24173 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_24172, v_s_24171));
  {
    V v_field_24174 = v_t_24173.f[0];
    V v_field_24175 = v_t_24173.f[1];
    V v_x_24176 = v_field_24174;
    V v_s_24177 = v_field_24175;
    switch (heff_tag_of(v_x_24176)) {
    case TAG_Nothing: {
      heff_drop(v_sh_24168);
      heff_drop(v_t_24169);
      HeffT2 v_t_24178 = ({ V a_0 = v_g_24170; V a_1 = v_l_24167; V a_2 = v_s_24177; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eknownField_24cpr(a_0, a_1, a_2)); heff_drop(v_g_24170); heff_drop(v_l_24167); r_; });
      {
        V v_field_24179 = v_t_24178.f[0];
        V v_field_24180 = v_t_24178.f[1];
        V v_x_24181 = v_field_24179;
        V v_s_24182 = v_field_24180;
        switch (heff_tag_of(v_x_24181)) {
        case TAG_Nothing: {
          V v_x_24183 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24183, v_s_24182});
        }
        case TAG_Just: {
          V v_v_24184 = heff_field(v_x_24181, 0);
          heff_take_n(v_x_24181, 1ULL, 1);
          V v_t_24185 = (g_list_2eany_24s415398368x1824706470(v_argv_241));
          V v_t_24186;
          if ((heff_dup(v_t_24185) == NTAG(TAG_True))) {
            heff_drop(v_t_24185);
            v_t_24186 = MK_INT(160LL);
          } else {
            heff_drop(v_t_24185);
            v_t_24186 = MK_INT(24LL);
          }
          V v_t_24187 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, heff_dup(v_argv_241)));
          V v_t_24188 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_v_24184, v_argv_241));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24186, v_t_24187, v_t_24188, v_s_24182));
        }
        default: return heff_nomatch(v_x_24181);
        }
      }
    }
    case TAG_Just: {
      V v_b_24189 = heff_field(v_x_24176, 0);
      heff_take_n(v_x_24176, 1ULL, 1);
      heff_drop(v_g_24170);
      V v_t_24190 = (g_list_2eany_24s415398368x1824706470(v_argv_241));
      V v_t_24191;
      if ((heff_dup(v_t_24190) == NTAG(TAG_True))) {
        heff_drop(v_t_24190);
        v_t_24191 = MK_INT(160LL);
      } else {
        heff_drop(v_t_24190);
        v_t_24191 = MK_INT(24LL);
      }
      V v_t_24192 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, heff_dup(v_argv_241)));
      V v_m_24193 = (g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(v_l_24167, v_sh_24168, v_t_24169, v_b_24189));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24191, v_t_24192, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam8, 1, 2, (V[]){v_m_24193, v_argv_241}), v_s_24177));
    }
    default: return heff_nomatch(v_x_24176);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam9(V self, V *args) {
  V v_s_24203 = args[0];
  V v_g_24202 = heff_env(self)[0];
  V v_bs_24201 = heff_env(self)[1];
  V v_argv_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_l_24167 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_lit_24204 = heff_dup(v_g_24202);
  V v_lit_24205 = heff_dup(v_bs_24201);
  V v_all_24206 = heff_get_n(heff_dup(heff_rfield(v_s_24203, 7)), 0, 7);
  V v_t_24207 = (g_list_2emap_24s1112048172x371485672(heff_dup(v_lit_24205)));
  V v_t_24208 = ({ V a_0 = v_t_24207; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24207); r_; });
  V v_t_24211;
  if ((heff_dup(v_t_24208) == NTAG(TAG_True))) {
    heff_drop(v_t_24208);
    V v_t_24209 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_lit_24205; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_lit_24205); r_; });
    V v_t_24210 = ({ V a_0 = v_all_24206; V a_1 = v_lit_24204; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_all_24206); r_; });
    v_t_24211 = ({ V a_0 = v_lit_24204; V a_1 = v_t_24209; V a_2 = v_t_24210; V r_ = (g_heff_2ecompile_2esimplify_2ebuilds(a_0, a_1, a_2)); heff_drop(v_t_24210); r_; });
  } else {
    heff_drop(v_lit_24204);
    heff_drop(v_lit_24205);
    heff_drop(v_all_24206);
    heff_drop(v_t_24208);
    v_t_24211 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
    heff_drop(v_t_24211);
    V v_t_24212 = (g_list_2eany_24s415398368x1824706470(v_argv_241));
    V v_t_24213;
    if ((heff_dup(v_t_24212) == NTAG(TAG_True))) {
      heff_drop(v_t_24212);
      v_t_24213 = MK_INT(160LL);
    } else {
      heff_drop(v_t_24212);
      v_t_24213 = MK_INT(24LL);
    }
    V v_t_24214 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_240), heff_dup(v_argv_241)));
    V v_t_24215 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_clo), 5, (V[]){v_g_24202, v_bs_24201, v_f_240, v_l_24167, v_argv_241}));
    return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24213, v_t_24214, v_t_24215, v_s_24203));
  } else {
    heff_drop(v_g_24202);
    heff_drop(v_bs_24201);
    heff_drop(v_l_24167);
    heff_drop(v_t_24211);
    V v_x_24216 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24216, v_s_24203});
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam10(V self, V *args) {
  V v_s_24218 = args[0];
  V v_x_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24218});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam11(V self, V *args) {
  V v_s_24220 = args[0];
  V v_x_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24219, v_s_24220});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam13(V self, V *args) {
  V v_s_24227 = args[0];
  V v_argv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_241, v_s_24227});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam14(V self, V *args) {
  V v_s_24228 = args[0];
  V v_argv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_241, v_s_24228});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam12(V self, V *args) {
  V v_s_24223 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_s_24221 = heff_env(self)[1];
  V v_arms_24222 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24224 = (g_list_2eany_24s756915015x218492736(v_argv_241));
  V v_m_24229;
  if ((heff_dup(v_t_24224) == NTAG(TAG_True))) {
    heff_drop(v_t_24224);
    V v_t_24225 = heff_get_n(heff_dup(heff_rfield(v_s_24223, 7)), 1, 7);
    V v_t_24226 = ({ V a_0 = v_t_24225; V a_1 = v_argv_241; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_24225); r_; });
    if ((heff_dup(v_t_24226) == NTAG(TAG_True))) {
      heff_drop(v_t_24226);
      v_m_24229 = (g_prelude_2etraverse_24s672366786x467588702(heff_dup(v_s_24223), v_argv_241));
    } else {
      heff_drop(v_t_24226);
      v_m_24229 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam13, 1, 1, (V[]){v_argv_241});
    }
  } else {
    heff_drop(v_t_24224);
    v_m_24229 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam14, 1, 1, (V[]){v_argv_241});
  }
  V v_x2_24230 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_s_24223}));
  switch (heff_tag_of(v_x2_24230)) {
  case TAG_MkPair: {
    V v_x_24231 = heff_field(v_x2_24230, 0);
    V v_s_24232 = heff_field(v_x2_24230, 1);
    V v_ru_24x2_24230_24MkPair = heff_take_reuse_n(v_x2_24230, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2(v_ru_24x2_24230_24MkPair, v_s_24221, v_arms_24222, v_x_24231, v_s_24232));
  }
  default: return heff_nomatch(v_x2_24230);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam15(V self, V *args) {
  V v_s_24235 = args[0];
  V v_x_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24234, v_s_24235});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam16(V self, V *args) {
  V v_s_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  V v_xs_24236 = heff_env(self)[1];
  V v_a_24237 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_s_24240}));
  switch (heff_tag_of(v_x2_24241)) {
  case TAG_MkPair: {
    V v_x_24242 = heff_field(v_x2_24241, 0);
    V v_s_24243 = heff_field(v_x2_24241, 1);
    V v_ru_24x2_24241_24MkPair = heff_take_reuse_n(v_x2_24241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24236, v_a_24237, v_x_24242}), v_s_24243});
  }
  default: return heff_nomatch(v_x2_24241);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_lam17(V self, V *args) {
  V v_s_24245 = args[0];
  V v_x_24244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24244, v_s_24245});
}
Clo g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442(V v_x_240, V v_a_241, V v_b_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_240), heff_dup(v_a_241), heff_dup(v_b_242)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_246;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_ESet: {
        V v_ys_248 = heff_field(v_it1_247, 0);
        V v_a2_249 = heff_field(v_it1_247, 1);
        V v_body_2410 = heff_field(v_it1_247, 2);
        V v_ru_24it1_247_24ESet = heff_take_reuse_n(v_it1_247, 7ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_b_242);
        V v_m_2411 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_body_2410));
        V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_243}));
        switch (heff_tag_of(v_x2_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x2_2412, 0);
          V v_s_2414 = heff_field(v_x2_2412, 1);
          V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_247_24ESet, TAG_ESet, 3, (V[]){v_ys_248, v_a2_249, v_x_2413}), v_s_2414});
        }
        default: return heff_nomatch(v_x2_2412);
        }
      }
      default: {
        heff_drop(v_it1_247);
        V v_m_2415 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_243}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_2417}), v_s_2418});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      }
    } else {
      heff_drop(v_field_246);
      V v_m_2419 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
      V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_z_243}));
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_MkPair: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_s_2422 = heff_field(v_x2_2420, 1);
        V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_2421}), v_s_2422});
      }
      default: return heff_nomatch(v_x2_2420);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2egrew_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrew_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2egrew(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_a_242, v_b_244, 0)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_argv_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2egrew(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(V v_lit_240, V v_lit_241, V v_h_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EApp: {
    V v_e1_244 = heff_dup(heff_field(v_e_243, 0));
    switch (heff_tag_of(v_e1_244)) {
    case TAG_EGlobal: {
      V v_g_246 = heff_field(v_e1_244, 0);
      heff_take_n(v_e1_244, 1ULL, 1);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EApp: {
        V v_argv_248 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_h_242)}));
        V v_m_2410 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_249, v_argv_248));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam0, 1, 5, (V[]){v_m_2410, v_g_246, v_h_242, v_lit_240, v_lit_241});
      }
      default: return heff_nomatch(v_e_243);
      }
    }
    default: {
      heff_drop(v_e1_244);
      return (g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam1, 2, 3, (V[]){v_lit_240, v_lit_241, v_h_242}), v_e_243));
    }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam2, 2, 3, (V[]){v_lit_240, v_lit_241, v_h_242}), v_e_243));
  }
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_g_246 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_246, v_h_242, 0)) {
      heff_drop(v_g_246);
      return (g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2(v_ru_24x2_2412_24MkPair, v_lit_240, v_lit_241, v_h_242, v_x_2413, v_s_2414));
    } else {
      heff_drop(v_h_242);
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      V v_t_2415 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_246}), v_x_2413});
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_s_2414});
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_q_2417 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2416);
  return (g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(v_lit_240, v_lit_241, v_h_242, v_q_2417));
}
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_q_2419 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2418);
  return (g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(v_lit_240, v_lit_241, v_h_242, v_q_2419));
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emakeOne_str0, 0, "");
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  V v_h_244 = heff_dup(v_h_241);
  V v_s_245 = v_s_243;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 0, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 2, 7);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 3, 7);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 4, 7);
  V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2410, v_h_244, NTAG(TAG_MkUnit)));
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  V v_p_2414 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_246, v_t_247, v_t_248, v_t_249, v_t_2411, v_t_2412, v_t_2413});
  V v_t_2415 = ({ V rv_7 = v_p_2414; V rr_ = heff_rec_reuse_nf(v_s_245, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x2_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2415});
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 2ULL, 2);
    V v_h_2419 = heff_dup(v_h_241);
    V v_s_2420 = v_s_2418;
    V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_s_2420, 8)), 0, 5);
    HeffT2 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_h_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2421); r_; });
    V v_x2_2448;
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_v_2425 = v_field_2424;
        V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2420, 8)), 1, 5);
        HeffT2 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_h_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2426); heff_drop(v_h_2419); r_; });
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_kc_2430 = v_field_2429;
            V v_ver_2431 = heff_take_field(v_kc_2430, 0);
            V v_made_2432 = heff_get_n(v_kc_2430, 5, 6);
            if ((heff_strEq_c_lent(v_ver_2431, v_v_2425, 0) && !heff_strEq_c_lent(v_v_2425, ((V)&g_heff_2ecompile_2esimplify_2emakeOne_str0), 2))) {
              heff_drop(v_v_2425);
              heff_drop(v_ver_2431);
              switch (heff_tag_of(v_made_2432)) {
              case TAG_Nothing: {
                v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
                break;
              }
              case TAG_Just: {
                V v_km_2433 = heff_field(v_made_2432, 0);
                V v_ru_24made_2432_24Just = heff_take_reuse_n(v_made_2432, 1ULL, 1);
                V v_km_2434 = heff_dup(v_km_2433);
                V v_x2_2435 = heff_tr(heff_call(heff_get_n(v_km_2433, 0, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
                V v_p_2436 = v_s_2420;
                switch (heff_tag_of(v_x2_2435)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24made_2432_24Just, 1);
                  heff_drop_rec(v_km_2434, 2);
                  v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2436});
                  break;
                }
                case TAG_Just: {
                  V v_b_2437 = heff_field(v_x2_2435, 0);
                  heff_take_n(v_x2_2435, 1ULL, 1);
                  HeffT2 v_t_2438 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_get_n(v_km_2434, 1, 2), v_p_2436));
                  {
                    V v_field_2439 = v_t_2438.f[0];
                    V v_field_2440 = v_t_2438.f[1];
                    V v_x_2441 = v_field_2439;
                    V v_s_2442 = v_field_2440;
                    if ((heff_dup(v_x_2441) == NTAG(TAG_True))) {
                      heff_drop(v_x_2441);
                      HeffT2 v_t_2443 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_2437, v_s_2442));
                      {
                        V v_field_2444 = v_t_2443.f[0];
                        V v_field_2445 = v_t_2443.f[1];
                        V v_x_2446 = v_field_2444;
                        V v_s_2447 = v_field_2445;
                        v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24made_2432_24Just, TAG_Just, 1, (V[]){v_x_2446}), v_s_2447});
                      }
                    } else {
                      heff_drop_cell(v_ru_24made_2432_24Just, 1);
                      heff_drop(v_b_2437);
                      heff_drop(v_x_2441);
                      v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2442});
                    }
                  }
                  break;
                }
                default: heff_nomatch(v_x2_2435);
                }
                break;
              }
              default: heff_nomatch(v_made_2432);
              }
            } else {
              heff_drop(v_v_2425);
              heff_drop(v_ver_2431);
              heff_drop(v_made_2432);
              v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
            }
          } else {
            heff_drop(v_v_2425);
            heff_drop(v_field_2429);
            v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
          }
        }
      } else {
        heff_drop(v_h_2419);
        heff_drop(v_field_2424);
        v_x2_2448 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
      }
    }
    switch (heff_tag_of(v_x2_2448)) {
    case TAG_MkPair: {
      V v_x_2449 = heff_field(v_x2_2448, 0);
      V v_s_2450 = heff_field(v_x2_2448, 1);
      heff_take_n(v_x2_2448, 3ULL, 2);
      return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam0, 1, 3, (V[]){heff_dup(v_x_2449), heff_dup(v_h_241), v_b0_242}), heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam1, 2, 3, (V[]){v_x_2449, v_more_240, v_h_241}), v_s_2450));
    }
    default: return heff_nomatch(v_x2_2448);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args) {
  V v_p_2451 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_b0_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2esimplify_2emakeFresh(v_h_241, v_b0_242, v_p_2451));
  }
  case TAG_Just: {
    V v_b_2452 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    heff_drop(v_h_241);
    heff_drop(v_b0_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2452, v_p_2451});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_b3_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b3_2453, v_x_2461}), v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam3(V self, V *args) {
  V v_s_2499 = args[0];
  V v_deps_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_2496, v_s_2499});
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam4(V self, V *args) {
  V v_s_24111 = args[0];
  V v_deps_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_2496, v_s_24111});
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam5(V self, V *args) {
  V v_s_24112 = args[0];
  V v_deps_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_2496, v_s_24112});
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam6(V self, V *args) {
  V v_s_24113 = args[0];
  V v_deps_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_2496, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args) {
  V v_b3_2453 = args[0];
  V v_z_2454 = args[1];
  V v_x_2449 = heff_env(self)[0];
  V v_more_240 = heff_env(self)[1];
  V v_h_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2463;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    v_m_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, MK_INT(5LL), heff_dup(v_h_241), v_b3_2453}));
    break;
  }
  case TAG_Just: {
    V v_t_2456 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b3_2453)));
    V v_t_2457 = (g_heff_2ecompile_2eir_2enubI(v_t_2456));
    V v_m_2458 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2457}));
    v_m_2463 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam2, 1, 2, (V[]){v_m_2458, v_b3_2453});
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_x2_2464 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_z_2454}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_x_2465)) {
    case TAG_MkPair: {
      V v_x_2467 = heff_dup(heff_field(v_x_2465, 0));
      v_t_2469 = v_x_2467;
      break;
    }
    default: heff_nomatch(v_x_2465);
    }
    HeffT2 v_t_2470 = ({ V a_0 = v_x_2449; V a_1 = heff_dup(v_h_241); V a_2 = v_t_2469; V a_3 = v_s_2466; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2erefsMade_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2449); r_; });
    {
      V v_field_2471 = v_t_2470.f[0];
      V v_field_2472 = v_t_2470.f[1];
      V v_x_2473 = v_field_2471;
      heff_drop(v_x_2473);
      V v_s_2474 = v_field_2472;
      V v_h_2475 = heff_dup(v_h_241);
      V v_b_2478;
      switch (heff_tag_of(v_x_2465)) {
      case TAG_MkPair: {
        V v_x_2476 = heff_dup(heff_field(v_x_2465, 0));
        v_b_2478 = v_x_2476;
        break;
      }
      default: heff_nomatch(v_x_2465);
      }
      V v_s_2479 = v_s_2474;
      V v_t_2480 = heff_get_n(heff_dup(heff_rfield(v_s_2479, 7)), 0, 7);
      V v_t_2481 = ({ V a_0 = v_t_2480; V a_1 = v_h_2475; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_2480); r_; });
      V v_t_2482 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_h_2475), heff_dup(v_b_2478)));
      V v_t_2483 = ({ V a_0 = v_t_2482; V a_1 = v_h_2475; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_2482); r_; });
      V v_t_2486;
      if (heff_intLt_c(v_t_2481, v_t_2483)) {
        V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2478), NTAG(TAG_Nil)});
        V v_x_2485 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_2484));
        if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_2485, 1)) {
          heff_drop(v_x_2485);
          v_t_2486 = (g_heff_2ecompile_2esimplify_2erecordAll(v_h_2475, v_b_2478, v_s_2479));
        } else {
          heff_drop(v_h_2475);
          heff_drop(v_b_2478);
          heff_drop(v_x_2485);
          v_t_2486 = v_s_2479;
        }
      } else {
        heff_drop(v_h_2475);
        heff_drop(v_b_2478);
        v_t_2486 = v_s_2479;
      }
      V v_x2_2487 = heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2486});
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_MkPair: {
        V v_s_2489 = heff_field(v_x2_2487, 1);
        V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 2ULL, 2);
        V v_h_2490 = heff_dup(v_h_241);
        V v_hb_2493;
        switch (heff_tag_of(v_x_2465)) {
        case TAG_MkPair: {
          V v_x_2491 = heff_dup(heff_field(v_x_2465, 0));
          v_hb_2493 = v_x_2491;
          break;
        }
        default: heff_nomatch(v_x_2465);
        }
        V v_deps_2496;
        switch (heff_tag_of(v_x_2465)) {
        case TAG_MkPair: {
          V v_y_2495 = heff_dup(heff_field(v_x_2465, 1));
          v_deps_2496 = v_y_2495;
          break;
        }
        default: heff_nomatch(v_x_2465);
        }
        V v_m_24114;
        switch (heff_tag_of(v_hb_2493)) {
        case TAG_ELam: {
          V v_xs_2497 = heff_field(v_hb_2493, 0);
          V v_b_2498 = heff_field(v_hb_2493, 1);
          V v_ru_24hb_2493_24ELam = heff_take_reuse_n(v_hb_2493, 3ULL, 2);
          switch (heff_tag_of(v_deps_2496)) {
          case TAG_Nil: {
            heff_drop(v_h_2490);
            heff_drop(v_xs_2497);
            heff_drop(v_b_2498);
            heff_drop_cell(v_ru_24hb_2493_24ELam, 2);
            v_m_24114 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam3, 1, 1, (V[]){v_deps_2496});
            break;
          }
          case TAG_Cons: {
            V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24hb_2493_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_2497), heff_dup(v_b_2498)}), NTAG(TAG_Nil)});
            V v_x_24103 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_24102));
            if (!heff_intLt_c_lent(MK_INT(50LL), v_x_24103, 1)) {
              heff_drop(v_x_24103);
              V v_t_24104 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2498)));
              V v_xs_24105 = (g_heff_2ecompile_2eir_2enubI(v_t_24104));
              V v_t_24106 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_h_2490)}));
              V v_x1_24107 = ({ V a_0 = v_t_24106; V a_1 = v_xs_24105; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_24105); r_; });
              if (!(heff_dup(v_x1_24107) == NTAG(TAG_True))) {
                heff_drop(v_x1_24107);
                V v_t_24108 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2498)));
                V v_t_24109 = (g_heff_2ecompile_2eir_2enubI(v_t_24108));
                V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_clo), 4, (V[]){v_xs_2497, v_b_2498, v_h_2490, v_t_24109}));
                v_m_24114 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24110, v_deps_2496));
              } else {
                heff_drop(v_h_2490);
                heff_drop(v_xs_2497);
                heff_drop(v_b_2498);
                heff_drop(v_x1_24107);
                v_m_24114 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam4, 1, 1, (V[]){v_deps_2496});
              }
            } else {
              heff_drop(v_h_2490);
              heff_drop(v_xs_2497);
              heff_drop(v_b_2498);
              heff_drop(v_x_24103);
              v_m_24114 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam5, 1, 1, (V[]){v_deps_2496});
            }
            break;
          }
          default: heff_nomatch(v_deps_2496);
          }
          break;
        }
        default: {
          heff_drop(v_h_2490);
          heff_drop(v_hb_2493);
          v_m_24114 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam6, 1, 1, (V[]){v_deps_2496});
          break;
        }
        }
        V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_s_2489}));
        switch (heff_tag_of(v_x2_24115)) {
        case TAG_MkPair: {
          V v_x_24116 = heff_field(v_x2_24115, 0);
          V v_s_24117 = heff_field(v_x2_24115, 1);
          V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
          V v_t_24120;
          switch (heff_tag_of(v_x_2465)) {
          case TAG_MkPair: {
            V v_x_24118 = heff_field(v_x_2465, 0);
            heff_take_n(v_x_2465, 1ULL, 2);
            v_t_24120 = v_x_24118;
            break;
          }
          default: heff_nomatch(v_x_2465);
          }
          V v_t_24121 = heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_t_24120}), NTAG(TAG_Nil)});
          V v_x_24122 = (g_prelude_2e_2b_2b(v_x_24116, v_t_24121));
          return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){v_x_24122, v_s_24117});
        }
        default: return heff_nomatch(v_x2_24115);
        }
      }
      default: return heff_nomatch(v_x2_2487);
      }
    }
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}), v_defs_241));
  V v_safe_243 = heff_take_field(v_sg_242, 0);
  V v_total_244 = heff_get_n(v_sg_242, 1, 2);
  V v_t_245 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  HeffT2 v_t_246 = (g_prelude_2etraverse_24s1252393826x821382319_24cpr(v_defs_241, heff_rec_n(10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_safe_243), v_safe_243, v_total_244, heff_dup(g_std_2eordmap_2eempty_get()), v_t_245, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get()), heff_dup(g_std_2eordmap_2eempty_get())})));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_out_249 = v_field_247;
    V v_st_2410 = v_field_248;
    V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_249)));
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_249)));
    V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_list_2emap_24s1937570095x2110149801(v_out_249));
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = ({ V a_0 = heff_dup(v_st_2410); V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2412, heff_get_n(v_st_2410, 0, 10), v_t_2414, v_t_2417});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str5, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str6, 2, "$s");
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2(V v_tok_240, V v_own_241, V v_g_242, V v_xs_243, V v_b_244, V v_argv_245, V v_marks_246, V v_sh_247, V v_s_248) {
top: ;
  V v_x1_249 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_246), heff_dup(v_xs_243)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nil: {
    V v_t_2410 = heff_dup(heff_rfield(v_sh_247, 1));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2410, 0ULL, 2);
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_own_241);
    heff_drop(v_xs_243);
    heff_drop(v_b_244);
    heff_drop(v_marks_246);
    heff_drop_rec(v_sh_247, 3);
    heff_drop(v_t_2415);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_242}), v_argv_245));
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2416, v_s_248});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_2415);
    V v_g_2417 = heff_dup(v_g_242);
    V v_marks_2418 = heff_dup(v_marks_246);
    V v_vars_2419 = heff_dup(heff_rfield(v_sh_247, 1));
    V v_argv_2420 = heff_dup(heff_rfield(v_sh_247, 0));
    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_marks_2418));
    V v_t_2422 = (g_list_2etake(v_t_2421, v_argv_2420));
    V v_x2_2426 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam0, 2, 1, (V[]){v_vars_2419}), v_marks_2418, v_t_2422));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str2); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_strAppend(heff_strAppend(v_g_2417, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str3)), v_t_2429);
    V v_k_2431 = heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str4));
    V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str5), v_g_242, MK_INT(0LL), 5);
    V v_t_2433;
    if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
      heff_drop(v_j_2432);
      v_t_2433 = heff_dup(v_g_242);
    } else {
      v_t_2433 = heff_strSlice_lent(v_g_242, MK_INT(0LL), v_j_2432, 6);
    }
    V v_t_2434 = ({ V a_0 = v_k_2431; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_k_2431); r_; });
    V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str6)), v_t_2434);
    V v_ds_2436 = heff_get_n(heff_dup(heff_rfield(v_s_248, 7)), 3, 7);
    V v_g_2437 = heff_dup(v_g_242);
    V v_f_2445 = heff_clo_n(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam1, 2, 1, (V[]){v_ds_2436});
    V v_t_2446 = (g_list_2efoldl_24f1287822497x2111322144(NTAG(TAG_Nil), heff_dup(v_marks_246), heff_dup(heff_rfield(v_sh_247, 0))));
    V v_t_2447 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2446; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_t_2448 = heff_tr(heff_call(heff_dup(v_f_2445), 2, (V[]){MK_INT(0LL), v_g_2437}));
    V v_t_2449 = ({ V a_0 = v_f_2445; V a_1 = v_t_2448; V a_2 = v_t_2447; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2447); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(v_own_241, v_g_242, v_xs_243, v_b_244, v_argv_245, v_marks_246, v_sh_247, v_t_2435, heff_intAdd(MK_INT(1LL), v_t_2449), v_s_248));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam0(V self, V *args) {
  V v_m_2423 = args[0];
  V v_a_2424 = args[1];
  V v_vars_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_m_2423) == NTAG(TAG_True))) {
    heff_drop(v_m_2423);
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_2419));
    return ({ V a_0 = v_t_2425; V a_1 = v_a_2424; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_a_2424); r_; });
  } else {
    heff_drop(v_m_2423);
    heff_drop(v_a_2424);
    heff_drop(v_vars_2419);
    return ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_str0);
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_24tok2_lam1(V self, V *args) {
  V v_d_2438 = args[0];
  V v_n_2439 = args[1];
  V v_ds_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2440 = ({ V a_0 = v_ds_2436; V a_1 = v_n_2439; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ds_2436); heff_drop(v_n_2439); r_; });
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    V v_b_2444;
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      V v_x_2443 = v_field_2442;
      v_b_2444 = v_x_2443;
    } else {
      heff_drop(v_field_2442);
      v_b_2444 = MK_INT(0LL);
    }
    if (heff_intLe_c_lent(v_b_2444, v_d_2438, 0)) {
      heff_drop(v_b_2444);
      return v_d_2438;
    } else {
      heff_drop(v_d_2438);
      return v_b_2444;
    }
  }
}