// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_e 319
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_match 305026527
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_vars 10107635
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2ehandedField(V, V);
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedField_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emadeOne_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
HeffT2 g_heff_2ecompile_2esimplify_2epushArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etieDeps(V, V, V);
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieDeps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eunOp_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebind_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebind(V v_m_240, V v_f_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_s_242}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    return heff_tail(v_f_241, 2, (V[]){v_x_244, v_s_245});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2esimplify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_240, v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str11, 5, "False");

HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str0), 2)) {
    V v_f_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str1), 2)) {
      V v_f_246 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str2), 2)) {
        V v_f_248 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str3), 2)) {
          V v_t_2411;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str4);
          } else {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str5);
          }
          V v_f_2412 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str6), 2)) {
            V v_t_2415;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str7);
            } else {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str8);
            }
            V v_f_2416 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2415, NTAG(TAG_Nil), NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str9), 2)) {
              V v_t_2419;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str10);
              } else {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str11);
              }
              V v_f_2420 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_24cpr_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_24cpr_str1, 9, "strLength");

HeffT2 g_heff_2ecompile_2esimplify_2eunOp_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_24cpr_str0), 2)) {
      V v_f_2429 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2427)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2429}});
    } else {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    V v_a_2431 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_24cpr_str1), 2)) {
      V v_f_2433 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2431)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
    } else {
      heff_drop(v_a_2431);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_249, v_argv_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_argv_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EPrim: {
      V v_p_2425 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2426 = (g_heff_2ecompile_2eprims_2eprimArityGo(v_p_2425, heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get())));
      return (g_heff_2ecompile_2esimplify_2eprimAppN(v_p_2425, v_argv_241, v_t_2426));
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_argv_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2elam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2epartialApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialApp(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_g_249; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_argv_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2efewerThan(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialApp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_s_240, 2, 9); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_EVar: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        V v_xs_2410 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 2);
        V v_x_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        return heff_intLt(v_n_242, v_x_2412);
      }
      case TAG_EApp: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_it1_247, 0ULL, 3);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_it1_247, 0ULL, 4);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_it1_247, 0ULL, 3);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_247, 0ULL, 1);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_it1_247, 0ULL, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_n_242);
      heff_drop(v_field_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etakesMore(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletFloat(V v_r_240, V v_x_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EGlobal: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELam: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EApp: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_242, 0);
    V v_a1_2411 = heff_field(v_a_242, 1);
    V v_a2_2412 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2412, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam0, 1, 3, (V[]){v_m_2413, v_y_2410, v_a1_2411});
  }
  case TAG_ERecord: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EProj: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ETag: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EMatch: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrim: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrimCall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ECall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EInt: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EStr: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EBytes: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFixed: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat32: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EAbandon: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFix: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a1_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a1_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V v_loop_240, V v_all_241, V v_back_242, V v_argv_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_back_242);
    heff_drop(v_argv_243);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_247 = heff_field(v_x5_244, 0);
    V v_rest_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2416;
    if ((heff_dup(v_st_247) == NTAG(TAG_True))) {
      heff_drop(v_st_247);
      HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), heff_dup(v_argv_243)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          V v_t_2414 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_2413)));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_x_2413);
            heff_drop(v_t_2414);
            v_t_2416 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2414);
            if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
              V v_t_2415 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_2413)));
              if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                heff_drop(v_x_2413);
                heff_drop(v_t_2415);
                v_t_2416 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2415);
                v_t_2416 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2413}));
              }
            } else {
              v_t_2416 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2413}));
            }
          }
        } else {
          heff_drop(v_field_2411);
          v_t_2416 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_247);
      v_t_2416 = NTAG(TAG_False);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_loop_240;
    V t_1 = v_all_241;
    V t_2 = v_back_242;
    V t_3 = v_argv_243;
    V t_4 = v_rest_248;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2417;
    v_loop_240 = t_0;
    v_all_241 = t_1;
    v_back_242 = t_2;
    v_argv_243 = t_3;
    v_x5_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo_24dps(a0, a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V v_x1_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_x2_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_246, v_p_242}});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_x2_241, 0);
      V v_argv_248 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      HeffT2 v_t_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_s_2413 = v_field_2411;
        V v_m_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_argv_248}));
        V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2413}));
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x2_2415, 0);
          V v_s_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2412, 0)), heff_dup(heff_rfield(v_x_2416, 0))});
          V v_t_2419 = (g_heff_2ecompile_2esimplify_2eappendL(heff_take_field(v_x_2412, 1), heff_take_field(v_x_2416, 1)));
          V v_t_2420 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_x_2412, 2, 4), heff_get_n(v_x_2416, 2, 3)));
          V v_x_2421 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_t_2418, v_t_2419, v_t_2420});
          return ((HeffT2){{v_x_2421, v_s_2417}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2415)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2earityIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earityIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2earityIn(V v_all_240, V v_g_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_all_240, v_g_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_EVar: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_ELam: {
        V v_xs_249 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 2);
        return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_249; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      }
      case TAG_EApp: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ELet: {
        heff_take_n(v_it1_246, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EProj: {
        heff_take_n(v_it1_246, 0ULL, 4);
        return MK_INT(0LL);
      }
      case TAG_ETag: {
        heff_take_n(v_it1_246, 0ULL, 3);
        return MK_INT(0LL);
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_ECall: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EStr: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_246, 0ULL, 1);
        return MK_INT(0LL);
      }
      case TAG_EAbandon: {
        return MK_INT(0LL);
      }
      case TAG_EFix: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return MK_INT(0LL);
      }
      default: return heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2earityIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2estripLams_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_e_241, 0);
    V v_b_246 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_argv_247 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_245), v_argv_247));
    V v_m_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245));
    V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2415;
    if (heff_intLt_c(v_y_2411, v_x_2410)) {
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2413, v_ys_245));
      v_e_2415 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2414, v_b_246});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_245);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2415 = v_b_246;
    }
    V v_t_2416 = (g_std_2emap_2esize(v_m_249));
    if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
      heff_drop(v_m_249);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_2415);
    } else {
      V v_t_2418 = ({ V a_0 = v_m_249; V a_1 = v_e_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_249); r_; });
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2418);
    }
  }
  case TAG_EApp: {
    V v_e1_2419 = heff_dup(heff_field(v_e_241, 0));
    V v_argv_2420 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_2419)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EGlobal: {
      V v_g_2422 = heff_field(v_e1_2419, 0);
      V v_ru_24e1_2419_24EGlobal = heff_take_reuse_n(v_e1_2419, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2423 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2eappendL(v_argv_2420, v_t_2423));
      V v_t_2425 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2419_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2422}), v_t_2424});
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2425);
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2419, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2419, 0ULL, 4);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2419, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_argv_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    default: return heff_nomatch(v_e1_2419);
    }
  }
  case TAG_ELet: {
    V v_x_2458 = heff_field(v_e_241, 0);
    V v_a_2459 = heff_field(v_e_241, 1);
    V v_b_2460 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2461 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2458, v_a_2459, heff_hole()});
    V v_u_2462 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2461));
    heff_drop(v_u_2462);
    V t_0 = v_zs_240;
    V t_1 = v_b_2460;
    V t_2 = v_cell_2461;
    v_zs_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2472 = heff_field(v_e_241, 0);
    V v_arms_2473 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2474 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2480 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0, 1, 1, (V[]){v_go_2474}), v_arms_2473));
    return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2472, v_t_2480}));
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args) {
  V v_x2_2475 = args[0];
  V v_go_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkArm: {
    V v_t_2476 = heff_field(v_x2_2475, 0);
    V v_vs_2477 = heff_field(v_x2_2475, 1);
    V v_b_2478 = heff_field(v_x2_2475, 2);
    V v_ru_24x2_2475_24MkArm = heff_take_reuse_n(v_x2_2475, 7ULL, 3);
    V v_t_2479 = heff_tr(heff_call(v_go_2474, 1, (V[]){v_b_2478}));
    return heff_tag_at_n(v_ru_24x2_2475_24MkArm, TAG_MkArm, 3, (V[]){v_t_2476, v_vs_2477, v_t_2479});
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
Clo g_heff_2ecompile_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c_lent(MK_INT(16LL), v_d_248, 1)) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_z_249});
  } else {
    V v_x2_2412 = heff_tr(g_heff_2ecompile_2esimplify_2eask(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 2ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_argv_244));
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_246, 2, 3), v_t_2415));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 3, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2416, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaWanted_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaWanted(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_243 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_243);
  }
  case TAG_EGlobal: {
    V v_x_245 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_245);
  }
  case TAG_ELam: {
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_248);
  }
  case TAG_EApp: {
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2411);
  }
  case TAG_ELet: {
    V v_e_2414 = heff_field(v_x2_241, 2);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_2414)));
    V v_t_2420;
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      V v_y_2419 = v_field_2417;
      v_t_2420 = v_y_2419;
    }
    V v_t_2421 = (g_heff_2ecompile_2esimplify_2ecapturing(v_t_2420));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_s_240);
      heff_drop(v_t_2421);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2421);
      HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_2414)));
      V v_t_2427;
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        heff_drop(v_x_2425);
        V v_y_2426 = v_field_2424;
        v_t_2427 = v_y_2426;
      }
      V v_x_2428 = ({ V a_0 = v_s_240; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2esimplify_2emissingOf(a_0, a_1)); heff_drop(v_t_2427); r_; });
      return heff_intLt(MK_INT(0LL), v_x_2428);
    }
  }
  case TAG_ERecord: {
    V v_x_2431 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2431);
  }
  case TAG_EProj: {
    V v_x_2436 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2436);
  }
  case TAG_ETag: {
    V v_x_2440 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2440);
  }
  case TAG_EMatch: {
    V v_x_2443 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2443);
  }
  case TAG_EPrim: {
    V v_x_2445 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2445);
  }
  case TAG_EPrimCall: {
    V v_x_2448 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2448);
  }
  case TAG_ECall: {
    V v_x_2451 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2451);
  }
  case TAG_EInt: {
    V v_x_2453 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2453);
  }
  case TAG_EFloat: {
    V v_x_2455 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2455);
  }
  case TAG_EStr: {
    V v_x_2457 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2457);
  }
  case TAG_EBytes: {
    V v_x_2459 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2459);
  }
  case TAG_EFixed: {
    V v_x_2462 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2462);
  }
  case TAG_EFloat32: {
    V v_x_2464 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2464);
  }
  case TAG_EAbandon: {
    V v_x_2465 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2465);
  }
  case TAG_EFix: {
    V v_x_2468 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    return heff_intLt(MK_INT(0LL), v_x_2468);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaWanted(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLoop_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2eetaLoop(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_x6_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V a_0 = v_g_241; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2espec_2eusesOf(v_g_241, v_b_243));
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_242; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eetaArgs(v_r_240, v_t_2411, v_argv_244));
      return heff_tail(v_t_2412, 1, (V[]){v_z_246});
    } else {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_t_249);
      V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_244});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_z_246});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_244});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2esimplify_2eetaLoop(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_argv_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_argv_243));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(v_s_240, v_argv_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_242);
      heff_drop(v_argv_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eapplyArm_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eapplyArm_lam10(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyArm(V v_r_240, V v_b_241, V v_argv_242) {
top: ;
  V v_m_2447 = (g_prelude_2etraverse_24s2064368144x1684679122(((V)&g_heff_2ecompile_2esimplify_2eapplyArm_lam0_clo), v_argv_242));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam10, 1, 3, (V[]){v_m_2447, v_r_240, v_b_241});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyArm(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2433});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2435});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2437});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam8(V self, V *args) {
  V v_s_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam9(V self, V *args) {
  V v_s_2444 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2444});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam0(V self, V *args) {
  V v_a_243 = args[0];
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam2, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EApp: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ELet: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ERecord: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EProj: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ETag: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EMatch: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam3, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ECall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EFix: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam10(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_s_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_s_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_b_241;
    heff_room[1] = v_x_2450;
    heff_room[2] = v_s_2451;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2ehandedField_lam39(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ehandedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandedField(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam0, 1, 1, (V[]){v_a_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam1, 1, 1, (V[]){v_a_241});
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam2, 1, 1, (V[]){v_a_241});
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam3, 1, 1, (V[]){v_a_241});
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam4, 1, 1, (V[]){v_a_241});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam5, 1, 1, (V[]){v_a_241});
  }
  case TAG_EProj: {
    V v_a1_2419 = heff_dup(heff_field(v_a_241, 0));
    V v_l_2420 = heff_dup(heff_field(v_a_241, 1));
    V v_sh_2421 = heff_dup(heff_field(v_a_241, 2));
    V v_t_2422 = heff_dup(heff_field(v_a_241, 3));
    switch (heff_tag_of(v_a1_2419)) {
    case TAG_EVar: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam6, 1, 1, (V[]){v_a_241});
    }
    case TAG_EGlobal: {
      V v_g_2425 = heff_field(v_a1_2419, 0);
      heff_take_n(v_a1_2419, 1ULL, 1);
      heff_drop_tag(v_a_241, 4);
      HeffT2 v_t_2426 = ({ V b_0 = heff_get_n(v_s_240, 2, 9); V a_1 = v_g_2425; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_x_2430 = v_field_2428;
          heff_drop(v_x_2430);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam7, 1, 4, (V[]){v_g_2425, v_l_2420, v_sh_2421, v_t_2422});
        } else {
          heff_drop(v_field_2428);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam8, 1, 4, (V[]){v_g_2425, v_l_2420, v_sh_2421, v_t_2422});
        }
      }
    }
    case TAG_ELam: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam9, 1, 1, (V[]){v_a_241});
    }
    case TAG_EApp: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam10, 1, 1, (V[]){v_a_241});
    }
    case TAG_ELet: {
      heff_take_n(v_a1_2419, 0ULL, 3);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam11, 1, 1, (V[]){v_a_241});
    }
    case TAG_ERecord: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam12, 1, 1, (V[]){v_a_241});
    }
    case TAG_EProj: {
      heff_take_n(v_a1_2419, 0ULL, 4);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam13, 1, 1, (V[]){v_a_241});
    }
    case TAG_ETag: {
      heff_take_n(v_a1_2419, 0ULL, 3);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam14, 1, 1, (V[]){v_a_241});
    }
    case TAG_EMatch: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam15, 1, 1, (V[]){v_a_241});
    }
    case TAG_EPrim: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam16, 1, 1, (V[]){v_a_241});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam17, 1, 1, (V[]){v_a_241});
    }
    case TAG_ECall: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam18, 1, 1, (V[]){v_a_241});
    }
    case TAG_EInt: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam19, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat: {
      heff_take_na(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam20, 1, 1, (V[]){v_a_241});
    }
    case TAG_EStr: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam21, 1, 1, (V[]){v_a_241});
    }
    case TAG_EBytes: {
      heff_take_n(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam22, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFixed: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam23, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat32: {
      heff_take_na(v_a1_2419, 0ULL, 1);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam24, 1, 1, (V[]){v_a_241});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam25, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFix: {
      heff_take_n(v_a1_2419, 0ULL, 2);
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_l_2420);
      heff_drop(v_sh_2421);
      heff_drop(v_t_2422);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam26, 1, 1, (V[]){v_a_241});
    }
    default: return heff_nomatch(v_a1_2419);
    }
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam27, 1, 1, (V[]){v_a_241});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam28, 1, 1, (V[]){v_a_241});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam29, 1, 1, (V[]){v_a_241});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam30, 1, 1, (V[]){v_a_241});
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam31, 1, 1, (V[]){v_a_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam32, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam33, 1, 1, (V[]){v_a_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam34, 1, 1, (V[]){v_a_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam35, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam36, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam37, 1, 1, (V[]){v_a_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam38, 1, 1, (V[]){v_a_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ehandedField_lam39, 1, 1, (V[]){v_a_241});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ehandedField(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_248});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2411});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2415});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam5(V self, V *args) {
  V v_s_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2418});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam6(V self, V *args) {
  V v_s_2424 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2424});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam7(V self, V *args) {
  V v_s_2431 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_l_2420 = heff_env(self)[1];
  V v_sh_2421 = heff_env(self)[2];
  V v_t_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2420, v_sh_2421, v_t_2422});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam8(V self, V *args) {
  V v_s_2433 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_l_2420 = heff_env(self)[1];
  V v_sh_2421 = heff_env(self)[2];
  V v_t_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2434 = (g_heff_2ecompile_2esimplify_2eknownField_24cpr(v_g_2425, v_l_2420, v_s_2433));
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_x_2437 = v_field_2435;
    V v_s_2438 = v_field_2436;
    V v_x_2441;
    switch (heff_tag_of(v_x_2437)) {
    case TAG_Nothing: {
      v_x_2441 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2420, v_sh_2421, v_t_2422});
      break;
    }
    case TAG_Just: {
      V v_v_2439 = heff_field(v_x_2437, 0);
      V v_ru_24x_2437_24Just = heff_take_reuse_n(v_x_2437, 1ULL, 1);
      V v_t_2440 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_v_2439)));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_g_2425);
        heff_drop(v_l_2420);
        heff_drop(v_sh_2421);
        heff_drop(v_t_2422);
        heff_drop_cell(v_ru_24x_2437_24Just, 1);
        heff_drop(v_t_2440);
        v_x_2441 = v_v_2439;
      } else {
        heff_drop(v_v_2439);
        heff_drop(v_t_2440);
        v_x_2441 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24x_2437_24Just, TAG_EGlobal, 1, (V[]){v_g_2425}), v_l_2420, v_sh_2421, v_t_2422});
      }
      break;
    }
    default: heff_nomatch(v_x_2437);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_s_2438});
  }
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam9(V self, V *args) {
  V v_s_2444 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2444});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam10(V self, V *args) {
  V v_s_2447 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam11(V self, V *args) {
  V v_s_2451 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2451});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam12(V self, V *args) {
  V v_s_2454 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam13(V self, V *args) {
  V v_s_2459 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2459});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam14(V self, V *args) {
  V v_s_2463 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2463});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam15(V self, V *args) {
  V v_s_2466 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2466});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam16(V self, V *args) {
  V v_s_2468 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2468});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam17(V self, V *args) {
  V v_s_2471 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2471});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam18(V self, V *args) {
  V v_s_2474 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2474});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam19(V self, V *args) {
  V v_s_2476 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2476});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam20(V self, V *args) {
  V v_s_2478 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2478});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam21(V self, V *args) {
  V v_s_2480 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2480});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam22(V self, V *args) {
  V v_s_2482 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2482});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam23(V self, V *args) {
  V v_s_2485 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2485});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam24(V self, V *args) {
  V v_s_2487 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2487});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam25(V self, V *args) {
  V v_s_2488 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2488});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam26(V self, V *args) {
  V v_s_2491 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2491});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam27(V self, V *args) {
  V v_s_2495 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2495});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam28(V self, V *args) {
  V v_s_2498 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_2498});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam29(V self, V *args) {
  V v_s_24100 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24100});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam30(V self, V *args) {
  V v_s_24103 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24103});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam31(V self, V *args) {
  V v_s_24106 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24106});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam32(V self, V *args) {
  V v_s_24108 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24108});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam33(V self, V *args) {
  V v_s_24110 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24110});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam34(V self, V *args) {
  V v_s_24112 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24112});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam35(V self, V *args) {
  V v_s_24114 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam36(V self, V *args) {
  V v_s_24117 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24117});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam37(V self, V *args) {
  V v_s_24119 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24119});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam38(V self, V *args) {
  V v_s_24120 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24120});
}
V g_heff_2ecompile_2esimplify_2ehandedField_lam39(V self, V *args) {
  V v_s_24123 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_245, v_l_240, 1)) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, heff_dup(v_l_240), v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eothersPure(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = ({ V a_0 = heff_dup(v_s_248); V a_1 = v_f_246; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_f_246); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2410 = ({ V a_0 = v_l_240; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2esimplify_2eothersPure(a_0, a_1)); heff_drop(v_l_240); r_; });
    V f_ = v_t_2410;
    args[0] = v_s_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_l_240);
    heff_drop(v_rest_244);
    heff_drop(v_t_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_248});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2epushArm_24cpr(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_t_247, v_p_243));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2447;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_EVar: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2411, 0ULL, 4);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2432 = heff_field(v_x_2411, 1);
        heff_take_n(v_x_2411, 2ULL, 2);
        v_t_2447 = v_arms_2432;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_2411, 0ULL, 1);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2447}));
      V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_MkPair: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_s_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2450}), v_s_2451}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2449)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = v_key_240; V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_247 = v_s_242;
  } else {
    heff_drop(v_t_245);
    V v_d_246 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 2), heff_dup(v_key_240), heff_dup(v_b_241)));
    v_t_247 = ({ V rv_2 = v_d_246; V rr_ = heff_rec_reuse_nf(v_s_242, 507ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  V v_f_248 = (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247));
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_248}});
}
Clo g_heff_2ecompile_2esimplify_2egrew_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrew_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2egrew(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_a_242, v_b_244, 0)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_argv_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2egrew(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2emadeOne_24cpr(heff_dup(v_h_241), v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    heff_drop(v_x_247);
    V v_s_248 = v_field_246;
    HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(heff_dup(v_s_248), v_h_241));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_x2_2417;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_kc_2413 = v_field_2411;
        V v_t_2414 = heff_get_n(v_kc_2413, 4, 5);
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Nothing: {
          v_x2_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_248});
          break;
        }
        case TAG_Just: {
          V v_km_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_km_2415, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
          v_x2_2417 = (g_heff_2ecompile_2esimplify_2emadeKept(v_km_2415, v_t_2416, v_s_248));
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_field_2411);
        v_x2_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_248});
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_s_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam0, 1, 3, (V[]){heff_dup(v_x_2418), heff_dup(v_h_241), v_b0_242}), heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam1, 2, 3, (V[]){v_x_2418, v_more_240, v_h_241}), v_s_2419));
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args) {
  V v_p_2420 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_b0_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2esimplify_2emakeFresh(v_h_241, v_b0_242, v_p_2420));
  }
  case TAG_Just: {
    V v_b_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_h_241);
    heff_drop(v_b0_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2421, v_p_2420});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam2(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_b3_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b3_2422, v_x_2430}), v_s_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam1(V self, V *args) {
  V v_b3_2422 = args[0];
  V v_z_2423 = args[1];
  V v_x_2418 = heff_env(self)[0];
  V v_more_240 = heff_env(self)[1];
  V v_h_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2432;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_m_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, MK_INT(5LL), heff_dup(v_h_241), v_b3_2422}));
    break;
  }
  case TAG_Just: {
    V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b3_2422)));
    V v_t_2426 = (g_heff_2ecompile_2eir_2enubI(v_t_2425));
    V v_m_2427 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2426}));
    v_m_2432 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam2, 1, 2, (V[]){v_m_2427, v_b3_2422});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_z_2423}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_dup(heff_field(v_x_2434, 0));
      v_t_2438 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x_2434);
    }
    HeffT2 v_t_2439 = ({ V a_0 = v_x_2418; V a_1 = heff_dup(v_h_241); V a_2 = v_t_2438; V a_3 = v_s_2435; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2erefsMade_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2418); r_; });
    {
      V v_field_2440 = v_t_2439.f[0];
      V v_field_2441 = v_t_2439.f[1];
      V v_x_2442 = v_field_2440;
      heff_drop(v_x_2442);
      V v_s_2443 = v_field_2441;
      V v_t_2446;
      switch (heff_tag_of(v_x_2434)) {
      case TAG_MkPair: {
        V v_x_2444 = heff_dup(heff_field(v_x_2434, 0));
        v_t_2446 = v_x_2444;
        break;
      }
      default: heff_nomatch(v_x_2434);
      }
      HeffT2 v_t_2447 = (g_heff_2ecompile_2esimplify_2eknownMade_24cpr(heff_dup(v_h_241), v_t_2446, v_s_2443));
      {
        V v_field_2448 = v_t_2447.f[0];
        V v_field_2449 = v_t_2447.f[1];
        V v_x_2450 = v_field_2448;
        heff_drop(v_x_2450);
        V v_s_2451 = v_field_2449;
        V v_t_2454;
        switch (heff_tag_of(v_x_2434)) {
        case TAG_MkPair: {
          V v_x_2452 = heff_dup(heff_field(v_x_2434, 0));
          v_t_2454 = v_x_2452;
          break;
        }
        default: heff_nomatch(v_x_2434);
        }
        V v_t_2457;
        switch (heff_tag_of(v_x_2434)) {
        case TAG_MkPair: {
          V v_y_2456 = heff_dup(heff_field(v_x_2434, 1));
          v_t_2457 = v_y_2456;
          break;
        }
        default: heff_nomatch(v_x_2434);
        }
        V v_m_2458 = (g_heff_2ecompile_2esimplify_2etieDeps(heff_dup(v_h_241), v_t_2454, v_t_2457));
        V v_x2_2459 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2451}));
        switch (heff_tag_of(v_x2_2459)) {
        case TAG_MkPair: {
          V v_x_2460 = heff_field(v_x2_2459, 0);
          V v_s_2461 = heff_field(v_x2_2459, 1);
          V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
          V v_t_2464;
          switch (heff_tag_of(v_x_2434)) {
          case TAG_MkPair: {
            V v_x_2462 = heff_field(v_x_2434, 0);
            heff_take_n(v_x_2434, 1ULL, 2);
            v_t_2464 = v_x_2462;
            break;
          }
          default: heff_nomatch(v_x_2434);
          }
          V v_t_2465 = heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_t_2464}), NTAG(TAG_Nil)});
          V v_x_2466 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2460, v_t_2465));
          return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2466, v_s_2461});
        }
        default: return heff_nomatch(v_x2_2459);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_244 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get()), heff_dup(heff_rfield(v_sg_242, 0)), heff_dup(heff_rfield(v_sg_242, 0)), heff_get_n(v_sg_242, 1, 2), heff_dup(g_std_2emap_2eempty_get()), v_t_243, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get())});
  HeffT2 v_t_245 = (g_prelude_2etraverse_24s1252393826x821382319_24cpr(v_defs_241, v_t_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_out_248 = v_field_246;
    V v_st_249 = v_field_247;
    V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_248)));
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_248)));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(v_out_248));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = ({ V a_0 = heff_dup(v_st_249); V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2411, heff_get_n(v_st_249, 0, 9), v_t_2413, v_t_2416});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}