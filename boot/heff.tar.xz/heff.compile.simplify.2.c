// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOne(V, V);
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOne_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebind_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebind(V v_m_240, V v_f_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_s_242}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    return heff_tail(v_f_241, 2, (V[]){v_x_244, v_s_245});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2esimplify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_e_27_243 = heff_field(v_x2_242, 0);
    V v_n_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24MkPair = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V rv_0 = v_n_244; V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24x2_242_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_243, v_t_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_249, v_as_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_as_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EPrim: {
      V v_p_2425 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2426 = ({ V a_0 = heff_dup(v_p_2425); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
      return (g_heff_2ecompile_2esimplify_2eprimAppN(v_p_2425, v_as_241, v_t_2426));
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2elam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2epartialApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialApp(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_as_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2efewerThan(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialApp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_g_241; V b_1 = heff_get_n(v_s_240, 2, 9); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 2);
      V v_x_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      return heff_intLt(v_n_242, v_x_249);
    }
    case TAG_EApp: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_244, 0ULL, 4);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakesMore(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletFloat(V v_r_240, V v_x_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EGlobal: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELam: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EApp: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_242, 0);
    V v_a1_2411 = heff_field(v_a_242, 1);
    V v_a2_2412 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2412, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam0, 1, 3, (V[]){v_m_2413, v_y_2410, v_a1_2411});
  }
  case TAG_ERecord: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EProj: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ETag: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EMatch: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrim: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrimCall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ECall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EInt: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EStr: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EBytes: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFixed: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat32: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EAbandon: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFix: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a1_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a1_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V v_loop_240, V v_all_241, V v_as_242, V v_x4_243, V v_i_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2411;
    if ((heff_dup(v_st_246) == NTAG(TAG_True))) {
      heff_drop(v_st_246);
      V v_x3_248 = (g_heff_2ecompile_2esimplify_2enthE(heff_dup(v_i_244), v_as_242));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        V v_t_2410 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_249)));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_x_249);
          heff_drop(v_t_2410);
          v_t_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2410);
          if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
            v_t_2411 = (g_heff_2ecompile_2esimplify_2ecapturing(v_x_249));
          } else {
            heff_drop(v_x_249);
            v_t_2411 = NTAG(TAG_False);
          }
        }
        break;
      }
      default: heff_nomatch(v_x3_248);
      }
    } else {
      heff_drop(v_st_246);
      v_t_2411 = NTAG(TAG_False);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_loop_240;
    V t_1 = v_all_241;
    V t_2 = v_as_242;
    V t_3 = v_rest_247;
    V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
    V t_5 = v_cell_2412;
    v_loop_240 = t_0;
    v_all_241 = t_1;
    v_as_242 = t_2;
    v_x4_243 = t_3;
    v_i_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2emarkGo_24dps(a0, a1, a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2earityIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earityIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2earityIn(V v_all_240, V v_g_241) {
top: ;
  V v_it_242 = (g_map_2elookup_24s1546226666x2146984184(v_g_241, v_all_240));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_it1_243 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 1);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_EVar: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 2);
      return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    }
    case TAG_EApp: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_243, 0ULL, 4);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_take_na(v_it1_243, 0ULL, 1);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_243, 0ULL, 2);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2earityIn(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2estripLams_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_e_241, 0);
    V v_b_246 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_247 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_245), v_as_247));
    V v_m_249 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245));
    V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2415;
    if (heff_intLt_c(v_y_2411, v_x_2410)) {
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2413, v_ys_245));
      v_e_2415 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2414, v_b_246});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_245);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2415 = v_b_246;
    }
    V v_t_2416 = (g_map_2esize(v_m_249));
    if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
      heff_drop(v_m_249);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_2415);
    } else {
      V v_t_2418 = ({ V a_0 = v_m_249; V a_1 = v_e_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_249); r_; });
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2418);
    }
  }
  case TAG_EApp: {
    V v_e1_2419 = heff_dup(heff_field(v_e_241, 0));
    V v_as_2420 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_2419)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EGlobal: {
      V v_g_2422 = heff_field(v_e1_2419, 0);
      V v_ru_24e1_2419_24EGlobal = heff_take_reuse_n(v_e1_2419, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2423 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2eappendL(v_as_2420, v_t_2423));
      V v_t_2425 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2419_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2422}), v_t_2424});
      return heff_setField(v_d_242, MK_INT(2LL), v_t_2425);
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2419, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2419, 0ULL, 4);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2419, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2419, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2419, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2420);
      return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
    }
    default: return heff_nomatch(v_e1_2419);
    }
  }
  case TAG_ELet: {
    V v_x_2458 = heff_field(v_e_241, 0);
    V v_a_2459 = heff_field(v_e_241, 1);
    V v_b_2460 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2461 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2458, v_a_2459, heff_hole()});
    V v_u_2462 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2461));
    heff_drop(v_u_2462);
    V t_0 = v_zs_240;
    V t_1 = v_b_2460;
    V t_2 = v_cell_2461;
    v_zs_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2472 = heff_field(v_e_241, 0);
    V v_arms_2473 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2474 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2480 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0, 1, 1, (V[]){v_go_2474}), v_arms_2473));
    return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2472, v_t_2480}));
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2estripLams_24dps_lam0(V self, V *args) {
  V v_x2_2475 = args[0];
  V v_go_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkArm: {
    V v_t_2476 = heff_field(v_x2_2475, 0);
    V v_vs_2477 = heff_field(v_x2_2475, 1);
    V v_b_2478 = heff_field(v_x2_2475, 2);
    V v_ru_24x2_2475_24MkArm = heff_take_reuse_n(v_x2_2475, 7ULL, 3);
    V v_t_2479 = heff_tr(heff_call(v_go_2474, 1, (V[]){v_b_2478}));
    return heff_tag_at_n(v_ru_24x2_2475_24MkArm, TAG_MkArm, 3, (V[]){v_t_2476, v_vs_2477, v_t_2479});
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
Clo g_heff_2ecompile_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c(MK_INT(16LL), heff_dup(v_d_248))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_z_249});
  } else {
    V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eask(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 2ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_as_244));
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_246, 2, 3), v_t_2415));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 3, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2416, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaWanted_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaWanted(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    V v_x_243 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_243);
  }
  case TAG_EGlobal: {
    V v_x_245 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_245);
  }
  case TAG_ELam: {
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_248);
  }
  case TAG_EApp: {
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2411);
  }
  case TAG_ELet: {
    V v_e_2414 = heff_field(v_a_241, 2);
    V v_x1_2415 = (g_heff_2ecompile_2esimplify_2eletsOut(heff_dup(v_e_2414)));
    V v_t_2418;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_y_2417 = heff_field(v_x1_2415, 1);
      heff_take_n(v_x1_2415, 2ULL, 2);
      v_t_2418 = v_y_2417;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    V v_t_2419 = (g_heff_2ecompile_2esimplify_2ecapturing(v_t_2418));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_s_240);
      heff_drop(v_t_2419);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2419);
      V v_x1_2420 = (g_heff_2ecompile_2esimplify_2eletsOut(heff_dup(v_e_2414)));
      V v_t_2423;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_MkPair: {
        V v_y_2422 = heff_field(v_x1_2420, 1);
        heff_take_n(v_x1_2420, 2ULL, 2);
        v_t_2423 = v_y_2422;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_x_2424 = ({ V a_0 = v_s_240; V a_1 = v_t_2423; V r_ = (g_heff_2ecompile_2esimplify_2emissingOf(a_0, a_1)); heff_drop(v_t_2423); r_; });
      return heff_intLt(MK_INT(0LL), v_x_2424);
    }
  }
  case TAG_ERecord: {
    V v_x_2427 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2427);
  }
  case TAG_EProj: {
    V v_x_2432 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2432);
  }
  case TAG_ETag: {
    V v_x_2436 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2436);
  }
  case TAG_EMatch: {
    V v_x_2439 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2439);
  }
  case TAG_EPrim: {
    V v_x_2441 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2441);
  }
  case TAG_EPrimCall: {
    V v_x_2444 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2444);
  }
  case TAG_ECall: {
    V v_x_2447 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2447);
  }
  case TAG_EInt: {
    V v_x_2449 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2449);
  }
  case TAG_EFloat: {
    V v_x_2451 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2451);
  }
  case TAG_EStr: {
    V v_x_2453 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2453);
  }
  case TAG_EBytes: {
    V v_x_2455 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2455);
  }
  case TAG_EFixed: {
    V v_x_2458 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2458);
  }
  case TAG_EFloat32: {
    V v_x_2460 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2460);
  }
  case TAG_EAbandon: {
    V v_x_2461 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2461);
  }
  case TAG_EFix: {
    V v_x_2464 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_a_241));
    return heff_intLt(MK_INT(0LL), v_x_2464);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaWanted(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLoop_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2eetaLoop(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_x6_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2espec_2eusesOf(v_g_241, v_b_243));
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_242; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eetaArgs(v_r_240, v_t_2411, v_as_244));
      return heff_tail(v_t_2412, 1, (V[]){v_z_246});
    } else {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_t_249);
      V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_as_244});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_z_246});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_as_244});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2esimplify_2eetaLoop(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_as_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_as_243));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(v_s_240, v_as_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_242);
      heff_drop(v_as_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_245, v_l_240, 1)) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, v_l_240, v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eothersPure(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = ({ V a_0 = v_f_246; V a_1 = v_s_248; V r_ = (g_heff_2ecompile_2esimplify_2eisPure(a_0, a_1)); heff_drop(v_f_246); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
      heff_drop(v_x_2410);
      heff_drop_cell(v_ru_24x2_249_24MkPair, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eothersPure(v_l_240, v_rest_244));
      V f_ = v_t_2412;
      args[0] = v_s_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_l_240);
      heff_drop(v_rest_244);
      heff_drop(v_x_2410);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2411});
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  V v_x2_244 = (g_heff_2ecompile_2esimplify_2emadeOne(heff_dup(v_h_241), v_s_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_x1_247 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_246), heff_dup(v_h_241)));
    V v_x2_2412;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nothing: {
      v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      break;
    }
    case TAG_Just: {
      V v_kc_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      V v_t_249 = heff_get_n(v_kc_248, 4, 5);
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
        break;
      }
      case TAG_Just: {
        V v_km_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_244_24MkPair, 2);
        V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_km_2410, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2412 = (g_heff_2ecompile_2esimplify_2emadeKept(v_km_2410, v_t_2411, v_s_246));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_x2_2416;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
        v_x2_2416 = (g_heff_2ecompile_2esimplify_2emakeFresh(heff_dup(v_h_241), v_b0_242, v_s_2414));
        break;
      }
      case TAG_Just: {
        V v_b_2415 = heff_field(v_x_2413, 0);
        heff_take_n(v_x_2413, 1ULL, 1);
        heff_drop(v_b0_242);
        v_x2_2416 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_b_2415, v_s_2414});
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
        V v_t_2419 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2417)));
        V v_t_2420 = (g_heff_2ecompile_2eir_2enubI(v_t_2419));
        V v_m_2421 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2420}));
        V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2418}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_s_2424 = heff_field(v_x2_2422, 1);
          V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
          V v_t_2425 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_x_2417}), NTAG(TAG_Nil)});
          V v_x_2426 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2423, v_t_2425));
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2424});
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eoneDef(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_244 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_242, 0)), heff_dup(heff_rfield(v_sg_242, 0)), heff_get_n(v_sg_242, 1, 2), heff_dup(g_map_2eempty_get()), v_t_243, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get())});
  V v_x1_245 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_defs_241, v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_out_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    V v_t_248 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_246)));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_246)));
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_out_246));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = ({ V a_0 = heff_dup(v_st_247); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_249, heff_get_n(v_st_247, 0, 9), v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}