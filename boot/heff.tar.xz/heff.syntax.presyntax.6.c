// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_DeclEquations 25755
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENest 28629
#define TAG_EReturn 59059
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IInvalid 29207
#define TAG_IsInferable 49402
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBits 43687
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_bind__pure__giveBack[] = {LBL_bind, LBL_pure, LBL_giveBack};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo;
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackLet(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo;
V g_heff_2esyntax_2epresyntax_2egivenTy(V, V, V);
V g_heff_2esyntax_2epresyntax_2egivenTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivenTy_clo;
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eany_24s750144226x405092487(V);
V g_list_2eany_24s750144226x405092487_entry(V self, V *a);
extern Clo g_list_2eany_24s750144226x405092487_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s958865698x1719976126(V, V, V);
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a);
extern Clo g_list_2efoldl_24s958865698x1719976126_clo;
V g_list_2ekeepIf_24s1674319799x1081446864(V);
V g_list_2ekeepIf_24s1674319799x1081446864_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_clo;
V g_list_2emap_24s1709068899x1960726563(V, V, V, V);
V g_list_2emap_24s1709068899x1960726563_entry(V self, V *a);
extern Clo g_list_2emap_24s1709068899x1960726563_clo;
V g_list_2emap_24s1732792088x1893487364(V, V, V);
V g_list_2emap_24s1732792088x1893487364_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s272223926x273382154(V);
V g_list_2emap_24s272223926x273382154_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ty_240)) {
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_242 = heff_field(v_x2_241, 0);
      V v_f_243 = heff_intMod(heff_dup(v_n_242), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    }
    case TAG_SizeName: {
      V v_unit_246 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_246), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_247 = heff_field(v_x2_241, 0);
      V v_f_248 = heff_intMod(heff_dup(v_n_247), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    }
    case TAG_SizeName: {
      V v_unit_2411 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2411), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_f_242 = heff_intMod(v_acc_241, MK_INT(8LL));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop(v_acc_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_n_245 = heff_field(v_x11_243, 0);
      V t_0 = v_x12_244;
      V t_1 = heff_intAdd(v_acc_241, heff_dup(v_n_245));
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str0, 6, "idBind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str1, 6, "idPure");

static V g_heff_2esyntax_2epresyntax_2eidNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eidNames_st;
static V g_heff_2esyntax_2epresyntax_2eidNames_init(void) {
  return heff_rec_n(3, shape_bind__pure__giveBack, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eidNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2eidNames_str1), NTAG(TAG_True)});
}
V g_heff_2esyntax_2epresyntax_2eidNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eidNames_st)) return g_heff_2esyntax_2epresyntax_2eidNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eidNames_val, &g_heff_2esyntax_2epresyntax_2eidNames_st, g_heff_2esyntax_2epresyntax_2eidNames_init);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V v_lit_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_f_245 = heff_dup(v_lit_240);
    V v_st_246 = v_st_241;
    V v_x3_247 = v_x_243;
    V v_x1_2422;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_At: {
      V v_x31_248 = heff_field(v_x3_247, 0);
      V v_sp_249 = heff_field(v_x3_247, 1);
      V v_ru_24x3_247_24At = heff_take_reuse_n(v_x3_247, 3ULL, 2);
      switch (heff_tag_of(v_x31_248)) {
      case TAG_SetField: {
        V v_x_2410 = heff_field(v_x31_248, 0);
        V v_xsp_2411 = heff_field(v_x31_248, 1);
        V v_e_2412 = heff_field(v_x31_248, 2);
        V v_ru_24x31_248_24SetField = heff_take_reuse_n(v_x31_248, 7ULL, 3);
        V v_x1_2413 = heff_tr(heff_call(v_f_245, 2, (V[]){v_st_246, v_e_2412}));
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x1_2413, 0);
          V v_y_2415 = heff_field(v_x1_2413, 1);
          V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at_n(v_ru_24x3_247_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_248_24SetField, TAG_SetField, 3, (V[]){v_x_2410, v_xsp_2411, v_y_2415}), v_sp_249});
          v_x1_2422 = heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_t_2416});
          break;
        }
        default: heff_nomatch(v_x1_2413);
        }
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2417 = heff_field(v_x31_248, 0);
        V v_ru_24x31_248_24BadFieldSet = heff_take_reuse_n(v_x31_248, 1ULL, 1);
        V v_x1_2418 = heff_tr(heff_call(v_f_245, 2, (V[]){v_st_246, v_e_2417}));
        switch (heff_tag_of(v_x1_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x1_2418, 0);
          V v_y_2420 = heff_field(v_x1_2418, 1);
          V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
          V v_t_2421 = heff_tag_at_n(v_ru_24x3_247_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_248_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_y_2420}), v_sp_249});
          v_x1_2422 = heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_t_2421});
          break;
        }
        default: heff_nomatch(v_x1_2418);
        }
        break;
      }
      default: heff_nomatch(v_x31_248);
      }
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_MkPair: {
      V v_st_2423 = heff_field(v_x1_2422, 0);
      V v_y_2424 = heff_field(v_x1_2422, 1);
      heff_take_n(v_x1_2422, 3ULL, 2);
      HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_lit_240, v_st_2423, v_xs_244));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_y_2429 = v_field_2427;
        return ((HeffT2){{v_x_2428, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_2424, v_y_2429})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2422)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_248, 0ULL, 4);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2433 = v_t_2432.f[0];
                V v_field_2434 = v_t_2432.f[1];
                V v_a_2435 = v_field_2433;
                V v_a_2436 = v_field_2434;
                heff_drop(v_a_2436);
                v_a_2437 = v_a_2435;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(v_a_2437, v_xs_243));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_x_2441 = v_field_2439;
          V v_y_2442 = v_field_2440;
          V v_t_2443 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2441, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2443, v_y_2442})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_244 = ({ V a_0 = v_st_240; V a_1 = v_x_242; HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      V v_st_248 = v_field_245;
      V v_y_249 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_st_248, v_xs_243));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_249, v_y_2414})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eliftE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eliftE_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eliftE(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eliftE(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eendOf_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2eendOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eendOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eendOf(V v_cx_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EndValue: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), heff_dup(v_sp_241)});
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eendOf_str0)}), heff_dup(v_sp_241)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
    return (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), v_sp_241, heff_get_n(v_cx_240, 4, 6), v_t_247));
  }
  case TAG_EndJump: {
    V v_j_248 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24EndJump = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    return (g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(v_ru_24x3_242_24EndJump, v_cx_240, v_sp_241, v_j_248));
  }
  case TAG_EndGive: {
    V v_vars_249 = heff_field(v_x3_242, 0);
    V v_d_2410 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EndGive = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2411 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_d_2410);
    V v_v_2412 = (g_heff_2esyntax_2epresyntax_2epackE(heff_dup(v_sp_241), v_vars_249));
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24EndGive, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), heff_dup(v_sp_241)});
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2412, NTAG(TAG_Nil)});
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2415));
    return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_2411, v_t_2416));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eendOf(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_246)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_246, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_246)));
              {
                V v_field_2421 = v_t_2420.f[0];
                V v_field_2422 = v_t_2420.f[1];
                V v_a_2423 = v_field_2421;
                V v_a_2424 = v_field_2422;
                heff_drop(v_a_2424);
                v_a_2425 = v_a_2423;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_246);
          }
        }
        HeffT2 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(v_a_2425, v_xs_243));
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_x_2429 = v_field_2427;
          V v_y_2430 = v_field_2428;
          V v_t_2431 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2429, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2431, v_y_2430})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2421;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2421 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_246)) {
        case TAG_At: {
          V v_a_247 = heff_dup(heff_field(v_e_246, 0));
          switch (heff_tag_of(v_a_247)) {
          case TAG_ELam: {
            heff_take_n(v_a_247, 0ULL, 2);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2421 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2421 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          default: {
            heff_drop(v_a_247);
            HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_246)));
            {
              V v_field_2417 = v_t_2416.f[0];
              V v_field_2418 = v_t_2416.f[1];
              V v_a_2419 = v_field_2417;
              V v_a_2420 = v_field_2418;
              heff_drop(v_a_2420);
              v_x_2421 = v_a_2419;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_246);
        }
      }
      return ((HeffT3){{v_x_2421, heff_tag_at_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_2422 = heff_field(v_x31_242, 0);
      V v_e_2423 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2438;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2438 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2423)) {
        case TAG_At: {
          V v_a_2424 = heff_dup(heff_field(v_e_2423, 0));
          switch (heff_tag_of(v_a_2424)) {
          case TAG_ELam: {
            heff_take_n(v_a_2424, 0ULL, 2);
            switch (heff_tag_of(v_e_2423)) {
            case TAG_At: {
              v_x_2438 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2423);
            }
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_a_2424, 0ULL, 1);
            switch (heff_tag_of(v_e_2423)) {
            case TAG_At: {
              v_x_2438 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2423);
            }
            break;
          }
          default: {
            heff_drop(v_a_2424);
            HeffT2 v_t_2433 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2423)));
            {
              V v_field_2434 = v_t_2433.f[0];
              V v_field_2435 = v_t_2433.f[1];
              V v_a_2436 = v_field_2434;
              V v_a_2437 = v_field_2435;
              heff_drop(v_a_2437);
              v_x_2438 = v_a_2436;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2423);
        }
      }
      return ((HeffT3){{v_x_2438, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_2422, v_e_2423}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2439 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2454;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2454 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2439)) {
        case TAG_At: {
          V v_a_2440 = heff_dup(heff_field(v_e_2439, 0));
          switch (heff_tag_of(v_a_2440)) {
          case TAG_ELam: {
            heff_take_n(v_a_2440, 0ULL, 2);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              v_x_2454 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_a_2440, 0ULL, 1);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              v_x_2454 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          default: {
            heff_drop(v_a_2440);
            HeffT2 v_t_2449 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2439)));
            {
              V v_field_2450 = v_t_2449.f[0];
              V v_field_2451 = v_t_2449.f[1];
              V v_a_2452 = v_field_2450;
              V v_a_2453 = v_field_2451;
              heff_drop(v_a_2453);
              v_x_2454 = v_a_2452;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2439);
        }
      }
      return ((HeffT3){{v_x_2454, heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_e_2439}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_2455 = heff_field(v_x31_242, 0);
      V v_xsp_2456 = heff_field(v_x31_242, 1);
      V v_e_2457 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2472;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2472 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2457)) {
        case TAG_At: {
          V v_a_2458 = heff_dup(heff_field(v_e_2457, 0));
          switch (heff_tag_of(v_a_2458)) {
          case TAG_ELam: {
            heff_take_n(v_a_2458, 0ULL, 2);
            switch (heff_tag_of(v_e_2457)) {
            case TAG_At: {
              v_x_2472 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2457);
            }
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_a_2458, 0ULL, 1);
            switch (heff_tag_of(v_e_2457)) {
            case TAG_At: {
              v_x_2472 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2457);
            }
            break;
          }
          default: {
            heff_drop(v_a_2458);
            HeffT2 v_t_2467 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2457)));
            {
              V v_field_2468 = v_t_2467.f[0];
              V v_field_2469 = v_t_2467.f[1];
              V v_a_2470 = v_field_2468;
              V v_a_2471 = v_field_2469;
              heff_drop(v_a_2471);
              v_x_2472 = v_a_2470;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2457);
        }
      }
      return ((HeffT3){{v_x_2472, heff_tag_at_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, (V[]){v_x_2455, v_xsp_2456, v_e_2457}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_2473 = heff_field(v_x31_242, 0);
      V v_e_2474 = heff_field(v_x31_242, 1);
      V v_ss_2475 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2490;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2490 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2474)) {
        case TAG_At: {
          V v_a_2476 = heff_dup(heff_field(v_e_2474, 0));
          switch (heff_tag_of(v_a_2476)) {
          case TAG_ELam: {
            heff_take_n(v_a_2476, 0ULL, 2);
            switch (heff_tag_of(v_e_2474)) {
            case TAG_At: {
              v_x_2490 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2474);
            }
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_a_2476, 0ULL, 1);
            switch (heff_tag_of(v_e_2474)) {
            case TAG_At: {
              v_x_2490 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2474);
            }
            break;
          }
          default: {
            heff_drop(v_a_2476);
            HeffT2 v_t_2485 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2474)));
            {
              V v_field_2486 = v_t_2485.f[0];
              V v_field_2487 = v_t_2485.f[1];
              V v_a_2488 = v_field_2486;
              V v_a_2489 = v_field_2487;
              heff_drop(v_a_2489);
              v_x_2490 = v_a_2488;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2474);
        }
      }
      HeffT2 v_t_2491 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_2490, v_ss_2475));
      {
        V v_field_2492 = v_t_2491.f[0];
        V v_field_2493 = v_t_2491.f[1];
        V v_x_2494 = v_field_2492;
        V v_y_2495 = v_field_2493;
        return ((HeffT3){{v_x_2494, heff_tag_at_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, (V[]){v_p_2473, v_e_2474, v_y_2495}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str0, 5, "join#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str1, 5, "join#");
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0, 1, 0};
Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(V v_cx_240, V v_sp_241, V v_s_242, V v_arms_243, V v_rest_244, V v_end_245) {
top: ;
  switch (heff_tag_of(v_rest_244)) {
  case TAG_Nil: {
    V v_t_246 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
    HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_246}), NTAG(TAG_Nil), v_s_242));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_y_2411 = v_field_249;
      V v_alts_2412 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), v_end_245, v_arms_243));
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2411, v_alts_2412}), v_sp_241});
      return ({ V a_0 = v_cx_240; V a_1 = v_x_2410; V a_2 = v_t_2413; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
    }
  }
  case TAG_Cons: {
    V v_x1_2416 = (g_list_2ekeepIf_24s1674319799x1081446864(heff_dup(v_arms_243)));
    V v_t_2426;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_a_2417 = heff_field(v_x1_2416, 0);
      V v_x12_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24Cons = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x12_2418)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a_2417)) {
        case TAG_MkPair: {
          V v_p_2419 = heff_field(v_a_2417, 0);
          V v_ss_2420 = heff_field(v_a_2417, 1);
          heff_take_n(v_a_2417, 3ULL, 2);
          V v_x1_2421 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x1_2416_24Cons, v_p_2419));
          switch (heff_tag_of(v_x1_2421)) {
          case TAG_Nil: {
            v_t_2426 = ({ V a_0 = v_ss_2420; V r_ = (g_list_2eall_24s568190696x1372373514(a_0)); heff_drop(v_ss_2420); r_; });
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x1_2421, 0ULL, 2);
            heff_drop(v_ss_2420);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_2421);
          }
          break;
        }
        default: heff_nomatch(v_a_2417);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x12_2418, 0ULL, 2);
        heff_drop(v_a_2417);
        heff_drop_cell(v_ru_24x1_2416_24Cons, 2);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_2418);
      }
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      V v_t_2427 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2427}), NTAG(TAG_Nil), v_s_242));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        V v_alts_2433 = (g_list_2emap_24s1709068899x1960726563(heff_dup(v_cx_240), v_rest_244, v_end_245, v_arms_243));
        V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2432, v_alts_2433}), v_sp_241});
        return ({ V a_0 = v_cx_240; V a_1 = v_x_2431; V a_2 = v_t_2434; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2431); r_; });
      }
    } else {
      heff_drop(v_t_2426);
      V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
      V v_t_2483;
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2435);
        V v_arms_2436 = heff_dup(v_arms_243);
        v_t_2483 = ({ V a_0 = ((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0_clo); V a_1 = v_arms_2436; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2436); r_; });
      } else {
        heff_drop(v_t_2435);
        v_t_2483 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
        heff_drop(v_t_2483);
        V v_t_2484 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2485 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2484}), NTAG(TAG_Nil), v_s_242));
        {
          V v_field_2486 = v_t_2485.f[0];
          V v_field_2487 = v_t_2485.f[1];
          V v_x_2488 = v_field_2486;
          V v_y_2489 = v_field_2487;
          V v_t_2490 = heff_tag_n(TAG_EndGive, 2, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 4))});
          V v_alts_2491 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), v_t_2490, v_arms_243));
          V v_t_2492 = (g_heff_2esyntax_2epresyntax_2epackTy(heff_dup(v_sp_241), heff_dup(heff_rfield(v_cx_240, 1))));
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2489, v_alts_2491}), heff_dup(v_sp_241)});
          V v_t_2496;
          switch (heff_tag_of(v_t_2492)) {
          case TAG_At: {
            V v_s_2495 = heff_dup(heff_field(v_t_2492, 1));
            v_t_2496 = v_s_2495;
            break;
          }
          default: heff_nomatch(v_t_2492);
          }
          V v_t_2497 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2496, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2493, v_t_2492}), v_t_2497});
          V v_t_2499 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_244; V a_2 = v_end_245; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop_tag(v_rest_244, 2); r_; });
          V v_t_24100 = (g_heff_2esyntax_2epresyntax_2egiveBackLet(v_sp_241, heff_dup(heff_rfield(v_cx_240, 1)), v_t_2498, v_t_2499));
          return ({ V a_0 = v_cx_240; V a_1 = v_x_2488; V a_2 = v_t_24100; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2488); r_; });
        }
      } else {
        heff_drop(v_t_2483);
        V v_t_24101 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24102 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24101}), NTAG(TAG_Nil), v_s_242));
        {
          V v_field_24103 = v_t_24102.f[0];
          V v_field_24104 = v_t_24102.f[1];
          V v_x_24105 = v_field_24103;
          V v_y_24106 = v_field_24104;
          V v_t_24107 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
          V v_t_24108 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str0), v_t_24107)});
          V v_t_24109 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24108, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
          V v_alts_24110 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), heff_tag_n(TAG_EndJump, 1, (V[]){v_t_24109}), v_arms_243));
          V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_24106, v_alts_24110}), heff_dup(v_sp_241)});
          V v_t_24112 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
          V v_t_24113 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          V v_t_24114 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_244; V a_2 = v_end_245; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop_tag(v_rest_244, 2); r_; });
          V v_t_24115 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str1), v_t_24112), heff_dup(v_sp_241), v_t_24113, v_t_24114));
          V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
          V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_24111, v_t_24116}), v_sp_241});
          return ({ V a_0 = v_cx_240; V a_1 = v_x_24105; V a_2 = v_t_24117; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24105); r_; });
        }
      }
    }
  }
  default: return heff_nomatch(v_rest_244);
  }
}
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0(V self, V *args) {
  V v_a_2437 = args[0];
  V v_t_2440;
  switch (heff_tag_of(v_a_2437)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_dup(heff_field(v_a_2437, 1));
    v_t_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_a_2437);
  }
  V v_x1_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2440));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nil: {
    V v_t_2444;
    switch (heff_tag_of(v_a_2437)) {
    case TAG_MkPair: {
      V v_y_2443 = heff_field(v_a_2437, 1);
      heff_take_n(v_a_2437, 2ULL, 2);
      v_t_2444 = v_y_2443;
      break;
    }
    default: heff_nomatch(v_a_2437);
    }
    V v_x1_2445 = (g_list_2eany_24s750144226x405092487(v_t_2444));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2445) == NTAG(TAG_True)));
    heff_drop(v_x1_2445);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 2);
    switch (heff_tag_of(v_x_2446)) {
    case TAG_At: {
      V v_it11_2448 = heff_field(v_x_2446, 0);
      heff_take_n(v_x_2446, 1ULL, 2);
      switch (heff_tag_of(v_it11_2448)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2455;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2454 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2455 = v_y_2454;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2456 = (g_list_2eany_24s750144226x405092487(v_t_2455));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2456) == NTAG(TAG_True)));
        heff_drop(v_x1_2456);
        return v_ret_24bool;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2448, 0ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2460 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2461 = v_y_2460;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2462 = (g_list_2eany_24s750144226x405092487(v_t_2461));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2462) == NTAG(TAG_True)));
        heff_drop(v_x1_2462);
        return v_ret_24bool;
      }
      case TAG_StmtExpr: {
        V v_e_2463 = heff_field(v_it11_2448, 0);
        heff_take_n(v_it11_2448, 1ULL, 1);
        V v_t_2464 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2463));
        if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
          heff_drop(v_t_2464);
          V v_t_2467;
          switch (heff_tag_of(v_a_2437)) {
          case TAG_MkPair: {
            V v_y_2466 = heff_field(v_a_2437, 1);
            heff_take_n(v_a_2437, 2ULL, 2);
            v_t_2467 = v_y_2466;
            break;
          }
          default: heff_nomatch(v_a_2437);
          }
          V v_x1_2468 = (g_list_2eany_24s750144226x405092487(v_t_2467));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2468) == NTAG(TAG_True)));
          heff_drop(v_x1_2468);
          return v_ret_24bool;
        } else {
          heff_drop(v_a_2437);
          heff_drop(v_t_2464);
          return NTAG(TAG_False);
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2474;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2473 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2474 = v_y_2473;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2475 = (g_list_2eany_24s750144226x405092487(v_t_2474));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2475) == NTAG(TAG_True)));
        heff_drop(v_x1_2475);
        return v_ret_24bool;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2481;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2480 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2481 = v_y_2480;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2482 = (g_list_2eany_24s750144226x405092487(v_t_2481));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2482) == NTAG(TAG_True)));
        heff_drop(v_x1_2482);
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_it11_2448);
      }
    }
    default: return heff_nomatch(v_x_2446);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str0, 5, "exit#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str1, 5, "Right");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str2, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str3, 5, "exit#");
Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry, 8, 0};

V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V v_cx_240, V v_sp_241, V v_ret_242, V v_call_243, V v_ps_244, V v_bodyOf_245, V v_rest_246, V v_end_247) {
top: ;
  V v_alts_248 = (g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718(heff_dup(v_cx_240), heff_dup(v_sp_241), v_ret_242, v_rest_246, v_end_247));
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_call_243, v_alts_248}), heff_dup(v_sp_241)});
  V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_f_2411 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str0), v_t_2410);
  V v_ps_2412 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_ty_2413 = (g_heff_2esyntax_2epresyntax_2egivenTy(heff_dup(v_sp_241), v_ret_242, heff_dup(heff_rfield(v_cx_240, 1))));
  V v_vars_2414 = heff_dup(heff_rfield(v_cx_240, 1));
  V v_v_2418;
  if ((heff_dup(v_ret_242) == NTAG(TAG_True))) {
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str1)}), heff_dup(v_sp_241)});
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2epackE(heff_dup(v_sp_241), v_vars_2414));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    v_v_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2417));
  } else {
    v_v_2418 = (g_heff_2esyntax_2epresyntax_2epackE(heff_dup(v_sp_241), v_vars_2414));
  }
  V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419}), heff_dup(v_sp_241)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2418, NTAG(TAG_Nil)});
  V v_body_2422 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2420, v_t_2421));
  V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2412)));
  V v_t_2424 = (g_list_2efoldl_24s958865698x1719976126(heff_dup(v_sp_241), v_ty_2413, v_t_2423));
  V v_t_2425 = (g_list_2emap_24s1937570095x2110149801(v_ps_2412));
  V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_2411), heff_dup(v_sp_241), v_t_2425, v_body_2422}), heff_dup(v_sp_241)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_f_2411, heff_dup(v_sp_241), NTAG(TAG_AsDefinition), v_t_2424, v_t_2427});
  V v_t_2429 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_f_2430 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str2), v_t_2429);
  V v_ty_2431 = (g_heff_2esyntax_2epresyntax_2egivenTy(heff_dup(v_sp_241), v_ret_242, heff_dup(heff_rfield(v_cx_240, 1))));
  V v_t_2432 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_t_2433 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_str3), v_t_2432)});
  V v_t_2434 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_241)}), heff_take_field(v_cx_240, 1), NTAG(TAG_True), heff_get_n(v_cx_240, 4, 6)});
  V v_body_2435 = heff_tr(heff_call(v_bodyOf_245, 1, (V[]){v_t_2434}));
  V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_244)));
  V v_t_2437 = (g_list_2efoldl_24s958865698x1719976126(heff_dup(v_sp_241), v_ty_2431, v_t_2436));
  V v_t_2438 = (g_list_2emap_24s1937570095x2110149801(v_ps_244));
  V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_2430), heff_dup(v_sp_241), v_t_2438, v_body_2435}), heff_dup(v_sp_241)});
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
  V v_t_2441 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_f_2430, heff_dup(v_sp_241), NTAG(TAG_AsDefinition), v_t_2437, v_t_2440});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2428, heff_dup(v_sp_241)}), v_t_2442});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_249, v_t_2443}), v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a6 = a[6]; V r = g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(a[0], a[1], a2, a[3], a[4], a[5], a6, a[7]); heff_drop(a2); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str0, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str2, 57, "` is not a `let mut` variable: only one is set, `let mut ");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str3, 5, " = e`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str4, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str5, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str6, 64, "`break` is in a loop only: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str7, 52, "nothing after `break` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str8, 52, "nothing after `break` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str9, 67, "`continue` is in a loop only: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str10, 55, "nothing after `continue` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str11, 55, "nothing after `continue` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str12, 53, "nothing after `return` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str13, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str15, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str16, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str17, 69, "nothing after this `with` runs: its statements do not reach their end");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str18, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V v_cx_240, V v_e_241, V v_rest_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_244 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_244)) {
    case TAG_EMatch: {
      V v_s_246 = heff_field(v_e1_244, 0);
      V v_alts_247 = heff_field(v_e1_244, 1);
      heff_take_n(v_e1_244, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_249 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        V v_t_2410 = (g_list_2emap_24s272223926x273382154(v_alts_247));
        return (g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(v_cx_240, v_sp_249, v_s_246, v_t_2410, v_rest_242, v_end_243));
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EAssign: {
      V v_x_2411 = heff_field(v_e1_244, 0);
      V v_xsp_2412 = heff_field(v_e1_244, 1);
      V v_v_2413 = heff_field(v_e1_244, 2);
      heff_take_n(v_e1_244, 7ULL, 3);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 0ULL, 2);
        V v_t_2416 = (g_list_2eany_24s2077819594x1842428557(v_x_2411, heff_rfield(v_cx_240, 1)));
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          V v_t_2417 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2417}), NTAG(TAG_Nil), v_v_2413));
          {
            V v_field_2419 = v_t_2418.f[0];
            V v_field_2420 = v_t_2418.f[1];
            V v_x_2421 = v_field_2419;
            V v_y_2422 = v_field_2420;
            V v_t_2423 = heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str0)}), heff_dup(v_xsp_2412)});
            V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2411)}), heff_dup(v_xsp_2412)});
            V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
            V v_t_2426 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2423, v_t_2425));
            V v_t_2429;
            switch (heff_tag_of(v_y_2422)) {
            case TAG_At: {
              V v_s_2428 = heff_dup(heff_field(v_y_2422, 1));
              v_t_2429 = v_s_2428;
              break;
            }
            default: heff_nomatch(v_y_2422);
            }
            V v_v_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2422, v_t_2426}), v_t_2429});
            V v_body_2431 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
            V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2411}), heff_dup(v_xsp_2412)});
            V v_t_2435;
            switch (heff_tag_of(v_body_2431)) {
            case TAG_At: {
              V v_s_2434 = heff_dup(heff_field(v_body_2431, 1));
              v_t_2435 = v_s_2434;
              break;
            }
            default: heff_nomatch(v_body_2431);
            }
            V v_t_2436 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2412, 0)); V rr_ = heff_rec_reuse_nf(v_t_2435, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2432, heff_dup(v_body_2431)}), v_t_2436});
            V v_t_2440;
            switch (heff_tag_of(v_body_2431)) {
            case TAG_At: {
              V v_s_2439 = heff_field(v_body_2431, 1);
              heff_take_n(v_body_2431, 2ULL, 2);
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_body_2431);
            }
            V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2430, v_t_2437}), v_t_2441});
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2421; V a_2 = v_t_2442; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2421); r_; });
          }
        } else {
          heff_drop_rec(v_cx_240, 6);
          heff_drop(v_rest_242);
          heff_drop(v_end_243);
          heff_drop(v_v_2413);
          heff_drop(v_t_2416);
          V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str1), heff_dup(v_x_2411)), ((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str2));
          V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2443, v_x_2411), ((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str3));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2444}), v_xsp_2412});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EWhile: {
      V v_c_2445 = heff_field(v_e1_244, 0);
      V v_body_2446 = heff_field(v_e1_244, 1);
      heff_take_n(v_e1_244, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2448 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        return ({ V a_0 = v_cx_240; V a_1 = v_sp_2448; V a_2 = v_c_2445; V a_3 = v_body_2446; V a_4 = v_rest_242; V a_5 = v_end_243; V r_ = (g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_242); r_; });
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EFor: {
      V v_p_2449 = heff_field(v_e1_244, 0);
      V v_c_2450 = heff_field(v_e1_244, 1);
      V v_body_2451 = heff_field(v_e1_244, 2);
      heff_take_n(v_e1_244, 7ULL, 3);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2453 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        return (g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(v_cx_240, v_sp_2453, v_p_2449, v_c_2450, v_body_2451, v_rest_242, v_end_243));
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EIfThen: {
      V v_c_2454 = heff_field(v_e1_244, 0);
      V v_a_2455 = heff_field(v_e1_244, 1);
      V v_ru_24e1_244_24EIfThen = heff_take_reuse_n(v_e1_244, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2457 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2458 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_2454));
        V v_t_2459 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str4), heff_dup(v_sp_2457), NTAG(TAG_Nil)});
        V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_2457, 0)), heff_dup(heff_rfield(v_sp_2457, 1))});
        V v_t_2470;
        switch (heff_tag_of(v_a_2455)) {
        case TAG_At: {
          V v_e1_2461 = heff_dup(heff_field(v_a_2455, 0));
          switch (heff_tag_of(v_e1_2461)) {
          case TAG_EDo: {
            V v_ss_2463 = heff_field(v_e1_2461, 0);
            heff_take_n(v_e1_2461, 1ULL, 1);
            heff_drop_cell(v_ru_24e1_244_24EIfThen, 2);
            switch (heff_tag_of(v_a_2455)) {
            case TAG_At: {
              heff_take_n(v_a_2455, 0ULL, 2);
              v_t_2470 = v_ss_2463;
              break;
            }
            default: heff_nomatch(v_a_2455);
            }
            break;
          }
          default: {
            heff_drop(v_e1_2461);
            V v_t_2468;
            switch (heff_tag_of(v_a_2455)) {
            case TAG_At: {
              V v_s_2467 = heff_dup(heff_field(v_a_2455, 1));
              v_t_2468 = v_s_2467;
              break;
            }
            default: heff_nomatch(v_a_2455);
            }
            V v_t_2469 = heff_tag_at_n(v_ru_24e1_244_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_a_2455}), v_t_2468});
            v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_a_2455);
        }
        V v_t_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){v_t_2459, v_t_2460}), v_t_2470});
        V v_t_2472 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str5), heff_dup(v_sp_2457), NTAG(TAG_Nil)});
        V v_t_2473 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_2457, 0)), heff_dup(heff_rfield(v_sp_2457, 1))});
        V v_t_2474 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2472, v_t_2473}), NTAG(TAG_Nil)});
        V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
        return (g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(v_cx_240, v_sp_2457, v_t_2458, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, v_t_2475}), v_rest_242, v_end_243));
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EBreak: {
      heff_drop(v_end_243);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2478 = heff_dup(heff_rfield(v_cx_240, 2));
        switch (heff_tag_of(v_t_2478)) {
        case TAG_Nothing: {
          heff_drop_rec(v_cx_240, 6);
          switch (heff_tag_of(v_rest_242)) {
          case TAG_Nil: {
            return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str6)}), v_sp_2477});
          }
          case TAG_Cons: {
            V v_s_2479 = heff_field(v_rest_242, 0);
            heff_take_n(v_rest_242, 1ULL, 2);
            heff_drop(v_sp_2477);
            V v_t_2483;
            switch (heff_tag_of(v_s_2479)) {
            case TAG_At: {
              V v_s_2482 = heff_field(v_s_2479, 1);
              heff_take_n(v_s_2479, 2ULL, 2);
              v_t_2483 = v_s_2482;
              break;
            }
            default: heff_nomatch(v_s_2479);
            }
            return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str7)}), v_t_2483});
          }
          default: return heff_nomatch(v_rest_242);
          }
        }
        case TAG_Just: {
          V v_x11_2484 = heff_field(v_t_2478, 0);
          V v_ru_24t_2478_24Just = heff_take_reuse_n(v_t_2478, 1ULL, 1);
          switch (heff_tag_of(v_x11_2484)) {
          case TAG_MkPair: {
            V v_b_2486 = heff_field(v_x11_2484, 1);
            heff_take_n(v_x11_2484, 2ULL, 2);
            switch (heff_tag_of(v_rest_242)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24t_2478_24Just, 1);
              HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(v_ru_24e_241_24At, v_cx_240, v_sp_2477, v_b_2486);
            }
            case TAG_Cons: {
              V v_s_2487 = heff_field(v_rest_242, 0);
              heff_take_n(v_rest_242, 1ULL, 2);
              heff_drop_rec(v_cx_240, 6);
              heff_drop(v_sp_2477);
              heff_drop(v_b_2486);
              V v_t_2491;
              switch (heff_tag_of(v_s_2487)) {
              case TAG_At: {
                V v_s_2490 = heff_field(v_s_2487, 1);
                heff_take_n(v_s_2487, 2ULL, 2);
                v_t_2491 = v_s_2490;
                break;
              }
              default: heff_nomatch(v_s_2487);
              }
              return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_2478_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str8)}), v_t_2491});
            }
            default: return heff_nomatch(v_rest_242);
            }
          }
          default: return heff_nomatch(v_x11_2484);
          }
        }
        default: return heff_nomatch(v_t_2478);
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EContinue: {
      heff_drop(v_end_243);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2493 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2494 = heff_dup(heff_rfield(v_cx_240, 2));
        switch (heff_tag_of(v_t_2494)) {
        case TAG_Nothing: {
          heff_drop_rec(v_cx_240, 6);
          switch (heff_tag_of(v_rest_242)) {
          case TAG_Nil: {
            return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str9)}), v_sp_2493});
          }
          case TAG_Cons: {
            V v_s_2495 = heff_field(v_rest_242, 0);
            heff_take_n(v_rest_242, 1ULL, 2);
            heff_drop(v_sp_2493);
            V v_t_2499;
            switch (heff_tag_of(v_s_2495)) {
            case TAG_At: {
              V v_s_2498 = heff_field(v_s_2495, 1);
              heff_take_n(v_s_2495, 2ULL, 2);
              v_t_2499 = v_s_2498;
              break;
            }
            default: heff_nomatch(v_s_2495);
            }
            return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str10)}), v_t_2499});
          }
          default: return heff_nomatch(v_rest_242);
          }
        }
        case TAG_Just: {
          V v_x11_24100 = heff_field(v_t_2494, 0);
          V v_ru_24t_2494_24Just = heff_take_reuse_n(v_t_2494, 1ULL, 1);
          switch (heff_tag_of(v_x11_24100)) {
          case TAG_MkPair: {
            V v_c_24101 = heff_field(v_x11_24100, 0);
            heff_take_n(v_x11_24100, 1ULL, 2);
            switch (heff_tag_of(v_rest_242)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24t_2494_24Just, 1);
              HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(v_ru_24e_241_24At, v_cx_240, v_sp_2493, v_c_24101);
            }
            case TAG_Cons: {
              V v_s_24103 = heff_field(v_rest_242, 0);
              heff_take_n(v_rest_242, 1ULL, 2);
              heff_drop_rec(v_cx_240, 6);
              heff_drop(v_sp_2493);
              heff_drop(v_c_24101);
              V v_t_24107;
              switch (heff_tag_of(v_s_24103)) {
              case TAG_At: {
                V v_s_24106 = heff_field(v_s_24103, 1);
                heff_take_n(v_s_24103, 2ULL, 2);
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_s_24103);
              }
              return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_2494_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str11)}), v_t_24107});
            }
            default: return heff_nomatch(v_rest_242);
            }
          }
          default: return heff_nomatch(v_x11_24100);
          }
        }
        default: return heff_nomatch(v_t_2494);
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EReturn: {
      V v_v_24108 = heff_field(v_e1_244, 0);
      V v_ru_24e1_244_24EReturn = heff_take_reuse_n(v_e1_244, 1ULL, 1);
      heff_drop(v_end_243);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24110 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        switch (heff_tag_of(v_rest_242)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24e1_244_24EReturn, 1);
          heff_drop_cell(v_ru_24e_241_24At, 2);
          V v_t_24111 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_24112 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24111}), NTAG(TAG_Nil), v_v_24108));
          {
            V v_field_24113 = v_t_24112.f[0];
            V v_field_24114 = v_t_24112.f[1];
            V v_x_24115 = v_field_24113;
            V v_y_24116 = v_field_24114;
            V v_t_24117 = (g_heff_2esyntax_2epresyntax_2ereturnOf(heff_dup(v_cx_240), heff_dup(v_sp_24110), v_y_24116));
            V v_t_24118 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), v_sp_24110, heff_dup(heff_rfield(v_cx_240, 4)), v_t_24117));
            return ({ V a_0 = v_cx_240; V a_1 = v_x_24115; V a_2 = v_t_24118; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24115); r_; });
          }
        }
        case TAG_Cons: {
          V v_s_24119 = heff_field(v_rest_242, 0);
          heff_take_n(v_rest_242, 1ULL, 2);
          heff_drop_rec(v_cx_240, 6);
          heff_drop(v_v_24108);
          heff_drop(v_sp_24110);
          V v_t_24123;
          switch (heff_tag_of(v_s_24119)) {
          case TAG_At: {
            V v_s_24122 = heff_field(v_s_24119, 1);
            heff_take_n(v_s_24119, 2ULL, 2);
            v_t_24123 = v_s_24122;
            break;
          }
          default: heff_nomatch(v_s_24119);
          }
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_244_24EReturn, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str12)}), v_t_24123});
        }
        default: return heff_nomatch(v_rest_242);
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ETry: {
      V v_e11_24124 = heff_field(v_e1_244, 0);
      V v_ru_24e1_244_24ETry = heff_take_reuse_n(v_e1_244, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24126 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        switch (heff_tag_of(v_e11_24124)) {
        case TAG_MkTry: {
          V v_err_24127 = heff_field(v_e11_24124, 0);
          V v_body_24128 = heff_field(v_e11_24124, 1);
          V v_h_24129 = heff_field(v_e11_24124, 2);
          V v_ru_24e11_24124_24MkTry = heff_take_reuse_n(v_e11_24124, 7ULL, 3);
          HeffT3 v_t_24130 = (g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(heff_dup(v_cx_240), heff_dup(v_h_24129)));
          {
            V v_field_24132 = v_t_24130.f[1];
            V v_field_24133 = v_t_24130.f[2];
            int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
            if ((v_tag_24131 == ((int64_t)0ULL))) {
              heff_drop_rec(v_cx_240, 6);
              heff_drop(v_rest_242);
              heff_drop(v_end_243);
              heff_drop_cell(v_ru_24e1_244_24ETry, 1);
              heff_drop(v_sp_24126);
              heff_drop(v_err_24127);
              heff_drop(v_body_24128);
              heff_drop(v_h_24129);
              heff_drop_cell(v_ru_24e11_24124_24MkTry, 3);
              V v_wrong_24134 = heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_field_24132}), v_field_24133});
              return v_wrong_24134;
            } else {
              heff_drop(v_field_24132);
              heff_drop(v_field_24133);
              V v_cx_24135 = v_cx_240;
              V v_sp_24136 = v_sp_24126;
              V v_tr_24137 = heff_tag_at_n(v_ru_24e11_24124_24MkTry, TAG_MkTry, 3, (V[]){v_err_24127, v_body_24128, v_h_24129});
              V v_rest_24138 = v_rest_242;
              V v_end_24139 = v_end_243;
              V v_scope_24140 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo), 3, (V[]){heff_dup(v_cx_24135), heff_dup(v_sp_24136), heff_dup(v_tr_24137)}));
              V v_t_24141 = heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_244_24ETry, TAG_ETry, 1, (V[]){v_tr_24137}), heff_dup(v_sp_24136)});
              V v_falls_24142 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_t_24141));
              switch (heff_tag_of(v_rest_24138)) {
              case TAG_Nil: {
                heff_drop(v_cx_24135);
                heff_drop(v_sp_24136);
                heff_drop(v_falls_24142);
                return heff_tail(v_scope_24140, 1, (V[]){v_end_24139});
              }
              case TAG_Cons: {
                V v_s_24143 = heff_field(v_rest_24138, 0);
                V v_rest_24144 = heff_field(v_rest_24138, 1);
                V v_ru_24rest_24138_24Cons = heff_take_reuse_n(v_rest_24138, 3ULL, 2);
                if ((heff_dup(v_falls_24142) == NTAG(TAG_True))) {
                  heff_drop(v_falls_24142);
                  return (g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(v_ru_24rest_24138_24Cons, v_s_24143, v_rest_24144, v_cx_24135, v_sp_24136, v_scope_24140, v_end_24139));
                } else {
                  heff_drop(v_cx_24135);
                  heff_drop(v_sp_24136);
                  heff_drop(v_end_24139);
                  heff_drop(v_scope_24140);
                  heff_drop(v_falls_24142);
                  heff_drop(v_rest_24144);
                  V v_t_24147;
                  switch (heff_tag_of(v_s_24143)) {
                  case TAG_At: {
                    V v_s_24146 = heff_field(v_s_24143, 1);
                    heff_take_n(v_s_24143, 2ULL, 2);
                    v_t_24147 = v_s_24146;
                    break;
                  }
                  default: heff_nomatch(v_s_24143);
                  }
                  return heff_tag_at_n(v_ru_24rest_24138_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str13)}), v_t_24147});
                }
              }
              default: return heff_nomatch(v_rest_24138);
              }
            }
          }
        }
        default: return heff_nomatch(v_e11_24124);
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EWith: {
      V v_w_24148 = heff_field(v_e1_244, 0);
      V v_x_24149 = heff_field(v_e1_244, 1);
      V v_xsp_24150 = heff_field(v_e1_244, 2);
      V v_body_24151 = heff_field(v_e1_244, 3);
      heff_take_n(v_e1_244, 15ULL, 4);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24153 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_cx_24154 = v_cx_240;
        V v_sp_24155 = v_sp_24153;
        V v_w_24156 = v_w_24148;
        V v_x_24157 = v_x_24149;
        V v_xsp_24158 = v_xsp_24150;
        V v_body_24159 = v_body_24151;
        V v_rest_24160 = v_rest_242;
        V v_end_24161 = v_end_243;
        V v_t_24162 = (g_list_2eany_24s2077819594x1842428557(v_x_24157, heff_rfield(v_cx_24154, 1)));
        if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
          heff_drop_rec(v_cx_24154, 6);
          heff_drop(v_sp_24155);
          heff_drop(v_w_24156);
          heff_drop(v_body_24159);
          heff_drop(v_rest_24160);
          heff_drop(v_end_24161);
          heff_drop(v_t_24162);
          V v_t_24163 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str14), heff_dup(v_x_24157)), ((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str15));
          V v_t_24164 = heff_strAppend(heff_strAppend(v_t_24163, v_x_24157), ((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str16));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24164}), v_xsp_24158});
        } else {
          heff_drop(v_t_24162);
          V v_scope_24165 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo), 6, (V[]){heff_dup(v_cx_24154), heff_dup(v_sp_24155), v_w_24156, v_x_24157, v_xsp_24158, heff_dup(v_body_24159)}));
          V v_x1_24166 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_24159));
          V v_falls_24183;
          switch (heff_tag_of(v_x1_24166)) {
          case TAG_Nil: {
            v_falls_24183 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            V v_x_24167 = heff_field(v_x1_24166, 0);
            heff_take_n(v_x1_24166, 1ULL, 2);
            switch (heff_tag_of(v_x_24167)) {
            case TAG_At: {
              V v_it11_24169 = heff_field(v_x_24167, 0);
              heff_take_n(v_x_24167, 1ULL, 2);
              switch (heff_tag_of(v_it11_24169)) {
              case TAG_StmtBind: {
                heff_take_n(v_it11_24169, 0ULL, 3);
                v_falls_24183 = NTAG(TAG_True);
                break;
              }
              case TAG_StmtLet: {
                heff_take_n(v_it11_24169, 0ULL, 2);
                v_falls_24183 = NTAG(TAG_True);
                break;
              }
              case TAG_StmtExpr: {
                V v_e_24176 = heff_field(v_it11_24169, 0);
                heff_take_n(v_it11_24169, 1ULL, 1);
                v_falls_24183 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_24176));
                break;
              }
              case TAG_StmtLetMut: {
                heff_take_n(v_it11_24169, 0ULL, 3);
                v_falls_24183 = NTAG(TAG_True);
                break;
              }
              case TAG_StmtLetElse: {
                heff_take_n(v_it11_24169, 0ULL, 3);
                v_falls_24183 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_it11_24169);
              }
              break;
            }
            default: heff_nomatch(v_x_24167);
            }
            break;
          }
          default: heff_nomatch(v_x1_24166);
          }
          switch (heff_tag_of(v_rest_24160)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24e_241_24At, 2);
            heff_drop_rec(v_cx_24154, 6);
            heff_drop(v_sp_24155);
            heff_drop(v_falls_24183);
            return heff_tail(v_scope_24165, 1, (V[]){v_end_24161});
          }
          case TAG_Cons: {
            V v_s_24184 = heff_field(v_rest_24160, 0);
            V v_rest_24185 = heff_field(v_rest_24160, 1);
            heff_take_n(v_rest_24160, 3ULL, 2);
            if ((heff_dup(v_falls_24183) == NTAG(TAG_True))) {
              heff_drop(v_falls_24183);
              return (g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(v_ru_24e_241_24At, v_s_24184, v_rest_24185, v_cx_24154, v_sp_24155, v_scope_24165, v_end_24161));
            } else {
              heff_drop_rec(v_cx_24154, 6);
              heff_drop(v_sp_24155);
              heff_drop(v_end_24161);
              heff_drop(v_scope_24165);
              heff_drop(v_falls_24183);
              heff_drop(v_rest_24185);
              V v_t_24188;
              switch (heff_tag_of(v_s_24184)) {
              case TAG_At: {
                V v_s_24187 = heff_field(v_s_24184, 1);
                heff_take_n(v_s_24184, 2ULL, 2);
                v_t_24188 = v_s_24187;
                break;
              }
              default: heff_nomatch(v_s_24184);
              }
              return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str17)}), v_t_24188});
            }
          }
          default: return heff_nomatch(v_rest_24160);
          }
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_244);
      V v_t_24189 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24190 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24189}), NTAG(TAG_Nil), v_e_241));
      {
        V v_field_24191 = v_t_24190.f[0];
        V v_field_24192 = v_t_24190.f[1];
        V v_x_24193 = v_field_24191;
        V v_y_24194 = v_field_24192;
        V v_xsp_24195 = heff_dup(heff_rfield(v_cx_240, 3));
        V v_rest_24196 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
        V v_t_24197 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
        V v_t_24198 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24197}), heff_dup(heff_rfield(v_cx_240, 3))});
        V v_t_24199 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_str18), heff_dup(v_xsp_24195)}), heff_dup(v_rest_24196)});
        V v_t_24202;
        switch (heff_tag_of(v_rest_24196)) {
        case TAG_At: {
          V v_s_24201 = heff_field(v_rest_24196, 1);
          heff_take_n(v_rest_24196, 2ULL, 2);
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_rest_24196);
        }
        V v_t_24203 = ({ V rv_1 = heff_get_n(v_t_24202, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24195, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24204 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24199, v_t_24203}), NTAG(TAG_Nil)});
        V v_t_24205 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24198, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24194, v_t_24204})));
        return ({ V a_0 = v_cx_240; V a_1 = v_x_24193; V a_2 = v_t_24205; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24193); r_; });
      }
    }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V v_cx_240, V v_x3_241, V v_end_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_240), heff_get_n(v_cx_240, 3, 6), v_end_242);
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x3_241, 0);
    V v_x32_244 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_242)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_240, heff_dup(v_s_243)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_240, heff_dup(v_s_243), heff_dup(v_x32_244), v_end_242));
      }
      case TAG_EndGive: {
        return (g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_240, heff_dup(v_s_243), heff_dup(v_x32_244), v_end_242));
      }
      default: return heff_nomatch(v_end_242);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_240, heff_dup(v_s_243), heff_dup(v_x32_244), v_end_242));
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_240, v_asBits_241, v_segs_242, v_sp_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_249 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str0, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str1, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str2, 4, "#arg");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str3, 1, "x");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str4, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str5, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str6, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str7, 1, " ");
Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V v_x_240) {
top: ;
  if ((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str0), v_x_240, MK_INT(0LL), 5)) ? (((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) ? 0 : ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL)) : 1)) : 1)) {
    return v_x_240;
  } else {
    int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)7ULL));
    V v_t_242 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_241), heff_strLength_lent(v_x_240, 0));
    if (heff_strEq_c(v_t_242, ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str1))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)7ULL));
      return heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_243));
    } else {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)4ULL));
      V v_t_245 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_244), heff_strLength_lent(v_x_240, 0));
      if (heff_strEq_c(v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str2))) {
        heff_drop(v_x_240);
        return ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str3);
      } else {
        if ((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str4), v_x_240, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str5), v_x_240, MK_INT(0LL), 5)))) {
          V v_j_246 = heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str6), v_x_240, MK_INT(0LL), 5);
          if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
            heff_drop(v_j_246);
            return v_x_240;
          } else {
            V v_t_247 = heff_strAppend(heff_strSlice_lent(v_x_240, MK_INT(0LL), v_j_246, 2), ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str7));
            V v_t_248 = heff_strSlice(heff_dup(v_x_240), heff_intAdd(v_j_246, MK_INT(1LL)), heff_strLength(v_x_240));
            return heff_strAppend(v_t_247, v_t_248);
          }
        } else {
          return v_x_240;
        }
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2emadeNameSaid(a[0]);
}