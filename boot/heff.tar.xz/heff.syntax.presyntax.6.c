// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IsInferable 49402
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatVar 49363
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_bind__pure[] = {LBL_bind, LBL_pure};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econdT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2eifLetOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifLetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifLetOf_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s2082625479x1989360661(V);
V g_list_2eall_24s2082625479x1989360661_entry(V self, V *a);
extern Clo g_list_2eall_24s2082625479x1989360661_clo;
V g_list_2efilter_24s323686712x1890140612(V);
V g_list_2efilter_24s323686712x1890140612_entry(V self, V *a);
extern Clo g_list_2efilter_24s323686712x1890140612_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1520235531x215612111(V, V, V, V, V);
V g_list_2emap_24s1520235531x215612111_entry(V self, V *a);
extern Clo g_list_2emap_24s1520235531x215612111_clo;
V g_list_2emap_24s2067738717x455808399(V, V, V, V);
V g_list_2emap_24s2067738717x455808399_entry(V self, V *a);
extern Clo g_list_2emap_24s2067738717x455808399_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ty_240)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_242 = heff_field(v_x2_241, 0);
      V v_f_243 = heff_intMod(heff_dup(v_n_242), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    }
    case TAG_SizeName: {
      V v_unit_246 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_246), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_248 = heff_field(v_x2_241, 0);
      V v_f_249 = heff_intMod(heff_dup(v_n_248), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
    }
    case TAG_SizeName: {
      V v_unit_2412 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2412), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2414 = heff_field(v_x2_241, 0);
      V v_f_2415 = heff_intMod(heff_dup(v_n_2414), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
    }
    case TAG_SizeName: {
      V v_unit_2418 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2418), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2420 = heff_field(v_x2_241, 0);
      V v_f_2421 = heff_intMod(heff_dup(v_n_2420), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
    }
    case TAG_SizeName: {
      V v_unit_2424 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2424), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentUtf: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2427 = heff_field(v_x2_241, 0);
      V v_f_2428 = heff_intMod(heff_dup(v_n_2427), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
    }
    case TAG_SizeName: {
      V v_unit_2431 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2431), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ty_240)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_f_242 = heff_intMod(v_acc_241, MK_INT(8LL));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop(v_acc_241);
      heff_drop(v_x12_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_n_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V t_0 = v_x12_244;
      V t_1 = heff_intAdd(v_acc_241, v_n_245);
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str0, 6, "idBind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str1, 6, "idPure");

static V g_heff_2esyntax_2epresyntax_2eidNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eidNames_st;
static V g_heff_2esyntax_2epresyntax_2eidNames_init(void) {
  return heff_rec_n(2, shape_bind__pure, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eidNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2eidNames_str1)});
}
V g_heff_2esyntax_2epresyntax_2eidNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eidNames_st)) return g_heff_2esyntax_2epresyntax_2eidNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eidNames_val, &g_heff_2esyntax_2epresyntax_2eidNames_st, g_heff_2esyntax_2epresyntax_2eidNames_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifLetOf_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eifLetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eifLetOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eifLetOf(V v_sp_240, V v_p_241, V v_s_242, V v_a_243, V v_b_244) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_s_246 = heff_dup(heff_field(v_p_241, 1));
    v_t_247 = v_s_246;
    break;
  }
  default: heff_nomatch(v_p_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_a_243)) {
  case TAG_At: {
    V v_s_249 = heff_dup(heff_field(v_a_243, 1));
    v_t_2410 = v_s_249;
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  V v_t_2411 = ({ V rv_1 = heff_get_n(v_t_2410, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_241, v_a_243}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifLetOf_str0)}), heff_dup(v_sp_240)});
  V v_t_2416;
  switch (heff_tag_of(v_b_244)) {
  case TAG_At: {
    V v_s_2415 = heff_dup(heff_field(v_b_244, 1));
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_b_244);
  }
  V v_t_2417 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2416, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2413, v_b_244}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2419})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eifLetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eifLetOf(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V v_lit_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(heff_dup(v_lit_240), v_st_241, v_x_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_st_248 = v_field_246;
      V v_y_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_lit_240, v_st_248, v_xs_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_249, v_y_2414})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eliftE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eliftE_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eliftE(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eliftE(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str0, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str2, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2econdT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2econdT(V v_t_240, V v_cx_241, V v_sp_242, V v_s_243, V v_arms_244, V v_rest_245, V v_end_246) {
top: ;
  switch (heff_tag_of(v_rest_245)) {
  case TAG_Nil: {
    V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
    HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_247}), NTAG(TAG_Nil), v_s_243));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_y_2412 = v_field_2410;
      V v_alts_2413 = (g_list_2emap_24s2067738717x455808399(v_t_240, heff_dup(v_cx_241), v_end_246, v_arms_244));
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2412, v_alts_2413}), v_sp_242});
      return ({ V a_0 = v_cx_241; V a_1 = v_x_2411; V a_2 = v_t_2414; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
    }
  }
  case TAG_Cons: {
    V v_x1_2417 = (g_list_2efilter_24s323686712x1890140612(heff_dup(v_arms_244)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_x1_2417, 0);
      V v_x12_2419 = heff_field(v_x1_2417, 1);
      heff_take_n(v_x1_2417, 3ULL, 2);
      switch (heff_tag_of(v_x12_2419)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a_2418)) {
        case TAG_MkPair: {
          V v_p_2420 = heff_field(v_a_2418, 0);
          V v_ss_2421 = heff_field(v_a_2418, 1);
          heff_take_n(v_a_2418, 3ULL, 2);
          V v_x1_2422 = (g_heff_2esyntax_2epresyntax_2epatNames(v_p_2420));
          switch (heff_tag_of(v_x1_2422)) {
          case TAG_Nil: {
            v_t_2427 = ({ V a_0 = v_ss_2421; V r_ = (g_list_2eall_24s2082625479x1989360661(a_0)); heff_drop(v_ss_2421); r_; });
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x1_2422, 0ULL, 2);
            heff_drop(v_ss_2421);
            v_t_2427 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_2422);
          }
          break;
        }
        default: heff_nomatch(v_a_2418);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x12_2419, 0ULL, 2);
        heff_drop(v_a_2418);
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_2419);
      }
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      V v_t_2428 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2428}), NTAG(TAG_Nil), v_s_243));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        V v_y_2433 = v_field_2431;
        V v_alts_2434 = (g_list_2emap_24s1520235531x215612111(v_t_240, heff_dup(v_cx_241), v_rest_245, v_end_246, v_arms_244));
        V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2433, v_alts_2434}), v_sp_242});
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2432; V a_2 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2432); r_; });
      }
    } else {
      heff_drop(v_t_2427);
      V v_t_2436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2436}), NTAG(TAG_Nil), v_s_243));
      {
        V v_field_2438 = v_t_2437.f[0];
        V v_field_2439 = v_t_2437.f[1];
        V v_x_2440 = v_field_2438;
        V v_y_2441 = v_field_2439;
        V v_t_2442 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
        V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str1), v_t_2442));
        V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2443}), heff_dup(v_sp_242)});
        V v_t_2445 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2444, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
        V v_alts_2446 = (g_list_2emap_24s2067738717x455808399(heff_dup(v_t_240), heff_dup(v_cx_241), heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2445}), v_arms_244));
        V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2441, v_alts_2446}), heff_dup(v_sp_242)});
        V v_t_2448 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
        V v_t_2449 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str3), v_t_2448));
        V v_t_2450 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        V v_t_2451 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_245, v_end_246}));
        V v_t_2452 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2449, heff_dup(v_sp_242), v_t_2450, v_t_2451));
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
        V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2447, v_t_2453}), v_sp_242});
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2440; V a_2 = v_t_2454; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
      }
    }
  }
  default: return heff_nomatch(v_rest_245);
  }
}
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econdT(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str1, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str2, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str3, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str5, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ewhileT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT(V v_t_240, V v_cx_241, V v_sp_242, V v_c_243, V v_body_244, V v_rest_245, V v_end_246) {
top: ;
  HeffT4 v_t_247 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(heff_dup(v_sp_242), heff_dup(v_cx_241)));
  V v_t_2417;
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    heff_drop(v_t_247.f[3]);
    V v_vars_2412 = v_field_249;
    V v_t_2416;
    if ((heff_dup(v_field_2410) == NTAG(TAG_True))) {
      heff_drop(v_field_2410);
      switch (heff_tag_of(v_vars_2412)) {
      case TAG_Nil: {
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str0)}), heff_dup(v_sp_242)});
        v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2416 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2412));
        break;
      }
      default: heff_nomatch(v_vars_2412);
      }
    } else {
      heff_drop(v_field_2410);
      v_t_2416 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2412));
    }
    v_t_2417 = (g_heff_2esyntax_2epresyntax_2eapp(v_field_248, v_t_2416));
  }
  V v_t_2418 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str1), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str2), v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_t_240, 0)), 3, (V[]){heff_dup(v_cx_241), v_rest_245, v_end_246}));
  V v_t_2422 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2419, heff_dup(v_sp_242), v_t_2420, v_t_2421));
  V v_t_2423 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str4), v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2426}), NTAG(TAG_Nil), v_c_243));
  V v_t_2450;
  {
    V v_field_2428 = v_t_2427.f[0];
    V v_field_2429 = v_t_2427.f[1];
    V v_x_2430 = v_field_2428;
    V v_y_2431 = v_field_2429;
    V v_cont_2432 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_brk_2433 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_cont_2432, v_brk_2433})});
    V v_t_2435 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), v_t_2434, heff_dup(heff_rfield(v_cx_241, 3)), heff_dup(heff_rfield(v_cx_241, 4))});
    V v_t_2436 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2435, v_body_244, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2436})}));
    HeffT4 v_t_2438 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2448;
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_field_2441 = v_t_2438.f[2];
      heff_drop(v_t_2438.f[3]);
      V v_vars_2443 = v_field_2440;
      V v_t_2447;
      if ((heff_dup(v_field_2441) == NTAG(TAG_True))) {
        heff_drop(v_field_2441);
        switch (heff_tag_of(v_vars_2443)) {
        case TAG_Nil: {
          V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str5)}), heff_dup(v_sp_242)});
          v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          v_t_2447 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2443));
          break;
        }
        default: heff_nomatch(v_vars_2443);
        }
      } else {
        heff_drop(v_field_2441);
        v_t_2447 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2443));
      }
      v_t_2448 = (g_heff_2esyntax_2epresyntax_2eapp(v_field_2439, v_t_2447));
    }
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2eifOf(heff_dup(v_sp_242), v_y_2431, v_t_2437, v_t_2448));
    v_t_2450 = ({ V a_0 = v_cx_241; V a_1 = v_x_2430; V a_2 = v_t_2449; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2430); r_; });
  }
  V v_t_2451 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2424, heff_dup(v_sp_242), v_t_2425, v_t_2450));
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2452})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2453, v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ewhileT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileT(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V v_cx_240, V v_x3_241, V v_end_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_sp_243 = heff_dup(heff_rfield(v_cx_240, 3));
    switch (heff_tag_of(v_end_242)) {
    case TAG_EndValue: {
      V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 2);
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_244}), heff_dup(v_sp_243)});
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_str0)}), heff_dup(v_sp_243)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, v_t_247));
      return (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), v_sp_243, heff_get_n(v_cx_240, 4, 5), v_t_248));
    }
    case TAG_EndJump: {
      V v_j_249 = heff_field(v_end_242, 0);
      heff_take_n(v_end_242, 1ULL, 1);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_240, v_sp_243, v_j_249);
    }
    default: return heff_nomatch(v_end_242);
    }
  }
  case TAG_Cons: {
    V v_s_2410 = heff_field(v_x3_241, 0);
    V v_x32_2411 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x32_2411)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_242)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_240, heff_dup(v_s_2410)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_240, heff_dup(v_s_2410), heff_dup(v_x32_2411), v_end_242));
      }
      default: return heff_nomatch(v_end_242);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_240, heff_dup(v_s_2410), heff_dup(v_x32_2411), v_end_242));
    }
    default: return heff_nomatch(v_x32_2411);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_str0, 11, "bytesConcat");
V g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V v_r_240, V v_segs_241, V v_sp_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_clo), 1, (V[]){v_r_240}));
    V v_m_248 = heff_rec_n(2, shape_part__run, (V[]){v_t_244, ((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0_clo)});
    V v_xs_249 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_248, v_segs_241, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2410, heff_dup(v_sp_242)));
    V v_args_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_str0)}), heff_dup(v_sp_242)});
    V v_t_2414 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2412));
    V v_f_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_242});
    return ((HeffT1){{v_f_2415}});
  }
  case TAG_Just: {
    V v_s_2416 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_segs_241);
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Just, TAG_IBytes, 1, (V[]){v_s_2416}), v_sp_242});
    return ((HeffT1){{v_t_2417}});
  }
  default: return ((HeffT1){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_sp_246 = args[1];
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_247}), v_sp_246});
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_240, v_asBits_241, v_segs_242, v_sp_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_rhs_246));
      V v_t_2421;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2411 = v_field_249;
          v_t_2421 = v_c_2411;
        } else {
          if ((v_tag_248 == ((int64_t)1ULL))) {
            V v_i_2413 = v_field_249;
            V v_t_2416;
            switch (heff_tag_of(v_i_2413)) {
            case TAG_At: {
              V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
              v_t_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_i_2413);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
          } else {
            V v_t_2417 = v_field_249;
            V v_t_2420;
            switch (heff_tag_of(v_t_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_t_2417);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2421}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_249 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}