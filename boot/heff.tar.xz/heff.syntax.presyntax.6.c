// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_EAnn 33099
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_MkAlt 55173
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_bind__pure__giveBack[] = {LBL_bind, LBL_pure, LBL_giveBack};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eafterArms_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2earmsGive(V);
V g_heff_2esyntax_2epresyntax_2earmsGive_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmsGive_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2econdT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_clo;
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackLet(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackPat(V, V);
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackPat_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1014015919x2013990442_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1674319799x1081446864(V);
V g_list_2ekeepIf_24s1674319799x1081446864_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1520235531x215612111(V, V, V, V, V);
V g_list_2emap_24s1520235531x215612111_entry(V self, V *a);
extern Clo g_list_2emap_24s1520235531x215612111_clo;
V g_list_2emap_24s2067738717x455808399(V, V, V, V);
V g_list_2emap_24s2067738717x455808399_entry(V self, V *a);
extern Clo g_list_2emap_24s2067738717x455808399_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ty_240)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_242 = heff_field(v_x2_241, 0);
      V v_f_243 = heff_intMod(heff_dup(v_n_242), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    }
    case TAG_SizeName: {
      V v_unit_246 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_246), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_247 = heff_field(v_x2_241, 0);
      V v_f_248 = heff_intMod(heff_dup(v_n_247), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    }
    case TAG_SizeName: {
      V v_unit_2411 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2411), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2412 = heff_field(v_x2_241, 0);
      V v_f_2413 = heff_intMod(heff_dup(v_n_2412), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
    }
    case TAG_SizeName: {
      V v_unit_2416 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2416), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2417 = heff_field(v_x2_241, 0);
      V v_f_2418 = heff_intMod(heff_dup(v_n_2417), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
    }
    case TAG_SizeName: {
      V v_unit_2421 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2421), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_SegmentUtf: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_2423 = heff_field(v_x2_241, 0);
      V v_f_2424 = heff_intMod(heff_dup(v_n_2423), MK_INT(8LL));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
    }
    case TAG_SizeName: {
      V v_unit_2427 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod(heff_dup(v_unit_2427), MK_INT(8LL))) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ty_240)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_f_242 = heff_intMod(v_acc_241, MK_INT(8LL));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop(v_acc_241);
      heff_drop(v_x12_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_n_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V t_0 = v_x12_244;
      V t_1 = heff_intAdd(v_acc_241, v_n_245);
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str0, 6, "idBind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str1, 6, "idPure");

static V g_heff_2esyntax_2epresyntax_2eidNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eidNames_st;
static V g_heff_2esyntax_2epresyntax_2eidNames_init(void) {
  return heff_rec_n(3, shape_bind__pure__giveBack, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eidNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2eidNames_str1), NTAG(TAG_True)});
}
V g_heff_2esyntax_2epresyntax_2eidNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eidNames_st)) return g_heff_2esyntax_2epresyntax_2eidNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eidNames_val, &g_heff_2esyntax_2epresyntax_2eidNames_st, g_heff_2esyntax_2epresyntax_2eidNames_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eendOf_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2eendOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eendOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eendOf(V v_cx_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EndValue: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), heff_dup(v_sp_241)});
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eendOf_str0)}), heff_dup(v_sp_241)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
    return (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), v_sp_241, heff_get_n(v_cx_240, 4, 6), v_t_247));
  }
  case TAG_EndJump: {
    V v_j_248 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24EndJump = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    return (g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(v_ru_24x3_242_24EndJump, v_cx_240, v_sp_241, v_j_248));
  }
  case TAG_EndGive: {
    V v_vars_249 = heff_field(v_x3_242, 0);
    V v_d_2410 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EndGive = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2411 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_d_2410);
    V v_v_2412 = (g_heff_2esyntax_2epresyntax_2epackE(heff_dup(v_sp_241), v_vars_249));
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24EndGive, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), heff_dup(v_sp_241)});
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2412, NTAG(TAG_Nil)});
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2415));
    return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_2411, v_t_2416));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eendOf(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1014015919x2013990442_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_247;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_247 = NTAG(TAG_True);
      } else {
        v_x_247 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_246)));
      }
      V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243});
      return ((HeffT2){{v_x_247, v_t_248}});
    }
    case TAG_StmtLet: {
      V v_p_249 = heff_field(v_x31_242, 0);
      V v_e_2410 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2411;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2411 = NTAG(TAG_True);
      } else {
        v_x_2411 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2410)));
      }
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_249, v_e_2410}), v_sp_243});
      return ((HeffT2){{v_x_2411, v_t_2412}});
    }
    case TAG_StmtExpr: {
      V v_e_2413 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      V v_x_2414;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2414 = NTAG(TAG_True);
      } else {
        v_x_2414 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2413)));
      }
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_2413}), v_sp_243});
      return ((HeffT2){{v_x_2414, v_t_2415}});
    }
    case TAG_StmtLetMut: {
      V v_x_2416 = heff_field(v_x31_242, 0);
      V v_xsp_2417 = heff_field(v_x31_242, 1);
      V v_e_2418 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_2419;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2419 = NTAG(TAG_True);
      } else {
        v_x_2419 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2418)));
      }
      V v_t_2420 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_x_2416, v_xsp_2417, v_e_2418}), v_sp_243});
      return ((HeffT2){{v_x_2419, v_t_2420}});
    }
    case TAG_StmtLetElse: {
      V v_p_2421 = heff_field(v_x31_242, 0);
      V v_e_2422 = heff_field(v_x31_242, 1);
      V v_ss_2423 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_2424;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2424 = NTAG(TAG_True);
      } else {
        v_x_2424 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2422)));
      }
      HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_x_2424, v_ss_2423));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_y_2429 = v_field_2427;
        V v_t_2430 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_p_2421, v_e_2422, v_y_2429}), v_sp_243});
        return ((HeffT2){{v_x_2428, v_t_2430}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str0, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str2, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2econdT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2econdT(V v_t_240, V v_cx_241, V v_sp_242, V v_s_243, V v_arms_244, V v_rest_245, V v_end_246) {
top: ;
  switch (heff_tag_of(v_rest_245)) {
  case TAG_Nil: {
    V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
    HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_247}), NTAG(TAG_Nil), v_s_243));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_y_2412 = v_field_2410;
      V v_alts_2413 = (g_list_2emap_24s2067738717x455808399(v_t_240, heff_dup(v_cx_241), v_end_246, v_arms_244));
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2412, v_alts_2413}), v_sp_242});
      return ({ V a_0 = v_cx_241; V a_1 = v_x_2411; V a_2 = v_t_2414; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
    }
  }
  case TAG_Cons: {
    V v_x1_2417 = (g_list_2ekeepIf_24s1674319799x1081446864(heff_dup(v_arms_244)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_x1_2417, 0);
      V v_x12_2419 = heff_field(v_x1_2417, 1);
      V v_ru_24x1_2417_24Cons = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
      switch (heff_tag_of(v_x12_2419)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a_2418)) {
        case TAG_MkPair: {
          V v_p_2420 = heff_field(v_a_2418, 0);
          V v_ss_2421 = heff_field(v_a_2418, 1);
          heff_take_n(v_a_2418, 3ULL, 2);
          V v_x1_2422 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x1_2417_24Cons, v_p_2420));
          switch (heff_tag_of(v_x1_2422)) {
          case TAG_Nil: {
            v_t_2427 = ({ V a_0 = v_ss_2421; V r_ = (g_list_2eall_24s568190696x1372373514(a_0)); heff_drop(v_ss_2421); r_; });
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x1_2422, 0ULL, 2);
            heff_drop(v_ss_2421);
            v_t_2427 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_2422);
          }
          break;
        }
        default: heff_nomatch(v_a_2418);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x12_2419, 0ULL, 2);
        heff_drop(v_a_2418);
        heff_drop_cell(v_ru_24x1_2417_24Cons, 2);
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_2419);
      }
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      V v_t_2428 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2428}), NTAG(TAG_Nil), v_s_243));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        V v_y_2433 = v_field_2431;
        V v_alts_2434 = (g_list_2emap_24s1520235531x215612111(v_t_240, heff_dup(v_cx_241), v_rest_245, v_end_246, v_arms_244));
        V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2433, v_alts_2434}), v_sp_242});
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2432; V a_2 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2432); r_; });
      }
    } else {
      heff_drop(v_t_2427);
      V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 2, 3);
      V v_t_2437;
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_t_2436);
        v_t_2437 = (g_heff_2esyntax_2epresyntax_2earmsGive(v_arms_244));
      } else {
        heff_drop(v_t_2436);
        v_t_2437 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        V v_t_2438 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2438}), NTAG(TAG_Nil), v_s_243));
        {
          V v_field_2440 = v_t_2439.f[0];
          V v_field_2441 = v_t_2439.f[1];
          V v_x_2442 = v_field_2440;
          V v_y_2443 = v_field_2441;
          V v_t_2444 = heff_tag_n(TAG_EndGive, 2, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), heff_dup(heff_rfield(v_cx_241, 4))});
          V v_alts_2445 = (g_list_2emap_24s2067738717x455808399(heff_dup(v_t_240), heff_dup(v_cx_241), v_t_2444, v_arms_244));
          V v_t_2446 = (g_heff_2esyntax_2epresyntax_2epackTy(heff_dup(v_sp_242), heff_dup(heff_rfield(v_cx_241, 1))));
          V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2443, v_alts_2445}), heff_dup(v_sp_242)});
          V v_t_2450;
          switch (heff_tag_of(v_t_2446)) {
          case TAG_At: {
            V v_s_2449 = heff_dup(heff_field(v_t_2446, 1));
            v_t_2450 = v_s_2449;
            break;
          }
          default: heff_nomatch(v_t_2446);
          }
          V v_t_2451 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2450, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2447, v_t_2446}), v_t_2451});
          V v_t_2453 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_245, v_end_246}));
          V v_t_2454 = (g_heff_2esyntax_2epresyntax_2egiveBackLet(v_sp_242, heff_dup(heff_rfield(v_cx_241, 1)), v_t_2452, v_t_2453));
          return ({ V a_0 = v_cx_241; V a_1 = v_x_2442; V a_2 = v_t_2454; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2442); r_; });
        }
      } else {
        heff_drop(v_t_2437);
        V v_t_2455 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2456 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2455}), NTAG(TAG_Nil), v_s_243));
        {
          V v_field_2457 = v_t_2456.f[0];
          V v_field_2458 = v_t_2456.f[1];
          V v_x_2459 = v_field_2457;
          V v_y_2460 = v_field_2458;
          V v_t_2461 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
          V v_t_2462 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str1), v_t_2461));
          V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2462}), heff_dup(v_sp_242)});
          V v_t_2464 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2463, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
          V v_alts_2465 = (g_list_2emap_24s2067738717x455808399(heff_dup(v_t_240), heff_dup(v_cx_241), heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2464}), v_arms_244));
          V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2460, v_alts_2465}), heff_dup(v_sp_242)});
          V v_t_2467 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
          V v_t_2468 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_str3), v_t_2467));
          V v_t_2469 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          V v_t_2470 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_245, v_end_246}));
          V v_t_2471 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2468, heff_dup(v_sp_242), v_t_2469, v_t_2470));
          V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
          V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2466, v_t_2472}), v_sp_242});
          return ({ V a_0 = v_cx_241; V a_1 = v_x_2459; V a_2 = v_t_2473; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2459); r_; });
        }
      }
    }
  }
  default: return heff_nomatch(v_rest_245);
  }
}
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econdT(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str0, 8, "returned");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str2, 4, "Left");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str3, 8, "returned");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str5, 4, "Left");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str6, 5, "Right");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_str7, 5, "Right");
Clo g_heff_2esyntax_2epresyntax_2eafterArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eafterArms_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2eafterArms(V v_t_240, V v_cx_241, V v_sp_242, V v_x4_243, V v_rest_244, V v_end_245) {
top: ;
  if ((heff_dup(v_x4_243) == NTAG(TAG_True))) {
    V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str1), v_t_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
    V v_ps_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str2)}), heff_dup(v_sp_242)});
    V v_x1_2411 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2410, v_ps_249));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_At: {
      V v_s_2413 = heff_field(v_x1_2411, 1);
      heff_take_n(v_x1_2411, 2ULL, 2);
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_x1_2411);
    }
    V v_t_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2414, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2416 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str4), v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2417}), heff_dup(v_sp_242)});
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2ereturnOf(heff_dup(v_cx_241), heff_dup(v_sp_242), v_t_2418));
    V v_e_2420 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), heff_dup(v_sp_242), heff_dup(heff_rfield(v_cx_241, 4)), v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str5), heff_dup(v_sp_242), v_ps_249}), heff_dup(v_t_2415)});
    V v_t_2424;
    switch (heff_tag_of(v_e_2420)) {
    case TAG_At: {
      V v_s_2423 = heff_dup(heff_field(v_e_2420, 1));
      v_t_2424 = v_s_2423;
      break;
    }
    default: heff_nomatch(v_e_2420);
    }
    V v_t_2425 = ({ V rv_1 = heff_get_n(v_t_2424, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2415, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2421, v_e_2420}), v_t_2425});
    V v_t_2427 = (g_heff_2esyntax_2epresyntax_2epackPat(heff_dup(v_sp_242), heff_dup(heff_rfield(v_cx_241, 1))));
    V v_ps_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str6)}), heff_dup(v_sp_242)});
    V v_x1_2430 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2429, v_ps_2428));
    V v_t_2433;
    switch (heff_tag_of(v_x1_2430)) {
    case TAG_At: {
      V v_s_2432 = heff_field(v_x1_2430, 1);
      heff_take_n(v_x1_2430, 2ULL, 2);
      v_t_2433 = v_s_2432;
      break;
    }
    default: heff_nomatch(v_x1_2430);
    }
    V v_t_2434 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2433, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_e_2435 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_rest_244, v_end_245}));
    V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_str7), v_sp_242, v_ps_2428}), heff_dup(v_t_2434)});
    V v_t_2439;
    switch (heff_tag_of(v_e_2435)) {
    case TAG_At: {
      V v_s_2438 = heff_dup(heff_field(v_e_2435, 1));
      v_t_2439 = v_s_2438;
      break;
    }
    default: heff_nomatch(v_e_2435);
    }
    V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2436, v_e_2435}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2442});
  } else {
    V v_p_2443 = (g_heff_2esyntax_2epresyntax_2epackPat(v_sp_242, heff_dup(heff_rfield(v_cx_241, 1))));
    V v_e_2444 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_rest_244, v_end_245}));
    V v_t_2447;
    switch (heff_tag_of(v_p_2443)) {
    case TAG_At: {
      V v_s_2446 = heff_dup(heff_field(v_p_2443, 1));
      v_t_2447 = v_s_2446;
      break;
    }
    default: heff_nomatch(v_p_2443);
    }
    V v_t_2450;
    switch (heff_tag_of(v_e_2444)) {
    case TAG_At: {
      V v_s_2449 = heff_dup(heff_field(v_e_2444, 1));
      v_t_2450 = v_s_2449;
      break;
    }
    default: heff_nomatch(v_e_2444);
    }
    V v_t_2451 = ({ V rv_1 = heff_get_n(v_t_2450, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2447, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2443, v_e_2444}), v_t_2451});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
  }
}
V g_heff_2esyntax_2epresyntax_2eafterArms_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2eafterArms(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_str0, 11, "bytesConcat");
V g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V v_r_240, V v_segs_241, V v_sp_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_clo), 1, (V[]){v_r_240}));
    V v_m_248 = heff_rec_n(2, shape_part__run, (V[]){v_t_244, ((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0_clo)});
    V v_xs_249 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_248, v_segs_241, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2410, heff_dup(v_sp_242)));
    V v_args_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_str0)}), heff_dup(v_sp_242)});
    V v_t_2414 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2412));
    V v_f_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_242});
    return ((HeffT1){{v_f_2415}});
  }
  case TAG_Just: {
    V v_s_2416 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_segs_241);
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Just, TAG_IBytes, 1, (V[]){v_s_2416}), v_sp_242});
    return ((HeffT1){{v_t_2417}});
  }
  default: return ((HeffT1){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_sp_246 = args[1];
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_247}), v_sp_246});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_249 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}