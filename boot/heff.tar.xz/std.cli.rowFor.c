// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2erowFor_2enextGo_240(V, V, V, V, V, V);
V g_std_2ecli_2erowFor_2enextGo_240_entry(V self, V *a);
extern Clo g_std_2ecli_2erowFor_2enextGo_240_clo;
V g_std_2ecli_2erowFor_2enextGo_240_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2erowFor_2enextGo_240_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2erowFor_2enextGo_240_24dps_clo;
Clo g_std_2ecli_2erowFor_2enextGo_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erowFor_2enextGo_240_entry, 6, 0};

V g_std_2ecli_2erowFor_2enextGo_240(V v_a_240, V v_c_241, V v_x2_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x2_242, 0);
    V v_ups_247 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_t_2410 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_u_2411 = (g_std_2ecli_2erowFor_2enextGo_240_24dps(v_a_240, v_c_241, v_ups_247, v_up_246, v_t_2410, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_249)));
    heff_drop(v_u_2411);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2ecli_2erowFor_2enextGo_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erowFor_2enextGo_240(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2erowFor_2enextGo_240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erowFor_2enextGo_240_24dps_entry, 7, 0};

V g_std_2ecli_2erowFor_2enextGo_240_24dps(V v_a_240, V v_c_241, V v_x2_242, V v_diag_243, V v_left_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_up_247 = heff_field(v_x2_242, 0);
    V v_ups_248 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_249 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V v_t_2412 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V t_0 = v_a_240;
    V t_1 = v_c_241;
    V t_2 = v_ups_248;
    V t_3 = v_up_247;
    V t_4 = v_t_2412;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2410;
    v_a_240 = t_0;
    v_c_241 = t_1;
    v_x2_242 = t_2;
    v_diag_243 = t_3;
    v_left_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2ecli_2erowFor_2enextGo_240_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erowFor_2enextGo_240_24dps(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}