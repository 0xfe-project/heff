// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_EQ 8989
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_Flagged 28540
#define TAG_GT 9054
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Kept 49931
#define TAG_LT 9209
#define TAG_LamName 56383
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_Often 32846
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Picked 5619
#define TAG_Pinned 8573
#define TAG_Positional 16703
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_Typed 36072
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_big 307066
#define LBL_body 9524841
#define LBL_defines 1776893014
#define LBL_e 319
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_input 301716452
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_pinned 958995203
#define LBL_place 308106529
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_version 583465758
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
V g_heff_2ecompile_2edefun_2eaddLabel(V, V, V);
V g_heff_2ecompile_2edefun_2eaddLabel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eaddLabel_clo;
V g_heff_2ecompile_2edefun_2egroupOf(V, V, V, V);
V g_heff_2ecompile_2edefun_2egroupOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egroupOf_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2efuse_2eproducerOf_24cpr(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_list_2eall_24s44244667x1445755514(V, V);
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a);
extern Clo g_list_2eall_24s44244667x1445755514_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
V g_list_2eany_24s2020157007x2085425027(V, V);
V g_list_2eany_24s2020157007x2085425027_entry(V self, V *a);
extern Clo g_list_2eany_24s2020157007x2085425027_clo;
V g_list_2eany_24s225693436x2092061921(V);
V g_list_2eany_24s225693436x2092061921_entry(V self, V *a);
extern Clo g_list_2eany_24s225693436x2092061921_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s398044887x377101364(V, V, V);
V g_list_2eany_24s398044887x377101364_entry(V self, V *a);
extern Clo g_list_2eany_24s398044887x377101364_clo;
V g_list_2eascending(V, V, V, V);
V g_list_2eascending_entry(V self, V *a);
extern Clo g_list_2eascending_clo;
V g_list_2eascending_24s1644543939x2049175771(V, V, V);
V g_list_2eascending_24s1644543939x2049175771_entry(V self, V *a);
extern Clo g_list_2eascending_24s1644543939x2049175771_clo;
V g_list_2edescending_24s374719826x79573307(V, V, V, V, V);
V g_list_2edescending_24s374719826x79573307_entry(V self, V *a);
extern Clo g_list_2edescending_24s374719826x79573307_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24f2005293661x823011722(V, V, V);
V g_list_2efoldl_24f2005293661x823011722_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2005293661x823011722_clo;
V g_list_2efoldl_24s1272156913x1766532544(V, V);
V g_list_2efoldl_24s1272156913x1766532544_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1272156913x1766532544_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1527809396x70961516(V, V);
V g_list_2efoldl_24s1527809396x70961516_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1527809396x70961516_clo;
V g_list_2efoldl_24s1530765264x1072548396(V, V);
V g_list_2efoldl_24s1530765264x1072548396_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530765264x1072548396_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s1722219619x1576677028(V, V);
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722219619x1576677028_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s327126808x177501924(V, V);
V g_list_2efoldl_24s327126808x177501924_entry(V self, V *a);
extern Clo g_list_2efoldl_24s327126808x177501924_clo;
V g_list_2efoldl_24s42602063x979600769(V, V);
V g_list_2efoldl_24s42602063x979600769_entry(V self, V *a);
extern Clo g_list_2efoldl_24s42602063x979600769_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s537755658x300885499(V, V);
V g_list_2efoldl_24s537755658x300885499_entry(V self, V *a);
extern Clo g_list_2efoldl_24s537755658x300885499_clo;
V g_list_2efoldl_24s594483157x1279518362(V, V, V);
V g_list_2efoldl_24s594483157x1279518362_entry(V self, V *a);
extern Clo g_list_2efoldl_24s594483157x1279518362_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1111636858x612918583_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_24dps_clo;
V g_list_2ekeepIf_24s1166238673x178798903_24dps(V, V, V);
V g_list_2ekeepIf_24s1166238673x178798903_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_24dps_clo;
V g_list_2ekeepIf_24s1405544077x1281126723(V, V);
V g_list_2ekeepIf_24s1405544077x1281126723_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1405544077x1281126723_clo;
V g_list_2ekeepIf_24s1405544077x1281126723_24dps(V, V, V);
V g_list_2ekeepIf_24s1405544077x1281126723_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1405544077x1281126723_24dps_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s1441124185x871809048_24dps(V, V, V);
V g_list_2ekeepIf_24s1441124185x871809048_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_24dps_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2ekeepIf_24s1552018029x993523539_24dps(V, V, V);
V g_list_2ekeepIf_24s1552018029x993523539_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_24dps_clo;
V g_list_2ekeepIf_24s185327080x101197346_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_24dps_clo;
V g_list_2ekeepIf_24s423901581x541836270_24dps(V, V, V);
V g_list_2ekeepIf_24s423901581x541836270_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_24dps_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24f1539731936x1117725130_24dps(V, V, V, V);
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_24dps_clo;
V g_list_2emap_24s1152414072x2935301(V, V);
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_clo;
V g_list_2emap_24s1152414072x2935301_24dps(V, V, V);
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_24dps_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1230649048x711093514(V, V);
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_clo;
V g_list_2emap_24s1230649048x711093514_24dps(V, V, V);
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_24dps_clo;
V g_list_2emap_24s137457135x961689574_24dps(V, V);
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_24dps_clo;
V g_list_2emap_24s1392650298x1192381411(V, V, V);
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_clo;
V g_list_2emap_24s1392650298x1192381411_24dps(V, V, V, V);
V g_list_2emap_24s1392650298x1192381411_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_24dps_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s1585362143x1323498048_24dps(V, V);
V g_list_2emap_24s1585362143x1323498048_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_24dps_clo;
V g_list_2emap_24s1691485302x273983346(V, V);
V g_list_2emap_24s1691485302x273983346_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_clo;
V g_list_2emap_24s1691485302x273983346_24dps(V, V, V);
V g_list_2emap_24s1691485302x273983346_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_24dps_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s179832492x431904054_24dps(V, V);
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_24dps_clo;
V g_list_2emap_24s1846289357x1055790465(V, V);
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_clo;
V g_list_2emap_24s1846289357x1055790465_24dps(V, V, V);
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_24dps_clo;
V g_list_2emap_24s1917875516x88484758_24dps(V, V);
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_24dps_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_list_2emap_24s2104774589x596860835_24dps(V, V);
V g_list_2emap_24s2104774589x596860835_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s244350250x1728178626_24dps(V, V);
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_24dps_clo;
V g_list_2emap_24s347605591x806617237(V);
V g_list_2emap_24s347605591x806617237_entry(V self, V *a);
extern Clo g_list_2emap_24s347605591x806617237_clo;
V g_list_2emap_24s347605591x806617237_24dps(V, V);
V g_list_2emap_24s347605591x806617237_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s347605591x806617237_24dps_clo;
V g_list_2emap_24s384717234x223264907(V, V);
V g_list_2emap_24s384717234x223264907_entry(V self, V *a);
extern Clo g_list_2emap_24s384717234x223264907_clo;
V g_list_2emap_24s384717234x223264907_24dps(V, V, V);
V g_list_2emap_24s384717234x223264907_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s384717234x223264907_24dps_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emap_24s570884835x2121220820_24dps(V, V);
V g_list_2emap_24s570884835x2121220820_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_24dps_clo;
V g_list_2emap_24s72189608x1424346484(V, V, V, V);
V g_list_2emap_24s72189608x1424346484_entry(V self, V *a);
extern Clo g_list_2emap_24s72189608x1424346484_clo;
V g_list_2emap_24s72189608x1424346484_24dps(V, V, V, V, V);
V g_list_2emap_24s72189608x1424346484_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s72189608x1424346484_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_clo;
V g_list_2epushRun_24s782281454x118641000(V, V, V);
V g_list_2epushRun_24s782281454x118641000_entry(V self, V *a);
extern Clo g_list_2epushRun_24s782281454x118641000_clo;
V g_list_2ezipWith_24s490727218x2138671_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s490727218x2138671_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s490727218x2138671_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V, V);
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2ecli_2einteractive_2eflagWord(V, V);
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagWord_clo;
V g_std_2ecli_2einteractive_2eposWords(V, V);
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposWords_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_list_2eascending_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_entry, 4, 0};

V g_list_2eascending(V v_le_240, V v_x_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    heff_drop(v_x_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_243, 0);
    V v_ys_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_x_241, heff_dup(v_y_245)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V t_0 = v_le_240;
      V t_1 = heff_dup(v_y_245);
      V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_acc_242});
      V t_3 = v_ys_246;
      v_le_240 = t_0;
      v_x_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_le_240);
      heff_drop(v_t_247);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246})});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_list_2eascending_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1173914895x100384474_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_entry, 1, 0};

V g_list_2emap_24s1173914895x100384474(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1173914895x100384474_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474(a[0]);
}
Clo g_list_2efoldl_24s1614667250x430274379_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1614667250x430274379_entry, 2, 0};

V g_list_2efoldl_24s1614667250x430274379(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1614667250x430274379(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1166238673x178798903_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1166238673x178798903_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1166238673x178798903_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_243, 0))) ? !heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_x_243, 1))) : 1)) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1166238673x178798903_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1166238673x178798903_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s225693436x2092061921_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s225693436x2092061921_entry, 1, 0};

V g_list_2eany_24s225693436x2092061921(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 2ULL, 2);
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_dup(heff_field(v_a_246, 0));
          switch (heff_tag_of(v_a_247)) {
          case TAG_EDo: {
            V v_a_249 = heff_field(v_a_247, 0);
            heff_take_n(v_a_247, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            switch (heff_tag_of(v_a_246)) {
            case TAG_At: {
              heff_take_n(v_a_246, 0ULL, 2);
              v_t_2416 = v_a_249;
              break;
            }
            default: heff_nomatch(v_a_246);
            }
            break;
          }
          default: {
            heff_drop(v_a_247);
            V v_t_2414;
            switch (heff_tag_of(v_a_246)) {
            case TAG_At: {
              V v_a_2413 = heff_dup(heff_field(v_a_246, 1));
              v_t_2414 = v_a_2413;
              break;
            }
            default: heff_nomatch(v_a_246);
            }
            V v_t_2415 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_a_246}), v_t_2414});
            v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2416));
    switch (heff_tag_of(v_a_2417)) {
    case TAG_Nil: {
      heff_drop(v_xs_242);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_a_2417, 0);
      heff_take_n(v_a_2417, 1ULL, 2);
      switch (heff_tag_of(v_a_2418)) {
      case TAG_At: {
        V v_a_2420 = heff_field(v_a_2418, 0);
        heff_take_n(v_a_2418, 1ULL, 2);
        switch (heff_tag_of(v_a_2420)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_True);
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2420, 0ULL, 2);
          heff_drop(v_xs_242);
          return NTAG(TAG_True);
        }
        case TAG_StmtExpr: {
          V v_a_2427 = heff_field(v_a_2420, 0);
          heff_take_n(v_a_2420, 1ULL, 1);
          V v_t_2428 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_a_2427));
          if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
            heff_drop(v_xs_242);
            heff_drop(v_t_2428);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2428);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_True);
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_2420);
        }
      }
      default: return heff_nomatch(v_a_2418);
      }
    }
    default: return heff_nomatch(v_a_2417);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s225693436x2092061921_entry(V self, V *a) {
  (void)self;
  return g_list_2eany_24s225693436x2092061921(a[0]);
}
Clo g_list_2emap_24s137457135x961689574_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s137457135x961689574_24dps_entry, 2, 0};

V g_list_2emap_24s137457135x961689574_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2423;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_SetPath: {
        V v_path_247 = heff_field(v_x21_245, 0);
        V v_e_248 = heff_field(v_x21_245, 1);
        V v_ru_24x21_245_24SetPath = heff_take_reuse_n(v_x21_245, 3ULL, 2);
        HeffT3 v_t_249 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_248));
        V v_t_2422;
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_c_2413 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
            v_t_2422 = v_c_2413;
          } else {
            if ((v_tag_2410 == ((int64_t)1ULL))) {
              heff_drop(v_field_2412);
              V v_i_2414 = v_field_2411;
              V v_t_2417;
              switch (heff_tag_of(v_i_2414)) {
              case TAG_At: {
                V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
                v_t_2417 = v_s_2416;
                break;
              }
              default: heff_nomatch(v_i_2414);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
            } else {
              V v_t_2418 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              V v_t_2421;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
            }
          }
        }
        v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24SetPath, TAG_SetPath, 2, (V[]){v_path_247, v_t_2422}), v_sp_246});
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2424;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s137457135x961689574_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1729787689x465380098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_entry, 1, 0};

V g_list_2emap_24s1729787689x465380098(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1729787689x465380098_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098(a[0]);
}
Clo g_list_2emap_24s244350250x1728178626_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_entry, 1, 0};

V g_list_2emap_24s244350250x1728178626(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24MkAlt = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24a_243_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s244350250x1728178626_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s244350250x1728178626(a[0]);
}
Clo g_list_2emap_24s513201124x806973253_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_entry, 1, 0};

V g_list_2emap_24s513201124x806973253(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_243 = heff_take_field(v_x_241, 1);
    V v_start_244 = heff_take_field(v_x_241, 3);
    V v_end_245 = heff_get_n(v_x_241, 4, 9);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){v_text_243}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s513201124x806973253_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513201124x806973253(a[0]);
}
HEFF_LIT(g_list_2emap_24s1691485302x273983346_str0, 4, "#arg");
HEFF_LIT(g_list_2emap_24s1691485302x273983346_str1, 7, "#mutual");
HEFF_LIT(g_list_2emap_24s1691485302x273983346_str2, 4, "#arg");
Clo g_list_2emap_24s1691485302x273983346_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1691485302x273983346_entry, 2, 0};

V g_list_2emap_24s1691485302x273983346(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_k_244 = heff_dup(v_lit_240);
    V v_d_245 = v_x_242;
    V v_name_246 = heff_take_field(v_d_245, 0);
    V v_span_247 = heff_get_n(v_d_245, 1, 5);
    V v_t_248 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(heff_dup(v_name_246), ((V)&g_list_2emap_24s1691485302x273983346_str0)), heff_dup(v_span_247)});
    V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_246), ((V)&g_list_2emap_24s1691485302x273983346_str1))});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_244}), heff_dup(v_span_247)});
    V v_t_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_246), ((V)&g_list_2emap_24s1691485302x273983346_str2))});
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_span_247)}), NTAG(TAG_Nil)});
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_span_247)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412})));
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_248, v_t_2413}), heff_dup(v_span_247)});
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_name_246, heff_dup(v_span_247), v_t_2414}), v_span_247});
    V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1691485302x273983346_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1691485302x273983346_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1691485302x273983346(a[0], a[1]);
}
Clo g_list_2eany_24s228396297x1310020012_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s228396297x1310020012_entry, 1, 0};

V g_list_2eany_24s228396297x1310020012(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if ((heff_dup(v_x_241) == NTAG(TAG_True))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s228396297x1310020012(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s423901581x541836270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s423901581x541836270_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s423901581x541836270_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_2444 = heff_bool(!heff_strEq_c_lent(v_lit_240, v_a_245, 0));
      heff_drop(v_a_245);
      break;
    }
    case TAG_EGlobal: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ELet: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ERecord: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EProj: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ETag: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EMatch: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrim: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ECall: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EInt: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EBool: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ESet: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EValues: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFix: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_t_2444);
      V v_cell_2445 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2446 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2445));
      heff_drop(v_u_2446);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2445;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_2444);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s423901581x541836270_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s423901581x541836270_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2eall_24s44244667x1445755514_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s44244667x1445755514_entry, 2, 0};

V g_list_2eall_24s44244667x1445755514(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (!heff_strEq_c_lent(v_t_246, v_lit_240, 0)) {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s44244667x1445755514(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s398044887x377101364_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s398044887x377101364_entry, 3, 0};

V g_list_2eany_24s398044887x377101364(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_key_245 = heff_dup(v_lit_240);
    V v_n_246 = heff_dup(v_lit_241);
    V v_e_247 = heff_dup(v_x_243);
    V v_t_2447;
    switch (heff_tag_of(v_e_247)) {
    case TAG_EVar: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_247, 0ULL, 4);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      V v_k_2431 = heff_field(v_e_247, 0);
      V v_args_2432 = heff_field(v_e_247, 1);
      heff_take_n(v_e_247, 3ULL, 2);
      v_t_2447 = heff_bool((heff_strEq_c_lent(v_k_2431, v_key_245, 0) && ({ V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2432)); int c_ = heff_intEq_c_lent(v_t_2448, v_n_246, 0); heff_drop(v_t_2448); c_; })));
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      heff_drop(v_k_2431);
      heff_drop(v_args_2432);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_247);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_2447);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2447);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s398044887x377101364_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s398044887x377101364(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str10, 7, "Float64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_str11, 3, "Int");
Clo g_list_2emap_24s2090270526x1588636862_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_entry, 1, 0};

V g_list_2emap_24s2090270526x1588636862(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str1);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str2);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str3);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str4);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str5);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str6);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str7);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str8);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str9);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str10);
      break;
    }
    case TAG_RepInt: {
      v_t_244 = ((V)&g_list_2emap_24s2090270526x1588636862_str11);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2090270526x1588636862_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862(a[0]);
}
Clo g_list_2emap_24s1917875516x88484758_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917875516x88484758_24dps_entry, 2, 0};

V g_list_2emap_24s1917875516x88484758_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, NTAG(TAG_RepV)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917875516x88484758_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1275727578x1654209034_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1275727578x1654209034_entry, 2, 0};

V g_list_2efoldl_24s1275727578x1654209034(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_y_245 = heff_field(v_x_242, 1);
      v_t_2420 = (g_heff_2ecompile_2erepr_2eunite(v_z_240, heff_dup(v_x_244), heff_dup(v_y_245)));
      break;
    }
    case TAG_Boxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_BoxedWord: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Element: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Binds: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Pinned: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Kept: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Often: {
      v_t_2420 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1275727578x1654209034(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1674844076x2137676876_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1674844076x2137676876_entry, 4, 0};

V g_list_2efoldl_24s1674844076x2137676876(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_parent_246 = heff_dup(v_lit_240);
    V v_stats_247 = heff_dup(v_lit_241);
    V v_m_248 = v_z_242;
    V v_e_249 = heff_dup(v_x_244);
    V v_t_2441;
    switch (heff_tag_of(v_e_249)) {
    case TAG_Merge: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Boxed: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_BoxedWord: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Element: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Unboxed: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Literal: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Wants: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Binds: {
      V v_x_2421 = heff_field(v_e_249, 0);
      V v_ru_24e_249_24Binds = heff_take_reuse_n(v_e_249, 1ULL, 1);
      V v_t_2422 = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(v_ru_24e_249_24Binds, v_parent_246, v_x_2421));
      V v_t_2423 = ({ V a_0 = v_parent_246; V a_1 = heff_dup(v_x_2421); V a_2 = v_t_2422; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_246); r_; });
      HeffT2 v_t_2424 = ({ V a_0 = v_stats_247; V a_1 = v_t_2423; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_stats_247); heff_drop(v_t_2423); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        V v_s_2428;
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_x_2427 = v_field_2426;
          v_s_2428 = v_x_2427;
        } else {
          heff_drop(v_field_2426);
          v_s_2428 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
        }
        V v_t_2429 = heff_dup(heff_rfield(v_s_2428, 6));
        V v_r_2435;
        switch (heff_tag_of(v_t_2429)) {
        case TAG_Nothing: {
          V v_t_2430 = heff_dup(heff_rfield(v_s_2428, 5));
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop_rec(v_s_2428, 8);
            heff_drop(v_t_2430);
            v_r_2435 = NTAG(TAG_RepV);
          } else {
            heff_drop(v_t_2430);
            V v_r_2431 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_2428), heff_rfield(v_s_2428, 0)));
            switch (heff_tag_of(v_r_2431)) {
            case TAG_RepV: {
              heff_drop_rec(v_s_2428, 8);
              v_r_2435 = v_r_2431;
              break;
            }
            case TAG_RepFix: {
              heff_drop_rec(v_s_2428, 8);
              v_r_2435 = v_r_2431;
              break;
            }
            case TAG_RepF64: {
              heff_drop_rec(v_s_2428, 8);
              v_r_2435 = v_r_2431;
              break;
            }
            case TAG_RepInt: {
              V v_t_2433 = heff_get_n(v_s_2428, 7, 8);
              if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                heff_drop(v_t_2433);
                v_r_2435 = NTAG(TAG_RepV);
              } else {
                heff_drop(v_t_2433);
                v_r_2435 = NTAG(TAG_RepInt);
              }
              break;
            }
            default: heff_nomatch(v_r_2431);
            }
          }
          break;
        }
        case TAG_Just: {
          V v_r_2434 = heff_field(v_t_2429, 0);
          heff_take_n(v_t_2429, 1ULL, 1);
          heff_drop_rec(v_s_2428, 8);
          v_r_2435 = v_r_2434;
          break;
        }
        default: heff_nomatch(v_t_2429);
        }
        switch (heff_tag_of(v_r_2435)) {
        case TAG_RepV: {
          heff_drop(v_x_2421);
          v_t_2441 = v_m_248;
          break;
        }
        case TAG_RepFix: {
          v_t_2441 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_x_2421, v_r_2435));
          break;
        }
        case TAG_RepF64: {
          v_t_2441 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_x_2421, v_r_2435));
          break;
        }
        case TAG_RepInt: {
          v_t_2441 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_x_2421, v_r_2435));
          break;
        }
        default: heff_nomatch(v_r_2435);
        }
      }
      break;
    }
    case TAG_Pinned: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Kept: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    case TAG_Often: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_parent_246);
      heff_drop(v_stats_247);
      v_t_2441 = v_m_248;
      break;
    }
    default: heff_nomatch(v_e_249);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2441;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s1674844076x2137676876(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s327126808x177501924_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s327126808x177501924_entry, 2, 0};

V g_list_2efoldl_24s327126808x177501924(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_body_246 = heff_take_field(v_d_245, 2);
    V v_key_247 = heff_get_n(v_d_245, 0, 3);
    V v_t_2450;
    switch (heff_tag_of(v_body_246)) {
    case TAG_EVar: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ELam: {
      V v_b_2411 = heff_field(v_body_246, 1);
      heff_take_n(v_body_246, 2ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_2411, NTAG(TAG_Nil)));
      V v_os_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1527809396x70961516(a_0, a_1)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = (g_list_2eany_24s1630057461x1822494873(v_os_2413));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_key_247);
        heff_drop(v_os_2413);
        heff_drop(v_t_2414);
        v_t_2450 = v_m_244;
      } else {
        heff_drop(v_t_2414);
        v_t_2450 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_key_247, v_os_2413));
      }
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_246, 0ULL, 4);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2450 = v_m_244;
      break;
    }
    default: heff_nomatch(v_body_246);
    }
    V t_0 = v_t_2450;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s327126808x177501924_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s327126808x177501924(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1405544077x1281126723_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1405544077x1281126723_entry, 2, 0};

V g_list_2ekeepIf_24s1405544077x1281126723(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = (g_std_2eordmap_2esize(heff_rfield(v_x_242, 1)));
    if (heff_intLt_c_lent(v_lit_240, v_a_244, 2)) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s1405544077x1281126723_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1405544077x1281126723_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1405544077x1281126723(a[0], a[1]);
}
Clo g_list_2emap_24s72189608x1424346484_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s72189608x1424346484_entry, 4, 0};

V g_list_2emap_24s72189608x1424346484(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2edefun_2egroupOf(v_lit_240, v_lit_241, v_lit_242, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s72189608x1424346484_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s72189608x1424346484_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24s72189608x1424346484(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s594483157x1279518362_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s594483157x1279518362_entry, 3, 0};

V g_list_2efoldl_24s594483157x1279518362(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2edefun_2eaddLabel(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s594483157x1279518362_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s594483157x1279518362(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s570884835x2121220820_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570884835x2121220820_24dps_entry, 2, 0};

V g_list_2emap_24s570884835x2121220820_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), v_x_242});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570884835x2121220820_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570884835x2121220820_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1530765264x1072548396_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530765264x1072548396_entry, 2, 0};

V g_list_2efoldl_24s1530765264x1072548396(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = ({ V a_0 = heff_dup(v_key_244); V a_1 = v_body_245; HeffT2 r_ = (g_heff_2ecompile_2efuse_2econsumerOf_24cpr(a_0, a_1)); heff_drop(v_body_245); r_; });
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_key_244, v_a_249));
      } else {
        heff_drop(v_key_244);
        heff_drop(v_field_248);
        v_t_2410 = v_z_240;
      }
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530765264x1072548396_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530765264x1072548396(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s42602063x979600769_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s42602063x979600769_entry, 2, 0};

V g_list_2efoldl_24s42602063x979600769(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = ({ V a_0 = heff_dup(v_key_244); V a_1 = v_body_245; HeffT2 r_ = (g_heff_2ecompile_2efuse_2eproducerOf_24cpr(a_0, a_1)); heff_drop(v_body_245); r_; });
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_key_244, v_a_249));
      } else {
        heff_drop(v_key_244);
        heff_drop(v_field_248);
        v_t_2410 = v_z_240;
      }
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s42602063x979600769_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s42602063x979600769(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1585362143x1323498048_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1585362143x1323498048_24dps_entry, 2, 0};

V g_list_2emap_24s1585362143x1323498048_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24PartVal = heff_take_reuse_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24x_242_24PartVal, TAG_Just, 1, (V[]){v_a_246});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_a_244, 0ULL, 4);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2429 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2430 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
    heff_drop(v_u_2431);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2430;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1585362143x1323498048_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1585362143x1323498048_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s185327080x101197346_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s185327080x101197346_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s185327080x101197346_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s185327080x101197346_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s185327080x101197346_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s152505078x225062837_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_entry, 1, 0};

V g_list_2emap_24s152505078x225062837(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s152505078x225062837_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s152505078x225062837(a[0]);
}
Clo g_list_2ezipWith_24s490727218x2138671_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s490727218x2138671_24dps_entry, 6, 0};

V g_list_2ezipWith_24s490727218x2138671_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_dup(heff_field(v_x_246, 0));
        v_t_2412 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, heff_dup(v_lit_240)), heff_intShow(v_y_248));
      V v_t_2416;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2415 = heff_field(v_x_246, 1);
        heff_take_n(v_x_246, 2ULL, 2);
        v_t_2416 = v_a_2415;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2413, heff_dup(v_lit_241)), v_t_2416);
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2417, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2419 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s490727218x2138671_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s490727218x2138671_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2ekeepIf_24s1552018029x993523539_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1552018029x993523539_entry, 2, 0};

V g_list_2ekeepIf_24s1552018029x993523539(V v_box_24lit_240, V v_x2_241) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((v_lit_240 < heff_unbox_word(heff_strLength_lent(v_x_242, 0)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1552018029x993523539_24dps(heff_box_word(v_lit_240), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      int64_t t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1552018029x993523539(a[0], a[1]);
}
Clo g_list_2efoldl_24s292588827x1477362994_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s292588827x1477362994_entry, 2, 0};

V g_list_2efoldl_24s292588827x1477362994(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 0)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s292588827x1477362994(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1272156913x1766532544_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1272156913x1766532544_entry, 2, 0};

V g_list_2efoldl_24s1272156913x1766532544(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s537755658x300885499(v_z_240, heff_rfield(v_x_242, 2)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1272156913x1766532544_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1272156913x1766532544(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1846289357x1055790465_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1846289357x1055790465_entry, 2, 0};

V g_list_2emap_24s1846289357x1055790465(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1846289357x1055790465_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1846289357x1055790465(a[0], a[1]);
}
Clo g_list_2emap_24s1230649048x711093514_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230649048x711093514_entry, 2, 0};

V g_list_2emap_24s1230649048x711093514(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1230649048x711093514_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230649048x711093514(a[0], a[1]);
}
Clo g_list_2emap_24s347605591x806617237_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s347605591x806617237_entry, 1, 0};

V g_list_2emap_24s347605591x806617237(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s347605591x806617237_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s347605591x806617237_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s347605591x806617237(a[0]);
}

HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2edescending_24s374719826x79573307_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s374719826x79573307_entry, 5, 0};

V g_list_2edescending_24s374719826x79573307(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_244, 0);
    V v_ys_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_247 = heff_strCompare_lent(v_x_242, v_y_245, 1);
    if ((heff_intLt_c_lent(v_a_247, v_lit_240, 0) || heff_intEq_c_lent(v_a_247, v_lit_241, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_a_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246})});
    } else {
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_245);
      V t_3 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_acc_243});
      V t_4 = v_ys_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2edescending_24s374719826x79573307_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s374719826x79573307(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1910320727x339655847_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1910320727x339655847_entry, 2, 0};

V g_list_2efoldl_24s1910320727x339655847(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_z_240, 0)))) {
      V v_t_244 = (g_heff_2ebuild_2eproject_2enewer(heff_rfield(v_x_242, 1), heff_rfield(v_z_240, 1)));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop_rec(v_z_240, 3);
        heff_drop(v_t_244);
        v_t_245 = heff_dup(v_x_242);
      } else {
        heff_drop(v_t_244);
        v_t_245 = v_z_240;
      }
    } else {
      v_t_245 = v_z_240;
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1910320727x339655847(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s384717234x223264907_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s384717234x223264907_entry, 2, 0};

V g_list_2emap_24s384717234x223264907(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_span_245 = heff_get_n(v_x_242, 1, 2);
    V v_a_246 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_name_244)}), NTAG(TAG_Nothing)});
    V v_a_247 = v_name_244;
    V v_a_248 = v_span_245;
    V v_a_249 = heff_take_field(v_a_248, 0);
    V v_a_2410 = heff_intSub(heff_dup(heff_rfield(v_a_248, 1)), heff_strLength_lent(v_a_247, 0));
    V v_t_2411;
    if (heff_intLe_c_lent(v_a_249, v_a_2410, 0)) {
      heff_drop(v_a_249);
      v_t_2411 = v_a_2410;
    } else {
      heff_drop(v_a_2410);
      v_t_2411 = v_a_249;
    }
    V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_a_248, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_a_246, v_a_247, v_t_2412}), heff_hole()});
    V v_u_2414 = (g_list_2emap_24s384717234x223264907_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s384717234x223264907_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s384717234x223264907(a[0], a[1]);
}
Clo g_list_2emap_24s1392650298x1192381411_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1392650298x1192381411_entry, 3, 0};

V g_list_2emap_24s1392650298x1192381411(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    heff_drop_rec(v_lit_241, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_245 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))));
    V v_t_246 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_241, 1)), heff_dup(heff_rfield(v_lit_241, 3)), v_x_243, v_a_245});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1392650298x1192381411_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1392650298x1192381411(a[0], a[1], a[2]);
}
Clo g_list_2epushRun_24s782281454x118641000_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s782281454x118641000_entry, 3, 0};

V g_list_2epushRun_24s782281454x118641000(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_2413;
        switch (heff_tag_of(v_below_246)) {
        case TAG_Nil: {
          v_t_2413 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(NTAG(TAG_True), v_below_246, v_run_241));
          break;
        }
        case TAG_Cons: {
          V v_a_247 = heff_dup(heff_field(v_below_246, 0));
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_a_247, 5);
            v_t_2413 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(NTAG(TAG_True), v_below_246, v_run_241));
            break;
          }
          case TAG_Cons: {
            V v_b_249 = heff_dup(heff_field(v_run_241, 0));
            V v_t_2411 = heff_get_n(heff_get_n(v_a_247, 2, 5), 0, 2);
            V v_t_2412 = heff_get_n(heff_get_n(v_b_249, 2, 5), 0, 2);
            if (heff_intLe_c(v_t_2411, v_t_2412)) {
              v_t_2413 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(NTAG(TAG_True), v_below_246, v_run_241));
            } else {
              v_t_2413 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(NTAG(TAG_False), v_run_241, v_below_246));
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          break;
        }
        default: heff_nomatch(v_below_246);
        }
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_2413;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_2414 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_2414});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s782281454x118641000_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s782281454x118641000(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1152414072x2935301_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_str3, 4, "(alt");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_str4, 1, ")");
Clo g_list_2emap_24s1152414072x2935301_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1152414072x2935301_entry, 2, 0};

V g_list_2emap_24s1152414072x2935301(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2418;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_MkAlt: {
        V v_p_248 = heff_field(v_x21_246, 0);
        V v_e_249 = heff_field(v_x21_246, 1);
        heff_take_n(v_x21_246, 3ULL, 2);
        V v_t_2410 = (g_heff_2esyntax_2eformat_2epatKey(v_p_248));
        V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_249}));
        V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        V v_parts_2413 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
        V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1152414072x2935301_str0), v_parts_2413));
        V v_t_2417;
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Nil: {
          v_t_2417 = ((V)&g_list_2emap_24s1152414072x2935301_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_xs_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          v_t_2417 = ({ V a_0 = ((V)&g_list_2emap_24s1152414072x2935301_str2); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2414);
        }
        v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1152414072x2935301_str3), v_t_2417), ((V)&g_list_2emap_24s1152414072x2935301_str4));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1152414072x2935301_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1152414072x2935301(a[0], a[1]);
}
Clo g_list_2emap_24s179832492x431904054_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s179832492x431904054_24dps_entry, 2, 0};

V g_list_2emap_24s179832492x431904054_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s179832492x431904054_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2020157007x2085425027_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2020157007x2085425027_entry, 2, 0};

V g_list_2eany_24s2020157007x2085425027(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410;
    if (heff_intLe_c_lent(v_t_246, v_lit_240, 1)) {
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_242, 1);
        v_t_2413 = heff_dup(v_a_248);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2410 = heff_intLe_lent(v_lit_240, v_t_2413, 2);
    } else {
      v_t_2410 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2020157007x2085425027_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s2020157007x2085425027(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eascending_24s1644543939x2049175771_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1644543939x2049175771_entry, 3, 0};

V g_list_2eascending_24s1644543939x2049175771(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 4);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_a_246 = ({ V b_0 = heff_get_n(v_x_240, 1, 4); V a_1 = heff_rfield(v_y_244, 1); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_a_246)) {
    case TAG_LT: {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_EQ: {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    case TAG_GT: {
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_ys_245})});
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s1644543939x2049175771_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s1644543939x2049175771(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2104774589x596860835_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2104774589x596860835_entry, 1, 0};

V g_list_2emap_24s2104774589x596860835(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2104774589x596860835_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2104774589x596860835(a[0]);
}
Clo g_list_2ekeepIf_24s1441124185x871809048_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1441124185x871809048_entry, 2, 0};

V g_list_2ekeepIf_24s1441124185x871809048(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_lit_240, 2)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1441124185x871809048_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 8);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1441124185x871809048(a[0], a[1]);
}
HEFF_LIT(g_list_2eany_24s1497517957x114012878_str0, 16, "refactor.rewrite");
Clo g_list_2eany_24s1497517957x114012878_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1497517957x114012878_entry, 1, 0};

V g_list_2eany_24s1497517957x114012878(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JInt: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JString: {
      V v_k_246 = heff_field(v_x_241, 0);
      V v_t_247 = heff_strSlice(((V)&g_list_2eany_24s1497517957x114012878_str0), MK_INT(0LL), heff_strLength_lent(v_k_246, 0));
      if (heff_strEq_c_lent(v_t_247, v_k_246, 1)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    case TAG_JArray: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JObject: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1497517957x114012878(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1111636858x612918583_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1111636858x612918583_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s1111636858x612918583_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1111636858x612918583_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1111636858x612918583_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s1722219619x1576677028_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24s1722219619x1576677028_str1, 0, "");
Clo g_list_2efoldl_24s1722219619x1576677028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1722219619x1576677028_entry, 2, 0};

V g_list_2efoldl_24s1722219619x1576677028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_part_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_input_245 = heff_dup(heff_rfield(v_x_242, 1));
    V v_x1_246 = v_part_244;
    V v_x2_247 = v_input_245;
    V v_t_2438;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Positional: {
      V v_p_248 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Typed: {
        V v_t_249 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        V v_t_2410 = heff_strOfRunes(heff_get_n(v_t_249, 0, 2));
        v_t_2438 = ({ V b_0 = heff_get_n(v_p_248, 1, 3); V a_1 = v_t_2410; V r_ = (g_std_2ecli_2einteractive_2eposWords(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2410); r_; });
        break;
      }
      case TAG_Picked: {
        V v_c_2411 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        V v_at_2412 = heff_take_field(v_c_2411, 1);
        V v_options_2413 = heff_get_n(v_c_2411, 0, 2);
        HeffT3 v_t_2414 = ({ V a_0 = v_at_2412; V a_1 = v_options_2413; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_options_2413); r_; });
        V v_t_2420;
        {
          V v_field_2416 = v_t_2414.f[1];
          V v_field_2417 = v_t_2414.f[2];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_x_2418 = v_field_2416;
            V v_x12_2419 = v_field_2417;
            heff_drop(v_x12_2419);
            v_t_2420 = v_x_2418;
          } else {
            heff_drop(v_field_2416);
            heff_drop(v_field_2417);
            v_t_2420 = ((V)&g_list_2efoldl_24s1722219619x1576677028_str0);
          }
        }
        v_t_2438 = ({ V b_0 = heff_get_n(v_p_248, 1, 3); V a_1 = v_t_2420; V r_ = (g_std_2ecli_2einteractive_2eposWords(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      break;
    }
    case TAG_Flagged: {
      V v_f_2421 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Typed: {
        V v_t_2422 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        V v_s_2423 = heff_strOfRunes(heff_get_n(v_t_2422, 0, 2));
        V v_t_2424 = (g_prelude_2eskipSpaces(v_s_2423, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_s_2423, 0)) - ((int64_t)1ULL));
        V v_t_2426 = (g_prelude_2eskipSpaces(v_s_2423, heff_box_word(v_t_2425), MK_INT(-1LL)));
        V v_t_2427 = heff_strSlice(v_s_2423, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
        v_t_2438 = (g_std_2ecli_2einteractive_2eflagWord(v_f_2421, v_t_2427));
        break;
      }
      case TAG_Picked: {
        V v_c_2428 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        V v_at_2429 = heff_take_field(v_c_2428, 1);
        V v_options_2430 = heff_get_n(v_c_2428, 0, 2);
        HeffT3 v_t_2431 = ({ V a_0 = v_at_2429; V a_1 = v_options_2430; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_options_2430); r_; });
        V v_t_2437;
        {
          V v_field_2433 = v_t_2431.f[1];
          V v_field_2434 = v_t_2431.f[2];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          if ((v_tag_2432 == ((int64_t)0ULL))) {
            V v_x_2435 = v_field_2433;
            V v_x12_2436 = v_field_2434;
            heff_drop(v_x12_2436);
            v_t_2437 = v_x_2435;
          } else {
            heff_drop(v_field_2433);
            heff_drop(v_field_2434);
            v_t_2437 = ((V)&g_list_2efoldl_24s1722219619x1576677028_str1);
          }
        }
        v_t_2438 = (g_std_2ecli_2einteractive_2eflagWord(v_f_2421, v_t_2437));
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2438, v_z_240));
    V t_0 = v_t_2439;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1722219619x1576677028(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f2005293661x823011722_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2005293661x823011722_entry, 3, 0};

V g_list_2efoldl_24f2005293661x823011722(V v_z_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_243)}));
    V t_0 = heff_intAdd(v_z_240, v_x_245);
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2005293661x823011722_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2005293661x823011722(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1539731936x1117725130_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1539731936x1117725130_entry, 3, 0};

V g_list_2emap_24f1539731936x1117725130(V v_lit_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c_lent(v_n_242, v_i_241, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_244 = (g_list_2emap_24f1539731936x1117725130_24dps(v_lit_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_n_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1539731936x1117725130(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2efoldl_24f1677743806x2032371213_str0, 1, "_");
Clo g_list_2efoldl_24f1677743806x2032371213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1677743806x2032371213_entry, 2, 0};

V g_list_2efoldl_24f1677743806x2032371213(V v_z_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_list_2efoldl_24f1677743806x2032371213_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_244);
        return v_z_240;
      } else {
        V v_x_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_245, v_z_240}), NTAG(TAG_Nil));
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2410);
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2414); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2415);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatBinary: {
      V v_segs_2419 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2419));
      V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2420); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2421);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatRecord: {
      V v_fs_2423 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2423));
      V v_t_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2424); r_; });
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2425);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_z_240;
    }
    case TAG_PatAs: {
      V v_x_2427 = heff_field(v_p1_242, 0);
      V v_sp_2428 = heff_field(v_p1_242, 1);
      V v_q_2429 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_x_2430 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2427, v_sp_2428, NTAG(TAG_False)});
      V t_0 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2430, v_z_240});
      V t_1 = v_q_2429;
      v_z_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1677743806x2032371213(a[0], a[1]);
}