// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_Among 19600
#define TAG_BadShape 33347
#define TAG_Dirs 41877
#define TAG_DirsOnly 64835
#define TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218 36790
#define TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139 11561
#define TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997 9522
#define TAG_Extra 49222
#define TAG_Files 59123
#define TAG_FilesBy 64286
#define TAG_Help 25956
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_None 17785
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35657
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define TAG_Words 20643
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_complete 145693389
#define LBL_count 296209705
#define LBL_doc 309170
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_pos__flags[] = {LBL_pos, LBL_flags};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s193691892x499187556(V, V, V, V);
V g_list_2eany_24s193691892x499187556_entry(V self, V *a);
extern Clo g_list_2eany_24s193691892x499187556_clo;
V g_list_2eany_24s70593242x1575694473(V, V);
V g_list_2eany_24s70593242x1575694473_entry(V self, V *a);
extern Clo g_list_2eany_24s70593242x1575694473_clo;
V g_list_2eany_24s811553642x27402676(V, V, V, V, V, V, V);
V g_list_2eany_24s811553642x27402676_entry(V self, V *a);
extern Clo g_list_2eany_24s811553642x27402676_clo;
V g_list_2efilter_24f1490579794x1456232270(V, V, V, V, V, V, V);
V g_list_2efilter_24f1490579794x1456232270_entry(V self, V *a);
extern Clo g_list_2efilter_24f1490579794x1456232270_clo;
V g_list_2efilter_24f419751885x381357165(V, V);
V g_list_2efilter_24f419751885x381357165_entry(V self, V *a);
extern Clo g_list_2efilter_24f419751885x381357165_clo;
V g_list_2efilter_24s1200694983x1257685262(V, V);
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_clo;
V g_list_2efilter_24s2009824277x1398398543(V, V, V);
V g_list_2efilter_24s2009824277x1398398543_entry(V self, V *a);
extern Clo g_list_2efilter_24s2009824277x1398398543_clo;
V g_list_2efilter_24s2016771181x401513202(V, V, V);
V g_list_2efilter_24s2016771181x401513202_entry(V self, V *a);
extern Clo g_list_2efilter_24s2016771181x401513202_clo;
V g_list_2efilter_24s561186959x2071570661(V, V, V);
V g_list_2efilter_24s561186959x2071570661_entry(V self, V *a);
extern Clo g_list_2efilter_24s561186959x2071570661_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1839921325x671097810_24cpr(V, V);
HeffT2 g_list_2efind_24s575827429x1292946038_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f134831722x1788320834(V, V, V);
V g_list_2emap_24f134831722x1788320834_entry(V self, V *a);
extern Clo g_list_2emap_24f134831722x1788320834_clo;
V g_list_2emap_24f1690623035x874154762(V, V, V, V, V, V);
V g_list_2emap_24f1690623035x874154762_entry(V self, V *a);
extern Clo g_list_2emap_24f1690623035x874154762_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1412546768x2004463577(V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2ebashScript(V);
V g_std_2ecli_2ebashScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ebashScript_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecommandsText(V, V);
V g_std_2ecli_2ecommandsText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecommandsText_clo;
V g_std_2ecli_2ecompleteAt(V, V, V);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
HeffT2 g_std_2ecli_2edupOf_24cpr(V);
V g_std_2ecli_2efishScript(V);
V g_std_2ecli_2efishScript_entry(V self, V *a);
extern Clo g_std_2ecli_2efishScript_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
HeffT2 g_std_2ecli_2eflagProblem_24cpr(V, V);
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf_24dps(V, V);
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_24dps_clo;
HeffT2 g_std_2ecli_2elastOnly_24cpr(V);
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
HeffT2 g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(V, V, V, V, V, V, V, V, V);
HeffT2 g_std_2ecli_2elongNamed_24cpr(V, V);
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2enextGo(V, V, V, V, V, V);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2enextGo_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_24dps_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eorList_24acc(V, V);
V g_std_2ecli_2eorList_24acc_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_24acc_clo;
HeffT2 g_std_2ecli_2eoutcomeOf_24cpr(V, V, V);
HeffT2 g_std_2ecli_2eparse_24cpr(V, V);
HeffT2 g_std_2ecli_2eposAt_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
HeffT2 g_std_2ecli_2eshapeProblem_24cpr(V);
V g_std_2ecli_2eshortWhere(V, V, V);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;
V g_std_2ecli_2eshortWhere_24scalars(V, V, V, V, V, V);
V g_std_2ecli_2eshortWhere_24scalars_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_24scalars_clo;
V g_std_2ecli_2ewhereGo(V, V, V, V);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;

HeffT2 g_std_2ecli_2elastS_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
    }
    case TAG_Cons: {
      heff_drop(v_x_241);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2ecli_2elookupL_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elookupL_entry, 2, 0};

V g_std_2ecli_2elookupL(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_240, v_x_244, 0)) {
        return heff_dup(v_vs_245);
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elookupL_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2elookupL(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_std_2ecli_2elastOnly_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_rec(v_p_241, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_t_245 = heff_take_field(v_p_241, 1);
      switch (heff_tag_of(v_t_245)) {
      case TAG_One: {
        heff_drop_rec(v_p_241, 3);
        V t_0 = v_x12_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Optional: {
        heff_drop_tag(v_x12_242, 2);
        V v_f_246 = heff_get_n(v_p_241, 0, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
      }
      case TAG_Many: {
        heff_drop_tag(v_x12_242, 2);
        V v_f_247 = heff_get_n(v_p_241, 0, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
      }
      case TAG_Some: {
        heff_drop_tag(v_x12_242, 2);
        V v_f_248 = heff_get_n(v_p_241, 0, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      }
      case TAG_Rest: {
        heff_drop_tag(v_x12_242, 2);
        V v_f_249 = heff_get_n(v_p_241, 0, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str1, 6, " twice");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str3, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str4, 6, " twice");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str5, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str6, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str7, 26, "a short name is one letter");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str8, 4, "help");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str9, 1, "h");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str10, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str11, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str12, 69, "--help and -h are the library's; a long name is not empty, has no `=`");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str13, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str14, 23, "a switch takes no value");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str15, 54, " takes more or less than one word, and is not the last");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str16, 41, " is every word, so no flag could be given");

HeffT2 g_std_2ecli_2eshapeProblem_24cpr(V v_sh_240) {
top: ;
  V v_t_241 = (g_list_2emap_24s1854779998x1713580578(heff_dup(heff_rfield(v_sh_240, 0))));
  HeffT2 v_t_242 = (g_std_2ecli_2edupOf_24cpr(v_t_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      V v_x_246 = v_field_244;
      V v_f_247 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_24cpr_str0), heff_strAppend(v_x_246, ((V)&g_std_2ecli_2eshapeProblem_24cpr_str1)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
    } else {
      heff_drop(v_field_244);
      V v_t_248 = ({ V b_0 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str2); V a_1 = heff_dup(heff_rfield(v_sh_240, 0)); V r_ = (g_list_2efilter_24f419751885x381357165(b_0, a_1)); heff_drop(b_0); r_; });
      HeffT2 v_t_249 = (g_std_2ecli_2edupOf_24cpr(v_t_248));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop_rec(v_sh_240, 2);
          V v_x_2413 = v_field_2411;
          V v_f_2414 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_24cpr_str3), heff_strAppend(v_x_2413, ((V)&g_std_2ecli_2eshapeProblem_24cpr_str4)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
        } else {
          heff_drop(v_field_2411);
          V v_t_2415 = ({ V a_0 = MK_INT(1LL); V b_1 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str5); V b_2 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str6); V a_3 = heff_rfield(v_sh_240, 0); V r_ = (g_list_2eany_24s193691892x499187556(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); r_; });
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop_rec(v_sh_240, 2);
            heff_drop(v_t_2415);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str7)}});
          } else {
            heff_drop(v_t_2415);
            V v_t_2416 = ({ V b_0 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str8); V b_1 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str9); V b_2 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str10); V b_3 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str11); V b_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V a_6 = heff_rfield(v_sh_240, 0); V r_ = (g_list_2eany_24s811553642x27402676(b_0, b_1, b_2, b_3, b_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop_rec(v_sh_240, 2);
              heff_drop(v_t_2416);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str12)}});
            } else {
              heff_drop(v_t_2416);
              V v_t_2417 = ({ V b_0 = ((V)&g_std_2ecli_2eshapeProblem_24cpr_str13); V a_1 = heff_rfield(v_sh_240, 0); V r_ = (g_list_2eany_24s70593242x1575694473(b_0, a_1)); heff_drop(b_0); r_; });
              if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                heff_drop_rec(v_sh_240, 2);
                heff_drop(v_t_2417);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str14)}});
              } else {
                heff_drop(v_t_2417);
                HeffT2 v_t_2418 = (g_std_2ecli_2elastOnly_24cpr(heff_dup(heff_rfield(v_sh_240, 1))));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    heff_drop_rec(v_sh_240, 2);
                    V v_m_2422 = v_field_2420;
                    V v_f_2423 = heff_strAppend(v_m_2422, ((V)&g_std_2ecli_2eshapeProblem_24cpr_str15));
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
                  } else {
                    heff_drop(v_field_2420);
                    V v_t_2424 = heff_take_field(v_sh_240, 1);
                    switch (heff_tag_of(v_t_2424)) {
                    case TAG_Nil: {
                      heff_drop_rec(v_sh_240, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_p_2425 = heff_field(v_t_2424, 0);
                      heff_take_n(v_t_2424, 1ULL, 2);
                      V v_t_2427 = heff_take_field(v_p_2425, 1);
                      switch (heff_tag_of(v_t_2427)) {
                      case TAG_One: {
                        heff_drop_rec(v_sh_240, 2);
                        heff_drop_rec(v_p_2425, 3);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Optional: {
                        heff_drop_rec(v_sh_240, 2);
                        heff_drop_rec(v_p_2425, 3);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Many: {
                        heff_drop_rec(v_sh_240, 2);
                        heff_drop_rec(v_p_2425, 3);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Some: {
                        heff_drop_rec(v_sh_240, 2);
                        heff_drop_rec(v_p_2425, 3);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Rest: {
                        V v_t_2428 = heff_get_n(v_sh_240, 0, 2);
                        switch (heff_tag_of(v_t_2428)) {
                        case TAG_Nil: {
                          heff_drop_rec(v_p_2425, 3);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Cons: {
                          heff_take_n(v_t_2428, 0ULL, 2);
                          V v_f_2431 = heff_strAppend(heff_get_n(v_p_2425, 0, 3), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str16));
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_t_2428)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_t_2427)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_t_2424)}});
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_std_2ecli_2elongNamed_24cpr(V v_sh_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2efind_24s1839921325x671097810_24cpr(v_x_241, heff_dup(heff_rfield(v_sh_240, 0))));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      V v_f_246 = v_field_244;
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_246}});
    } else {
      heff_drop(v_field_244);
      V v_fs_247 = ({ V b_0 = MK_INT(0LL); V a_1 = v_x_241; V a_2 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efilter_24s561186959x2071570661(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_fs_247)) {
      case TAG_Nil: {
        V v_f_248 = (g_list_2emap_24s1854779998x1713580578(v_fs_247));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      }
      case TAG_Cons: {
        V v_fs1_249 = heff_dup(heff_field(v_fs_247, 0));
        V v_fs2_2410 = heff_dup(heff_field(v_fs_247, 1));
        switch (heff_tag_of(v_fs2_2410)) {
        case TAG_Nil: {
          heff_drop_tag(v_fs_247, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_fs1_249}});
        }
        case TAG_Cons: {
          heff_take_n(v_fs2_2410, 0ULL, 2);
          heff_drop(v_fs1_249);
          V v_f_2413 = (g_list_2emap_24s1854779998x1713580578(v_fs_247));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
        }
        default: return ((HeffT2){{heff_nomatch(v_fs2_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_fs_247)}});
      }
    }
  }
}
Clo g_std_2ecli_2enextGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_24dps_entry, 7, 0};

V g_std_2ecli_2enextGo_24dps(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_up_247 = heff_field(v_x3_242, 0);
    V v_ups_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V v_t_2412 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V t_0 = v_a_240;
    V t_1 = v_c_241;
    V t_2 = v_ups_248;
    V t_3 = v_up_247;
    V t_4 = v_t_2412;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2410;
    v_a_240 = t_0;
    v_c_241 = t_1;
    v_x3_242 = t_2;
    v_diag_243 = t_3;
    v_left_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2enextGo_24dps(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args);
Clo g_std_2ecli_2edistance_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edistance_entry, 2, 0};

V g_std_2ecli_2edistance(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_strLength_lent(v_a_240, 0), MK_INT(1LL));
  V v_t_243 = (g_list_2erange(MK_INT(0LL), v_t_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_std_2ecli_2edistance_lam0, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_b_241)}); V a_1 = v_t_243; V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2414; V r_ = (g_std_2ecli_2elastOr(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_std_2ecli_2edistance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2edistance(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_j_246 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_b_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_xs_248 = heff_dup(heff_field(v_row_245, 1));
    v_t_249 = v_xs_248;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2412;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_row_245, 0);
    heff_take_n(v_row_245, 1ULL, 2);
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2413 = ({ V a_0 = v_a_240; V a_1 = heff_strByteAt_lent(v_b_241, v_j_246, 1); V a_2 = v_t_249; V a_3 = v_t_2412; V a_4 = heff_intAdd(heff_dup(v_j_246), MK_INT(1LL)); V a_5 = MK_INT(1LL); V r_ = (g_std_2ecli_2enextGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_a_240); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_j_246, MK_INT(1LL)), v_t_2413});
}
Clo g_std_2ecli_2erestIndex_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erestIndex_entry, 2, 0};

V g_std_2ecli_2erestIndex(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_x11_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Rest: {
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2erestIndex_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erestIndex(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str0, 1, "=");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str3, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str4, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str5, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str6, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str7, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str8, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str9, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str10, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str11, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str12, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str13, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str14, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str15, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str16, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str17, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str18, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str19, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str20, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str21, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str22, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str23, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str24, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str25, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str26, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str27, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str28, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str29, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str30, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str31, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str32, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str33, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str34, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str35, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str36, 6, "--help");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str37, 2, "-h");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str38, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str39, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str40, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str41, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str42, 0, "");

HeffT2 g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(V v_tag_240, V v_at_241, V v_ws_242, V v_body_243, V v_at_244, V v_ws_245, V v_cl_246, V v_at_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218: {
    top_TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218: ;
    heff_drop_rec(v_at_247, 5);
    heff_drop(v_x3_248);
    V v_j_249 = heff_strFind_lent(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str0), v_body_243, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_j_249);
      HeffT2 v_t_2411 = (g_std_2ecli_2elongNamed_24cpr(heff_dup(heff_rfield(v_at_241, 0)), v_body_243));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_ws_242);
          heff_drop_rec(v_at_244, 5);
          heff_drop(v_ws_245);
          heff_drop(v_cl_246);
          V v_cands_2415 = v_field_2413;
          V v_f_2419;
          switch (heff_tag_of(v_cands_2415)) {
          case TAG_Nil: {
            V v_t_2416 = (g_std_2ecli_2enearest(heff_get_n(v_at_241, 0, 5), v_body_243));
            v_f_2419 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str1), v_body_243), v_t_2416});
            break;
          }
          case TAG_Cons: {
            heff_drop_rec(v_at_241, 5);
            v_f_2419 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str2), v_body_243), v_cands_2415});
            break;
          }
          default: heff_nomatch(v_cands_2415);
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
        } else {
          heff_drop(v_body_243);
          V v_f_2420 = v_field_2413;
          if (heff_strEq_c(heff_dup(heff_rfield(v_f_2420, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str3))) {
            V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2420, 0, 8), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str4)});
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_take_field(v_at_241, 4)});
            V v_t_2424 = ({ V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
            V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str5);
            V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str6);
            V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str7);
            V t_4 = v_at_244;
            V t_5 = v_ws_245;
            V t_6 = v_cl_246;
            V t_7 = v_t_2424;
            V t_8 = v_ws_242;
            v_tag_240 = t_0;
            v_at_241 = t_1;
            v_ws_242 = t_2;
            v_body_243 = t_3;
            v_at_244 = t_4;
            v_ws_245 = t_5;
            v_cl_246 = t_6;
            v_at_247 = t_7;
            v_x3_248 = t_8;
            goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
          } else {
            switch (heff_tag_of(v_ws_242)) {
            case TAG_Nil: {
              heff_drop_rec(v_at_241, 5);
              heff_drop_rec(v_at_244, 5);
              heff_drop(v_ws_245);
              heff_drop(v_cl_246);
              V v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str8), heff_get_n(v_f_2420, 0, 8));
              V v_f_2426 = heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2425});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
            }
            case TAG_Cons: {
              V v_v_2427 = heff_field(v_ws_242, 0);
              V v_ws2_2428 = heff_field(v_ws_242, 1);
              V v_ru_24ws_242_24Cons = heff_take_reuse_n(v_ws_242, 3ULL, 2);
              V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2420, 0, 8), v_v_2427});
              V v_t_2430 = heff_tag_at_n(v_ru_24ws_242_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_dup(heff_rfield(v_at_241, 4))});
              V v_t_2431 = ({ V rv_4 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
              V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str9);
              V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str10);
              V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str11);
              V t_4 = v_at_244;
              V t_5 = v_ws_245;
              V t_6 = v_cl_246;
              V t_7 = v_t_2431;
              V t_8 = v_ws2_2428;
              v_tag_240 = t_0;
              v_at_241 = t_1;
              v_ws_242 = t_2;
              v_body_243 = t_3;
              v_at_244 = t_4;
              v_ws_245 = t_5;
              v_cl_246 = t_6;
              v_at_247 = t_7;
              v_x3_248 = t_8;
              goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
            }
            default: return ((HeffT2){{heff_nomatch(v_ws_242)}});
            }
          }
        }
      }
    } else {
      HeffT2 v_t_2432 = ({ V a_0 = heff_dup(heff_rfield(v_at_241, 0)); V b_1 = heff_strSlice_lent(v_body_243, MK_INT(0LL), v_j_249, 2); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop(v_ws_242);
          heff_drop_rec(v_at_244, 5);
          heff_drop(v_ws_245);
          heff_drop(v_cl_246);
          V v_cands_2436 = v_field_2434;
          V v_x_2437 = heff_strSlice(v_body_243, MK_INT(0LL), v_j_249);
          V v_f_2441;
          switch (heff_tag_of(v_cands_2436)) {
          case TAG_Nil: {
            V v_t_2438 = (g_std_2ecli_2enearest(heff_get_n(v_at_241, 0, 5), v_x_2437));
            v_f_2441 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str12), v_x_2437), v_t_2438});
            break;
          }
          case TAG_Cons: {
            heff_drop_rec(v_at_241, 5);
            v_f_2441 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str13), v_x_2437), v_cands_2436});
            break;
          }
          default: heff_nomatch(v_cands_2436);
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2441}});
        } else {
          V v_f_2442 = v_field_2434;
          if (heff_strEq_c(heff_dup(heff_rfield(v_f_2442, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str14))) {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop(v_cl_246);
            heff_drop(v_j_249);
            V v_t_2444 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str15), heff_get_n(v_f_2442, 0, 8));
            V v_f_2445 = heff_tag_n(TAG_SwitchValue, 1, (V[]){v_t_2444});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2445}});
          } else {
            V v_t_2446 = heff_strSlice(heff_dup(v_body_243), heff_intAdd(v_j_249, MK_INT(1LL)), heff_strLength(v_body_243));
            V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2442, 0, 8), v_t_2446});
            V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_take_field(v_at_241, 4)});
            V v_t_2449 = ({ V rv_4 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
            V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str16);
            V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str17);
            V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str18);
            V t_4 = v_at_244;
            V t_5 = v_ws_245;
            V t_6 = v_cl_246;
            V t_7 = v_t_2449;
            V t_8 = v_ws_242;
            v_tag_240 = t_0;
            v_at_241 = t_1;
            v_ws_242 = t_2;
            v_body_243 = t_3;
            v_at_244 = t_4;
            v_ws_245 = t_5;
            v_cl_246 = t_6;
            v_at_247 = t_7;
            v_x3_248 = t_8;
            goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
          }
        }
      }
    }
  }
  case TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139: {
    top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139: ;
    if (heff_strEq_c_lent(v_cl_246, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str19), 2)) {
      heff_drop(v_cl_246);
      heff_drop_rec(v_at_247, 5);
      heff_drop(v_x3_248);
      V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
      V t_1 = v_at_241;
      V t_2 = v_ws_242;
      V t_3 = v_body_243;
      V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str20);
      V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str21);
      V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str22);
      V t_7 = v_at_244;
      V t_8 = v_ws_245;
      v_tag_240 = t_0;
      v_at_241 = t_1;
      v_ws_242 = t_2;
      v_body_243 = t_3;
      v_at_244 = t_4;
      v_ws_245 = t_5;
      v_cl_246 = t_6;
      v_at_247 = t_7;
      v_x3_248 = t_8;
      goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
    } else {
      V v_x_2451 = heff_strSlice_lent(v_cl_246, MK_INT(0LL), MK_INT(1LL), 6);
      if (heff_strEq_c_lent(v_x_2451, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str23), 2)) {
        heff_drop_rec(v_at_241, 5);
        heff_drop(v_ws_242);
        heff_drop(v_body_243);
        heff_drop_rec(v_at_244, 5);
        heff_drop(v_ws_245);
        heff_drop_rec(v_at_247, 5);
        heff_drop(v_x3_248);
        heff_drop(v_x_2451);
        V v_t_2453 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str24), heff_strSlice(v_cl_246, MK_INT(0LL), MK_INT(1LL)));
        V v_f_2454 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_2453, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2454}});
      } else {
        V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_at_244, 0)), 0, 2);
        HeffT2 v_t_2456 = ({ V a_0 = v_x_2451; V a_1 = v_t_2455; HeffT2 r_ = (g_list_2efind_24s575827429x1292946038_24cpr(a_0, a_1)); heff_drop(v_x_2451); r_; });
        {
          V v_field_2458 = v_t_2456.f[1];
          int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
          if ((v_tag_2457 == ((int64_t)0ULL))) {
            V v_f_2460 = v_field_2458;
            if (heff_strEq_c(heff_dup(heff_rfield(v_f_2460, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str25))) {
              V v_t_2462 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2460, 0, 8), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str26)});
              V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, heff_take_field(v_at_244, 4)});
              V v_t_2464 = ({ V rv_4 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              V v_t_2465 = heff_strSlice(heff_dup(v_cl_246), MK_INT(1LL), heff_strLength(v_cl_246));
              V t_0 = NTAG(TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139);
              V t_1 = v_at_241;
              V t_2 = v_ws_242;
              V t_3 = v_body_243;
              V t_4 = v_t_2464;
              V t_5 = v_ws_245;
              V t_6 = v_t_2465;
              V t_7 = v_at_247;
              V t_8 = v_x3_248;
              v_tag_240 = t_0;
              v_at_241 = t_1;
              v_ws_242 = t_2;
              v_body_243 = t_3;
              v_at_244 = t_4;
              v_ws_245 = t_5;
              v_cl_246 = t_6;
              v_at_247 = t_7;
              v_x3_248 = t_8;
              goto top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139;
            } else {
              heff_drop_rec(v_at_247, 5);
              heff_drop(v_x3_248);
              if ((((int64_t)1ULL) < heff_unbox_word(heff_strLength_lent(v_cl_246, 0)))) {
                V v_t_2467 = heff_strSlice(heff_dup(v_cl_246), MK_INT(1LL), heff_strLength(v_cl_246));
                V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2460, 0, 8), v_t_2467});
                V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, heff_take_field(v_at_244, 4)});
                V v_t_2470 = ({ V rv_4 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                V t_1 = v_at_241;
                V t_2 = v_ws_242;
                V t_3 = v_body_243;
                V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str27);
                V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str28);
                V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str29);
                V t_7 = v_t_2470;
                V t_8 = v_ws_245;
                v_tag_240 = t_0;
                v_at_241 = t_1;
                v_ws_242 = t_2;
                v_body_243 = t_3;
                v_at_244 = t_4;
                v_ws_245 = t_5;
                v_cl_246 = t_6;
                v_at_247 = t_7;
                v_x3_248 = t_8;
                goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
              } else {
                heff_drop(v_cl_246);
                switch (heff_tag_of(v_ws_245)) {
                case TAG_Nil: {
                  heff_drop_rec(v_at_241, 5);
                  heff_drop(v_ws_242);
                  heff_drop(v_body_243);
                  heff_drop_rec(v_at_244, 5);
                  V v_t_2471 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str30), heff_get_n(v_f_2460, 1, 8));
                  V v_f_2472 = heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2471});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2472}});
                }
                case TAG_Cons: {
                  V v_v_2473 = heff_field(v_ws_245, 0);
                  V v_ws2_2474 = heff_field(v_ws_245, 1);
                  V v_ru_24ws_245_24Cons = heff_take_reuse_n(v_ws_245, 3ULL, 2);
                  V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2460, 0, 8), v_v_2473});
                  V v_t_2476 = heff_tag_at_n(v_ru_24ws_245_24Cons, TAG_Cons, 2, (V[]){v_t_2475, heff_dup(heff_rfield(v_at_244, 4))});
                  V v_t_2477 = ({ V rv_4 = v_t_2476; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                  V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                  V t_1 = v_at_241;
                  V t_2 = v_ws_242;
                  V t_3 = v_body_243;
                  V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str31);
                  V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str32);
                  V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str33);
                  V t_7 = v_t_2477;
                  V t_8 = v_ws2_2474;
                  v_tag_240 = t_0;
                  v_at_241 = t_1;
                  v_ws_242 = t_2;
                  v_body_243 = t_3;
                  v_at_244 = t_4;
                  v_ws_245 = t_5;
                  v_cl_246 = t_6;
                  v_at_247 = t_7;
                  v_x3_248 = t_8;
                  goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
                }
                default: return ((HeffT2){{heff_nomatch(v_ws_245)}});
                }
              }
            }
          } else {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop_rec(v_at_247, 5);
            heff_drop(v_x3_248);
            heff_drop(v_field_2458);
            V v_t_2478 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str34), heff_strSlice(v_cl_246, MK_INT(0LL), MK_INT(1LL)));
            V v_f_2479 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_2478, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2479}});
          }
        }
      }
    }
  }
  case TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997: {
    top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997: ;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop_rec(v_at_241, 5);
      heff_drop(v_ws_242);
      heff_drop(v_body_243);
      heff_drop_rec(v_at_244, 5);
      heff_drop(v_ws_245);
      heff_drop(v_cl_246);
      V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_at_247, 3)));
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_at_247, 4, 5)));
      V v_f_2482 = heff_rec_n(2, shape_pos__flags, (V[]){v_t_2480, v_t_2481});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2482}});
    }
    case TAG_Cons: {
      V v_w_2483 = heff_field(v_x3_248, 0);
      V v_ws_2484 = heff_field(v_x3_248, 1);
      V v_ru_24x3_248_24Cons = heff_take_reuse_n(v_x3_248, 3ULL, 2);
      V v_t_2485 = heff_dup(heff_rfield(v_at_247, 2));
      V v_t_2488 = heff_bool(((heff_dup(v_t_2485) == NTAG(TAG_True)) ? (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_at_247, 1))) && ({ V v_x_2487 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_at_247, 3))); int c_ = heff_intLe_c(heff_dup(heff_rfield(v_at_247, 1)), heff_dup(v_x_2487)); heff_drop(v_x_2487); c_; })) : 1));
      heff_drop(v_t_2485);
      if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
        heff_drop(v_t_2488);
        V v_t_2489 = heff_tag_at_n(v_ru_24x3_248_24Cons, TAG_Cons, 2, (V[]){v_w_2483, heff_dup(heff_rfield(v_at_247, 3))});
        V v_t_2490 = ({ V rv_2 = NTAG(TAG_False); V rv_3 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_at_247, 19ULL, 5, shape_sh__ra__on__ps__fs, 783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
        V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
        V t_1 = v_at_241;
        V t_2 = v_ws_242;
        V t_3 = v_body_243;
        V t_4 = v_at_244;
        V t_5 = v_ws_245;
        V t_6 = v_cl_246;
        V t_7 = v_t_2490;
        V t_8 = v_ws_2484;
        v_tag_240 = t_0;
        v_at_241 = t_1;
        v_ws_242 = t_2;
        v_body_243 = t_3;
        v_at_244 = t_4;
        v_ws_245 = t_5;
        v_cl_246 = t_6;
        v_at_247 = t_7;
        v_x3_248 = t_8;
        goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
      } else {
        heff_drop(v_t_2488);
        if (heff_strEq_c_lent(v_w_2483, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str35), 2)) {
          heff_drop(v_w_2483);
          heff_drop_cell(v_ru_24x3_248_24Cons, 2);
          V v_t_2492 = ({ V rv_2 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_at_247, 27ULL, 5, shape_sh__ra__on__ps__fs, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
          V t_1 = v_at_241;
          V t_2 = v_ws_242;
          V t_3 = v_body_243;
          V t_4 = v_at_244;
          V t_5 = v_ws_245;
          V t_6 = v_cl_246;
          V t_7 = v_t_2492;
          V t_8 = v_ws_2484;
          v_tag_240 = t_0;
          v_at_241 = t_1;
          v_ws_242 = t_2;
          v_body_243 = t_3;
          v_at_244 = t_4;
          v_ws_245 = t_5;
          v_cl_246 = t_6;
          v_at_247 = t_7;
          v_x3_248 = t_8;
          goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
        } else {
          if (heff_strEq_c_lent(v_w_2483, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str36), 2)) {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop(v_cl_246);
            heff_drop_rec(v_at_247, 5);
            heff_drop(v_w_2483);
            heff_drop(v_ws_2484);
            heff_drop_cell(v_ru_24x3_248_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Help)}});
          } else {
            if (heff_strEq_c_lent(v_w_2483, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str37), 2)) {
              heff_drop_rec(v_at_241, 5);
              heff_drop(v_ws_242);
              heff_drop(v_body_243);
              heff_drop_rec(v_at_244, 5);
              heff_drop(v_ws_245);
              heff_drop(v_cl_246);
              heff_drop_rec(v_at_247, 5);
              heff_drop(v_w_2483);
              heff_drop(v_ws_2484);
              heff_drop_cell(v_ru_24x3_248_24Cons, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Help)}});
            } else {
              if (heff_strEq_c(heff_strSlice_lent(v_w_2483, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str38))) {
                heff_drop_rec(v_at_241, 5);
                heff_drop(v_ws_242);
                heff_drop(v_body_243);
                heff_drop_cell(v_ru_24x3_248_24Cons, 2);
                V v_t_2496 = heff_strSlice(heff_dup(v_w_2483), MK_INT(2LL), heff_strLength(v_w_2483));
                V t_0 = NTAG(TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218);
                V t_1 = v_at_247;
                V t_2 = v_ws_2484;
                V t_3 = v_t_2496;
                V t_4 = v_at_244;
                V t_5 = v_ws_245;
                V t_6 = v_cl_246;
                V t_7 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str39);
                V t_8 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str40);
                v_tag_240 = t_0;
                v_at_241 = t_1;
                v_ws_242 = t_2;
                v_body_243 = t_3;
                v_at_244 = t_4;
                v_ws_245 = t_5;
                v_cl_246 = t_6;
                v_at_247 = t_7;
                v_x3_248 = t_8;
                goto top_TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218;
              } else {
                if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_w_2483, 0)))) {
                  if ((heff_unbox_word(heff_strByteAt_lent(v_w_2483, MK_INT(0LL), 2)) == ((int64_t)45ULL))) {
                    heff_drop_rec(v_at_244, 5);
                    heff_drop(v_ws_245);
                    heff_drop(v_cl_246);
                    heff_drop_cell(v_ru_24x3_248_24Cons, 2);
                    V v_t_2499 = heff_strSlice(heff_dup(v_w_2483), MK_INT(1LL), heff_strLength(v_w_2483));
                    V t_0 = NTAG(TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139);
                    V t_1 = v_at_241;
                    V t_2 = v_ws_242;
                    V t_3 = v_body_243;
                    V t_4 = v_at_247;
                    V t_5 = v_ws_2484;
                    V t_6 = v_t_2499;
                    V t_7 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str41);
                    V t_8 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str42);
                    v_tag_240 = t_0;
                    v_at_241 = t_1;
                    v_ws_242 = t_2;
                    v_body_243 = t_3;
                    v_at_244 = t_4;
                    v_ws_245 = t_5;
                    v_cl_246 = t_6;
                    v_at_247 = t_7;
                    v_x3_248 = t_8;
                    goto top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139;
                  } else {
                    V v_t_24100 = heff_tag_at_n(v_ru_24x3_248_24Cons, TAG_Cons, 2, (V[]){v_w_2483, heff_dup(heff_rfield(v_at_247, 3))});
                    V v_t_24101 = ({ V rv_3 = v_t_24100; V rr_ = heff_rec_reuse_nf(v_at_247, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                    V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                    V t_1 = v_at_241;
                    V t_2 = v_ws_242;
                    V t_3 = v_body_243;
                    V t_4 = v_at_244;
                    V t_5 = v_ws_245;
                    V t_6 = v_cl_246;
                    V t_7 = v_t_24101;
                    V t_8 = v_ws_2484;
                    v_tag_240 = t_0;
                    v_at_241 = t_1;
                    v_ws_242 = t_2;
                    v_body_243 = t_3;
                    v_at_244 = t_4;
                    v_ws_245 = t_5;
                    v_cl_246 = t_6;
                    v_at_247 = t_7;
                    v_x3_248 = t_8;
                    goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
                  }
                } else {
                  V v_t_24102 = heff_tag_at_n(v_ru_24x3_248_24Cons, TAG_Cons, 2, (V[]){v_w_2483, heff_dup(heff_rfield(v_at_247, 3))});
                  V v_t_24103 = ({ V rv_3 = v_t_24102; V rr_ = heff_rec_reuse_nf(v_at_247, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                  V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                  V t_1 = v_at_241;
                  V t_2 = v_ws_242;
                  V t_3 = v_body_243;
                  V t_4 = v_at_244;
                  V t_5 = v_ws_245;
                  V t_6 = v_cl_246;
                  V t_7 = v_t_24103;
                  V t_8 = v_ws_2484;
                  v_tag_240 = t_0;
                  v_at_241 = t_1;
                  v_ws_242 = t_2;
                  v_body_243 = t_3;
                  v_at_244 = t_4;
                  v_ws_245 = t_5;
                  v_cl_246 = t_6;
                  v_at_247 = t_7;
                  v_x3_248 = t_8;
                  goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
                }
              }
            }
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str3, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str5, 2, "--");
V g_std_2ecli_2eflagProblem_24cpr_lam0(V self, V *args);
V g_std_2ecli_2eflagProblem_24cpr_lam1(V self, V *args);

HeffT2 g_std_2ecli_2eflagProblem_24cpr(V v_fs_240, V v_f_241) {
top: ;
  V v_t_242 = (g_list_2efilter_24s1200694983x1257685262(heff_rfield(v_f_241, 0), heff_dup(v_fs_240)));
  V v_x1_243 = (g_list_2emap_24s1173914895x100384474(v_t_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_dup(heff_rfield(v_f_241, 6));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_fs_240);
      heff_drop(v_t_244);
      V v_t_246;
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_241, 2)), ((V)&g_std_2ecli_2eflagProblem_24cpr_str0))) {
        v_t_246 = ((V)&g_std_2ecli_2eflagProblem_24cpr_str1);
      } else {
        v_t_246 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str2), heff_dup(heff_rfield(v_f_241, 2)));
      }
      V v_t_247 = heff_strAppend(heff_get_n(v_f_241, 0, 8), v_t_246);
      V v_f_248 = heff_tag_n(TAG_MissingFlag, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str3), v_t_247)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    } else {
      heff_drop(v_t_244);
      V v_t_249 = (g_list_2efilter_24s1200694983x1257685262(heff_rfield(v_f_241, 0), v_fs_240));
      V v_t_2410 = (g_list_2emap_24s1173914895x100384474(v_t_249));
      HeffT2 v_t_2417 = (g_list_2efind_24cpr(heff_clo_n(g_std_2ecli_2eflagProblem_24cpr_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), v_t_2410));
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_v_2421 = v_field_2419;
          V v_t_2422 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str4), heff_take_field(v_f_241, 0));
          V v_f_2423 = heff_tag_n(TAG_NotIn, 3, (V[]){v_t_2422, v_v_2421, heff_get_n(v_f_241, 4, 8)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
        } else {
          heff_drop_rec(v_f_241, 8);
          heff_drop(v_field_2419);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
  case TAG_Cons: {
    heff_take_n(v_x1_243, 0ULL, 2);
    V v_t_2426 = (g_list_2efilter_24s1200694983x1257685262(heff_rfield(v_f_241, 0), v_fs_240));
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474(v_t_2426));
    HeffT2 v_t_2434 = (g_list_2efind_24cpr(heff_clo_n(g_std_2ecli_2eflagProblem_24cpr_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), v_t_2427));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_v_2438 = v_field_2436;
        V v_t_2439 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str5), heff_take_field(v_f_241, 0));
        V v_f_2440 = heff_tag_n(TAG_NotIn, 3, (V[]){v_t_2439, v_v_2438, heff_get_n(v_f_241, 4, 8)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2440}});
      } else {
        heff_drop_rec(v_f_241, 8);
        heff_drop(v_field_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_243)}});
  }
}
V g_std_2ecli_2eflagProblem_24cpr_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_dup(heff_rfield(v_f_241, 4));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    heff_drop(v_v_2411);
    heff_drop_rec(v_f_241, 8);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2412, 0ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_v_2411}));
    V v_x1_2416 = ({ V a_0 = v_t_2415; V b_1 = heff_get_n(v_f_241, 4, 8); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2416) == NTAG(TAG_True)));
    heff_drop(v_x1_2416);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_std_2ecli_2eflagProblem_24cpr_lam1(V self, V *args) {
  V v_v_2428 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_dup(heff_rfield(v_f_241, 4));
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nil: {
    heff_drop(v_v_2428);
    heff_drop_rec(v_f_241, 8);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2429, 0ULL, 2);
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_v_2428}));
    V v_x1_2433 = ({ V a_0 = v_t_2432; V b_1 = heff_get_n(v_f_241, 4, 8); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
    heff_drop(v_x1_2433);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_t_2429);
  }
}
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str2, 0, "");
Clo g_std_2ecli_2eshortWhere_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_24scalars_entry, 6, 0};

V g_std_2ecli_2eshortWhere_24scalars(V v_sh_240, V v_on_241, V v_waiting_242, V v_count_243, V v_given_244, V v_cl_245) {
top: ;
  if (heff_strEq_c_lent(v_cl_245, ((V)&g_std_2ecli_2eshortWhere_24scalars_str0), 2)) {
    heff_drop_rec(v_sh_240, 2);
    heff_drop(v_cl_245);
    return heff_rec_n(4, shape_on__waiting__count__given, (V[]){v_on_241, v_waiting_242, v_count_243, v_given_244});
  } else {
    V v_x_247 = heff_strSlice_lent(v_cl_245, MK_INT(0LL), MK_INT(1LL), 6);
    if (heff_strEq_c_lent(v_x_247, ((V)&g_std_2ecli_2eshortWhere_24scalars_str1), 2)) {
      heff_drop_rec(v_sh_240, 2);
      heff_drop(v_cl_245);
      heff_drop(v_x_247);
      return heff_rec_n(4, shape_on__waiting__count__given, (V[]){v_on_241, v_waiting_242, v_count_243, v_given_244});
    } else {
      HeffT2 v_t_249 = ({ V a_0 = v_x_247; V a_1 = heff_dup(heff_rfield(v_sh_240, 0)); HeffT2 r_ = (g_list_2efind_24s575827429x1292946038_24cpr(a_0, a_1)); heff_drop(v_x_247); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop(v_waiting_242);
          V v_f_2413 = v_field_2411;
          if (heff_strEq_c(heff_dup(heff_rfield(v_f_2413, 2)), ((V)&g_std_2ecli_2eshortWhere_24scalars_str2))) {
            V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_2413, 0, 8), v_given_244});
            V v_t_2416 = heff_strSlice(heff_dup(v_cl_245), MK_INT(1LL), heff_strLength(v_cl_245));
            V t_0 = v_sh_240;
            V t_1 = v_on_241;
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = v_count_243;
            V t_4 = v_t_2415;
            V t_5 = v_t_2416;
            v_sh_240 = t_0;
            v_on_241 = t_1;
            v_waiting_242 = t_2;
            v_count_243 = t_3;
            v_given_244 = t_4;
            v_cl_245 = t_5;
            goto top;
          } else {
            heff_drop_rec(v_sh_240, 2);
            V v_t_2418;
            if ((((int64_t)1ULL) < heff_unbox_word(heff_strLength(v_cl_245)))) {
              v_t_2418 = NTAG(TAG_Nothing);
            } else {
              v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2413)});
            }
            V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_2413, 0, 8), v_given_244});
            return heff_rec_n(4, shape_on__waiting__count__given, (V[]){v_on_241, v_t_2418, v_count_243, v_t_2419});
          }
        } else {
          heff_drop_rec(v_sh_240, 2);
          heff_drop(v_cl_245);
          heff_drop(v_field_2411);
          return heff_rec_n(4, shape_on__waiting__count__given, (V[]){v_on_241, v_waiting_242, v_count_243, v_given_244});
        }
      }
    }
  }
}
V g_std_2ecli_2eshortWhere_24scalars_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortWhere_24scalars(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2eshortWhere_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_entry, 3, 0};

V g_std_2ecli_2eshortWhere(V v_sh_240, V v_st_241, V v_cl_242) {
top: ;
  return (g_std_2ecli_2eshortWhere_24scalars(v_sh_240, heff_dup(heff_rfield(v_st_241, 0)), heff_dup(heff_rfield(v_st_241, 1)), heff_dup(heff_rfield(v_st_241, 2)), heff_get_n(v_st_241, 3, 4), v_cl_242));
}
V g_std_2ecli_2eshortWhere_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortWhere(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2ewhereGo_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ewhereGo_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2ewhereGo_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2ewhereGo_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ewhereGo_str4, 0, "");
Clo g_std_2ecli_2ewhereGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ewhereGo_entry, 4, 0};

V g_std_2ecli_2ewhereGo(V v_sh_240, V v_ra_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sh_240);
    heff_drop(v_ra_241);
    return v_st_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_ws_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_st_242, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_dup(heff_rfield(v_st_242, 0));
      V v_t_249 = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_ra_241, 1) && heff_intLe_c(heff_dup(v_ra_241), heff_dup(heff_rfield(v_st_242, 2)))) : 1));
      heff_drop(v_t_247);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_x41_244);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_t_249);
        V v_t_2410 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
        V v_t_2411 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_sh_240;
        V t_1 = v_ra_241;
        V t_2 = v_t_2411;
        V t_3 = v_ws_245;
        v_sh_240 = t_0;
        v_ra_241 = t_1;
        v_st_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_249);
        if (heff_strEq_c_lent(v_x41_244, ((V)&g_std_2ecli_2ewhereGo_str0), 2)) {
          heff_drop(v_x41_244);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          V v_t_2413 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 12ULL, 4, shape_on__waiting__count__given, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          V t_0 = v_sh_240;
          V t_1 = v_ra_241;
          V t_2 = v_t_2413;
          V t_3 = v_ws_245;
          v_sh_240 = t_0;
          v_ra_241 = t_1;
          v_st_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        } else {
          if (heff_strEq_c(heff_strSlice_lent(v_x41_244, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ewhereGo_str1))) {
            V v_t_2415 = heff_strSlice(heff_dup(v_x41_244), MK_INT(2LL), heff_strLength_lent(v_x41_244, 0));
            HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_sh_240); V a_1 = v_t_2415; HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_x_2420 = v_field_2418;
                heff_drop(v_x_2420);
                V v_j_2421 = heff_strFind_lent(((V)&g_std_2ecli_2ewhereGo_str2), v_x41_244, MK_INT(0LL), 5);
                if (heff_intLt_c_lent(v_j_2421, MK_INT(0LL), 2)) {
                  heff_drop(v_x41_244);
                  heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                  heff_drop(v_j_2421);
                  V t_0 = v_sh_240;
                  V t_1 = v_ra_241;
                  V t_2 = v_st_242;
                  V t_3 = v_ws_245;
                  v_sh_240 = t_0;
                  v_ra_241 = t_1;
                  v_st_242 = t_2;
                  v_x4_243 = t_3;
                  goto top;
                } else {
                  HeffT2 v_t_2423 = ({ V a_0 = heff_dup(v_sh_240); V b_1 = heff_strSlice(v_x41_244, MK_INT(2LL), v_j_2421); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
                  V v_t_2429;
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x_2427 = v_field_2425;
                      heff_drop(v_x_2427);
                      v_t_2429 = ((V)&g_std_2ecli_2ewhereGo_str3);
                    } else {
                      V v_f_2428 = v_field_2425;
                      v_t_2429 = heff_get_n(v_f_2428, 0, 8);
                    }
                  }
                  V v_t_2430 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_dup(heff_rfield(v_st_242, 3))});
                  V v_t_2431 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_3 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
                  V t_0 = v_sh_240;
                  V t_1 = v_ra_241;
                  V t_2 = v_t_2431;
                  V t_3 = v_ws_245;
                  v_sh_240 = t_0;
                  v_ra_241 = t_1;
                  v_st_242 = t_2;
                  v_x4_243 = t_3;
                  goto top;
                }
              } else {
                heff_drop(v_x41_244);
                V v_f_2432 = v_field_2418;
                V v_t_2434;
                if (heff_strEq_c(heff_dup(heff_rfield(v_f_2432, 2)), ((V)&g_std_2ecli_2ewhereGo_str4))) {
                  v_t_2434 = NTAG(TAG_Nothing);
                } else {
                  v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2432)});
                }
                V v_t_2435 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_2432, 0, 8), heff_dup(heff_rfield(v_st_242, 3))});
                V v_t_2436 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = v_t_2434; V rv_3 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2436;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
            }
          } else {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x41_244, 0)))) {
              if ((heff_unbox_word(heff_strByteAt_lent(v_x41_244, MK_INT(0LL), 2)) == ((int64_t)45ULL))) {
                V v_t_2439 = heff_strSlice(heff_dup(v_x41_244), MK_INT(1LL), heff_strLength(v_x41_244));
                V v_t_2440 = (g_std_2ecli_2eshortWhere(heff_dup(v_sh_240), v_st_242, v_t_2439));
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2440;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              } else {
                heff_drop(v_x41_244);
                V v_t_2441 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
                V v_t_2442 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2442;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
            } else {
              heff_drop(v_x41_244);
              V v_t_2443 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
              V v_t_2444 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2444;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x4_243 = t_3;
              goto top;
            }
          }
        }
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x41_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2446 = ({ V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 13ULL, 4, shape_on__waiting__count__given, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V t_0 = v_sh_240;
      V t_1 = v_ra_241;
      V t_2 = v_t_2446;
      V t_3 = v_ws_245;
      v_sh_240 = t_0;
      v_ra_241 = t_1;
      v_st_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2ewhereGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ewhereGo(a[0], a[1], a[2], a[3]);
}

HeffT2 g_std_2ecli_2eposAt_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_p_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_ps_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
      } else {
        heff_drop_rec(v_p_242, 3);
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Optional: {
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_ps_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
      } else {
        heff_drop_rec(v_p_242, 3);
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Many: {
      heff_drop(v_i_241);
      heff_drop(v_ps_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
    }
    case TAG_Some: {
      heff_drop(v_i_241);
      heff_drop(v_ps_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
    }
    case TAG_Rest: {
      heff_drop(v_i_241);
      heff_drop(v_ps_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2ecompleteAt_str0, 1, "-");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str1, 1, "-");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str3, 2, "--");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str4, 6, "--help");
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args);
Clo g_std_2ecli_2ecompleteAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteAt_entry, 3, 0};

V g_std_2ecli_2ecompleteAt(V v_sh_240, V v_st_241, V v_cur_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_241, 1));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_dup(heff_rfield(v_st_241, 0));
    V v_t_249 = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) && ({ V v_x_245 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = (heff_intLe_c_lent(MK_INT(0LL), v_x_245, 1) ? ({ V v_y_247 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = (heff_intLe_c(heff_dup(v_y_247), heff_dup(heff_rfield(v_st_241, 2))) ? 0 : heff_strEq_c(heff_strSlice_lent(v_cur_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2ecompleteAt_str0))); heff_drop(v_y_247); c_; }) : heff_strEq_c(heff_strSlice_lent(v_cur_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2ecompleteAt_str1))); heff_drop(v_x_245); c_; })));
    heff_drop(v_t_244);
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_j_2410 = heff_strFind_lent(((V)&g_std_2ecli_2ecompleteAt_str2), v_cur_242, MK_INT(0LL), 5);
      if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
        heff_drop(v_j_2410);
        V v_t_2416 = (g_list_2emap_24f134831722x1788320834(((V)&g_std_2ecli_2ecompleteAt_str3), heff_clo_n(g_std_2ecli_2ecompleteAt_lam0, 1, 1, (V[]){v_st_241}), heff_get_n(v_sh_240, 0, 2)));
        V v_t_2417 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_242; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ecompleteAt_str4), v_t_2416}); V r_ = (g_list_2efilter_24s2009824277x1398398543(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        return heff_tag_n(TAG_Words, 1, (V[]){v_t_2417});
      } else {
        heff_drop_rec(v_st_241, 4);
        HeffT2 v_t_2418 = ({ V a_0 = v_sh_240; V b_1 = heff_strSlice_lent(v_cur_242, MK_INT(2LL), v_j_2410, 2); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            heff_drop(v_j_2410);
            V v_x_2422 = v_field_2420;
            heff_drop(v_x_2422);
            return NTAG(TAG_Nothing);
          } else {
            V v_f_2423 = v_field_2420;
            V v_t_2424 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_242; V a_2 = v_cur_242; V b_3 = MK_INT(0LL); V a_4 = v_j_2410; V a_5 = MK_INT(1LL); V a_6 = heff_get_n(v_f_2423, 4, 8); V r_ = (g_list_2efilter_24f1490579794x1456232270(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
            return heff_tag_n(TAG_Words, 1, (V[]){v_t_2424});
          }
        }
      }
    } else {
      heff_drop(v_t_249);
      HeffT2 v_t_2425 = (g_std_2ecli_2eposAt_24cpr(heff_get_n(v_sh_240, 1, 2), heff_get_n(v_st_241, 2, 4)));
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_p_2429 = v_field_2427;
          V v_t_2430 = heff_get_n(v_p_2429, 2, 3);
          switch (heff_tag_of(v_t_2430)) {
          case TAG_None: {
            return NTAG(TAG_Nothing);
          }
          case TAG_Files: {
            V v_sfx_2431 = heff_field(v_t_2430, 0);
            V v_ru_24t_2430_24Files = heff_take_reuse_n(v_t_2430, 1ULL, 1);
            return heff_tag_at_n(v_ru_24t_2430_24Files, TAG_FilesBy, 1, (V[]){v_sfx_2431});
          }
          case TAG_Dirs: {
            return NTAG(TAG_DirsOnly);
          }
          case TAG_Among: {
            V v_ws_2432 = heff_field(v_t_2430, 0);
            V v_ru_24t_2430_24Among = heff_take_reuse_n(v_t_2430, 1ULL, 1);
            V v_t_2433 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_242; V a_2 = v_ws_2432; V r_ = (g_list_2efilter_24s2009824277x1398398543(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            return heff_tag_at_n(v_ru_24t_2430_24Among, TAG_Words, 1, (V[]){v_t_2433});
          }
          default: return heff_nomatch(v_t_2430);
          }
        } else {
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  case TAG_Just: {
    V v_waiting1_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_sh_240, 2);
    heff_drop_rec(v_st_241, 4);
    V v_t_2435 = heff_dup(heff_rfield(v_waiting1_2434, 4));
    switch (heff_tag_of(v_t_2435)) {
    case TAG_Nil: {
      V v_t_2436 = heff_get_n(v_waiting1_2434, 7, 8);
      switch (heff_tag_of(v_t_2436)) {
      case TAG_None: {
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Files: {
        V v_sfx_2437 = heff_field(v_t_2436, 0);
        heff_take_n(v_t_2436, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_243_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2437});
      }
      case TAG_Dirs: {
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_DirsOnly);
      }
      case TAG_Among: {
        V v_ws_2438 = heff_field(v_t_2436, 0);
        heff_take_n(v_t_2436, 1ULL, 1);
        V v_t_2439 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_242; V a_2 = v_ws_2438; V r_ = (g_list_2efilter_24s2009824277x1398398543(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){v_t_2439});
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_2435, 0ULL, 2);
      V v_t_2442 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_242; V a_2 = heff_get_n(v_waiting1_2434, 4, 8); V r_ = (g_list_2efilter_24s2009824277x1398398543(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){v_t_2442});
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2ecompleteAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ecli_2ecompleteAt(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args) {
  V v_f_2412 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_take_field(v_f_2412, 5);
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2413) == NTAG(TAG_True)) || ({ V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2412, 0))})); int c_ = ({ V v_x1_2415 = (g_list_2eany(heff_dup(v_t_2414), heff_rfield(v_st_241, 3))); int c_ = !(heff_dup(v_x1_2415) == NTAG(TAG_True)); heff_drop(v_x1_2415); c_; }); heff_drop(v_t_2414); c_; })));
  heff_drop_rec(v_f_2412, 8);
  heff_drop_rec(v_st_241, 4);
  heff_drop(v_t_2413);
  return v_ret_24bool;
}
HEFF_LIT(g_std_2ecli_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagWord_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2eflagWord_str2, 3, "[--");
HEFF_LIT(g_std_2ecli_2eflagWord_str3, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagWord_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagWord_str5, 1, "]");
HEFF_LIT(g_std_2ecli_2eflagWord_str6, 1, " ");
HEFF_LIT(g_std_2ecli_2eflagWord_str7, 3, "[--");
Clo g_std_2ecli_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagWord_entry, 1, 0};

V g_std_2ecli_2eflagWord(V v_f_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2eflagWord_str0))) {
    V v_t_242 = heff_strAppend(heff_get_n(v_f_240, 0, 8), ((V)&g_std_2ecli_2eflagWord_str1));
    return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str2), v_t_242);
  } else {
    V v_t_243 = heff_take_field(v_f_240, 6);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2eflagWord_str3), heff_take_field(v_f_240, 2));
      V v_t_245 = heff_strAppend(heff_get_n(v_f_240, 0, 8), v_t_244);
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str4), v_t_245);
    } else {
      heff_drop(v_t_243);
      V v_t_246 = heff_strAppend(heff_take_field(v_f_240, 2), ((V)&g_std_2ecli_2eflagWord_str5));
      V v_t_247 = heff_strAppend(heff_get_n(v_f_240, 0, 8), heff_strAppend(((V)&g_std_2ecli_2eflagWord_str6), v_t_246));
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str7), v_t_247);
    }
  }
}
V g_std_2ecli_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagWord(a[0]);
}
HEFF_LIT(g_std_2ecli_2eline2_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str3, 1, "\012");
HEFF_LIT(g_std_2ecli_2eline2_str4, 2, "  ");
HEFF_LIT(g_std_2ecli_2eline2_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str6, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str8, 2, "  ");
Clo g_std_2ecli_2eline2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eline2_entry, 2, 0};

V g_std_2ecli_2eline2(V v_x_240, V v_doc_241) {
top: ;
  if ((((int64_t)26ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    V v_x2_243 = (g_list_2ereplicate(MK_INT(30LL), ((V)&g_std_2ecli_2eline2_str0)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_std_2ecli_2eline2_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2eline2_str3), heff_strAppend(v_t_246, v_doc_241));
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str4), heff_strAppend(v_x_240, v_t_247));
  } else {
    int64_t v_t_248 = (((int64_t)28ULL) - heff_unbox_word(heff_strLength_lent(v_x_240, 0)));
    V v_x2_249 = (g_list_2ereplicate(heff_box_word(v_t_248), ((V)&g_std_2ecli_2eline2_str5)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_std_2ecli_2eline2_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str7); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2413 = heff_strAppend(v_x_240, heff_strAppend(v_t_2412, v_doc_241));
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str8), v_t_2413);
  }
}
V g_std_2ecli_2eline2_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eline2(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eflagLine_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str1, 4, "    ");
HEFF_LIT(g_std_2ecli_2eflagLine_str2, 2, ", ");
HEFF_LIT(g_std_2ecli_2eflagLine_str3, 1, "-");
HEFF_LIT(g_std_2ecli_2eflagLine_str4, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str5, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str6, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagLine_str7, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagLine_str8, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str9, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str10, 2, ", ");
HEFF_LIT(g_std_2ecli_2eflagLine_str11, 2, " (");
HEFF_LIT(g_std_2ecli_2eflagLine_str12, 1, ")");
Clo g_std_2ecli_2eflagLine_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagLine_entry, 1, 0};

V g_std_2ecli_2eflagLine(V v_f_240) {
top: ;
  V v_t_243;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 1)), ((V)&g_std_2ecli_2eflagLine_str0))) {
    v_t_243 = ((V)&g_std_2ecli_2eflagLine_str1);
  } else {
    V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_f_240, 1)), ((V)&g_std_2ecli_2eflagLine_str2));
    v_t_243 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str3), v_t_242);
  }
  V v_t_245;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2eflagLine_str4))) {
    v_t_245 = ((V)&g_std_2ecli_2eflagLine_str5);
  } else {
    v_t_245 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str6), heff_dup(heff_rfield(v_f_240, 2)));
  }
  V v_t_246 = heff_strAppend(heff_take_field(v_f_240, 0), v_t_245);
  V v_t_247 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_std_2ecli_2eflagLine_str7), v_t_246));
  V v_t_248 = heff_dup(heff_rfield(v_f_240, 4));
  V v_t_2415;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_std_2ecli_2eflagLine_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_248, 0ULL, 2);
    V v_t_2411 = heff_dup(heff_rfield(v_f_240, 4));
    V v_t_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_std_2ecli_2eflagLine_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_t_2411, 0);
      V v_xs_2413 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_std_2ecli_2eflagLine_str10); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    v_t_2415 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str11), heff_strAppend(v_t_2414, ((V)&g_std_2ecli_2eflagLine_str12)));
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2416 = heff_strAppend(heff_get_n(v_f_240, 3, 8), v_t_2415);
  return (g_std_2ecli_2eline2(v_t_247, v_t_2416));
}
V g_std_2ecli_2eflagLine_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagLine(a[0]);
}
HEFF_LIT(g_std_2ecli_2ehelpOf_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str1, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str4, 6, "flags:");
HEFF_LIT(g_std_2ecli_2ehelpOf_str5, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2ehelpOf_str7, 1, "\012");
Clo g_std_2ecli_2ehelpOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ehelpOf_entry, 2, 0};

V g_std_2ecli_2ehelpOf(V v_prog_240, V v_k_241) {
top: ;
  V v_t_242 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
  V v_t_243 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str0), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_k_241, 1), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str1), v_t_243), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str2), v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_x1_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_241, 4);
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 0ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_k_241, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_2411 = heff_get_n(heff_get_n(v_t_2410, 0, 2), 0, 2);
    V v_t_2412 = (g_list_2emap_24s1753874608x910016727(v_t_2411));
    v_t_2413 = heff_tag_at_n(v_ru_24x1_247_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str4), v_t_2412})});
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_x2_2414 = (g_prelude_2e_2b_2b(v_t_245, v_t_2413));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_std_2ecli_2ehelpOf_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2ehelpOf_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  return heff_strAppend(v_t_2417, ((V)&g_std_2ecli_2ehelpOf_str7));
}
V g_std_2ecli_2ehelpOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ehelpOf(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eorList_24acc_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str2, 2, ", ");
Clo g_std_2ecli_2eorList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_24acc_entry, 2, 0};

V g_std_2ecli_2eorList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_std_2ecli_2eorList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_std_2ecli_2eorList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_std_2ecli_2eorList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eproblemSaid_str0, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str1, 4, "; --");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str2, 1, "\?");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str3, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str4, 14, " takes a value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str5, 15, " takes no value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str6, 2, "--");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str7, 17, " is the start of ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str8, 10, " is wanted");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str9, 6, ", not ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str10, 4, " is ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str11, 9, "expected ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str12, 16, "too many words: ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str13, 4, "help");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str14, 34, "the command is described wrongly: ");
Clo g_std_2ecli_2eproblemSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eproblemSaid_entry, 1, 0};

V g_std_2ecli_2eproblemSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unknown: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nothing: {
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str0), heff_dup(v_w_241));
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x12_242, 0);
      V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str1), heff_strAppend(heff_dup(v_s_243), ((V)&g_std_2ecli_2eproblemSaid_str2)));
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str3), heff_strAppend(heff_dup(v_w_241), v_t_244));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_NoValue: {
    V v_w_245 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_245), ((V)&g_std_2ecli_2eproblemSaid_str4));
  }
  case TAG_SwitchValue: {
    V v_w_246 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_246), ((V)&g_std_2ecli_2eproblemSaid_str5));
  }
  case TAG_Ambiguous: {
    V v_w_247 = heff_field(v_x1_240, 0);
    V v_cands_248 = heff_field(v_x1_240, 1);
    V v_t_249 = (g_list_2emap_24s231073986x752637537(((V)&g_std_2ecli_2eproblemSaid_str6), heff_dup(v_cands_248)));
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_std_2ecli_2eorList(a_0)); heff_drop(v_t_249); r_; });
    return heff_strAppend(heff_dup(v_w_247), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str7), v_t_2410));
  }
  case TAG_MissingFlag: {
    V v_w_2411 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_2411), ((V)&g_std_2ecli_2eproblemSaid_str8));
  }
  case TAG_NotIn: {
    V v_w_2412 = heff_field(v_x1_240, 0);
    V v_v_2413 = heff_field(v_x1_240, 1);
    V v_vs_2414 = heff_field(v_x1_240, 2);
    V v_t_2415 = (g_std_2ecli_2eorList(v_vs_2414));
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str9), heff_dup(v_v_2413)));
    return heff_strAppend(heff_dup(v_w_2412), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str10), v_t_2416));
  }
  case TAG_Missing: {
    V v_m_2417 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str11), heff_dup(v_m_2417));
  }
  case TAG_Extra: {
    V v_w_2418 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str12), heff_dup(v_w_2418));
  }
  case TAG_Help: {
    return ((V)&g_std_2ecli_2eproblemSaid_str13);
  }
  case TAG_BadShape: {
    V v_why_2419 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str14), heff_dup(v_why_2419));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eproblemSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eproblemSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2ecandidatesText_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str1, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str4, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str5, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str6, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str7, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str8, 7, ":files ");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str9, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str10, 6, ":dirs\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str11, 0, "");
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args);
Clo g_std_2ecli_2ecandidatesText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecandidatesText_entry, 2, 0};

V g_std_2ecli_2ecandidatesText(V v_sh_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Words: {
    V v_ws_242 = heff_field(v_x2_241, 0);
    V v_x2_2414 = (g_list_2emap(heff_clo_n(g_std_2ecli_2ecandidatesText_lam0, 1, 1, (V[]){v_sh_240}), heff_dup(v_ws_242)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_std_2ecli_2ecandidatesText_str6);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_std_2ecli_2ecandidatesText_str7); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_FilesBy: {
    V v_sfx_2417 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_sh_240, 2);
    return heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str8), heff_strAppend(heff_dup(v_sfx_2417), ((V)&g_std_2ecli_2ecandidatesText_str9)));
  }
  case TAG_DirsOnly: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str10);
  }
  case TAG_Nothing: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str11);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecandidatesText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecandidatesText(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args) {
  V v_w_243 = args[0];
  V v_sh_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_doc_2411;
  if (heff_strEq_c(heff_strSlice_lent(v_w_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ecandidatesText_str0))) {
    V v_t_245 = heff_strSlice(heff_dup(v_w_243), MK_INT(2LL), heff_strLength_lent(v_w_243, 0));
    HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_get_n(v_sh_240, 0, 2); HeffT2 r_ = (g_list_2efind_24s1839921325x671097810_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_f_2410 = v_field_248;
        v_doc_2411 = heff_get_n(v_f_2410, 3, 8);
      } else {
        heff_drop(v_field_248);
        v_doc_2411 = ((V)&g_std_2ecli_2ecandidatesText_str1);
      }
    }
  } else {
    heff_drop_rec(v_sh_240, 2);
    v_doc_2411 = ((V)&g_std_2ecli_2ecandidatesText_str2);
  }
  V v_t_2413;
  if (heff_strEq_c_lent(v_doc_2411, ((V)&g_std_2ecli_2ecandidatesText_str3), 2)) {
    heff_drop(v_doc_2411);
    v_t_2413 = v_w_243;
  } else {
    v_t_2413 = heff_strAppend(v_w_243, heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str4), v_doc_2411));
  }
  return heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2ecandidatesText_str5));
}
HEFF_LIT(g_std_2ecli_2ecommandsText_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str1, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecommandsText_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecommandsText_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str5, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecommandsText_str6, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecommandsText_str7, 4, "help");
HEFF_LIT(g_std_2ecli_2ecommandsText_str8, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2ecommandsText_str9, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str10, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecommandsText_str11, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecommandsText_str12, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str13, 0, "");
Clo g_std_2ecli_2ecommandsText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecommandsText_entry, 2, 0};

V g_std_2ecli_2ecommandsText(V v_cs_240, V v_cur_241) {
top: ;
  V v_x2_242 = ({ V b_0 = ((V)&g_std_2ecli_2ecommandsText_str0); V a_1 = ((V)&g_std_2ecli_2ecommandsText_str1); V a_2 = ((V)&g_std_2ecli_2ecommandsText_str2); V b_3 = MK_INT(0LL); V a_4 = v_cur_241; V a_5 = v_cs_240; V r_ = (g_list_2emap_24f1690623035x874154762(b_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_std_2ecli_2ecommandsText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str5), ((V)&g_std_2ecli_2ecommandsText_str6)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str7), ((V)&g_std_2ecli_2ecommandsText_str8)}), v_t_246});
  V v_xs_248 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_t_247; V r_ = (g_list_2efilter_24s2016771181x401513202(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_x2_249 = ({ V b_0 = ((V)&g_std_2ecli_2ecommandsText_str9); V a_1 = ((V)&g_std_2ecli_2ecommandsText_str10); V a_2 = ((V)&g_std_2ecli_2ecommandsText_str11); V a_3 = v_xs_248; V r_ = (g_list_2emap_24s1412546768x2004463577(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_std_2ecli_2ecommandsText_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  return heff_strAppend(v_t_245, v_t_2412);
}
V g_std_2ecli_2ecommandsText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecommandsText(a[0], a1); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einitOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_24dps_entry, 2, 0};

V g_std_2ecli_2einitOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf_24dps(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2efishScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2efishScript_str1, 18, " completions fish`");
HEFF_LIT(g_std_2ecli_2efishScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2efishScript_str3, 11, "function __");
HEFF_LIT(g_std_2ecli_2efishScript_str4, 9, "_complete");
HEFF_LIT(g_std_2ecli_2efishScript_str5, 16, "    set -l out (");
HEFF_LIT(g_std_2ecli_2efishScript_str6, 17, " complete $words)");
HEFF_LIT(g_std_2ecli_2efishScript_str7, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str8, 3, " -e");
HEFF_LIT(g_std_2ecli_2efishScript_str9, 11, " -f -a '(__");
HEFF_LIT(g_std_2ecli_2efishScript_str10, 11, "_complete)'");
HEFF_LIT(g_std_2ecli_2efishScript_str11, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str12, 3, "end");
HEFF_LIT(g_std_2ecli_2efishScript_str13, 30, "            printf '%s\\n' $out");
HEFF_LIT(g_std_2ecli_2efishScript_str14, 7, "    end");
HEFF_LIT(g_std_2ecli_2efishScript_str15, 57, "            __fish_complete_directories (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str16, 16, "        case '*'");
HEFF_LIT(g_std_2ecli_2efishScript_str17, 75, "            __fish_complete_suffix (string replace ':files ' '' -- $out[1])");
HEFF_LIT(g_std_2ecli_2efishScript_str18, 20, "        case ':dirs'");
HEFF_LIT(g_std_2ecli_2efishScript_str19, 20, "    switch \"$out[1]\"");
HEFF_LIT(g_std_2ecli_2efishScript_str20, 23, "        case ':files *'");
HEFF_LIT(g_std_2ecli_2efishScript_str21, 19, "    set -e words[1]");
HEFF_LIT(g_std_2ecli_2efishScript_str22, 53, "    set -l words (commandline -opc) (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str23, 1, "\012");
Clo g_std_2ecli_2efishScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efishScript_entry, 1, 0};

V g_std_2ecli_2efishScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str6)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str8)));
  V v_t_246 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str9), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str10)));
  V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str11), heff_strAppend(v_prog_240, v_t_246));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str12), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str14), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str16), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str18), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str20), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str22), v_t_2414})});
  return ({ V a_0 = ((V)&g_std_2ecli_2efishScript_str23); V a_1 = v_t_242; V a_2 = v_t_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
}
V g_std_2ecli_2efishScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2efishScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ebashScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ebashScript_str1, 18, " completions bash`");
HEFF_LIT(g_std_2ecli_2ebashScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2ebashScript_str3, 1, "_");
HEFF_LIT(g_std_2ecli_2ebashScript_str4, 4, "() {");
HEFF_LIT(g_std_2ecli_2ebashScript_str5, 49, "  while IFS= read -r w; do out+=(\"$w\"); done < <(");
HEFF_LIT(g_std_2ecli_2ebashScript_str6, 26, " complete \"${words[@]:1}\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str7, 1, " ");
HEFF_LIT(g_std_2ecli_2ebashScript_str8, 26, "complete -o filenames -F _");
HEFF_LIT(g_std_2ecli_2ebashScript_str9, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ebashScript_str10, 1, "}");
HEFF_LIT(g_std_2ecli_2ebashScript_str11, 25, "        COMPREPLY+=(\"$w\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str12, 13, "      done ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str13, 22, "        w=${w%%$'\\t'*}");
HEFF_LIT(g_std_2ecli_2ebashScript_str14, 77, "        if [[ $last == *=* ]]; then w=${w#*=}; [[ $cur == = ]] && w=\"=$w\"; fi");
HEFF_LIT(g_std_2ecli_2ebashScript_str15, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ebashScript_str16, 30, "      for w in \"${out[@]}\"; do");
HEFF_LIT(g_std_2ecli_2ebashScript_str17, 103, "    ':files '*) COMPREPLY=($(compgen -d -- \"$cur\") $(compgen -f -X \"!*${out[0]#:files }\" -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str18, 51, "    ':dirs') COMPREPLY=($(compgen -d -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str19, 14, "  COMPREPLY=()");
HEFF_LIT(g_std_2ecli_2ebashScript_str20, 21, "  case \"${out[0]}\" in");
HEFF_LIT(g_std_2ecli_2ebashScript_str21, 31, "  last=${words[${#words[@]}-1]}");
HEFF_LIT(g_std_2ecli_2ebashScript_str22, 28, "  read -ra words <<< \"$line\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str23, 58, "  [[ $line == *' ' || ${#words[@]} -eq 1 ]] && words+=('')");
HEFF_LIT(g_std_2ecli_2ebashScript_str24, 75, "  local line=${COMP_LINE:0:COMP_POINT} cur=${COMP_WORDS[COMP_CWORD]} w last");
HEFF_LIT(g_std_2ecli_2ebashScript_str25, 20, "  local -a words out");
HEFF_LIT(g_std_2ecli_2ebashScript_str26, 1, "\012");
Clo g_std_2ecli_2ebashScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ebashScript_entry, 1, 0};

V g_std_2ecli_2ebashScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str6)));
  V v_t_245 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ebashScript_str7), v_prog_240));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2ebashScript_str8), v_t_245), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str10), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str12), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str14), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str16), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str18), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str20), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str23), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str25), v_t_2414})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ebashScript_str26); V a_1 = v_t_242; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2415}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2ebashScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ebashScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str2, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str3, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str7, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str8, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str10, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str11, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str12, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str13, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str14, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str15, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str16, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str17, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str18, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str19, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str20, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str21, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str22, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str23, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str24, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str25, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str26, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str27, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str28, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str29, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str30, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str31, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str32, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str33, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str34, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str35, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str36, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str37, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str38, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str39, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str40, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str41, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str42, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str43, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str44, 1, " ");

HeffT2 g_std_2ecli_2eoutcomeOf_24cpr(V v_prog_240, V v_k_241, V v_ws_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2ecli_2eparse_24cpr(heff_dup(heff_rfield(v_k_241, 3)), v_ws_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_Unknown: {
        V v_t_2410 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 2); r_; });
        V v_t_2411 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str0), heff_strAppend(v_t_2411, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str1)));
        V v_t_2413 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str2), heff_strAppend(heff_dup(v_prog_240), v_t_2412));
        V v_t_2414 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str3), heff_strAppend(v_t_2410, v_t_2413));
        V v_t_2415 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2414);
        V v_f_2416 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str4), v_t_2415));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
      }
      case TAG_NoValue: {
        V v_t_2418 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2419 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2420 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str5), heff_strAppend(v_t_2419, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str6)));
        V v_t_2421 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str7), heff_strAppend(heff_dup(v_prog_240), v_t_2420));
        V v_t_2422 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str8), heff_strAppend(v_t_2418, v_t_2421));
        V v_t_2423 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2422);
        V v_f_2424 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str9), v_t_2423));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
      }
      case TAG_SwitchValue: {
        V v_t_2426 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2427 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2428 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str10), heff_strAppend(v_t_2427, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str11)));
        V v_t_2429 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str12), heff_strAppend(heff_dup(v_prog_240), v_t_2428));
        V v_t_2430 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str13), heff_strAppend(v_t_2426, v_t_2429));
        V v_t_2431 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2430);
        V v_f_2432 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str14), v_t_2431));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
      }
      case TAG_Ambiguous: {
        V v_t_2435 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 2); r_; });
        V v_t_2436 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2437 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str15), heff_strAppend(v_t_2436, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str16)));
        V v_t_2438 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str17), heff_strAppend(heff_dup(v_prog_240), v_t_2437));
        V v_t_2439 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str18), heff_strAppend(v_t_2435, v_t_2438));
        V v_t_2440 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2439);
        V v_f_2441 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str19), v_t_2440));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2441}});
      }
      case TAG_MissingFlag: {
        V v_t_2443 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2444 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2445 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str20), heff_strAppend(v_t_2444, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str21)));
        V v_t_2446 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str22), heff_strAppend(heff_dup(v_prog_240), v_t_2445));
        V v_t_2447 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str23), heff_strAppend(v_t_2443, v_t_2446));
        V v_t_2448 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2447);
        V v_f_2449 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str24), v_t_2448));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2449}});
      }
      case TAG_NotIn: {
        V v_t_2453 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 3); r_; });
        V v_t_2454 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2455 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str25), heff_strAppend(v_t_2454, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str26)));
        V v_t_2456 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str27), heff_strAppend(heff_dup(v_prog_240), v_t_2455));
        V v_t_2457 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str28), heff_strAppend(v_t_2453, v_t_2456));
        V v_t_2458 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2457);
        V v_f_2459 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str29), v_t_2458));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2459}});
      }
      case TAG_Missing: {
        V v_t_2461 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2462 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2463 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str30), heff_strAppend(v_t_2462, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str31)));
        V v_t_2464 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str32), heff_strAppend(heff_dup(v_prog_240), v_t_2463));
        V v_t_2465 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str33), heff_strAppend(v_t_2461, v_t_2464));
        V v_t_2466 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2465);
        V v_f_2467 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str34), v_t_2466));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2467}});
      }
      case TAG_Extra: {
        V v_t_2469 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2470 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2471 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str35), heff_strAppend(v_t_2470, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str36)));
        V v_t_2472 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str37), heff_strAppend(heff_dup(v_prog_240), v_t_2471));
        V v_t_2473 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str38), heff_strAppend(v_t_2469, v_t_2472));
        V v_t_2474 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2473);
        V v_f_2475 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str39), v_t_2474));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
      }
      case TAG_Help: {
        V v_f_2476 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_241));
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2476}});
      }
      case TAG_BadShape: {
        V v_t_2478 = ({ V a_0 = v_it1_247; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_247, 1); r_; });
        V v_t_2479 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2480 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str40), heff_strAppend(v_t_2479, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str41)));
        V v_t_2481 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str42), heff_strAppend(heff_dup(v_prog_240), v_t_2480));
        V v_t_2482 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str43), heff_strAppend(v_t_2478, v_t_2481));
        V v_t_2483 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2482);
        V v_f_2484 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_24cpr_str44), v_t_2483));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2484}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_247)}});
      }
    } else {
      heff_drop(v_prog_240);
      heff_drop_rec(v_k_241, 4);
      V v_x_2485 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_x_2485}});
    }
  }
}