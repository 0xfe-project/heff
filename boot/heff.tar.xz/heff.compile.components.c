// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_RepV 61860
#define LBL_again 294104954
#define LBL_arity 294440695
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_callers 780494982
#define LBL_comp 9554902
#define LBL_defs 9574869
#define LBL_facts 298546081
#define LBL_falls 298554482
#define LBL_first 298798794
#define LBL_fresh 299054408
#define LBL_hope 9703939
#define LBL_hoped 300822210
#define LBL_imps 9731822
#define LBL_key 315609
#define LBL_lent 9813446
#define LBL_log 316862
#define LBL_members 1180739419
#define LBL_params 951713969
#define LBL_result 1012715336
#define LBL_sig 323403
#define LBL_sigs 10025609
#define LBL_sums 10037327
#define LBL_track 311979365
#define LBL_tracks 1081425843
#define LBL_ver 326173
static uint32_t shape_comp__base__hoped[] = {LBL_comp, LBL_base, LBL_hoped};
static uint32_t shape_facts__defs__callers[] = {LBL_facts, LBL_defs, LBL_callers};
static uint32_t shape_first__hope__falls__again[] = {LBL_first, LBL_hope, LBL_falls, LBL_again};
static uint32_t shape_key__track__sig__lent[] = {LBL_key, LBL_track, LBL_sig, LBL_lent};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_sigs__imps__log[] = {LBL_sigs, LBL_imps, LBL_log};
static uint32_t shape_tracks__sigs[] = {LBL_tracks, LBL_sigs};
static uint32_t shape_tracks__sigs__lent__sums__fresh[] = {LBL_tracks, LBL_sigs, LBL_lent, LBL_sums, LBL_fresh};
static uint32_t shape_ver__members[] = {LBL_ver, LBL_members};
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2ecomponents_2ecomputed(V, V, V, V, V, V);
V g_heff_2ecompile_2ecomponents_2ecomputed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecomponents_2ecomputed_clo;
V g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_get(void);
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2eworker_2ecycleOf(V, V);
V g_heff_2ecompile_2eworker_2ecycleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ecycleOf_clo;
V g_heff_2ecompile_2eworker_2efallsIn(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2efallsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallsIn_clo;
V g_heff_2ecompile_2eworker_2eroundsIn(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eroundsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eroundsIn_clo;
V g_heff_2ecompile_2eworker_2etouched(V, V);
V g_heff_2ecompile_2eworker_2etouched_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2etouched_clo;
V g_heff_2ecompile_2eworker_2ewithSig(V, V, V);
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ewithSig_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1325692678x1256705229(V, V);
V g_list_2efoldl_24s1325692678x1256705229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325692678x1256705229_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1388784929x1889262583(V, V);
V g_list_2efoldl_24s1388784929x1889262583_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1388784929x1889262583_clo;
V g_list_2efoldl_24s1568113292x813960132(V, V);
V g_list_2efoldl_24s1568113292x813960132_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1568113292x813960132_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1721918130x1703222899(V, V);
V g_list_2efoldl_24s1721918130x1703222899_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1721918130x1703222899_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1870413144x1677052540(V, V);
V g_list_2efoldl_24s1870413144x1677052540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1870413144x1677052540_clo;
V g_list_2efoldl_24s1885006984x1134653659(V, V);
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885006984x1134653659_clo;
V g_list_2efoldl_24s1887491001x1647849980(V, V);
V g_list_2efoldl_24s1887491001x1647849980_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1887491001x1647849980_clo;
V g_list_2efoldl_24s2079805794x637914515(V, V);
V g_list_2efoldl_24s2079805794x637914515_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2079805794x637914515_clo;
V g_list_2efoldl_24s2103009317x1481930218(V, V);
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2103009317x1481930218_clo;
V g_list_2efoldl_24s319398146x1205310166(V, V, V, V);
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a);
extern Clo g_list_2efoldl_24s319398146x1205310166_clo;
V g_list_2efoldl_24s350419482x997384157(V, V);
V g_list_2efoldl_24s350419482x997384157_entry(V self, V *a);
extern Clo g_list_2efoldl_24s350419482x997384157_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2efoldl_24s878331809x629122930(V, V);
V g_list_2efoldl_24s878331809x629122930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s878331809x629122930_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2efoldl_24s932544939x1448830416(V, V);
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_clo;
V g_list_2efoldl_24s986393991x630357464(V, V);
V g_list_2efoldl_24s986393991x630357464_entry(V self, V *a);
extern Clo g_list_2efoldl_24s986393991x630357464_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s549724630x1684056779(V);
V g_list_2ekeepIf_24s549724630x1684056779_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s549724630x1684056779_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1619849299x1543923271(V);
V g_list_2emap_24f1619849299x1543923271_entry(V self, V *a);
extern Clo g_list_2emap_24f1619849299x1543923271_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;

static V g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_val;
static HEFF_ONCE g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_st;
static V g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_init(void) {
  return heff_rec_n(3, shape_sigs__imps__log, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_st)) return g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_val;
  return heff_global(&g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_val, &g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_st, g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_init);
}
HEFF_LIT(g_heff_2ecompile_2ecomponents_2ecomputed_str0, 0, "");
V g_heff_2ecompile_2ecomponents_2ecomputed_lam0(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam1(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam3(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam2(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam4(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam7(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam6(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam5(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam8(V self, V *args);
V g_heff_2ecompile_2ecomponents_2ecomputed_lam9(V self, V *args);
Clo g_heff_2ecompile_2ecomponents_2ecomputed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecomponents_2ecomputed_entry, 6, 0};

V g_heff_2ecompile_2ecomponents_2ecomputed(V v_facts_240, V v_w_241, V v_ks_242, V v_defs_243, V v_out_244, V v_ver_245) {
top: ;
  V v_w_246 = heff_dup(v_w_241);
  V v_fresh_247 = heff_take_field(v_w_246, 4);
  V v_tracks_248 = heff_take_field(v_w_246, 0);
  V v_sigs_249 = heff_take_field(v_w_246, 1);
  V v_lent_2410 = heff_take_field(v_w_246, 2);
  V v_sums_2411 = heff_take_field(v_w_246, 3);
  V v_ks_2412 = v_ks_242;
  V v_ver_2413 = v_ver_245;
  V v_facts_2414 = v_facts_240;
  V v_known_2421 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam0, 1, 1, (V[]){heff_dup(v_w_241)}), heff_dup(v_out_244)));
  V v_defs_2422 = heff_dup(v_defs_243);
  V v_t_2423 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2422));
  V v_t_2424 = (g_list_2efoldl_24s1885006984x1134653659(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_2422)));
  V v_c_2425 = heff_rec_n(3, shape_facts__defs__callers, (V[]){heff_dup(v_facts_2414), v_t_2423, v_t_2424});
  V v_t_2426 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2422));
  V v_t_2427 = (g_list_2efoldl_24s1885006984x1134653659(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_2422)));
  V v_m_2428 = (g_list_2efoldl_24s350419482x997384157(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_known_2421)));
  V v_t_2429 = ({ V a_0 = v_m_2428; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2428); r_; });
  V v_xs_2430 = (g_list_2emap_24f1619849299x1543923271(heff_dup(v_defs_2422)));
  V v_m_2431 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2430; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2430); r_; });
  V v_t_2432 = ({ V a_0 = v_m_2431; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2431); r_; });
  V v_t_2433 = (g_list_2emap_24s1937570095x2110149801(v_t_2432));
  V v_s1_2434 = ({ V b_0 = heff_rec_n(3, shape_facts__defs__callers, (V[]){v_facts_2414, v_t_2426, v_t_2427}); V a_1 = MK_INT(1LL); V a_2 = v_t_2429; V a_3 = v_t_2433; V a_4 = heff_dup(g_heff_2ecompile_2ecomponents_2ecomputed_24rec0_get()); V r_ = heff_tr(g_heff_2ecompile_2eworker_2eroundsIn(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_c_2435 = heff_dup(v_c_2425);
  V v_defs_2436 = v_defs_2422;
  V v_known_2437 = v_known_2421;
  V v_s1_2438 = heff_dup(v_s1_2434);
  V v_t_2439 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_s1_2434, 1), NTAG(TAG_Nil)));
  V v_hs_2440 = ({ V b_0 = heff_get_n(v_c_2425, 0, 3); V b_1 = heff_get_n(v_s1_2434, 0, 3); V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V a_3 = v_t_2439; V r_ = (g_list_2efoldl_24s319398146x1205310166(b_0, b_1, a_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_t_2439); r_; });
  V v_c_2441 = heff_dup(v_c_2435);
  V v_defs_2442 = v_defs_2436;
  V v_known_2443 = heff_dup(v_known_2437);
  V v_hs_2444 = heff_dup(v_hs_2440);
  V v_s1_2445 = heff_dup(v_s1_2438);
  V v_m_2446 = (g_list_2efoldl_24s1388784929x1889262583(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_known_2437)));
  V v_t_2447 = ({ V a_0 = v_m_2446; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2446); r_; });
  V v_t_2448 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_hs_2440, NTAG(TAG_Nil)));
  V v_t_2449 = (g_list_2emap_24s1937570095x2110149801(v_t_2448));
  V v_t_2450 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_hs_2440, NTAG(TAG_Nil)));
  V v_t_2451 = ({ V a_0 = heff_dup(heff_rfield(v_s1_2438, 0)); V a_1 = v_t_2450; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_t_2450); r_; });
  V v_t_2452 = ({ V a_0 = v_t_2451; V a_1 = v_known_2437; V r_ = (g_list_2efoldl_24s986393991x630357464(a_0, a_1)); heff_drop(v_known_2437); r_; });
  V v_t_2453 = heff_rec_n(3, shape_comp__base__hoped, (V[]){v_c_2435, heff_take_field(v_s1_2438, 0), v_hs_2440});
  V v_t_2454 = ({ V rv_0 = v_t_2452; V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_s1_2438, 2ULL, 3, shape_sigs__imps__log, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s2_2455 = heff_tr(g_heff_2ecompile_2eworker_2efallsIn(v_t_2453, MK_INT(0LL), v_t_2447, v_t_2449, v_t_2454));
  V v_c_2456 = heff_dup(v_c_2441);
  V v_defs_2457 = v_defs_2442;
  V v_hs_2458 = heff_dup(v_hs_2444);
  V v_s1_2459 = v_s1_2445;
  V v_s2_2460 = heff_dup(v_s2_2455);
  V v_m_2461 = (g_list_2efoldl_24s1887491001x1647849980(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_known_2443)));
  V v_t_2462 = ({ V a_0 = v_m_2461; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2461); r_; });
  V v_t_2463 = ({ V a_0 = v_hs_2444; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_hs_2444); r_; });
  V v_t_2464 = (g_list_2emap_24s1937570095x2110149801(v_t_2463));
  V v_t_2465 = (g_list_2ekeepIf_24s549724630x1684056779(v_known_2443));
  V v_t_2466 = (g_list_2emap_24s1937570095x2110149801(v_t_2465));
  V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2466));
  V v_t_2468 = (g_heff_2ecompile_2eworker_2etouched(heff_dup(v_c_2441), v_t_2467));
  V v_sg_2469 = heff_take_field(v_s2_2455, 0);
  V v_t_2470 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_sg_2469, NTAG(TAG_Nil)));
  V v_t_2471 = ({ V a_0 = v_sg_2469; V a_1 = v_t_2470; V r_ = (g_list_2efoldl_24s2103009317x1481930218(a_0, a_1)); heff_drop(v_t_2470); r_; });
  V v_t_2472 = ({ V rv_0 = v_t_2471; V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_s2_2455, 2ULL, 3, shape_sigs__imps__log, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s3_2473 = ({ V a_0 = v_c_2441; V a_1 = MK_INT(1LL); V a_2 = v_t_2462; V a_3 = v_t_2468; V a_4 = v_t_2472; V r_ = heff_tr(g_heff_2ecompile_2eworker_2eroundsIn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_2441); r_; });
  V v_log_2474 = heff_take_field(v_s3_2473, 2);
  V v_sigs_2475 = heff_get_n(v_s3_2473, 0, 3);
  V v_t_2498 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam1, 1, 4, (V[]){v_s1_2459, v_hs_2458, v_s2_2460, v_log_2474}), heff_dup(v_defs_2457)));
  V v_js_24158 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam2, 2, 1, (V[]){v_c_2456}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2457; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_sg_24165 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam4, 2, 1, (V[]){v_sigs_2475}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2457; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_2457); r_; });
  V v_t_24166 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_sg_24165, NTAG(TAG_Nil)));
  V v_t_24188 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam5, 2, 1, (V[]){v_js_24158}); V a_1 = v_sg_24165; V a_2 = v_t_24166; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24166); r_; });
  V v_wk_24189 = heff_rec_n(2, shape_tracks__sigs, (V[]){v_t_2498, v_t_24188});
  V v_sigs_24190 = heff_take_field(v_wk_24189, 1);
  V v_tracks_24191 = heff_get_n(v_wk_24189, 0, 2);
  V v_known_24198 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam8, 2, 1, (V[]){v_w_241}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_out_244; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_out_244); r_; });
  V v_t_24199 = (g_list_2efoldl_24s1769360958x1839054239(v_known_24198, v_defs_243));
  V v_bor_24200 = ({ V a_0 = v_defs_243; V a_1 = MK_INT(-1LL); V a_2 = v_t_24199; V r_ = (g_heff_2ecompile_2eborrow_2eborFix(a_0, a_1, a_2)); heff_drop(v_defs_243); r_; });
  V v_ms_24206 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam9, 1, 2, (V[]){v_sigs_24190, v_bor_24200}), v_tracks_24191));
  V v_t_24207 = v_fresh_247;
  V v_t_24208 = (g_list_2efoldl_24s1721918130x1703222899(v_tracks_248, v_ms_24206));
  V v_t_24209 = (g_list_2efoldl_24s1568113292x813960132(v_sigs_249, v_ms_24206));
  V v_t_24210 = (g_list_2efoldl_24s2079805794x637914515(v_lent_2410, v_ms_24206));
  V v_t_24211 = (g_list_2efoldl_24s878331809x629122930(v_sums_2411, heff_dup(v_ms_24206)));
  V v_t_24214;
  switch (heff_tag_of(v_ks_2412)) {
  case TAG_Nil: {
    v_t_24214 = ((V)&g_heff_2ecompile_2ecomponents_2ecomputed_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_24212 = heff_field(v_ks_2412, 0);
    heff_take_n(v_ks_2412, 1ULL, 2);
    v_t_24214 = v_x_24212;
    break;
  }
  default: heff_nomatch(v_ks_2412);
  }
  V v_t_24215 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24214, heff_rec_n(2, shape_ver__members, (V[]){v_ver_2413, v_ms_24206})});
  return ({ V rv_0 = v_t_24208; V rv_1 = v_t_24209; V rv_2 = v_t_24210; V rv_3 = v_t_24211; V rv_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24215, v_t_24207}); V rr_ = heff_rec_reuse_nf(v_w_246, 0ULL, 5, shape_tracks__sigs__lent__sums__fresh, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2ecomponents_2ecomputed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecomponents_2ecomputed(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam0(V self, V *args) {
  V v_g_2415 = args[0];
  V v_w_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_w_241, 0, 5); V a_1 = v_g_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2420;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = heff_rec_n(4, shape_first__hope__falls__again, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nothing), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_g_2415, v_t_2420});
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam1(V self, V *args) {
  V v_d_2476 = args[0];
  V v_s1_2459 = heff_env(self)[0];
  V v_hs_2458 = heff_env(self)[1];
  V v_s2_2460 = heff_env(self)[2];
  V v_log_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_l1_2477 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_get_n(v_s1_2459, 2, 3)));
  V v_hs_2478 = v_hs_2458;
  V v_l2_2479 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_get_n(v_s2_2460, 2, 3)));
  V v_l3_2480 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), v_log_2474));
  V v_k_2481 = heff_dup(heff_rfield(v_d_2476, 0));
  HeffT2 v_t_2482 = ({ V a_0 = v_l1_2477; V a_1 = v_k_2481; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_l1_2477); r_; });
  {
    V v_field_2484 = v_t_2482.f[1];
    int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
    V v_t_2486;
    if ((v_tag_2483 == ((int64_t)0ULL))) {
      V v_x_2485 = v_field_2484;
      v_t_2486 = v_x_2485;
    } else {
      heff_drop(v_field_2484);
      v_t_2486 = NTAG(TAG_Nil);
    }
    V v_t_2487 = ({ V a_0 = v_hs_2478; V a_1 = v_k_2481; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_hs_2478); r_; });
    HeffT2 v_t_2488 = ({ V a_0 = v_l2_2479; V a_1 = v_k_2481; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_l2_2479); r_; });
    {
      V v_field_2490 = v_t_2488.f[1];
      int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
      V v_t_2492;
      if ((v_tag_2489 == ((int64_t)0ULL))) {
        V v_x_2491 = v_field_2490;
        v_t_2492 = v_x_2491;
      } else {
        heff_drop(v_field_2490);
        v_t_2492 = NTAG(TAG_Nil);
      }
      HeffT2 v_t_2493 = ({ V a_0 = v_l3_2480; V a_1 = v_k_2481; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_l3_2480); heff_drop(v_k_2481); r_; });
      {
        V v_field_2495 = v_t_2493.f[1];
        int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
        V v_t_2497;
        if ((v_tag_2494 == ((int64_t)0ULL))) {
          V v_x_2496 = v_field_2495;
          v_t_2497 = v_x_2496;
        } else {
          heff_drop(v_field_2495);
          v_t_2497 = NTAG(TAG_Nil);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_d_2476, 0, 3), heff_rec_n(4, shape_first__hope__falls__again, (V[]){v_t_2486, v_t_2487, v_t_2492, v_t_2497})});
      }
    }
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam3(V self, V *args) {
  V v_x4_24114 = args[0];
  V v_key_24104 = heff_env(self)[0];
  V v_n_24110 = heff_env(self)[1];
  V v_ar_24101 = heff_env(self)[2];
  switch (heff_tag_of(v_x4_24114)) {
  case TAG_MkPair: {
    V v_g_24115 = heff_field(v_x4_24114, 0);
    V v_m_24116 = heff_field(v_x4_24114, 1);
    heff_take_n(v_x4_24114, 3ULL, 2);
    if (!heff_strEq_c_lent(v_g_24115, v_key_24104, 0)) {
      heff_clo_take(self, 3);
      heff_drop(v_key_24104);
      if (heff_intEq_c_lent(v_m_24116, v_n_24110, 1)) {
        HeffT2 v_t_24117 = ({ V a_0 = v_ar_24101; V a_1 = v_g_24115; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ar_24101); heff_drop(v_g_24115); r_; });
        {
          V v_field_24119 = v_t_24117.f[1];
          int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
          if ((v_tag_24118 == ((int64_t)0ULL))) {
            V v_m_24120 = v_field_24119;
            V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_n_24110, v_m_24120, 0));
            heff_drop(v_n_24110);
            heff_drop(v_m_24120);
            return v_ret_24bool;
          } else {
            heff_drop(v_n_24110);
            heff_drop(v_field_24119);
            return NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_n_24110);
        heff_drop(v_ar_24101);
        heff_drop(v_g_24115);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(self);
      heff_drop(v_g_24115);
      heff_drop(v_m_24116);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x4_24114);
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam2(V self, V *args) {
  V v_m_2499 = args[0];
  V v_d_24100 = args[1];
  V v_c_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ar_24101 = heff_get_n(heff_get_n(v_c_2456, 0, 3), 0, 12);
  V v_d_24102 = heff_dup(v_d_24100);
  V v_body_24103 = heff_take_field(v_d_24102, 2);
  V v_key_24104 = heff_get_n(v_d_24102, 0, 3);
  V v_t_24105 = v_body_24103;
  V v_t_24157;
  switch (heff_tag_of(v_t_24105)) {
  case TAG_EVar: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_24108 = heff_field(v_t_24105, 0);
    V v_b_24109 = heff_field(v_t_24105, 1);
    V v_ru_24t_24105_24ELam = heff_take_reuse_n(v_t_24105, 3ULL, 2);
    V v_n_24110 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24108; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24108); r_; });
    V v_xs_24111 = ({ V a_0 = v_b_24109; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2ewaysOnto(a_0, a_1)); heff_drop(v_b_24109); r_; });
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24111));
    V v_t_24113 = (g_list_2efoldl_24s1870413144x1677052540(NTAG(TAG_Nil), v_t_24112));
    V v_t_24121 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam3, 1, 3, (V[]){v_key_24104, v_n_24110, v_ar_24101}); V a_1 = v_t_24113; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_24157 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24t_24105_24ELam, v_t_24121));
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_24105, 0ULL, 3);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_24105, 0ULL, 4);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_24105, 0ULL, 3);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_t_24105, 0ULL, 3);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_t_24105, 0ULL, 1);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_24105, 0ULL, 2);
    heff_drop(v_ar_24101);
    heff_drop(v_key_24104);
    v_t_24157 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_24105);
  }
  return ({ V a_0 = v_m_2499; V b_1 = heff_get_n(v_d_24100, 0, 3); V a_2 = v_t_24157; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_24157); r_; });
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam4(V self, V *args) {
  V v_m_24159 = args[0];
  V v_d_24160 = args[1];
  V v_sigs_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24161 = ({ V a_0 = v_sigs_2475; V a_1 = heff_rfield(v_d_24160, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_sigs_2475); r_; });
  {
    V v_field_24163 = v_t_24161.f[1];
    int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
    if ((v_tag_24162 == ((int64_t)0ULL))) {
      V v_s_24164 = v_field_24163;
      return ({ V a_0 = v_m_24159; V b_1 = heff_get_n(v_d_24160, 0, 3); V a_2 = v_s_24164; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_s_24164); r_; });
    } else {
      heff_drop_rec(v_d_24160, 3);
      heff_drop(v_field_24163);
      return v_m_24159;
    }
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam7(V self, V *args) {
  V v_h_24178 = args[0];
  V v_s_24174 = heff_env(self)[0];
  V v_sg_24173 = heff_env(self)[1];
  V v_n_24179 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_24174, 0)));
  V v_t_24180 = (g_list_2ereplicate(v_n_24179, NTAG(TAG_RepV)));
  heff_clo_take(self, 2);
  V v_d_24181 = ({ V rv_0 = v_t_24180; V rv_1 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_s_24174, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  HeffT2 v_t_24182 = ({ V a_0 = v_sg_24173; V a_1 = v_h_24178; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_sg_24173); heff_drop(v_h_24178); r_; });
  {
    V v_field_24184 = v_t_24182.f[1];
    int64_t v_tag_24183 = ((int64_t)v_t_24182.f[0]);
    if ((v_tag_24183 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_24181, 2);
      V v_x_24185 = v_field_24184;
      return v_x_24185;
    } else {
      heff_drop(v_field_24184);
      return v_d_24181;
    }
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam6(V self, V *args) {
  V v_m_24176 = args[0];
  V v_k_24177 = args[1];
  V v_s_24174 = heff_env(self)[0];
  V v_sg_24173 = heff_env(self)[1];
  V v_ks_24175 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24186 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam7, 1, 2, (V[]){heff_dup(v_s_24174), v_sg_24173}), v_ks_24175));
  V v_t_24187 = ({ V a_0 = v_s_24174; V a_1 = v_t_24186; V r_ = (g_list_2efoldl_24s932544939x1448830416(a_0, a_1)); heff_drop(v_t_24186); r_; });
  return ({ V a_0 = v_m_24176; V a_1 = v_k_24177; V a_2 = v_t_24187; V r_ = (g_heff_2ecompile_2eworker_2ewithSig(a_0, a_1, a_2)); heff_drop(v_k_24177); r_; });
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam5(V self, V *args) {
  V v_sg_24167 = args[0];
  V v_x3_24168 = args[1];
  V v_js_24158 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24168)) {
  case TAG_MkPair: {
    V v_k_24169 = heff_field(v_x3_24168, 0);
    V v_s_24170 = heff_field(v_x3_24168, 1);
    heff_take_n(v_x3_24168, 3ULL, 2);
    V v_xs_24171 = (g_heff_2ecompile_2eworker_2ecycleOf(v_js_24158, v_k_24169));
    V v_x_24172 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24171; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24171); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_x_24172)) {
      V v_sg_24173 = v_sg_24167;
      V v_s_24174 = v_s_24170;
      heff_clo_take(self, 1);
      V v_ks_24175 = ({ V a_0 = v_js_24158; V a_1 = v_k_24169; V r_ = (g_heff_2ecompile_2eworker_2ecycleOf(a_0, a_1)); heff_drop(v_js_24158); heff_drop(v_k_24169); r_; });
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecomponents_2ecomputed_lam6, 2, 3, (V[]){v_s_24174, heff_dup(v_sg_24173), heff_dup(v_ks_24175)}); V a_1 = v_sg_24173; V a_2 = v_ks_24175; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ks_24175); r_; });
    } else {
      heff_drop(self);
      heff_drop(v_k_24169);
      heff_drop(v_s_24170);
      return v_sg_24167;
    }
  }
  default: return heff_nomatch(v_x3_24168);
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam8(V self, V *args) {
  V v_m_24192 = args[0];
  V v_g_24193 = args[1];
  V v_w_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24194 = ({ V b_0 = heff_get_n(v_w_241, 2, 5); V a_1 = v_g_24193; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_24196 = v_t_24194.f[1];
    int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
    if ((v_tag_24195 == ((int64_t)0ULL))) {
      V v_is_24197 = v_field_24196;
      return ({ V a_0 = v_m_24192; V a_1 = v_g_24193; V a_2 = v_is_24197; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_g_24193); heff_drop(v_is_24197); r_; });
    } else {
      heff_drop(v_g_24193);
      heff_drop(v_field_24196);
      return v_m_24192;
    }
  }
}
V g_heff_2ecompile_2ecomponents_2ecomputed_lam9(V self, V *args) {
  V v_x3_24201 = args[0];
  V v_sigs_24190 = heff_env(self)[0];
  V v_bor_24200 = heff_env(self)[1];
  switch (heff_tag_of(v_x3_24201)) {
  case TAG_MkPair: {
    V v_k_24202 = heff_field(v_x3_24201, 0);
    V v_tr_24203 = heff_field(v_x3_24201, 1);
    heff_take_n(v_x3_24201, 3ULL, 2);
    heff_clo_take(self, 2);
    V v_t_24204 = ({ V a_0 = v_sigs_24190; V a_1 = v_k_24202; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_sigs_24190); r_; });
    V v_t_24205 = ({ V a_0 = v_bor_24200; V a_1 = v_k_24202; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_bor_24200); r_; });
    return heff_rec_n(4, shape_key__track__sig__lent, (V[]){v_k_24202, v_tr_24203, v_t_24204, v_t_24205});
  }
  default: return heff_nomatch(v_x3_24201);
  }
}