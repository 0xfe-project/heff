// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_names 305943394
#define LBL_off 319465
#define LBL_out 319944
#define LBL_placed 961367912
#define LBL_plain 308106724
#define LBL_pool 9942243
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_pool__placed__out[] = {LBL_pool, LBL_placed, LBL_out};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
HeffT2 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efirstCalled(V, V);
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo;
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
V g_heff_2ecompile_2esimplify_2efollowerCopied(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerCopied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerCopied_clo;
V g_heff_2ecompile_2esimplify_2efollowerSet(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerSet_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efromKept_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ehandlerPushed(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2ematchOn(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchOn_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2eprunedArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedArm_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etoValues_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_list_2eall_24s673599783x290475791(V, V);
V g_list_2eall_24s673599783x290475791_entry(V self, V *a);
extern Clo g_list_2eall_24s673599783x290475791_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s740336339x1862813792(V, V);
V g_list_2efoldl_24s740336339x1862813792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s740336339x1862813792_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1891751394x1524628247(V, V, V, V, V);
V g_list_2ezipWith_24s1891751394x1524628247_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1891751394x1524628247_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V v_e_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_fuel_243 = heff_take_field(v_s_241, 1);
  V v_defs_244 = heff_take_field(v_s_241, 2);
  V v_safe_245 = heff_take_field(v_s_241, 3);
  V v_base_246 = heff_take_field(v_s_241, 4);
  V v_total_247 = heff_take_field(v_s_241, 5);
  V v_plain_248 = heff_take_field(v_s_241, 6);
  V v_sp_249 = heff_take_field(v_s_241, 7);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), v_supply_242, v_e_240));
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_e_27_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_f_2416 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n_2415, v_fuel_243, v_defs_244, v_safe_245, v_base_246, v_total_247, v_plain_248, v_sp_249, v_kp_2410});
    return ((HeffT2){{v_e_27_2414, v_f_2416}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str0, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str1, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str2, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str3, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str4, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str5, 6, "intShl");

static V g_heff_2ecompile_2esimplify_2efailing_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2efailing_st;
static V g_heff_2ecompile_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str4), v_t_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str5), v_t_242});
}
V g_heff_2ecompile_2esimplify_2efailing_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2efailing_st)) return g_heff_2ecompile_2esimplify_2efailing_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2efailing_val, &g_heff_2ecompile_2esimplify_2efailing_st, g_heff_2ecompile_2esimplify_2efailing_init);
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam32(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_243, v_x_240, 0)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_249 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_248));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_m_249, v_xs_247});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_e_242, 0);
    V v_argv_2415 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2416 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_f_2414));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 1, 4, (V[]){v_m_2416, heff_dup(v_x_240), v_a_241, v_argv_2415});
  }
  case TAG_ELet: {
    V v_y_2427 = heff_field(v_e_242, 0);
    V v_e2_2428 = heff_field(v_e_242, 1);
    V v_b_2429 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2430 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_e2_2428));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam5, 1, 5, (V[]){v_m_2430, heff_dup(v_x_240), v_a_241, v_b_2429, v_y_2427});
  }
  case TAG_ERecord: {
    V v_fs_2439 = heff_field(v_e_242, 0);
    V v_ts_2440 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2449 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam6, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_fs_2439));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2449, v_ts_2440});
  }
  case TAG_EProj: {
    V v_e2_2454 = heff_field(v_e_242, 0);
    V v_l_2455 = heff_field(v_e_242, 1);
    V v_sh_2456 = heff_field(v_e_242, 2);
    V v_t_2457 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_m_2458 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2454));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam9, 1, 4, (V[]){v_m_2458, v_l_2455, v_sh_2456, v_t_2457});
  }
  case TAG_ETag: {
    V v_t_2463 = heff_field(v_e_242, 0);
    V v_argv_2464 = heff_field(v_e_242, 1);
    V v_ts_2465 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2467 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_2464));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam11, 1, 3, (V[]){v_m_2467, v_t_2463, v_ts_2465});
  }
  case TAG_EMatch: {
    V v_s_2472 = heff_field(v_e_242, 0);
    V v_arms_2473 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2474 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_s_2472));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam12, 1, 4, (V[]){v_m_2474, heff_dup(v_x_240), v_a_241, v_arms_2473});
  }
  case TAG_EPrim: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam15, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_e_242, 0);
    V v_argv_2495 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2497 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam16, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_2495));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_m_2497, v_p_2494});
  }
  case TAG_ECall: {
    V v_g_24102 = heff_field(v_e_242, 0);
    V v_argv_24103 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24105 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_24103));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_m_24105, v_g_24102});
  }
  case TAG_EInt: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam20, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBytes: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBool: {
    V v_c_24124 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_m_24126 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam27, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_c_24124));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam28, 1, 1, (V[]){v_m_24126});
  }
  case TAG_ESet: {
    V v_ys_24131 = heff_field(v_e_242, 0);
    V v_e2_24132 = heff_field(v_e_242, 1);
    V v_b_24133 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_24134 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_e2_24132));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam29, 1, 5, (V[]){v_m_24134, heff_dup(v_x_240), v_a_241, v_b_24133, v_ys_24131});
  }
  case TAG_EValues: {
    V v_es_24143 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_m_24145 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam30, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_es_24143));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam31, 1, 1, (V[]){v_m_24145});
  }
  case TAG_EFix: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam32, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esubstCopies(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_x_2412}), v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_q_2421 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2421; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_m_2422 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam4, 1, 2, (V[]){v_x_240, v_a_241}), v_argv_2415));
    V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2420}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      V v_x_2426 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2419, v_x_2424));
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2425});
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2429 = heff_env(self)[3];
  V v_y_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_m_2435 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_2429; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    V v_x2_2436 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2427, v_x_2433, v_x_2437}), v_s_2438});
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2442, v_x_2447}), v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_p_2441 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2441)) {
  case TAG_MkPair: {
    V v_l_2442 = heff_field(v_p_2441, 0);
    V v_e_2443 = heff_field(v_p_2441, 1);
    heff_take_n(v_p_2441, 3ULL, 2);
    V v_m_2444 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_e_2443; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_m_2444, v_l_2442});
  }
  default: return heff_nomatch(v_p_2441);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_ts_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2452, v_ts_2440}), v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_l_2455 = heff_env(self)[1];
  V v_sh_2456 = heff_env(self)[2];
  V v_t_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2461, v_l_2455, v_sh_2456, v_t_2457}), v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_q_2466 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2466; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_s_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_t_2463 = heff_env(self)[1];
  V v_ts_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_s_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_s_2471 = heff_field(v_x2_2469, 1);
    V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2463, v_x_2470, v_ts_2465}), v_s_2471});
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_t_2480 = heff_env(self)[1];
  V v_vs_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2480, v_vs_2481, v_x_2486}), v_s_2487});
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_a_2479 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2479)) {
  case TAG_MkArm: {
    V v_t_2480 = heff_field(v_a_2479, 0);
    V v_vs_2481 = heff_field(v_a_2479, 1);
    V v_b_2482 = heff_field(v_a_2479, 2);
    heff_take_n(v_a_2479, 7ULL, 3);
    V v_m_2483 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_2482; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam14, 1, 3, (V[]){v_m_2483, v_t_2480, v_vs_2481});
  }
  default: return heff_nomatch(v_a_2479);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2473 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_s_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    V v_m_2488 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam13, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2473));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2478}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2477, v_x_2490}), v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2493 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_2493});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_q_2496 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2496; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_s_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  V v_p_2494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_s_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    V v_s_24101 = heff_field(v_x2_2499, 1);
    V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2494, v_x_24100}), v_s_24101});
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_q_24104 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_24104; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_s_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_g_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_s_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_s_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24102, v_x_24108}), v_s_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24111 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24111});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24113 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24115 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24115});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24117 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24117});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24120 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24120});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24122 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24122});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24123 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args) {
  V v_q_24125 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_24125; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam28(V self, V *args) {
  V v_s_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_s_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24129}), v_s_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam29(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_24133 = heff_env(self)[3];
  V v_ys_24131 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_m_24139 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_24133; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    V v_x2_24140 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_s_24138}));
    switch (heff_tag_of(v_x2_24140)) {
    case TAG_MkPair: {
      V v_x_24141 = heff_field(v_x2_24140, 0);
      V v_s_24142 = heff_field(v_x2_24140, 1);
      heff_take_n(v_x2_24140, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_24131, v_x_24137, v_x_24141}), v_s_24142});
    }
    default: return heff_nomatch(v_x2_24140);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam30(V self, V *args) {
  V v_q_24144 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_24144; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam31(V self, V *args) {
  V v_s_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_s_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_s_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24148}), v_s_24149});
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam32(V self, V *args) {
  V v_s_24152 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24152});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str1, 2, "$_");

HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eapartOf_24cpr(v_x_240, v_b_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_ap_246 = v_field_245;
      V v_tags_247 = heff_take_field(v_ap_246, 0);
      V v_names_248 = heff_take_field(v_ap_246, 1);
      V v_body_249 = heff_get_n(v_ap_246, 2, 3);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2etoValues_24cpr(v_tags_247, v_a_241));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2412;
          V v_ys_2414 = v_names_248;
          V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2414));
          V v_t_2416 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL))));
          V v_t_2417 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str0); V a_1 = v_x_240; V a_2 = ((V)&g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str1); V a_3 = v_ys_2414; V a_4 = v_t_2416; V r_ = (g_list_2ezipWith_24s1891751394x1524628247(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_f_2418 = heff_tag_n(TAG_ESet, 3, (V[]){v_t_2417, v_x_2413, v_body_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
        } else {
          heff_drop(v_x_240);
          heff_drop(v_names_248);
          heff_drop(v_body_249);
          heff_drop(v_field_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletSplit(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2421 = heff_field(v_a_242, 0);
    V v_argv_2422 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EApp = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_x2_2423 = heff_tr(g_heff_2ecompile_2esimplify_2esplitArgs(v_argv_2422, v_z_244));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_args_2426 = heff_take_field(v_x_2424, 1);
      V v_binds_2427 = heff_get_n(v_x_2424, 0, 2);
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2429 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), v_t_2428));
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2431 = (g_heff_2ecompile_2eir_2elamW(v_x_241, v_t_2430));
      V v_t_2432 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2429, v_t_2431}), 0, 2);
      V v_x2_2433 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, heff_tag_at_n(v_ru_24a_242_24EApp, TAG_EApp, 2, (V[]){v_f_2421, v_args_2426}), v_b_243, v_t_2432, v_s_2425));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_s_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        V v_x_2436 = ({ V a_0 = v_binds_2427; V a_1 = v_x_2434; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_binds_2427); r_; });
        return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_s_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2442}), v_s_2443});
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_ERecord: {
    V v_m_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_s_2449 = heff_field(v_x2_2447, 1);
      V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2448}), v_s_2449});
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  case TAG_EProj: {
    V v_m_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_MkPair: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_s_2457 = heff_field(v_x2_2455, 1);
      V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2456}), v_s_2457});
    }
    default: return heff_nomatch(v_x2_2455);
    }
  }
  case TAG_ETag: {
    V v_m_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2463}), v_s_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  case TAG_EMatch: {
    V v_m_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2468 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2468)) {
    case TAG_MkPair: {
      V v_x_2469 = heff_field(v_x2_2468, 0);
      V v_s_2470 = heff_field(v_x2_2468, 1);
      V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2469}), v_s_2470});
    }
    default: return heff_nomatch(v_x2_2468);
    }
  }
  case TAG_EPrim: {
    V v_m_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_s_2475 = heff_field(v_x2_2473, 1);
      V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2474}), v_s_2475});
    }
    default: return heff_nomatch(v_x2_2473);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2479)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_field(v_x2_2479, 0);
      V v_s_2481 = heff_field(v_x2_2479, 1);
      V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2480}), v_s_2481});
    }
    default: return heff_nomatch(v_x2_2479);
    }
  }
  case TAG_ECall: {
    V v_m_2484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_s_2487 = heff_field(v_x2_2485, 1);
      V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2486}), v_s_2487});
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  case TAG_EInt: {
    V v_m_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2491}), v_s_2492});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  case TAG_EFloat: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_s_2497 = heff_field(v_x2_2495, 1);
      V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2496}), v_s_2497});
    }
    default: return heff_nomatch(v_x2_2495);
    }
  }
  case TAG_EStr: {
    V v_m_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24100 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24100)) {
    case TAG_MkPair: {
      V v_x_24101 = heff_field(v_x2_24100, 0);
      V v_s_24102 = heff_field(v_x2_24100, 1);
      V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24101}), v_s_24102});
    }
    default: return heff_nomatch(v_x2_24100);
    }
  }
  case TAG_EBytes: {
    V v_m_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24105 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24105)) {
    case TAG_MkPair: {
      V v_x_24106 = heff_field(v_x2_24105, 0);
      V v_s_24107 = heff_field(v_x2_24105, 1);
      V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24106}), v_s_24107});
    }
    default: return heff_nomatch(v_x2_24105);
    }
  }
  case TAG_EFixed: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24111)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_field(v_x2_24111, 0);
      V v_s_24113 = heff_field(v_x2_24111, 1);
      V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24112}), v_s_24113});
    }
    default: return heff_nomatch(v_x2_24111);
    }
  }
  case TAG_EFloat32: {
    V v_m_24115 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24116 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24116)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_field(v_x2_24116, 0);
      V v_s_24118 = heff_field(v_x2_24116, 1);
      V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24117}), v_s_24118});
    }
    default: return heff_nomatch(v_x2_24116);
    }
  }
  case TAG_EAbandon: {
    V v_m_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_s_24122 = heff_field(v_x2_24120, 1);
      V v_ru_24x2_24120_24MkPair = heff_take_reuse_n(v_x2_24120, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24121}), v_s_24122});
    }
    default: return heff_nomatch(v_x2_24120);
    }
  }
  case TAG_EBool: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24126}), v_s_24127});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  case TAG_ESet: {
    V v_m_24131 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24132 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24132)) {
    case TAG_MkPair: {
      V v_x_24133 = heff_field(v_x2_24132, 0);
      V v_s_24134 = heff_field(v_x2_24132, 1);
      V v_ru_24x2_24132_24MkPair = heff_take_reuse_n(v_x2_24132, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24133}), v_s_24134});
    }
    default: return heff_nomatch(v_x2_24132);
    }
  }
  case TAG_EValues: {
    V v_m_24136 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24137 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_s_24139 = heff_field(v_x2_24137, 1);
      V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24138}), v_s_24139});
    }
    default: return heff_nomatch(v_x2_24137);
    }
  }
  case TAG_EFix: {
    V v_m_24142 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24143)) {
    case TAG_MkPair: {
      V v_x_24144 = heff_field(v_x2_24143, 0);
      V v_s_24145 = heff_field(v_x2_24143, 1);
      V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24144}), v_s_24145});
    }
    default: return heff_nomatch(v_x2_24143);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2etestsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etestsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etestsOf(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    return MK_INT(0LL);
  }
  case TAG_CFalse: {
    return MK_INT(0LL);
  }
  case TAG_CRel: {
    return MK_INT(0LL);
  }
  case TAG_CTest: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_x21_245, 0);
      if (heff_strEq_c_lent(v_x_240, v_y_246, 0)) {
        return MK_INT(1LL);
      } else {
        return MK_INT(0LL);
      }
    }
    case TAG_EGlobal: {
      return MK_INT(0LL);
    }
    case TAG_ELam: {
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  case TAG_CNot: {
    V v_c_2445 = heff_field(v_x2_241, 0);
    V t_0 = v_x_240;
    V t_1 = v_c_2445;
    v_x_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2446 = heff_field(v_x2_241, 0);
    V v_b_2447 = heff_field(v_x2_241, 1);
    V v_c_2448 = heff_field(v_x2_241, 2);
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_a_2446));
    V v_t_2450 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_b_2447));
    V v_t_2451 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_2448));
    return heff_intAdd(heff_intAdd(v_t_2449, v_t_2450), v_t_2451);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etestsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedPast_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ehandedPast(V v_kinds_240, V v_b_241, V v_argv_242) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_b_241, 0);
    V v_x_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2edropL(v_t_249, v_argv_242));
      return ({ V a_0 = v_kinds_240; V a_1 = v_t_2410; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2410); r_; });
    } else {
      heff_drop(v_argv_242);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedPast(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V v_known_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_known_240;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_241, 0);
    V v_argv_2411 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_f_2410));
    V v_t_2414 = (g_list_2emap_24tok2(v_ru_24e_241_24EApp, heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0, 1, 1, (V[]){v_known_240}), v_argv_2411));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2412, v_t_2414}));
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_241, 0);
    V v_a_2416 = heff_field(v_e_241, 1);
    V v_b_2417 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_known_240;
    V t_1 = v_b_2417;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2430 = heff_field(v_e_241, 0);
    V v_arms_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2473 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1, 1, 2, (V[]){heff_dup(v_sc_2430), v_known_240}), v_arms_2431));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2430, v_t_2473}));
  }
  case TAG_EPrim: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBool: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2487 = heff_field(v_e_241, 0);
    V v_a_2488 = heff_field(v_e_241, 1);
    V v_b_2489 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2490 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2488));
    V v_cell_2491 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2487, v_t_2490, heff_hole()});
    V v_u_2492 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2491));
    heff_drop(v_u_2492);
    V t_0 = v_known_240;
    V t_1 = v_b_2489;
    V t_2 = v_cell_2491;
    V t_3 = MK_INT(2LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedFor_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2esimplify_2eprunedFor(v_known_240, v_a_2413));
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_sc_2430 = heff_env(self)[0];
  V v_known_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2472;
  switch (heff_tag_of(v_sc_2430)) {
  case TAG_EVar: {
    V v_x_2433 = heff_field(v_sc_2430, 0);
    V v_ru_24sc_2430_24EVar = heff_take_reuse_n(v_sc_2430, 1ULL, 1);
    v_t_2472 = ({ V a_0 = v_ru_24sc_2430_24EVar; V a_1 = v_known_240; V a_2 = v_x_2433; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(a_0, a_1, a_2)); heff_drop(v_x_2433); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_sc_2430, 0ULL, 4);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    v_t_2472 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_sc_2430);
  }
  return ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2eprunedFor_clo); V a_1 = v_known_240; V a_2 = v_t_2472; V a_3 = v_a_2432; V r_ = (g_heff_2ecompile_2esimplify_2eprunedArm(a_0, a_1, a_2, a_3)); heff_drop(v_t_2472); r_; });
}

HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_f_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_243 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 6), v_k_240, v_p_241));
    v_f_244 = ({ V rv_6 = v_t_243; V rr_ = heff_rec_reuse_nf(v_s_242, 447ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_f_244 = v_s_242;
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_244}});
}
Clo g_heff_2ecompile_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_245 = ({ V a_0 = v_kinds_240; V a_1 = v_g_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_g_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) && ({ V v_x_248 = heff_dup(v_field_247); int c_ = 1; heff_drop(v_x_248); c_; })));
      heff_drop(v_field_247);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EApp: {
    V v_t_2414 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2414);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2414);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ELet: {
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 3);
      heff_drop(v_t_2418);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2418);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ERecord: {
    V v_t_2421 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2421);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2421);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EProj: {
    V v_t_2426 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 4);
      heff_drop(v_t_2426);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2426);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ETag: {
    V v_t_2430 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 3);
      heff_drop(v_t_2430);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2430);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EMatch: {
    V v_t_2433 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2433);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2433);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EPrim: {
    V v_t_2435 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2435);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2435);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EPrimCall: {
    V v_t_2438 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2438);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2438);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ECall: {
    V v_t_2441 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2441);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2441);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EInt: {
    V v_t_2443 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2443);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2443);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFloat: {
    V v_t_2445 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2445);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2445);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EStr: {
    V v_t_2447 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2447);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2447);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EBytes: {
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2449);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2449);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFixed: {
    V v_t_2452 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2452);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2452);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFloat32: {
    V v_t_2454 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2454);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2454);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EAbandon: {
    V v_t_2455 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop(v_t_2455);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2455);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EBool: {
    V v_t_2457 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2457);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2457);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ESet: {
    V v_t_2461 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 3);
      heff_drop(v_t_2461);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2461);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EValues: {
    V v_t_2463 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2463);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFix: {
    V v_t_2466 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2466);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2466);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eknownArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_241, 0);
      V v_xs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2ekeepParams_24dps(v_ms_243, v_xs_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_argv_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ms_244;
        V t_1 = v_argv_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V v_s_240) {
top: ;
  V v_supply_241 = heff_take_field(v_s_240, 0);
  V v_defs_242 = heff_take_field(v_s_240, 2);
  V v_safe_243 = heff_take_field(v_s_240, 3);
  V v_base_244 = heff_take_field(v_s_240, 4);
  V v_total_245 = heff_take_field(v_s_240, 5);
  V v_sp_246 = heff_take_field(v_s_240, 7);
  V v_kp_247 = heff_get_n(v_s_240, 8, 9);
  V v_t_248 = ({ V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_sp_246, 95ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_f_249 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_241, MK_INT(4000LL), v_defs_242, v_safe_243, v_base_244, v_total_245, heff_dup(g_std_2emap_2eempty_get()), v_t_248, v_kp_247});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_249}});
}

HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V v_x1_240, V v_h_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_p_242, 4), heff_dup(v_h_241), NTAG(TAG_MkUnit)));
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_p_242, 3), v_h_241, NTAG(TAG_MkUnit)));
    V v_f_245 = ({ V rv_3 = v_t_244; V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_245}});
  } else {
    heff_drop(v_h_241);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_242}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_h_240);
      heff_drop(v_v_241);
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      return ((HeffT2){{NTAG(TAG_True), v_s_242}});
    } else {
      heff_drop(v_field_246);
      V v_k_248 = heff_take_field(v_s_242, 8);
      V v_vers_249 = heff_take_field(v_k_248, 0);
      V v_kept_2410 = heff_take_field(v_k_248, 1);
      V v_touched_2411 = heff_take_field(v_k_248, 2);
      V v_fresh_2412 = heff_take_field(v_k_248, 3);
      V v_madeFresh_2413 = heff_get_n(v_k_248, 4, 5);
      V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(v_vers_249, heff_dup(v_h_240), v_v_241));
      V v_k_2415 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_t_2414, v_kept_2410, v_touched_2411, v_fresh_2412, v_madeFresh_2413});
      V v_t_2416 = ({ V rv_8 = v_k_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      return (g_heff_2ecompile_2esimplify_2efromKept_24cpr(v_h_240, v_t_2416));
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerPushed_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerPushed(V v_arms_240, V v_argv_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s1531069132x955165792(heff_dup(v_argv_241)));
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_242); r_; });
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_list_2eany_24s860380051x1466609135(v_argv_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_argv_245 = (g_list_2ekeepIf_24s183165982x1490920686(v_argv_241));
      V v_t_246 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_245)));
      V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_246); r_; });
      V v_ret_24bool = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_245))); int c_ = ({ V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_240)); int c_ = ({ V v_t_2410 = heff_intMul(heff_dup(v_t_248), heff_intSub(heff_dup(v_t_249), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2410, MK_INT(120LL), 2); heff_drop(v_t_2410); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; })));
      heff_drop(v_argv_245);
      heff_drop(v_t_247);
      return v_ret_24bool;
    } else {
      heff_drop(v_argv_241);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_argv_241);
    heff_drop(v_t_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerPushed(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efollowerSet_str0, 1, "v");
V g_heff_2ecompile_2esimplify_2efollowerSet_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowerSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efollowerSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerSet_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2efollowerSet(V v_r_240, V v_orig_241, V v_k_242, V v_f_243, V v_s_244, V v_arms_245, V v_argv_246, V v_s_247) {
top: ;
  V v_m_2417 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerSet_lam0, 1, 2, (V[]){heff_dup(v_r_240), v_argv_246}), v_arms_245));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_dup(v_s_247)}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_n_2421 = (g_heff_2ecompile_2esimplify_2efirstCalled(v_k_242, heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_244), heff_dup(v_x_2419)})));
    HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(v_k_242, heff_dup(v_n_2421), heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_244), heff_dup(v_x_2419)})));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_m2_2425 = v_field_2424;
        if ((heff_intLt_c_lent(MK_INT(0LL), v_n_2421, 1) && ({ V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m2_2425), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2427 = (g_heff_2ecompile_2eir_2ecountW(v_k_242, MK_INT(0LL), heff_dup(v_t_2426))); int c_ = ({ V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m2_2425), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2429 = (g_heff_2ecompile_2eir_2elamW(v_k_242, heff_dup(v_t_2428))); int c_ = ({ V v_t_2440 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2427), heff_dup(v_t_2429)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2440, MK_INT(0LL), 2); heff_drop(v_t_2440); c_; }); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2427); c_; }); heff_drop(v_t_2426); c_; }))) {
          heff_drop(v_orig_241);
          heff_drop(v_s_244);
          heff_drop(v_s_247);
          heff_drop(v_x_2419);
          HeffT2 v_t_2430 = (g_heff_2ecompile_2esimplify_2efreshNames_24cpr(((V)&g_heff_2ecompile_2esimplify_2efollowerSet_str0), v_n_2421, v_s_2420));
          {
            V v_field_2431 = v_t_2430.f[0];
            V v_field_2432 = v_t_2430.f[1];
            V v_x_2433 = v_field_2431;
            V v_s_2434 = v_field_2432;
            V v_t_2435 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2433)));
            V v_m_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_f_243, v_t_2435}));
            V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2434}));
            switch (heff_tag_of(v_x2_2437)) {
            case TAG_MkPair: {
              V v_x_2438 = heff_field(v_x2_2437, 0);
              V v_s_2439 = heff_field(v_x2_2437, 1);
              heff_take_n(v_x2_2437, 3ULL, 2);
              return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_x_2433, v_m2_2425, v_x_2438}), v_s_2439});
            }
            default: return heff_nomatch(v_x2_2437);
            }
          }
        } else {
          heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
          heff_drop(v_n_2421);
          heff_drop(v_m2_2425);
          return (g_heff_2ecompile_2esimplify_2efollowerCopied(v_r_240, v_s_247, v_orig_241, v_k_242, v_f_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_244, v_x_2419}), v_s_2420));
        }
      } else {
        heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
        heff_drop(v_n_2421);
        heff_drop(v_field_2424);
        return (g_heff_2ecompile_2esimplify_2efollowerCopied(v_r_240, v_s_247, v_orig_241, v_k_242, v_f_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_244, v_x_2419}), v_s_2420));
      }
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerSet_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2efollowerSet(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2efollowerSet_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_vs_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_vs_2410, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerSet_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_argv_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkArm: {
    V v_t_249 = heff_field(v_a_248, 0);
    V v_vs_2410 = heff_field(v_a_248, 1);
    V v_b_2411 = heff_field(v_a_248, 2);
    heff_take_n(v_a_248, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2esimplify_2eapplyArm(v_r_240, v_b_2411, v_argv_246));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerSet_lam1, 1, 3, (V[]){v_m_2412, v_t_249, v_vs_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_str3, 5, "False");
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_arms_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    v_t_245 = (g_list_2eall_24s673599783x290475791(v_s_241, v_arms_242));
    break;
  }
  default: heff_nomatch(v_arms_242);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_arms_242);
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam0, 1, 1, (V[]){v_s_241});
  } else {
    heff_drop(v_t_245);
    HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(heff_dup(v_arms_242)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_249;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_MkPair: {
          V v_t_2411 = heff_field(v_it1_2410, 0);
          V v_f_2412 = heff_field(v_it1_2410, 1);
          heff_take_n(v_it1_2410, 3ULL, 2);
          V v_t_2413 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_t_2411)));
          V v_t_2416;
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            V v_t_2414 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_f_2412)));
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              V v_t_2415 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_t_2411)));
              if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                heff_drop(v_t_2415);
                v_t_2416 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2415);
                v_t_2416 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_f_2412)));
              }
            } else {
              heff_drop(v_t_2414);
              v_t_2416 = NTAG(TAG_False);
            }
          } else {
            heff_drop(v_t_2413);
            v_t_2416 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
            heff_drop(v_r_240);
            heff_drop(v_arms_242);
            heff_drop(v_t_2416);
            V v_t_2417 = (g_heff_2ecompile_2eir_2econdOf(v_s_241));
            V v_t_2418 = (g_heff_2ecompile_2eir_2econdOf(v_t_2411));
            V v_t_2419 = (g_heff_2ecompile_2eir_2econdOf(v_f_2412));
            V v_t_2420 = (g_heff_2ecompile_2eir_2econdIf(v_t_2417, v_t_2418, v_t_2419));
            V v_c_2421 = (g_heff_2ecompile_2esimplify_2efoldCond(v_t_2420));
            return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam1, 1, 1, (V[]){v_c_2421});
          } else {
            heff_drop(v_t_2411);
            heff_drop(v_f_2412);
            heff_drop(v_t_2416);
            V v_t_2432 = (g_heff_2ecompile_2eir_2econdOf(v_s_241));
            V v_c_2433 = (g_heff_2ecompile_2esimplify_2efoldCond(v_t_2432));
            V v_t_2442;
            switch (heff_tag_of(v_c_2433)) {
            case TAG_CTrue: {
              v_t_2442 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
              break;
            }
            case TAG_CFalse: {
              v_t_2442 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_str3), NTAG(TAG_Nil), NTAG(TAG_Nil)});
              break;
            }
            case TAG_CRel: {
              v_t_2442 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2433});
              break;
            }
            case TAG_CTest: {
              V v_e_2437 = heff_field(v_c_2433, 0);
              heff_take_n(v_c_2433, 1ULL, 1);
              v_t_2442 = v_e_2437;
              break;
            }
            case TAG_CNot: {
              v_t_2442 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2433});
              break;
            }
            case TAG_CIf: {
              v_t_2442 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2433});
              break;
            }
            default: heff_nomatch(v_c_2433);
            }
            HEFF_LAST return g_heff_2ecompile_2esimplify_2ematchOn(v_r_240, v_t_2442, v_arms_242);
          }
        }
        default: return heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_field_249);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2ematchOn(v_r_240, v_s_241, v_arms_242);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_s_241, v_s_246});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_2422 = args[0];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431;
  switch (heff_tag_of(v_c_2421)) {
  case TAG_CTrue: {
    v_t_2431 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    break;
  }
  case TAG_CFalse: {
    v_t_2431 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    break;
  }
  case TAG_CRel: {
    v_t_2431 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2421});
    break;
  }
  case TAG_CTest: {
    V v_e_2426 = heff_field(v_c_2421, 0);
    heff_take_n(v_c_2421, 1ULL, 1);
    v_t_2431 = v_e_2426;
    break;
  }
  case TAG_CNot: {
    v_t_2431 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2421});
    break;
  }
  case TAG_CIf: {
    v_t_2431 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2421});
    break;
  }
  default: heff_nomatch(v_c_2421);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, v_s_2422});
}
V g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(V v_b_240, V v_s_241) {
top: ;
  V v_sp_242 = heff_take_field(v_s_241, 7);
  V v_kp_243 = heff_take_field(v_s_241, 8);
  V v_supply_244 = heff_take_field(v_s_241, 0);
  V v_fuel_245 = heff_take_field(v_s_241, 1);
  V v_defs_246 = heff_take_field(v_s_241, 2);
  V v_safe_247 = heff_take_field(v_s_241, 3);
  V v_base_248 = heff_take_field(v_s_241, 4);
  V v_total_249 = heff_take_field(v_s_241, 5);
  V v_plain_2410 = heff_get_n(v_s_241, 6, 9);
  V v_t_2411 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_240));
  V v_hs_2412 = (g_heff_2ecompile_2eir_2enubI(v_t_2411));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0, 2, 1, (V[]){heff_dup(v_sp_242)}); V a_1 = heff_dup(heff_rfield(v_kp_243, 2)); V a_2 = v_hs_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_2412); r_; });
  V v_k_2420 = v_kp_243;
  V v_vers_2421 = heff_take_field(v_k_2420, 0);
  V v_kept_2422 = heff_take_field(v_k_2420, 1);
  V v_fresh_2423 = heff_take_field(v_k_2420, 3);
  V v_madeFresh_2424 = heff_get_n(v_k_2420, 4, 5);
  V v_f_2425 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_244, v_fuel_245, v_defs_246, v_safe_247, v_base_248, v_total_249, v_plain_2410, v_sp_242, heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2421, v_kept_2422, v_t_2419, v_fresh_2423, v_madeFresh_2424})});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2425}});
}
V g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_h_2414 = args[1];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_sp_242, 2, 7); V a_1 = v_h_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      heff_drop(v_x_2418);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2414, v_acc_2413});
    } else {
      heff_drop(v_h_2414);
      heff_drop(v_field_2417);
      return v_acc_2413;
    }
  }
}
V g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(V v_k_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 4, 5);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_k_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_f_2426;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_t_247 = v_field_246;
      V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_241));
      V v_hs_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
      V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0, 2, 1, (V[]){heff_dup(v_s_242)}); V a_1 = v_t_247; V a_2 = v_hs_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_249); r_; });
      V v_k_2418 = heff_take_field(v_s_242, 8);
      V v_vers_2419 = heff_take_field(v_k_2418, 0);
      V v_kept_2420 = heff_take_field(v_k_2418, 1);
      V v_touched_2421 = heff_take_field(v_k_2418, 2);
      V v_fresh_2422 = heff_take_field(v_k_2418, 3);
      V v_madeFresh_2423 = heff_get_n(v_k_2418, 4, 5);
      V v_t_2424 = (g_std_2emap_2einsert_24s93785294x875597928(v_madeFresh_2423, v_k_240, v_t_2417));
      V v_k_2425 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2419, v_kept_2420, v_touched_2421, v_fresh_2422, v_t_2424});
      v_f_2426 = ({ V rv_8 = v_k_2425; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    } else {
      heff_drop(v_k_240);
      heff_drop(v_b_241);
      heff_drop(v_field_246);
      v_f_2426 = v_s_242;
    }
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2426}});
}
V g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_h_2411 = args[1];
  V v_s_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_get_n(heff_get_n(v_s_242, 7, 9), 2, 7);
  HeffT2 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2415;
      heff_drop(v_x_2416);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2411, v_acc_2410});
    } else {
      heff_drop(v_h_2411);
      heff_drop(v_field_2415);
      return v_acc_2410;
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecanonVisit_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecanonVisit(V v_c_240, V v_h_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_c_240, 0), v_h_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_245 = v_field_244;
      HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_c_240, 1), v_h_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          heff_drop_rec(v_d_245, 3);
          V v_x_249 = v_field_248;
          heff_drop(v_x_249);
          return v_c_240;
        } else {
          heff_drop(v_field_248);
          V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_c_240, 1), v_h_241, NTAG(TAG_MkUnit)));
          V v_t_2411 = ({ V rv_1 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_c_240, 5ULL, 3, shape_pool__placed__out, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_245, 2))));
          V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
          V v_c_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2ecanonVisit_clo); V a_1 = v_t_2411; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
          V v_pool_2415 = heff_take_field(v_c_2414, 0);
          V v_placed_2416 = heff_take_field(v_c_2414, 1);
          V v_out_2417 = heff_get_n(v_c_2414, 2, 3);
          return heff_rec_n(3, shape_pool__placed__out, (V[]){v_pool_2415, v_placed_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_d_245, v_out_2417})});
        }
      }
    } else {
      heff_drop(v_h_241);
      heff_drop(v_field_244);
      return v_c_240;
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecanonVisit(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2einOrder_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_lam2, 1, 0};
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2einOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2einOrder(V v_b_240, V v_made_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s740336339x1862813792(heff_dup(g_std_2emap_2eempty_get()), v_made_241));
  V v_t_243 = heff_rec_n(3, shape_pool__placed__out, (V[]){v_t_242, heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil)});
  V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_240));
  V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
  V v_x_246 = ({ V a_0 = v_t_243; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s419339443x1702462498(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_placed_247 = heff_take_field(v_x_246, 1);
  V v_out_248 = heff_get_n(v_x_246, 2, 3);
  return heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam0, 1, 3, (V[]){v_placed_247, v_made_241, v_out_248});
}
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einOrder(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2415});
}
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args) {
  V v_d_2410 = args[0];
  V v_placed_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = ({ V a_0 = v_placed_247; V a_1 = heff_rfield(v_d_2410, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_placed_247); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_2410, 3);
      V v_x_2414 = v_field_2413;
      heff_drop(v_x_2414);
      return ((V)&g_heff_2ecompile_2esimplify_2einOrder_lam2_clo);
    } else {
      heff_drop(v_field_2413);
      V f_ = ((V)&g_heff_2ecompile_2esimplify_2eunmade_clo);
      args[0] = heff_get_n(v_d_2410, 0, 3);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_placed_247 = heff_env(self)[0];
  V v_made_241 = heff_env(self)[1];
  V v_out_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2416 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam1, 1, 1, (V[]){v_placed_247}), v_made_241));
  V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 2ULL, 2);
    V v_x_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_out_248));
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}