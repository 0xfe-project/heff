// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Leaf 13717
#define TAG_Plus 9189
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_syntax 1059664654
V g_heff_2eelab_2eeffect_2eappendE(V, V);
V g_heff_2eelab_2eeffect_2eappendE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eappendE_clo;
V g_heff_2eelab_2eeffect_2eappendE_24dps(V, V, V);
V g_heff_2eelab_2eeffect_2eappendE_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eappendE_24dps_clo;
HeffT2 g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(V, V);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2edropLastD_24dps(V, V);
V g_heff_2eelab_2eeffect_2edropLastD_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_24dps_clo;
HeffT2 g_heff_2eelab_2eeffect_2eeffectOf_24cpr(V, V);
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2eelab_2eeffect_2eappendE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2eappendE_entry, 2, 0};

V g_heff_2eelab_2eeffect_2eappendE(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eeffect_2eappendE_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeffect_2eappendE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeffect_2eappendE(a[0], a[1]);
}
Clo g_heff_2eelab_2eeffect_2eappendE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2eappendE_24dps_entry, 3, 0};

V g_heff_2eelab_2eeffect_2eappendE_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeffect_2eappendE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeffect_2eappendE_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eeffect_2eleaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2eleaves_entry, 1, 0};

V g_heff_2eelab_2eeffect_2eleaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_x_241 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
  }
  case TAG_Plus: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_b_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2eeffect_2eleaves(v_a_242));
    V v_t_245 = (g_heff_2eelab_2eeffect_2eleaves(v_b_243));
    return (g_heff_2eelab_2eeffect_2eappendE(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eeffect_2eleaves(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eeffect_2edropLastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2edropLastD_entry, 1, 0};

V g_heff_2eelab_2eeffect_2edropLastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eeffect_2edropLastD_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeffect_2edropLastD(a[0]);
}
Clo g_heff_2eelab_2eeffect_2edropLastD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2edropLastD_24dps_entry, 2, 0};

V g_heff_2eelab_2eeffect_2edropLastD_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeffect_2edropLastD_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeffect_2edropLastD_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eeffect_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeffect_2elastOr_entry, 2, 0};

V g_heff_2eelab_2eeffect_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eeffect_2elastOr(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eeffect_2eeffectOf_24cpr_str0, 7, "co.plus");
HEFF_LIT(g_heff_2eelab_2eeffect_2eeffectOf_24cpr_str1, 6, "co.<+>");

HeffT2 g_heff_2eelab_2eeffect_2eeffectOf_24cpr(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_SLocal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_k_243 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24SGlobal = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 1), v_k_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_e_248 = v_field_246;
        HeffT2 v_t_249 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, heff_get_n(v_e_248, 0, 4)));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            heff_drop_cell(v_ru_24e_241_24SGlobal, 1);
            V v_e_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2413}});
          } else {
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SGlobal, TAG_Leaf, 1, (V[]){v_k_243})}});
          }
        }
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 2), v_k_243));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_k2_2418 = v_field_2416;
            HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_g_240, 1); V a_1 = v_k2_2418; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k2_2418); r_; });
            {
              V v_field_2421 = v_t_2419.f[1];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                V v_entry_2423 = v_field_2421;
                HeffT2 v_t_2424 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, heff_get_n(v_entry_2423, 0, 4)));
                {
                  V v_field_2426 = v_t_2424.f[1];
                  int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                  if ((v_tag_2425 == ((int64_t)0ULL))) {
                    heff_drop(v_k_243);
                    heff_drop_cell(v_ru_24e_241_24SGlobal, 1);
                    V v_e_2428 = v_field_2426;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2428}});
                  } else {
                    heff_drop(v_field_2426);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SGlobal, TAG_Leaf, 1, (V[]){v_k_243})}});
                  }
                }
              } else {
                heff_drop_rec(v_g_240, 8);
                heff_drop(v_field_2421);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SGlobal, TAG_Leaf, 1, (V[]){v_k_243})}});
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_field_2416);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SGlobal, TAG_Leaf, 1, (V[]){v_k_243})}});
          }
        }
      }
    }
  }
  case TAG_SCode: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    V v_e1_2430 = heff_field(v_e_241, 0);
    V v_b_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24SApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2430)) {
    case TAG_SLocal: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      V v_k_2433 = heff_field(v_e1_2430, 0);
      V v_ru_24e1_2430_24SGlobal = heff_take_reuse_n(v_e1_2430, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e1_2430_24SGlobal, TAG_Leaf, 1, (V[]){v_k_2433})}});
    }
    case TAG_SCode: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      V v_e11_2435 = heff_field(v_e1_2430, 0);
      V v_a_2436 = heff_field(v_e1_2430, 1);
      heff_take_n(v_e1_2430, 3ULL, 2);
      switch (heff_tag_of(v_e11_2435)) {
      case TAG_SLocal: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        V v_p_2438 = heff_field(v_e11_2435, 0);
        heff_take_n(v_e11_2435, 1ULL, 1);
        if (heff_strEq_c_lent(v_p_2438, ((V)&g_heff_2eelab_2eeffect_2eeffectOf_24cpr_str0), 2)) {
          heff_drop(v_p_2438);
          HeffT2 v_t_2440 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(heff_dup(v_g_240), v_a_2436));
          {
            V v_field_2442 = v_t_2440.f[1];
            int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
            HeffT2 v_t_2443 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, v_b_2431));
            {
              V v_field_2445 = v_t_2443.f[1];
              int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
              if ((v_tag_2441 == ((int64_t)0ULL))) {
                V v_a_2447 = v_field_2442;
                if ((v_tag_2444 == ((int64_t)0ULL))) {
                  V v_b_2449 = v_field_2445;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SApp, TAG_Plus, 2, (V[]){v_a_2447, v_b_2449})}});
                } else {
                  heff_drop_cell(v_ru_24e_241_24SApp, 2);
                  heff_drop(v_field_2445);
                  heff_drop(v_a_2447);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop_cell(v_ru_24e_241_24SApp, 2);
                heff_drop(v_field_2442);
                heff_drop(v_field_2445);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
        } else {
          if (heff_strEq_c(v_p_2438, ((V)&g_heff_2eelab_2eeffect_2eeffectOf_24cpr_str1))) {
            HeffT2 v_t_2451 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(heff_dup(v_g_240), v_a_2436));
            {
              V v_field_2453 = v_t_2451.f[1];
              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
              HeffT2 v_t_2454 = (g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, v_b_2431));
              {
                V v_field_2456 = v_t_2454.f[1];
                int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                if ((v_tag_2452 == ((int64_t)0ULL))) {
                  V v_a_2458 = v_field_2453;
                  if ((v_tag_2455 == ((int64_t)0ULL))) {
                    V v_b_2460 = v_field_2456;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24SApp, TAG_Plus, 2, (V[]){v_a_2458, v_b_2460})}});
                  } else {
                    heff_drop_cell(v_ru_24e_241_24SApp, 2);
                    heff_drop(v_field_2456);
                    heff_drop(v_a_2458);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24e_241_24SApp, 2);
                  heff_drop(v_field_2453);
                  heff_drop(v_field_2456);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_b_2431);
            heff_drop_cell(v_ru_24e_241_24SApp, 2);
            heff_drop(v_a_2436);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_SCode: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLam: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        heff_take_n(v_e11_2435, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        heff_take_n(v_e11_2435, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        heff_take_na(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        heff_take_n(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        heff_take_n(v_e11_2435, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_e11_2435, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2431);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e11_2435)}});
      }
    }
    case TAG_SLam: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_e1_2430, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_e1_2430, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_e1_2430, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_e1_2430, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2431);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_2430)}});
    }
  }
  case TAG_SLam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_27_24136 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V t_0 = v_g_240;
    V t_1 = v_e_27_24136;
    v_g_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr_str0, 5, "co.Co");
HEFF_LIT(g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr_str1, 10, "co.Handler");

HeffT2 g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(V v_g_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SU: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SDecode: {
    V v_t1_243 = heff_field(v_t_241, 0);
    switch (heff_tag_of(v_t1_243)) {
    case TAG_SLocal: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      V v_t11_247 = heff_field(v_t1_243, 0);
      switch (heff_tag_of(v_t11_247)) {
      case TAG_SLocal: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        V v_t111_2412 = heff_field(v_t11_247, 0);
        V v_h_2413 = heff_field(v_t11_247, 1);
        switch (heff_tag_of(v_t111_2412)) {
        case TAG_SLocal: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          V v_p_2415 = heff_field(v_t111_2412, 0);
          if (heff_strEq_c_lent(v_p_2415, ((V)&g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr_str0), 2)) {
            HEFF_LAST return g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, heff_dup(v_h_2413));
          } else {
            heff_drop(v_g_240);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SCode: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SOpaque: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t111_2412)}});
        }
      }
      case TAG_SLam: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t11_247)}});
      }
    }
    case TAG_SLam: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t1_243)}});
    }
  }
  case TAG_SFunction: {
    V v_t2_24111 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_t2_24111)) {
    case TAG_SU: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecode: {
      V v_t21_24116 = heff_field(v_t2_24111, 0);
      switch (heff_tag_of(v_t21_24116)) {
      case TAG_SLocal: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        V v_t211_24120 = heff_field(v_t21_24116, 0);
        V v_h_24121 = heff_field(v_t21_24116, 1);
        switch (heff_tag_of(v_t211_24120)) {
        case TAG_SLocal: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          V v_p_24123 = heff_field(v_t211_24120, 0);
          if (heff_strEq_c_lent(v_p_24123, ((V)&g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr_str1), 2)) {
            HEFF_LAST return g_heff_2eelab_2eeffect_2eeffectOf_24cpr(v_g_240, heff_dup(v_h_24121));
          } else {
            heff_drop(v_g_240);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SCode: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SOpaque: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_drop(v_g_240);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t211_24120)}});
        }
      }
      case TAG_SLam: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        heff_drop(v_g_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t21_24116)}});
      }
    }
    case TAG_SFunction: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRecord: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSum: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIsTy: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimInt: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimString: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimRune: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimArray: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_drop(v_g_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t2_24111)}});
    }
  }
  case TAG_SRecord: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSum: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIsTy: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimArray: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    heff_drop(v_g_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}