// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2esplitFrom_2ebackwards_240(V, V);
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_2ebackwards_240_clo;
Clo g_prelude_2esplitFrom_2ebackwards_240_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_2ebackwards_240_entry, 2, 0};

V g_prelude_2esplitFrom_2ebackwards_240(V v_x1_240, V v_out_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_out_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_out_241});
    v_x1_240 = t_0;
    v_out_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esplitFrom_2ebackwards_240(a[0], a[1]);
}