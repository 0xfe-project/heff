// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FailBecause 16014
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_Often 32846
#define TAG_Pinned 8573
#define TAG_RepV 61860
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_binder 558177493
#define LBL_def 308863
#define LBL_defines 1776893014
#define LBL_discarded 1490202606
#define LBL_end 310101
#define LBL_failure 1292767177
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_goldens 436112074
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_ops 319788
#define LBL_path 9928940
#define LBL_property 1899481104
#define LBL_refs 9991943
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_slots 310891087
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_target 1066236092
#define LBL_tighter 1059982480
#define LBL_ty 10476
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2emetIn(V, V, V, V);
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emetIn_clo;
V g_heff_2ecompile_2efuse_2earmKind(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmKind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmKind_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eowned_2egivesUp(V, V);
V g_heff_2ecompile_2eowned_2egivesUp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2egivesUp_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2esyntax_2efmt_2eimports_2eentryText(V);
V g_heff_2esyntax_2efmt_2eimports_2eentryText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eentryText_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_list_2eany_24s1011930416x23610018(V, V);
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a);
extern Clo g_list_2eany_24s1011930416x23610018_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2eany_24s1116296567x1614305171(V);
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a);
extern Clo g_list_2eany_24s1116296567x1614305171_clo;
V g_list_2eany_24s1687778528x1571134043(V, V);
V g_list_2eany_24s1687778528x1571134043_entry(V self, V *a);
extern Clo g_list_2eany_24s1687778528x1571134043_clo;
V g_list_2eany_24s1968468648x2095421717(V, V, V, V, V, V, V);
V g_list_2eany_24s1968468648x2095421717_entry(V self, V *a);
extern Clo g_list_2eany_24s1968468648x2095421717_clo;
V g_list_2eany_24s357349853x1862456690(V, V);
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a);
extern Clo g_list_2eany_24s357349853x1862456690_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
V g_list_2efind_24s292855629x1492583570(V, V);
V g_list_2efind_24s292855629x1492583570_entry(V self, V *a);
extern Clo g_list_2efind_24s292855629x1492583570_clo;
HeffT2 g_list_2efind_24s292855629x1492583570_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24f1805635826x1386625471(V, V, V);
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1805635826x1386625471_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1667556251x1484232478(V, V);
V g_list_2efoldl_24s1667556251x1484232478_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1667556251x1484232478_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s199835065x1975386105(V, V);
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a);
extern Clo g_list_2efoldl_24s199835065x1975386105_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s345718350x1678852400(V, V);
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s345718350x1678852400_clo;
V g_list_2efoldl_24s585316429x898527369(V, V);
V g_list_2efoldl_24s585316429x898527369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s585316429x898527369_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2efoldl_24s963266017x1719814548(V, V);
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a);
extern Clo g_list_2efoldl_24s963266017x1719814548_clo;
V g_list_2ekeepIf_24dps(V, V, V);
V g_list_2ekeepIf_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24dps_clo;
V g_list_2ekeepIf_24s14815453x1234467625(V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_clo;
V g_list_2ekeepIf_24s14815453x1234467625_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_24dps_clo;
V g_list_2ekeepIf_24s1943838498x1969994910_24dps(V, V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_24dps_clo;
V g_list_2ekeepIf_24s1950790755x1251737354(V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_clo;
V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V, V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo;
V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s44384897x1267641110_24dps(V, V);
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1099021180x1702355548(V, V);
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_clo;
V g_list_2emap_24s1099021180x1702355548_24dps(V, V, V);
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_24dps_clo;
V g_list_2emap_24s1218614972x495009292(V, V, V);
V g_list_2emap_24s1218614972x495009292_entry(V self, V *a);
extern Clo g_list_2emap_24s1218614972x495009292_clo;
V g_list_2emap_24s1218614972x495009292_24dps(V, V, V, V);
V g_list_2emap_24s1218614972x495009292_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218614972x495009292_24dps_clo;
V g_list_2emap_24s1224226459x189329095_24dps(V, V, V, V);
V g_list_2emap_24s1224226459x189329095_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1224226459x189329095_24dps_clo;
V g_list_2emap_24s1341404685x1564972929_24dps(V, V);
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_24dps_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s137457135x961689574_24dps(V, V);
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_24dps_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s159228909x554161698_24dps(V, V, V, V, V);
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_24dps_clo;
V g_list_2emap_24s1611344417x463861413_24dps(V, V, V, V);
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_24dps_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s1681408447x1763680441_24dps(V, V, V, V);
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_24dps_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s1975257801x764827799_24dps(V, V);
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_24dps_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2015709068x2065046486_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_24dps_clo;
V g_list_2emap_24s2139359291x1524787922(V);
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_clo;
V g_list_2emap_24s2139359291x1524787922_24dps(V, V);
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_24dps_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s244350250x1728178626_24dps(V, V);
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_24dps_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s418652630x628827683(V);
V g_list_2emap_24s418652630x628827683_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_clo;
V g_list_2emap_24s418652630x628827683_24dps(V, V);
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_24dps_clo;
V g_list_2emap_24s564507054x318389057_24dps(V, V, V);
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_24dps_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s674081137x339217813_24dps(V, V);
V g_list_2emap_24s674081137x339217813_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_24dps_clo;
V g_list_2emap_24s777254429x1856211654_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_24dps_clo;
V g_list_2emap_24s866308031x234213482(V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_clo;
V g_list_2emap_24s866308031x234213482_24dps(V, V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_24dps_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge_24s169102166x1112743251_24dps(V, V, V);
V g_list_2emerge_24s169102166x1112743251_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s169102166x1112743251_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_list_2emap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24dps_entry, 3, 0};

V g_list_2emap_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1370882877x364361272_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370882877x364361272_entry, 2, 0};

V g_list_2efoldl_24s1370882877x364361272(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370882877x364361272(a[0], a[1]);
}
Clo g_list_2ekeepIf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24dps_entry, 3, 0};

V g_list_2ekeepIf_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s199835065x1975386105_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s199835065x1975386105_entry, 2, 0};

V g_list_2efoldl_24s199835065x1975386105(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_245 = (g_prelude_2e_2b_2b_24f1206589350x791019229(v_z_240, heff_dup(v_x_242), v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s199835065x1975386105(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s688114072x773797180_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s688114072x773797180_entry, 2, 0};

V g_list_2eany_24s688114072x773797180(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s688114072x773797180_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s688114072x773797180(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s947555161x768980202_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947555161x768980202_entry, 2, 0};

V g_list_2efoldl_24s947555161x768980202(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength_lent(v_z_240, 0));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947555161x768980202(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1817208647x1282894070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_24dps_entry, 2, 0};

V g_list_2emap_24s1817208647x1282894070_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817208647x1282894070_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1975257801x764827799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1975257801x764827799_24dps_entry, 2, 0};

V g_list_2emap_24s1975257801x764827799_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2eimports_2eentryText(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1975257801x764827799_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2139359291x1524787922_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2139359291x1524787922_entry, 1, 0};

V g_list_2emap_24s2139359291x1524787922(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2139359291x1524787922_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2139359291x1524787922(a[0]);
}
Clo g_list_2emap_24s97919758x216970748_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_entry, 2, 0};

V g_list_2emap_24s97919758x216970748(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2evariantOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s97919758x216970748_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97919758x216970748(a[0], a[1]);
}
Clo g_list_2emap_24s137457135x961689574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s137457135x961689574_entry, 1, 0};

V g_list_2emap_24s137457135x961689574(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s137457135x961689574_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s137457135x961689574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s137457135x961689574(a[0]);
}
Clo g_list_2emap_24s1992667171x110340492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_24dps_entry, 2, 0};

V g_list_2emap_24s1992667171x110340492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s158244903x55062455_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_24dps_entry, 2, 0};

V g_list_2emap_24s158244903x55062455_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x_242_24At, v_a_245, v_a_244));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s244350250x1728178626_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_24dps_entry, 2, 0};

V g_list_2emap_24s244350250x1728178626_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s244350250x1728178626_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s249042484x1701682908_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_entry, 1, 0};

V g_list_2emap_24s249042484x1701682908(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s249042484x1701682908_24dps(v_xs_242, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908(a[0]);
}
Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_245, 1)));
    V v_a_248 = heff_bool(heff_intEq_c_lent(v_t_247, v_lit_242, 0));
    heff_drop(v_t_247);
    if (!(heff_dup(v_a_248) == NTAG(TAG_True))) {
      heff_drop(v_a_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2053104128x1598844325_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s418652630x628827683_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s418652630x628827683_entry, 1, 0};

V g_list_2emap_24s418652630x628827683(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2442, heff_hole()});
    V v_u_2444 = (g_list_2emap_24s418652630x628827683_24dps(v_xs_242, heff_dup(v_cell_2443)));
    heff_drop(v_u_2444);
    return v_cell_2443;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s418652630x628827683_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s418652630x628827683(a[0]);
}
Clo g_list_2eany_24s415398368x1824706470_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s415398368x1824706470_entry, 1, 0};

V g_list_2eany_24s415398368x1824706470(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EMatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2442);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s415398368x1824706470(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1318914558x1386196507_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1318914558x1386196507_entry, 2, 0};

V g_list_2efoldl_24s1318914558x1386196507(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_246)));
      v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1318914558x1386196507(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1735038056x329845490_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1735038056x329845490_entry, 2, 0};

V g_list_2efoldl_24s1735038056x329845490(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2evalNamesTop(v_x_242, v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1735038056x329845490(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1694506840x958926808_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1694506840x958926808_entry, 2, 0};

V g_list_2efoldl_24s1694506840x958926808(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_BoxedWord: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Element: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Binds: {
      V v_x_2415 = heff_field(v_x_242, 0);
      v_t_2420 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_dup(v_x_2415), NTAG(TAG_MkUnit)));
      break;
    }
    case TAG_Pinned: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Kept: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Often: {
      v_t_2420 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1694506840x958926808(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1796125103x644876049_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_entry, 1, 0};

V g_list_2emap_24s1796125103x644876049(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1796125103x644876049_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049(a[0]);
}
Clo g_list_2eany_24s1687778528x1571134043_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1687778528x1571134043_entry, 2, 0};

V g_list_2eany_24s1687778528x1571134043(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intEq_c_lent(v_t_246, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1687778528x1571134043_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1687778528x1571134043(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s910662703x1730636603_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s910662703x1730636603_entry, 1, 0};

V g_list_2eany_24s910662703x1730636603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s910662703x1730636603(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1341404685x1564972929_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_24dps_entry, 2, 0};

V g_list_2emap_24s1341404685x1564972929_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1341404685x1564972929_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s357349853x1862456690_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s357349853x1862456690_entry, 2, 0};

V g_list_2eany_24s357349853x1862456690(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eowned_2egivesUp(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s357349853x1862456690(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s345718350x1678852400_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s345718350x1678852400_entry, 2, 0};

V g_list_2efoldl_24s345718350x1678852400(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2433;
    switch (heff_tag_of(v_x_242)) {
    case TAG_CDrop: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CLet: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CDecl: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CSet: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CAbandon: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CIf: {
      V v_a_2411 = heff_field(v_x_242, 1);
      V v_a_2412 = heff_field(v_x_242, 2);
      V v_t_2413 = (g_list_2efoldl_24s345718350x1678852400(v_z_240, v_a_2411));
      v_t_2433 = (g_list_2efoldl_24s345718350x1678852400(v_t_2413, v_a_2412));
      break;
    }
    case TAG_CSwitch: {
      V v_a_2415 = heff_field(v_x_242, 1);
      v_t_2433 = (g_list_2efoldl_24s585316429x898527369(v_z_240, v_a_2415));
      break;
    }
    case TAG_CReturn: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CInPlace: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CRoomed: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CTail: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CLoop: {
      v_t_2433 = v_z_240;
      break;
    }
    case TAG_CLoopTo: {
      heff_drop(v_z_240);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_CLabel: {
      heff_drop(v_z_240);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_CJump: {
      v_t_2433 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2433;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s345718350x1678852400(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1947501783x1475115781_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_24dps_entry, 4, 0};

V g_list_2emap_24s1947501783x1475115781_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_lit_240), v_x_244), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1947501783x1475115781_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s777254429x1856211654_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s777254429x1856211654_24dps_entry, 12, 0};

V g_list_2emap_24s777254429x1856211654_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410, V v_d_2411) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return heff_setField(v_d_2411, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2410, 0);
    V v_xs_2413 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_2412, 0);
      V v_a_2415 = heff_field(v_x_2412, 1);
      V v_ru_24x_2412_24MkPair = heff_take_reuse_n(v_x_2412, 3ULL, 2);
      V v_t_2416 = ({ V a_0 = v_a_2414; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2414); r_; });
      V v_t_2417 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2416, heff_dup(v_lit_243)));
      V v_a_2418 = (g_list_2emap_24tok2(v_ru_24x_2412_24MkPair, heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2415)));
      V v_t_2419 = ({ V a_0 = v_a_2418; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2418); r_; });
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2419, heff_dup(v_lit_247)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2420, heff_dup(v_lit_248)));
      V v_t_2422 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2421, heff_dup(v_lit_249)));
      v_t_2423 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2417, v_t_2422));
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2411, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_xs_2413;
    V t_11 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_x2_2410 = t_10;
    v_d_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s777254429x1856211654_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2emap_24s866308031x234213482_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s866308031x234213482_entry, 5, 0};

V g_list_2emap_24s866308031x234213482(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = heff_dup(v_lit_242); V a_3 = v_lit_243; V a_4 = v_x_245; V r_ = (g_heff_2ecompile_2efuse_2earmKind(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_245); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s866308031x234213482_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s866308031x234213482_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s866308031x234213482(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_list_2efind_24s292855629x1492583570_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s292855629x1492583570_entry, 2, 0};

V g_list_2efind_24s292855629x1492583570(V v_lit_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2efind_24s292855629x1492583570_24cpr(v_lit_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2efind_24s292855629x1492583570_entry(V self, V *a) {
  (void)self;
  return g_list_2efind_24s292855629x1492583570(a[0], a[1]);
}
Clo g_list_2efoldl_24s1667556251x1484232478_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1667556251x1484232478_entry, 2, 0};

V g_list_2efoldl_24s1667556251x1484232478(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_slots_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_def_245 = heff_dup(heff_rfield(v_x_242, 0));
    V v_t_248;
    switch (heff_tag_of(v_slots_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_def_245, 3);
      v_t_248 = v_z_240;
      break;
    }
    case TAG_Cons: {
      v_t_248 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_get_n(v_def_245, 0, 3), v_slots_244));
      break;
    }
    default: heff_nomatch(v_slots_244);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1667556251x1484232478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1667556251x1484232478(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s151204990x680105425_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_entry, 2, 0};

V g_list_2ezipWith_24s151204990x680105425(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_t_247;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = v_x_242;
      } else {
        heff_drop(v_x_242);
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_RepV);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s151204990x680105425_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425(a[0], a[1]);
}
Clo g_list_2efoldl_24s963266017x1719814548_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s963266017x1719814548_entry, 2, 0};

V g_list_2efoldl_24s963266017x1719814548(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 3, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s963266017x1719814548(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1009200955x251267316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_entry, 1, 0};

V g_list_2emap_24s1009200955x251267316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1009200955x251267316_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316(a[0]);
}
Clo g_list_2emap_24s1218614972x495009292_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218614972x495009292_entry, 3, 0};

V g_list_2emap_24s1218614972x495009292(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1218614972x495009292_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1218614972x495009292_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218614972x495009292(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1116296567x1614305171_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1116296567x1614305171_entry, 1, 0};

V g_list_2eany_24s1116296567x1614305171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SegmentInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentBinary: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentBits: {
      return NTAG(TAG_True);
    }
    case TAG_SegmentFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentUtf: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1116296567x1614305171(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s14815453x1234467625_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s14815453x1234467625_entry, 4, 0};

V g_list_2ekeepIf_24s14815453x1234467625(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2emetIn(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_x_244)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s14815453x1234467625_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s14815453x1234467625_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s14815453x1234467625(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_str0, 0, "");
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_entry, 1, 0};

V g_list_2emap_24s214260857x938990544(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_span_243 = heff_take_field(v_x_241, 0);
    V v_name_244 = heff_take_field(v_x_241, 1);
    V v_key_245 = heff_take_field(v_x_241, 2);
    V v_member_246 = heff_get_n(v_x_241, 3, 5);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_243, v_name_244, v_key_245, v_member_246, ((V)&g_list_2emap_24s214260857x938990544_lam0_clo)}), heff_hole()});
    V v_u_249 = (g_list_2emap_24s214260857x938990544_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544(a[0]);
}
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return ((V)&g_list_2emap_24s214260857x938990544_str0);
}
Clo g_list_2emap_24s570961906x1112476114_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_entry, 1, 0};

V g_list_2emap_24s570961906x1112476114(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s570961906x1112476114_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114(a[0]);
}
Clo g_list_2emap_24s1611344417x463861413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1611344417x463861413_24dps_entry, 4, 0};

V g_list_2emap_24s1611344417x463861413_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_246 = heff_take_field(v_x_244, 0);
    V v_tags_247 = heff_get_n(v_x_244, 1, 3);
    V v_t_248 = (g_heff_2ebuild_2edriver_2elistedName(v_name_246));
    V v_t_249;
    if ((heff_dup(v_tags_247) == NTAG(TAG_True))) {
      heff_drop(v_tags_247);
      v_t_249 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_247);
      v_t_249 = heff_dup(v_lit_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_t_249), heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1611344417x463861413_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s564507054x318389057_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s564507054x318389057_24dps_entry, 3, 0};

V g_list_2emap_24s564507054x318389057_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_245 = heff_take_field(v_x_243, 0);
    V v_looser_246 = heff_get_n(v_x_243, 1, 2);
    V v_t_247 = heff_strAppend(v_tighter_245, heff_strAppend(heff_dup(v_lit_240), v_looser_246));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s564507054x318389057_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1011930416x23610018_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1011930416x23610018_entry, 2, 0};

V g_list_2eany_24s1011930416x23610018(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    if ((heff_intEq_c_lent(v_start_245, v_start_248, 0) && heff_intEq_c_lent(v_end_246, v_end_249, 0))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1011930416x23610018(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    if ((heff_intEq_c(heff_dup(v_start_245), heff_dup(heff_rfield(v_lit_240, 0))) && heff_intEq_c(heff_dup(v_end_246), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_xs_243);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s1224226459x189329095_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1224226459x189329095_24dps_entry, 4, 0};

V g_list_2emap_24s1224226459x189329095_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_lit_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(heff_rfield(v_lit_241, 1)))));
    V v_t_247 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_lit_240, 3)), v_x_244, v_t_246});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1224226459x189329095_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1224226459x189329095_24dps(a[0], a[1], a[2], a[3]);
}

HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_xs_242);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop_rec(v_x_241, 3);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_t_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_list_2ekeepIf_24s1950790755x1251737354_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1950790755x1251737354_entry, 2, 0};

V g_list_2ekeepIf_24s1950790755x1251737354(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_244)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s1950790755x1251737354_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1950790755x1251737354(a[0], a[1]);
}
Clo g_list_2emerge_24s169102166x1112743251_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s169102166x1112743251_24dps_entry, 3, 0};

V g_list_2emerge_24s169102166x1112743251_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 5);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_245, 2)), 0, 2);
      if (heff_intLe_c(v_t_247, v_t_248)) {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_249;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2411;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s169102166x1112743251_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s169102166x1112743251_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1092144743x1559898298_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1092144743x1559898298_entry, 1, 0};

V g_list_2eany_24s1092144743x1559898298(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 6));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1092144743x1559898298(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1816200867x1876638332_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_entry, 1, 0};

V g_list_2emap_24s1816200867x1876638332(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1816200867x1876638332_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332(a[0]);
}
Clo g_list_2emap_24s1099021180x1702355548_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1099021180x1702355548_entry, 2, 0};

V g_list_2emap_24s1099021180x1702355548(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2efieldSetKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1099021180x1702355548_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1099021180x1702355548(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1943838498x1969994910_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1943838498x1969994910_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1943838498x1969994910_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s159228909x554161698_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159228909x554161698_entry, 4, 0};

V g_list_2emap_24s159228909x554161698(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2erefusedReaching(heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s159228909x554161698_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s159228909x554161698_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s159228909x554161698(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1681408447x1763680441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1681408447x1763680441_entry, 3, 0};

V g_list_2emap_24s1681408447x1763680441(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_strAppend(heff_take_field(v_x_243, 4), heff_dup(v_lit_241));
      v_t_246 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_nf(v_x_243, 239ULL, 8, shape_module__named__path__shown__source__renames__implicit__library, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      v_t_246 = v_x_243;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1681408447x1763680441_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1681408447x1763680441(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2015709068x2065046486_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2015709068x2065046486_24dps_entry, 8, 0};

V g_list_2emap_24s2015709068x2065046486_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(heff_dup(v_lit_243), heff_dup(v_lit_244))});
    V v_t_2414 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2412, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2413}), heff_dup(v_lit_245), NTAG(TAG_Nil)});
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2015709068x2065046486_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eany_24s944501138x775098345_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s944501138x775098345_entry, 2, 0};

V g_list_2eany_24s944501138x775098345(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s944501138x775098345_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s944501138x775098345(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s674081137x339217813_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s674081137x339217813_24dps_entry, 2, 0};

V g_list_2emap_24s674081137x339217813_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if ((heff_runeLe_c(MK_INT(65LL), heff_dup(v_x_242)) && heff_runeLe_c(heff_dup(v_x_242), MK_INT(90LL)))) {
      V v_t_244 = heff_intAdd(heff_runeToInt(v_x_242), MK_INT(32LL));
      v_t_245 = heff_runeFromInt(v_t_244);
    } else {
      v_t_245 = v_x_242;
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s674081137x339217813_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s674081137x339217813_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1968468648x2095421717_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1968468648x2095421717_entry, 7, 0};

V g_list_2eany_24s1968468648x2095421717(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_245);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_long_249 = heff_dup(heff_rfield(v_x_247, 0));
    V v_short_2410 = heff_dup(heff_rfield(v_x_247, 1));
    if ((heff_strEq_c_lent(v_long_249, v_lit_240, 0) || (heff_strEq_c_lent(v_short_2410, v_lit_241, 0) || (heff_strEq_c_lent(v_long_249, v_lit_242, 0) || !heff_intLt_c(heff_strFind_lent(v_lit_243, v_long_249, v_lit_244, 0), heff_dup(v_lit_245)))))) {
      heff_drop(v_lit_245);
      heff_drop(v_long_249);
      heff_drop(v_short_2410);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_long_249);
      heff_drop(v_short_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2eany_24s1968468648x2095421717_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2eany_24s1968468648x2095421717(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_list_2ekeepIf_24s44384897x1267641110_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s44384897x1267641110_entry, 1, 0};

V g_list_2ekeepIf_24s44384897x1267641110(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s44384897x1267641110_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s44384897x1267641110(a[0]);
}
Clo g_list_2efoldl_24f155552269x628597815_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f155552269x628597815_entry, 3, 0};

V g_list_2efoldl_24f155552269x628597815(V v_z_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245});
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_xs_244;
      V t_2 = v_ys_246;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f155552269x628597815(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1805635826x1386625471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1805635826x1386625471_entry, 3, 0};

V g_list_2efoldl_24f1805635826x1386625471(V v_z_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_lit_241), heff_dup(v_x_243)));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_lit_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1805635826x1386625471(a[0], a[1], a2); heff_drop(a2); return r;
}