// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_co_2e_3c_2b_3e_24s1505336972x898038096_get(void);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1314008918x267595320(V, V, V);
V g_co_2eop_24s1314008918x267595320_entry(V self, V *a);
extern Clo g_co_2eop_24s1314008918x267595320_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_exception_2eattempted_24s1047538290x862646821_get(void);
V g_exception_2eattempted_24s588401679x1225922520_get(void);
V g_exception_2eattempted_24s588401679x1225922520_24rec0_get(void);
V g_exception_2eattempted_24s588401679x1225922520_24rec0_lam1(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_24rec0_lam0(V self, V *args); static Clo g_exception_2eattempted_24s588401679x1225922520_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s588401679x1225922520_24rec0_lam0, 4, 0};

static V g_exception_2eattempted_24s588401679x1225922520_24rec0_val;
static HEFF_ONCE g_exception_2eattempted_24s588401679x1225922520_24rec0_st;
static V g_exception_2eattempted_24s588401679x1225922520_24rec0_init(void) {
  return heff_rec_n(1, shape_fmap, (V[]){((V)&g_exception_2eattempted_24s588401679x1225922520_24rec0_lam0_clo)});
}
V g_exception_2eattempted_24s588401679x1225922520_24rec0_get(void) {
  if (HEFF_DONE(g_exception_2eattempted_24s588401679x1225922520_24rec0_st)) return g_exception_2eattempted_24s588401679x1225922520_24rec0_val;
  return heff_global(&g_exception_2eattempted_24s588401679x1225922520_24rec0_val, &g_exception_2eattempted_24s588401679x1225922520_24rec0_st, g_exception_2eattempted_24s588401679x1225922520_24rec0_init);
}
V g_exception_2eattempted_24s588401679x1225922520_24rec0_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_248;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_x_245 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 1ULL, 1);
    heff_drop(v_g_240);
    v_x_248 = heff_tag_re_n(v_ru_24x_244_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_245});
    break;
  }
  case TAG_Right: {
    V v_y_246 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_g_240, 1, (V[]){v_y_246}));
    v_x_248 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_Right, 1, (V[]){v_t_247});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_243;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s588401679x1225922520_24rec0_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_m_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  V f_ = v_m_241;
  args[0] = v_hd_242;
  args[1] = heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_24rec0_lam1, 1, 2, (V[]){v_g_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam0(V self, V *args); static Clo g_exception_2eattempted_24s588401679x1225922520_lam0_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s588401679x1225922520_lam0, 3, 0};
V g_exception_2eattempted_24s588401679x1225922520_lam2(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_lam1(V self, V *args); static Clo g_exception_2eattempted_24s588401679x1225922520_lam1_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s588401679x1225922520_lam1, 4, 0};
V g_exception_2eattempted_24s588401679x1225922520_lam4(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_lam6(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_lam5(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_lam8(V self, V *args);
V g_exception_2eattempted_24s588401679x1225922520_lam7(V self, V *args); static Clo g_exception_2eattempted_24s588401679x1225922520_lam7_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s588401679x1225922520_lam7, 3, 0};
V g_exception_2eattempted_24s588401679x1225922520_lam3(V self, V *args); static Clo g_exception_2eattempted_24s588401679x1225922520_lam3_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s588401679x1225922520_lam3, 1, 0};

static V g_exception_2eattempted_24s588401679x1225922520_val;
static HEFF_ONCE g_exception_2eattempted_24s588401679x1225922520_st;
static V g_exception_2eattempted_24s588401679x1225922520_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_exception_2eattempted_24s588401679x1225922520_lam0_clo), ((V)&g_exception_2eattempted_24s588401679x1225922520_lam1_clo), ((V)&g_exception_2eattempted_24s588401679x1225922520_lam3_clo)});
}
V g_exception_2eattempted_24s588401679x1225922520_get(void) {
  if (HEFF_DONE(g_exception_2eattempted_24s588401679x1225922520_st)) return g_exception_2eattempted_24s588401679x1225922520_val;
  return heff_global(&g_exception_2eattempted_24s588401679x1225922520_val, &g_exception_2eattempted_24s588401679x1225922520_st, g_exception_2eattempted_24s588401679x1225922520_init);
}
V g_exception_2eattempted_24s588401679x1225922520_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    V v_x_248 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_k_244);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_248});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_249 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_clo_take(self, 3);
    V f_ = v_k_244;
    heff_room[0] = v_y_249;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_exception_2eattempted_24s588401679x1225922520_lam1(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_m_243;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_lam2, 1, 3, (V[]){v_k_246, v_k_244, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_s_2412 = heff_env(self)[0];
  heff_drop(v_hd_2413);
  heff_clo_take(self, 1);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_h_2416 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 3);
    V f_ = v_h_2416;
    heff_room[0] = v_x_2420;
    heff_room[1] = v_hd_2417;
    heff_room[2] = v_k_2418;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_h_2416);
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_y_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_exception_2eattempted_24s588401679x1225922520_lam5(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_h_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_lam6, 1, 3, (V[]){v_h_2416, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    V v_t_2428 = heff_abandon();
    heff_clo_take(self, 2);
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2424;
    heff_room[1] = v_k_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_hd_2424);
    V f_ = v_k_2425;
    args[0] = v_y_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_exception_2eattempted_24s588401679x1225922520_lam7(V self, V *args) {
  V v_m_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V f_ = v_m_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_lam8, 1, 2, (V[]){v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s588401679x1225922520_lam3(V self, V *args) {
  V v_p_2410 = args[0];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_t_2411 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_lam4, 2, 1, (V[]){v_s_2412});
    }
    case TAG_Catch: {
      V v_c_2415 = heff_field(v_t_2411, 0);
      V v_h_2416 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      return heff_clo_n(g_exception_2eattempted_24s588401679x1225922520_lam5, 2, 2, (V[]){v_c_2415, v_h_2416});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_InR: {
    V v_q_2422 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_exception_2eattempted_24s588401679x1225922520_24rec0_get()), heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), ((V)&g_exception_2eattempted_24s588401679x1225922520_lam7_clo), v_q_2422}));
    V f_ = ((V)&g_co_2eop_24s1896221640x2141527803_clo);
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_exception_2eattempted_24s1047538290x862646821_lam0(V self, V *args); static Clo g_exception_2eattempted_24s1047538290x862646821_lam0_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1047538290x862646821_lam0, 3, 0};
V g_exception_2eattempted_24s1047538290x862646821_lam2(V self, V *args);
V g_exception_2eattempted_24s1047538290x862646821_lam1(V self, V *args); static Clo g_exception_2eattempted_24s1047538290x862646821_lam1_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1047538290x862646821_lam1, 4, 0};
V g_exception_2eattempted_24s1047538290x862646821_lam4(V self, V *args);
V g_exception_2eattempted_24s1047538290x862646821_lam6(V self, V *args);
V g_exception_2eattempted_24s1047538290x862646821_lam5(V self, V *args);
V g_exception_2eattempted_24s1047538290x862646821_lam8(V self, V *args);
V g_exception_2eattempted_24s1047538290x862646821_lam7(V self, V *args); static Clo g_exception_2eattempted_24s1047538290x862646821_lam7_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1047538290x862646821_lam7, 3, 0};
V g_exception_2eattempted_24s1047538290x862646821_lam3(V self, V *args); static Clo g_exception_2eattempted_24s1047538290x862646821_lam3_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1047538290x862646821_lam3, 1, 0};

static V g_exception_2eattempted_24s1047538290x862646821_val;
static HEFF_ONCE g_exception_2eattempted_24s1047538290x862646821_st;
static V g_exception_2eattempted_24s1047538290x862646821_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_exception_2eattempted_24s1047538290x862646821_lam0_clo), ((V)&g_exception_2eattempted_24s1047538290x862646821_lam1_clo), ((V)&g_exception_2eattempted_24s1047538290x862646821_lam3_clo)});
}
V g_exception_2eattempted_24s1047538290x862646821_get(void) {
  if (HEFF_DONE(g_exception_2eattempted_24s1047538290x862646821_st)) return g_exception_2eattempted_24s1047538290x862646821_val;
  return heff_global(&g_exception_2eattempted_24s1047538290x862646821_val, &g_exception_2eattempted_24s1047538290x862646821_st, g_exception_2eattempted_24s1047538290x862646821_init);
}
V g_exception_2eattempted_24s1047538290x862646821_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1047538290x862646821_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    V v_x_248 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_k_244);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_248});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_249 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_clo_take(self, 3);
    V f_ = v_k_244;
    heff_room[0] = v_y_249;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_exception_2eattempted_24s1047538290x862646821_lam1(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_m_243;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1047538290x862646821_lam2, 1, 3, (V[]){v_k_246, v_k_244, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1047538290x862646821_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_s_2412 = heff_env(self)[0];
  heff_drop(v_hd_2413);
  heff_clo_take(self, 1);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1047538290x862646821_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_h_2416 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 3);
    V f_ = v_h_2416;
    heff_room[0] = v_x_2420;
    heff_room[1] = v_hd_2417;
    heff_room[2] = v_k_2418;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_h_2416);
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_y_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_exception_2eattempted_24s1047538290x862646821_lam5(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_h_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1047538290x862646821_lam6, 1, 3, (V[]){v_h_2416, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1047538290x862646821_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    heff_take_n(v_x_2428, 0ULL, 1);
    V v_t_2430 = heff_abandon();
    heff_clo_take(self, 2);
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2426;
    heff_room[1] = v_k_2427;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_hd_2426);
    V f_ = v_k_2427;
    args[0] = v_y_2431;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_exception_2eattempted_24s1047538290x862646821_lam7(V self, V *args) {
  V v_m_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  V f_ = v_m_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1047538290x862646821_lam8, 1, 2, (V[]){v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1047538290x862646821_lam3(V self, V *args) {
  V v_p_2410 = args[0];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_t_2411 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return heff_clo_n(g_exception_2eattempted_24s1047538290x862646821_lam4, 2, 1, (V[]){v_s_2412});
    }
    case TAG_Catch: {
      V v_c_2415 = heff_field(v_t_2411, 0);
      V v_h_2416 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      return heff_clo_n(g_exception_2eattempted_24s1047538290x862646821_lam5, 2, 2, (V[]){v_c_2415, v_h_2416});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_InR: {
    V v_q_2422 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_q_2422)) {
    case TAG_InL: {
      V v_x_2423 = heff_field(v_q_2422, 0);
      V v_ru_24q_2422_24InL = heff_take_reuse_n(v_q_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2410_24InR, 1);
      v_t_2433 = heff_tag_re_n(v_ru_24q_2422_24InL, TAG_InL, 1, 1ULL, (V[]){v_x_2423});
      break;
    }
    case TAG_InR: {
      V v_y_2424 = heff_field(v_q_2422, 0);
      heff_take_n(v_q_2422, 1ULL, 1);
      V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){heff_dup(g_exception_2eattempted_24s588401679x1225922520_24rec0_get()), heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), ((V)&g_exception_2eattempted_24s1047538290x862646821_lam7_clo), v_y_2424}));
      v_t_2433 = heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2432});
      break;
    }
    default: heff_nomatch(v_q_2422);
    }
    V f_ = ((V)&g_co_2eop_24s1314008918x267595320_clo);
    args[0] = v_t_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2410);
  }
}