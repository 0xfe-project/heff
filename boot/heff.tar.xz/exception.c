// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_co_2eop_24s1050926098x962532285(V, V, V);
V g_co_2eop_24s1050926098x962532285_entry(V self, V *a);
extern Clo g_co_2eop_24s1050926098x962532285_clo;
V g_co_2eop_24s1549572115x1242285242(V, V, V, V);
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a);
extern Clo g_co_2eop_24s1549572115x1242285242_clo;
V g_co_2eplus_24s638448470x237911921_get(void);
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_exception_2eattempted_24s1195609006x58926992_get(void);
V g_exception_2eattempted_lam0(V self, V *args); static Clo g_exception_2eattempted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_lam0, 3, 0};
V g_exception_2eattempted_lam2(V self, V *args);
V g_exception_2eattempted_lam1(V self, V *args); static Clo g_exception_2eattempted_lam1_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_lam1, 4, 0};
V g_exception_2eattempted_lam4(V self, V *args);
V g_exception_2eattempted_lam6(V self, V *args);
V g_exception_2eattempted_lam5(V self, V *args);
V g_exception_2eattempted_lam8(V self, V *args);
V g_exception_2eattempted_lam7(V self, V *args); static Clo g_exception_2eattempted_lam7_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_lam7, 4, 0};
V g_exception_2eattempted_lam10(V self, V *args);
V g_exception_2eattempted_lam9(V self, V *args); static Clo g_exception_2eattempted_lam9_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_lam9, 4, 0};
V g_exception_2eattempted_lam12(V self, V *args);
V g_exception_2eattempted_lam11(V self, V *args); static Clo g_exception_2eattempted_lam11_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_lam11, 3, 0};
V g_exception_2eattempted_lam3(V self, V *args);
Clo g_exception_2eattempted_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_entry, 1, 0};

V g_exception_2eattempted(V v_e_240) {
top: ;
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_exception_2eattempted_lam0_clo), ((V)&g_exception_2eattempted_lam1_clo), heff_clo_n(g_exception_2eattempted_lam3, 1, 1, (V[]){v_e_240})});
}
V g_exception_2eattempted_entry(V self, V *a) {
  (void)self;
  return g_exception_2eattempted(a[0]);
}
V g_exception_2eattempted_lam0(V self, V *args) {
  V v_x_241 = args[0];
  V v_hd_242 = args[1];
  V v_k_243 = args[2];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Left: {
    V v_x_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_k_245);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_249});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2410 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V f_ = v_k_245;
    heff_room[0] = v_y_2410;
    heff_room[1] = v_hd_246;
    heff_room[2] = v_k_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_exception_2eattempted_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_m_244;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_exception_2eattempted_lam2, 1, 3, (V[]){v_k_247, v_k_245, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_lam4(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_h_2417 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V f_ = v_h_2417;
    heff_room[0] = v_x_2421;
    heff_room[1] = v_hd_2418;
    heff_room[2] = v_k_2419;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    heff_drop(v_h_2417);
    heff_drop(v_hd_2418);
    V f_ = v_k_2419;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_y_2422});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_exception_2eattempted_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_h_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_exception_2eattempted_lam6, 1, 3, (V[]){v_h_2417, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2424 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2432;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_x_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    heff_drop(v_g_2424);
    v_x_2432 = heff_tag_at_n(v_ru_24x_2428_24Left, TAG_Left, 1, (V[]){v_x_2429});
    break;
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Right = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    V v_t_2431 = heff_tr(heff_call(v_g_2424, 1, (V[]){v_y_2430}));
    v_x_2432 = heff_tag_at_n(v_ru_24x_2428_24Right, TAG_Right, 1, (V[]){v_t_2431});
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V f_ = v_k_2427;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_lam7(V self, V *args) {
  V v_g_2424 = args[0];
  V v_m_2425 = args[1];
  V v_hd_2426 = args[2];
  V v_k_2427 = args[3];
  V f_ = v_m_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_exception_2eattempted_lam8, 1, 2, (V[]){v_g_2424, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_lam10(V self, V *args) {
  V v_x_2437 = args[0];
  V v_g_2433 = heff_env(self)[0];
  V v_k_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2438 = heff_tr(heff_call(v_g_2433, 1, (V[]){v_x_2437}));
  V f_ = v_k_2436;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_lam9(V self, V *args) {
  V v_g_2433 = args[0];
  V v_c_2434 = args[1];
  V v_hd_2435 = args[2];
  V v_k_2436 = args[3];
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_exception_2eattempted_lam10, 1, 2, (V[]){v_g_2433, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_lam12(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  V v_k_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    heff_take_n(v_x_2442, 0ULL, 1);
    V v_t_2444 = heff_abandon();
    V f_ = v_t_2444;
    heff_room[0] = v_hd_2440;
    heff_room[1] = v_k_2441;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2445 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    heff_drop(v_hd_2440);
    V f_ = v_k_2441;
    args[0] = v_y_2445;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_exception_2eattempted_lam11(V self, V *args) {
  V v_m_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  V f_ = v_m_2439;
  args[0] = heff_dup(v_hd_2440);
  args[1] = heff_clo_n(g_exception_2eattempted_lam12, 1, 2, (V[]){v_hd_2440, v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_lam3(V self, V *args) {
  V v_p_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2411)) {
  case TAG_InL: {
    V v_t_2412 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 1);
    heff_drop_rec(v_e_240, 2);
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Throw: {
      V v_s_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      return heff_clo_n(g_exception_2eattempted_lam4, 2, 1, (V[]){v_s_2413});
    }
    case TAG_Catch: {
      V v_c_2416 = heff_field(v_t_2412, 0);
      V v_h_2417 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      return heff_clo_n(g_exception_2eattempted_lam5, 2, 2, (V[]){v_c_2416, v_h_2417});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_InR: {
    V v_q_2423 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 1);
    V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_e_240, 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_exception_2eattempted_lam7_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_exception_2eattempted_lam9_clo)}), ((V)&g_exception_2eattempted_lam11_clo), v_q_2423}));
    V f_ = ((V)&g_co_2eop_24s1549572115x1242285242_clo);
    heff_room[0] = v_e_240;
    heff_room[1] = v_t_2446;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_p_2411);
  }
}
V g_exception_2eattempted_24s1195609006x58926992_lam0(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam0_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam0, 3, 0};
V g_exception_2eattempted_24s1195609006x58926992_lam2(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam1(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam1_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam1, 4, 0};
V g_exception_2eattempted_24s1195609006x58926992_lam4(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam6(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam5(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam8(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam7(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam7_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam7, 4, 0};
V g_exception_2eattempted_24s1195609006x58926992_lam10(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam9(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam9_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam9, 4, 0};
V g_exception_2eattempted_24s1195609006x58926992_lam12(V self, V *args);
V g_exception_2eattempted_24s1195609006x58926992_lam11(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam11_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam11, 3, 0};
V g_exception_2eattempted_24s1195609006x58926992_lam3(V self, V *args); static Clo g_exception_2eattempted_24s1195609006x58926992_lam3_clo = {{0x80000000u, K_CLO, 0}, g_exception_2eattempted_24s1195609006x58926992_lam3, 1, 0};

static V g_exception_2eattempted_24s1195609006x58926992_val;
static HEFF_ONCE g_exception_2eattempted_24s1195609006x58926992_st;
static V g_exception_2eattempted_24s1195609006x58926992_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_exception_2eattempted_24s1195609006x58926992_lam0_clo), ((V)&g_exception_2eattempted_24s1195609006x58926992_lam1_clo), ((V)&g_exception_2eattempted_24s1195609006x58926992_lam3_clo)});
}
V g_exception_2eattempted_24s1195609006x58926992_get(void) {
  if (HEFF_DONE(g_exception_2eattempted_24s1195609006x58926992_st)) return g_exception_2eattempted_24s1195609006x58926992_val;
  return heff_global(&g_exception_2eattempted_24s1195609006x58926992_val, &g_exception_2eattempted_24s1195609006x58926992_st, g_exception_2eattempted_24s1195609006x58926992_init);
}
V g_exception_2eattempted_24s1195609006x58926992_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    V v_x_248 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_k_244);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_248});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_249 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    V f_ = v_k_244;
    heff_room[0] = v_y_249;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_exception_2eattempted_24s1195609006x58926992_lam1(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_m_243;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam2, 1, 3, (V[]){v_k_246, v_k_244, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_s_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_h_2416 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    V f_ = v_h_2416;
    heff_room[0] = v_x_2420;
    heff_room[1] = v_hd_2417;
    heff_room[2] = v_k_2418;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_h_2416);
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_y_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_exception_2eattempted_24s1195609006x58926992_lam5(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_h_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam6, 1, 3, (V[]){v_h_2416, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_x_2428 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop(v_g_2423);
    v_x_2431 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_Left, 1, (V[]){v_x_2428});
    break;
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(v_g_2423, 1, (V[]){v_y_2429}));
    v_x_2431 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Right, 1, (V[]){v_t_2430});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_2426;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam7(V self, V *args) {
  V v_g_2423 = args[0];
  V v_m_2424 = args[1];
  V v_hd_2425 = args[2];
  V v_k_2426 = args[3];
  V f_ = v_m_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam8, 1, 2, (V[]){v_g_2423, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam10(V self, V *args) {
  V v_x_2436 = args[0];
  V v_g_2432 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2437 = heff_tr(heff_call(v_g_2432, 1, (V[]){v_x_2436}));
  V f_ = v_k_2435;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam9(V self, V *args) {
  V v_g_2432 = args[0];
  V v_c_2433 = args[1];
  V v_hd_2434 = args[2];
  V v_k_2435 = args[3];
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam10, 1, 2, (V[]){v_g_2432, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam12(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    heff_take_n(v_x_2441, 0ULL, 1);
    V v_t_2443 = heff_abandon();
    V f_ = v_t_2443;
    heff_room[0] = v_hd_2439;
    heff_room[1] = v_k_2440;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    heff_drop(v_hd_2439);
    V f_ = v_k_2440;
    args[0] = v_y_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_exception_2eattempted_24s1195609006x58926992_lam11(V self, V *args) {
  V v_m_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  V f_ = v_m_2438;
  args[0] = heff_dup(v_hd_2439);
  args[1] = heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam12, 1, 2, (V[]){v_hd_2439, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_exception_2eattempted_24s1195609006x58926992_lam3(V self, V *args) {
  V v_p_2410 = args[0];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_t_2411 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam4, 2, 1, (V[]){v_s_2412});
    }
    case TAG_Catch: {
      V v_c_2415 = heff_field(v_t_2411, 0);
      V v_h_2416 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      return heff_clo_n(g_exception_2eattempted_24s1195609006x58926992_lam5, 2, 2, (V[]){v_c_2415, v_h_2416});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_InR: {
    V v_q_2422 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s638448470x237911921_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_exception_2eattempted_24s1195609006x58926992_lam7_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_exception_2eattempted_24s1195609006x58926992_lam9_clo)}), ((V)&g_exception_2eattempted_24s1195609006x58926992_lam11_clo), v_q_2422}));
    V f_ = ((V)&g_co_2eop_24s1050926098x962532285_clo);
    args[0] = v_t_2445;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2410);
  }
}