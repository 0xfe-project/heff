// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArmCovered 35323
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_EquationCovered 28162
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HGlobal 55847
#define TAG_IApp 21275
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SIs 29577
#define TAG_SpId 35501
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_evidence 1128105991
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_unreached 121683306
#define LBL_val 326043
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2enothingMatched_get(void);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2erules_2eevidenceSearch_get(void);
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2elambdaChk(V, V, V, V);
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elambdaChk_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2earmsSaid(V, V, V);
V g_heff_2eelab_2etoplevel_2earmsSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2earmsSaid_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_get(void);
V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec1_get(void);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(V, V, V);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2enamedTwice_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2enamedTwice_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enamedTwice_24dps_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(V);
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2ethawKeep(V, V, V);
V g_heff_2eelab_2etoplevel_2ethawKeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawKeep_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s651804017x1543238976(V, V);
V g_list_2eany_24s651804017x1543238976_entry(V self, V *a);
extern Clo g_list_2eany_24s651804017x1543238976_clo;
V g_list_2eany_24s683544084x423451648(V, V);
V g_list_2eany_24s683544084x423451648_entry(V self, V *a);
extern Clo g_list_2eany_24s683544084x423451648_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(v_k_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eselfWalk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalChk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_val_2410 = heff_env(self)[0];
  heff_drop(v_u_2411);
  heff_clo_take(self, 1);
  V v_x1_2412 = heff_tr(heff_call(v_val_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_stx_249 = heff_take_field(v_x_248, 0);
  V v_val_2410 = heff_take_field(v_x_248, 1);
  V v_t_2417 = ({ V rv_0 = heff_tag_n(TAG_SIs, 1, (V[]){v_stx_249}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_val_2410}); V rr_ = heff_rec_reuse_nf(v_x_248, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  heff_clo_take(self, 1);
  V f_ = v_k_247;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  V v_c_245;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_call(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str1, 30, "an arm above it is `_` already");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str2, 25, "an arm above it matches `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str3, 9, "` already");
Clo g_heff_2eelab_2etoplevel_2enamedTwice_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enamedTwice_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2enamedTwice_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_sp_246 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      V v_t_247 = (g_list_2eany_24s1006624359x760861690(v_x_245, v_seen_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248;
        if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str0), 2)) {
          heff_drop(v_x_245);
          v_t_248 = ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str1);
        } else {
          v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str2), v_x_245), ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_24dps_str3));
        }
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_ArmCovered, 2, (V[]){v_sp_246, v_t_248}), heff_hole()});
        V v_u_2410 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_249);
        V t_0 = v_seen_240;
        V t_1 = v_rest_244;
        V t_2 = v_u_2410;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_sp_246);
        heff_drop_cell(v_ru_24x21_243_24MkPair, 2);
        heff_drop(v_t_247);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_seen_240});
        V t_1 = v_rest_244;
        V t_2 = v_d_242;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2enamedTwice_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2enamedTwice_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eupdatePath_str0, 51, "an update sets a field by its name: `{ r | x = v }`");
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eupdatePath_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eupdatePath(V v_sp_240, V v_x2_241, V v_c_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_242);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam0, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_x22_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x21_2411, 0);
      V v_xsp_2414 = heff_field(v_x21_2411, 1);
      heff_take_n(v_x21_2411, 3ULL, 2);
      switch (heff_tag_of(v_x22_2412)) {
      case TAG_Nil: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam1, 2, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_c_242});
      }
      case TAG_Cons: {
        V v_c_2419 = (g_heff_2eelab_2etoplevel_2eupdatePath(heff_dup(v_sp_240), v_x22_2412, v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam2, 2, 4, (V[]){v_c_2419, v_x_2413, v_xsp_2414, v_sp_240});
      }
      default: return heff_nomatch(v_x22_2412);
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eupdatePath(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  heff_clo_take(self, 1);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eupdatePath_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_249}));
  V f_ = v_bind_246;
  args[0] = v_t_2410;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2413 = heff_env(self)[0];
  V v_xsp_2414 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  heff_drop(v_hd_2415);
  heff_clo_take(self, 4);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_UpdateTo, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_c_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_xsp_2414 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_UpdateIn, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_t_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_xsp_2414 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam3, 1, 4, (V[]){v_k_2421, v_x_2413, v_xsp_2414, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str2, 16, "prelude.inferred");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str3, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str4, 12, "prelude.Pair");
Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epairOfHoles_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2epairOfHoles(V v_sp_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str0)}), heff_dup(v_sp_240)});
  V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_ArgExplicit, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_240)})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_241, v_t_244}), heff_dup(v_sp_240)});
  V v_c_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), heff_dup(v_sp_240)});
  V v_t_249;
  switch (heff_tag_of(v_c_246)) {
  case TAG_At: {
    V v_s_248 = heff_dup(heff_field(v_c_246, 1));
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_c_246);
  }
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str2)}), heff_dup(v_sp_240)});
  V v_t_2411 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str3), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_ArgExplicit, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_240)})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, v_t_2413}), heff_dup(v_sp_240)});
  V v_c_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), heff_dup(v_sp_240)});
  V v_t_2418;
  switch (heff_tag_of(v_c_2415)) {
  case TAG_At: {
    V v_s_2417 = heff_dup(heff_field(v_c_2415, 1));
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_c_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str4)}), heff_dup(v_sp_240)});
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_246}), v_t_249});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_2415}), v_t_2418});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_240)})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_240});
}
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epairOfHoles(a[0]);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 1, 4, (V[]){v_start_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_start_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V v_x2_240, V v_scrutN_241, V v_sp_242, V v_msg_243) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nothing: {
    heff_drop(v_scrutN_241);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0, 2, 2, (V[]){v_msg_243, v_sp_242});
  }
  case TAG_Just: {
    V v_see_2412 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2413 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_241));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1, 2, 4, (V[]){v_c_2413, v_see_2412, v_msg_243, v_sp_242});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_msg_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_malg_246 = heff_take_field(v_hd_244, 2);
  V v_bind_247 = heff_get_n(v_hd_244, 1, 3);
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_msg_243, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2410}));
  V f_ = v_bind_247;
  args[0] = v_t_2411;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_msg_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_drop(v_x_2424);
  heff_clo_take(self, 4);
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_msg_243, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2422, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2422, 1, 3);
  heff_room[0] = v_t_2428;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_msg_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5, 1, 4, (V[]){v_msg_243, v_sp_242, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3(V self, V *args) {
  V v_e_2417 = args[0];
  V v_a_2418 = args[1];
  V v_see_2412 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_drop(v_a_2418);
  heff_clo_take(self, 4);
  V v_x1_2419 = heff_tr(heff_call(v_see_2412, 1, (V[]){v_x_2416}));
  V v_c_2421;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkSyn: {
    V v_f_2420 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_c_2421 = heff_tr(heff_call(v_f_2420, 1, (V[]){v_e_2417}));
    break;
  }
  default: heff_nomatch(v_x1_2419);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4, 2, 3, (V[]){v_c_2421, v_msg_243, v_sp_242});
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_see_2412 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3, 2, 4, (V[]){v_see_2412, v_x_2416, v_msg_243, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_see_2412 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2, 1, 4, (V[]){v_k_2415, v_see_2412, v_msg_243, v_sp_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ab_244 = v_ab_242;
    V v_implicit_245 = heff_take_field(v_ab_244, 3);
    V v_name_246 = heff_take_field(v_ab_244, 1);
    V v_typ_247 = heff_take_field(v_ab_244, 2);
    V v_span_248 = heff_get_n(v_ab_244, 0, 4);
    V v_x2_249 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    V v_t_2410 = v_implicit_245;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Expl: {
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_t_2411 = heff_field(v_x2_249, 0);
        V v_c_2412 = heff_field(v_x2_249, 1);
        V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
        V v_t_2413 = ({ V a_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Named, 2, (V[]){heff_dup(v_name_246), v_typ_247}); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2411); r_; });
        V v_t_2414 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_span_248; V a_2 = v_name_246; V a_3 = v_c_2412; V r_ = (g_heff_2eelab_2erules_2elambdaChk(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_c_2412); r_; });
        return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2414});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_t_2415 = heff_field(v_x2_249, 0);
        V v_c_2416 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_t_2417 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(v_span_248), heff_dup(v_name_246), v_typ_247, NTAG(TAG_Nothing)});
        V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_t_2415; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2415); r_; });
        V v_t_2419 = ({ V a_0 = v_span_248; V a_1 = v_name_246; V a_2 = v_c_2416; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2416); r_; });
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_2418, v_t_2419});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_t_2420 = heff_field(v_x2_249, 0);
        V v_c_2421 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_t_2422 = ({ V a_0 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(v_span_248), heff_dup(v_name_246), v_typ_247}); V a_1 = v_t_2420; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2420); r_; });
        V v_t_2423 = ({ V a_0 = v_span_248; V a_1 = v_name_246; V a_2 = v_c_2421; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2421); r_; });
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_2422, v_t_2423});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithArgs(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 21, "`; give it as `{...}`");
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebodyPhase_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_lam12, 1, 0};
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam14(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebodyPhase_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_lam14, 1, 0};
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam16(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebodyPhase_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_lam16, 1, 0};
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam19(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebodyPhase_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_lam19, 1, 0};
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_tm_245 = heff_take_field(v_d_241, 2);
  V v_name_246 = heff_get_n(v_d_241, 0, 4);
  V v_x1_247 = v_tm_245;
  V v_gSelf_248 = heff_dup(v_gSelf_242);
  V v_k_249 = v_k_243;
  V v_name_2410 = v_name_246;
  V v_aval_2411 = heff_dup(v_aval_244);
  V v_v_2413 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_249)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 1, 1, (V[]){heff_dup(v_aval_2411)}), NTAG(TAG_Nothing)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_2410, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 1, (V[]){v_v_2413})});
  V v_t_2417 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_2411});
  V v_t_2418 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_249)}), NTAG(TAG_SpId)});
  V v_e_2419 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){heff_rec_n(5, shape_len__names__locals__ctx__matched, (V[]){MK_INT(1LL), v_t_2414, v_t_2416, v_t_2417, heff_dup(g_heff_2eelab_2eenvironment_2enothingMatched_get())}), v_gSelf_248, v_t_2418, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_249}), NTAG(TAG_Nil), NTAG(TAG_True), heff_dup(g_heff_2eelab_2erules_2eevidenceSearch_get())});
  V v_m_2421;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkChk: {
    V v_f_2420 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    v_m_2421 = heff_tr(heff_call(v_f_2420, 2, (V[]){v_e_2419, heff_dup(v_aval_244)}));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 2, 4, (V[]){v_m_2421, v_aval_244, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_aval_2411 = heff_env(self)[0];
  heff_drop(v_u_2412);
  heff_clo_take(self, 1);
  return v_aval_2411;
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  return v_v_2413;
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_d_2427 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  V v_t_2431;
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2430) == NTAG(TAG_True))) {
    heff_drop(v_x_2430);
    v_t_2431 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_2427, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_2430);
    v_t_2431 = v_d_2427;
  }
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2433}));
  V f_ = heff_get_n(v_hd_2428, 1, 3);
  heff_room[0] = v_t_2434;
  heff_room[1] = v_k_2429;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_aval_244 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_aval_2426 = v_aval_244;
  V v_d_2427 = v_s_2425;
  V v_hd_2428 = heff_dup(v_hd_2422);
  V v_k_2429 = heff_get_n(v_hd_2422, 0, 3);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_aval_2426, heff_dup(v_hd_2428), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 3, (V[]){v_d_2427, v_hd_2428, v_k_2429})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam11(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_2457 = heff_env(self)[0];
  V v_x_2438 = heff_env(self)[1];
  heff_drop(v_x_2469);
  heff_clo_take(self, 2);
  V f_ = v_k_2457;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam10(V self, V *args) {
  V v_unsolved_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  V v_x_2438 = heff_env(self)[0];
  V v_malg_2458 = heff_take_field(v_hd_2456, 2);
  V v_bind_2459 = heff_get_n(v_hd_2456, 1, 3);
  switch (heff_tag_of(v_unsolved_2455)) {
  case TAG_Nil: {
    heff_drop(v_malg_2458);
    heff_drop(v_bind_2459);
    heff_clo_take(self, 1);
    V f_ = v_k_2457;
    args[0] = v_x_2438;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2460 = heff_field(v_unsolved_2455, 0);
    heff_take_n(v_unsolved_2455, 1ULL, 2);
    V v_name_2462 = heff_take_field(v_u_2460, 0);
    V v_span_2463 = heff_get_n(v_u_2460, 1, 2);
    V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0), v_name_2462), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1));
    V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2464, v_span_2463, NTAG(TAG_Nothing)});
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_call(v_malg_2458, 1, (V[]){v_t_2467}));
    heff_clo_take(self, 1);
    V f_ = v_bind_2459;
    args[0] = v_t_2468;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam11, 1, 2, (V[]){v_k_2457, v_x_2438});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2455);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_drop(v_x_2454);
  heff_clo_take(self, 3);
  return (g_co_2ebind_24s1831149655x1541910000(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam10, 3, 1, (V[]){v_x_2438}), v_hd_2422, v_k_2423));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam12(V self, V *args) {
  V v_c_2473 = args[0];
  return heff_get_n(v_c_2473, 3, 9);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam13(V self, V *args) {
  V v_x_2477 = args[0];
  V v_g_2448 = heff_env(self)[0];
  V v_sp_2449 = heff_env(self)[1];
  V v_p_2471 = heff_env(self)[2];
  V v_malg_2452 = heff_env(self)[3];
  V v_bind_2453 = heff_env(self)[4];
  V v_p_2470 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2478 = ({ V a_0 = v_g_2448; V a_1 = v_sp_2449; V a_2 = v_p_2471; V a_3 = v_x_2477; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2477); r_; });
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tr(heff_call(v_malg_2452, 1, (V[]){v_t_2480}));
  V f_ = v_bind_2453;
  heff_room[0] = v_t_2481;
  heff_room[1] = v_p_2470;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_hd_2422 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_drop(v_x_2447);
  heff_clo_take(self, 6);
  V v_g_2448 = v_gSelf_242;
  V v_sp_2449 = v_dsp_240;
  V v_x3_2450 = v_x_2439;
  V v_p_2451 = heff_dup(v_hd_2422);
  V v_malg_2452 = heff_take_field(v_p_2451, 2);
  V v_bind_2453 = heff_get_n(v_p_2451, 1, 3);
  V v_p_2470 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam9, 1, 3, (V[]){v_x_2438, v_hd_2422, v_k_2423});
  switch (heff_tag_of(v_x3_2450)) {
  case TAG_Nil: {
    heff_drop(v_g_2448);
    heff_drop(v_sp_2449);
    heff_drop(v_malg_2452);
    heff_drop(v_bind_2453);
    V f_ = v_p_2470;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_p_2471 = heff_field(v_x3_2450, 0);
    heff_take_n(v_x3_2450, 1ULL, 2);
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_lam12_clo)})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_dup(v_malg_2452), 1, (V[]){v_t_2475}));
    V f_ = heff_dup(v_bind_2453);
    heff_room[0] = v_t_2476;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam13, 1, 6, (V[]){v_g_2448, v_sp_2449, v_p_2471, v_malg_2452, v_bind_2453, v_p_2470});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x3_2450);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam14(V self, V *args) {
  V v_c_2483 = args[0];
  return heff_get_n(v_c_2483, 2, 9);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam16(V self, V *args) {
  V v_c_2488 = args[0];
  return heff_get_n(v_c_2488, 3, 9);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam18(V self, V *args) {
  V v_m_2495 = args[0];
  V v_x_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2496 = ({ V a_0 = v_x_2492; V a_1 = v_m_2495; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2492); r_; });
  {
    V v_field_2498 = v_t_2496.f[1];
    int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
    if ((v_tag_2497 == ((int64_t)0ULL))) {
      V v_me_2499 = v_field_2498;
      V v_t_24100 = heff_get_n(v_me_2499, 1, 6);
      switch (heff_tag_of(v_t_24100)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_t_24100, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_24100);
      }
    } else {
      heff_drop(v_field_2498);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam17(V self, V *args) {
  V v_x_2492 = args[0];
  V v_x_2487 = heff_env(self)[0];
  V v_malg_2445 = heff_env(self)[1];
  V v_bind_2446 = heff_env(self)[2];
  V v_k_2482 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = ({ V a_0 = v_x_2487; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_x_2487); r_; });
  V v_t_2494 = (g_list_2emap_24s1415906091x1371825187(v_t_2493));
  V v_t_24102 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam18, 1, 1, (V[]){v_x_2492}); V a_1 = v_t_2494; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2494); r_; });
  if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
    heff_drop(v_t_24102);
    V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){heff_dup(g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_get())})});
    V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tr(heff_call(v_malg_2445, 1, (V[]){v_t_24104}));
    V f_ = v_bind_2446;
    heff_room[0] = v_t_24105;
    heff_room[1] = v_k_2482;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_malg_2445);
    heff_drop(v_bind_2446);
    heff_drop(v_t_24102);
    V f_ = v_k_2482;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam15(V self, V *args) {
  V v_x_2487 = args[0];
  V v_malg_2445 = heff_env(self)[0];
  V v_bind_2446 = heff_env(self)[1];
  V v_k_2482 = heff_env(self)[2];
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_lam16_clo)})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tr(heff_call(heff_dup(v_malg_2445), 1, (V[]){v_t_2490}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(v_bind_2446);
  heff_room[0] = v_t_2491;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam17, 1, 4, (V[]){v_x_2487, v_malg_2445, v_bind_2446, v_k_2482});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_drop(v_x_2443);
  V v_hd_2444 = heff_dup(v_hd_2422);
  V v_malg_2445 = heff_take_field(v_hd_2444, 2);
  V v_bind_2446 = heff_get_n(v_hd_2444, 1, 3);
  heff_clo_take(self, 6);
  V v_k_2482 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam8, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2439, v_hd_2422, v_x_2438, v_k_2423});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_lam14_clo)})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tr(heff_call(heff_dup(v_malg_2445), 1, (V[]){v_t_2485}));
  V f_ = heff_dup(v_bind_2446);
  heff_room[0] = v_t_2486;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam15, 1, 3, (V[]){v_malg_2445, v_bind_2446, v_k_2482});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam19(V self, V *args) {
  V v_c_24107 = args[0];
  return heff_get_n(v_c_24107, 1, 9);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam20(V self, V *args) {
  V v_x_24111 = args[0];
  V v_k_24106 = heff_env(self)[0];
  V v_malg_2441 = heff_env(self)[1];
  V v_bind_2442 = heff_env(self)[2];
  V v_t_24112 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24111; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24111); r_; });
  if (heff_intEq_c(v_t_24112, MK_INT(0LL))) {
    heff_clo_take(self, 3);
    heff_drop(v_malg_2441);
    heff_drop(v_bind_2442);
    V f_ = v_k_24106;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){heff_dup(g_heff_2eelab_2etoplevel_2ebodyPhase_24rec1_get())})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    heff_clo_take(self, 3);
    V v_t_24115 = heff_tr(heff_call(v_malg_2441, 1, (V[]){v_t_24114}));
    V f_ = v_bind_2442;
    heff_room[0] = v_t_24115;
    heff_room[1] = v_k_24106;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  V v_hd_2440 = heff_dup(v_hd_2422);
  V v_malg_2441 = heff_take_field(v_hd_2440, 2);
  V v_bind_2442 = heff_get_n(v_hd_2440, 1, 3);
  heff_clo_take(self, 5);
  V v_k_24106 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 1, 6, (V[]){v_hd_2422, v_gSelf_242, v_dsp_240, v_x_2439, v_x_2438, v_k_2423});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_lam19_clo)})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tr(heff_call(heff_dup(v_malg_2441), 1, (V[]){v_t_24109}));
  V f_ = heff_dup(v_bind_2442);
  heff_room[0] = v_t_24110;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam20, 1, 3, (V[]){v_k_24106, v_malg_2441, v_bind_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 1, 5, (V[]){v_hd_2422, v_gSelf_242, v_dsp_240, v_x_2438, v_k_2423})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_m_2421 = heff_env(self)[0];
  V v_aval_244 = heff_env(self)[1];
  V v_gSelf_242 = heff_env(self)[2];
  V v_dsp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2424 = heff_tr(heff_call(v_m_2421, 2, (V[]){heff_dup(v_hd_2422), heff_dup(heff_rfield(v_hd_2422, 0))}));
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2424, heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 2, (V[]){v_aval_244, heff_dup(v_hd_2422)})})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){v_t_2436}));
  V f_ = heff_dup(heff_rfield(v_hd_2422, 1));
  args[0] = v_t_2437;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 4, (V[]){v_gSelf_242, v_hd_2422, v_dsp_240, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2earmsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2earmsSaid_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2earmsSaid(V v_seen_240, V v_said_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_said_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_ArmTaken: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_said_241;
      V t_2 = v_rest_244;
      v_seen_240 = t_0;
      v_said_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ArmRuledOut: {
      V v_at_246 = heff_field(v_x31_243, 0);
      V v_by_247 = heff_field(v_x31_243, 1);
      V v_what_248 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24ArmRuledOut = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      V v_t_249 = (g_list_2eany_24s651804017x1543238976(heff_dup(v_at_246), v_said_241));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_at_246);
        heff_drop(v_by_247);
        heff_drop(v_what_248);
        heff_drop_cell(v_ru_24x31_243_24ArmRuledOut, 3);
        heff_drop(v_t_249);
        V t_0 = v_seen_240;
        V t_1 = v_said_241;
        V t_2 = v_rest_244;
        v_seen_240 = t_0;
        v_said_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_249);
        V v_t_2410 = (g_list_2eany_24s683544084x423451648(heff_dup(v_at_246), v_seen_240));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_at_246);
          heff_drop(v_by_247);
          heff_drop(v_what_248);
          heff_drop_cell(v_ru_24x31_243_24ArmRuledOut, 3);
          heff_drop(v_t_2410);
          V t_0 = v_seen_240;
          V t_1 = v_said_241;
          V t_2 = v_rest_244;
          v_seen_240 = t_0;
          v_said_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_t_2410);
          V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x31_243_24ArmRuledOut, TAG_ArmRuledOut, 3, 7ULL, (V[]){v_at_246, v_by_247, v_what_248}), v_said_241});
          V t_0 = v_seen_240;
          V t_1 = v_t_2411;
          V t_2 = v_rest_244;
          v_seen_240 = t_0;
          v_said_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
    case TAG_ArmCovered: {
      V v_t_2421;
      switch (heff_tag_of(v_x31_243)) {
      case TAG_ArmTaken: {
        V v_sp_2414 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2421 = v_sp_2414;
        break;
      }
      case TAG_ArmRuledOut: {
        V v_sp_2415 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2421 = v_sp_2415;
        break;
      }
      case TAG_ArmCovered: {
        V v_sp_2418 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2421 = v_sp_2418;
        break;
      }
      case TAG_EquationCovered: {
        V v_sp_2420 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2421 = v_sp_2420;
        break;
      }
      default: heff_nomatch(v_x31_243);
      }
      V v_t_2422 = (g_list_2eany_24s651804017x1543238976(v_t_2421, v_said_241));
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop_tag(v_x31_243, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2422);
        V t_0 = v_seen_240;
        V t_1 = v_said_241;
        V t_2 = v_rest_244;
        v_seen_240 = t_0;
        v_said_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2422);
        V t_0 = v_seen_240;
        V t_1 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x31_243, v_said_241});
        V t_2 = v_rest_244;
        v_seen_240 = t_0;
        v_said_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EquationCovered: {
      V v_t_2431;
      switch (heff_tag_of(v_x31_243)) {
      case TAG_ArmTaken: {
        V v_sp_2424 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2431 = v_sp_2424;
        break;
      }
      case TAG_ArmRuledOut: {
        V v_sp_2425 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2431 = v_sp_2425;
        break;
      }
      case TAG_ArmCovered: {
        V v_sp_2428 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2431 = v_sp_2428;
        break;
      }
      case TAG_EquationCovered: {
        V v_sp_2430 = heff_dup(heff_field(v_x31_243, 0));
        v_t_2431 = v_sp_2430;
        break;
      }
      default: heff_nomatch(v_x31_243);
      }
      V v_t_2432 = (g_list_2eany_24s651804017x1543238976(v_t_2431, v_said_241));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop_tag(v_x31_243, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2432);
        V t_0 = v_seen_240;
        V t_1 = v_said_241;
        V t_2 = v_rest_244;
        v_seen_240 = t_0;
        v_said_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2432);
        V t_0 = v_seen_240;
        V t_1 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x31_243, v_said_241});
        V t_2 = v_rest_244;
        v_seen_240 = t_0;
        v_said_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2earmsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2earmsSaid(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2411, 1, 9)));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_246, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2415 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_241, 1, 10), v_t_2413, v_t_2414));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2415);
    }
    case TAG_Right: {
      V v_r_2416 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_prim_2417 = heff_take_field(v_r_2416, 2);
      V v_key_2418 = heff_take_field(v_r_2416, 1);
      V v_entry_2419 = heff_take_field(v_r_2416, 4);
      V v_name_2420 = heff_take_field(v_r_2416, 0);
      V v_isInstance_2421 = heff_take_field(v_r_2416, 3);
      V v_failed_2422 = heff_get_n(v_r_2416, 5, 6);
      V v_g_2423 = heff_take_field(v_acc_241, 0);
      V v_t_2424 = v_prim_2417;
      V v_t_2429;
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        HeffT2 v_t_2425 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_2423, 1), v_key_2418));
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            heff_drop(v_entry_2419);
            V v_e_2428 = v_field_2427;
            heff_drop(v_e_2428);
            v_t_2429 = v_g_2423;
          } else {
            heff_drop(v_field_2427);
            v_t_2429 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2418), v_entry_2419, v_g_2423));
          }
        }
      } else {
        heff_drop(v_t_2424);
        v_t_2429 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2418), v_entry_2419, v_g_2423));
      }
      V v_t_2430 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_2420), heff_dup(v_key_2418), v_t_2429));
      V v_globals_2431 = ({ V a_0 = v_isInstance_2421; V a_1 = heff_dup(v_key_2418); V a_2 = v_name_2420; V a_3 = v_t_2430; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_2421); r_; });
      V v_t_2435;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2432 = heff_dup(heff_field(v_st_245, 0));
        v_t_2435 = v_c_2432;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2435, 1, 9)));
      V v_t_2437 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2436));
      V v_t_2438 = heff_dup(v_failed_2422);
      V v_t_2440;
      switch (heff_tag_of(v_t_2438)) {
      case TAG_Nothing: {
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2439 = heff_field(v_t_2438, 0);
        heff_take_n(v_t_2438, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2439, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2439, 5);
          v_t_2440 = NTAG(TAG_Nil);
        } else {
          v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2439, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2438);
      }
      V v_diags_2441 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_241, 1), v_t_2437, v_t_2440));
      V v_broken_2442 = heff_take_field(v_acc_241, 3);
      V v_watches_2443 = heff_take_field(v_acc_241, 4);
      V v_tests_2444 = heff_take_field(v_acc_241, 5);
      V v_t_2445 = v_name_2420;
      V v_t_2446 = heff_take_field(v_acc_241, 6);
      V v_t_2450;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2447 = heff_dup(heff_field(v_st_245, 0));
        v_t_2450 = v_c_2447;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2457 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_241, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam0, 1, 1, (V[]){heff_dup(v_st_245)}), heff_get_n(v_t_2450, 0, 9)));
      V v_t_2461;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2458 = heff_dup(heff_field(v_st_245, 0));
        v_t_2461 = v_c_2458;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2462 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2461, 6, 9), heff_take_field(v_acc_241, 8)));
      V v_t_2466;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2463 = heff_dup(heff_field(v_st_245, 0));
        v_t_2466 = v_c_2463;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2467 = heff_get_n(v_t_2466, 1, 9);
      V v_t_2481;
      switch (heff_tag_of(v_t_2467)) {
      case TAG_Nil: {
        V v_t_2468 = v_failed_2422;
        switch (heff_tag_of(v_t_2468)) {
        case TAG_Nothing: {
          V v_t_2472;
          switch (heff_tag_of(v_st_245)) {
          case TAG_MkSt: {
            V v_c_2469 = heff_dup(heff_field(v_st_245, 0));
            v_t_2472 = v_c_2469;
            break;
          }
          default: heff_nomatch(v_st_245);
          }
          V v_t_2476;
          switch (heff_tag_of(v_st_245)) {
          case TAG_MkSt: {
            V v_c_2473 = heff_field(v_st_245, 0);
            heff_take_n(v_st_245, 1ULL, 3);
            v_t_2476 = v_c_2473;
            break;
          }
          default: heff_nomatch(v_st_245);
          }
          V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2476, 8, 9)));
          v_t_2481 = ({ V b_0 = heff_get_n(v_t_2472, 8, 9); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2477; V r_ = (g_heff_2eelab_2etoplevel_2earmsSaid(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2468, 0ULL, 1);
          heff_drop(v_st_245);
          v_t_2481 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2468);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2467, 0ULL, 2);
        heff_drop(v_st_245);
        heff_drop(v_failed_2422);
        v_t_2481 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
      V v_unreached_2482 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2481, heff_take_field(v_acc_241, 9)));
      V v_t_2485;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2484 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        v_t_2485 = v_s_2484;
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_2418, heff_take_field(v_acc_241, 2)});
      V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2445, v_t_2485}), v_t_2446});
      return ({ V rv_0 = v_globals_2431; V rv_1 = v_diags_2441; V rv_2 = v_t_2486; V rv_3 = v_broken_2442; V rv_4 = v_watches_2443; V rv_5 = v_tests_2444; V rv_6 = v_t_2487; V rv_7 = v_infos_2457; V rv_8 = v_trace_2462; V rv_9 = v_unreached_2482; V rr_ = heff_rec_reuse_nf(v_acc_241, 0ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args) {
  V v_u_2452 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_n_2451 = heff_env(self)[1];
  heff_drop(v_u_2452);
  V v_t_2456;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_245)) {
  case TAG_MkSt: {
    V v_c_2453 = heff_field(v_st_245, 0);
    heff_take_n(v_st_245, 1ULL, 3);
    v_t_2456 = v_c_2453;
    break;
  }
  default: heff_nomatch(v_st_245);
  }
  V f_ = heff_get_n(v_n_2451, 4, 5);
  args[0] = heff_get_n(v_t_2456, 3, 9);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args) {
  V v_n_2451 = args[0];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam1, 1, 2, (V[]){v_st_245, heff_dup(v_n_2451)}); V rr_ = heff_rec_reuse_nf(v_n_2451, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_249, 1, 9)));
      V v_t_2411 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2410));
      V v_t_2412;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2412 = NTAG(TAG_Nil);
      } else {
        v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_diags_2413 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2411, v_t_2412));
      V v_broken_2414 = heff_take_field(v_acc_240, 3);
      V v_watches_2415 = heff_take_field(v_acc_240, 4);
      V v_tests_2416 = heff_take_field(v_acc_240, 5);
      V v_spans_2417 = heff_take_field(v_acc_240, 6);
      V v_t_2421;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2418 = heff_dup(heff_field(v_st_244, 0));
        v_t_2421 = v_c_2418;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2428 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam0, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2421, 0, 9)));
      V v_t_2432;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2429 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2432 = v_c_2429;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2433 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2432, 6, 9), heff_take_field(v_acc_240, 8)));
      V v_unreached_2434 = heff_take_field(v_acc_240, 9);
      return ({ V rv_1 = v_diags_2413; V rv_3 = v_broken_2414; V rv_4 = v_watches_2415; V rv_5 = v_tests_2416; V rv_6 = v_spans_2417; V rv_7 = v_infos_2428; V rv_8 = v_trace_2433; V rv_9 = v_unreached_2434; V rr_ = heff_rec_reuse_nf(v_acc_240, 5ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 51u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    case TAG_Right: {
      V v_entry_2435 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2439;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2436 = heff_dup(heff_field(v_st_244, 0));
        v_t_2439 = v_c_2436;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2439, 1, 9)));
      V v_t_2441 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2440));
      V v_diags_2442 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2441));
      V v_broken_2443 = heff_take_field(v_acc_240, 3);
      V v_t_2444 = heff_take_field(v_acc_240, 4);
      V v_tests_2445 = heff_take_field(v_acc_240, 5);
      V v_spans_2446 = heff_take_field(v_acc_240, 6);
      V v_t_2450;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2447 = heff_dup(heff_field(v_st_244, 0));
        v_t_2450 = v_c_2447;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2457 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam2, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2450, 0, 9)));
      V v_t_2461;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2458 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2461 = v_c_2458;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2462 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2461, 6, 9), heff_take_field(v_acc_240, 8)));
      V v_unreached_2463 = heff_take_field(v_acc_240, 9);
      V v_t_2464 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2435}), v_t_2444});
      return ({ V rv_1 = v_diags_2442; V rv_3 = v_broken_2443; V rv_4 = v_t_2464; V rv_5 = v_tests_2445; V rv_6 = v_spans_2446; V rv_7 = v_infos_2457; V rv_8 = v_trace_2462; V rv_9 = v_unreached_2463; V rr_ = heff_rec_reuse_nf(v_acc_240, 5ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 51u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_n_2422 = heff_env(self)[1];
  heff_drop(v_u_2423);
  V v_t_2427;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2424 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2427 = v_c_2424;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = heff_get_n(v_n_2422, 4, 5);
  args[0] = heff_get_n(v_t_2427, 3, 9);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args) {
  V v_n_2422 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam1, 1, 2, (V[]){v_st_244, heff_dup(v_n_2422)}); V rr_ = heff_rec_reuse_nf(v_n_2422, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args) {
  V v_u_2452 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_n_2451 = heff_env(self)[1];
  heff_drop(v_u_2452);
  V v_t_2456;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2453 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2456 = v_c_2453;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = heff_get_n(v_n_2451, 4, 5);
  args[0] = heff_get_n(v_t_2456, 3, 9);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args) {
  V v_n_2451 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam3, 1, 2, (V[]){v_st_244, heff_dup(v_n_2451)}); V rr_ = heff_rec_reuse_nf(v_n_2451, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_t_2412;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_d_249 = heff_field(v_st_243, 1);
    V v_w_2410 = heff_field(v_st_243, 2);
    V v_ru_24st_243_24MkSt = heff_take_reuse_n(v_st_243, 6ULL, 3);
    V v_t_2411 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_247, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2412 = heff_tag_re_n(v_ru_24st_243_24MkSt, TAG_MkSt, 3, 6ULL, (V[]){v_t_2411, v_d_249, v_w_2410});
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  return (g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(heff_dup(v_n_242), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, v_n_242, v_key_240}), v_t_2412));
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_a_2427 = args[0];
  V v_a_2428 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2427}), v_a_2428});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args) {
  V v_a_2435 = args[0];
  V v_a_2436 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2435}), v_a_2436});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_drop(v_x_2434);
  heff_clo_take(self, 5);
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args) {
  V v_a_2443 = args[0];
  V v_a_2444 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2443}), v_a_2444});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args) {
  V v_a_2450 = args[0];
  V v_a_2451 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2450}), v_a_2451});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args) {
  V v_a_2456 = args[0];
  V v_a_2457 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2456}), v_a_2457});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args) {
  V v_a_2461 = args[0];
  V v_a_2462 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2461}), v_a_2462});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args) {
  V v_a_2465 = args[0];
  V v_a_2466 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2465}), v_a_2466});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_2419 = args[1];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_drop(v_x_2418);
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2420 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_DeclEquations: {
      V v_x113_2424 = heff_field(v_x11_2420, 2);
      V v_tyN_2425 = heff_field(v_x11_2420, 3);
      heff_take_n(v_x11_2420, 12ULL, 5);
      switch (heff_tag_of(v_x113_2424)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2425);
        V v_t_2429 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
        V f_ = v_t_2429;
        args[0] = v_z_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_AsInstance: {
        V v_t_2432;
        switch (heff_tag_of(v_tyN_2425)) {
        case TAG_At: {
          V v_s_2431 = heff_field(v_tyN_2425, 1);
          heff_take_n(v_tyN_2425, 2ULL, 2);
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_tyN_2425);
        }
        V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2417, 0))));
        V v_t_2437 = heff_tr(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(v_t_2432, NTAG(TAG_Nil), MK_INT(0LL), v_t_2433, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2413, v_x_2417})));
        V f_ = v_t_2437;
        args[0] = v_z_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x113_2424);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2420, 0ULL, 5);
      V v_t_2445 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
      V f_ = v_t_2445;
      args[0] = v_z_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2420, 0ULL, 4);
      V v_t_2452 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
      V f_ = v_t_2452;
      args[0] = v_z_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2420, 0ULL, 3);
      V v_t_2458 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
      V f_ = v_t_2458;
      args[0] = v_z_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2420, 0ULL, 2);
      V v_t_2463 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
      V f_ = v_t_2463;
      args[0] = v_z_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2420, 0ULL, 1);
      V v_t_2467 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2413; V a_4 = v_x_2417; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo); V r_ = heff_tr(g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_n_242, 2); r_; });
      V f_ = v_t_2467;
      args[0] = v_z_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 2, 5, (V[]){v_n_242, v_key_240, v_g_241, v_x_2413, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_t_2414 = heff_dup(heff_rfield(v_x_2413, 1));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_MkTyp: {
    V v_f_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_t_2416 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil), NTAG(TAG_False), heff_dup(g_heff_2eelab_2erules_2eevidenceSearch_get())});
    heff_clo_take(self, 3);
    V f_ = v_f_2415;
    heff_room[0] = v_t_2416;
    heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
    heff_room[2] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_n_242, v_key_240, v_g_241, v_x_2413});
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267(V v_k_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_get_n(v_t_245, 3, 9);
  V v_t_2410;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_247 = heff_dup(heff_field(v_st_241, 0));
    v_t_2410 = v_c_247;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_2411 = ({ V b_0 = heff_get_n(v_t_2410, 2, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = (g_list_2emap_24s1415906091x1371825187(v_t_2411));
  V v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_lam0, 1, 1, (V[]){v_t_246}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2412); r_; });
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_k_240);
    heff_drop(v_t_2420);
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){heff_dup(g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_get())}), v_st_241});
  } else {
    heff_drop(v_t_2420);
    return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_241});
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_lam0(V self, V *args) {
  V v_m_2413 = args[0];
  V v_t_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2414 = ({ V a_0 = v_t_246; V a_1 = v_m_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_me_2417 = v_field_2416;
      V v_t_2418 = heff_get_n(v_me_2417, 1, 6);
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_t_2418, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2418);
      }
    } else {
      heff_drop(v_field_2416);
      return NTAG(TAG_False);
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2ethawKeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawKeep_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ethawKeep(V v_acc_240, V v_d_241, V v_g_242) {
top: ;
  V v_key_243 = heff_take_field(v_d_241, 1);
  V v_name_244 = heff_take_field(v_d_241, 0);
  V v_span_245 = heff_get_n(v_d_241, 3, 6);
  V v_t_246 = v_key_243;
  V v_t_247 = heff_take_field(v_acc_240, 2);
  V v_broken_248 = heff_take_field(v_acc_240, 3);
  V v_watches_249 = heff_take_field(v_acc_240, 4);
  V v_tests_2410 = heff_take_field(v_acc_240, 5);
  V v_t_2411 = v_name_244;
  V v_t_2412 = heff_take_field(v_acc_240, 6);
  V v_infos_2413 = heff_take_field(v_acc_240, 7);
  V v_trace_2414 = heff_take_field(v_acc_240, 8);
  V v_unreached_2415 = heff_take_field(v_acc_240, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_span_245}), v_t_2412});
  return ({ V rv_0 = v_g_242; V rv_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_247}); V rv_3 = v_broken_248; V rv_4 = v_watches_249; V rv_5 = v_tests_2410; V rv_6 = v_t_2416; V rv_7 = v_infos_2413; V rv_8 = v_trace_2414; V rv_9 = v_unreached_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawKeep_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawKeep(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2etoplevel_2eappendM_24dps(v_xs_244, v_ys_242, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM_24tok2(a[0], a[1], a[2]);
}