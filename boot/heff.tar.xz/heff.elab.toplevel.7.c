// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_ForNominative 23095
#define TAG_IApp 21275
#define TAG_IVar 40993
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SIs 29577
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_heff_2eelab_2eenvironment_2ecatchE(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ecatchE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ecatchE_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24tok1(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24tok1_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2etoplevel_2ewithOne_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_24tok2_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){heff_dup(v_k_240)})});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eselfWalk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_k_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2etoplevel_2eselfTermF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalChk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_val_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_x1_2417 = heff_tr(heff_call(v_val_2415, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2421});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_stx_2414 = heff_take_field(v_x_2413, 0);
  V v_val_2415 = heff_get_n(v_x_2413, 1, 2);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_stx_2414}), heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_val_2415})});
  V f_ = v_k_2412;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_scope_243 = heff_take_field(v_e_241, 0);
  V v_globals_244 = heff_take_field(v_e_241, 1);
  V v_lams_245 = heff_take_field(v_e_241, 3);
  V v_self_246 = heff_take_field(v_e_241, 4);
  V v_insts_247 = heff_get_n(v_e_241, 5, 6);
  V v_c_2410;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_248 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_249 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_243, v_globals_244, NTAG(TAG_ForNominative), v_lams_245, v_self_246, v_insts_247});
    v_c_2410 = heff_tr(heff_call(v_f_248, 2, (V[]){v_t_249, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_2410});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eupdatePath_str0, 51, "an update sets a field by its name: `{ r | x = v }`");
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eupdatePath_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eupdatePath(V v_sp_240, V v_x2_241, V v_c_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_242);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam0, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_x22_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x21_2411, 0);
      V v_xsp_2414 = heff_field(v_x21_2411, 1);
      heff_take_n(v_x21_2411, 3ULL, 2);
      switch (heff_tag_of(v_x22_2412)) {
      case TAG_Nil: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam1, 2, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_c_242});
      }
      case TAG_Cons: {
        V v_c_2419 = (g_heff_2eelab_2etoplevel_2eupdatePath(heff_dup(v_sp_240), v_x22_2412, v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam2, 2, 4, (V[]){v_c_2419, v_x_2413, v_xsp_2414, v_sp_240});
      }
      default: return heff_nomatch(v_x22_2412);
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eupdatePath(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_245 = heff_take_field(v_hd_243, 1);
  V v_malg_246 = heff_get_n(v_hd_243, 2, 3);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eupdatePath_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_249}));
  V f_ = v_bind_245;
  args[0] = v_t_2410;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2413 = heff_env(self)[0];
  V v_xsp_2414 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_UpdateTo, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_c_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_xsp_2414 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_UpdateIn, 4, (V[]){v_x_2413, v_xsp_2414, v_sp_240, v_t_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_xsp_2414 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam3, 1, 4, (V[]){v_k_2421, v_x_2413, v_xsp_2414, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str0, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str1, 16, "prelude.inferred");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str2, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str3, 16, "prelude.inferred");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epairOfHoles_str4, 6, "MkUnit");
Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epairOfHoles_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2epairOfHoles(V v_sp_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str0)}), heff_dup(v_sp_240)});
  V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str1)}), heff_dup(v_sp_240)});
  V v_t_243 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str2), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_ArgExplicit, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_242, v_t_245}), heff_dup(v_sp_240)});
  V v_c_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), heff_dup(v_sp_240)});
  V v_t_2410;
  switch (heff_tag_of(v_c_247)) {
  case TAG_At: {
    V v_s_249 = heff_dup(heff_field(v_c_247, 1));
    v_t_2410 = v_s_249;
    break;
  }
  default: heff_nomatch(v_c_247);
  }
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_247}), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str3)}), heff_dup(v_sp_240)});
  V v_t_2413 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2epairOfHoles_str4), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_ArgExplicit, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_240)})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2415}), heff_dup(v_sp_240)});
  V v_c_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2416}), heff_dup(v_sp_240)});
  V v_t_2420;
  switch (heff_tag_of(v_c_2417)) {
  case TAG_At: {
    V v_s_2419 = heff_dup(heff_field(v_c_2417, 1));
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2417);
  }
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_2417}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_240)})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_240});
}
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epairOfHoles(a[0]);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V v_x2_240, V v_scrutN_241, V v_sp_242, V v_msg_243) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nothing: {
    heff_drop(v_scrutN_241);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0, 2, 2, (V[]){v_msg_243, v_sp_242});
  }
  case TAG_Just: {
    V v_see_2412 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2413 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_241));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1, 2, 4, (V[]){v_c_2413, v_see_2412, v_msg_243, v_sp_242});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_msg_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_246 = heff_take_field(v_hd_244, 1);
  V v_malg_247 = heff_get_n(v_hd_244, 2, 3);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_msg_243, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_247, 1, (V[]){v_t_2410}));
  V f_ = v_bind_246;
  args[0] = v_t_2411;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_msg_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_msg_243, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2422, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2422, 1, 3);
  heff_room[0] = v_t_2428;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_msg_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam5, 1, 4, (V[]){v_msg_243, v_sp_242, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3(V self, V *args) {
  V v_e_2417 = args[0];
  V v_a_2418 = args[1];
  V v_see_2412 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2418);
  V v_x1_2419 = heff_tr(heff_call(v_see_2412, 1, (V[]){v_x_2416}));
  V v_c_2421;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkSyn: {
    V v_f_2420 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_c_2421 = heff_tr(heff_call(v_f_2420, 1, (V[]){v_e_2417}));
    break;
  }
  default: heff_nomatch(v_x1_2419);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam4, 2, 3, (V[]){v_c_2421, v_msg_243, v_sp_242});
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_see_2412 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam3, 2, 4, (V[]){v_see_2412, v_x_2416, v_msg_243, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_see_2412 = heff_env(self)[1];
  V v_msg_243 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_lam2, 1, 4, (V[]){v_k_2415, v_see_2412, v_msg_243, v_sp_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithArgs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 21, "`; give it as `{...}`");
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_name_245 = heff_take_field(v_d_241, 0);
  V v_tm_246 = heff_get_n(v_d_241, 2, 4);
  V v_e_247 = (g_heff_2eelab_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, v_name_245, heff_dup(v_aval_244)));
  V v_t_249;
  switch (heff_tag_of(v_tm_246)) {
  case TAG_MkChk: {
    V v_f_248 = heff_field(v_tm_246, 0);
    heff_take_n(v_tm_246, 1ULL, 1);
    v_t_249 = heff_tr(heff_call(v_f_248, 2, (V[]){v_e_247, heff_dup(v_aval_244)}));
    break;
  }
  default: heff_nomatch(v_tm_246);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 2, 4, (V[]){v_aval_244, v_t_249, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V f_ = v_k_2420;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_unsolved_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2421 = heff_take_field(v_hd_2419, 1);
  V v_malg_2422 = heff_get_n(v_hd_2419, 2, 3);
  switch (heff_tag_of(v_unsolved_2418)) {
  case TAG_Nil: {
    heff_drop(v_bind_2421);
    heff_drop(v_malg_2422);
    V f_ = v_k_2420;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2423 = heff_field(v_unsolved_2418, 0);
    heff_take_n(v_unsolved_2418, 1ULL, 2);
    V v_name_2425 = heff_take_field(v_u_2423, 0);
    V v_span_2426 = heff_get_n(v_u_2423, 1, 2);
    V v_t_2427 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0), heff_strAppend(v_name_2425, ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1)));
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2427, v_span_2426, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(v_malg_2422, 1, (V[]){v_t_2430}));
    V f_ = v_bind_2421;
    args[0] = v_t_2431;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 1, 2, (V[]){v_k_2420, v_x_2413});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2418);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2417);
  return (g_co_2ebind_24s1831149655x1541910000(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 3, 1, (V[]){v_x_2413}), v_hd_2410, v_k_2411));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2414; V a_3 = heff_dup(v_hd_2410); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 3, (V[]){v_x_2413, v_hd_2410, v_k_2411}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2414); r_; });
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2414, v_hd_2410, v_x_2413, v_k_2411})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 6, (V[]){v_hd_2410, v_gSelf_242, v_dsp_240, v_x_2414, v_x_2413, v_k_2411})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 1, 5, (V[]){v_hd_2410, v_gSelf_242, v_dsp_240, v_x_2413, v_k_2411})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_aval_244 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_gSelf_242 = heff_env(self)[2];
  V v_dsp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2eelab_2etoplevel_2efailedAt_clo), 1, (V[]){v_aval_244}));
  return (g_heff_2eelab_2eenvironment_2ecatchE(v_t_249, v_t_2412, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 4, (V[]){v_gSelf_242, v_hd_2410, v_dsp_240, v_k_2411})));
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V v_kf_240, V v_n_241, V v_g_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_f_245});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 4);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 3);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_243, 0ULL, 1);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    heff_drop(v_n_241);
    return v_g_242;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_x11_2427 = heff_field(v_n_241, 0);
      V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_2427)) {
      case TAG_DeclEquations: {
        V v_x113_2431 = heff_field(v_x11_2427, 2);
        heff_take_n(v_x11_2427, 4ULL, 5);
        switch (heff_tag_of(v_x113_2431)) {
        case TAG_AsDefinition: {
          heff_drop(v_kf_240);
          heff_drop(v_x_2426);
          heff_drop_cell(v_ru_24n_241_24At, 2);
          return v_g_242;
        }
        case TAG_AsInstance: {
          V v_k_2434 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2426)}));
          V v_key_2435 = heff_tr(heff_call(v_kf_240, 1, (V[]){heff_dup(v_x_2426)}));
          V v_t_2437;
          if (heff_strEq_c_lent(v_key_2435, v_x_2426, 0)) {
            heff_drop(v_x_2426);
            heff_drop(v_key_2435);
            v_t_2437 = ((V)&g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0);
          } else {
            int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_key_2435, 0)) - heff_unbox_word(heff_strLength(v_x_2426)));
            v_t_2437 = heff_strSlice(v_key_2435, MK_INT(0LL), heff_box_word((v_t_2436 - ((int64_t)1ULL))));
          }
          V v_t_2438 = (g_list_2ekeepIf_24s2115931744x466898799(v_k_2434, heff_take_field(v_g_242, 7)));
          V v_t_2439 = heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_k_2434, v_t_2437}), v_t_2438});
          return ({ V rv_7 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_g_242, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
        }
        default: return heff_nomatch(v_x113_2431);
        }
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_2427, 0ULL, 5);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_2427, 0ULL, 4);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_2427, 0ULL, 3);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2427, 0ULL, 2);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2427, 0ULL, 1);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      default: return heff_nomatch(v_x11_2427);
      }
    }
    default: return heff_nomatch(v_n_241);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithBrokenInstance(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24Left = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2411, 1, 8)));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_246, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2415 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_241, 1, 9), v_t_2413, v_t_2414));
      return (g_heff_2eelab_2etoplevel_2etopBroken_24tok1(v_ru_24x41_244_24Left, v_kf_240, v_t_247, v_n_242, v_t_2415));
    }
    case TAG_Right: {
      V v_r_2416 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_isInstance_2417 = heff_take_field(v_r_2416, 3);
      V v_key_2418 = heff_take_field(v_r_2416, 1);
      V v_name_2419 = heff_take_field(v_r_2416, 0);
      V v_prim_2420 = heff_take_field(v_r_2416, 2);
      V v_entry_2421 = heff_take_field(v_r_2416, 4);
      V v_failed_2422 = heff_get_n(v_r_2416, 5, 6);
      V v_g_2423 = heff_take_field(v_acc_241, 0);
      V v_t_2428;
      if ((heff_dup(v_prim_2420) == NTAG(TAG_True))) {
        heff_drop(v_prim_2420);
        HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_2423, 1), v_key_2418));
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            heff_drop(v_entry_2421);
            V v_e_2427 = v_field_2426;
            heff_drop(v_e_2427);
            v_t_2428 = v_g_2423;
          } else {
            heff_drop(v_field_2426);
            v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2418), v_entry_2421, v_g_2423));
          }
        }
      } else {
        heff_drop(v_prim_2420);
        v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2418), v_entry_2421, v_g_2423));
      }
      V v_t_2429 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_2419), heff_dup(v_key_2418), v_t_2428));
      V v_globals_2430 = ({ V a_0 = v_isInstance_2417; V a_1 = heff_dup(v_key_2418); V a_2 = v_name_2419; V a_3 = v_t_2429; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_2417); r_; });
      V v_t_2434;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2431 = heff_dup(heff_field(v_st_245, 0));
        v_t_2434 = v_c_2431;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2434, 1, 8)));
      V v_t_2436 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2435));
      V v_t_2438;
      switch (heff_tag_of(v_failed_2422)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2437 = heff_field(v_failed_2422, 0);
        heff_take_n(v_failed_2422, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2437, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2437, 5);
          v_t_2438 = NTAG(TAG_Nil);
        } else {
          v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2437, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_failed_2422);
      }
      V v_diags_2439 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_241, 1), v_t_2436, v_t_2438));
      V v_t_2443;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2440 = heff_dup(heff_field(v_st_245, 0));
        v_t_2443 = v_c_2440;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2455 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_241, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam0, 1, 1, (V[]){heff_dup(v_st_245)}), heff_get_n(v_t_2443, 0, 8)));
      V v_t_2459;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2456 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2459 = v_c_2456;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2460 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2459, 6, 8), heff_take_field(v_acc_241, 8)));
      V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_2418, heff_take_field(v_acc_241, 2)});
      V v_t_2464;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2463 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        v_t_2464 = v_s_2463;
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_name_2419, v_t_2464}), heff_take_field(v_acc_241, 6)});
      return ({ V rv_0 = v_globals_2430; V rv_1 = v_diags_2439; V rv_2 = v_t_2461; V rv_6 = v_t_2465; V rv_7 = v_infos_2455; V rv_8 = v_trace_2460; V rr_ = heff_rec_reuse_nf(v_acc_241, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args) {
  V v_u_2450 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_ty_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2450);
  V v_t_2454;
  switch (heff_tag_of(v_st_245)) {
  case TAG_MkSt: {
    V v_c_2451 = heff_field(v_st_245, 0);
    heff_take_n(v_st_245, 1ULL, 3);
    v_t_2454 = v_c_2451;
    break;
  }
  default: heff_nomatch(v_st_245);
  }
  V f_ = v_ty_2449;
  args[0] = heff_get_n(v_t_2454, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args) {
  V v_n_2444 = args[0];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2445 = heff_take_field(v_n_2444, 0);
  V v_name_2446 = heff_take_field(v_n_2444, 1);
  V v_key_2447 = heff_take_field(v_n_2444, 2);
  V v_member_2448 = heff_take_field(v_n_2444, 3);
  V v_ty_2449 = heff_get_n(v_n_2444, 4, 5);
  return heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_2445, v_name_2446, v_key_2447, v_member_2448, heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam1, 1, 2, (V[]){v_st_245, v_ty_2449})});
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  V v_diags_243 = heff_take_field(v_acc_240, 1);
  V v_infos_244 = heff_take_field(v_acc_240, 7);
  V v_trace_245 = heff_take_field(v_acc_240, 8);
  V v_globals_246 = heff_take_field(v_acc_240, 0);
  V v_keys_247 = heff_take_field(v_acc_240, 2);
  V v_broken_248 = heff_take_field(v_acc_240, 3);
  V v_watches_249 = heff_take_field(v_acc_240, 4);
  V v_tests_2410 = heff_take_field(v_acc_240, 5);
  V v_spans_2411 = heff_get_n(v_acc_240, 6, 9);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_2412 = heff_field(v_x3_242, 0);
    V v_st_2413 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_Left: {
      V v_d_2414 = heff_field(v_x31_2412, 0);
      heff_take_n(v_x31_2412, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_2418;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2415 = heff_dup(heff_field(v_st_2413, 0));
        v_t_2418 = v_c_2415;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2418, 1, 8)));
      V v_t_2420 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2419));
      V v_t_2421;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_2414, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_2414, 5);
        v_t_2421 = NTAG(TAG_Nil);
      } else {
        v_t_2421 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_2414, NTAG(TAG_Nil)});
      }
      V v_diags_2422 = (g_list_2efoldl_24f106956753x832547985(v_diags_243, v_t_2420, v_t_2421));
      V v_t_2426;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2423 = heff_dup(heff_field(v_st_2413, 0));
        v_t_2426 = v_c_2423;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_infos_2438 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(v_infos_244, heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam0, 1, 1, (V[]){heff_dup(v_st_2413)}), heff_get_n(v_t_2426, 0, 8)));
      V v_t_2442;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2439 = heff_field(v_st_2413, 0);
        heff_take_n(v_st_2413, 1ULL, 3);
        v_t_2442 = v_c_2439;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_trace_2443 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2442, 6, 8), v_trace_245));
      return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_246, v_diags_2422, v_keys_247, v_broken_248, v_watches_249, v_tests_2410, v_spans_2411, v_infos_2438, v_trace_2443});
    }
    case TAG_Right: {
      V v_entry_2444 = heff_field(v_x31_2412, 0);
      heff_take_n(v_x31_2412, 1ULL, 1);
      V v_t_2448;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2445 = heff_dup(heff_field(v_st_2413, 0));
        v_t_2448 = v_c_2445;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2448, 1, 8)));
      V v_t_2450 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2449));
      V v_diags_2451 = (g_list_2efoldl_24s1370882877x364361272(v_diags_243, v_t_2450));
      V v_t_2455;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2452 = heff_dup(heff_field(v_st_2413, 0));
        v_t_2455 = v_c_2452;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_infos_2467 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(v_infos_244, heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam2, 1, 1, (V[]){heff_dup(v_st_2413)}), heff_get_n(v_t_2455, 0, 8)));
      V v_t_2471;
      switch (heff_tag_of(v_st_2413)) {
      case TAG_MkSt: {
        V v_c_2468 = heff_field(v_st_2413, 0);
        heff_take_n(v_st_2413, 1ULL, 3);
        v_t_2471 = v_c_2468;
        break;
      }
      default: heff_nomatch(v_st_2413);
      }
      V v_trace_2472 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2471, 6, 8), v_trace_245));
      V v_t_2473 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2444}), v_watches_249});
      return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_246, v_diags_2451, v_keys_247, v_broken_248, v_t_2473, v_tests_2410, v_spans_2411, v_infos_2467, v_trace_2472});
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_ty_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  V v_t_2437;
  switch (heff_tag_of(v_st_2413)) {
  case TAG_MkSt: {
    V v_c_2434 = heff_field(v_st_2413, 0);
    heff_take_n(v_st_2413, 1ULL, 3);
    v_t_2437 = v_c_2434;
    break;
  }
  default: heff_nomatch(v_st_2413);
  }
  V f_ = v_ty_2432;
  args[0] = heff_get_n(v_t_2437, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args) {
  V v_n_2427 = args[0];
  V v_st_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2428 = heff_take_field(v_n_2427, 0);
  V v_name_2429 = heff_take_field(v_n_2427, 1);
  V v_key_2430 = heff_take_field(v_n_2427, 2);
  V v_member_2431 = heff_take_field(v_n_2427, 3);
  V v_ty_2432 = heff_get_n(v_n_2427, 4, 5);
  return heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_2428, v_name_2429, v_key_2430, v_member_2431, heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam1, 1, 2, (V[]){v_st_2413, v_ty_2432})});
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args) {
  V v_u_2462 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_ty_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2462);
  V v_t_2466;
  switch (heff_tag_of(v_st_2413)) {
  case TAG_MkSt: {
    V v_c_2463 = heff_field(v_st_2413, 0);
    heff_take_n(v_st_2413, 1ULL, 3);
    v_t_2466 = v_c_2463;
    break;
  }
  default: heff_nomatch(v_st_2413);
  }
  V f_ = v_ty_2461;
  args[0] = heff_get_n(v_t_2466, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args) {
  V v_n_2456 = args[0];
  V v_st_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2457 = heff_take_field(v_n_2456, 0);
  V v_name_2458 = heff_take_field(v_n_2456, 1);
  V v_key_2459 = heff_take_field(v_n_2456, 2);
  V v_member_2460 = heff_take_field(v_n_2456, 3);
  V v_ty_2461 = heff_get_n(v_n_2456, 4, 5);
  return heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_2457, v_name_2458, v_key_2459, v_member_2460, heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam3, 1, 2, (V[]){v_st_2413, v_ty_2461})});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_infos_248 = heff_take_field(v_c_247, 0);
  V v_recovered_249 = heff_take_field(v_c_247, 1);
  V v_poisoned_2410 = heff_take_field(v_c_247, 2);
  V v_metas_2411 = heff_take_field(v_c_247, 3);
  V v_nextMeta_2412 = heff_take_field(v_c_247, 4);
  V v_postponed_2413 = heff_take_field(v_c_247, 5);
  V v_trace_2414 = heff_get_n(v_c_247, 6, 8);
  V v_c_2415 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_242));
  V v_t_2420;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_d_2417 = heff_field(v_st_243, 1);
    V v_w_2418 = heff_field(v_st_243, 2);
    V v_ru_24st_243_24MkSt = heff_take_reuse_n(v_st_243, 6ULL, 3);
    V v_t_2419 = heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_248, v_recovered_249, v_poisoned_2410, v_metas_2411, v_nextMeta_2412, v_postponed_2413, v_trace_2414, NTAG(TAG_Nothing)});
    v_t_2420 = heff_tag_at_n(v_ru_24st_243_24MkSt, TAG_MkSt, 3, (V[]){v_t_2419, v_d_2417, v_w_2418});
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  return heff_tail(v_c_2415, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, heff_dup(v_n_242), v_key_240}), v_t_2420});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args) {
  V v_a_2469 = args[0];
  V v_a_2470 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2469}), v_a_2470});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2468);
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2421; V a_4 = v_x_2426; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_n_242); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_2428 = args[1];
  V v_n_242 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  V v_c_2467;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2429 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_DeclEquations: {
      V v_x113_2433 = heff_field(v_x11_2429, 2);
      V v_tyN_2434 = heff_field(v_x11_2429, 3);
      heff_take_n(v_x11_2429, 12ULL, 5);
      switch (heff_tag_of(v_x113_2433)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2434);
        v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2440;
        switch (heff_tag_of(v_tyN_2434)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_tyN_2434, 1);
          heff_take_n(v_tyN_2434, 2ULL, 2);
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_tyN_2434);
        }
        V v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2426, 0))));
        v_c_2467 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_t_2440, NTAG(TAG_Nil), MK_INT(0LL), v_t_2441));
        break;
      }
      default: heff_nomatch(v_x113_2433);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2429, 0ULL, 5);
      v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2429, 0ULL, 4);
      v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2429, 0ULL, 3);
      v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2429, 0ULL, 2);
      v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2429, 0ULL, 1);
      v_c_2467 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo);
      break;
    }
    default: heff_nomatch(v_x11_2429);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2421, v_x_2426});
  heff_room[2] = v_z_2428;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 2, 5, (V[]){v_n_242, v_x_2426, v_key_240, v_g_241, v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_dup(heff_rfield(v_x_2421, 1));
  V v_c_2425;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_MkTyp: {
    V v_f_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    V v_t_2424 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2425 = heff_tr(heff_call(v_f_2423, 1, (V[]){v_t_2424}));
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_n_242, v_key_240, v_g_241, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_diags_243 = (g_heff_2eelab_2etoplevel_2eonceEach(NTAG(TAG_Nil), v_t_242));
    V v_keys_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    return ({ V rv_1 = v_diags_243; V rv_2 = v_keys_244; V rv_3 = v_broken_245; V rv_4 = v_watches_246; V rv_5 = v_tests_247; V rv_6 = v_spans_248; V rv_7 = v_infos_249; V rv_8 = v_trace_2410; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_241, 0);
    V v_rest_2412 = heff_field(v_x3_241, 1);
    V v_t_2413 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2411)));
    V t_0 = v_t_2413;
    V t_1 = v_rest_2412;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 1, 8);
    HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = heff_rfield(v_d_241, 1); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_e_247 = v_field_246;
        heff_drop(v_e_247);
        V v_g_248 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_acc_240, 0)));
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
        V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_take_field(v_acc_240, 6)});
        return ({ V rv_0 = v_g_248; V rv_2 = v_t_249; V rv_6 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
      } else {
        heff_drop(v_field_246);
        V v_g_2412 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
        V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_acc_240, 6)});
        return ({ V rv_0 = v_g_2412; V rv_2 = v_t_2413; V rv_6 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
      }
    }
  } else {
    heff_drop(v_t_242);
    V v_g_2416 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_2416; V rv_2 = v_t_2417; V rv_6 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
}
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2etoplevel_2eappendM_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM_24tok2(a[0], a[1], a[2]);
}