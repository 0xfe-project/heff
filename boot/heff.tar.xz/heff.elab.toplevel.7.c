// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_ForNominative 23095
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSt 48854
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_val 326043
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s935789828x1526377372(V, V, V);
V g_co_2ebind_24s935789828x1526377372_entry(V self, V *a);
extern Clo g_co_2ebind_24s935789828x1526377372_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddInstance(V, V, V);
V g_heff_2eelab_2eglobals_2eaddInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddInstance_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V);
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2elamsOf(V, V);
V g_heff_2eelab_2etoplevel_2elamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elamsOf_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2eparamsOf(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsOf_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2etagSynonym(V);
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfWalk(a[0]);
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return (g_heff_2eelab_2etoplevel_2eselfTermF(v_t_243, v_k_240, v_d_241, v_t_242));
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalChk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_x_248, 0))});
  V f_ = v_k_247;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_x_248})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_245;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_call(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSynonym_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSynonym(V v_ge_240) {
top: ;
  V v_it_241 = (g_heff_2eelab_2etoplevel_2eparamsOf(MK_INT(0LL), MK_INT(0LL), heff_take_field(v_ge_240, 1)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ge_240, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_242 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Just = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_MkPair: {
      V v_i_243 = heff_field(v_it1_242, 0);
      V v_k_244 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      V v_it_245 = (g_heff_2eelab_2etoplevel_2elamsOf(MK_INT(0LL), heff_get_n(v_ge_240, 0, 4)));
      switch (heff_tag_of(v_it_245)) {
      case TAG_MkPair: {
        V v_n_246 = heff_field(v_it_245, 0);
        V v_it2_247 = heff_field(v_it_245, 1);
        heff_take_n(v_it_245, 3ULL, 2);
        switch (heff_tag_of(v_it2_247)) {
        case TAG_SLocal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          V v_t_2418 = heff_field(v_it2_247, 0);
          V v_args_2419 = heff_field(v_it2_247, 1);
          heff_take_n(v_it2_247, 3ULL, 2);
          if (heff_intEq_c(v_n_246, heff_intAdd(v_i_243, heff_dup(v_k_244)))) {
            V v_t_2421 = ({ V a_0 = heff_dup(v_k_244); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2419); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
              heff_drop(v_t_2421);
              return heff_tag_at_n(v_ru_24it_241_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_k_244})});
            } else {
              heff_drop_cell(v_ru_24it_241_24Just, 1);
              heff_drop(v_k_244);
              heff_drop(v_t_2418);
              heff_drop(v_t_2421);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop_cell(v_ru_24it_241_24Just, 1);
            heff_drop(v_k_244);
            heff_drop(v_t_2418);
            heff_drop(v_args_2419);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_SMatch: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_247);
        }
      }
      default: return heff_nomatch(v_it_245);
      }
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSynonym(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_a_247));
        v_a_2410 = heff_bool(!(heff_dup(v_a_249) == NTAG(TAG_True)));
        heff_drop(v_a_249);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_a_2410) == NTAG(TAG_True))) {
      heff_drop(v_a_2410);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_a_2410);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eupdatePath_str0, 51, "an update sets a field by its name: `{ r | x = v }`");
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eupdatePath_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eupdatePath(V v_sp_240, V v_x2_241, V v_c_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_242);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam0, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_x21_249 = heff_field(v_x2_241, 0);
    V v_x22_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_249, 0);
      V v_xsp_2412 = heff_field(v_x21_249, 1);
      heff_take_n(v_x21_249, 3ULL, 2);
      switch (heff_tag_of(v_x22_2410)) {
      case TAG_Nil: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam1, 2, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_c_242});
      }
      case TAG_Cons: {
        V v_c_2417 = (g_heff_2eelab_2etoplevel_2eupdatePath(heff_dup(v_sp_240), v_x22_2410, v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam2, 2, 4, (V[]){v_c_2417, v_x_2411, v_xsp_2412, v_sp_240});
      }
      default: return heff_nomatch(v_x22_2410);
      }
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eupdatePath(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eupdatePath_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  args[0] = v_t_248;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_xsp_2412 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_UpdateTo, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_c_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_xsp_2412 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, NTAG(TAG_Nil)});
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_UpdateIn, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_t_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_xsp_2412 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam3, 1, 4, (V[]){v_k_2419, v_x_2411, v_xsp_2412, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1, 2, 3, (V[]){v_a_245, v_x_243, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2412, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2410 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_t_2411 = v_a_2410;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_a_2412 = ({ V a_0 = v_t_2411; V a_1 = v_a_248; V r_ = (g_heff_2eelab_2erules_2easSmall(a_0, a_1)); heff_drop(v_a_248); r_; });
  V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(v_xs_244));
  V f_ = v_c_2413;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3, 1, 2, (V[]){v_k_247, v_a_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2, 1, 4, (V[]){v_x_243, v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithArgs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 21, "`; give it as `{...}`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 36, "cannot infer the implicit argument `");
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_e_245 = (g_heff_2eelab_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, heff_take_field(v_d_241, 0), heff_dup(v_aval_244)));
  V v_t_246 = heff_get_n(v_d_241, 2, 4);
  V v_m_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_m_248 = heff_tr(heff_call(v_f_247, 2, (V[]){v_e_245, heff_dup(v_aval_244)}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 2, 4, (V[]){v_m_248, v_aval_244, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_aval_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2efailedAt(v_aval_244, v_s_2412, heff_dup(v_hd_249), heff_get_n(v_hd_249, 0, 3)));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V f_ = v_k_2423;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_unsolved_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_unsolved_2421)) {
  case TAG_Nil: {
    heff_drop_rec(v_hd_2422, 3);
    V f_ = v_k_2423;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2424 = heff_field(v_unsolved_2421, 0);
    heff_take_n(v_unsolved_2421, 1ULL, 2);
    V v_t_2426 = heff_strAppend(heff_take_field(v_u_2424, 0), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0));
    V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1), v_t_2426), heff_get_n(v_u_2424, 1, 2), NTAG(TAG_Nothing)});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2422, 2), 1, (V[]){v_t_2429}));
    V f_ = heff_get_n(v_hd_2422, 1, 3);
    args[0] = v_t_2430;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam8, 1, 2, (V[]){v_k_2423, v_x_2416});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2421);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  return (g_co_2ebind_24s935789828x1526377372(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 3, 1, (V[]){v_x_2416}), v_hd_249, v_k_2410));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2419);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2417; V a_3 = heff_dup(v_hd_249); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 1, 3, (V[]){v_x_2416, v_hd_249, v_k_2410}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2417); r_; });
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2418);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2417, v_hd_249, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2417, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 5, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_m_248 = heff_env(self)[0];
  V v_aval_244 = heff_env(self)[1];
  V v_gSelf_242 = heff_env(self)[2];
  V v_dsp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tr(heff_call(v_m_248, 2, (V[]){heff_dup(v_hd_249), heff_dup(heff_rfield(v_hd_249, 0))}));
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 2, (V[]){v_aval_244, heff_dup(v_hd_249)})})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_t_2415;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 1, 4, (V[]){v_gSelf_242, v_hd_249, v_dsp_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V v_kf_240, V v_n_241, V v_g_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_field(v_n_241, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_245)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2410)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2415)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2419)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2422)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return v_g_242;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
    V v_t_2452;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_x11_2427 = heff_field(v_n_241, 0);
      switch (heff_tag_of(v_x11_2427)) {
      case TAG_DeclEquations: {
        V v_x113_2431 = heff_field(v_x11_2427, 2);
        V v_tyN_2432 = heff_field(v_x11_2427, 3);
        switch (heff_tag_of(v_x113_2431)) {
        case TAG_AsDefinition: {
          heff_drop_cell(v_ru_24t_2425_24Just, 1);
          v_t_2452 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_AsInstance: {
          V v_t_2436;
          switch (heff_tag_of(v_tyN_2432)) {
          case TAG_At: {
            V v_s_2435 = heff_field(v_tyN_2432, 1);
            v_t_2436 = heff_dup(v_s_2435);
            break;
          }
          default: heff_nomatch(v_tyN_2432);
          }
          v_t_2452 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_t_2436});
          break;
        }
        default: heff_nomatch(v_x113_2431);
        }
        break;
      }
      case TAG_DeclDefine: {
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTest: {
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2427);
      }
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    switch (heff_tag_of(v_t_2452)) {
    case TAG_Nothing: {
      heff_drop(v_kf_240);
      heff_drop(v_x_2426);
      return v_g_242;
    }
    case TAG_Just: {
      heff_take_n(v_t_2452, 0ULL, 1);
      V v_t_2454 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2426)}));
      V v_key_2455 = heff_tr(heff_call(v_kf_240, 1, (V[]){heff_dup(v_x_2426)}));
      V v_t_2458;
      if (heff_strEq_c(heff_dup(v_key_2455), heff_dup(v_x_2426))) {
        heff_drop(v_x_2426);
        heff_drop(v_key_2455);
        v_t_2458 = ((V)&g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0);
      } else {
        V v_t_2457 = heff_intSub(heff_strLength(heff_dup(v_key_2455)), heff_strLength(v_x_2426));
        v_t_2458 = heff_strSlice(v_key_2455, MK_INT(0LL), heff_intSub(v_t_2457, MK_INT(1LL)));
      }
      HEFF_LAST return g_heff_2eelab_2eglobals_2eaddInstance(v_t_2454, v_t_2458, v_g_242);
    }
    default: return heff_nomatch(v_t_2452);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewithBrokenInstance(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2412 = heff_get_n(v_t_2411, 1, 8);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
      V v_t_2414 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2413));
      V v_t_2416;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        heff_drop_rec(v_d_246, 5);
        v_t_2416 = NTAG(TAG_Nil);
      } else {
        v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2417 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_241, 1, 9), v_t_2414, v_t_2416));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2417);
    }
    case TAG_Right: {
      V v_r_2418 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_g_2419 = heff_take_field(v_acc_241, 0);
      V v_t_2420 = heff_take_field(v_r_2418, 2);
      V v_t_2423;
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_t_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2418, 1)), heff_rfield(v_g_2419, 1)));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_Nothing: {
          v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 4)), v_g_2419));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2421, 0ULL, 1);
          v_t_2423 = v_g_2419;
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
      } else {
        heff_drop(v_t_2420);
        v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 4)), v_g_2419));
      }
      V v_t_2424 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2418, 0)), heff_dup(heff_rfield(v_r_2418, 1)), v_t_2423));
      V v_globals_2425 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2418, 3), heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 0)), v_t_2424));
      V v_t_2429;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2426 = heff_dup(heff_field(v_st_245, 0));
        v_t_2429 = v_c_2426;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2430 = heff_get_n(v_t_2429, 1, 8);
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      V v_t_2432 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2431));
      V v_t_2433 = heff_take_field(v_r_2418, 5);
      V v_t_2436;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2434 = heff_field(v_t_2433, 0);
        heff_take_n(v_t_2433, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2434, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          heff_drop_rec(v_d_2434, 5);
          v_t_2436 = NTAG(TAG_Nil);
        } else {
          v_t_2436 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_2434, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_diags_2437 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_241, 1), v_t_2432, v_t_2436));
      V v_t_2440;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2439 = heff_field(v_n_242, 1);
        v_t_2440 = heff_dup(v_s_2439);
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2418, 0), v_t_2440});
      V v_spans_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_take_field(v_acc_241, 6)});
      V v_t_2446;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2443 = heff_dup(heff_field(v_st_245, 0));
        v_t_2446 = v_c_2443;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2447 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2446, 0, 8), heff_take_field(v_acc_241, 7)));
      V v_t_2451;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2448 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2451 = v_c_2448;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2452 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2451, 6, 8), heff_take_field(v_acc_241, 8)));
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2418, 1, 6), heff_take_field(v_acc_241, 2)});
      return ({ V rv_0 = v_globals_2425; V rv_1 = v_diags_2437; V rv_2 = v_t_2453; V rv_6 = v_spans_2442; V rv_7 = v_infos_2447; V rv_8 = v_trace_2452; V rr_ = heff_rec_reuse_nf(v_acc_241, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2410 = heff_get_n(v_t_249, 1, 8);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_diags_2415 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2412, v_t_2414));
      V v_t_2419;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2416 = heff_dup(heff_field(v_st_244, 0));
        v_t_2419 = v_c_2416;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2420 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2419, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2424;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2421 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2424 = v_c_2421;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2425 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2424, 6, 8), heff_take_field(v_acc_240, 8)));
      return ({ V rv_1 = v_diags_2415; V rv_7 = v_infos_2420; V rv_8 = v_trace_2425; V rr_ = heff_rec_reuse_nf(v_acc_240, 125ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    case TAG_Right: {
      V v_entry_2426 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2430;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2427 = heff_dup(heff_field(v_st_244, 0));
        v_t_2430 = v_c_2427;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2431 = heff_get_n(v_t_2430, 1, 8);
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
      V v_t_2433 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2432));
      V v_diags_2434 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2433));
      V v_t_2438;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2435 = heff_dup(heff_field(v_st_244, 0));
        v_t_2438 = v_c_2435;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2439 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2438, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2443;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2440 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2443 = v_c_2440;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2444 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2443, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2426}), heff_dup(heff_rfield(v_acc_240, 4))});
      return ({ V rv_1 = v_diags_2434; V rv_4 = v_t_2445; V rv_7 = v_infos_2439; V rv_8 = v_trace_2444; V rr_ = heff_rec_reuse_nf(v_acc_240, 109ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 15603u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_t_248 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_247, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_248}), v_st_243});
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2418;
      switch (heff_tag_of(v_st_2411)) {
      case TAG_MkSt: {
        V v_d_2416 = heff_field(v_st_2411, 1);
        V v_w_2417 = heff_field(v_st_2411, 2);
        V v_ru_24st_2411_24MkSt = heff_take_reuse_n(v_st_2411, 6ULL, 3);
        v_t_2418 = heff_tag_at_n(v_ru_24st_2411_24MkSt, TAG_MkSt, 3, (V[]){v_x_2413, v_d_2416, v_w_2417});
        break;
      }
      default: heff_nomatch(v_st_2411);
      }
      V v_x1_2419 = heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x11_2420 = heff_field(v_x1_2419, 0);
        V v_st_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          heff_take_n(v_x11_2420, 1ULL, 1);
          heff_drop(v_key_240);
          heff_drop(v_g_241);
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2419_24MkPair, 2);
          V v_c_2424 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_242));
          return heff_tail(v_c_2424, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, heff_dup(v_n_242), v_key_240}), v_st_2421});
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  heff_drop(v_hd_2459);
  V f_ = v_k_2460;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args) {
  V v_a_2465 = args[0];
  V v_a_2466 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2465}), v_a_2466});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args) {
  V v_x_2464 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2464);
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2425; V a_4 = v_x_2430; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_n_242); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_2432 = args[1];
  V v_n_242 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_x1_2458;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2433 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2433)) {
    case TAG_DeclEquations: {
      V v_x113_2437 = heff_field(v_x11_2433, 2);
      V v_tyN_2438 = heff_field(v_x11_2433, 3);
      heff_take_n(v_x11_2433, 12ULL, 5);
      switch (heff_tag_of(v_x113_2437)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2438);
        v_x1_2458 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2442;
        switch (heff_tag_of(v_tyN_2438)) {
        case TAG_At: {
          V v_s_2441 = heff_field(v_tyN_2438, 1);
          heff_take_n(v_tyN_2438, 2ULL, 2);
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_tyN_2438);
        }
        v_x1_2458 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442});
        break;
      }
      default: heff_nomatch(v_x113_2437);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2433, 0ULL, 5);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2433, 0ULL, 4);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2433, 0ULL, 3);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2433, 0ULL, 2);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2433);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2463;
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nothing: {
    v_c_2463 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo);
    break;
  }
  case TAG_Just: {
    V v_sp_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    V v_t_2462 = (g_heff_2esyntax_2epsurface_2eunIsTy(heff_dup(heff_rfield(v_x_2430, 0))));
    v_c_2463 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_sp_2461, NTAG(TAG_Nil), MK_INT(0LL), v_t_2462));
    break;
  }
  default: heff_nomatch(v_x1_2458);
  }
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425, v_x_2430});
  heff_room[2] = v_z_2432;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 2, 5, (V[]){v_n_242, v_x_2430, v_key_240, v_g_241, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_dup(heff_rfield(v_x_2425, 1));
  V v_c_2429;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_MkTyp: {
    V v_f_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_t_2428 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2429 = heff_tr(heff_call(v_f_2427, 1, (V[]){v_t_2428}));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_n_242, v_key_240, v_g_241, v_x_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_diags_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_keys_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    return ({ V rv_1 = v_diags_242; V rv_2 = v_keys_243; V rv_3 = v_broken_244; V rv_4 = v_watches_245; V rv_5 = v_tests_246; V rv_6 = v_spans_247; V rv_7 = v_infos_248; V rv_8 = v_trace_249; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2410 = heff_field(v_x3_241, 0);
    V v_rest_2411 = heff_field(v_x3_241, 1);
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2410)));
    V t_0 = v_t_2412;
    V t_1 = v_rest_2411;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  V v_t_246;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 1, 7);
    V v_t_244 = ({ V a_0 = heff_dup(heff_rfield(v_d_241, 1)); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  } else {
    heff_drop(v_t_242);
    v_t_246 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_g_247 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_acc_240, 0)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_247; V rv_2 = v_t_248; V rv_6 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_t_246);
    V v_g_2411 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_2411; V rv_2 = v_t_2412; V rv_6 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
}
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawOne(a[0], a[1]);
}