// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLocal 28569
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ereadback_2earrayEmpty_get(void);
V g_heff_2eelab_2ereadback_2eforcedRb(V);
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eforcedRb_clo;
V g_heff_2eelab_2ereadback_2egoRT(V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_clo;
V g_heff_2eelab_2ereadback_2elocalArgs(V);
V g_heff_2eelab_2ereadback_2elocalArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2elocalArgs_clo;
V g_heff_2eelab_2ereadback_2ereadbBare(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_clo;
V g_heff_2eelab_2ereadback_2ereadbCloEl(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbCloEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbCloEl_clo;
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_clo;
V g_heff_2eelab_2ereadback_2ereadbCloTy(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbCloTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbCloTy_clo;
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;

static V g_heff_2eelab_2ereadback_2earrayEmpty_val;
static HEFF_ONCE g_heff_2eelab_2ereadback_2earrayEmpty_st;
static V g_heff_2eelab_2ereadback_2earrayEmpty_init(void) {
  return heff_dup(g_array_2eempty_get());
}
V g_heff_2eelab_2ereadback_2earrayEmpty_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ereadback_2earrayEmpty_st)) return g_heff_2eelab_2ereadback_2earrayEmpty_val;
  return heff_global(&g_heff_2eelab_2ereadback_2earrayEmpty_val, &g_heff_2eelab_2ereadback_2earrayEmpty_st, g_heff_2eelab_2ereadback_2earrayEmpty_init);
}
Clo g_heff_2eelab_2ereadback_2elocalArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2elocalArgs_entry, 1, 0};

V g_heff_2eelab_2ereadback_2elocalArgs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_VNeu: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 5);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_HLocal: {
        V v_l_248 = heff_field(v_x121_243, 0);
        V v_ru_24x121_243_24HLocal = heff_take_reuse_n(v_x121_243, 1ULL, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_SpId: {
          V v_x2_249 = (g_heff_2eelab_2ereadback_2elocalArgs(v_sp_241));
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
            heff_drop(v_l_248);
            heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_xs_2410 = heff_field(v_x2_249, 0);
            heff_take_n(v_x2_249, 1ULL, 1);
            return heff_tag_at_n(v_ru_24x121_243_24HLocal, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_l_248, v_xs_2410})});
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_take_n(v_x122_244, 0ULL, 3);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HMeta: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    case TAG_VCode: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_take_n(v_x12_242, 0ULL, 2);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2ereadback_2elocalArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2elocalArgs(a[0]);
}
Clo g_heff_2eelab_2ereadback_2ereadbSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbSpine_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbSpine(V v_r_240, V v_n_241, V v_x3_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return v_t_243;
  }
  case TAG_SpApp: {
    V v_sp_244 = heff_field(v_x3_242, 0);
    V v_v_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24SpApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_heff_2eelab_2ereadback_2ereadbSpine(heff_dup(v_r_240), heff_dup(v_n_241), v_sp_244, v_t_243));
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_245}));
    return heff_tag_at_n(v_ru_24x3_242_24SpApp, TAG_SApp, 2, (V[]){v_t_246, v_t_247});
  }
  case TAG_SpProj: {
    V v_sp_248 = heff_field(v_x3_242, 0);
    V v_x_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24SpProj = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_248, v_t_243));
    return heff_tag_at_n(v_ru_24x3_242_24SpProj, TAG_SProj, 2, (V[]){v_t_2410, v_x_249});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x3_242, 0);
    V v_x_2412 = heff_field(v_x3_242, 1);
    V v_v_2413 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24SpSpec = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbSpine(heff_dup(v_r_240), heff_dup(v_n_241), v_sp_2411, v_t_243));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2413}));
    return heff_tag_at_n(v_ru_24x3_242_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2414, v_x_2412, v_t_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbSpine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbSpine(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2ereadbBare_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbBare_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbBare(V v_r_240, V v_n_241, V v_h_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    V v_t_2410;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_245 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_n_241), v_i_245), MK_INT(1LL));
      v_t_2410 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_246});
      break;
    }
    case TAG_HGlobal: {
      V v_x_247 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_HMeta: {
      V v_m_248 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_249 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2410 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_248, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_249});
      break;
    }
    case TAG_HError: {
      v_t_2410 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2410);
  }
  case TAG_HGlobal: {
    V v_t_2417;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_2412 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2413 = heff_intSub(heff_intSub(heff_dup(v_n_241), v_i_2412), MK_INT(1LL));
      v_t_2417 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2414 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2414});
      break;
    }
    case TAG_HMeta: {
      V v_m_2415 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2416 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2417 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2415, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2416});
      break;
    }
    case TAG_HError: {
      v_t_2417 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2417);
  }
  case TAG_HMeta: {
    V v_m_2418 = heff_field(v_h_242, 0);
    V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
    V v_t_2419 = (g_heff_2eelab_2ereadback_2elocalArgs(heff_dup(v_sp_243)));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      V v_t_2420 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2418, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2420}));
    }
    case TAG_Just: {
      V v_idxs_2421 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2421));
      V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2ereadback_2ereadbBare_lam0, 1, 1, (V[]){v_n_241}), v_t_2422));
      V v_t_2425 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2418, heff_arrayFromList(v_t_2424), v_t_2425});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_HError: {
    V v_t_2431;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_2426 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2427 = heff_intSub(heff_intSub(heff_dup(v_n_241), v_i_2426), MK_INT(1LL));
      v_t_2431 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2428 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2431 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_HMeta: {
      V v_m_2429 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2431 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2429, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2430});
      break;
    }
    case TAG_HError: {
      v_t_2431 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2431);
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2ereadbBare_lam0(V self, V *args) {
  V v_l_2423 = args[0];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_241, v_l_2423), MK_INT(1LL));
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbCloEl_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbCloEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbCloEl_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbCloEl(V v_r_240, V v_n_241, V v_dom_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkClo: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_l_245 = heff_field(v_x4_243, 1);
    V v_f_246 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_n_247 = heff_intAdd(heff_dup(v_n_241), MK_INT(1LL));
    V v_v_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloEl_lam0, 1, 1, (V[]){v_dom_242}), NTAG(TAG_Nothing)));
    V v_x3_2411 = heff_tr(heff_call(v_f_246, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_245, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloEl_lam1, 1, 1, (V[]){v_v_249})})}));
    V v_t_2416;
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nom: {
      V v_v_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_247, v_v_2412}));
      break;
    }
    case TAG_Describe: {
      V v_v_2413 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_247, v_v_2413}));
      break;
    }
    case TAG_Become: {
      V v_v_2414 = heff_field(v_x3_2411, 0);
      V v_ru_24x3_2411_24Become = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_247, v_v_2414}));
      v_t_2416 = heff_tag_at_n(v_ru_24x3_2411_24Become, TAG_SIs, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_x3_2411);
    }
    return heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_244, v_t_2416});
  }
  case TAG_CloConst: {
    V v_t_2417 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CloConst = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_dom_242);
    V v_t_2422;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nom: {
      V v_v_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24CloConst, 1);
      v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2418}));
      break;
    }
    case TAG_Describe: {
      V v_v_2419 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24CloConst, 1);
      v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2419}));
      break;
    }
    case TAG_Become: {
      V v_v_2420 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24x4_243_24CloConst, TAG_SIs, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbCloEl(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_dom_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_dom_242;
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_v_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_v_249;
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbCloTy_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbCloTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbCloTy_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbCloTy(V v_r_240, V v_n_241, V v_dom_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkClo: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_l_245 = heff_field(v_x4_243, 1);
    V v_f_246 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_n_247 = heff_intAdd(heff_dup(v_n_241), MK_INT(1LL));
    V v_v_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_lam0, 1, 1, (V[]){v_dom_242}), NTAG(TAG_Nothing)));
    V v_x3_2411 = heff_tr(heff_call(v_f_246, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_245, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_lam1, 1, 1, (V[]){v_v_249})})}));
    V v_t_2416;
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nom: {
      V v_a_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_247, v_a_2412}));
      break;
    }
    case TAG_Describe: {
      V v_a_2413 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_247, v_a_2413}));
      break;
    }
    case TAG_Become: {
      V v_a_2414 = heff_field(v_x3_2411, 0);
      V v_ru_24x3_2411_24Become = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_247, v_a_2414}));
      v_t_2416 = heff_tag_at_n(v_ru_24x3_2411_24Become, TAG_SIsTy, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_x3_2411);
    }
    return heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_244, v_t_2416});
  }
  case TAG_CloConst: {
    V v_t_2417 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CloConst = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_dom_242);
    V v_t_2422;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nom: {
      V v_a_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24CloConst, 1);
      v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_2418}));
      break;
    }
    case TAG_Describe: {
      V v_a_2419 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24CloConst, 1);
      v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_2419}));
      break;
    }
    case TAG_Become: {
      V v_a_2420 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24x4_243_24CloConst, TAG_SIsTy, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbCloTy(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_dom_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_dom_242;
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_v_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_v_249;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF(V v_r_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 5);
    return (g_heff_2eelab_2ereadback_2ereadbBare(v_r_240, v_n_241, v_h_243, v_sp_244));
  }
  case TAG_VCode: {
    V v_a_248 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VCode = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_248}));
    return heff_tag_at_n(v_ru_24x3_242_24VCode, TAG_SCode, 1, (V[]){v_t_249});
  }
  case TAG_VLam: {
    V v_fty_2410 = heff_field(v_x3_242, 0);
    V v_body_2411 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24VLam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_fty_2410), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_n_241), v_t_2412}));
    V v_t_2414 = heff_tr(heff_call(v_fty_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2414)));
    V v_t_2427;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2418 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 2ULL, 4);
      heff_drop(v_t_2414);
      v_t_2427 = v_dom_2418;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2415, 0ULL, 3);
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeInt: {
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFloat: {
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeString: {
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeRune: {
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_t_2427 = v_t_2414;
      break;
    }
    case TAG_NoRules: {
      v_t_2427 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag_at_n(v_ru_24x3_242_24VLam, TAG_SLam, 2, (V[]){v_t_2413, (g_heff_2eelab_2ereadback_2ereadbCloEl(v_r_240, v_n_241, v_t_2427, v_body_2411))});
  }
  case TAG_VCons: {
    V v_d_2428 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VCons = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_xs_2429 = heff_take_field(v_d_2428, 2);
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_lam0, 1, 3, (V[]){v_xs_2429, v_r_240, v_n_241}));
    V v_t_2437 = ({ V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_n(v_d_2428, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_242_24VCons, TAG_SCons, 1, (V[]){v_t_2437});
  }
  case TAG_VOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbTermF_lam0(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x3_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  switch (heff_tag_of(v_x3_2431)) {
  case TAG_Nom: {
    V v_v_2432 = heff_field(v_x3_2431, 0);
    heff_take_n(v_x3_2431, 1ULL, 1);
    V f_ = heff_get_n(v_r_240, 0, 2);
    heff_room[0] = v_n_241;
    heff_room[1] = v_v_2432;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Describe: {
    V v_v_2433 = heff_field(v_x3_2431, 0);
    heff_take_n(v_x3_2431, 1ULL, 1);
    V f_ = heff_get_n(v_r_240, 0, 2);
    heff_room[0] = v_n_241;
    heff_room[1] = v_v_2433;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Become: {
    V v_v_2434 = heff_field(v_x3_2431, 0);
    V v_ru_24x3_2431_24Become = heff_take_reuse_n(v_x3_2431, 1ULL, 1);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2434}));
    return heff_tag_at_n(v_ru_24x3_2431_24Become, TAG_SIs, 1, (V[]){v_t_2435});
  }
  default: return heff_nomatch(v_x3_2431);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_entry, 4, 0};

V g_heff_2eelab_2ereadback_2egoRT(V v_r_240, V v_i_241, V v_ls_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_ls_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_ls_242)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkField: {
      V v_ty_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_i_241), heff_dup(v_ty_247)}));
      V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_lam0, 1, 1, (V[]){v_ty_247}), NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_heff_2eelab_2ereadback_2egoRT(v_r_240, heff_intAdd(v_i_241, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_242, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_lam1, 1, 1, (V[]){v_v_2411})}), v_rest_245))});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2egoRT(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2egoRT_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_ty_247;
}
V g_heff_2eelab_2ereadback_2egoRT_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_v_2411;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF(V v_r_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_VU: {
    V v_u_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VU = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return heff_tag_at_n(v_ru_24x3_242_24VU, TAG_SU, 1, (V[]){v_u_243});
  }
  case TAG_VDecode: {
    V v_h_244 = heff_field(v_x3_242, 0);
    V v_sp_245 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_h_244)) {
    case TAG_HLocal: {
      V v_i_249 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HLocal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2410 = heff_intSub(heff_intSub(heff_dup(v_n_241), v_i_249), MK_INT(1LL));
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HLocal, TAG_SLocal, 1, (V[]){v_t_2410});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2411 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HGlobal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_HMeta: {
      V v_m_2412 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HMeta = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24h_244_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2414 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2412, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2413});
      break;
    }
    case TAG_HError: {
      v_t_2414 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_244);
    }
    return heff_tag_n(TAG_SDecode, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_245, v_t_2414))});
  }
  case TAG_VFunction: {
    V v_level_2415 = heff_field(v_x3_242, 0);
    V v_dom_2416 = heff_field(v_x3_242, 1);
    V v_cod_2417 = heff_field(v_x3_242, 2);
    V v_implicit_2418 = heff_field(v_x3_242, 3);
    V v_dflt_2419 = heff_field(v_x3_242, 4);
    V v_ru_24x3_242_24VFunction = heff_take_reuse_n(v_x3_242, 31ULL, 5);
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_n_241), heff_dup(v_dom_2416)}));
    V v_t_2421 = (g_heff_2eelab_2ereadback_2ereadbCloTy(v_r_240, v_n_241, v_dom_2416, v_cod_2417));
    return heff_tag_at_n(v_ru_24x3_242_24VFunction, TAG_SFunction, 5, (V[]){v_level_2415, v_t_2420, v_t_2421, v_implicit_2418, v_dflt_2419});
  }
  case TAG_VRecord: {
    V v_level_2422 = heff_field(v_x3_242, 0);
    V v_capture_2423 = heff_field(v_x3_242, 1);
    V v_fieldTypes_2424 = heff_field(v_x3_242, 2);
    V v_defaults_2425 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 15ULL, 4);
    V v_t_2426 = heff_arrayToList(heff_take_field(v_fieldTypes_2424, 2));
    V v_t_2427 = (g_heff_2eelab_2ereadback_2egoRT(v_r_240, v_n_241, v_capture_2423, v_t_2426));
    V v_t_2428 = ({ V rv_2 = heff_arrayFromList(v_t_2427); V rr_ = heff_rec_reuse_n(v_fieldTypes_2424, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2422, v_t_2428, v_defaults_2425});
  }
  case TAG_VSum: {
    V v_st_2429 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VSum = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_xs_2430 = heff_take_field(v_st_2429, 2);
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam0, 1, 3, (V[]){v_xs_2430, v_r_240, v_n_241}));
    V v_t_2437 = ({ V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_n(v_st_2429, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_242_24VSum, TAG_SSum, 1, (V[]){v_t_2437});
  }
  case TAG_VPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2438 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VPrimArray = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_2438}));
    return heff_tag_at_n(v_ru_24x3_242_24VPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2439});
  }
  case TAG_VFixed: {
    V v_w_2440 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VFixed = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return heff_tag_at_n(v_ru_24x3_242_24VFixed, TAG_SFixed, 1, (V[]){v_w_2440});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTypeF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam1(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  V v_t_2435 = heff_tr(heff_call(v_t_2434, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_n_241;
  heff_room[1] = v_t_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam0(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2432)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam1, 1, 3, (V[]){v_xs_2432, v_r_240, v_n_241}));
}
Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(V v_n_240, V v_x3_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SpId: {
    heff_drop(v_n_240);
    return v_t_242;
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x3_241, 0);
    V v_v_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpApp = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(heff_dup(v_n_240), v_sp_243, v_t_242));
    return heff_tag_at_n(v_ru_24x3_241_24SpApp, TAG_SApp, 2, (V[]){v_t_245, (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_244))});
  }
  case TAG_SpProj: {
    V v_sp_246 = heff_field(v_x3_241, 0);
    V v_x_247 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpProj = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_246, v_t_242));
    return heff_tag_at_n(v_ru_24x3_241_24SpProj, TAG_SProj, 2, (V[]){v_t_248, v_x_247});
  }
  case TAG_SpSpec: {
    V v_sp_249 = heff_field(v_x3_241, 0);
    V v_x_2410 = heff_field(v_x3_241, 1);
    V v_v_2411 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24SpSpec = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2412 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(heff_dup(v_n_240), v_sp_249, v_t_242));
    return heff_tag_at_n(v_ru_24x3_241_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2412, v_x_2410, (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2411))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2eelab_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_a_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_246, v_a_2411));
      break;
    }
    case TAG_Describe: {
      V v_a_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_246, v_a_2412));
      break;
    }
    case TAG_Become: {
      V v_a_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x3_2410_24Become, TAG_SIsTy, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_246, v_a_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_a_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_2416));
      break;
    }
    case TAG_Describe: {
      V v_a_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_2417));
      break;
    }
    case TAG_Become: {
      V v_a_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24x4_242_24CloConst, TAG_SIsTy, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry, 3, 0};

V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(V v_i_240, V v_ls_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkField: {
      V v_ty_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_i_240), heff_dup(v_ty_246)));
      V v_v_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0, 1, 1, (V[]){v_ty_246}), NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(heff_intAdd(v_i_240, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1, 1, 1, (V[]){v_v_2410})}), v_rest_244))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_ty_246;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_v_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_v_2410;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VU = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VU, TAG_SU, 1, (V[]){v_u_242});
  }
  case TAG_VDecode: {
    V v_h_243 = heff_field(v_x3_241, 0);
    V v_sp_244 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2413;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      V v_i_248 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HLocal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_249 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_248), MK_INT(1LL));
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HLocal, TAG_SLocal, 1, (V[]){v_t_249});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2410 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HGlobal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_HMeta: {
      V v_m_2411 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HMeta = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24h_243_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2413 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2411, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2412});
      break;
    }
    case TAG_HError: {
      v_t_2413 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    return heff_tag_n(TAG_SDecode, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_244, v_t_2413))});
  }
  case TAG_VFunction: {
    V v_level_2414 = heff_field(v_x3_241, 0);
    V v_dom_2415 = heff_field(v_x3_241, 1);
    V v_cod_2416 = heff_field(v_x3_241, 2);
    V v_implicit_2417 = heff_field(v_x3_241, 3);
    V v_dflt_2418 = heff_field(v_x3_241, 4);
    V v_ru_24x3_241_24VFunction = heff_take_reuse_n(v_x3_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_n_240), heff_dup(v_dom_2415)));
    V v_t_2420 = (g_heff_2eelab_2ereadback_2ereadbCloTy_24s475907098x1695655154(v_n_240, v_dom_2415, v_cod_2416));
    return heff_tag_at_n(v_ru_24x3_241_24VFunction, TAG_SFunction, 5, (V[]){v_level_2414, v_t_2419, v_t_2420, v_implicit_2417, v_dflt_2418});
  }
  case TAG_VRecord: {
    V v_level_2421 = heff_field(v_x3_241, 0);
    V v_capture_2422 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2423 = heff_field(v_x3_241, 2);
    V v_defaults_2424 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2425 = heff_arrayToList(heff_take_field(v_fieldTypes_2423, 2));
    V v_t_2426 = (g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(v_n_240, v_capture_2422, v_t_2425));
    V v_t_2427 = ({ V rv_2 = heff_arrayFromList(v_t_2426); V rr_ = heff_rec_reuse_n(v_fieldTypes_2423, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2421, v_t_2427, v_defaults_2424});
  }
  case TAG_VSum: {
    V v_st_2428 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VSum = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2429 = heff_take_field(v_st_2428, 2);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0, 1, 2, (V[]){v_xs_2429, v_n_240}));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_n(v_st_2428, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_241_24VSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2437 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x3_241_24VPrimArray, TAG_SPrimArray, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_2437))});
  }
  case TAG_VFixed: {
    V v_w_2438 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VFixed = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VFixed, TAG_SFixed, 1, (V[]){v_w_2438});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  V v_t_2434 = heff_tr(heff_call(v_t_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_t_2434));
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2431)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1, 1, 2, (V[]){v_xs_2431, v_n_240}));
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_v_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_246, v_v_2411));
      break;
    }
    case TAG_Describe: {
      V v_v_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_246, v_v_2412));
      break;
    }
    case TAG_Become: {
      V v_v_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x3_2410_24Become, TAG_SIs, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_246, v_v_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_v_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2416));
      break;
    }
    case TAG_Describe: {
      V v_v_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2417));
      break;
    }
    case TAG_Become: {
      V v_v_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24x4_242_24CloConst, TAG_SIs, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    return (g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(v_n_240, v_h_242, v_sp_243));
  }
  case TAG_VCode: {
    V v_a_247 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCode = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x3_241_24VCode, TAG_SCode, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_247))});
  }
  case TAG_VLam: {
    V v_fty_248 = heff_field(v_x3_241, 0);
    V v_body_249 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24VLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_fty_248), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_n_240), v_t_2410));
    V v_t_2412 = heff_tr(heff_call(v_fty_248, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2412)));
    V v_t_2425;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2416 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 2ULL, 4);
      heff_drop(v_t_2412);
      v_t_2425 = v_dom_2416;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2413, 0ULL, 3);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeInt: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFloat: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeString: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeRune: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_NoRules: {
      v_t_2425 = v_t_2412;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_tag_at_n(v_ru_24x3_241_24VLam, TAG_SLam, 2, (V[]){v_t_2411, (g_heff_2eelab_2ereadback_2ereadbCloEl_24s629653326x776489016(v_n_240, v_t_2425, v_body_249))});
  }
  case TAG_VCons: {
    V v_d_2426 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCons = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2427 = heff_take_field(v_d_2426, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0, 1, 2, (V[]){v_xs_2427, v_n_240}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_n(v_d_2426, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_241_24VCons, TAG_SCons, 1, (V[]){v_t_2434});
  }
  case TAG_VOpaque: {
    heff_drop(v_n_240);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  switch (heff_tag_of(v_x3_2429)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_x3_2429, 0);
    heff_take_n(v_x3_2429, 1ULL, 1);
    return (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2430));
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_x3_2429, 0);
    heff_take_n(v_x3_2429, 1ULL, 1);
    return (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2431));
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_x3_2429, 0);
    V v_ru_24x3_2429_24Become = heff_take_reuse_n(v_x3_2429, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x3_2429_24Become, TAG_SIs, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2432))});
  }
  default: return heff_nomatch(v_x3_2429);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2eelab_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2eelab_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}
V g_heff_2eelab_2ereadback_2eforcedRb_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2eforcedRb_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2eforcedRb_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eforcedRb_entry, 1, 0};

V g_heff_2eelab_2ereadback_2eforcedRb(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2ereadback_2eforcedRb_lam0, 2, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2ereadback_2eforcedRb_lam1, 2, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2eforcedRb(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2ereadback_2eforcedRb_lam0(V self, V *args) {
  V v_n_241 = args[0];
  V v_v_242 = args[1];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_240));
  V v_t_244 = ({ V a_0 = v_mc_240; V a_1 = v_v_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(a_0, a_1)); heff_drop(v_mc_240); r_; });
  return (g_heff_2eelab_2ereadback_2ereadbTermF(v_t_243, v_n_241, v_t_244));
}
V g_heff_2eelab_2ereadback_2eforcedRb_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = args[1];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_240));
  V v_t_248 = ({ V a_0 = v_mc_240; V a_1 = v_t_246; V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_mc_240); r_; });
  return (g_heff_2eelab_2ereadback_2ereadbTypeF(v_t_247, v_n_245, v_t_248));
}