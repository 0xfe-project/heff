// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Posix 44191
#define TAG_Windows 49101
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
V g_std_2epath_2erender_2eslashesTo_240(V, V);
V g_std_2epath_2erender_2eslashesTo_240_entry(V self, V *a);
extern Clo g_std_2epath_2erender_2eslashesTo_240_clo;
HEFF_LIT(g_std_2epath_2erender_2eslashesTo_240_str0, 1, "/");
HEFF_LIT(g_std_2epath_2erender_2eslashesTo_240_str1, 1, "/");
HEFF_LIT(g_std_2epath_2erender_2eslashesTo_240_str2, 0, "");
HEFF_LIT(g_std_2epath_2erender_2eslashesTo_240_str3, 1, "/");
HEFF_LIT(g_std_2epath_2erender_2eslashesTo_240_str4, 1, "\\");
Clo g_std_2epath_2erender_2eslashesTo_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erender_2eslashesTo_240_entry, 2, 0};

V g_std_2epath_2erender_2eslashesTo_240(V v_st_240, V v_s_241) {
top: ;
  V v_t_242 = (g_prelude_2estrFind(((V)&g_std_2epath_2erender_2eslashesTo_240_str0), heff_dup(v_s_241), MK_INT(0LL)));
  V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2erender_2eslashesTo_240_str1), v_s_241, MK_INT(0LL), v_t_242, NTAG(TAG_Nil)));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return ((V)&g_std_2epath_2erender_2eslashesTo_240_str2);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_st_240)) {
    case TAG_Posix: {
      v_t_246 = ((V)&g_std_2epath_2erender_2eslashesTo_240_str3);
      break;
    }
    case TAG_Windows: {
      v_t_246 = ((V)&g_std_2epath_2erender_2eslashesTo_240_str4);
      break;
    }
    default: heff_nomatch(v_st_240);
    }
    return ({ V a_0 = v_t_246; V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_std_2epath_2erender_2eslashesTo_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2erender_2eslashesTo_240(a0, a[1]); heff_drop(a0); return r;
}