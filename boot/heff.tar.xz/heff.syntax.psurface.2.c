// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_ctx 308385
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_clo;
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_clo;
V g_heff_2esyntax_2epsurface_2earrayNone_get(void);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_clo;
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_clo;
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo;
V g_heff_2esyntax_2epsurface_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerAt_clo;
V g_heff_2esyntax_2epsurface_2eformerParam(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerParam_clo;
V g_heff_2esyntax_2epsurface_2eisOperator(V);
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eisOperator_clo;
V g_heff_2esyntax_2epsurface_2elocalName(V, V);
V g_heff_2esyntax_2epsurface_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elocalName_clo;
V g_heff_2esyntax_2epsurface_2enth(V, V);
V g_heff_2esyntax_2epsurface_2enth_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2enth_clo;
V g_heff_2esyntax_2epsurface_2eopApp(V, V, V);
V g_heff_2esyntax_2epsurface_2eopApp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eopApp_clo;
V g_heff_2esyntax_2epsurface_2eopHead(V);
V g_heff_2esyntax_2epsurface_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eopHead_clo;
V g_heff_2esyntax_2epsurface_2eoperatorGo(V, V, V);
V g_heff_2esyntax_2epsurface_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eoperatorGo_clo;
V g_heff_2esyntax_2epsurface_2eplainImplicits_get(void);
V g_heff_2esyntax_2epsurface_2eprimitiveOf(V);
V g_heff_2esyntax_2epsurface_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprimitiveOf_clo;
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V, V, V, V);
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo;
V g_heff_2esyntax_2epsurface_2espineGo(V, V);
V g_heff_2esyntax_2epsurface_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2espineGo_clo;
V g_heff_2esyntax_2epsurface_2estripIs(V);
V g_heff_2esyntax_2epsurface_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2estripIs_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_clo;
V g_heff_2esyntax_2epsurface_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etypeFormer_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_heff_2esyntax_2epsurface_2ewordOf(V);
V g_heff_2esyntax_2epsurface_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ewordOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efilter_24s1072053347x1149577110(V);
V g_list_2efilter_24s1072053347x1149577110_entry(V self, V *a);
extern Clo g_list_2efilter_24s1072053347x1149577110_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1481425034x1400185912(V, V, V, V, V);
V g_list_2efoldl_24f1481425034x1400185912_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1481425034x1400185912_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2esyntax_2epsurface_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2epsurface_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2epsurface_2eplainImplicits_st;
static V g_heff_2esyntax_2epsurface_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2epsurface_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epsurface_2eplainImplicits_st)) return g_heff_2esyntax_2epsurface_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2epsurface_2eplainImplicits_val, &g_heff_2esyntax_2epsurface_2eplainImplicits_st, g_heff_2esyntax_2epsurface_2eplainImplicits_init);
}
V g_heff_2esyntax_2epsurface_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
Clo g_heff_2esyntax_2epsurface_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eoperatorGo_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_t_245 = (g_heff_2esyntax_2epsurface_2ewordOf(heff_strByteAt(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_246, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
}
V g_heff_2esyntax_2epsurface_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eoperatorGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str3, 3, "op_");
Clo g_heff_2esyntax_2epsurface_2eisOperator_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eisOperator_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eisOperator(V v_x_240) {
top: ;
  V v_x3_247;
  if (heff_strEq_c(heff_dup(v_x_240), ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str0))) {
    heff_drop(v_x_240);
    v_x3_247 = NTAG(TAG_Nothing);
  } else {
    V v_x1_242 = (g_heff_2esyntax_2epsurface_2eoperatorGo(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nothing: {
      v_x3_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_ws_243 = heff_field(v_x1_242, 0);
      V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
      V v_t_246;
      switch (heff_tag_of(v_ws_243)) {
      case TAG_Nil: {
        v_t_246 = ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_244 = heff_field(v_ws_243, 0);
        V v_xs_245 = heff_field(v_ws_243, 1);
        heff_take_n(v_ws_243, 3ULL, 2);
        v_t_246 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
        break;
      }
      default: heff_nomatch(v_ws_243);
      }
      v_x3_247 = heff_tag_at_n(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eisOperator_str3), v_t_246)});
      break;
    }
    default: heff_nomatch(v_x1_242);
    }
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eisOperator(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str0, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str1, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str3, 0, "");
V g_heff_2esyntax_2epsurface_2elocalName_lam0(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elocalName_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2epsurface_2enth(v_xs_240, heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elocalName_str0), heff_intShow(v_i_241));
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_245 = (g_list_2efoldl_24f1481425034x1400185912(MK_INT(1LL), MK_INT(0LL), heff_clo_n(g_heff_2esyntax_2epsurface_2elocalName_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_i_241, v_xs_240));
    V v_x2_246 = (g_list_2ereplicate(v_t_245, ((V)&g_heff_2esyntax_2epsurface_2elocalName_str1)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2esyntax_2epsurface_2elocalName_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2elocalName_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(v_x_243, v_t_249);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2epsurface_2elocalName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epsurface_2elocalName(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2epsurface_2elocalName_lam0(V self, V *args) {
  V v_y_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_y_244, v_x_243);
}
Clo g_heff_2esyntax_2epsurface_2eopApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eopApp_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eopApp(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_take_field(v_sp_242, 0);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_args_246 = heff_get_n(v_sp_242, 1, 2);
    V v_t_247 = heff_get_n(heff_get_n(v_c_240, 0, 2), 1, 2);
    V v_it_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_it_248 = (g_list_2efilter_24s1072053347x1149577110(v_args_246));
    } else {
      heff_drop(v_t_247);
      v_it_248 = v_args_246;
    }
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_l_249 = heff_field(v_it_248, 0);
      V v_it2_2410 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it2_2410)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
        heff_drop(v_l_249);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_r2_2411 = heff_field(v_it2_2410, 0);
        V v_it22_2412 = heff_field(v_it2_2410, 1);
        heff_take_n(v_it2_2410, 3ULL, 2);
        switch (heff_tag_of(v_it22_2412)) {
        case TAG_Nil: {
          V v_t_2413 = (g_heff_2esyntax_2epsurface_2eisOperator(v_x_245));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            V v_t_2449;
            switch (heff_tag_of(v_l_249)) {
            case TAG_SLocal: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SGlobal: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SCode: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SApp: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLam: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SCons: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SProj: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_STag: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SMatch: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SSpecialize: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SIs: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SOpaque: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SAbandon: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SRec: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SFix: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SImplicit: {
              v_t_2449 = NTAG(TAG_True);
              break;
            }
            case TAG_SPrim: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SMetaApp: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitInt: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitString: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitBytes: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitRune: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFixed: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat32: {
              v_t_2449 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_l_249);
            }
            V v_x1_2485;
            if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
              heff_drop(v_t_2449);
              v_x1_2485 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2449);
              switch (heff_tag_of(v_r2_2411)) {
              case TAG_SLocal: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SGlobal: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SCode: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SApp: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLam: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SCons: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SProj: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_STag: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SMatch: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SSpecialize: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SIs: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SOpaque: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SAbandon: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SRec: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SFix: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SImplicit: {
                v_x1_2485 = NTAG(TAG_True);
                break;
              }
              case TAG_SPrim: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SMetaApp: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitInt: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitString: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitBytes: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitRune: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFixed: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat32: {
                v_x1_2485 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_r2_2411);
              }
            }
            if ((heff_dup(v_x1_2485) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
              heff_drop(v_l_249);
              heff_drop(v_r2_2411);
              heff_drop(v_x1_2485);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_x1_2485);
              return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_249, v_r2_2411})});
            }
          } else {
            heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
            heff_drop(v_l_249);
            heff_drop(v_r2_2411);
            heff_drop(v_t_2413);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2412, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
          heff_drop(v_l_249);
          heff_drop(v_r2_2411);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it22_2412);
        }
      }
      default: return heff_nomatch(v_it2_2410);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2epsurface_2eopApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epsurface_2eopApp(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str2, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str3, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str4, 1, "{");
Clo g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(V v_c_240, V v_xs_241, V v_dom_242, V v_r_243) {
top: ;
  V v_t_244 = heff_take_field(v_r_243, 0);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), v_xs_241, v_dom_242));
  V v_t_249 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_r_243, 2); V b_3 = heff_get_n(v_r_243, 1, 3); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str2), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str3), v_t_2410));
  return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str4), v_t_2411);
}
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str0, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str4, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str6, 5, "{_ : ");
Clo g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry, 5, 0};

V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkAbs = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_249 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x5_243_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_xs_241}); V a_3 = v_b_246; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_246); r_; });
    V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str0), v_t_249));
    V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str1), v_t_2410));
    V v_t_2412 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str2), v_t_2411));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str3), v_t_2412);
  }
  case TAG_AbsConst: {
    V v_b_2413 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2414 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2415 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    V v_t_2416 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2413; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2413); r_; });
    V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str4), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str5), v_t_2417));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str6), v_t_2418);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V v_c_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x5_243, 0);
    V v_dom_247 = heff_field(v_x5_243, 1);
    V v_cod_248 = heff_field(v_x5_243, 2);
    V v_implicit_249 = heff_field(v_x5_243, 3);
    V v_dflt_2410 = heff_field(v_x5_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(v_c_240, v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(v_c_240, v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str3)));
    } else {
      return v_s_2412;
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_x5_243, 1);
    V v_ds_2416 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 2)));
    V v_fs_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0, 2, 2, (V[]){v_c_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_t_2424 = heff_get_n(v_acc_2423, 1, 2);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_t_2424, 0);
      V v_xs_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 2)));
    V v_t_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2431));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str11); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str12), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2444 = heff_field(v_x5_243, 0);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_t2_2444;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_x5_243 = t_3;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2445 = heff_field(v_x5_243, 0);
    V v_t_2446 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(v_c_240, MK_INT(2LL), v_xs_242, v_a_2445));
    V v_s_2447 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str18), v_t_2446);
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str19), heff_strAppend(v_s_2447, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str20)));
    } else {
      return v_s_2447;
    }
  }
  case TAG_SFixed: {
    V v_w_2449 = heff_field(v_x5_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2449)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str29);
    }
    default: return heff_nomatch(v_w_2449);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(v_c_240, v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2434)));
    V v_x2_2437 = heff_tag_at_n(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, v_t_2436});
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str8);
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str9); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str3, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2epsurface_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  V v_it_245 = (g_heff_2esyntax_2epsurface_2eopApp(heff_dup(v_c_240), v_xs_242, v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2esyntax_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(v_c_240, v_p_241, v_xs_242, v_t_246);
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_MkPair: {
      V v_l_248 = heff_field(v_it1_247, 0);
      V v_r2_249 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      V v_t_2410 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_248));
      V v_t_2411 = (g_heff_2esyntax_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
      V v_t_2412 = ({ V b_0 = heff_get_n(v_t_2411, 0, 2); V r_ = (g_heff_2esyntax_2epsurface_2eopHead(b_0)); heff_drop(b_0); r_; });
      V v_t_2413 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(1LL), v_xs_242, v_r2_249));
      V v_t_2414 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str0), v_t_2413));
      V v_s_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str1), v_t_2414));
      if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str2), heff_strAppend(v_s_2415, ((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str3)));
      } else {
        return v_s_2415;
      }
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epsurface_2eprimitiveOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eprimitiveOf_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eprimitiveOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24SPrim, TAG_Just, 1, (V[]){v_x_2424});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2eprimitiveOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eprimitiveOf(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2estripIs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    return v_e_240;
  }
  case TAG_SGlobal: {
    return v_e_240;
  }
  case TAG_SCode: {
    return v_e_240;
  }
  case TAG_SApp: {
    return v_e_240;
  }
  case TAG_SLam: {
    return v_e_240;
  }
  case TAG_SCons: {
    return v_e_240;
  }
  case TAG_SProj: {
    return v_e_240;
  }
  case TAG_STag: {
    return v_e_240;
  }
  case TAG_SMatch: {
    return v_e_240;
  }
  case TAG_SSpecialize: {
    return v_e_240;
  }
  case TAG_SIs: {
    V v_e1_2418 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V t_0 = v_e1_2418;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_e_240;
  }
  case TAG_SAbandon: {
    return v_e_240;
  }
  case TAG_SRec: {
    return v_e_240;
  }
  case TAG_SFix: {
    return v_e_240;
  }
  case TAG_SImplicit: {
    return v_e_240;
  }
  case TAG_SPrim: {
    return v_e_240;
  }
  case TAG_SMetaApp: {
    return v_e_240;
  }
  case TAG_SLitInt: {
    return v_e_240;
  }
  case TAG_SLitFloat: {
    return v_e_240;
  }
  case TAG_SLitString: {
    return v_e_240;
  }
  case TAG_SLitBytes: {
    return v_e_240;
  }
  case TAG_SLitRune: {
    return v_e_240;
  }
  case TAG_SLitFixed: {
    return v_e_240;
  }
  case TAG_SLitFloat32: {
    return v_e_240;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epsurface_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2estripIs(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eunIsTy_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eunIsTy(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_SU: {
    return v_d_240;
  }
  case TAG_SDecode: {
    return v_d_240;
  }
  case TAG_SFunction: {
    return v_d_240;
  }
  case TAG_SRecord: {
    return v_d_240;
  }
  case TAG_SSum: {
    return v_d_240;
  }
  case TAG_SIsTy: {
    V v_d1_2412 = heff_field(v_d_240, 0);
    heff_take_n(v_d_240, 1ULL, 1);
    V t_0 = v_d1_2412;
    v_d_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_d_240;
  }
  case TAG_SPrimFloat: {
    return v_d_240;
  }
  case TAG_SPrimString: {
    return v_d_240;
  }
  case TAG_SPrimRune: {
    return v_d_240;
  }
  case TAG_SPrimArray: {
    return v_d_240;
  }
  case TAG_SFixed: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eunIsTy(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2etypeFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etypeFormer_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_t_240, 0);
    V v_ru_24t_240_24SU = heff_take_reuse_n(v_t_240, 1ULL, 1);
    V v_t_245 = (g_heff_2esyntax_2epsurface_2estripIs(v_body_241));
    V v_t_246;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_LargeU: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    V v_t_247 = (g_heff_2esyntax_2epsurface_2eformerAt(v_params_243, v_ns_242, v_t_245, v_t_246));
    return heff_tag_at_n(v_ru_24t_240_24SU, TAG_Just, 1, (V[]){v_t_247});
  }
  case TAG_SDecode: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_2426 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_2426;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFunction: {
    V v_dom_2445 = heff_dup(heff_field(v_t_240, 1));
    V v_t3_2446 = heff_dup(heff_field(v_t_240, 2));
    V v_t4_2447 = heff_dup(heff_field(v_t_240, 3));
    switch (heff_tag_of(v_t3_2446)) {
    case TAG_MkAbs: {
      V v_cod_2450 = heff_field(v_t3_2446, 1);
      V v_ru_24t3_2446_24MkAbs = heff_take_reuse_n(v_t3_2446, 2ULL, 2);
      switch (heff_tag_of(v_t4_2447)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          V v_it2_2457 = heff_field(v_body_241, 1);
          V v_ru_24body_241_24SLam = heff_take_reuse_n(v_body_241, 2ULL, 2);
          heff_drop_tag(v_t_240, 5);
          switch (heff_tag_of(v_it2_2457)) {
          case TAG_MkAbs: {
            V v_x_2458 = heff_field(v_it2_2457, 0);
            V v_b_2459 = heff_field(v_it2_2457, 1);
            heff_take_n(v_it2_2457, 3ULL, 2);
            V v_t_2460 = ({ V a_0 = heff_dup(v_ns_242); V a_1 = heff_dup(v_x_2458); V a_2 = v_dom_2445; V r_ = (g_heff_2esyntax_2epsurface_2eformerParam(a_0, a_1, a_2)); heff_drop(v_dom_2445); r_; });
            V v_t_2461 = heff_tag_at_n(v_ru_24t3_2446_24MkAbs, TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
            V v_t_2462 = (g_prelude_2e_2b_2b(v_params_243, v_t_2461));
            V t_0 = v_cod_2450;
            V t_1 = v_b_2459;
            V t_2 = heff_tag_at_n(v_ru_24body_241_24SLam, TAG_Cons, 2, (V[]){v_x_2458, v_ns_242});
            V t_3 = v_t_2462;
            v_t_240 = t_0;
            v_body_241 = t_1;
            v_ns_242 = t_2;
            v_params_243 = t_3;
            goto top;
          }
          case TAG_AbsConst: {
            heff_take_n(v_it2_2457, 0ULL, 1);
            heff_drop(v_ns_242);
            heff_drop(v_params_243);
            heff_drop(v_dom_2445);
            heff_drop(v_cod_2450);
            heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
            heff_drop_cell(v_ru_24body_241_24SLam, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it2_2457);
          }
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_2474 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          V t_0 = v_t_240;
          V t_1 = v_b_2474;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2445);
          heff_drop(v_cod_2450);
          heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Impl: {
        heff_drop(v_dom_2445);
        heff_drop(v_cod_2450);
        heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24109 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24109;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Inst: {
        heff_drop(v_dom_2445);
        heff_drop(v_cod_2450);
        heff_drop_cell(v_ru_24t3_2446_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24144 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24144;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      default: return heff_nomatch(v_t4_2447);
      }
    }
    case TAG_AbsConst: {
      heff_take_n(v_t3_2446, 0ULL, 1);
      heff_drop(v_dom_2445);
      heff_drop(v_t4_2447);
      switch (heff_tag_of(v_body_241)) {
      case TAG_SLocal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        V v_b_24180 = heff_field(v_body_241, 0);
        heff_take_n(v_body_241, 1ULL, 1);
        V t_0 = v_t_240;
        V t_1 = v_b_24180;
        V t_2 = v_ns_242;
        V t_3 = v_params_243;
        v_t_240 = t_0;
        v_body_241 = t_1;
        v_ns_242 = t_2;
        v_params_243 = t_3;
        goto top;
      }
      case TAG_SOpaque: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitRune: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat32: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_body_241);
      }
    }
    default: return heff_nomatch(v_t3_2446);
    }
  }
  case TAG_SRecord: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24218 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24218;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SSum: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24254 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24254;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SIsTy: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24290 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24290;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimInt: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24325 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24325;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimFloat: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24360 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24360;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimString: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24395 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24395;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimRune: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24430 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24430;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimArray: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24466 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24466;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFixed: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24502 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24502;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2esyntax_2epsurface_2etypeFormer_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2etypeFormer(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x5_243, 0);
    V v_dom_247 = heff_field(v_x5_243, 1);
    V v_cod_248 = heff_field(v_x5_243, 2);
    V v_implicit_249 = heff_field(v_x5_243, 3);
    V v_dflt_2410 = heff_field(v_x5_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str3)));
    } else {
      return v_s_2412;
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_x5_243, 1);
    V v_ds_2416 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 2)));
    V v_fs_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_t_2424 = heff_get_n(v_acc_2423, 1, 2);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_t_2424, 0);
      V v_xs_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 2)));
    V v_t_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2431));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str11); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str12), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2444 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_t2_2444);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2445 = heff_field(v_x5_243, 0);
    V v_t_2446 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2445));
    V v_s_2447 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str18), v_t_2446);
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str19), heff_strAppend(v_s_2447, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str20)));
    } else {
      return v_s_2447;
    }
  }
  case TAG_SFixed: {
    V v_w_2449 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2449)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str29);
    }
    default: return heff_nomatch(v_w_2449);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2434)));
    V v_x2_2437 = heff_tag_at_n(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, v_t_2436});
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str8);
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_str9); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}