// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_json_2eplainEnd(V, V);
V g_json_2eplainEnd_entry(V self, V *a);
extern Clo g_json_2eplainEnd_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str0, 2, "\\\"");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str1, 2, "\\\\");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str2, 2, "\\n");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str3, 2, "\\r");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str4, 2, "\\t");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str5, 2, "\\b");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str6, 2, "\\f");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str7, 16, "0123456789abcdef");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str8, 16, "0123456789abcdef");
HEFF_LIT(g_json_2equotedInto_2eescapeInto_241_str9, 4, "\\u00");
Clo g_json_2equotedInto_2eescapeInto_241_clo = {{0x80000000u, K_CLO, 0}, g_json_2equotedInto_2eescapeInto_241_entry, 3, 0};

V g_json_2equotedInto_2eescapeInto_241(V v_s_240, V v_acc_241, V v_i_242) {
top: ;
  V v_j_243 = (g_json_2eplainEnd(v_s_240, heff_dup(v_i_242)));
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_243))) {
    heff_drop(v_j_243);
    if (heff_intEq_c_lent(v_i_242, MK_INT(0LL), 2)) {
      heff_drop(v_i_242);
      return heff_strAppend(v_acc_241, v_s_240);
    } else {
      V v_t_244 = heff_strSlice(heff_dup(v_s_240), v_i_242, heff_strLength(v_s_240));
      return heff_strAppend(v_acc_241, v_t_244);
    }
  } else {
    V v_t_245 = heff_strAppend(v_acc_241, heff_strSlice_lent(v_s_240, v_i_242, v_j_243, 2));
    V v_t_2412;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_243, 0)) < ((int64_t)128ULL))) {
      V v_c_246 = heff_strByteAt_lent(v_s_240, v_j_243, 0);
      if ((heff_peek_word(v_c_246) == ((int64_t)34ULL))) {
        heff_drop(v_c_246);
        v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str0);
      } else {
        if ((heff_peek_word(v_c_246) == ((int64_t)92ULL))) {
          heff_drop(v_c_246);
          v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str1);
        } else {
          if ((heff_peek_word(v_c_246) == ((int64_t)10ULL))) {
            heff_drop(v_c_246);
            v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str2);
          } else {
            if ((heff_peek_word(v_c_246) == ((int64_t)13ULL))) {
              heff_drop(v_c_246);
              v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str3);
            } else {
              if ((heff_peek_word(v_c_246) == ((int64_t)9ULL))) {
                heff_drop(v_c_246);
                v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str4);
              } else {
                if ((heff_peek_word(v_c_246) == ((int64_t)8ULL))) {
                  heff_drop(v_c_246);
                  v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str5);
                } else {
                  if ((heff_peek_word(v_c_246) == ((int64_t)12ULL))) {
                    heff_drop(v_c_246);
                    v_t_2412 = ((V)&g_json_2equotedInto_2eescapeInto_241_str6);
                  } else {
                    int64_t v_d_247 = heff_word_div(heff_peek_word(v_c_246), ((int64_t)16ULL));
                    V v_t_248 = heff_strSlice(((V)&g_json_2equotedInto_2eescapeInto_241_str7), heff_box_word(v_d_247), heff_box_word((v_d_247 + ((int64_t)1ULL))));
                    int64_t v_d_249 = heff_word_mod(heff_unbox_word(v_c_246), ((int64_t)16ULL));
                    V v_t_2410 = heff_strSlice(((V)&g_json_2equotedInto_2eescapeInto_241_str8), heff_box_word(v_d_249), heff_box_word((v_d_249 + ((int64_t)1ULL))));
                    v_t_2412 = heff_strAppend(((V)&g_json_2equotedInto_2eescapeInto_241_str9), heff_strAppend(v_t_248, v_t_2410));
                  }
                }
              }
            }
          }
        }
      }
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(65533LL), NTAG(TAG_Nil)});
      v_t_2412 = heff_strOfRunes(v_t_2411);
    }
    V v_t_2413;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_243, 0)) < ((int64_t)128ULL))) {
      v_t_2413 = MK_INT(1LL);
    } else {
      v_t_2413 = heff_strRuneWidth_lent(v_s_240, v_j_243, 0);
    }
    V t_0 = v_s_240;
    V t_1 = heff_strAppend(v_t_245, v_t_2412);
    V t_2 = heff_intAdd(v_j_243, v_t_2413);
    v_s_240 = t_0;
    v_acc_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
}
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a) {
  (void)self;
  return g_json_2equotedInto_2eescapeInto_241(a[0], a[1], a[2]);
}