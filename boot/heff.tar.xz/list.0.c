// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ISts 38700
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_MkArm 55352
#define TAG_MkSegment 38079
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RepFix 59335
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_defines 1776893014
#define LBL_detail 611917692
#define LBL_doc 309170
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_errors 652506774
#define LBL_from 9647217
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prims 308293287
#define LBL_runs 10007567
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_syntax 1059664654
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_use 325633
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_witness 1587180415
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2enameByteOf(V, V);
V g_heff_2ebuild_2ecommands_2enameByteOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameByteOf_clo;
V g_heff_2ebuild_2edriver_2egoldenOfV(V);
V g_heff_2ebuild_2edriver_2egoldenOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2egoldenOfV_clo;
V g_heff_2ebuild_2edriver_2eintegrationOfV(V);
V g_heff_2ebuild_2edriver_2eintegrationOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eintegrationOfV_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2escalars_2eslotFor(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotFor_clo;
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2eunbox_2eaddGiven(V, V);
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eimport_2eisIdent(V);
V g_heff_2esyntax_2eimport_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eisIdent_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2eall_24s525729714x658270192(V);
V g_list_2eall_24s525729714x658270192_entry(V self, V *a);
extern Clo g_list_2eall_24s525729714x658270192_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
V g_list_2eany_24s359366115x1439523039(V, V);
V g_list_2eany_24s359366115x1439523039_entry(V self, V *a);
extern Clo g_list_2eany_24s359366115x1439523039_clo;
V g_list_2eany_24s430343851x1474283355(V, V);
V g_list_2eany_24s430343851x1474283355_entry(V self, V *a);
extern Clo g_list_2eany_24s430343851x1474283355_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efilter_24f1490579794x1456232270(V, V, V, V, V, V, V);
V g_list_2efilter_24f1490579794x1456232270_entry(V self, V *a);
extern Clo g_list_2efilter_24f1490579794x1456232270_clo;
V g_list_2efilter_24f1490579794x1456232270_24dps(V, V, V, V, V, V, V, V);
V g_list_2efilter_24f1490579794x1456232270_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f1490579794x1456232270_24dps_clo;
V g_list_2efilter_24f1668687542x1574966783_24dps(V, V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_24dps_clo;
V g_list_2efilter_24f75237897x367824150(V, V);
V g_list_2efilter_24f75237897x367824150_entry(V self, V *a);
extern Clo g_list_2efilter_24f75237897x367824150_clo;
V g_list_2efilter_24f75237897x367824150_24dps(V, V, V);
V g_list_2efilter_24f75237897x367824150_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f75237897x367824150_24dps_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
V g_list_2efilter_24s639151216x1214259357_24dps(V, V, V, V);
V g_list_2efilter_24s639151216x1214259357_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_24dps_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_list_2efind_24s1702742059x483228236_24cpr(V, V);
HeffT2 g_list_2efind_24s193168643x1963383024_24cpr(V, V);
HeffT2 g_list_2efind_24s882806058x114262163_24cpr(V, V);
HeffT2 g_list_2efind_24s924148649x7864569_24cpr(V, V);
V g_list_2efoldl_24f1045673032x1961362160(V, V, V, V, V);
V g_list_2efoldl_24f1045673032x1961362160_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1045673032x1961362160_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1144358441x1946627577(V, V);
V g_list_2efoldl_24s1144358441x1946627577_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1144358441x1946627577_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1511444646x1476348587(V, V);
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1511444646x1476348587_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s1632803824x316822742(V, V, V, V);
V g_list_2efoldl_24s1632803824x316822742_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1632803824x316822742_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s354099975x1239835002(V, V);
V g_list_2efoldl_24s354099975x1239835002_entry(V self, V *a);
extern Clo g_list_2efoldl_24s354099975x1239835002_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s571074576x1179600767_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo;
V g_list_2efoldl_24s651278233x871164524(V, V);
V g_list_2efoldl_24s651278233x871164524_entry(V self, V *a);
extern Clo g_list_2efoldl_24s651278233x871164524_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s825077203x853965193(V, V);
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s825077203x853965193_clo;
V g_list_2emap_24f1546297617x1475313215(V, V, V, V, V, V);
V g_list_2emap_24f1546297617x1475313215_entry(V self, V *a);
extern Clo g_list_2emap_24f1546297617x1475313215_clo;
V g_list_2emap_24f1546297617x1475313215_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f1546297617x1475313215_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1546297617x1475313215_24dps_clo;
V g_list_2emap_24f1638246995x433291654_24dps(V, V, V, V);
V g_list_2emap_24f1638246995x433291654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_24dps_clo;
V g_list_2emap_24f2063070488x1806431062(V, V);
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_clo;
V g_list_2emap_24f2063070488x1806431062_24dps(V, V, V);
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_24dps_clo;
V g_list_2emap_24f2126005327x1567543363_24dps(V, V);
V g_list_2emap_24f2126005327x1567543363_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2126005327x1567543363_24dps_clo;
V g_list_2emap_24f342794667x1308411312(V, V);
V g_list_2emap_24f342794667x1308411312_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_clo;
V g_list_2emap_24f342794667x1308411312_24dps(V, V, V);
V g_list_2emap_24f342794667x1308411312_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_24dps_clo;
V g_list_2emap_24f74587876x194913022_24dps(V, V, V, V);
V g_list_2emap_24f74587876x194913022_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f74587876x194913022_24dps_clo;
V g_list_2emap_24f881582358x206177481(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f881582358x206177481_entry(V self, V *a);
extern Clo g_list_2emap_24f881582358x206177481_clo;
V g_list_2emap_24f881582358x206177481_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f881582358x206177481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f881582358x206177481_24dps_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1068592055x839006909(V, V, V, V);
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_clo;
V g_list_2emap_24s1068592055x839006909_24dps(V, V, V, V, V);
V g_list_2emap_24s1068592055x839006909_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_24dps_clo;
V g_list_2emap_24s1099021180x1702355548_24dps(V, V, V);
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_24dps_clo;
V g_list_2emap_24s1215346472x331828322_24dps(V, V);
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_24dps_clo;
V g_list_2emap_24s1292210741x1158835606_24dps(V, V, V, V);
V g_list_2emap_24s1292210741x1158835606_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1292210741x1158835606_24dps_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s149108714x637478466_24dps(V, V, V, V);
V g_list_2emap_24s149108714x637478466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s149108714x637478466_24dps_clo;
V g_list_2emap_24s1512999845x472671375(V, V, V, V, V);
V g_list_2emap_24s1512999845x472671375_entry(V self, V *a);
extern Clo g_list_2emap_24s1512999845x472671375_clo;
V g_list_2emap_24s1512999845x472671375_24dps(V, V, V, V, V, V);
V g_list_2emap_24s1512999845x472671375_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512999845x472671375_24dps_clo;
V g_list_2emap_24s1517387949x485543551(V);
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_clo;
V g_list_2emap_24s1517387949x485543551_24dps(V, V);
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s1618539892x552009225_24dps(V, V);
V g_list_2emap_24s1618539892x552009225_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_24dps_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s1721231741x1085491812_24dps(V, V);
V g_list_2emap_24s1721231741x1085491812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_24dps_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1792553290x233563724_24dps(V, V);
V g_list_2emap_24s1792553290x233563724_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_24dps_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_list_2emap_24s1975257801x764827799_24dps(V, V);
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_24dps_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s228910449x1110031924_24dps(V, V, V);
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_24dps_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2emap_24s258116700x992061112_24dps(V, V, V);
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_24dps_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s273193875x235978955_24dps(V, V, V, V, V);
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_24dps_clo;
V g_list_2emap_24s313852718x340738167_24dps(V, V, V);
V g_list_2emap_24s313852718x340738167_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s313852718x340738167_24dps_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s34825065x1144190520_24dps(V, V);
V g_list_2emap_24s34825065x1144190520_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_24dps_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s370939663x1496042695_24dps(V, V, V);
V g_list_2emap_24s370939663x1496042695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_24dps_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s430074199x1834682414(V, V, V, V);
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_clo;
V g_list_2emap_24s430074199x1834682414_24dps(V, V, V, V, V);
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_24dps_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24s473401207x1960255357_24dps(V, V);
V g_list_2emap_24s473401207x1960255357_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_24dps_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s531657185x2070920831(V, V);
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s588468714x1874323009(V);
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_clo;
V g_list_2emap_24s588468714x1874323009_24dps(V, V);
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_24dps_clo;
V g_list_2emap_24s708435384x833942752_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s708435384x833942752_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s708435384x833942752_24dps_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24s723912745x1713553694_24dps(V, V);
V g_list_2emap_24s723912745x1713553694_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_24dps_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s88069640x1067514236(V);
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_clo;
V g_list_2emap_24s88069640x1067514236_24dps(V, V);
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_24dps_clo;
V g_list_2emerge_24s1037857700x2096250953(V, V);
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_clo;
V g_list_2emerge_24s1037857700x2096250953_24dps(V, V, V);
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2ezipWith_24s1259666496x1713656817(V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_clo;
V g_list_2ezipWith_24s1259666496x1713656817_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_24dps_clo;
V g_list_2ezipWith_24s1877091673x1588480570(V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_clo;
V g_list_2ezipWith_24s1877091673x1588480570_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo;
V g_list_2ezipWith_24s457513469x1891643252_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2emap_2einsert_24s389317661x481376749(V, V, V);
V g_std_2emap_2einsert_24s389317661x481376749_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s389317661x481376749_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);

HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_I8: {
      v_t_2413 = heff_dup(v_lit_240);
      break;
    }
    case TAG_I16: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I32: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I64: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    case TAG_U8: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U16: {
      v_t_2413 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U32: {
      v_t_2413 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U64: {
      v_t_2413 = heff_dup(v_lit_247);
      break;
    }
    case TAG_F32: {
      v_t_2413 = heff_dup(v_lit_248);
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_249, 1)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_xs_2412);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2411}});
    } else {
      heff_drop(v_x_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2410)}});
  }
}
Clo g_list_2emap_24s1044393341x1523302351_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_entry, 1, 0};

V g_list_2emap_24s1044393341x1523302351(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1044393341x1523302351_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351(a[0]);
}
Clo g_list_2emap_24s584454411x1006678865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_24dps_entry, 2, 0};

V g_list_2emap_24s584454411x1006678865_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s525729714x658270192_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s525729714x658270192_entry, 1, 0};

V g_list_2eall_24s525729714x658270192(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_r1_243 = heff_field(v_x_241, 0);
      V v_r2_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_r1_243)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_lo_245 = heff_field(v_r1_243, 0);
        switch (heff_tag_of(v_r2_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_hi_246 = heff_field(v_r2_244, 0);
          if (heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_245, 1)) {
            if (heff_intLe_c_lent(v_hi_246, MK_INT(4611686018427387903LL), 2)) {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            } else {
              return NTAG(TAG_False);
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_r2_244);
        }
      }
      default: return heff_nomatch(v_r1_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s525729714x658270192_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s525729714x658270192(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s258116700x992061112_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_entry, 2, 0};

V g_list_2emap_24s258116700x992061112(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_245 = (g_list_2emap_24s258116700x992061112_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s258116700x992061112(a[0], a[1]);
}
Clo g_list_2emap_24s258116700x992061112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_24dps_entry, 3, 0};

V g_list_2emap_24s258116700x992061112_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s258116700x992061112_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1792553290x233563724_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1792553290x233563724_entry, 1, 0};

V g_list_2emap_24s1792553290x233563724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Unreached), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1792553290x233563724_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1792553290x233563724(a[0]);
}
Clo g_list_2efoldl_24s651278233x871164524_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s651278233x871164524_entry, 2, 0};

V g_list_2efoldl_24s651278233x871164524(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s389317661x481376749(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s651278233x871164524_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s651278233x871164524(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str0, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str1, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str2, 4, "(..)");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str3, 0, "");
Clo g_list_2emap_24s1975257801x764827799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1975257801x764827799_entry, 1, 0};

V g_list_2emap_24s1975257801x764827799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eimport_2eisIdent(heff_rfield(v_x_241, 0)));
    V v_t_245;
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      v_t_245 = heff_dup(heff_rfield(v_x_241, 0));
    } else {
      heff_drop(v_t_243);
      V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_x_241, 0)), ((V)&g_list_2emap_24s1975257801x764827799_str0));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_str1), v_t_244);
    }
    V v_t_246 = heff_get_n(v_x_241, 1, 3);
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = ((V)&g_list_2emap_24s1975257801x764827799_str2);
    } else {
      heff_drop(v_t_246);
      v_t_247 = ((V)&g_list_2emap_24s1975257801x764827799_str3);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s1975257801x764827799_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1975257801x764827799(a[0]);
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_entry, 1, 0};

V g_list_2emap_24s1409451498x400757684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_241, 2)), heff_dup(heff_rfield(v_x_241, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_list_2emap_24s1409451498x400757684_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1409451498x400757684_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684(a[0]);
}
Clo g_list_2emap_24s34825065x1144190520_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s34825065x1144190520_entry, 1, 0};

V g_list_2emap_24s34825065x1144190520(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        V v_size_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 6ULL, 5);
        v_t_2410 = ({ V a_0 = v_ty_246; V a_1 = v_size_247; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_246); heff_drop(v_size_247); r_; });
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s34825065x1144190520_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s34825065x1144190520(a[0]);
}
Clo g_list_2emap_24s1036840854x702708481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_entry, 2, 0};

V g_list_2emap_24s1036840854x702708481(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1036840854x702708481_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1036840854x702708481(a[0], a[1]);
}
Clo g_list_2emap_24s158244903x55062455_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_entry, 1, 0};

V g_list_2emap_24s158244903x55062455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s158244903x55062455_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455(a[0]);
}
Clo g_list_2emap_24s1729787689x465380098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_24dps_entry, 2, 0};

V g_list_2emap_24s1729787689x465380098_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2412});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2413 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s604143829x1495140576_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s604143829x1495140576_entry, 2, 0};

V g_list_2eany_24s604143829x1495140576(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ehandlerArg(v_lit_240, heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s604143829x1495140576(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s473401207x1960255357_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s473401207x1960255357_entry, 1, 0};

V g_list_2emap_24s473401207x1960255357(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s473401207x1960255357_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s473401207x1960255357(a[0]);
}
Clo g_list_2emap_24s2067043448x720245267_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_24dps_entry, 2, 0};

V g_list_2emap_24s2067043448x720245267_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1144358441x1946627577_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1144358441x1946627577_entry, 2, 0};

V g_list_2efoldl_24s1144358441x1946627577(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 2))));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1144358441x1946627577_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1144358441x1946627577(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2070597502x591087275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2070597502x591087275_entry, 2, 0};

V g_list_2efoldl_24s2070597502x591087275(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2esgItem(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2070597502x591087275(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1632803824x316822742_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1632803824x316822742_entry, 4, 0};

V g_list_2efoldl_24s1632803824x316822742(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_248;
    if (heff_intLt_c_lent(v_x_244, v_lit_240, 0)) {
      V v_t_247 = (g_heff_2ecompile_2erepr_2efourTo(heff_dup(v_x_244)));
      v_t_248 = heff_intAdd(v_z_242, heff_intMul(heff_dup(v_lit_241), v_t_247));
    } else {
      v_t_248 = v_z_242;
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_248;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1632803824x316822742_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s1632803824x316822742(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s1104809983x118204267_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1104809983x118204267_entry, 2, 0};

V g_list_2efoldl_24s1104809983x118204267(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1104809983x118204267(a[0], a[1]);
}
Clo g_list_2eany_24s1630057461x1822494873_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1630057461x1822494873_entry, 1, 0};

V g_list_2eany_24s1630057461x1822494873(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_OutTag: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutRecord: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutCall: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutOther: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1630057461x1822494873(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s273193875x235978955_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s273193875x235978955_entry, 4, 0};

V g_list_2emap_24s273193875x235978955(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_take_field(v_a_2411, 1);
    V v_t_2414;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_get_n(v_a_2411, 2, 7)});
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2412);
      v_t_2414 = heff_get_n(v_a_2411, 2, 7);
    }
    V v_t_2415 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_248, heff_dup(v_lit_240)), v_t_2415});
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s273193875x235978955_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s273193875x235978955_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s273193875x235978955(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s410120642x105714730_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s410120642x105714730_entry, 2, 0};

V g_list_2efoldl_24s410120642x105714730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_take_field(v_x_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec_n(2, shape_name__span, (V[]){heff_take_field(v_x_242, 4), heff_get_n(v_x_242, 5, 6)});
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 6);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s410120642x105714730(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_24dps_entry, 2, 0};

V g_list_2emap_24s1397747289x2145601499_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_24dps_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1397747289x2145601499_24dps_str1)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1292210741x1158835606_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1292210741x1158835606_24dps_entry, 4, 0};

V g_list_2emap_24s1292210741x1158835606_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 6);
    V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_248 = heff_get_n(heff_get_n(v_x_244, 0, 3), 1, 6);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_248, heff_dup(v_lit_241)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_249), heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1292210741x1158835606_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1292210741x1158835606_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1690674600x556093466_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_24dps_entry, 2, 0};

V g_list_2emap_24s1690674600x556093466_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1690674600x556093466_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s531657185x2070920831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_entry, 2, 0};

V g_list_2emap_24s531657185x2070920831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2ekeptFrom(v_lit_240, v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s531657185x2070920831_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s88069640x1067514236_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s88069640x1067514236_entry, 1, 0};

V g_list_2emap_24s88069640x1067514236(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s88069640x1067514236_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s88069640x1067514236(a[0]);
}
Clo g_list_2ezipWith_24s1259666496x1713656817_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1259666496x1713656817_entry, 5, 0};

V g_list_2ezipWith_24s1259666496x1713656817(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_249 = (g_heff_2ecompile_2escalars_2eslotFor(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_245, v_y_247));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2ezipWith_24s1259666496x1713656817_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1259666496x1713656817_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s1259666496x1713656817(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s882806058x114262163_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s825077203x853965193_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s825077203x853965193_entry, 2, 0};

V g_list_2efoldl_24s825077203x853965193(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eunbox_2eaddGiven(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s825077203x853965193(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s357242026x384251201_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_entry, 1, 0};

V g_list_2emap_24s357242026x384251201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s357242026x384251201_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201(a[0]);
}
Clo g_list_2efoldl_24s25420611x1990549631_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s25420611x1990549631_entry, 2, 0};

V g_list_2efoldl_24s25420611x1990549631(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 4, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s25420611x1990549631(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_entry, 1, 0};

V g_list_2emap_24s391931963x434308123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s391931963x434308123_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123(a[0]);
}
Clo g_list_2emap_24s1009200955x251267316_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_24dps_entry, 2, 0};

V g_list_2emap_24s1009200955x251267316_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_247 = v_t_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s457513469x1891643252_24dps_entry, 10, 0};

V g_list_2ezipWith_24s457513469x1891643252_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_intShow(v_y_2412), heff_dup(v_lit_246));
      V v_t_2416 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_strAppend(heff_dup(v_lit_245), v_t_2415));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2416), heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_cell_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s457513469x1891643252_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2ezipWith_24s1877091673x1588480570_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1877091673x1588480570_entry, 5, 0};

V g_list_2ezipWith_24s1877091673x1588480570(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_249 = heff_dup(heff_field(v_x_245, 0));
        v_t_2411 = v_a_249;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_x_245, 1);
        heff_take_n(v_x_245, 2ULL, 2);
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2414, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_intShow(v_y_247), v_t_2415);
      V v_t_2417 = heff_strAppend(v_t_2411, heff_strAppend(heff_dup(v_lit_240), v_t_2416));
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = (g_list_2ezipWith_24s1877091673x1588480570_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2418)));
      heff_drop(v_u_2419);
      return v_cell_2418;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1877091673x1588480570_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1877091673x1588480570(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s430074199x1834682414_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s430074199x1834682414_entry, 4, 0};

V g_list_2emap_24s430074199x1834682414(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2etupleRead(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s430074199x1834682414_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s430074199x1834682414(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str0, 6, "double");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str1, 4, "bool");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str2, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str3, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str4, 6, "char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str5, 2, " *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str6, 4, "void");
Clo g_list_2emap_24s1215346472x331828322_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1215346472x331828322_24dps_entry, 2, 0};

V g_list_2emap_24s1215346472x331828322_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_CInteger: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_247 = v_t_244;
      break;
    }
    case TAG_CDouble: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str0);
      break;
    }
    case TAG_CBool: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str1);
      break;
    }
    case TAG_CString: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str2);
      break;
    }
    case TAG_CText: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_245 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_247 = heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1215346472x331828322_24dps_str5));
      break;
    }
    case TAG_CVoid: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str6);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1215346472x331828322_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2073083146x1445066245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_entry, 1, 0};

V g_list_2emap_24s2073083146x1445066245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2073083146x1445066245_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245(a[0]);
}
Clo g_list_2emap_24s380834591x871125279_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_entry, 1, 0};

V g_list_2emap_24s380834591x871125279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s380834591x871125279_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279(a[0]);
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_entry, 1, 0};

V g_list_2emap_24s502656580x1955732096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 5);
    V v_t_2424;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_list_2emap_24s502656580x1955732096_str0), 2)) {
          heff_drop(v_x_246);
          heff_drop_cell(v_ru_24x11_244_24PatVar, 1);
          v_t_2424 = NTAG(TAG_Nothing);
        } else {
          v_t_2424 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = (g_list_2emap_24s502656580x1955732096_24dps(v_xs_242, heff_dup(v_cell_2425)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096(a[0]);
}
Clo g_list_2emap_24s1512999845x472671375_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512999845x472671375_entry, 5, 0};

V g_list_2emap_24s1512999845x472671375(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_247 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_248 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_242), heff_strLength_lent(v_a_247, 0));
    V v_t_2412;
    if (heff_strEq_c(v_t_248, v_a_247)) {
      V v_t_2410 = heff_intAdd(heff_strLength_lent(v_lit_240, 0), heff_dup(v_lit_243));
      V v_t_2411 = heff_strSlice(heff_dup(v_x_245), v_t_2410, heff_strLength_lent(v_x_245, 0));
      v_t_2412 = heff_rec_n(2, shape_name__key, (V[]){v_t_2411, v_x_245});
    } else {
      v_t_2412 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_245), v_x_245});
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s1512999845x472671375_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1512999845x472671375_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1512999845x472671375(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1608132097x1207501887_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1608132097x1207501887_entry, 2, 0};

V g_list_2efoldl_24s1608132097x1207501887(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 3));
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1608132097x1207501887(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s370939663x1496042695_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s370939663x1496042695_24dps_entry, 3, 0};

V g_list_2emap_24s370939663x1496042695_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 2, 5));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s370939663x1496042695_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s370939663x1496042695_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1068592055x839006909_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1068592055x839006909_entry, 4, 0};

V g_list_2emap_24s1068592055x839006909(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 10);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_lit_240, 9));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(v_lit_241);
    } else {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(v_lit_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_x_244), heff_hole()});
    V v_u_249 = (g_list_2emap_24s1068592055x839006909_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1068592055x839006909(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s359366115x1439523039_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s359366115x1439523039_entry, 2, 0};

V g_list_2eany_24s359366115x1439523039(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s359366115x1439523039_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s359366115x1439523039(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1517387949x485543551_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1517387949x485543551_entry, 1, 0};

V g_list_2emap_24s1517387949x485543551(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2egoldenOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1517387949x485543551_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1517387949x485543551(a[0]);
}
Clo g_list_2emap_24s588468714x1874323009_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588468714x1874323009_entry, 1, 0};

V g_list_2emap_24s588468714x1874323009(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eintegrationOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s588468714x1874323009_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588468714x1874323009(a[0]);
}

HeffT2 g_list_2efind_24s1702742059x483228236_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 4);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s354099975x1239835002_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s354099975x1239835002_entry, 2, 0};

V g_list_2efoldl_24s354099975x1239835002(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_z_240, v_a_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_a_2410 = v_field_248;
          heff_drop(v_a_2410);
          v_t_2411 = v_z_240;
        } else {
          heff_drop(v_field_248);
          v_t_2411 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(v_a_244), heff_dup(v_a_245)));
        }
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s354099975x1239835002_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s354099975x1239835002(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s193168643x1963383024_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 14);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s313852718x340738167_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s313852718x340738167_24dps_entry, 3, 0};

V g_list_2emap_24s313852718x340738167_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2estmtKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s313852718x340738167_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s313852718x340738167_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1099021180x1702355548_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1099021180x1702355548_24dps_entry, 3, 0};

V g_list_2emap_24s1099021180x1702355548_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2efieldSetKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1099021180x1702355548_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s228910449x1110031924_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s228910449x1110031924_24dps_entry, 3, 0};

V g_list_2emap_24s228910449x1110031924_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eparamKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s228910449x1110031924_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634456687x1151454243_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s639151216x1214259357_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s639151216x1214259357_entry, 3, 0};

V g_list_2efilter_24s639151216x1214259357(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2efilter_24s639151216x1214259357_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop_rec(v_x_243, 3);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efilter_24s639151216x1214259357(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s132798885x1165759438_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_24dps_entry, 3, 0};

V g_list_2emerge_24s132798885x1165759438_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_247 = (g_heff_2ebuild_2eproject_2esumBefore(heff_dup(v_x_243), heff_dup(v_y_245)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_248;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2410;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str0, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str2, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str3, 9, "{ name = ");
Clo g_list_2emap_24s1381986540x1952410492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_24dps_entry, 2, 0};

V g_list_2emap_24s1381986540x1952410492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_rfield(v_x_242, 0)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_rfield(v_x_242, 1)));
    V v_t_246 = ({ V b_0 = heff_get_n(v_x_242, 2, 3); V r_ = (g_heff_2ebuild_2eproject_2equoted(b_0)); heff_drop(b_0); r_; });
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str0), heff_strAppend(v_t_246, ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str1)));
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str2), heff_strAppend(v_t_245, v_t_247));
    V v_t_249 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str3), heff_strAppend(v_t_244, v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_24dps_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_24dps_entry, 2, 0};

V g_list_2emap_24s1462590149x1582455373_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_x_242), heff_box_word(v_t_244), heff_strLength_lent(v_x_242, 0));
    V v_t_248;
    if (heff_strEq_c(v_t_245, ((V)&g_list_2emap_24s1462590149x1582455373_24dps_str0))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
      v_t_248 = heff_strSlice(v_x_242, MK_INT(0LL), heff_box_word(v_t_247));
    } else {
      v_t_248 = v_x_242;
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s1037857700x2096250953_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1037857700x2096250953_entry, 2, 0};

V g_list_2emerge_24s1037857700x2096250953(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 1, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2412 = (g_list_2emerge_24s1037857700x2096250953_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      } else {
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2414 = (g_list_2emerge_24s1037857700x2096250953_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_2413)));
        heff_drop(v_u_2414);
        return v_cell_2413;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1037857700x2096250953(a[0], a[1]);
}
Clo g_list_2emap_24s1721231741x1085491812_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1721231741x1085491812_24dps_entry, 2, 0};

V g_list_2emap_24s1721231741x1085491812_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(v_t_246, 0, 4);
    V v_t_2446;
    switch (heff_tag_of(v_t_247)) {
    case TAG_SLocal: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      V v_ru_24t_247_24SPrim = heff_take_reuse_n(v_t_247, 0ULL, 1);
      V v_t_2434;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_2432 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_2434 = v_a_2432;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2446 = heff_tag_at_n(v_ru_24t_247_24SPrim, TAG_Just, 1, (V[]){v_t_2434});
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_cell_2447 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2446, heff_hole()});
    V v_u_2448 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2447));
    heff_drop(v_u_2448);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2447;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1721231741x1085491812_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1721231741x1085491812_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s430343851x1474283355_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s430343851x1474283355_entry, 2, 0};

V g_list_2eany_24s430343851x1474283355(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(heff_rfield(v_x_242, 1)))) {
        heff_drop(v_lit_240);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s430343851x1474283355_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s430343851x1474283355(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s924148649x7864569_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_dup(heff_rfield(v_lit_240, 1)))) {
        heff_drop_rec(v_lit_240, 2);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
      } else {
        heff_drop_rec(v_x_242, 3);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s149108714x637478466_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s149108714x637478466_24dps_entry, 4, 0};

V g_list_2emap_24s149108714x637478466_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_lit_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(heff_rfield(v_lit_241, 1)))));
    V v_t_248 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_lit_240, 3)), v_x_244, v_t_247});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s149108714x637478466_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s149108714x637478466_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s54159557x1528472185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s54159557x1528472185_entry, 2, 0};

V g_list_2efoldl_24s54159557x1528472185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s54159557x1528472185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s571074576x1179600767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_entry, 2, 0};

V g_list_2efoldl_24s571074576x1179600767(V v_z_240, V v_x3_241) {
top: ;
  return (g_list_2efoldl_24s571074576x1179600767_24scalars(heff_dup(heff_rfield(v_z_240, 0)), heff_dup(heff_rfield(v_z_240, 1)), heff_dup(heff_rfield(v_z_240, 2)), heff_dup(heff_rfield(v_z_240, 3)), heff_get_n(v_z_240, 4, 5), v_x3_241));
}
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767(a[0], a[1]);
}
Clo g_list_2emap_24s708435384x833942752_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s708435384x833942752_24dps_entry, 9, 0};

V g_list_2emap_24s708435384x833942752_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 12);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2411 = heff_dup(heff_rfield(v_lit_241, 4));
    V v_t_2416;
    if (heff_intEq_c_lent(v_a_2411, v_lit_242, 0)) {
      heff_drop(v_a_2411);
      v_t_2416 = heff_dup(v_lit_243);
    } else {
      V v_t_2415;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_dup(heff_field(v_x_249, 1));
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      v_t_2416 = heff_intDiv(heff_intMul(v_t_2415, heff_dup(v_lit_244)), v_a_2411);
    }
    V v_t_2417 = heff_strAppend(heff_intShow(v_t_2416), heff_dup(v_lit_245));
    V v_t_2420;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 2);
      v_t_2420 = v_a_2418;
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2421 = heff_strAppend(v_t_2417, heff_strAppend(heff_dup(v_lit_246), v_t_2420));
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2421), heff_hole()});
    V v_u_2423 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2422));
    heff_drop(v_u_2423);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2422;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s708435384x833942752_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s708435384x833942752_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str5, 0, "");
Clo g_list_2emap_24s1618539892x552009225_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1618539892x552009225_entry, 1, 0};

V g_list_2emap_24s1618539892x552009225(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str0);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str1);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str2);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str3);
      break;
    }
    case TAG_JString: {
      V v_t_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_t_246;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str4);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str5);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1618539892x552009225_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1618539892x552009225(a[0]);
}
Clo g_list_2emap_24s723912745x1713553694_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s723912745x1713553694_entry, 1, 0};

V g_list_2emap_24s723912745x1713553694(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s723912745x1713553694_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s723912745x1713553694(a[0]);
}
HEFF_LIT(g_list_2efoldl_24s1511444646x1476348587_str0, 2, ": ");
HEFF_LIT(g_list_2efoldl_24s1511444646x1476348587_str1, 2, "\015\012");
Clo g_list_2efoldl_24s1511444646x1476348587_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1511444646x1476348587_entry, 2, 0};

V g_list_2efoldl_24s1511444646x1476348587(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x_242, 0);
      V v_v_245 = heff_field(v_x_242, 1);
      V v_t_246 = heff_strAppend(((V)&g_list_2efoldl_24s1511444646x1476348587_str0), heff_strAppend(heff_dup(v_v_245), ((V)&g_list_2efoldl_24s1511444646x1476348587_str1)));
      v_t_247 = heff_strAppend(v_z_240, heff_strAppend(heff_dup(v_n_244), v_t_246));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1511444646x1476348587(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s831190316x576961335_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_24dps_entry, 2, 0};

V g_list_2emap_24s831190316x576961335_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str0, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str1, 6, "detail");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str2, 5, "label");
Clo g_list_2emap_24s4199228x1154005405_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_24dps_entry, 2, 0};

V g_list_2emap_24s4199228x1154005405_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_246 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 1, 2)});
    V v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str1), v_t_246}), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str2), v_t_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_248}), heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f2092936166x2062766724_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2092936166x2062766724_entry, 3, 0};

V g_list_2efoldl_24f2092936166x2062766724(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      v_x_247 = heff_dup(v_y_246);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    heff_drop(v_x_247);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2092936166x2062766724(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1625738412x188935108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1625738412x188935108_entry, 3, 0};

V g_list_2efoldl_24f1625738412x188935108(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x1_241, 0);
    V v_ks_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x2_242, 0);
      V v_vs_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_k_243, v_v_245});
      V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ks_244;
      V t_2 = v_vs_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1625738412x188935108(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1686830387x1555365313_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1686830387x1555365313_entry, 4, 0};

V g_list_2efoldl_24f1686830387x1555365313(V v_z_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_x3_243);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_244, v_y_246}));
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_z_240});
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_ys_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1686830387x1555365313(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1419248316x13095286_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1419248316x13095286_entry, 3, 0};

V g_list_2efoldl_24f1419248316x13095286(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1419248316x13095286(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f2126005327x1567543363_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2126005327x1567543363_24dps_entry, 2, 0};

V g_list_2emap_24f2126005327x1567543363_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_2440;
    switch (heff_tag_of(v_t_244)) {
    case TAG_EVar: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_244, 0ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_242, 2)), NTAG(TAG_Nil)});
      v_t_2440 = (g_heff_2ecompile_2eworker_2enumericW(v_t_249));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_244, 0ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
      V v_u_2442 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2441));
      heff_drop(v_u_2442);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2441;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_t_2440);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f2126005327x1567543363_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2126005327x1567543363_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f881582358x206177481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f881582358x206177481_entry, 9, 0};

V g_list_2emap_24f881582358x206177481(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_249, v_lit_245, v_lit_246, 0), heff_dup(v_lit_247))) {
      heff_drop(v_x_249);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      goto top;
    } else {
      V v_t_2414;
      if (heff_strEq_c(heff_strSlice_lent(v_x_249, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2413 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_244), heff_strLength(v_x_249));
        v_t_2414 = heff_strAppend(heff_dup(v_lit_243), v_t_2413);
      } else {
        v_t_2414 = v_x_249;
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = (g_list_2emap_24f881582358x206177481_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f881582358x206177481_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f881582358x206177481(a0, a1, a2, a[3], a4, a5, a6, a7, a[8]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efilter_24f1668687542x1574966783_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f1668687542x1574966783_24dps_entry, 5, 0};

V g_list_2efilter_24f1668687542x1574966783_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_243, 0);
    V v_xs_246 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      if (heff_strEq_c(heff_strSlice_lent(v_x_247, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_247);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_249;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2efilter_24f1668687542x1574966783_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2efilter_24f1668687542x1574966783_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1546297617x1475313215_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1546297617x1475313215_entry, 6, 0};

V g_list_2emap_24f1546297617x1475313215(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_p_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_244), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_intShow(v_x_246), heff_dup(v_lit_243));
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_lit_242), v_t_249));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2410), heff_hole()});
      V v_u_2412 = (g_list_2emap_24f1546297617x1475313215_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_p_244, v_xs_247, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_p_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_p_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f1546297617x1475313215_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1546297617x1475313215(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1638246995x433291654_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1638246995x433291654_24dps_entry, 4, 0};

V g_list_2emap_24f1638246995x433291654_24dps(V v_lit_240, V v_box_24lit_241, V v_x2_242, V v_d_243) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_244, 0)))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_244), heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1638246995x433291654_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1638246995x433291654_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f342794667x1308411312_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f342794667x1308411312_entry, 2, 0};

V g_list_2emap_24f342794667x1308411312(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 3);
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_a_245, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_get_n(v_a_245, 1, 2))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
        V v_u_249 = (g_list_2emap_24f342794667x1308411312_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_rec(v_x_242, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop_rec(v_a_244, 2);
      heff_drop_rec(v_a_245, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f342794667x1308411312_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f342794667x1308411312(a[0], a[1]);
}
Clo g_list_2emap_24f2063070488x1806431062_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2063070488x1806431062_entry, 2, 0};

V g_list_2emap_24f2063070488x1806431062(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
      V v_u_246 = (g_list_2emap_24f2063070488x1806431062_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2063070488x1806431062(a[0], a[1]);
}
Clo g_list_2emap_24f74587876x194913022_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f74587876x194913022_24dps_entry, 4, 0};

V g_list_2emap_24f74587876x194913022_24dps(V v_lit_240, V v_box_24i_241, V v_box_24n_242, V v_d_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= v_i_241)) {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = (g_heff_2ebuild_2ecommands_2enameByteOf(v_lit_240, heff_box_word(v_i_241)));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_n_242;
    V t_3 = v_cell_246;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f74587876x194913022_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f74587876x194913022_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f1045673032x1961362160_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1045673032x1961362160_entry, 5, 0};

V g_list_2efoldl_24f1045673032x1961362160(V v_lit_240, V v_z_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_242, 4);
    heff_drop_rec(v_lit_243, 2);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_lit_242, 0)))) {
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_245, 2)), 0, 2);
      if (heff_intLt_c(v_t_248, heff_dup(heff_rfield(v_lit_243, 0)))) {
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1045673032x1961362160_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24f1045673032x1961362160(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2efilter_24f1490579794x1456232270_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f1490579794x1456232270_entry, 7, 0};

V g_list_2efilter_24f1490579794x1456232270(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_intAdd(heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_x_2410 = heff_strAppend(v_t_249, v_x_247);
    V v_t_2411 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_2411, v_lit_241, 1)) {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2414 = (g_list_2efilter_24f1490579794x1456232270_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2efilter_24f1490579794x1456232270_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2efilter_24f1490579794x1456232270(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1425140065x1254143828_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1425140065x1254143828_entry, 4, 0};

V g_list_2efoldl_24f1425140065x1254143828(V v_lit_240, V v_z_241, V v_seen_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_seen_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_rest_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_244, v_seen_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_seen_242});
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1425140065x1254143828(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24f75237897x367824150_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f75237897x367824150_entry, 2, 0};

V g_list_2efilter_24f75237897x367824150(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2efilter_24s1623010005x1805617852(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24f75237897x367824150_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_ys_241;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2efilter_24f75237897x367824150_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f75237897x367824150(a[0], a[1]);
}