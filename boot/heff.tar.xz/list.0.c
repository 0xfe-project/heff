// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CDrop 58400
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ISts 38700
#define TAG_IVal 40987
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RLocal 34280
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_code 9554612
#define LBL_detail 611917692
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_long 9823043
#define LBL_member 869372357
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_post 9942375
#define LBL_prims 308293287
#define LBL_severity 75955546
#define LBL_ships 310766033
#define LBL_sol 323594
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_version 583465758
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_clo;
V g_heff_2ecompile_2eimp_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimp_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2evalNamesTop_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2eworker_2etailCalls(V);
V g_heff_2ecompile_2eworker_2etailCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2etailCalls_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2efilter_24f1461841536x2133820294_24dps(V, V, V, V);
V g_list_2efilter_24f1461841536x2133820294_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f1461841536x2133820294_24dps_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efilter_24s1967523567x64647275_24dps(V, V);
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_24dps_clo;
V g_list_2efilter_24s413688307x112671032(V, V, V, V);
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_clo;
V g_list_2efilter_24s413688307x112671032_24dps(V, V, V, V, V);
V g_list_2efilter_24s413688307x112671032_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_24dps_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1040186323x1541137667(V, V);
V g_list_2efoldl_24s1040186323x1541137667_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1040186323x1541137667_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1418838819x1907320638(V, V);
V g_list_2efoldl_24s1418838819x1907320638_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1418838819x1907320638_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s1880194630x798487332(V, V);
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1880194630x798487332_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s2126981320x1580482478(V, V);
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2126981320x1580482478_clo;
V g_list_2efoldl_24s2137706589x1353696470(V, V);
V g_list_2efoldl_24s2137706589x1353696470_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2137706589x1353696470_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s71083851x23251329(V, V);
V g_list_2efoldl_24s71083851x23251329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s71083851x23251329_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2emap_24f131620269x1652606631(V, V, V);
V g_list_2emap_24f131620269x1652606631_entry(V self, V *a);
extern Clo g_list_2emap_24f131620269x1652606631_clo;
V g_list_2emap_24f131620269x1652606631_24dps(V, V, V, V);
V g_list_2emap_24f131620269x1652606631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f131620269x1652606631_24dps_clo;
V g_list_2emap_24f2000583729x2114721175_24dps(V, V, V, V);
V g_list_2emap_24f2000583729x2114721175_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2000583729x2114721175_24dps_clo;
V g_list_2emap_24f2063070488x1806431062(V, V);
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_clo;
V g_list_2emap_24f2063070488x1806431062_24dps(V, V, V);
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_24dps_clo;
V g_list_2emap_24f359508862x1661952287(V, V, V, V);
V g_list_2emap_24f359508862x1661952287_entry(V self, V *a);
extern Clo g_list_2emap_24f359508862x1661952287_clo;
V g_list_2emap_24f359508862x1661952287_24dps(V, V, V, V, V);
V g_list_2emap_24f359508862x1661952287_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f359508862x1661952287_24dps_clo;
V g_list_2emap_24f514979201x2029883448_24dps(V, V, V);
V g_list_2emap_24f514979201x2029883448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f514979201x2029883448_24dps_clo;
V g_list_2emap_24f599584836x1400862534(V, V);
V g_list_2emap_24f599584836x1400862534_entry(V self, V *a);
extern Clo g_list_2emap_24f599584836x1400862534_clo;
V g_list_2emap_24f599584836x1400862534_24dps(V, V, V);
V g_list_2emap_24f599584836x1400862534_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f599584836x1400862534_24dps_clo;
V g_list_2emap_24f998257836x1791893456_24dps(V, V, V, V);
V g_list_2emap_24f998257836x1791893456_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f998257836x1791893456_24dps_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1092537139x232684611(V, V);
V g_list_2emap_24s1092537139x232684611_entry(V self, V *a);
extern Clo g_list_2emap_24s1092537139x232684611_clo;
V g_list_2emap_24s1092537139x232684611_24dps(V, V, V);
V g_list_2emap_24s1092537139x232684611_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1092537139x232684611_24dps_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1374235278x875430684(V);
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a);
extern Clo g_list_2emap_24s1374235278x875430684_clo;
V g_list_2emap_24s1374235278x875430684_24dps(V, V);
V g_list_2emap_24s1374235278x875430684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1374235278x875430684_24dps_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1378753456x1787722089_24dps(V, V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_24dps_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s143096761x246530315_24dps(V, V);
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_24dps_clo;
V g_list_2emap_24s1437960788x1959942644(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1437960788x1959942644_entry(V self, V *a);
extern Clo g_list_2emap_24s1437960788x1959942644_clo;
V g_list_2emap_24s1437960788x1959942644_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1437960788x1959942644_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1437960788x1959942644_24dps_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1490052334x152035327(V);
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a);
extern Clo g_list_2emap_24s1490052334x152035327_clo;
V g_list_2emap_24s1490052334x152035327_24dps(V, V);
V g_list_2emap_24s1490052334x152035327_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1490052334x152035327_24dps_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1661823642x1450093706(V);
V g_list_2emap_24s1661823642x1450093706_entry(V self, V *a);
extern Clo g_list_2emap_24s1661823642x1450093706_clo;
V g_list_2emap_24s1661823642x1450093706_24dps(V, V);
V g_list_2emap_24s1661823642x1450093706_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661823642x1450093706_24dps_clo;
V g_list_2emap_24s1665123230x1905625068_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s1665123230x1905625068_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1665123230x1905625068_24dps_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1820916133x486035825_24dps(V, V);
V g_list_2emap_24s1820916133x486035825_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1820916133x486035825_24dps_clo;
V g_list_2emap_24s1842320150x747311840(V);
V g_list_2emap_24s1842320150x747311840_entry(V self, V *a);
extern Clo g_list_2emap_24s1842320150x747311840_clo;
V g_list_2emap_24s1842320150x747311840_24dps(V, V);
V g_list_2emap_24s1842320150x747311840_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1842320150x747311840_24dps_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2081626528x1476576812(V);
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_clo;
V g_list_2emap_24s2081626528x1476576812_24dps(V, V);
V g_list_2emap_24s2081626528x1476576812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_24dps_clo;
V g_list_2emap_24s2103553821x564582624_24dps(V, V, V);
V g_list_2emap_24s2103553821x564582624_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2103553821x564582624_24dps_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s546447922x1671206170_24dps(V, V, V);
V g_list_2emap_24s546447922x1671206170_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s546447922x1671206170_24dps_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s594167626x1954057348(V, V);
V g_list_2emap_24s594167626x1954057348_entry(V self, V *a);
extern Clo g_list_2emap_24s594167626x1954057348_clo;
V g_list_2emap_24s594167626x1954057348_24dps(V, V, V);
V g_list_2emap_24s594167626x1954057348_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s594167626x1954057348_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s864521685x1610969087_24dps(V, V);
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_24dps_clo;
V g_list_2emap_24s876522837x2005194065(V, V, V, V);
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a);
extern Clo g_list_2emap_24s876522837x2005194065_clo;
V g_list_2emap_24s876522837x2005194065_24dps(V, V, V, V, V);
V g_list_2emap_24s876522837x2005194065_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s876522837x2005194065_24dps_clo;
V g_list_2emerge_24s1037857700x2096250953(V, V);
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_clo;
V g_list_2emerge_24s1037857700x2096250953_24dps(V, V, V);
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2emerge_24s179604802x978393081(V, V);
V g_list_2emerge_24s179604802x978393081_entry(V self, V *a);
extern Clo g_list_2emerge_24s179604802x978393081_clo;
V g_list_2emerge_24s179604802x978393081_24dps(V, V, V);
V g_list_2emerge_24s179604802x978393081_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s179604802x978393081_24dps_clo;
V g_list_2emerge_24s1904498032x521599863(V, V);
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_clo;
V g_list_2emerge_24s1904498032x521599863_24dps(V, V, V);
V g_list_2emerge_24s1904498032x521599863_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_24dps_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
Clo g_list_2emap_24s1044393341x1523302351_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_entry, 1, 0};

V g_list_2emap_24s1044393341x1523302351(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1044393341x1523302351_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351(a[0]);
}
Clo g_list_2emap_24s584454411x1006678865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_24dps_entry, 2, 0};

V g_list_2emap_24s584454411x1006678865_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s179604802x978393081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s179604802x978393081_entry, 2, 0};

V g_list_2emerge_24s179604802x978393081(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 6);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s179604802x978393081_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s179604802x978393081_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s179604802x978393081_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s179604802x978393081(a[0], a[1]);
}
Clo g_list_2emap_24s1374235278x875430684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1374235278x875430684_entry, 1, 0};

V g_list_2emap_24s1374235278x875430684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1374235278x875430684_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1374235278x875430684(a[0]);
}
Clo g_list_2emap_24s2081626528x1476576812_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081626528x1476576812_entry, 1, 0};

V g_list_2emap_24s2081626528x1476576812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2081626528x1476576812_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081626528x1476576812(a[0]);
}
Clo g_list_2emap_24s158244903x55062455_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_entry, 1, 0};

V g_list_2emap_24s158244903x55062455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s158244903x55062455_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455(a[0]);
}
Clo g_list_2emap_24s1729787689x465380098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_24dps_entry, 2, 0};

V g_list_2emap_24s1729787689x465380098_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2412});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2413 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1782778565x402128078_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_entry, 1, 0};

V g_list_2emap_24s1782778565x402128078(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s1782778565x402128078_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_entry, 1, 0};

V g_list_2emap_24s386875578x1005587669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s386875578x1005587669_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669(a[0]);
}
Clo g_list_2emap_24s1624059865x1140896478_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_entry, 1, 0};

V g_list_2emap_24s1624059865x1140896478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2esurface_2easNameE(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1624059865x1140896478_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478(a[0]);
}
Clo g_list_2emap_24s1006818869x590968200_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_24dps_entry, 2, 0};

V g_list_2emap_24s1006818869x590968200_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 7), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str0, 7, "Float64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str10, 1, "_");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str11, 1, "\?");
Clo g_list_2emap_24s143096761x246530315_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s143096761x246530315_24dps_entry, 2, 0};

V g_list_2emap_24s143096761x246530315_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s143096761x246530315_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2067043448x720245267_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_24dps_entry, 2, 0};

V g_list_2emap_24s2067043448x720245267_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2070597502x591087275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2070597502x591087275_entry, 2, 0};

V g_list_2efoldl_24s2070597502x591087275(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2esgItem(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2070597502x591087275(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1040186323x1541137667_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1040186323x1541137667_entry, 2, 0};

V g_list_2efoldl_24s1040186323x1541137667(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1040186323x1541137667_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1040186323x1541137667(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s71083851x23251329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s71083851x23251329_entry, 2, 0};

V g_list_2efoldl_24s71083851x23251329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimp_2evalNamesTop(v_x_242, v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s71083851x23251329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s71083851x23251329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1690891682x1517899652_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1690891682x1517899652_entry, 2, 0};

V g_list_2efoldl_24s1690891682x1517899652(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_t_246, v_t_249}), v_z_240});
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1690891682x1517899652(a[0], a[1]);
}
Clo g_list_2efoldl_24s1104809983x118204267_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1104809983x118204267_entry, 2, 0};

V g_list_2efoldl_24s1104809983x118204267(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1104809983x118204267(a[0], a[1]);
}
Clo g_list_2efoldl_24s410120642x105714730_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s410120642x105714730_entry, 2, 0};

V g_list_2efoldl_24s410120642x105714730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_take_field(v_x_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec_n(2, shape_name__span, (V[]){heff_take_field(v_x_242, 4), heff_get_n(v_x_242, 5, 6)});
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 6);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s410120642x105714730(a[0], a[1]);
}
Clo g_list_2eany_24s141450647x925029990_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s141450647x925029990_entry, 1, 0};

V g_list_2eany_24s141450647x925029990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s141450647x925029990_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s141450647x925029990(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_24dps_entry, 2, 0};

V g_list_2emap_24s1397747289x2145601499_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eprint_2eescFrom(v_x_242, MK_INT(0LL)));
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_24dps_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1397747289x2145601499_24dps_str1)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1880194630x798487332_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1880194630x798487332_entry, 2, 0};

V g_list_2efoldl_24s1880194630x798487332(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1880194630x798487332(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s797527640x986490519_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s797527640x986490519_entry, 2, 0};

V g_list_2efoldl_24s797527640x986490519(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1880194630x798487332(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s797527640x986490519(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1842320150x747311840_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1842320150x747311840_entry, 1, 0};

V g_list_2emap_24s1842320150x747311840(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_a_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_a_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_a_245, 0);
      heff_take_n(v_a_245, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1842320150x747311840_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1842320150x747311840_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1842320150x747311840(a[0]);
}
Clo g_list_2emap_24s1796125103x644876049_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_24dps_entry, 2, 0};

V g_list_2emap_24s1796125103x644876049_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1490052334x152035327_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1490052334x152035327_entry, 1, 0};

V g_list_2emap_24s1490052334x152035327(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_a_248, 1);
      heff_take_n(v_a_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1490052334x152035327_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1490052334x152035327(a[0]);
}
Clo g_list_2emap_24s1661823642x1450093706_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661823642x1450093706_entry, 1, 0};

V g_list_2emap_24s1661823642x1450093706(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_e_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_243;
      break;
    }
    case TAG_GivenU: {
      V v_e_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_e_245;
      break;
    }
    case TAG_LentVar: {
      V v_x_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_249 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_LentValue: {
      V v_e_248 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1661823642x1450093706_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1661823642x1450093706_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661823642x1450093706(a[0]);
}
Clo g_list_2efoldl_24s1418838819x1907320638_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1418838819x1907320638_entry, 2, 0};

V g_list_2efoldl_24s1418838819x1907320638(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2eworker_2etailCalls(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1418838819x1907320638_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1418838819x1907320638(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1820916133x486035825_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1820916133x486035825_24dps_entry, 2, 0};

V g_list_2emap_24s1820916133x486035825_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24PartVal = heff_take_reuse_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        v_t_2428 = heff_tag_at_n(v_ru_24x_242_24PartVal, TAG_Just, 1, (V[]){v_a_246});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_a_244, 0ULL, 4);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x_242_24PartVal, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2428 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2429));
    heff_drop(v_u_2430);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2429;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1820916133x486035825_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1820916133x486035825_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s357242026x384251201_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_entry, 1, 0};

V g_list_2emap_24s357242026x384251201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s357242026x384251201_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201(a[0]);
}
Clo g_list_2eany_24s184951243x1948563855_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s184951243x1948563855_entry, 1, 0};

V g_list_2eany_24s184951243x1948563855(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = (g_heff_2ecompile_2eemit_2eloops(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s184951243x1948563855(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s25420611x1990549631_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s25420611x1990549631_entry, 2, 0};

V g_list_2efoldl_24s25420611x1990549631(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 4, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s25420611x1990549631(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s413688307x112671032_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s413688307x112671032_entry, 4, 0};

V g_list_2efilter_24s413688307x112671032(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s413688307x112671032_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s413688307x112671032(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s649333309x1802289391_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_entry, 1, 0};

V g_list_2emap_24s649333309x1802289391(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2ehostLineOf(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s649333309x1802289391_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391(a[0]);
}
Clo g_list_2emap_24s720989758x1967438448_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_entry, 1, 0};

V g_list_2emap_24s720989758x1967438448(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s720989758x1967438448_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448(a[0]);
}
Clo g_list_2emap_24s1009200955x251267316_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_24dps_entry, 2, 0};

V g_list_2emap_24s1009200955x251267316_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_247 = v_t_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str1, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str2, 2, ");");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str3, 10, "heff_drop(");
Clo g_list_2emap_24s577269653x49010166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_entry, 1, 0};

V g_list_2emap_24s577269653x49010166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s577269653x49010166_str0)));
        V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str1), v_t_245), ((V)&g_list_2emap_24s577269653x49010166_str2));
        v_t_248 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str3), v_t_246);
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s577269653x49010166_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166(a[0]);
}
Clo g_list_2efoldl_24s2138447488x1597606028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2138447488x1597606028_entry, 2, 0};

V g_list_2efoldl_24s2138447488x1597606028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2138447488x1597606028(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1437960788x1959942644_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1437960788x1959942644_entry, 8, 0};

V g_list_2emap_24s1437960788x1959942644(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkDrop: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      switch (heff_tag_of(v_a_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_a_2410, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
        V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_245));
        v_t_2415 = heff_strAppend(heff_dup(v_lit_240), v_t_2413);
        break;
      }
      case TAG_Just: {
        V v_a_2414 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = ({ V a_0 = v_a_2410; V a_1 = v_a_2414; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2414); r_; });
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1437960788x1959942644_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1437960788x1959942644_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1437960788x1959942644(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1437960788x1959942644_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1437960788x1959942644_24dps_entry, 9, 0};

V g_list_2emap_24s1437960788x1959942644_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkDrop: {
      V v_a_2411 = heff_field(v_x_249, 0);
      V v_a_2412 = heff_field(v_x_249, 1);
      heff_take_n(v_x_249, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nothing: {
        V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_a_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
        V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_dup(v_lit_245));
        v_t_2416 = heff_strAppend(heff_dup(v_lit_240), v_t_2414);
        break;
      }
      case TAG_Just: {
        V v_a_2415 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 1);
        v_t_2416 = ({ V a_0 = v_a_2411; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2415); r_; });
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2418 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1437960788x1959942644_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1437960788x1959942644_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1378753456x1787722089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1378753456x1787722089_entry, 4, 0};

V g_list_2emap_24s1378753456x1787722089(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)));
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_248), v_t_2412);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2413), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s1378753456x1787722089_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1378753456x1787722089(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s2073083146x1445066245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_entry, 1, 0};

V g_list_2emap_24s2073083146x1445066245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2073083146x1445066245_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245(a[0]);
}
Clo g_list_2efilter_24s1967523567x64647275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1967523567x64647275_entry, 1, 0};

V g_list_2efilter_24s1967523567x64647275(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1967523567x64647275_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1967523567x64647275(a[0]);
}
Clo g_list_2emap_24s380834591x871125279_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_entry, 1, 0};

V g_list_2emap_24s380834591x871125279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s380834591x871125279_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279(a[0]);
}
Clo g_list_2emap_24s1665123230x1905625068_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1665123230x1905625068_24dps_entry, 7, 0};

V g_list_2emap_24s1665123230x1905625068_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_x_247), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    V v_t_2412;
    if (heff_strEq_c(v_t_249, heff_dup(v_lit_242))) {
      V v_t_2411 = (g_heff_2ecompile_2eemitc_2eidentAt(v_x_247, heff_dup(v_lit_243), heff_dup(v_lit_244)));
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
    } else {
      heff_drop(v_x_247);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1665123230x1905625068_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1665123230x1905625068_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s2137706589x1353696470_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2137706589x1353696470_entry, 2, 0};

V g_list_2efoldl_24s2137706589x1353696470(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s2126981320x1580482478(v_z_240, heff_rfield(v_x_242, 2)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2137706589x1353696470_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2137706589x1353696470(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_entry, 1, 0};

V g_list_2emap_24s391931963x434308123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s391931963x434308123_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123(a[0]);
}
Clo g_list_2emap_24s2103553821x564582624_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2103553821x564582624_24dps_entry, 3, 0};

V g_list_2emap_24s2103553821x564582624_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2103553821x564582624_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2103553821x564582624_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1608132097x1207501887_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1608132097x1207501887_entry, 2, 0};

V g_list_2efoldl_24s1608132097x1207501887(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 3));
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1608132097x1207501887(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s864521685x1610969087_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_entry, 1, 0};

V g_list_2emap_24s864521685x1610969087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edriver_2ehint(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s864521685x1610969087_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087(a[0]);
}
Clo g_list_2emap_24s864521685x1610969087_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_24dps_entry, 2, 0};

V g_list_2emap_24s864521685x1610969087_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ehint(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1535007417x1587061701_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_entry, 1, 0};

V g_list_2emap_24s1535007417x1587061701(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2419 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = (g_list_2emap_24s1535007417x1587061701_24dps(v_xs_242, heff_dup(v_cell_2426)));
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701(a[0]);
}
Clo g_list_2emap_24s1092537139x232684611_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1092537139x232684611_entry, 2, 0};

V g_list_2emap_24s1092537139x232684611(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_242, 2, 5));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_244, v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1092537139x232684611_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1092537139x232684611_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1092537139x232684611(a[0], a[1]);
}
Clo g_list_2emap_24s1895313378x47656836_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_24dps_entry, 2, 0};

V g_list_2emap_24s1895313378x47656836_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1561756891x1126436879_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_entry, 1, 0};

V g_list_2emap_24s1561756891x1126436879(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eformat_2epatKey(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1561756891x1126436879_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879(a[0]);
}
Clo g_list_2emap_24s594167626x1954057348_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s594167626x1954057348_entry, 2, 0};

V g_list_2emap_24s594167626x1954057348(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(v_x_242, 2, 3);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_244), heff_strLength(heff_dup(v_a_244))));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_a_244, heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s594167626x1954057348_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s594167626x1954057348_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s594167626x1954057348(a[0], a[1]);
}
Clo g_list_2emap_24s546447922x1671206170_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s546447922x1671206170_24dps_entry, 3, 0};

V g_list_2emap_24s546447922x1671206170_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_prelude_2eparseInt(v_x_243));
    V v_t_247;
    switch (heff_tag_of(v_a_245)) {
    case TAG_Nothing: {
      v_t_247 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_a_245, 0);
      heff_take_n(v_a_245, 1ULL, 1);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s546447922x1671206170_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s546447922x1671206170_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634456687x1151454243_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_248;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s132798885x1165759438_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_24dps_entry, 3, 0};

V g_list_2emerge_24s132798885x1165759438_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_247 = (g_heff_2ebuild_2eproject_2esumBefore(heff_dup(v_x_243), heff_dup(v_y_245)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_248;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str0, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str2, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str3, 9, "{ name = ");
Clo g_list_2emap_24s1381986540x1952410492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_24dps_entry, 2, 0};

V g_list_2emap_24s1381986540x1952410492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_242, 0)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_242, 1)));
    V v_t_246 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_242, 2, 3)));
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str0), heff_strAppend(v_t_246, ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str1)));
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str2), heff_strAppend(v_t_245, v_t_247));
    V v_t_249 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str3), heff_strAppend(v_t_244, v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_24dps_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_24dps_entry, 2, 0};

V g_list_2emap_24s1462590149x1582455373_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_x_242)), MK_INT(3LL));
    V v_t_245 = heff_strSlice(heff_dup(v_x_242), v_t_244, heff_strLength(heff_dup(v_x_242)));
    V v_t_248;
    if (heff_strEq_c(v_t_245, ((V)&g_list_2emap_24s1462590149x1582455373_24dps_str0))) {
      V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_x_242)), MK_INT(3LL));
      v_t_248 = heff_strSlice(v_x_242, MK_INT(0LL), v_t_247);
    } else {
      v_t_248 = v_x_242;
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s435407392x1528135477_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_24dps_entry, 2, 0};

V g_list_2emap_24s435407392x1528135477_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s1037857700x2096250953_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1037857700x2096250953_entry, 2, 0};

V g_list_2emerge_24s1037857700x2096250953(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 1, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2412 = (g_list_2emerge_24s1037857700x2096250953_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      } else {
        V v_cell_2413 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2414 = (g_list_2emerge_24s1037857700x2096250953_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_2413)));
        heff_drop(v_u_2414);
        return v_cell_2413;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1037857700x2096250953(a[0], a[1]);
}
Clo g_list_2efoldl_24s1777318809x1106245647_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1777318809x1106245647_entry, 2, 0};

V g_list_2efoldl_24s1777318809x1106245647(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2413));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1777318809x1106245647(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s54159557x1528472185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s54159557x1528472185_entry, 2, 0};

V g_list_2efoldl_24s54159557x1528472185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s54159557x1528472185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1904498032x521599863_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1904498032x521599863_entry, 2, 0};

V g_list_2emerge_24s1904498032x521599863(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_y_244, 2)), 0, 2);
      if (heff_intLe_c(v_t_246, v_t_247)) {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1904498032x521599863_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      } else {
        V v_cell_2411 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2412 = (g_list_2emerge_24s1904498032x521599863_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1904498032x521599863(a[0], a[1]);
}
Clo g_list_2efoldl_24s571074576x1179600767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_entry, 2, 0};

V g_list_2efoldl_24s571074576x1179600767(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_dup(heff_rfield(v_z_240, 1))});
    V v_t_245 = ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_nf(v_z_240, 29ULL, 5, shape_sources__errors__paths__package__packages, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767(a[0], a[1]);
}
Clo g_list_2efoldl_24s1325969685x576913065_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1325969685x576913065_entry, 2, 0};

V g_list_2efoldl_24s1325969685x576913065(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 1)), 2, 3);
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1325969685x576913065(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s831190316x576961335_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_entry, 1, 0};

V g_list_2emap_24s831190316x576961335(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s831190316x576961335_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335(a[0]);
}
Clo g_list_2emap_24s831190316x576961335_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_24dps_entry, 2, 0};

V g_list_2emap_24s831190316x576961335_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str0, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str1, 6, "detail");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str2, 5, "label");
Clo g_list_2emap_24s4199228x1154005405_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_24dps_entry, 2, 0};

V g_list_2emap_24s4199228x1154005405_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_246 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 1, 2)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str1), v_t_246}), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str2), v_t_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_248}), heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1281445768x1036802655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_24dps_entry, 2, 0};

V g_list_2emap_24s1281445768x1036802655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eflagWord(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1753874608x910016727_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_24dps_entry, 2, 0};

V g_list_2emap_24s1753874608x910016727_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eflagLine(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s876522837x2005194065_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s876522837x2005194065_entry, 4, 0};

V g_list_2emap_24s876522837x2005194065(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2413;
    if (heff_strEq_c(heff_dup(v_a_2411), heff_dup(v_lit_240))) {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_248;
    } else {
      v_t_2413 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s876522837x2005194065_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s876522837x2005194065(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f359508862x1661952287_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f359508862x1661952287_entry, 4, 0};

V g_list_2emap_24f359508862x1661952287(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_244, 1))}));
    V v_t_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_take_field(v_x_244, 1), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 2), heff_get_n(v_x_244, 3, 7)});
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_248), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f359508862x1661952287_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_244, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f359508862x1661952287_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f359508862x1661952287(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1625738412x188935108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1625738412x188935108_entry, 3, 0};

V g_list_2efoldl_24f1625738412x188935108(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x1_241, 0);
    V v_ks_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x2_242, 0);
      V v_vs_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_MkPair, 2, (V[]){v_k_243, v_v_245});
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ks_244;
      V t_2 = v_vs_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1625738412x188935108(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1686830387x1555365313_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1686830387x1555365313_entry, 4, 0};

V g_list_2efoldl_24f1686830387x1555365313(V v_z_240, V v_f_241, V v_xs_242, V v_ys_243) {
top: ;
  switch (heff_tag_of(v_xs_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_ys_243);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_242, 0);
    V v_xs2_245 = heff_field(v_xs_242, 1);
    V v_ru_24xs_242_24Cons = heff_take_reuse_n(v_xs_242, 3ULL, 2);
    switch (heff_tag_of(v_ys_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      heff_drop(v_x_244);
      heff_drop(v_xs2_245);
      heff_drop_cell(v_ru_24xs_242_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_ys_243, 0);
      V v_ys2_247 = heff_field(v_ys_243, 1);
      heff_take_n(v_ys_243, 3ULL, 2);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_244, v_y_246}));
      V t_0 = heff_tag_at_n(v_ru_24xs_242_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_z_240});
      V t_1 = v_f_241;
      V t_2 = v_xs2_245;
      V t_3 = v_ys2_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_xs_242 = t_2;
      v_ys_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_ys_243);
    }
  }
  default: return heff_nomatch(v_xs_242);
  }
}
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1686830387x1555365313(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1419248316x13095286_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1419248316x13095286_entry, 3, 0};

V g_list_2efoldl_24f1419248316x13095286(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1419248316x13095286(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f998257836x1791893456_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f998257836x1791893456_24dps_entry, 4, 0};

V g_list_2emap_24f998257836x1791893456_24dps(V v_lit_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2emap_24s1367796012x2117543847(v_lit_240, v_ys_242));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_245), heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f998257836x1791893456_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f998257836x1791893456_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f2000583729x2114721175_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2000583729x2114721175_24dps_entry, 4, 0};

V g_list_2emap_24f2000583729x2114721175_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_241), heff_strLength(heff_dup(v_x_244)))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_244), heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f2000583729x2114721175_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2000583729x2114721175_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f409057300x985797598_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f409057300x985797598_entry, 2, 0};

V g_list_2efoldl_24f409057300x985797598(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f409057300x985797598(a[0], a[1]);
}
Clo g_list_2emap_24f514979201x2029883448_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f514979201x2029883448_24dps_entry, 3, 0};

V g_list_2emap_24f514979201x2029883448_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 0, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f514979201x2029883448_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f514979201x2029883448_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f2063070488x1806431062_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2063070488x1806431062_entry, 2, 0};

V g_list_2emap_24f2063070488x1806431062(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
      V v_u_246 = (g_list_2emap_24f2063070488x1806431062_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2063070488x1806431062(a[0], a[1]);
}
Clo g_list_2emap_24f599584836x1400862534_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f599584836x1400862534_entry, 2, 0};

V g_list_2emap_24f599584836x1400862534(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_xs_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f599584836x1400862534_24dps(v_f_240, v_xs_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f599584836x1400862534_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f599584836x1400862534(a[0], a[1]);
}
Clo g_list_2emap_24f131620269x1652606631_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f131620269x1652606631_entry, 3, 0};

V g_list_2emap_24f131620269x1652606631(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 0, 8));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f131620269x1652606631_24dps(v_lit_240, v_p_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f131620269x1652606631_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f131620269x1652606631(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24f1461841536x2133820294_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f1461841536x2133820294_24dps_entry, 4, 0};

V g_list_2efilter_24f1461841536x2133820294_24dps(V v_p_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_t_247 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_p_240;
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_p_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_x_246);
      heff_drop(v_t_247);
      V t_0 = v_p_240;
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_p_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24f1461841536x2133820294_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f1461841536x2133820294_24dps(a[0], a[1], a[2], a[3]);
}