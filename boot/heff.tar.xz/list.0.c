// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I64 19315
#define TAG_ISts 38700
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkPath 49630
#define TAG_MkSegment 38079
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RepFix 59335
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_TopL 65516
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_at 9882
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_detail 611917692
#define LBL_doc 309170
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_hidden 729654485
#define LBL_id 10114
#define LBL_index 301704428
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_long 9823043
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_ok 10307
#define LBL_order 307364712
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_param 307795111
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_places 961367927
#define LBL_prims 308293287
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_witness 1587180415
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2edriver_2egoldenOfV(V);
V g_heff_2ebuild_2edriver_2egoldenOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2egoldenOfV_clo;
V g_heff_2ebuild_2edriver_2eintegrationOfV(V);
V g_heff_2ebuild_2edriver_2eintegrationOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eintegrationOfV_clo;
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eowned_2eownedAt(V, V);
V g_heff_2ecompile_2eowned_2eownedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedAt_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2escalars_2eslotFor(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotFor_clo;
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2eunbox_2eaddGiven(V, V);
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2efmt_2eimports_2eentryText(V);
V g_heff_2esyntax_2efmt_2eimports_2eentryText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eentryText_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1014015919x2013990442_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s335630579x1560445122(V, V);
V g_list_2eall_24s335630579x1560445122_entry(V self, V *a);
extern Clo g_list_2eall_24s335630579x1560445122_clo;
V g_list_2eall_24s525729714x658270192(V);
V g_list_2eall_24s525729714x658270192_entry(V self, V *a);
extern Clo g_list_2eall_24s525729714x658270192_clo;
V g_list_2eany_24s1414887908x732433189(V);
V g_list_2eany_24s1414887908x732433189_entry(V self, V *a);
extern Clo g_list_2eany_24s1414887908x732433189_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
V g_list_2eany_24s277053946x716662586(V, V);
V g_list_2eany_24s277053946x716662586_entry(V self, V *a);
extern Clo g_list_2eany_24s277053946x716662586_clo;
V g_list_2eany_24s325511642x189735065(V, V, V);
V g_list_2eany_24s325511642x189735065_entry(V self, V *a);
extern Clo g_list_2eany_24s325511642x189735065_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1618362284x812128366_24cpr(V, V);
HeffT2 g_list_2efind_24s1734629631x1085593985_24cpr(V, V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V, V);
HeffT2 g_list_2efind_24s292855629x1492583570_24cpr(V, V);
HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V, V);
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f2082849937x387822498(V, V, V, V);
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2082849937x387822498_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24s1061624263x1097104198(V, V);
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061624263x1097104198_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1511444646x1476348587(V, V);
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1511444646x1476348587_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s193704652x357697644(V, V);
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a);
extern Clo g_list_2efoldl_24s193704652x357697644_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s237252239x317103379(V, V);
V g_list_2efoldl_24s237252239x317103379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s237252239x317103379_clo;
V g_list_2efoldl_24s237252239x317103379_24scalars(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s237252239x317103379_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s237252239x317103379_24scalars_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s571074576x1179600767_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s571074576x1179600767_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_24scalars_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s825077203x853965193(V, V);
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s825077203x853965193_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24dps(V, V, V);
V g_list_2ekeepIf_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24dps_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2ekeepIf_24s1201185697x960477413_24dps(V, V, V);
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo;
V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V, V);
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo;
V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V, V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo;
V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V, V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo;
V g_list_2ekeepIf_24s1814523351x214817707_24dps(V, V);
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo;
V g_list_2ekeepIf_24s25507577x707942422_24dps(V, V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110_24dps(V, V);
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2ekeepIf_24s458067099x815639923_24dps(V, V);
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2ekeepIf_24s478006518x1380334353_24dps(V, V);
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo;
V g_list_2emap_24f1632378148x1903828118(V, V);
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_clo;
V g_list_2emap_24f1632378148x1903828118_24dps(V, V, V);
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_24dps_clo;
V g_list_2emap_24f2124896334x71745266_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_24dps_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1068592055x839006909(V, V, V, V);
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_clo;
V g_list_2emap_24s1068592055x839006909_24dps(V, V, V, V, V);
V g_list_2emap_24s1068592055x839006909_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_24dps_clo;
V g_list_2emap_24s1099021180x1702355548_24dps(V, V, V);
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_24dps_clo;
V g_list_2emap_24s1112048172x371485672_24dps(V, V);
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_24dps_clo;
V g_list_2emap_24s1215346472x331828322_24dps(V, V);
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_24dps_clo;
V g_list_2emap_24s1218614972x495009292_24dps(V, V, V, V);
V g_list_2emap_24s1218614972x495009292_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218614972x495009292_24dps_clo;
V g_list_2emap_24s1292210741x1158835606_24dps(V, V, V, V);
V g_list_2emap_24s1292210741x1158835606_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1292210741x1158835606_24dps_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1517387949x485543551(V);
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_clo;
V g_list_2emap_24s1517387949x485543551_24dps(V, V);
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_24dps_clo;
V g_list_2emap_24s1524528409x1420927362_24dps(V, V);
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s1618539892x552009225_24dps(V, V);
V g_list_2emap_24s1618539892x552009225_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_24dps_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s1700608285x1639860354_24dps(V, V);
V g_list_2emap_24s1700608285x1639860354_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_24dps_clo;
V g_list_2emap_24s1721231741x1085491812_24dps(V, V);
V g_list_2emap_24s1721231741x1085491812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_24dps_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1792553290x233563724_24dps(V, V);
V g_list_2emap_24s1792553290x233563724_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_list_2emap_24s1975257801x764827799_24dps(V, V);
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_24dps_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2139359291x1524787922_24dps(V, V);
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_24dps_clo;
V g_list_2emap_24s219049803x1458391381_24dps(V, V);
V g_list_2emap_24s219049803x1458391381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_24dps_clo;
V g_list_2emap_24s228910449x1110031924_24dps(V, V, V);
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_24dps_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2emap_24s258116700x992061112_24dps(V, V, V);
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_24dps_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s273193875x235978955_24dps(V, V, V, V, V);
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_24dps_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s34825065x1144190520_24dps(V, V);
V g_list_2emap_24s34825065x1144190520_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_24dps_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s370939663x1496042695_24dps(V, V, V);
V g_list_2emap_24s370939663x1496042695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_24dps_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s430074199x1834682414(V, V, V, V);
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_clo;
V g_list_2emap_24s430074199x1834682414_24dps(V, V, V, V, V);
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_24dps_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24s473401207x1960255357_24dps(V, V);
V g_list_2emap_24s473401207x1960255357_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_24dps_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s531657185x2070920831(V, V);
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s588468714x1874323009(V);
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_clo;
V g_list_2emap_24s588468714x1874323009_24dps(V, V);
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_24dps_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24s723912745x1713553694_24dps(V, V);
V g_list_2emap_24s723912745x1713553694_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_24dps_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s88069640x1067514236(V);
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_clo;
V g_list_2emap_24s88069640x1067514236_24dps(V, V);
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_24dps_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2emerge_24s2030620912x751826577_24dps(V, V, V);
V g_list_2emerge_24s2030620912x751826577_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2030620912x751826577_24dps_clo;
V g_list_2emerge_24s991540778x2011810329(V, V);
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_clo;
V g_list_2emerge_24s991540778x2011810329_24tok2(V, V, V);
V g_list_2emerge_24s991540778x2011810329_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_24tok2_clo;
V g_list_2esortBy_24s1993185874x500694228(V);
V g_list_2esortBy_24s1993185874x500694228_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1993185874x500694228_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1259666496x1713656817(V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_clo;
V g_list_2ezipWith_24s1259666496x1713656817_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_24dps_clo;
V g_list_2ezipWith_24s1877091673x1588480570(V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_clo;
V g_list_2ezipWith_24s1877091673x1588480570_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo;
V g_list_2ezipWith_24s457513469x1891643252_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_list_2ekeepIf_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_entry, 2, 0};

V g_list_2ekeepIf(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf(a[0], a[1]);
}
Clo g_list_2emap_24s1044393341x1523302351_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_entry, 1, 0};

V g_list_2emap_24s1044393341x1523302351(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1044393341x1523302351_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351(a[0]);
}
Clo g_list_2emap_24s584454411x1006678865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_24dps_entry, 2, 0};

V g_list_2emap_24s584454411x1006678865_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s525729714x658270192_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s525729714x658270192_entry, 1, 0};

V g_list_2eall_24s525729714x658270192(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_r1_243 = heff_field(v_x_241, 0);
      V v_r2_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_r1_243)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_lo_245 = heff_field(v_r1_243, 0);
        switch (heff_tag_of(v_r2_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_hi_246 = heff_field(v_r2_244, 0);
          if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_245, 1) && heff_intLe_c_lent(v_hi_246, MK_INT(4611686018427387903LL), 2))) {
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_r2_244);
        }
      }
      default: return heff_nomatch(v_r1_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s525729714x658270192_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s525729714x658270192(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s258116700x992061112_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_entry, 2, 0};

V g_list_2emap_24s258116700x992061112(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_245 = (g_list_2emap_24s258116700x992061112_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s258116700x992061112(a[0], a[1]);
}
Clo g_list_2emap_24s258116700x992061112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_24dps_entry, 3, 0};

V g_list_2emap_24s258116700x992061112_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s258116700x992061112_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1792553290x233563724_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1792553290x233563724_entry, 1, 0};

V g_list_2emap_24s1792553290x233563724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Unreached), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1792553290x233563724_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1792553290x233563724(a[0]);
}
Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1613584875x1342487326_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1975257801x764827799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1975257801x764827799_entry, 1, 0};

V g_list_2emap_24s1975257801x764827799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2eimports_2eentryText(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1975257801x764827799_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1975257801x764827799(a[0]);
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_entry, 1, 0};

V g_list_2emap_24s1409451498x400757684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_241, 2)), heff_dup(heff_rfield(v_x_241, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_list_2emap_24s1409451498x400757684_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1409451498x400757684_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684(a[0]);
}
Clo g_list_2emap_24s2139359291x1524787922_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2139359291x1524787922_24dps_entry, 2, 0};

V g_list_2emap_24s2139359291x1524787922_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2139359291x1524787922_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s34825065x1144190520_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s34825065x1144190520_entry, 1, 0};

V g_list_2emap_24s34825065x1144190520(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        V v_size_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 6ULL, 5);
        v_t_2410 = ({ V a_0 = v_ty_246; V a_1 = v_size_247; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_246); heff_drop(v_size_247); r_; });
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s34825065x1144190520_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s34825065x1144190520(a[0]);
}
Clo g_list_2eany_24s1414887908x732433189_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1414887908x732433189_entry, 1, 0};

V g_list_2eany_24s1414887908x732433189(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    HeffT2 v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_x_241); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s1014015919x2013990442_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_a_246 = v_field_244;
      V v_a_247 = v_field_245;
      heff_drop(v_a_247);
      if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
        heff_drop(v_a_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_a_246);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1414887908x732433189_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1414887908x732433189(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1036840854x702708481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_entry, 2, 0};

V g_list_2emap_24s1036840854x702708481(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1036840854x702708481_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1036840854x702708481(a[0], a[1]);
}
Clo g_list_2emap_24s158244903x55062455_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_entry, 1, 0};

V g_list_2emap_24s158244903x55062455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x_241_24At, v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s158244903x55062455_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455(a[0]);
}
Clo g_list_2emap_24s1729787689x465380098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_24dps_entry, 2, 0};

V g_list_2emap_24s1729787689x465380098_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2412});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2413 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1112048172x371485672_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1112048172x371485672_24dps_entry, 2, 0};

V g_list_2emap_24s1112048172x371485672_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2444 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2443, heff_hole()});
    V v_u_2445 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2444));
    heff_drop(v_u_2445);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2444;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1112048172x371485672_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s604143829x1495140576_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s604143829x1495140576_entry, 2, 0};

V g_list_2eany_24s604143829x1495140576(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ehandlerArg(v_lit_240, heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s604143829x1495140576(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s473401207x1960255357_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s473401207x1960255357_entry, 1, 0};

V g_list_2emap_24s473401207x1960255357(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s473401207x1960255357_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s473401207x1960255357(a[0]);
}
Clo g_list_2emap_24s2067043448x720245267_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_24dps_entry, 2, 0};

V g_list_2emap_24s2067043448x720245267_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2070597502x591087275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2070597502x591087275_entry, 2, 0};

V g_list_2efoldl_24s2070597502x591087275(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2esgItem(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2070597502x591087275(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1104809983x118204267_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1104809983x118204267_entry, 2, 0};

V g_list_2efoldl_24s1104809983x118204267(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1104809983x118204267(a[0], a[1]);
}
Clo g_list_2emap_24s531657185x2070920831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_entry, 2, 0};

V g_list_2emap_24s531657185x2070920831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2ekeptFrom(v_lit_240, v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s531657185x2070920831_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s88069640x1067514236_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s88069640x1067514236_entry, 1, 0};

V g_list_2emap_24s88069640x1067514236(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s88069640x1067514236_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s88069640x1067514236(a[0]);
}
Clo g_list_2efoldl_24s193704652x357697644_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s193704652x357697644_entry, 2, 0};

V g_list_2efoldl_24s193704652x357697644(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s490001784x345683100(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s193704652x357697644(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s335630579x1560445122_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s335630579x1560445122_entry, 2, 0};

V g_list_2eall_24s335630579x1560445122(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s335630579x1560445122_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s335630579x1560445122(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1061624263x1097104198_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1061624263x1097104198_entry, 2, 0};

V g_list_2efoldl_24s1061624263x1097104198(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eowned_2eownedAt(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1061624263x1097104198(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1366776885x1474218589_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1700608285x1639860354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1700608285x1639860354_24dps_entry, 2, 0};

V g_list_2emap_24s1700608285x1639860354_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1700608285x1639860354_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1700608285x1639860354_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1630057461x1822494873_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1630057461x1822494873_entry, 1, 0};

V g_list_2eany_24s1630057461x1822494873(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_OutTag: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutRecord: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutCall: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutOther: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1630057461x1822494873(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s273193875x235978955_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s273193875x235978955_entry, 4, 0};

V g_list_2emap_24s273193875x235978955(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_numbered_2412 = heff_take_field(v_a_2411, 1);
    V v_kinds_2413 = heff_get_n(v_a_2411, 2, 7);
    V v_t_2415;
    if ((heff_dup(v_numbered_2412) == NTAG(TAG_True))) {
      heff_drop(v_numbered_2412);
      V v_t_2414 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_kinds_2413});
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_numbered_2412);
      v_t_2415 = v_kinds_2413;
    }
    V v_t_2416 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_2415; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_248, heff_dup(v_lit_240)), v_t_2416});
    V v_cell_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s273193875x235978955_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s273193875x235978955_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s273193875x235978955(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s410120642x105714730_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s410120642x105714730_entry, 2, 0};

V g_list_2efoldl_24s410120642x105714730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_sol_244 = heff_take_field(v_x_242, 1);
    V v_name_245 = heff_take_field(v_x_242, 4);
    V v_span_246 = heff_get_n(v_x_242, 5, 6);
    V v_t_248;
    switch (heff_tag_of(v_sol_244)) {
    case TAG_Nothing: {
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_name_245, v_span_246}), v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_sol_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_name_245);
      heff_drop(v_span_246);
      v_t_248 = v_z_240;
      break;
    }
    default: heff_nomatch(v_sol_244);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s410120642x105714730(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_24dps_entry, 2, 0};

V g_list_2emap_24s1397747289x2145601499_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_24dps_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1397747289x2145601499_24dps_str1)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1292210741x1158835606_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1292210741x1158835606_24dps_entry, 4, 0};

V g_list_2emap_24s1292210741x1158835606_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 6);
    V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_248 = heff_get_n(heff_get_n(v_x_244, 0, 3), 1, 6);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_248, heff_dup(v_lit_241)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_249), heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1292210741x1158835606_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1292210741x1158835606_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1690674600x556093466_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_24dps_entry, 2, 0};

V g_list_2emap_24s1690674600x556093466_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1690674600x556093466_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1524528409x1420927362_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1524528409x1420927362_24dps_entry, 2, 0};

V g_list_2emap_24s1524528409x1420927362_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24Given = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_245 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_244));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24Given, TAG_Given, 1, (V[]){v_t_245});
      break;
    }
    case TAG_GivenU: {
      V v_a_246 = heff_field(v_x_242, 0);
      V v_a_247 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24GivenU = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_247));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24GivenU, TAG_GivenU, 2, (V[]){v_a_246, v_t_248});
      break;
    }
    case TAG_LentVar: {
      v_t_2413 = v_x_242;
      break;
    }
    case TAG_LentValue: {
      V v_a_2411 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24LentValue = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_2412 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24LentValue, TAG_LentValue, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1524528409x1420927362_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1259666496x1713656817_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1259666496x1713656817_entry, 5, 0};

V g_list_2ezipWith_24s1259666496x1713656817(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_249 = (g_heff_2ecompile_2escalars_2eslotFor(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_245, v_y_247));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2ezipWith_24s1259666496x1713656817_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1259666496x1713656817_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s1259666496x1713656817(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s292855629x1492583570_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s277053946x716662586_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s277053946x716662586_entry, 2, 0};

V g_list_2eany_24s277053946x716662586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s277053946x716662586_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s277053946x716662586(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s825077203x853965193_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s825077203x853965193_entry, 2, 0};

V g_list_2efoldl_24s825077203x853965193(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eunbox_2eaddGiven(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s825077203x853965193(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1734629631x1085593985_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s357242026x384251201_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_entry, 1, 0};

V g_list_2emap_24s357242026x384251201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s357242026x384251201_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201(a[0]);
}
Clo g_list_2efoldl_24s25420611x1990549631_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s25420611x1990549631_entry, 2, 0};

V g_list_2efoldl_24s25420611x1990549631(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 4, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s25420611x1990549631(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_entry, 1, 0};

V g_list_2emap_24s391931963x434308123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s391931963x434308123_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123(a[0]);
}
Clo g_list_2emap_24s1009200955x251267316_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_24dps_entry, 2, 0};

V g_list_2emap_24s1009200955x251267316_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_247 = v_t_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s457513469x1891643252_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s457513469x1891643252_24dps_entry, 10, 0};

V g_list_2ezipWith_24s457513469x1891643252_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_intShow(v_y_2412), heff_dup(v_lit_246));
      V v_t_2416 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_strAppend(heff_dup(v_lit_245), v_t_2415));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2416), heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_cell_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s457513469x1891643252_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s457513469x1891643252_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2ezipWith_24s1877091673x1588480570_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1877091673x1588480570_entry, 5, 0};

V g_list_2ezipWith_24s1877091673x1588480570(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_249 = heff_dup(heff_field(v_x_245, 0));
        v_t_2411 = v_a_249;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_x_245, 1);
        heff_take_n(v_x_245, 2ULL, 2);
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2414, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_intShow(v_y_247), v_t_2415);
      V v_t_2417 = heff_strAppend(v_t_2411, heff_strAppend(heff_dup(v_lit_240), v_t_2416));
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = (g_list_2ezipWith_24s1877091673x1588480570_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2418)));
      heff_drop(v_u_2419);
      return v_cell_2418;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1877091673x1588480570_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1877091673x1588480570(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s430074199x1834682414_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s430074199x1834682414_entry, 4, 0};

V g_list_2emap_24s430074199x1834682414(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2etupleRead(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s430074199x1834682414_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s430074199x1834682414(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str0, 6, "double");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str1, 4, "bool");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str2, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str3, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str4, 6, "char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str5, 2, " *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_24dps_str6, 4, "void");
Clo g_list_2emap_24s1215346472x331828322_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1215346472x331828322_24dps_entry, 2, 0};

V g_list_2emap_24s1215346472x331828322_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_CInteger: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_247 = v_t_244;
      break;
    }
    case TAG_CDouble: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str0);
      break;
    }
    case TAG_CBool: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str1);
      break;
    }
    case TAG_CString: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str2);
      break;
    }
    case TAG_CText: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_245 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_247 = heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1215346472x331828322_24dps_str5));
      break;
    }
    case TAG_CVoid: {
      v_t_247 = ((V)&g_list_2emap_24s1215346472x331828322_24dps_str6);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1215346472x331828322_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1814523351x214817707_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1814523351x214817707_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(v_t_246); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1814523351x214817707_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2073083146x1445066245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_entry, 1, 0};

V g_list_2emap_24s2073083146x1445066245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2073083146x1445066245_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245(a[0]);
}
Clo g_list_2ekeepIf_24s478006518x1380334353_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s478006518x1380334353_entry, 1, 0};

V g_list_2ekeepIf_24s478006518x1380334353(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = v_x_241; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s478006518x1380334353_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s478006518x1380334353(a[0]);
}
Clo g_list_2emap_24s380834591x871125279_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_entry, 1, 0};

V g_list_2emap_24s380834591x871125279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s380834591x871125279_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279(a[0]);
}
Clo g_list_2emap_24s1218614972x495009292_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218614972x495009292_24dps_entry, 4, 0};

V g_list_2emap_24s1218614972x495009292_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1218614972x495009292_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218614972x495009292_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_entry, 1, 0};

V g_list_2emap_24s502656580x1955732096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 5);
    V v_t_2423;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_list_2emap_24s502656580x1955732096_str0), 2)) {
          heff_drop(v_x_246);
          heff_drop_cell(v_ru_24x11_244_24PatVar, 1);
          v_t_2423 = NTAG(TAG_Nothing);
        } else {
          v_t_2423 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s502656580x1955732096_24dps(v_xs_242, heff_dup(v_cell_2424)));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096(a[0]);
}
Clo g_list_2efoldl_24s237252239x317103379_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s237252239x317103379_entry, 2, 0};

V g_list_2efoldl_24s237252239x317103379(V v_z_240, V v_x3_241) {
top: ;
  V v_order_242 = heff_take_field(v_z_240, 0);
  V v_entries_243 = heff_take_field(v_z_240, 1);
  V v_aliases_244 = heff_take_field(v_z_240, 2);
  V v_broken_245 = heff_take_field(v_z_240, 3);
  V v_ambiguous_246 = heff_take_field(v_z_240, 4);
  V v_places_247 = heff_take_field(v_z_240, 5);
  V v_hidden_248 = heff_take_field(v_z_240, 6);
  V v_instances_249 = heff_get_n(v_z_240, 7, 8);
  return (g_list_2efoldl_24s237252239x317103379_24scalars(v_order_242, v_entries_243, v_aliases_244, v_broken_245, v_ambiguous_246, v_places_247, v_hidden_248, v_instances_249, v_x3_241));
}
V g_list_2efoldl_24s237252239x317103379_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s237252239x317103379(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1608132097x1207501887_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1608132097x1207501887_entry, 2, 0};

V g_list_2efoldl_24s1608132097x1207501887(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 3));
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1608132097x1207501887(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s325511642x189735065_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s325511642x189735065_entry, 3, 0};

V g_list_2eany_24s325511642x189735065(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_strEq_c_lent(v_lit_240, v_x_243, 0)) {
      heff_drop(v_lit_241);
      return NTAG(TAG_True);
    } else {
      V v_a_245 = heff_strAppend(heff_dup(v_lit_241), heff_dup(v_x_243));
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) - heff_unbox_word(heff_strLength_lent(v_a_245, 0)));
      V v_t_247 = heff_strSlice(heff_dup(v_lit_240), heff_box_word(v_t_246), heff_strLength_lent(v_lit_240, 0));
      if (heff_strEq_c(v_t_247, v_a_245)) {
        heff_drop(v_lit_241);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s325511642x189735065_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2eany_24s325511642x189735065(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s370939663x1496042695_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s370939663x1496042695_24dps_entry, 3, 0};

V g_list_2emap_24s370939663x1496042695_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 2, 5));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s370939663x1496042695_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s370939663x1496042695_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1068592055x839006909_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1068592055x839006909_entry, 4, 0};

V g_list_2emap_24s1068592055x839006909(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 10);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_lit_240, 9));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(v_lit_241);
    } else {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(v_lit_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_x_244), heff_hole()});
    V v_u_249 = (g_list_2emap_24s1068592055x839006909_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1068592055x839006909(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1517387949x485543551_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1517387949x485543551_entry, 1, 0};

V g_list_2emap_24s1517387949x485543551(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2egoldenOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1517387949x485543551_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1517387949x485543551(a[0]);
}
Clo g_list_2emap_24s588468714x1874323009_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588468714x1874323009_entry, 1, 0};

V g_list_2emap_24s588468714x1874323009(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eintegrationOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s588468714x1874323009_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588468714x1874323009(a[0]);
}
Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_242, 2)) == NTAG(TAG_True))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_xs_243;
      V t_1 = v_cell_244;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1266148589x1647110933_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s2030620912x751826577_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2030620912x751826577_24dps_entry, 3, 0};

V g_list_2emerge_24s2030620912x751826577_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 2);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_247;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_249;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s2030620912x751826577_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2030620912x751826577_24dps(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_24s1993185874x500694228_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1993185874x500694228_entry, 1, 0};

V g_list_2esortBy_24s1993185874x500694228(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s1993185874x500694228(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s1993185874x500694228(v_t_2411));
      return (g_list_2emerge_24s991540778x2011810329_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1993185874x500694228_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1993185874x500694228(a[0]);
}
Clo g_list_2emap_24s1721231741x1085491812_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1721231741x1085491812_24dps_entry, 2, 0};

V g_list_2emap_24s1721231741x1085491812_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(v_t_246, 0, 4);
    V v_t_2446;
    switch (heff_tag_of(v_t_247)) {
    case TAG_SLocal: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      V v_ru_24t_247_24SPrim = heff_take_reuse_n(v_t_247, 0ULL, 1);
      V v_t_2434;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_2432 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_2434 = v_a_2432;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2446 = heff_tag_at_n(v_ru_24t_247_24SPrim, TAG_Just, 1, (V[]){v_t_2434});
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_247, 0ULL, 1);
      heff_drop(v_x_242);
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_cell_2447 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2446, heff_hole()});
    V v_u_2448 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2447));
    heff_drop(v_u_2448);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2447;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1721231741x1085491812_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1721231741x1085491812_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    if ((heff_intLe_c_lent(v_start_245, v_lit_240, 0) && heff_intLe_c_lent(v_lit_240, v_end_246, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 14);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s54159557x1528472185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s54159557x1528472185_entry, 2, 0};

V g_list_2efoldl_24s54159557x1528472185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s54159557x1528472185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1099021180x1702355548_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1099021180x1702355548_24dps_entry, 3, 0};

V g_list_2emap_24s1099021180x1702355548_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2efieldSetKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1099021180x1702355548_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s228910449x1110031924_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s228910449x1110031924_24dps_entry, 3, 0};

V g_list_2emap_24s228910449x1110031924_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eparamKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s228910449x1110031924_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634456687x1151454243_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s25507577x707942422_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s25507577x707942422_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240)) && heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s25507577x707942422_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s132798885x1165759438_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_24dps_entry, 3, 0};

V g_list_2emerge_24s132798885x1165759438_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 3);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_247;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
          V v_x1_249 = (g_heff_2ebuild_2eproject_2enewer(heff_rfield(v_x_243, 1), heff_rfield(v_y_245, 1)));
          if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
            heff_drop(v_x1_249);
            V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
            heff_drop(v_u_2411);
            V t_0 = v_xs_244;
            V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
            V t_2 = v_cell_2410;
            v_x2_240 = t_0;
            v_x3_241 = t_1;
            v_d_242 = t_2;
            goto top;
          } else {
            heff_drop(v_x1_249);
            V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
            V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
            heff_drop(v_u_2413);
            V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
            V t_1 = v_ys_246;
            V t_2 = v_cell_2412;
            v_x2_240 = t_0;
            v_x3_241 = t_1;
            v_d_242 = t_2;
            goto top;
          }
        } else {
          V v_cell_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
          V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
          heff_drop(v_u_2415);
          V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
          V t_1 = v_ys_246;
          V t_2 = v_cell_2414;
          v_x2_240 = t_0;
          v_x3_241 = t_1;
          v_d_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str0, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str2, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str3, 9, "{ name = ");
Clo g_list_2emap_24s1381986540x1952410492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_24dps_entry, 2, 0};

V g_list_2emap_24s1381986540x1952410492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_path_245 = heff_take_field(v_x_242, 1);
    V v_version_246 = heff_get_n(v_x_242, 2, 3);
    V v_t_247 = ({ V a_0 = v_name_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_244); r_; });
    V v_t_248 = ({ V a_0 = v_path_245; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_path_245); r_; });
    V v_t_249 = ({ V a_0 = v_version_246; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_version_246); r_; });
    V v_t_2410 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str0), heff_strAppend(v_t_249, ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str1)));
    V v_t_2411 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str2), heff_strAppend(v_t_248, v_t_2410));
    V v_t_2412 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str3), heff_strAppend(v_t_247, v_t_2411));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s219049803x1458391381_24dps_str0, 0, "");
Clo g_list_2emap_24s219049803x1458391381_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s219049803x1458391381_24dps_entry, 2, 0};

V g_list_2emap_24s219049803x1458391381_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPath: {
      V v_xs_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_xs_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x1_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_list_2emap_24s219049803x1458391381_24dps_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 2);
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s219049803x1458391381_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s219049803x1458391381_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_24dps_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_24dps_entry, 2, 0};

V g_list_2emap_24s1462590149x1582455373_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_x_242), heff_box_word(v_t_244), heff_strLength_lent(v_x_242, 0));
    V v_t_247;
    if (heff_strEq_c(v_t_245, ((V)&g_list_2emap_24s1462590149x1582455373_24dps_str0))) {
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
      v_t_247 = heff_strSlice(v_x_242, MK_INT(0LL), heff_box_word(v_t_246));
    } else {
      v_t_247 = v_x_242;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s571074576x1179600767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_entry, 2, 0};

V g_list_2efoldl_24s571074576x1179600767(V v_z_240, V v_x3_241) {
top: ;
  V v_sources_242 = heff_take_field(v_z_240, 0);
  V v_errors_243 = heff_take_field(v_z_240, 1);
  V v_paths_244 = heff_take_field(v_z_240, 2);
  V v_package_245 = heff_take_field(v_z_240, 3);
  V v_packages_246 = heff_get_n(v_z_240, 4, 5);
  return (g_list_2efoldl_24s571074576x1179600767_24scalars(v_sources_242, v_errors_243, v_paths_244, v_package_245, v_packages_246, v_x3_241));
}
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s458067099x815639923_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s458067099x815639923_entry, 1, 0};

V g_list_2ekeepIf_24s458067099x815639923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_241, 1)) == NTAG(TAG_True))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s458067099x815639923_24dps(v_xs_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_x_241, 12);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s458067099x815639923(a[0]);
}
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1618539892x552009225_str5, 0, "");
Clo g_list_2emap_24s1618539892x552009225_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1618539892x552009225_entry, 1, 0};

V g_list_2emap_24s1618539892x552009225(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str0);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str1);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str2);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str3);
      break;
    }
    case TAG_JString: {
      V v_t_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_t_246;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str4);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1618539892x552009225_str5);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1618539892x552009225_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1618539892x552009225(a[0]);
}
Clo g_list_2emap_24s723912745x1713553694_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s723912745x1713553694_entry, 1, 0};

V g_list_2emap_24s723912745x1713553694(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s723912745x1713553694_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s723912745x1713553694(a[0]);
}
HEFF_LIT(g_list_2efoldl_24s1511444646x1476348587_str0, 2, ": ");
HEFF_LIT(g_list_2efoldl_24s1511444646x1476348587_str1, 2, "\015\012");
Clo g_list_2efoldl_24s1511444646x1476348587_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1511444646x1476348587_entry, 2, 0};

V g_list_2efoldl_24s1511444646x1476348587(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x_242, 0);
      V v_v_245 = heff_field(v_x_242, 1);
      V v_t_246 = heff_strAppend(((V)&g_list_2efoldl_24s1511444646x1476348587_str0), heff_strAppend(heff_dup(v_v_245), ((V)&g_list_2efoldl_24s1511444646x1476348587_str1)));
      v_t_247 = heff_strAppend(v_z_240, heff_strAppend(heff_dup(v_n_244), v_t_246));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1511444646x1476348587(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s831190316x576961335_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_24dps_entry, 2, 0};

V g_list_2emap_24s831190316x576961335_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str0, 5, "label");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str1, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str2, 6, "detail");
Clo g_list_2emap_24s4199228x1154005405_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_24dps_entry, 2, 0};

V g_list_2emap_24s4199228x1154005405_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_label_244 = heff_take_field(v_x_242, 0);
    V v_detail_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str0), heff_tag_n(TAG_JString, 1, (V[]){v_label_244})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str1), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str2), heff_tag_n(TAG_JString, 1, (V[]){v_detail_245})});
    V v_t_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    V v_cell_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1201185697x960477413_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1201185697x960477413_entry, 2, 0};

V g_list_2ekeepIf_24s1201185697x960477413(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intLe_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1201185697x960477413_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1201185697x960477413(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1618362284x812128366_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 8);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s44384897x1267641110_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s44384897x1267641110_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s44384897x1267641110_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f2082849937x387822498_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2082849937x387822498_entry, 4, 0};

V g_list_2efoldl_24f2082849937x387822498(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c_lent(v_x_244, v_lit_242, 0)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f2082849937x387822498(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1686830387x1555365313_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1686830387x1555365313_entry, 4, 0};

V g_list_2efoldl_24f1686830387x1555365313(V v_z_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_x3_243);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_244, v_y_246}));
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_z_240});
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_ys_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1686830387x1555365313(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1419248316x13095286_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1419248316x13095286_entry, 3, 0};

V g_list_2efoldl_24f1419248316x13095286(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1419248316x13095286(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f2092936166x2062766724_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2092936166x2062766724_entry, 3, 0};

V g_list_2efoldl_24f2092936166x2062766724(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      v_x_247 = heff_dup(v_y_246);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    heff_drop(v_x_247);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2092936166x2062766724(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1625738412x188935108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1625738412x188935108_entry, 3, 0};

V g_list_2efoldl_24f1625738412x188935108(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x1_241, 0);
    V v_ks_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x2_242, 0);
      V v_vs_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_k_243, v_v_245});
      V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ks_244;
      V t_2 = v_vs_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1625738412x188935108(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24f1632378148x1903828118_str0, 13, "static Clo g_");
Clo g_list_2emap_24f1632378148x1903828118_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1632378148x1903828118_entry, 2, 0};

V g_list_2emap_24f1632378148x1903828118(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f1632378148x1903828118_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
      V v_u_246 = (g_list_2emap_24f1632378148x1903828118_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1632378148x1903828118(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f2124896334x71745266_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2124896334x71745266_24dps_entry, 13, 0};

V g_list_2emap_24f2124896334x71745266_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_2412, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2415 = heff_take_field(v_x_2413, 0);
    V v_key_2416 = heff_get_n(v_x_2413, 1, 2);
    V v_a_2417 = heff_dup(v_name_2415);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2417, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2417);
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__key, (V[]){v_name_2415, v_key_2416}), heff_hole()});
      V v_u_2419 = heff_setField(v_d_2412, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2415);
      heff_drop(v_key_2416);
      heff_drop(v_a_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f2124896334x71745266_24dps(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11], a[12]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2efoldl_24f1425140065x1254143828_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1425140065x1254143828_entry, 4, 0};

V g_list_2efoldl_24f1425140065x1254143828(V v_lit_240, V v_z_241, V v_seen_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_seen_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_rest_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_244, v_seen_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_seen_242});
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1425140065x1254143828(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24tok2_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24tok2(a[0], a[1]);
}