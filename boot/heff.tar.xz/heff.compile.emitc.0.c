// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkWrapper 39179
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_copies 592412158
#define LBL_defs 9574869
#define LBL_emits 297985818
#define LBL_ems 310085
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_groups 709681407
#define LBL_lams 9809570
#define LBL_lowered 588863906
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_parts 307795706
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_parts__errors__groups__copies__emits[] = {LBL_parts, LBL_errors, LBL_groups, LBL_copies, LBL_emits};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2ecByte(V, V, V);
V g_heff_2ecompile_2eemitc_2ecByte_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecByte_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2ecallC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallC_clo;
V g_heff_2ecompile_2eemitc_2ecallHead(V, V, V);
V g_heff_2ecompile_2eemitc_2ecallHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallHead_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefsKept(V, V, V);
V g_heff_2ecompile_2eemitc_2edefsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefsKept_clo;
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2einfixC(V, V);
V g_heff_2ecompile_2eemitc_2einfixC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einfixC_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptParts(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo;
V g_heff_2ecompile_2eemitc_2ekeptPartsCE(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptPartsCE_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eemitc_2ewrapperCode(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_list_2eall_24s1359914687x262073401(V);
V g_list_2eall_24s1359914687x262073401_entry(V self, V *a);
extern Clo g_list_2eall_24s1359914687x262073401_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1414103338x1084960320(V, V, V, V);
V g_list_2efoldl_24s1414103338x1084960320_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1414103338x1084960320_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1732572494x729779974(V, V);
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1732572494x729779974_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap_24s1661823642x1450093706(V);
V g_list_2emap_24s1661823642x1450093706_entry(V self, V *a);
extern Clo g_list_2emap_24s1661823642x1450093706_clo;
V g_list_2emap_24s1785262601x1752264566(V, V, V, V);
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a);
extern Clo g_list_2emap_24s1785262601x1752264566_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1280198663x1762821176(V, V, V);
V g_prelude_2e_2b_2b_24f1280198663x1762821176_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1280198663x1762821176_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str0, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str2, 1, "_");
Clo g_heff_2ecompile_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2emangleChar(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_dup(v_c_240)));
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_240)));
  } else {
    heff_drop(v_t_241);
    V v_d_242 = heff_intDiv(heff_intMod(heff_dup(v_c_240), MK_INT(256LL)), MK_INT(16LL));
    V v_t_243 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str0), heff_dup(v_d_242), heff_intAdd(v_d_242, MK_INT(1LL)));
    V v_d_244 = heff_intMod(v_c_240, MK_INT(16LL));
    V v_t_245 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str1), heff_dup(v_d_244), heff_intAdd(v_d_244, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str2), heff_strAppend(v_t_243, v_t_245));
  }
}
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = (g_prelude_2eindexFrom(heff_dup(v_pre_240), v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_pre_240);
    heff_drop(v_text_241);
    heff_drop(v_i_242);
    return v_acc_243;
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_248 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_246), heff_strLength(heff_dup(v_pre_240)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2eidentAt(heff_dup(v_text_241), v_t_248, v_t_249));
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_247;
    V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enamesInGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecBytesGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecBytesGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2ecByte(heff_dup(v_s_240), heff_dup(v_i_241), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecBytesGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str0, 10, "((V)&prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str1, 5, "_clo)");
Clo g_heff_2ecompile_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimLit_str0), heff_strAppend(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemitc_2eprimLit_str1)));
  V v_o_243 = heff_dup(heff_rfield(v_s_241, 0));
  V v_ps_244 = heff_take_field(v_s_241, 7);
  V v_t_245 = (g_heff_2ecompile_2eemitc_2eownHas(heff_dup(v_o_243), heff_dup(v_p_240), v_ps_244));
  V v_t_246;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_p_240);
    heff_drop(v_o_243);
    heff_drop(v_t_245);
    v_t_246 = v_ps_244;
  } else {
    heff_drop(v_t_245);
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_243, v_p_240}), v_ps_244});
  }
  V v_t_247 = ({ V rv_7 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_247});
}
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimLit(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str0, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str1, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str2, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str3, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str4, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str5, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str6, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str7, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str8, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str9, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str10, 2, "_t");
Clo g_heff_2ecompile_2eemitc_2efixedType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedType_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedType(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedType_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_244 = heff_strAppend(heff_intShow(v_t_243), ((V)&g_heff_2ecompile_2eemitc_2efixedType_str10));
    return heff_strAppend(v_t_242, v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedType(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einfixC_str5, 1, "(");
Clo g_heff_2ecompile_2eemitc_2einfixC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2einfixC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2einfixC(V v_op_240, V v_vs_241) {
top: ;
  V v_x2_244;
  switch (heff_tag_of(v_vs_241)) {
  case TAG_Nil: {
    v_x2_244 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_vs_241, 0));
    v_x2_244 = heff_tag_n(TAG_Just, 1, (V[]){v_x_242});
    break;
  }
  default: heff_nomatch(v_vs_241);
  }
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2einfixC_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_x1_247 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
  V v_x2_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_x2_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_x2_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_x_248});
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2einfixC_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einfixC_str2), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2einfixC_str3)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einfixC_str4), heff_strAppend(v_op_240, v_t_2413));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einfixC_str5), heff_strAppend(v_t_246, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2einfixC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2einfixC(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str3, 9, "heff_div_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str8, 9, "heff_rem_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str13, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str14, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str15, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str16, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str18, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str19, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str20, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str21, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str22, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str23, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str35, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str36, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str37, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str38, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str39, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str41, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str42, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str43, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str44, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str45, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str46, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str54, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str56, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str57, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str58, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str59, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str60, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str61, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str62, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str63, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str64, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str65, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str66, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str67, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str68, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str69, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str70, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str71, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str72, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str73, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str74, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str75, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str76, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str77, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str78, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str80, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str81, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str82, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str83, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str84, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str85, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str86, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str87, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str88, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str89, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str90, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str91, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str92, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str93, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str94, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str95, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str96, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str97, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str98, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str100, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str101, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str102, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str103, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str104, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str105, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str106, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str107, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str108, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str109, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str110, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str111, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str112, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str113, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str114, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str115, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str116, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str117, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str118, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str119, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str120, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str121, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str122, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str123, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str125, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str127, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str128, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str129, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str130, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str131, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str132, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str133, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str134, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str135, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str136, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str137, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str138, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str139, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str140, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str141, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str142, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str143, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str144, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str145, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str146, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str147, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str148, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str149, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str150, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str151, 9, "heff_shl_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str152, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str153, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str154, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str155, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str156, 9, "heff_shr_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str157, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str158, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str159, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str160, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str161, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str162, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str163, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str164, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str165, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str166, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str167, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str168, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str169, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str170, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str171, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str172, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str173, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str174, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str175, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str176, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str177, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str178, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str179, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str182, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str183, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str184, 14, "heff_from_int_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str185, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str186, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str187, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str188, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str189, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str190, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str191, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str192, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str193, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str194, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str195, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str196, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str197, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str198, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str199, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str200, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str201, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str202, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str203, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str204, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str205, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str206, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str207, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str208, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str209, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str210, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str211, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str212, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str213, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str214, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str215, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str216, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str217, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str218, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str219, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str220, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str221, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str222, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str223, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str224, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str225, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str226, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str227, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str228, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str229, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str230, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str231, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str232, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str233, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str234, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str235, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str237, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str238, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str239, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str240, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str241, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str242, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str243, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str244, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str245, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str246, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str247, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str248, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str249, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str250, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str251, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str252, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str253, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str254, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str255, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str256, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str257, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str258, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str259, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str260, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str261, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str262, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str263, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str264, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str265, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str266, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str267, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str268, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str269, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str270, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str271, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str272, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str273, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str274, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str275, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str276, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str277, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str278, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str279, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str280, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str281, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str282, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str283, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str284, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str285, 2, "((");
Clo g_heff_2ecompile_2eemitc_2eintU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eintU_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eintU(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str0), v_vs_242);
  }
  case TAG_OpSub: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str1), v_vs_242);
  }
  case TAG_OpMul: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str2), v_vs_242);
  }
  case TAG_OpDiv: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str3), v_t_243);
    V v_t_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_242, 0);
      V v_xs_246 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str5); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str6), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eintU_str7)));
    return heff_strAppend(v_f_244, v_t_248);
  }
  case TAG_OpRem: {
    V v_t_249 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str8), v_t_249);
    V v_t_2413;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_242, 0);
      V v_xs_2412 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str10); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str11), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eintU_str12)));
    return heff_strAppend(v_f_2410, v_t_2414);
  }
  case TAG_OpEq: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2416;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str13);
      break;
    }
    case TAG_OpSub: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str14);
      break;
    }
    case TAG_OpMul: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str15);
      break;
    }
    case TAG_OpDiv: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str16);
      break;
    }
    case TAG_OpRem: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str17);
      break;
    }
    case TAG_OpEq: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str18);
      break;
    }
    case TAG_OpLt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str19);
      break;
    }
    case TAG_OpLe: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str20);
      break;
    }
    case TAG_OpAnd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str21);
      break;
    }
    case TAG_OpOr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str22);
      break;
    }
    case TAG_OpXor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str23);
      break;
    }
    case TAG_OpShl: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str24);
      break;
    }
    case TAG_OpShr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str25);
      break;
    }
    case TAG_OpShow: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str26);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str27);
      break;
    }
    case TAG_OpToInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str28);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str29);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str30);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str31);
      break;
    }
    case TAG_OpFloor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str32);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2416, v_vs_242));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str33), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2eintU_str34)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str35), heff_strAppend(v_t_2415, v_t_2418));
  }
  case TAG_OpLt: {
    V v_t_2419 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2420;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str36);
      break;
    }
    case TAG_OpSub: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str37);
      break;
    }
    case TAG_OpMul: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str38);
      break;
    }
    case TAG_OpDiv: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str39);
      break;
    }
    case TAG_OpRem: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str40);
      break;
    }
    case TAG_OpEq: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str41);
      break;
    }
    case TAG_OpLt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str42);
      break;
    }
    case TAG_OpLe: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str43);
      break;
    }
    case TAG_OpAnd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str44);
      break;
    }
    case TAG_OpOr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str45);
      break;
    }
    case TAG_OpXor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str46);
      break;
    }
    case TAG_OpShl: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str47);
      break;
    }
    case TAG_OpShr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str48);
      break;
    }
    case TAG_OpShow: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str49);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str50);
      break;
    }
    case TAG_OpToInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str51);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str52);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str53);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str54);
      break;
    }
    case TAG_OpFloor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str55);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2420, v_vs_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str56), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eintU_str57)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str58), heff_strAppend(v_t_2419, v_t_2422));
  }
  case TAG_OpLe: {
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2424;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str59);
      break;
    }
    case TAG_OpSub: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str60);
      break;
    }
    case TAG_OpMul: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str61);
      break;
    }
    case TAG_OpDiv: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str62);
      break;
    }
    case TAG_OpRem: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str63);
      break;
    }
    case TAG_OpEq: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str64);
      break;
    }
    case TAG_OpLt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str65);
      break;
    }
    case TAG_OpLe: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str66);
      break;
    }
    case TAG_OpAnd: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str67);
      break;
    }
    case TAG_OpOr: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str68);
      break;
    }
    case TAG_OpXor: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str69);
      break;
    }
    case TAG_OpShl: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str70);
      break;
    }
    case TAG_OpShr: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str71);
      break;
    }
    case TAG_OpShow: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str72);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str73);
      break;
    }
    case TAG_OpToInt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str74);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str75);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str76);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str77);
      break;
    }
    case TAG_OpFloor: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str78);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2424, v_vs_242));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str79), heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2eintU_str80)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str81), heff_strAppend(v_t_2423, v_t_2426));
  }
  case TAG_OpAnd: {
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2428;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str82);
      break;
    }
    case TAG_OpSub: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str83);
      break;
    }
    case TAG_OpMul: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str84);
      break;
    }
    case TAG_OpDiv: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str85);
      break;
    }
    case TAG_OpRem: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str86);
      break;
    }
    case TAG_OpEq: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str87);
      break;
    }
    case TAG_OpLt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str88);
      break;
    }
    case TAG_OpLe: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str89);
      break;
    }
    case TAG_OpAnd: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str90);
      break;
    }
    case TAG_OpOr: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str91);
      break;
    }
    case TAG_OpXor: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str92);
      break;
    }
    case TAG_OpShl: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str93);
      break;
    }
    case TAG_OpShr: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str94);
      break;
    }
    case TAG_OpShow: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str95);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str96);
      break;
    }
    case TAG_OpToInt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str97);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str98);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str99);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str100);
      break;
    }
    case TAG_OpFloor: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str101);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2429 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2428, v_vs_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str102), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2eintU_str103)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str104), heff_strAppend(v_t_2427, v_t_2430));
  }
  case TAG_OpOr: {
    V v_t_2431 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2432;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str105);
      break;
    }
    case TAG_OpSub: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str106);
      break;
    }
    case TAG_OpMul: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str107);
      break;
    }
    case TAG_OpDiv: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str108);
      break;
    }
    case TAG_OpRem: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str109);
      break;
    }
    case TAG_OpEq: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str110);
      break;
    }
    case TAG_OpLt: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str111);
      break;
    }
    case TAG_OpLe: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str112);
      break;
    }
    case TAG_OpAnd: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str113);
      break;
    }
    case TAG_OpOr: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str114);
      break;
    }
    case TAG_OpXor: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str115);
      break;
    }
    case TAG_OpShl: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str116);
      break;
    }
    case TAG_OpShr: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str117);
      break;
    }
    case TAG_OpShow: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str118);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str119);
      break;
    }
    case TAG_OpToInt: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str120);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str121);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str122);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str123);
      break;
    }
    case TAG_OpFloor: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str124);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2432, v_vs_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str125), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemitc_2eintU_str126)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str127), heff_strAppend(v_t_2431, v_t_2434));
  }
  case TAG_OpXor: {
    V v_t_2435 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2436;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str128);
      break;
    }
    case TAG_OpSub: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str129);
      break;
    }
    case TAG_OpMul: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str130);
      break;
    }
    case TAG_OpDiv: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str131);
      break;
    }
    case TAG_OpRem: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str132);
      break;
    }
    case TAG_OpEq: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str133);
      break;
    }
    case TAG_OpLt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str134);
      break;
    }
    case TAG_OpLe: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str135);
      break;
    }
    case TAG_OpAnd: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str136);
      break;
    }
    case TAG_OpOr: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str137);
      break;
    }
    case TAG_OpXor: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str138);
      break;
    }
    case TAG_OpShl: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str139);
      break;
    }
    case TAG_OpShr: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str140);
      break;
    }
    case TAG_OpShow: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str141);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str142);
      break;
    }
    case TAG_OpToInt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str143);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str144);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str145);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str146);
      break;
    }
    case TAG_OpFloor: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str147);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2437 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2436, v_vs_242));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str148), heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2eintU_str149)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str150), heff_strAppend(v_t_2435, v_t_2438));
  }
  case TAG_OpShl: {
    V v_t_2439 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str151), v_t_2439);
    V v_t_2443;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str152);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_vs_242, 0);
      V v_xs_2442 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str153); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str154), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2eintU_str155)));
    return heff_strAppend(v_f_2440, v_t_2444);
  }
  case TAG_OpShr: {
    V v_t_2445 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str156), v_t_2445);
    V v_t_2449;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str157);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_vs_242, 0);
      V v_xs_2448 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_2449 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str158); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str159), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemitc_2eintU_str160)));
    return heff_strAppend(v_f_2446, v_t_2450);
  }
  case TAG_OpShow: {
    V v_t_2451 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2452;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str161);
      break;
    }
    case TAG_OpSub: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str162);
      break;
    }
    case TAG_OpMul: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str163);
      break;
    }
    case TAG_OpDiv: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str164);
      break;
    }
    case TAG_OpRem: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str165);
      break;
    }
    case TAG_OpEq: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str166);
      break;
    }
    case TAG_OpLt: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str167);
      break;
    }
    case TAG_OpLe: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str168);
      break;
    }
    case TAG_OpAnd: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str169);
      break;
    }
    case TAG_OpOr: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str170);
      break;
    }
    case TAG_OpXor: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str171);
      break;
    }
    case TAG_OpShl: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str172);
      break;
    }
    case TAG_OpShr: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str173);
      break;
    }
    case TAG_OpShow: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str174);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str175);
      break;
    }
    case TAG_OpToInt: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str176);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str177);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str178);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str179);
      break;
    }
    case TAG_OpFloor: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str180);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2453 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2452, v_vs_242));
    V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str181), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eemitc_2eintU_str182)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str183), heff_strAppend(v_t_2451, v_t_2454));
  }
  case TAG_OpFromInt: {
    V v_t_2455 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str184), v_t_2455);
    V v_t_2459;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2459 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str185);
      break;
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_vs_242, 0);
      V v_xs_2458 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_2459 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str186); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str187), heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemitc_2eintU_str188)));
    return heff_strAppend(v_f_2456, v_t_2460);
  }
  case TAG_OpToInt: {
    V v_t_2461 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str189), v_t_2461);
    V v_t_2465;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str190);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_vs_242, 0);
      V v_xs_2464 = heff_field(v_vs_242, 1);
      heff_take_n(v_vs_242, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str191); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str192), heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eemitc_2eintU_str193)));
    return heff_strAppend(v_f_2462, v_t_2466);
  }
  case TAG_OpSqrt: {
    V v_t_2467 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2468;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str194);
      break;
    }
    case TAG_OpSub: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str195);
      break;
    }
    case TAG_OpMul: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str196);
      break;
    }
    case TAG_OpDiv: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str197);
      break;
    }
    case TAG_OpRem: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str198);
      break;
    }
    case TAG_OpEq: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str199);
      break;
    }
    case TAG_OpLt: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str200);
      break;
    }
    case TAG_OpLe: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str201);
      break;
    }
    case TAG_OpAnd: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str202);
      break;
    }
    case TAG_OpOr: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str203);
      break;
    }
    case TAG_OpXor: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str204);
      break;
    }
    case TAG_OpShl: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str205);
      break;
    }
    case TAG_OpShr: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str206);
      break;
    }
    case TAG_OpShow: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str207);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str208);
      break;
    }
    case TAG_OpToInt: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str209);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str210);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str211);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str212);
      break;
    }
    case TAG_OpFloor: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str213);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2469 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2468, v_vs_242));
    V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str214), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemitc_2eintU_str215)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str216), heff_strAppend(v_t_2467, v_t_2470));
  }
  case TAG_OpFromFloat: {
    V v_t_2471 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2472;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str217);
      break;
    }
    case TAG_OpSub: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str218);
      break;
    }
    case TAG_OpMul: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str219);
      break;
    }
    case TAG_OpDiv: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str220);
      break;
    }
    case TAG_OpRem: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str221);
      break;
    }
    case TAG_OpEq: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str222);
      break;
    }
    case TAG_OpLt: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str223);
      break;
    }
    case TAG_OpLe: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str224);
      break;
    }
    case TAG_OpAnd: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str225);
      break;
    }
    case TAG_OpOr: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str226);
      break;
    }
    case TAG_OpXor: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str227);
      break;
    }
    case TAG_OpShl: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str228);
      break;
    }
    case TAG_OpShr: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str229);
      break;
    }
    case TAG_OpShow: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str230);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str231);
      break;
    }
    case TAG_OpToInt: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str232);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str233);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str234);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str235);
      break;
    }
    case TAG_OpFloor: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str236);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2473 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2472, v_vs_242));
    V v_t_2474 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str237), heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemitc_2eintU_str238)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str239), heff_strAppend(v_t_2471, v_t_2474));
  }
  case TAG_OpToFloat: {
    V v_t_2475 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2476;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str240);
      break;
    }
    case TAG_OpSub: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str241);
      break;
    }
    case TAG_OpMul: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str242);
      break;
    }
    case TAG_OpDiv: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str243);
      break;
    }
    case TAG_OpRem: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str244);
      break;
    }
    case TAG_OpEq: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str245);
      break;
    }
    case TAG_OpLt: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str246);
      break;
    }
    case TAG_OpLe: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str247);
      break;
    }
    case TAG_OpAnd: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str248);
      break;
    }
    case TAG_OpOr: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str249);
      break;
    }
    case TAG_OpXor: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str250);
      break;
    }
    case TAG_OpShl: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str251);
      break;
    }
    case TAG_OpShr: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str252);
      break;
    }
    case TAG_OpShow: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str253);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str254);
      break;
    }
    case TAG_OpToInt: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str255);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str256);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str257);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str258);
      break;
    }
    case TAG_OpFloor: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str259);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2477 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2476, v_vs_242));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str260), heff_strAppend(v_t_2477, ((V)&g_heff_2ecompile_2eemitc_2eintU_str261)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str262), heff_strAppend(v_t_2475, v_t_2478));
  }
  case TAG_OpFloor: {
    V v_t_2479 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2480;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str263);
      break;
    }
    case TAG_OpSub: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str264);
      break;
    }
    case TAG_OpMul: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str265);
      break;
    }
    case TAG_OpDiv: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str266);
      break;
    }
    case TAG_OpRem: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str267);
      break;
    }
    case TAG_OpEq: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str268);
      break;
    }
    case TAG_OpLt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str269);
      break;
    }
    case TAG_OpLe: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str270);
      break;
    }
    case TAG_OpAnd: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str271);
      break;
    }
    case TAG_OpOr: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str272);
      break;
    }
    case TAG_OpXor: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str273);
      break;
    }
    case TAG_OpShl: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str274);
      break;
    }
    case TAG_OpShr: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str275);
      break;
    }
    case TAG_OpShow: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str276);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str277);
      break;
    }
    case TAG_OpToInt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str278);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str279);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str280);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str281);
      break;
    }
    case TAG_OpFloor: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str282);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2481 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2480, v_vs_242));
    V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str283), heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemitc_2eintU_str284)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str285), heff_strAppend(v_t_2479, v_t_2482));
  }
  default: return heff_nomatch(v_op_241);
  }
}
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eintU(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str0, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str1, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str2, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str3, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str4, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str5, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str6, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str7, 7, "MK_INT(");
Clo g_heff_2ecompile_2eemitc_2efixedLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efixedLit(V v_w_240, V v_n_241) {
top: ;
  V v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
    if (heff_intLt_c(heff_dup(v_n_241), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_241))) {
        V v_t_246 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str0));
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str1), v_t_246);
      } else {
        V v_t_247 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str2));
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str3), v_t_247);
      }
    } else {
      V v_t_248 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str4));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str5), v_t_248);
    }
  } else {
    V v_t_249 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str6));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str7), v_t_249);
  }
}
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedLit(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallLent_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallLent(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_args_244, v_t_246));
  V v_m_2415 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam0, 1, 1, (V[]){v_k_240}), v_t_247));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam1, 1, 4, (V[]){v_m_2415, v_g_241, heff_dup(v_tr_242), heff_dup(v_w_243)});
}
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallLent(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_248, 1));
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  return (g_heff_2ecompile_2eemitc_2eargC(v_k_240, v_t_2411, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_tr_242 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_x_2420 = ({ V a_0 = v_g_241; V a_1 = v_tr_242; V a_2 = v_w_243; V a_3 = v_x_2418; V r_ = (g_heff_2ecompile_2eemitc_2ecallBound(a_0, a_1, a_2, a_3)); heff_drop(v_tr_242); heff_drop(v_w_243); r_; });
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str2, 2, "))");
V g_heff_2ecompile_2eemitc_2ecallC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallC_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallC(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2eall_24s1359914687x262073401(v_args_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2emap_24s1661823642x1450093706(v_args_244));
    V v_m_247 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_t_246));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallC_lam0, 1, 4, (V[]){v_m_247, v_g_241, heff_dup(v_tr_242), heff_dup(v_w_243)});
  } else {
    heff_drop(v_t_245);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecallLent(v_k_240, v_g_241, v_tr_242, v_w_243, v_args_244);
  }
}
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallC(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallC_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_tr_242 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_g_241; V a_1 = v_tr_242; V a_2 = v_w_243; V r_ = (g_heff_2ecompile_2eemitc_2ecallHead(a_0, a_1, a_2)); heff_drop(v_tr_242); heff_drop(v_w_243); r_; });
    V v_t_2415;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x_2410, 0);
      V v_xs_2414 = heff_field(v_x_2410, 1);
      heff_take_n(v_x_2410, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_x_2416 = heff_strAppend(v_t_2412, heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2ecallC_str2)));
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str0, 5, "V rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str2, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str6, 17, "heff_rfield(rr_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str7, 7, ") = rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str8, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str11, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str12, 7, "rr_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str15, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str16, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str18, 26, "V rr_ = heff_rec_reuse_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str19, 3, "({ ");
Clo g_heff_2ecompile_2eemitc_2eupdateText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eupdateText_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2eupdateText(V v_x_240, V v_shape_241, V v_keep_242, V v_flats_243, V v_n_244, V v_vs_245, V v_changed_246) {
top: ;
  V v_x2_247 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str0), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str1), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str2), v_vs_245, heff_dup(v_changed_246)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str5)));
  V v_x2_2412 = (g_list_2emap_24s1785262601x1752264566(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str6), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str7), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str8), v_changed_246));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str10); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str11), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str12)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str13), heff_strAppend(v_flats_243, v_t_2416));
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str14), heff_strAppend(v_shape_241, v_t_2417));
  V v_t_2419 = heff_strAppend(heff_intShow(v_n_244), v_t_2418);
  V v_t_2420 = heff_strAppend(heff_intShow(v_keep_242), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str15), v_t_2419));
  V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str16), v_t_2411), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str17), v_t_2420));
  V v_t_2422 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str18), v_t_2421));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str19), v_t_2422);
}
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eupdateText(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str2, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str6, 9, "static V ");
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ewrapperCode_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperCode_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperCode_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapperCode(V v_key_240, V v_rs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_key_240);
    return ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_lam0_clo);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkWrapper: {
      V v_ws_245 = heff_field(v_x31_244, 0);
      V v_body_246 = heff_field(v_x31_244, 1);
      V v_t_247 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_241));
      V v_m_248 = heff_tr(heff_call(heff_get_n(v_t_247, 1, 3), 1, (V[]){heff_dup(v_body_246)}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2ewrapperCode_lam1, 1, 4, (V[]){v_m_248, v_key_240, heff_dup(v_rs_241), heff_dup(v_ws_245)});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapperCode(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_rs_241 = heff_env(self)[2];
  V v_ws_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str0)));
    V v_t_2414 = ({ V a_0 = v_rs_241; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0)); heff_drop(v_rs_241); r_; });
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2414, v_ws_245));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str1), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str2)));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str3), v_t_2413), v_t_2416);
    V v_t_2418 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str4), NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2e_2b_2b_24f1280198663x1762821176(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str5), v_x_2411));
    V v_x_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str6), v_t_2417), v_t_2419});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_x_242, NTAG(TAG_MkUnit), v_seen_240));
      V v_u_247 = (g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(v_t_246, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_247);
      return v_cell_245;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonceInOrder(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str2, 2, ".c");
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulePart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulePart_entry, 9, 0};

V g_heff_2ecompile_2eemitc_2emodulePart(V v_head_240, V v_ce_241, V v_s_242, V v_shapes_243, V v_prims_244, V v_strs_245, V v_protos_246, V v_lams_247, V v_x9_248) {
top: ;
  switch (heff_tag_of(v_x9_248)) {
  case TAG_MkPair: {
    V v_m_249 = heff_field(v_x9_248, 0);
    V v_ps_2410 = heff_field(v_x9_248, 1);
    V v_ru_24x9_248_24MkPair = heff_take_reuse_n(v_x9_248, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x9_248_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2412 = (g_list_2efoldl_24f891411706x655200538(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_t_2413 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2eusedBy(v_shapes_243, heff_dup(v_ps_2410)));
    V v_t_2416 = (g_list_2emap_24s2073083146x1445066245(v_t_2415));
    V v_xs_2417 = (g_heff_2ecompile_2eemitc_2eusedBy(v_prims_244, heff_dup(v_ps_2410)));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
    V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_xs_2421 = (g_list_2efoldl_24s1732572494x729779974(NTAG(TAG_Nil), v_t_2420));
    V v_m_2422 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2421; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2421); r_; });
    V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2423));
    V v_t_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam0, 2, 1, (V[]){v_ce_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
    V v_t_2433 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam1, 2, 4, (V[]){heff_dup(v_s_242), heff_dup(v_strs_245), heff_dup(v_protos_246), heff_dup(v_lams_247)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2429; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
    V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2433));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2434));
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2435));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2436));
    V v_x2_2438 = (g_prelude_2e_2b_2b(v_head_240, v_t_2437));
    V v_t_2441;
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_Nil: {
      v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2439 = heff_field(v_x2_2438, 0);
      V v_xs_2440 = heff_field(v_x2_2438, 1);
      heff_take_n(v_x2_2438, 3ULL, 2);
      v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str1); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2438);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_249, ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str2)), v_t_2441});
  }
  default: return heff_nomatch(v_x9_248);
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_heff_2ecompile_2eemitc_2emodulePart(a[0], a[1], a2, a3, a4, a5, a6, a7, a[8]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = (g_heff_2ecompile_2eemitc_2edeclOf(v_ce_241, v_x_2426));
  return (g_prelude_2e_2b_2b(v_t_2427, v_acc_2425));
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_x_2431 = args[1];
  V v_s_242 = heff_env(self)[0];
  V v_strs_245 = heff_env(self)[1];
  V v_protos_246 = heff_env(self)[2];
  V v_lams_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = ({ V a_0 = v_s_242; V a_1 = v_strs_245; V a_2 = v_protos_246; V a_3 = v_lams_247; V a_4 = v_x_2431; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_242); heff_drop(v_strs_245); heff_drop(v_protos_246); heff_drop(v_lams_247); heff_drop(v_x_2431); r_; });
  return (g_prelude_2e_2b_2b(v_t_2432, v_acc_2430));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str1, 25, "V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str4, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str5, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str6, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str9, 6, "heff.h");
Clo g_heff_2ecompile_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_246 = heff_field(v_x6_245, 0);
    V v_s_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x6_245_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str1), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ending_242, 0), heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_t_249})));
    V v_x2_2411 = (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str4); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; V r_ = (g_list_2efoldl_24s1414103338x1084960320(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str5); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_list_2efoldl_24s1414103338x1084960320(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = ({ V a_0 = heff_dup(v_ce_244); V b_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_t_2418}); V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2420 = (g_heff_2ecompile_2eemitc_2edeclOf(heff_dup(v_ce_244), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get())));
    V v_t_2421 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2422 = heff_tr(heff_call(heff_get_n(v_ending_242, 1, 2), 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2425));
    V v_x2_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str6), v_t_2426});
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str8); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2431 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 5))));
    V v_t_2432 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 3))));
    V v_t_2433 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 2))));
    V v_t_2434 = (g_heff_2ecompile_2eemitc_2emodulesParts(v_ce_244, v_s_247, v_t_2431, v_t_2432, v_t_2433, v_defs_243, v_ems_246));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eentryPart_get()), v_t_2430}), v_t_2434});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str9), v_t_2414}), v_t_2435});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2eemitc_2ekeptPartsCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2ekeptPartsCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_kept_243, V v_lk_244, V v_ce_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_acc_247 = ({ V a_0 = heff_dup(v_ce_245); V a_1 = v_kept_243; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2eemitc_2edefsKept(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_247, 0)));
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_take_field(v_acc_247, 1)});
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2epartsWith(v_runtime_240, v_provs_241, v_ending_242, v_t_248, v_ce_245, v_t_2410));
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 2, 3);
  return heff_rec_n(5, shape_parts__errors__groups__copies__emits, (V[]){v_t_2411, v_t_2412, heff_dup(heff_rfield(v_lk_244, 1)), heff_get_n(v_lk_244, 2, 3), heff_get_n(v_acc_247, 2, 3)});
}
V g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ekeptPartsCE(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptParts_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ekeptParts(V v_runtime_240, V v_provs_241, V v_eff_242, V v_kept_243, V v_lk_244) {
top: ;
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){v_eff_242}));
  V v_t_246 = heff_rec_n(2, shape_prefix__end, (V[]){NTAG(TAG_Nil), v_t_245});
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 1, 3);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_t_2410 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), v_t_249));
  V v_t_2411 = (g_list_2efoldl_24s1659194469x1936830512(v_t_248, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_t_247; V a_2 = v_t_2411; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  return (g_heff_2ecompile_2eemitc_2ekeptPartsCE(v_runtime_240, v_provs_241, v_t_246, v_kept_243, v_lk_244, v_t_2412));
}
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ekeptParts(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(a[0], a[1]);
}