// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DoneOrErrno 39355
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FlatAll 51900
#define TAG_FlatNone 33150
#define TAG_FlatSome 51022
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Leaf 13717
#define TAG_MkCArm 24694
#define TAG_MkWrapper 39179
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_includes 835398315
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_leaf 9813029
#define LBL_lent 9813446
#define LBL_module 878357911
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tag 324116
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_wrapper 1827365593
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2eargLine(V, V);
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLine_clo;
V g_heff_2ecompile_2eemitc_2eargLines(V, V);
V g_heff_2ecompile_2eemitc_2eargLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_clo;
V g_heff_2ecompile_2eemitc_2eargLines_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2eassertLine(V, V);
V g_heff_2ecompile_2eemitc_2eassertLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eassertLine_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2ecaseLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecaseLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecaseLines_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2econvOf(V, V, V);
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econvOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2eglueProvider(V);
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo;
V g_heff_2ecompile_2eemitc_2ehelperLines(V, V);
V g_heff_2ecompile_2eemitc_2ehelperLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehelperLines_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(V, V, V);
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2epointersGo(V, V);
V g_heff_2ecompile_2eemitc_2epointersGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointersGo_clo;
V g_heff_2ecompile_2eemitc_2eprimCloOf(V);
V g_heff_2ecompile_2eemitc_2eprimCloOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloOf_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2eresultLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultLines_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etupleArm(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleArm_clo;
V g_heff_2ecompile_2eemitc_2etupleDecl(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2eemitc_2ewordAs(V, V);
V g_heff_2ecompile_2eemitc_2ewordAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewordAs_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2eowned_2elendingPrim(V);
V g_heff_2ecompile_2eowned_2elendingPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elendingPrim_clo;
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eprimitive_2eprimArity(V);
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimArity_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_intShow_get(void);
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eany_24s1606644238x788321190(V, V);
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a);
extern Clo g_list_2eany_24s1606644238x788321190_clo;
V g_list_2eany_24s280395686x983781620(V);
V g_list_2eany_24s280395686x983781620_entry(V self, V *a);
extern Clo g_list_2eany_24s280395686x983781620_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1323813142x1311067101(V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1323813142x1311067101_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24s1071292119x112543158(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1071292119x112543158_clo;
V g_list_2efoldl_24s1325692678x1256705229(V, V);
V g_list_2efoldl_24s1325692678x1256705229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325692678x1256705229_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1520027297x1040032870(V, V);
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1520027297x1040032870_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s949876182x1887521458(V);
V g_list_2ekeepIf_24s949876182x1887521458_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s949876182x1887521458_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24f230958709x841260712(V, V, V, V, V, V);
V g_list_2emap_24f230958709x841260712_entry(V self, V *a);
extern Clo g_list_2emap_24f230958709x841260712_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1566016224x493905666(V, V, V, V);
V g_list_2emap_24s1566016224x493905666_entry(V self, V *a);
extern Clo g_list_2emap_24s1566016224x493905666_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2010608108x1221393166(V);
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s379205986x2089287346(V, V, V, V, V, V, V, V);
V g_list_2emap_24s379205986x2089287346_entry(V self, V *a);
extern Clo g_list_2emap_24s379205986x2089287346_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s430074199x1834682414(V, V, V, V);
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s693155583x821663253(V, V, V);
V g_list_2emap_24s693155583x821663253_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159(V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str0, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str2, 1, "_");
Clo g_heff_2ecompile_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2emangleChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((((((int64_t)97ULL) <= v_c_240) && (v_c_240 <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))))) {
    return heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_240))));
  } else {
    int64_t v_d_241 = (heff_word_mod(v_c_240, ((int64_t)256ULL)) / ((int64_t)16ULL));
    V v_t_242 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str0), heff_box_word(v_d_241), heff_box_word((v_d_241 + ((int64_t)1ULL))));
    int64_t v_d_243 = heff_word_mod(v_c_240, ((int64_t)16ULL));
    V v_t_244 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str1), heff_box_word(v_d_243), heff_box_word((v_d_243 + ((int64_t)1ULL))));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str2), v_t_242), v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleChar(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagsLbls_str0, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagsLbls_str1, 4, "True");
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_argv_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_argv_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return (g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(v_a_2410, v_b_2411, ((V)&g_heff_2ecompile_2eemitc_2etagsLbls_clo)));
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2414 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2412)));
    V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2416 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2412));
    V v_x2_2417 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2415, v_t_2416));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_ts_2418 = heff_field(v_x2_2417, 0);
      V v_ls2_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      V v_t_2420 = (g_prelude_2e_2b_2b(v_ls_2414, v_ls2_2419));
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2418, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  case TAG_EProj: {
    V v_e_2421 = heff_field(v_x1_240, 0);
    V v_l_2422 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2425 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2421));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_ts_2426 = heff_field(v_x2_2425, 0);
      V v_ls2_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_l_2422, v_ls2_2427})});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  case TAG_ETag: {
    V v_t_2428 = heff_field(v_x1_240, 0);
    V v_argv_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2429));
    V v_x2_2433 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2431, v_t_2432));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_ts2_2434 = heff_field(v_x2_2433, 0);
      V v_ls_2435 = heff_field(v_x2_2433, 1);
      V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
      V v_t_2436;
      if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2428, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2428, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)) {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_t_2428);
        v_t_2436 = NTAG(TAG_Nil);
      }
      V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2436, v_ts2_2434));
      return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_ls_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2438 = heff_field(v_x1_240, 0);
    V v_arms_2439 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2440 = (g_list_2ekeepIf_24s949876182x1887521458(heff_dup(v_arms_2439)));
    V v_ts_2441 = (g_list_2emap_24s1009200955x251267316(v_t_2440));
    V v_t_2442 = (g_list_2emap_24s60612435x257154841(v_arms_2439));
    V v_es_2443 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2438, v_t_2442});
    V v_t_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2443));
    V v_x2_2446 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2444, v_t_2445));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_ts2_2447 = heff_field(v_x2_2446, 0);
      V v_ls_2448 = heff_field(v_x2_2446, 1);
      V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
      V v_t_2449 = ({ V a_0 = v_ts2_2447; V a_1 = MK_INT(0LL); V b_2 = MK_INT(0LL); V a_3 = MK_INT(35LL); V a_4 = v_ts_2441; V r_ = (g_prelude_2e_2b_2b_24f292729551x60683815(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){v_t_2449, v_ls_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_argv_2452 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2453 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2452));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2453, v_t_2454));
  }
  case TAG_ECall: {
    V v_argv_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2457 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2456));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2457, v_t_2458));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_es_2467 = ({ V a_0 = v_c_2466; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2466); r_; });
    V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2467));
    V v_x2_2470 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2468, v_t_2469));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_ts2_2471 = heff_field(v_x2_2470, 0);
      V v_ls_2472 = heff_field(v_x2_2470, 1);
      V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
      V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etagsLbls_str0), NTAG(TAG_Nil)});
      V v_t_2474 = ({ V a_0 = v_ts2_2471; V a_1 = MK_INT(0LL); V b_2 = MK_INT(0LL); V a_3 = MK_INT(35LL); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etagsLbls_str1), v_t_2473}); V r_ = (g_prelude_2e_2b_2b_24f292729551x60683815(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){v_t_2474, v_ls_2472});
    }
    default: return heff_nomatch(v_x2_2470);
    }
  }
  case TAG_ESet: {
    V v_a_2476 = heff_field(v_x1_240, 1);
    V v_b_2477 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return (g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(v_a_2476, v_b_2477, ((V)&g_heff_2ecompile_2eemitc_2etagsLbls_clo)));
  }
  case TAG_EValues: {
    V v_es_2478 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2479 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2478));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2479, v_t_2480));
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_242), heff_strLength_lent(v_text_240, 0)) && ({ V v_c_243 = heff_strByteAt_lent(v_text_240, v_i_242, 0); int c_ = ((((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))))) || (heff_unbox_word(heff_strByteAt_lent(v_text_240, v_i_242, 0)) == ((int64_t)95ULL))); heff_drop(v_c_243); c_; }))) {
    V t_0 = v_text_240;
    V t_1 = v_start_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    v_text_240 = t_0;
    v_start_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    return heff_strSlice_lent(v_text_240, v_start_241, v_i_242, 4);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eidentAt(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength_lent(v_text_241, 0));
  V v_j_245 = heff_strFind_lent(v_pre_240, v_t_244, MK_INT(0LL), 6);
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_i_242);
    heff_drop(v_j_245);
    return v_acc_243;
  } else {
    V v_t_246 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_245)), heff_strLength_lent(v_pre_240, 0));
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_245)), heff_strLength_lent(v_pre_240, 0));
    V v_t_248 = heff_intAdd(heff_intAdd(v_i_242, v_j_245), heff_strLength_lent(v_pre_240, 0));
    V v_t_249 = ({ V a_0 = v_text_241; V a_1 = v_t_247; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eemitc_2eidentAt(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_246;
    V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesInGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str0, 2, "\\\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str1, 2, "\\\\");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str2, 2, "\\\?");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str3, 1, "\\");
Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecBytesGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecBytesGo(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    heff_drop(v_s_240);
    return v_acc_242;
  } else {
    V v_s_243 = heff_dup(v_s_240);
    int64_t v_i_244 = v_i_241;
    V v_b_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    V v_t_2410;
    if ((heff_peek_word(v_b_245) == ((int64_t)34ULL))) {
      heff_drop(v_s_243);
      heff_drop(v_b_245);
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str0);
    } else {
      if ((heff_peek_word(v_b_245) == ((int64_t)92ULL))) {
        heff_drop(v_s_243);
        heff_drop(v_b_245);
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str1);
      } else {
        if ((heff_peek_word(v_b_245) == ((int64_t)63ULL))) {
          heff_drop(v_s_243);
          heff_drop(v_b_245);
          v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str2);
        } else {
          if (((((int64_t)32ULL) <= heff_peek_word(v_b_245)) && (heff_peek_word(v_b_245) < ((int64_t)127ULL)))) {
            heff_drop(v_b_245);
            v_t_2410 = heff_strSlice(v_s_243, heff_box_word(v_i_244), heff_box_word((v_i_244 + ((int64_t)1ULL))));
          } else {
            heff_drop(v_s_243);
            V v_t_246 = heff_intShow(heff_box_word(heff_word_div(heff_peek_word(v_b_245), ((int64_t)64ULL))));
            int64_t v_t_247 = heff_word_mod(heff_word_div(heff_peek_word(v_b_245), ((int64_t)8ULL)), ((int64_t)8ULL));
            V v_t_248 = heff_strAppend(v_t_246, heff_intShow(heff_box_word(v_t_247)));
            V v_t_249 = heff_intShow(heff_box_word(heff_word_mod(heff_unbox_word(v_b_245), ((int64_t)8ULL))));
            v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str3), heff_strAppend(v_t_248, v_t_249));
          }
        }
      }
    }
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_2410);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecBytesGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 1, ")");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_dup(heff_rfield(v_s_242, 0)));
  V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_245 = heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str1)), v_t_244);
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str2));
  V v_t_248 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_249 = heff_strAppend(heff_strAppend(v_mac_240, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3)), heff_strAppend(v_t_247, v_t_248));
  V v_t_2410 = heff_intShow(heff_strLength_lent(v_str_241, 0));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str4)), v_t_2410);
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str6)), v_t_2412);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str7))});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_246; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str8)), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str0, 10, "((V)&prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str1, 5, "_clo)");
Clo g_heff_2ecompile_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimLit_str0), v_t_242), ((V)&g_heff_2ecompile_2eemitc_2eprimLit_str1));
  V v_o_244 = heff_dup(heff_rfield(v_s_241, 0));
  V v_k_245 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
  V v_ps_246 = heff_take_field(v_s_241, 7);
  V v_t_247 = (g_heff_2ecompile_2eemitc_2eownHas(v_o_244, v_k_245, v_ps_246));
  V v_t_248;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_o_244);
    heff_drop(v_k_245);
    heff_drop(v_t_247);
    v_t_248 = v_ps_246;
  } else {
    heff_drop(v_t_247);
    v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_244, v_k_245}), v_ps_246});
  }
  V v_t_249 = ({ V rv_7 = v_t_248; V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_249});
}
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eprimLit(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eaddLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eaddLam_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_def_241});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_take_field(v_s_242, 2)});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_proto_240});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_take_field(v_s_242, 3)});
  V v_t_247 = ({ V rv_2 = v_t_244; V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 243ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65295u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eaddLam(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str0, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str1, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str2, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str3, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str4, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str5, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str6, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str7, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str8, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str9, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str10, 2, "_t");
Clo g_heff_2ecompile_2eemitc_2efixedType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedType_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedType(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedType_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_244 = heff_strAppend(v_t_242, heff_intShow(v_t_243));
    return heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2efixedType_str10));
  }
}
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedType(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str3, 9, "heff_div_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str8, 9, "heff_rem_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str13, 9, "heff_shl_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str18, 9, "heff_shr_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str23, 14, "heff_from_int_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str25, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str28, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str30, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str31, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str32, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str33, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str35, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str36, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str37, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str38, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str40, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str41, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str42, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str43, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str44, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str45, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str46, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str47, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str48, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str54, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str57, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str58, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str59, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str60, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str61, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eintU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eintU_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eintU(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str0), v_vs_242);
  }
  case TAG_OpSub: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str1), v_vs_242);
  }
  case TAG_OpMul: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str2), v_vs_242);
  }
  case TAG_OpDiv: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str3), v_t_243);
    V v_t_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_242, 0);
      V v_xs_246 = heff_field(v_vs_242, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str5), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_248 = heff_strAppend(heff_strAppend(v_f_244, ((V)&g_heff_2ecompile_2eemitc_2eintU_str6)), v_t_247);
    return heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eintU_str7));
  }
  case TAG_OpRem: {
    V v_t_249 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str8), v_t_249);
    V v_t_2413;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_242, 0);
      V v_xs_2412 = heff_field(v_vs_242, 1);
      v_t_2413 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str10), heff_dup(v_x_2411), v_xs_2412));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(v_f_2410, ((V)&g_heff_2ecompile_2eemitc_2eintU_str11)), v_t_2413);
    return heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eintU_str12));
  }
  case TAG_OpShl: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str13), v_t_2415);
    V v_t_2419;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_vs_242, 0);
      V v_xs_2418 = heff_field(v_vs_242, 1);
      v_t_2419 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str15), heff_dup(v_x_2417), v_xs_2418));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_f_2416, ((V)&g_heff_2ecompile_2eemitc_2eintU_str16)), v_t_2419);
    return heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2eintU_str17));
  }
  case TAG_OpShr: {
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str18), v_t_2421);
    V v_t_2425;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_vs_242, 0);
      V v_xs_2424 = heff_field(v_vs_242, 1);
      v_t_2425 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str20), heff_dup(v_x_2423), v_xs_2424));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2426 = heff_strAppend(heff_strAppend(v_f_2422, ((V)&g_heff_2ecompile_2eemitc_2eintU_str21)), v_t_2425);
    return heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eintU_str22));
  }
  case TAG_OpFromInt: {
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str23), v_t_2427);
    V v_t_2431;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str24);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_vs_242, 0);
      V v_xs_2430 = heff_field(v_vs_242, 1);
      v_t_2431 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str25), heff_dup(v_x_2429), v_xs_2430));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_f_2428, ((V)&g_heff_2ecompile_2eemitc_2eintU_str26)), v_t_2431);
    return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eintU_str27));
  }
  case TAG_OpToInt: {
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str28), v_t_2433);
    V v_t_2437;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str29);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_vs_242, 0);
      V v_xs_2436 = heff_field(v_vs_242, 1);
      v_t_2437 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str30), heff_dup(v_x_2435), v_xs_2436));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2438 = heff_strAppend(heff_strAppend(v_f_2434, ((V)&g_heff_2ecompile_2eemitc_2eintU_str31)), v_t_2437);
    return heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2eintU_str32));
  }
  default: {
    V v_t_2439 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str33), v_t_2439), ((V)&g_heff_2ecompile_2eemitc_2eintU_str34));
    V v_t_2443;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_vs_242, 0);
      v_t_2443 = heff_dup(v_x_2441);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str36), v_t_2443), ((V)&g_heff_2ecompile_2eemitc_2eintU_str37));
    V v_t_2445;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str38);
      break;
    }
    case TAG_OpSub: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str39);
      break;
    }
    case TAG_OpMul: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str40);
      break;
    }
    case TAG_OpDiv: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str41);
      break;
    }
    case TAG_OpRem: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str42);
      break;
    }
    case TAG_OpEq: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str43);
      break;
    }
    case TAG_OpLt: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str44);
      break;
    }
    case TAG_OpLe: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str45);
      break;
    }
    case TAG_OpAnd: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str46);
      break;
    }
    case TAG_OpOr: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str47);
      break;
    }
    case TAG_OpXor: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str48);
      break;
    }
    case TAG_OpShl: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str49);
      break;
    }
    case TAG_OpShr: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str50);
      break;
    }
    case TAG_OpShow: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str51);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str52);
      break;
    }
    case TAG_OpToInt: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str53);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str54);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str55);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str56);
      break;
    }
    case TAG_OpFloor: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str57);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2444, v_t_2445), ((V)&g_heff_2ecompile_2eemitc_2eintU_str58));
    HeffT3 v_t_2447 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2453;
    {
      V v_field_2449 = v_t_2447.f[1];
      V v_field_2450 = v_t_2447.f[2];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        V v_x_2451 = v_field_2449;
        V v_x12_2452 = v_field_2450;
        heff_drop(v_x12_2452);
        v_t_2453 = v_x_2451;
      } else {
        heff_drop(v_field_2449);
        heff_drop(v_field_2450);
        v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str59);
      }
    }
    V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2446, v_t_2453), ((V)&g_heff_2ecompile_2eemitc_2eintU_str60));
    return heff_strAppend(heff_strAppend(v_t_2440, v_t_2454), ((V)&g_heff_2ecompile_2eemitc_2eintU_str61));
  }
  }
}
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eintU(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str1, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str3, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str4, 7, "int64_t");
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallLent_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallLent(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_args_244, v_t_246));
  V v_m_2415 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam0, 1, 1, (V[]){heff_dup(v_k_240)}), v_t_247));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam1, 1, 5, (V[]){v_m_2415, v_k_240, heff_dup(v_g_241), heff_dup(v_w_243), heff_dup(v_tr_242)});
}
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallLent(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_248, 1));
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  return (g_heff_2ecompile_2eemitc_2eargC(v_k_240, v_t_2411, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  V v_tr_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_k_240, 3), v_g_241));
    V v_t_2432;
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      V v_t_2424;
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2422;
        v_t_2424 = v_x_2423;
      } else {
        heff_drop(v_field_2422);
        v_t_2424 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_2424)) {
        HeffT2 v_t_2425 = ({ V b_0 = heff_get_n(v_k_240, 3, 6); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          V v_t_2429;
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_x_2428 = v_field_2427;
            v_t_2429 = v_x_2428;
          } else {
            heff_drop(v_field_2427);
            v_t_2429 = MK_INT(0LL);
          }
          v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallLent_str0), heff_intShow(v_t_2429));
        }
      } else {
        heff_drop_rec(v_k_240, 6);
        switch (heff_tag_of(v_w_243)) {
        case TAG_Nothing: {
          v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str1);
          break;
        }
        case TAG_Just: {
          V v_r_2430 = heff_dup(heff_field(v_w_243, 0));
          switch (heff_tag_of(v_r_2430)) {
          case TAG_RepV: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str2);
            break;
          }
          case TAG_RepFix: {
            V v_w_2431 = heff_field(v_r_2430, 0);
            heff_take_n(v_r_2430, 1ULL, 1);
            v_t_2432 = ({ V a_0 = v_w_2431; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2431); r_; });
            break;
          }
          case TAG_RepF64: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str3);
            break;
          }
          case TAG_RepInt: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str4);
            break;
          }
          default: heff_nomatch(v_r_2430);
          }
          break;
        }
        default: heff_nomatch(v_w_243);
        }
      }
    }
    V v_x_2433 = ({ V a_0 = v_t_2432; V a_1 = v_g_241; V a_2 = v_tr_242; V a_3 = v_w_243; V a_4 = v_x_2418; V r_ = (g_heff_2ecompile_2eemitc_2ecallBound(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_241); heff_drop(v_tr_242); heff_drop(v_w_243); r_; });
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2433, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 2, "_c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 6, "c_; })");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eowned_2elendingPrim(v_p_244));
    V v_t_248;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eall_24s1465078656x604124530(v_es_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = (g_list_2eany_24s63755471x810534073(v_es_245, v_es_245));
      } else {
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_246);
      v_t_248 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return ({ V a_0 = v_k_240; V a_1 = v_p_244; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str2); V a_3 = v_es_245; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_p_244); r_; });
    } else {
      heff_drop(v_t_248);
      V v_m_249 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_245));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_249, v_p_244});
    }
  }
  case TAG_CondRelU: {
    V v_p_2420 = heff_field(v_x2_241, 0);
    V v_es_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2422 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_2421));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2422, v_p_2420});
  }
  case TAG_CondBool: {
    V v_e_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2449}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_CondNot: {
    V v_c_2456 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2457 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2456));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2457});
  }
  case TAG_CondIf: {
    V v_a_2462 = heff_field(v_x2_241, 0);
    V v_b_2463 = heff_field(v_x2_241, 1);
    V v_x23_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2464)) {
    case TAG_CondFalse: {
      V v_m_2465 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2462));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2465, v_k_240, v_b_2463});
    }
    default: {
      switch (heff_tag_of(v_b_2463)) {
      case TAG_CondTrue: {
        V v_m_2476 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2462));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 3, (V[]){v_m_2476, v_k_240, v_x23_2464});
      }
      default: {
        V v_m_2487 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2462));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2487, v_k_240, v_b_2463, v_x23_2464});
      }
      }
    }
    }
  }
  case TAG_CondLet: {
    V v_x_24103 = heff_field(v_x2_241, 0);
    V v_e_24104 = heff_field(v_x2_241, 1);
    V v_c_24105 = heff_field(v_x2_241, 2);
    V v_drops_24106 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_24104}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 5, (V[]){v_m_24107, v_k_240, v_c_24105, v_x_24103, v_drops_24106});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etestC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = ({ V a_0 = v_p_244; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_244); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str3), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2etestC_str4));
    V v_t_2418;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x_2412, 0);
      V v_xs_2417 = heff_field(v_x_2412, 1);
      heff_take_n(v_x_2412, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str6); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_x_2419 = heff_strAppend(heff_strAppend(v_t_2415, v_t_2418), ((V)&g_heff_2ecompile_2eemitc_2etestC_str7));
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_p_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_p_2427 = v_p_2420;
    V v_vs_2428 = v_x_2425;
    V v_u_2429 = (g_heff_2ecompile_2eemitc_2eunboxed(v_p_2427));
    V v_op_2435;
    switch (heff_tag_of(v_u_2429)) {
    case TAG_UFixed: {
      V v_op_2431 = heff_field(v_u_2429, 1);
      heff_take_n(v_u_2429, 2ULL, 2);
      switch (heff_tag_of(v_op_2431)) {
      case TAG_OpAdd: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str8);
        break;
      }
      case TAG_OpSub: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str9);
        break;
      }
      case TAG_OpMul: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str10);
        break;
      }
      case TAG_OpDiv: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str11);
        break;
      }
      case TAG_OpRem: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str12);
        break;
      }
      case TAG_OpEq: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str13);
        break;
      }
      case TAG_OpLt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str14);
        break;
      }
      case TAG_OpLe: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str15);
        break;
      }
      case TAG_OpAnd: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str16);
        break;
      }
      case TAG_OpOr: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str17);
        break;
      }
      case TAG_OpXor: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str18);
        break;
      }
      case TAG_OpShl: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str19);
        break;
      }
      case TAG_OpShr: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str20);
        break;
      }
      case TAG_OpShow: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str21);
        break;
      }
      case TAG_OpFromInt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str22);
        break;
      }
      case TAG_OpToInt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str23);
        break;
      }
      case TAG_OpSqrt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str24);
        break;
      }
      case TAG_OpFromFloat: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str25);
        break;
      }
      case TAG_OpToFloat: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str26);
        break;
      }
      case TAG_OpFloor: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str27);
        break;
      }
      default: heff_nomatch(v_op_2431);
      }
      break;
    }
    case TAG_URel: {
      V v_op_2432 = heff_field(v_u_2429, 0);
      heff_take_n(v_u_2429, 1ULL, 1);
      v_op_2435 = v_op_2432;
      break;
    }
    case TAG_UOp: {
      heff_take_n(v_u_2429, 0ULL, 1);
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str28);
      break;
    }
    case TAG_UFn: {
      heff_take_n(v_u_2429, 0ULL, 1);
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str29);
      break;
    }
    case TAG_UToDouble: {
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str30);
      break;
    }
    default: heff_nomatch(v_u_2429);
    }
    V v_t_2438;
    switch (heff_tag_of(v_vs_2428)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_dup(heff_field(v_vs_2428, 0));
      v_t_2438 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_vs_2428);
    }
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str32), v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2etestC_str33));
    V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, v_op_2435), ((V)&g_heff_2ecompile_2eemitc_2etestC_str34));
    HeffT3 v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = v_vs_2428; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_2428); r_; });
    V v_t_2447;
    {
      V v_field_2443 = v_t_2441.f[1];
      V v_field_2444 = v_t_2441.f[2];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        V v_x_2445 = v_field_2443;
        V v_x12_2446 = v_field_2444;
        heff_drop(v_x12_2446);
        v_t_2447 = v_x_2445;
      } else {
        heff_drop(v_field_2443);
        heff_drop(v_field_2444);
        v_t_2447 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str35);
      }
    }
    V v_x_2448 = heff_strAppend(heff_strAppend(v_t_2440, v_t_2447), ((V)&g_heff_2ecompile_2eemitc_2etestC_str36));
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2448, v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), v_x_2453), ((V)&g_heff_2ecompile_2eemitc_2etestC_str38));
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){v_t_2455, v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str39), v_x_2460), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_m_2470 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2463));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_s_2469}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), v_x_2468), ((V)&g_heff_2ecompile_2eemitc_2etestC_str41));
      V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2474, v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2etestC_str42));
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){v_t_2475, v_s_2473});
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_m_2481 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2464));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2480}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      heff_take_n(v_x2_2482, 3ULL, 2);
      V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str43), v_x_2479), ((V)&g_heff_2ecompile_2eemitc_2etestC_str44));
      V v_t_2486 = heff_strAppend(heff_strAppend(v_t_2485, v_x_2483), ((V)&g_heff_2ecompile_2eemitc_2etestC_str45));
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){v_t_2486, v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2463 = heff_env(self)[2];
  V v_x23_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_m_2492 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2463));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_s_2491}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_s_2495 = heff_field(v_x2_2493, 1);
      heff_take_n(v_x2_2493, 3ULL, 2);
      V v_m_2496 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2464));
      V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2495}));
      switch (heff_tag_of(v_x2_2497)) {
      case TAG_MkPair: {
        V v_x_2498 = heff_field(v_x2_2497, 0);
        V v_s_2499 = heff_field(v_x2_2497, 1);
        heff_take_n(v_x2_2497, 3ULL, 2);
        V v_t_24100 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str46), v_x_2490), ((V)&g_heff_2ecompile_2eemitc_2etestC_str47));
        V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, v_x_2494), ((V)&g_heff_2ecompile_2eemitc_2etestC_str48));
        V v_t_24102 = heff_strAppend(heff_strAppend(v_t_24101, v_x_2498), ((V)&g_heff_2ecompile_2eemitc_2etestC_str49));
        return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){v_t_24102, v_s_2499});
      }
      default: return heff_nomatch(v_x2_2497);
      }
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_24105 = heff_env(self)[2];
  V v_x_24103 = heff_env(self)[3];
  V v_drops_24106 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    V v_m_24112 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_24105));
    V v_x2_24113 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_MkPair: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_s_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      V v_t_24116 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_24103)}));
      V v_t_24117 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str50), v_t_24116), ((V)&g_heff_2ecompile_2eemitc_2etestC_str51));
      V v_t_24118 = ({ V a_0 = v_x_24103; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str52); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24103); r_; });
      V v_t_24119 = heff_strAppend(v_t_24117, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str53), v_t_24118));
      V v_t_24120 = heff_strAppend(heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eemitc_2etestC_str54)), v_x_24110);
      V v_t_24121 = heff_strAppend(heff_strAppend(v_t_24120, ((V)&g_heff_2ecompile_2eemitc_2etestC_str55)), v_x_24114);
      V v_x2_24122 = (g_list_2emap_24s379205986x2089287346(((V)&g_heff_2ecompile_2eemitc_2etestC_str56), ((V)&g_heff_2ecompile_2eemitc_2etestC_str57), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str58), ((V)&g_heff_2ecompile_2eemitc_2etestC_str59), ((V)&g_heff_2ecompile_2eemitc_2etestC_str60), v_drops_24106));
      V v_t_24125;
      switch (heff_tag_of(v_x2_24122)) {
      case TAG_Nil: {
        v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str61);
        break;
      }
      case TAG_Cons: {
        V v_x_24123 = heff_field(v_x2_24122, 0);
        V v_xs_24124 = heff_field(v_x2_24122, 1);
        heff_take_n(v_x2_24122, 3ULL, 2);
        v_t_24125 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str62); V a_1 = v_x_24123; V a_2 = v_xs_24124; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24124); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24122);
      }
      V v_t_24126 = heff_strAppend(heff_strAppend(v_t_24121, ((V)&g_heff_2ecompile_2eemitc_2etestC_str63)), v_t_24125);
      V v_x_24127 = heff_strAppend(v_t_24126, ((V)&g_heff_2ecompile_2eemitc_2etestC_str64));
      return heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){v_x_24127, v_s_24115});
    }
    default: return heff_nomatch(v_x2_24113);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 10, "default: {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str7, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str8, 11, "heff_take_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str11, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str12, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str14, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str15, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str17, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str18, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str19, 20, " = heff_take_reuse_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str21, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str22, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str23, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str24, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str25, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str26, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_sure_246 = heff_field(v_x3_242, 3);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_leaves_2410 = heff_field(v_x3_242, 7);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 10, (V[]){v_m_2411, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_247), heff_dup(v_fields_244), v_k_240, heff_dup(v_sure_246), heff_dup(v_flats_245), heff_dup(v_take_248), heff_dup(v_leaves_2410)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_247 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_sure_246 = heff_env(self)[6];
  V v_flats_245 = heff_env(self)[7];
  V v_take_248 = heff_env(self)[8];
  V v_leaves_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2418;
    if (heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
      heff_drop(v_t_243);
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str0);
    } else {
      V v_t_2416 = ({ V a_0 = v_t_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2416));
      v_t_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2earmF_str4));
    }
    V v_t_2419 = (g_list_2emap_24s1518131677x2038133191(heff_dup(v_sv_241), v_plain_247, v_fields_244));
    V v_t_2420 = (g_list_2emap_24s1936967306x1304226505(v_k_240, heff_dup(v_sv_241), v_sure_246, v_flats_245));
    V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2420));
    V v_sv_2422 = v_sv_241;
    V v_x2_2423 = v_take_248;
    V v_t_2443;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_TakeNone: {
      heff_drop(v_sv_2422);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_TakeN: {
      V v_fl_2424 = heff_field(v_x2_2423, 0);
      V v_mask_2425 = heff_field(v_x2_2423, 1);
      V v_n_2426 = heff_field(v_x2_2423, 2);
      heff_take_n(v_x2_2423, 7ULL, 3);
      V v_t_2427;
      switch (heff_tag_of(v_fl_2424)) {
      case TAG_FlatNone: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str5);
        break;
      }
      case TAG_FlatSome: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str6);
        break;
      }
      case TAG_FlatAll: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str7);
        break;
      }
      default: heff_nomatch(v_fl_2424);
      }
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str8), v_t_2427), ((V)&g_heff_2ecompile_2eemitc_2earmF_str9));
      V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_sv_2422), ((V)&g_heff_2ecompile_2eemitc_2earmF_str10));
      V v_t_2430 = heff_strAppend(v_t_2429, heff_intShow(v_mask_2425));
      V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2earmF_str11)), heff_intShow(v_n_2426));
      v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2earmF_str12)), NTAG(TAG_Nil)});
      break;
    }
    case TAG_TakeKeep: {
      V v_fl_2432 = heff_field(v_x2_2423, 0);
      V v_ru_2433 = heff_field(v_x2_2423, 1);
      V v_mask_2434 = heff_field(v_x2_2423, 2);
      V v_n_2435 = heff_field(v_x2_2423, 3);
      heff_take_n(v_x2_2423, 15ULL, 4);
      V v_t_2436 = ({ V a_0 = v_ru_2433; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str13); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_ru_2433); r_; });
      V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str14), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str15), v_t_2436));
      V v_t_2438;
      switch (heff_tag_of(v_fl_2432)) {
      case TAG_FlatNone: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str16);
        break;
      }
      case TAG_FlatSome: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str17);
        break;
      }
      case TAG_FlatAll: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str18);
        break;
      }
      default: heff_nomatch(v_fl_2432);
      }
      V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2earmF_str19)), v_t_2438);
      V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemitc_2earmF_str20)), v_sv_2422);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2earmF_str21)), heff_intShow(v_mask_2434));
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2earmF_str22)), heff_intShow(v_n_2435));
      v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2earmF_str23)), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2444 = (g_list_2emap_24f1217399696x462307458(((V)&g_heff_2ecompile_2eemitc_2earmF_str24), v_t_2443, v_x_2414));
    V v_t_2445;
    if ((heff_dup(v_leaves_2410) == NTAG(TAG_True))) {
      heff_drop(v_leaves_2410);
      v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str25), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_2410);
      v_t_2445 = NTAG(TAG_Nil);
    }
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str26), NTAG(TAG_Nil)});
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2447));
    V v_ys_2449 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2448));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_ys_2449}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str4, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str5, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str6, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str7, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str8, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str10, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str13, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str14, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str16, 1, ";");
Clo g_heff_2ecompile_2eemitc_2etupleRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleRead_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleRead(V v_k_240, V v_sv_241, V v_kinds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str0), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str1));
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str2)));
      V v_t_2411 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str3), v_t_2410));
      V v_t_2420;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        HeffT3 v_t_2412 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_x12_2417 = v_field_2415;
            heff_drop(v_x12_2417);
            switch (heff_tag_of(v_x_2416)) {
            case TAG_RepV: {
              v_t_2420 = NTAG(TAG_False);
              break;
            }
            case TAG_RepFix: {
              heff_take_n(v_x_2416, 0ULL, 1);
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            case TAG_RepF64: {
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            case TAG_RepInt: {
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x_2416);
            }
          } else {
            heff_drop(v_field_2414);
            heff_drop(v_field_2415);
            v_t_2420 = NTAG(TAG_False);
          }
        }
        break;
      }
      case TAG_RepFix: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2447;
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        HeffT3 v_t_2421 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        V v_t_2428;
        {
          V v_field_2423 = v_t_2421.f[1];
          V v_field_2424 = v_t_2421.f[2];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_x_2425 = v_field_2423;
            V v_x12_2426 = v_field_2424;
            heff_drop(v_x12_2426);
            switch (heff_tag_of(v_x_2425)) {
            case TAG_RepV: {
              v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str4);
              break;
            }
            case TAG_RepFix: {
              V v_w_2427 = heff_field(v_x_2425, 0);
              heff_take_n(v_x_2425, 1ULL, 1);
              v_t_2428 = ({ V a_0 = v_w_2427; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_2427); r_; });
              break;
            }
            case TAG_RepF64: {
              v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str5);
              break;
            }
            case TAG_RepInt: {
              v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str6);
              break;
            }
            default: heff_nomatch(v_x_2425);
            }
          } else {
            heff_drop(v_field_2423);
            heff_drop(v_field_2424);
            v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str7);
          }
        }
        V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str8), v_t_2428), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str9));
        HeffT3 v_t_2430 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        V v_t_2436;
        {
          V v_field_2432 = v_t_2430.f[1];
          V v_field_2433 = v_t_2430.f[2];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_x_2434 = v_field_2432;
            V v_x12_2435 = v_field_2433;
            heff_drop(v_x12_2435);
            v_t_2436 = v_x_2434;
          } else {
            heff_drop(v_field_2432);
            heff_drop(v_field_2433);
            v_t_2436 = NTAG(TAG_RepV);
          }
        }
        V v_t_2437 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str10)), heff_intShow(heff_dup(v_i_246)));
        V v_t_2438 = ({ V a_0 = v_t_2436; V a_1 = heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str11)); V r_ = (g_heff_2ecompile_2eemitc_2ewordAs(a_0, a_1)); heff_drop(v_t_2436); r_; });
        v_t_2447 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str12));
      } else {
        heff_drop(v_t_2420);
        HeffT3 v_t_2439 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        V v_t_2445;
        {
          V v_field_2441 = v_t_2439.f[1];
          V v_field_2442 = v_t_2439.f[2];
          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
          if ((v_tag_2440 == ((int64_t)0ULL))) {
            V v_x_2443 = v_field_2441;
            V v_x12_2444 = v_field_2442;
            heff_drop(v_x12_2444);
            v_t_2445 = v_x_2443;
          } else {
            heff_drop(v_field_2441);
            heff_drop(v_field_2442);
            v_t_2445 = NTAG(TAG_RepV);
          }
        }
        V v_t_2446 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str13)), heff_intShow(heff_dup(v_i_246)));
        v_t_2447 = ({ V a_0 = v_t_2445; V a_1 = heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str14)); V r_ = (g_heff_2ecompile_2eemitc_2ewordAs(a_0, a_1)); heff_drop(v_t_2445); r_; });
      }
      V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str15)), v_t_2447);
      return heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str16));
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2etupleRead(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str1, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str3, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str4, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str5, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str6, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str7, 2, "])");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str8, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str9, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str10, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str11, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str12, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str13, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str14, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str15, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str16, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str17, 3, "]);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str18, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str19, 1, "{");
V g_heff_2ecompile_2eemitc_2etupleArm_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2etupleArm_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etupleArm_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etupleArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleArm_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etupleArm(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam0, 1, 8, (V[]){v_m_2411, heff_dup(v_plain_247), v_sv_241, heff_dup(v_fields_244), heff_dup(v_t_243), v_k_240, heff_dup(v_flats_245), heff_dup(v_take_248)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2etupleArm(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam1(V self, V *args) {
  V v_p_2416 = args[0];
  V v_plain_247 = heff_env(self)[0];
  V v_sv_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  switch (heff_tag_of(v_p_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_dup(heff_field(v_p_2416, 0));
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_p_2416);
  }
  V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str2), v_t_2420));
  V v_t_2431;
  if ((heff_dup(v_plain_247) == NTAG(TAG_True))) {
    heff_drop(v_plain_247);
    V v_t_2424;
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_y_2423 = heff_field(v_p_2416, 1);
      heff_take_n(v_p_2416, 2ULL, 2);
      v_t_2424 = v_y_2423;
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    V v_t_2425 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str3)), heff_intShow(v_t_2424));
    v_t_2431 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str4));
  } else {
    heff_drop(v_plain_247);
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str5), v_sv_241), ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str6));
    V v_t_2429;
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_y_2428 = heff_field(v_p_2416, 1);
      heff_take_n(v_p_2416, 2ULL, 2);
      v_t_2429 = v_y_2428;
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    V v_t_2430 = heff_strAppend(v_t_2426, heff_intShow(v_t_2429));
    v_t_2431 = heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str7));
  }
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str8)), v_t_2431);
  return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str9));
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam2(V self, V *args) {
  V v_i_2449 = args[0];
  V v_mask_2446 = heff_env(self)[0];
  V v_kinds_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_2449)));
  V v_t_2451 = heff_intMod(heff_intDiv(v_mask_2446, v_t_2450), MK_INT(2LL));
  V v_x1_2452 = heff_bool((heff_peek_word(v_t_2451) == ((int64_t)1ULL)));
  heff_drop(v_t_2451);
  if (!(heff_dup(v_x1_2452) == NTAG(TAG_True))) {
    heff_drop(v_x1_2452);
    HeffT3 v_t_2453 = ({ V a_0 = v_i_2449; V a_1 = v_kinds_2443; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_kinds_2443); r_; });
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2455;
        V v_x12_2458 = v_field_2456;
        heff_drop(v_x12_2458);
        switch (heff_tag_of(v_x_2457)) {
        case TAG_RepV: {
          return NTAG(TAG_True);
        }
        case TAG_RepFix: {
          heff_take_n(v_x_2457, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_RepF64: {
          return NTAG(TAG_False);
        }
        case TAG_RepInt: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x_2457);
        }
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        return NTAG(TAG_True);
      }
    }
  } else {
    heff_drop(v_i_2449);
    heff_drop(v_kinds_2443);
    heff_drop(v_x1_2452);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_plain_247 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_fields_244 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_flats_245 = heff_env(self)[6];
  V v_take_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam1, 1, 2, (V[]){v_plain_247, heff_dup(v_sv_241)}), v_fields_244));
    V v_s_2434 = heff_strSlice(heff_dup(v_t_243), MK_INT(1LL), heff_strLength_lent(v_t_243, 0));
    V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str10); V a_1 = v_s_2434; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str11), v_s_2434, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2434); r_; });
    V v_t_2436 = (g_list_2emap_24s2010608108x1221393166(v_t_2435));
    V v_t_2437 = ({ V a_0 = v_k_240; V a_1 = heff_dup(v_sv_241); V a_2 = v_t_2436; V a_3 = v_flats_245; V r_ = (g_list_2emap_24s430074199x1834682414(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); r_; });
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2437));
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleArm_str12), NTAG(TAG_Nil)});
    V v_sv_2440 = v_sv_241;
    V v_s_2441 = heff_strSlice(heff_dup(v_t_243), MK_INT(1LL), heff_strLength(v_t_243));
    V v_t_2442 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str13); V a_1 = v_s_2441; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str14), v_s_2441, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2441); r_; });
    V v_kinds_2443 = (g_list_2emap_24s2010608108x1221393166(v_t_2442));
    V v_t_2444 = v_take_248;
    V v_t_2464;
    switch (heff_tag_of(v_t_2444)) {
    case TAG_TakeNone: {
      heff_drop(v_sv_2440);
      heff_drop(v_kinds_2443);
      v_t_2464 = NTAG(TAG_Nil);
      break;
    }
    case TAG_TakeN: {
      V v_mask_2446 = heff_field(v_t_2444, 1);
      V v_n_2447 = heff_field(v_t_2444, 2);
      heff_take_n(v_t_2444, 6ULL, 3);
      V v_t_2448 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2447, MK_INT(1LL))));
      v_t_2464 = (g_list_2emap_24f230958709x841260712(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str15), v_sv_2440, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str16), ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str17), heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam2, 1, 2, (V[]){v_mask_2446, v_kinds_2443}), v_t_2448));
      break;
    }
    case TAG_TakeKeep: {
      heff_take_n(v_t_2444, 0ULL, 4);
      heff_drop(v_sv_2440);
      heff_drop(v_kinds_2443);
      v_t_2464 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2444);
    }
    V v_t_2465 = (g_prelude_2e_2b_2b_24f354580856x2119298159(v_t_2439, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str18), v_t_2464, v_x_2414));
    V v_ys_2466 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2465));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleArm_str19), v_ys_2466}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = ({ V a_0 = v_x_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
  return heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eparamList_str2)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 10, " return r;");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), v_t_243));
    V v_x2_245 = (g_list_2emap_24f1512150482x179770396(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7)), v_t_248);
    return heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8));
  }
  case TAG_Cons: {
    V v_x2_2412 = (g_list_2emap_24s1613211967x1923010103(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14), v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15));
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16)));
    V v_t_2418 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17), v_t_2417));
    V v_t_2419 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2419));
    V v_t_2426;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_xs_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23)), v_t_2426);
    V v_x2_2428 = (g_list_2emap_24s693155583x821663253(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25), v_bi_241));
    V v_t_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28)), v_t_2431);
    return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29));
  }
  default: return heff_nomatch(v_bi_241);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eentryCall(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2420 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = ({ V a_0 = heff_dup(v_i_2420); V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop_tag(v_bi_241, 2); r_; });
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18), heff_intShow(v_i_2420));
  } else {
    heff_drop(v_t_2421);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19), heff_intShow(v_i_2420));
    return heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20));
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str1, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str6, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str7, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str8, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str9, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str11, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str13, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str14, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str16, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str17, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str19, 11, "static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str20, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str22, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str23, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str24, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str25, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str26, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str28, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str29, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str30, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str31, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str32, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str33, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str34, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str36, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str37, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str38, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str39, 13, "  (void)self;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str40, 22, "_entry(V self, V *a) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str41, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str42, 0, "");
V g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V v_tu_240, V v_f_241, V v_z_242) {
top: ;
  V v_reprs_243 = heff_take_field(v_f_241, 5);
  V v_entry_244 = heff_take_field(v_f_241, 3);
  V v_body_245 = heff_take_field(v_f_241, 4);
  V v_key_246 = heff_take_field(v_f_241, 0);
  V v_wrapper_247 = heff_take_field(v_f_241, 7);
  V v_params_248 = heff_take_field(v_f_241, 1);
  V v_ret_249 = heff_take_field(v_f_241, 6);
  V v_lent_2410 = heff_get_n(v_f_241, 2, 8);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 6), 1, (V[]){v_entry_244}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_242}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 6), 1, (V[]){v_body_245}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      V v_tu_2421 = v_tu_240;
      V v_key_2422 = heff_dup(v_key_246);
      V v_rs_2423 = heff_dup(v_reprs_243);
      V v_x4_2424 = heff_dup(v_wrapper_247);
      V v_m_2443;
      switch (heff_tag_of(v_x4_2424)) {
      case TAG_Nothing: {
        heff_drop(v_tu_2421);
        heff_drop(v_key_2422);
        heff_drop(v_rs_2423);
        v_m_2443 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam0_clo);
        break;
      }
      case TAG_Just: {
        V v_x41_2426 = heff_field(v_x4_2424, 0);
        heff_take_n(v_x4_2424, 1ULL, 1);
        switch (heff_tag_of(v_x41_2426)) {
        case TAG_MkWrapper: {
          V v_ws_2427 = heff_field(v_x41_2426, 0);
          V v_body_2428 = heff_field(v_x41_2426, 1);
          heff_take_n(v_x41_2426, 3ULL, 2);
          V v_t_2429 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_2423, v_tu_2421, MK_INT(0LL)));
          V v_m_2430 = heff_tr(heff_call(heff_get_n(v_t_2429, 1, 6), 1, (V[]){v_body_2428}));
          v_m_2443 = heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam1, 1, 4, (V[]){v_m_2430, v_key_2422, v_rs_2423, v_ws_2427});
          break;
        }
        default: heff_nomatch(v_x41_2426);
        }
        break;
      }
      default: heff_nomatch(v_x4_2424);
      }
      V v_x2_2444 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2420}));
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_MkPair: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        V v_s_2446 = heff_field(v_x2_2444, 1);
        V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
        V v_t_2448;
        switch (heff_tag_of(v_ret_249)) {
        case TAG_RepV: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str7);
          break;
        }
        case TAG_RepFix: {
          V v_w_2447 = heff_dup(heff_field(v_ret_249, 0));
          v_t_2448 = ({ V a_0 = v_w_2447; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2447); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str8);
          break;
        }
        case TAG_RepInt: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str9);
          break;
        }
        default: heff_nomatch(v_ret_249);
        }
        V v_t_2450;
        switch (heff_tag_of(v_wrapper_247)) {
        case TAG_Nothing: {
          v_t_2450 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          v_t_2450 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_wrapper_247);
        }
        V v_t_2451 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_248); V a_2 = v_reprs_243; V a_3 = v_t_2448; V a_4 = v_t_2450; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2450); r_; });
        V v_key_2452 = heff_dup(v_key_246);
        V v_rs_2453 = heff_dup(v_reprs_243);
        V v_x3_2454 = heff_dup(v_wrapper_247);
        V v_t_2463;
        switch (heff_tag_of(v_x3_2454)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
          heff_drop(v_key_2452);
          heff_drop(v_rs_2453);
          v_t_2463 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x31_2455 = heff_field(v_x3_2454, 0);
          heff_take_n(v_x3_2454, 1ULL, 1);
          switch (heff_tag_of(v_x31_2455)) {
          case TAG_MkWrapper: {
            V v_ws_2456 = heff_field(v_x31_2455, 0);
            heff_take_n(v_x31_2455, 1ULL, 2);
            V v_t_2458 = ({ V a_0 = v_key_2452; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2452); r_; });
            V v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str11), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str12), v_t_2458));
            V v_t_2460 = ({ V a_0 = v_rs_2453; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_2453); r_; });
            V v_t_2461 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2460, v_ws_2456));
            V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str13)), v_t_2461);
            v_t_2463 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str14)), NTAG(TAG_Nil)});
            break;
          }
          default: heff_nomatch(v_x31_2455);
          }
          break;
        }
        default: heff_nomatch(v_x3_2454);
        }
        V v_t_2464 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str15)));
        V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str16), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str17), v_t_2464));
        V v_t_2466 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str18)));
        V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str19), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str20), v_t_2466));
        V v_t_2468 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str21)));
        V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str22)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str23), v_t_2468));
        V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_248));
        V v_t_2471 = heff_strAppend(heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str24)), heff_intShow(v_t_2470));
        V v_t_2472 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str25)), NTAG(TAG_Nil)});
        V v_t_2473 = heff_tag_at_n(v_ru_24x2_2444_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str26)), v_t_2472});
        V v_t_2474 = (g_prelude_2e_2b_2b(v_t_2463, v_t_2473));
        V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str27)), v_t_2474});
        V v_t_2477;
        switch (heff_tag_of(v_ret_249)) {
        case TAG_RepV: {
          v_t_2477 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str28);
          break;
        }
        case TAG_RepFix: {
          V v_w_2476 = heff_field(v_ret_249, 0);
          heff_take_n(v_ret_249, 1ULL, 1);
          v_t_2477 = ({ V a_0 = v_w_2476; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2476); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2477 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str29);
          break;
        }
        case TAG_RepInt: {
          v_t_2477 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str30);
          break;
        }
        default: heff_nomatch(v_ret_249);
        }
        V v_t_2479;
        switch (heff_tag_of(v_wrapper_247)) {
        case TAG_Nothing: {
          v_t_2479 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_wrapper_247, 0ULL, 1);
          v_t_2479 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_wrapper_247);
        }
        V v_t_2480 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_248); V a_2 = v_reprs_243; V a_3 = v_t_2477; V a_4 = v_t_2479; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_reprs_243); heff_drop(v_t_2479); r_; });
        V v_t_2481 = heff_strAppend(v_t_2480, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str31));
        V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str32), NTAG(TAG_Nil)});
        V v_t_2483 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2482, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str33), v_x_2414));
        V v_t_2484 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str34), v_x_2419));
        V v_t_2485 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str35)));
        V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str36), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str37), v_t_2485));
        V v_t_2487 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_248); r_; });
        V v_t_2488 = ({ V a_0 = v_key_246; V a_1 = v_lent_2410; V a_2 = v_t_2487; V r_ = (g_heff_2ecompile_2eemitc_2eentryCall(a_0, a_1, a_2)); heff_drop(v_key_246); r_; });
        V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str38), NTAG(TAG_Nil)});
        V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str39), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_t_2489})});
        V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2486, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str40)), v_t_2490});
        V v_t_2492 = (g_prelude_2e_2b_2b(v_x_2445, v_t_2491));
        V v_ys_2493 = (g_prelude_2e_2b_2b(v_t_2484, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str41), v_t_2492})));
        V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2483, v_ys_2493));
        V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, v_t_2494})});
        V v_x_2496 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2475, v_t_2495});
        return ((HeffT2){{v_x_2496, v_s_2446}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2444)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2418)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
  }
}
V g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam0(V self, V *args) {
  V v_s_2425 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_2425});
}
V g_heff_2ecompile_2eemitc_2efunDef_24cpr_lam1(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_key_2422 = heff_env(self)[1];
  V v_rs_2423 = heff_env(self)[2];
  V v_ws_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = ({ V a_0 = v_key_2422; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2422); r_; });
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str2), v_t_2435));
    V v_t_2437 = ({ V a_0 = v_rs_2423; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_2423); r_; });
    V v_t_2438 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2437, v_ws_2427));
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str3)), v_t_2438);
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str4), NTAG(TAG_Nil)});
    V v_t_2441 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str5), v_x_2433));
    V v_x_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str6)), v_t_2441});
    return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
Clo g_heff_2ecompile_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2edefC(V v_tu_240, V v_x2_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eemitc_2edefC_24cpr(v_tu_240, v_x2_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2edefC(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0, 22, "static V heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3, 34, "(V p, V k) { return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str5, 22, "static V heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str6, 120, "(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l \? heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str7, 22, "(q, k) : heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str8, 9, "(q, k); }");

HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0), heff_intShow(heff_dup(v_n_241)));
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_245 = ({ V a_0 = v_k_242; V a_1 = v_t_244; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3)), v_t_245);
    V v_f_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4)), NTAG(TAG_Nil)});
    V v_f_248 = heff_intAdd(v_n_241, MK_INT(1LL));
    return ((HeffT2){{v_f_247, v_f_248}});
  }
  case TAG_Plus: {
    V v_a_249 = heff_field(v_x1_240, 0);
    V v_b_2410 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Plus = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_a_249, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_la_2414 = v_field_2412;
      V v_na_2415 = v_field_2413;
      V v_n_2416 = v_n_241;
      V v_la_2417 = v_la_2414;
      V v_na_2418 = heff_dup(v_na_2415);
      HeffT2 v_t_2419 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_b_2410, v_na_2415));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_lb_2422 = v_field_2420;
        V v_nb_2423 = v_field_2421;
        V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str5), heff_intShow(heff_dup(v_n_2416)));
        V v_t_2425 = heff_intShow(heff_intAdd(v_n_2416, MK_INT(1LL)));
        V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str6)), v_t_2425);
        V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str7)), heff_intShow(v_na_2418));
        V v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24Plus, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str8)), NTAG(TAG_Nil)});
        V v_t_2429 = (g_prelude_2e_2b_2b(v_lb_2422, v_t_2428));
        V v_f_2430 = (g_prelude_2e_2b_2b(v_la_2417, v_t_2429));
        return ((HeffT2){{v_f_2430, v_nb_2423}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str0, 4, "    ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str1, 2, " a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str2, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str3, 30, ")heff_int_low64(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str4, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str5, 7, "    V t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str6, 18, " = heff_tget_v(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str7, 11, "); double a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str8, 11, " = FLT_OF(t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str9, 14, "); heff_drop(t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str10, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str11, 10, "    bool a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str12, 17, " = heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str13, 20, ") == NTAG(TAG_True);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str14, 11, "    char *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str15, 27, " = heff_cstr(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str16, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str17, 11, "    char *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str18, 32, " = heff_cstr_text(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str19, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str21, 4, "    ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str22, 3, " *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str23, 34, " = heff_foreign_ptr(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str24, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str25, 0, "");
Clo g_heff_2ecompile_2eemitc_2eargLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLine_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eargLine(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CInteger: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str0), heff_dup(v_t_242)), ((V)&g_heff_2ecompile_2eemitc_2eargLine_str1));
    V v_t_244 = heff_strAppend(v_t_243, heff_intShow(heff_dup(v_i_240)));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str2)), heff_dup(v_t_242));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str3)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str4));
  }
  case TAG_CDouble: {
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str5), heff_intShow(heff_dup(v_i_240)));
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str6)), heff_intShow(heff_dup(v_i_240)));
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str7)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str8)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str9)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str10));
  }
  case TAG_CBool: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str11), heff_intShow(heff_dup(v_i_240)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str12)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str13));
  }
  case TAG_CString: {
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str14), heff_intShow(heff_dup(v_i_240)));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str15)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str16));
  }
  case TAG_CText: {
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str17), heff_intShow(heff_dup(v_i_240)));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str18)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str19));
  }
  case TAG_COwnedString: {
    heff_drop(v_i_240);
    return ((V)&g_heff_2ecompile_2eemitc_2eargLine_str20);
  }
  case TAG_CPointer: {
    V v_t_2418 = heff_field(v_x2_241, 0);
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str21), heff_dup(v_t_2418)), ((V)&g_heff_2ecompile_2eemitc_2eargLine_str22));
    V v_t_2421 = heff_strAppend(v_t_2420, heff_intShow(heff_dup(v_i_240)));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str23)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str24));
  }
  case TAG_CVoid: {
    heff_drop(v_i_240);
    return ((V)&g_heff_2ecompile_2eemitc_2eargLine_str25);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eargLine(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2eargLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLines_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eargLines(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V a_0 = heff_dup(v_i_240); V a_1 = v_t_242; V r_ = (g_heff_2ecompile_2eemitc_2eargLine(a_0, a_1)); heff_drop(v_t_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eemitc_2eargLines_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_rest_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargLines(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_CInteger: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CDouble: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CBool: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CString: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CText: {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_cell_248;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_COwnedString: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_CVoid: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str0, 20, "heff_int((int64_t)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str1, 19, "heff_flt((double)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str2, 30, "NTAG(c \? TAG_True : TAG_False)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str3, 37, "heff_str_bytes(c, (int64_t)strlen(c))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str4, 16, "heff_str_text(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str5, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str6, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str7, 5, "owned");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str8, 3, "(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str9, 7, "let_go_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str10, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str11, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str12, 16, "heff_foreign(c, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str14, 16, "NTAG(TAG_MkUnit)");
Clo g_heff_2ecompile_2eemitc_2econvOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econvOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2econvOf(V v_leaf_240, V v_ptrs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CInteger: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str0);
  }
  case TAG_CDouble: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str1);
  }
  case TAG_CBool: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str2);
  }
  case TAG_CString: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str3);
  }
  case TAG_CText: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str4);
  }
  case TAG_COwnedString: {
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str5), v_leaf_240), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str6));
    return heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str7)), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str8));
  }
  case TAG_CPointer: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_r_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2eletGoIndexGo(MK_INT(0LL), v_ptrs_241, v_t_245, v_r_246));
    V v_what_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str9), heff_intShow(v_t_247));
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str10), v_leaf_240), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str11));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str12), heff_strAppend(v_t_249, v_what_248));
    return heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str13));
  }
  case TAG_CVoid: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str14);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2econvOf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str0, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str1, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str2, 27, "      r = NTAG(TAG_MkUnit);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str3, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str4, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str5, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str6, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str7, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str8, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str9, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str10, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str11, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str13, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str14, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str15, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str16, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str17, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str18, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str19, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str20, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str21, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str22, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str23, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str24, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str25, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str26, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str27, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str28, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str29, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str30, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str31, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str32, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str33, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str34, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str35, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str36, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str37, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str38, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str39, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str40, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str41, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str42, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str43, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str44, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str45, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str46, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str47, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str48, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str49, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str50, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str51, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str52, 10, "(errno) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str53, 5, "right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str54, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str55, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str56, 14, "      int c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str57, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str58, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str59, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str60, 19, "      r = c == 0 \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str61, 5, "right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str62, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str63, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str64, 21, "(NTAG(TAG_MkUnit)) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str65, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str66, 8, "(errno);");
Clo g_heff_2ecompile_2eemitc_2eresultLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eresultLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eresultLines(V v_md_240, V v_leaf_241, V v_ptrs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_b_243, 3));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Gives: {
    V v_it1_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_CVoid: {
      heff_drop(v_md_240);
      heff_drop(v_leaf_241);
      V v_t_246 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
      V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str0), v_t_246), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str1));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eresultLines_str2), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_248});
    }
    default: {
      V v_t_2412;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_249 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2412 = v_t_249;
        break;
      }
      case TAG_CDouble: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str3);
        break;
      }
      case TAG_CBool: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str4);
        break;
      }
      case TAG_CString: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str5);
        break;
      }
      case TAG_CText: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str6);
        break;
      }
      case TAG_COwnedString: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str7);
        break;
      }
      case TAG_CPointer: {
        V v_t_2410 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2412 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str8));
        break;
      }
      case TAG_CVoid: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str9);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str10), v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str11));
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str12));
      V v_t_2427;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_CDouble: {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_CBool: {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_CString: {
        V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str13), v_md_240), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str14));
        V v_t_2418 = heff_strAppend(v_t_2417, heff_get_n(v_b_243, 0, 5));
        v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str15)), NTAG(TAG_Nil)});
        break;
      }
      case TAG_CText: {
        V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str16), v_md_240), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str17));
        V v_t_2420 = heff_strAppend(v_t_2419, heff_get_n(v_b_243, 0, 5));
        v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str18)), NTAG(TAG_Nil)});
        break;
      }
      case TAG_COwnedString: {
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str19), v_md_240), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str20));
        V v_t_2422 = heff_strAppend(v_t_2421, heff_get_n(v_b_243, 0, 5));
        v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str21)), NTAG(TAG_Nil)});
        break;
      }
      case TAG_CPointer: {
        V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str22), v_md_240), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str23));
        V v_t_2426 = heff_strAppend(v_t_2425, heff_get_n(v_b_243, 0, 5));
        v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str24)), NTAG(TAG_Nil)});
        break;
      }
      case TAG_CVoid: {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2428 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_it1_245; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop(v_it1_245); r_; });
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str25), v_t_2428), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str26));
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      V v_ys_2431 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2430));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_ys_2431});
    }
    }
  }
  case TAG_GivesOrErrno: {
    V v_t_2432 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_md_240);
    V v_t_2436;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_CInteger: {
      V v_t_2433 = heff_dup(heff_field(v_t_2432, 0));
      v_t_2436 = v_t_2433;
      break;
    }
    case TAG_CDouble: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str27);
      break;
    }
    case TAG_CBool: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str28);
      break;
    }
    case TAG_CString: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str29);
      break;
    }
    case TAG_CText: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str30);
      break;
    }
    case TAG_COwnedString: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str31);
      break;
    }
    case TAG_CPointer: {
      V v_t_2434 = heff_dup(heff_field(v_t_2432, 0));
      v_t_2436 = heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str32));
      break;
    }
    case TAG_CVoid: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str33);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str34), v_t_2436), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str35));
    V v_t_2438 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2437, v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str36));
    V v_t_2443;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_CInteger: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str37);
      break;
    }
    case TAG_CDouble: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str38);
      break;
    }
    case TAG_CBool: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str39);
      break;
    }
    case TAG_CString: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str40);
      break;
    }
    case TAG_CText: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str41);
      break;
    }
    case TAG_COwnedString: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str42);
      break;
    }
    case TAG_CPointer: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str43);
      break;
    }
    case TAG_CVoid: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str44);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str45), v_t_2443), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str46));
    V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str47), heff_dup(v_leaf_241)), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str48));
    V v_t_2446 = heff_strAppend(v_t_2444, heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str49)));
    V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str50), heff_dup(v_leaf_241)), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str51));
    V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str52)), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str53)));
    V v_t_2449 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_t_2432; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
    V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str54)), v_t_2449);
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str55)), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2451});
  }
  case TAG_DoneOrErrno: {
    heff_drop(v_md_240);
    V v_t_2452 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str56), v_t_2452), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str57));
    V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str58), heff_dup(v_leaf_241)), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str59));
    V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str60), heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str61)));
    V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str62), v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str63));
    V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str64)), heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str65)));
    V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str66)), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2458});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eresultLines(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str0, 3, "// ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str1, 4, "'s `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str2, 57, "` in C, as the module describes it: made by the compiler.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str3, 9, "#include ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str4, 20, "#include <stdbool.h>");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str5, 24, "static V heff_described_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str6, 35, "    heff_fail(\"not an operation of ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str7, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str8, 35, "(V p, V k) { return heff_described_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str9, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str10, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str11, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str12, 15, " that C does\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str13, 13, "    return 0;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str14, 10, "  default:");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str15, 12, "(V p, V k) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str16, 27, "  switch (heff_tag_of(p)) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str18, 1, "\012");
V g_heff_2ecompile_2eemitc_2eglueProvider_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueProvider_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueProvider(V v_gl_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str0), heff_dup(heff_rfield(v_gl_240, 0)));
  V v_t_242 = heff_strAppend(heff_strAppend(v_t_241, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str1)), heff_dup(heff_rfield(v_gl_240, 1)));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_242, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str2)), NTAG(TAG_Nil)});
  V v_t_244 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str3), heff_dup(heff_rfield(v_gl_240, 2))));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_246 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_list_2eany_24s280395686x983781620(a_0)); heff_drop(v_t_246); r_; });
  V v_t_248;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str4), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_247);
    v_t_248 = NTAG(TAG_Nil);
  }
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eassertLine_clo), 1, (V[]){heff_dup(heff_rfield(v_gl_240, 0))}));
  V v_t_2410 = (g_list_2emap(v_t_249, heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2412 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2epointersGo(NTAG(TAG_Nil), v_t_2412));
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2ehelperLines(heff_dup(v_gl_240), v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2416 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_2415));
  V v_t_2417 = (g_heff_2ecompile_2eemitc_2epointersGo(NTAG(TAG_Nil), v_t_2416));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eglueProvider_lam0, 2, 2, (V[]){heff_dup(v_gl_240), v_t_2417}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2418; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str5), heff_dup(heff_rfield(v_gl_240, 1)));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str6), heff_dup(heff_rfield(v_gl_240, 1)));
  V v_t_2425 = heff_take_field(v_gl_240, 4);
  V v_t_2428;
  if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
    heff_drop(v_t_2425);
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str7), heff_dup(heff_rfield(v_gl_240, 1)));
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str8)), heff_dup(heff_rfield(v_gl_240, 1)));
    v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str9)), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2425);
    v_t_2428 = NTAG(TAG_Nil);
  }
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str11), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str12)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str13), v_t_2429})});
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str14), v_t_2430})));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str15)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str16), v_t_2431})});
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2432));
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2433));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_248, v_t_2434));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_244, v_t_2435));
  V v_x2_2437 = (g_prelude_2e_2b_2b(v_t_243, v_t_2436));
  V v_t_2440;
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str17);
    break;
  }
  case TAG_Cons: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_xs_2439 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str18); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2437);
  }
  return heff_rec_n(2, shape_module__text, (V[]){heff_get_n(v_gl_240, 0, 5), v_t_2440});
}
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueProvider(a[0]);
}
V g_heff_2ecompile_2eemitc_2eglueProvider_lam0(V self, V *args) {
  V v_acc_2419 = args[0];
  V v_x_2420 = args[1];
  V v_gl_240 = heff_env(self)[0];
  V v_t_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = ({ V a_0 = heff_take_field(v_gl_240, 0); V a_1 = heff_get_n(v_gl_240, 1, 5); V a_2 = v_t_2417; V a_3 = v_x_2420; V r_ = (g_heff_2ecompile_2eemitc_2ecaseLines(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
  return (g_prelude_2e_2b_2b(v_t_2421, v_acc_2419));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str0, 14, "static V prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str1, 42, "_entry(V self, V *a) { (void)self; return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str2, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str3, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str4, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str8, 16, "static Clo prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str9, 38, "_clo = {{0x80000000u, K_CLO, 0}, prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str10, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str11, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloOf_str12, 4, "); }");
Clo g_heff_2ecompile_2eemitc_2eprimCloOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimCloOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eprimCloOf(V v_q_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_240));
  V v_t_242 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str0), v_t_241), ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str1));
  V v_t_243 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_240));
  V v_t_244 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str2), v_t_243));
  V v_t_245 = (g_heff_2eelab_2eprimitive_2eprimArity(v_q_240));
  V v_x2_246 = (g_list_2emap_24f1512150482x179770396(((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str3), ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str4), MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str6); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str7)), v_t_249);
  V v_t_2411 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_240));
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str8), v_t_2411), ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str9));
  V v_t_2413 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_240));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str10));
  V v_t_2415 = (g_heff_2eelab_2eprimitive_2eprimArity(v_q_240));
  V v_t_2416 = heff_strAppend(v_t_2414, heff_intShow(v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str11)), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eprimCloOf_str12)), v_t_2417});
}
V g_heff_2ecompile_2eemitc_2eprimCloOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eprimCloOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        V t_0 = v_seen_240;
        V t_1 = v_xs_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_240, v_x_242, NTAG(TAG_MkUnit)));
        V v_u_2410 = (g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(v_t_249, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_2410);
        return v_cell_248;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonceInOrder(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 22, "static const HeffName ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 2, "};");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), v_name_240), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1));
  V v_t_243 = (g_std_2eordmap_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_244 = (g_list_2emap_24s1566016224x493905666(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4), v_t_243));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = (g_std_2eordmap_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_248, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8);
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_242, v_t_247), v_t_249);
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9)), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 14, "static V gget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 5, "gget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 4, "_get");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 42, "static const Global heff_globals_arr[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str25, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str26, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str28, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str29, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str30, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str31, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str32, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str33, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str34, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_247 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2425 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6), heff_rfield(v_ce_242, 0)));
  V v_t_2426 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7), heff_rfield(v_ce_242, 1)));
  V v_t_2431 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2431));
  V v_t_2452;
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_Nil: {
    v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16);
    break;
  }
  case TAG_Cons: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_xs_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2449);
  }
  V v_x1_2457 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2460;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nil: {
    v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19);
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_t_2461 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2452), v_t_2460);
  V v_t_2466 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f1323813142x1311067101(a_0, a_1, a_2, a_3)); heff_drop(v_exports_240); r_; });
  V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_intShow(v_t_2466));
  V v_t_2468 = (g_std_2eordmap_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), heff_intShow(v_t_2468));
  V v_t_2470 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_std_2eordmap_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), heff_intShow(v_t_2470));
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str24), NTAG(TAG_Nil)});
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str25)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str26), v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str27)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str28), v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str29)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str30), v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str32), v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str33)), v_t_2476});
  V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2477));
  V v_t_2479 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2478));
  V v_ys_2480 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2479));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str34), v_ys_2480});
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_245 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_t_246 = v_y_245;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  return ({ V a_0 = v_t_246; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ce_2410 = v_ce_242;
  V v_x2_2411 = v_x_249;
  V v_t_2423;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_key_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 2ULL, 2);
    V v_t_2414 = heff_get_n(heff_get_n(v_ce_2410, 2, 3), 0, 11);
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_key_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_x_2418 = v_field_2417;
        heff_drop(v_x_2418);
        V v_t_2419 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_2413, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0)));
        V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), v_t_2419), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2));
        V v_t_2421 = ({ V a_0 = v_key_2413; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2413); r_; });
        V v_t_2422 = heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4), v_t_2421));
        v_t_2423 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_key_2413);
        heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
        heff_drop(v_field_2417);
        v_t_2423 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_248));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_p_2427 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_p_2427, 1);
    heff_take_n(v_p_2427, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  return ({ V a_0 = v_t_2430; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2430); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2432 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_p_2432, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8), v_t_2435), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9));
  V v_ce_2437 = v_ce_242;
  V v_key_2440;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_field(v_p_2432, 1);
    heff_take_n(v_p_2432, 2ULL, 2);
    v_key_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2441 = heff_get_n(heff_get_n(v_ce_2437, 2, 3), 0, 11);
  HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_key_2440; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2441); r_; });
  V v_t_2448;
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_x_2445 = v_field_2444;
      heff_drop(v_x_2445);
      V v_t_2446 = ({ V a_0 = v_key_2440; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2440); r_; });
      v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11), v_t_2446);
    } else {
      heff_drop(v_field_2444);
      V v_t_2447 = ({ V a_0 = v_key_2440; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2440); r_; });
      v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13), v_t_2447), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14));
    }
  }
  return heff_strAppend(heff_strAppend(v_t_2436, v_t_2448), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_p_2453 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456;
  switch (heff_tag_of(v_p_2453)) {
  case TAG_MkPair: {
    V v_y_2455 = heff_field(v_p_2453, 1);
    heff_take_n(v_p_2453, 2ULL, 2);
    v_t_2456 = v_y_2455;
    break;
  }
  default: heff_nomatch(v_p_2453);
  }
  return ({ V a_0 = v_t_2456; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2456); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2462 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465;
  switch (heff_tag_of(v_p_2462)) {
  case TAG_MkPair: {
    V v_y_2464 = heff_field(v_p_2462, 1);
    heff_take_n(v_p_2462, 2ULL, 2);
    v_t_2465 = v_y_2464;
    break;
  }
  default: heff_nomatch(v_p_2462);
  }
  return ({ V a_0 = v_t_2465; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2465); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 8, "uint64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 6, "double");

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str4, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str5, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str9, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str10, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str13, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str14, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str15, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str19, 2, ");");
Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleDecl_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleDecl(V v_k_240, V v_n_241, V v_x3_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str0), heff_intShow(v_t_243));
    V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str1)));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str2)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str3), v_t_245));
    V v_t_2410;
    if (heff_intEq_c_lent(v_n_241, MK_INT(0LL), 2)) {
      heff_drop(v_n_241);
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str4);
    } else {
      V v_x2_247 = (g_list_2ereplicate(v_n_241, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str5)));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str7); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
    }
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str8)), v_t_2410);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str9)), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_sg_2412 = heff_field(v_x3_242, 0);
    heff_drop(v_n_241);
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str10), heff_intShow(v_t_243));
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str11)));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str12), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str13));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str14)), v_t_2415);
    V v_t_2417 = heff_dup(heff_rfield(v_sg_2412, 0));
    V v_t_2423;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str15);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2417, 0ULL, 2);
      V v_x2_2420 = (g_list_2emap_24s1386329375x1773300759(heff_dup(heff_rfield(v_sg_2412, 0))));
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str17); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str18)), v_t_2423);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str19)), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2etupleDecl(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c_lent(v_b_241, v_k_243, 0)) {
    heff_drop(v_m_240);
    heff_drop(v_b_241);
    heff_drop(v_ps_242);
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_n_244 = heff_strAppend(heff_strAppend(heff_dup(v_m_240), ((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0)), heff_intShow(heff_dup(v_k_243)));
    V v_qs_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}), heff_dup(v_ps_242)));
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(v_m_240, v_b_241, v_ps_242, heff_intAdd(v_k_243, MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_n_244);
      return v_rest_2411;
    }
    case TAG_Cons: {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_n_244, v_qs_2410}), v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V a_2 = MK_INT(7LL); V r_ = (g_heff_2ecompile_2eemitc_2ekeyHashGo(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_ret_24bool = heff_bool(heff_intEq_c(heff_intMod(heff_dup(v_t_249), heff_dup(v_b_241)), heff_dup(v_k_243)));
  heff_drop(v_b_241);
  heff_drop(v_k_243);
  heff_drop(v_t_249);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str0, 25, "V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str2, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str3, 18, "#define HEFF_SPLIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str4, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str5, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str6, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str7, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str8, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str9, 17, "#define HEFF_PART");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str10, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str11, 6, "heff.h");
V g_heff_2ecompile_2eemitc_2epartsWith_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2epartsWith_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  V v_prefix_246 = heff_take_field(v_ending_242, 0);
  V v_end_247 = heff_get_n(v_ending_242, 1, 2);
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_x6_245, 0);
    V v_s_249 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_ys_2411 = (g_prelude_2e_2b_2b(v_prefix_246, heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_t_2410})));
    V v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str1); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str2); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str3), v_ys_2411}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2414 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str4); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2413; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2416 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str5); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2415); r_; });
    V v_t_2417 = ({ V a_0 = heff_dup(v_ce_244); V b_1 = heff_tag_at_n(v_ru_24x6_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2416}); V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2418 = (g_heff_2ecompile_2eemitc_2edeclOf(heff_dup(v_ce_244), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get())));
    V v_t_2419 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2420 = heff_tr(heff_call(v_end_247, 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2421 = (g_list_2emap_24s380834591x871125279(v_t_2420));
    V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2421));
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2422));
    V v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str6); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str7); V a_2 = v_t_2417; V a_3 = v_t_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); heff_drop(v_t_2423); r_; });
    V v_ce_2425 = v_ce_244;
    V v_s_2426 = heff_dup(v_s_249);
    V v_strs_2427 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_249, 5)));
    V v_protos_2428 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_249, 3)));
    V v_lams_2429 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_get_n(v_s_249, 2, 8)));
    V v_defs_2430 = v_defs_243;
    V v_ems_2431 = v_ems_248;
    V v_t_2432 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_s_2426, 6))));
    V v_t_2433 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_s_2426, 7))));
    V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo), 10, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str8), ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str9), ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str10), v_ce_2425, heff_dup(v_s_2426), v_t_2432, v_t_2433, heff_dup(v_strs_2427), heff_dup(v_protos_2428), heff_dup(v_lams_2429)}));
    V v_f_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2epartsWith_lam0, 1, 4, (V[]){v_s_2426, v_strs_2427, v_protos_2428, v_lams_2429})}));
    V v_t_2438 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_2430, v_ems_2431));
    V v_m_2439 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(-1LL); V a_2 = MK_INT(0LL); V b_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V a_5 = MK_INT(-1LL); V a_6 = MK_INT(0LL); V b_7 = MK_INT(0LL); V a_8 = heff_dup(g_std_2eordmap_2eempty_get()); V a_9 = v_t_2438; V r_ = (g_list_2efoldl_24s1071292119x112543158(a_0, a_1, a_2, b_3, a_4, a_5, a_6, b_7, a_8, a_9)); heff_drop(b_3); heff_drop(b_7); r_; });
    V v_xs_2440 = ({ V a_0 = v_m_2439; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2439); r_; });
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2445 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2epartsWith_lam1, 2, 1, (V[]){v_f_2437}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2441; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; });
    V v_t_2446 = (g_list_2emap(v_t_2434, v_t_2445));
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eentryPart_get()), v_t_2424}), v_t_2446});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str11), v_t_2412}), v_t_2447});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2epartsWith_lam0(V self, V *args) {
  V v_p_2435 = args[0];
  V v_s_2426 = heff_env(self)[0];
  V v_strs_2427 = heff_env(self)[1];
  V v_protos_2428 = heff_env(self)[2];
  V v_lams_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2436 = ({ V a_0 = v_s_2426; V a_1 = v_strs_2427; V a_2 = v_protos_2428; V a_3 = v_lams_2429; V a_4 = v_p_2435; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_2426, 8); heff_drop(v_strs_2427); heff_drop(v_protos_2428); heff_drop(v_lams_2429); heff_drop(v_p_2435); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2436; V r_ = (g_list_2efoldl_24s1894035205x969464323(a_0, a_1, a_2)); heff_drop(v_ls_2436); r_; });
}
V g_heff_2ecompile_2eemitc_2epartsWith_lam1(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_x_2443 = args[1];
  V v_f_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_tr(heff_call(v_f_2437, 1, (V[]){v_x_2443}));
  return (g_prelude_2e_2b_2b(v_t_2444, v_acc_2442));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str3, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str4, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str5, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str6, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str7, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str8, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str9, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str10, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str11, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str12, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str13, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str14, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str15, 3, "Int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str16, 2, "->");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str19, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str21, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 11);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = MK_INT(-1LL);
    }
  }
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 11);
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      heff_drop(v_x_2413);
      v_t_2414 = MK_INT(1LL);
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = MK_INT(0LL);
    }
  }
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 11);
  HeffT2 v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2420;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2421 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2420));
  V v_t_2424;
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2421);
  }
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 4, 11);
  HeffT2 v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2425); r_; });
  V v_t_2439;
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_x_2429 = v_field_2428;
      V v_s_2430 = v_x_2429;
      V v_params_2431 = heff_take_field(v_s_2430, 0);
      V v_result_2432 = heff_get_n(v_s_2430, 1, 2);
      V v_x2_2433 = (g_list_2emap_24s2090270526x1588636862(v_params_2431));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str3); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      V v_t_2438;
      switch (heff_tag_of(v_result_2432)) {
      case TAG_RepV: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str4);
        break;
      }
      case TAG_RepFix: {
        V v_w_2437 = heff_field(v_result_2432, 0);
        heff_take_n(v_result_2432, 1ULL, 1);
        switch (heff_tag_of(v_w_2437)) {
        case TAG_I8: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str5);
          break;
        }
        case TAG_I16: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str6);
          break;
        }
        case TAG_I32: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str7);
          break;
        }
        case TAG_I64: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str8);
          break;
        }
        case TAG_U8: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str9);
          break;
        }
        case TAG_U16: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str10);
          break;
        }
        case TAG_U32: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str11);
          break;
        }
        case TAG_U64: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str12);
          break;
        }
        case TAG_F32: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str13);
          break;
        }
        default: heff_nomatch(v_w_2437);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str14);
        break;
      }
      case TAG_RepInt: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str15);
        break;
      }
      default: heff_nomatch(v_result_2432);
      }
      v_t_2439 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str16)), v_t_2438);
    } else {
      heff_drop(v_field_2428);
      v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str17);
    }
  }
  V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 11);
  HeffT2 v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2440); r_; });
  V v_t_2445;
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_x_2444 = v_field_2443;
      v_t_2445 = v_x_2444;
    } else {
      heff_drop(v_field_2443);
      v_t_2445 = MK_INT(0LL);
    }
  }
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 9, 11);
  HeffT2 v_t_2447 = ({ V a_0 = v_t_2446; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2446); r_; });
  V v_t_2451;
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      V v_x_2450 = v_field_2449;
      v_t_2451 = v_x_2450;
    } else {
      heff_drop(v_field_2449);
      v_t_2451 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2452 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2451));
  V v_t_2455;
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    v_t_2455 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str18);
    break;
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_xs_2454 = heff_field(v_x2_2452, 1);
    heff_take_n(v_x2_2452, 3ULL, 2);
    v_t_2455 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str19); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2452);
  }
  V v_t_2456 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 10, 11);
  HeffT2 v_t_2457 = ({ V b_0 = heff_get_n(v_t_2456, 0, 2); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2461;
  {
    V v_field_2459 = v_t_2457.f[1];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_x_2460 = v_field_2459;
      v_t_2461 = v_x_2460;
    } else {
      heff_drop(v_field_2459);
      v_t_2461 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2462 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2461));
  V v_t_2465;
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_Nil: {
    v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str20);
    break;
  }
  case TAG_Cons: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_xs_2464 = heff_field(v_x2_2462, 1);
    heff_take_n(v_x2_2462, 3ULL, 2);
    v_t_2465 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str21); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2462);
  }
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2465}), v_rest_242});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2455}), v_t_2466});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2445}), v_t_2467});
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2439}), v_t_2468});
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2424}), v_t_2469});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2470});
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2471});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2472});
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epushOwn(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(a[0], a[1]);
}