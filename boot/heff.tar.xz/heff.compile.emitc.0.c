// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_DoneOrErrno 39355
#define TAG_F32 16337
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Leaf 13717
#define TAG_MkWrapper 39179
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_ctype 296362551
#define LBL_defs 9574869
#define LBL_emits 297985818
#define LBL_ems 310085
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_errors 652506774
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_fresh 299054408
#define LBL_groups 709681407
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lowered 588863906
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_parts 307795706
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sure 10037468
#define LBL_tag 324116
#define LBL_tuples 1084651734
#define LBL_workers 1757018875
#define LBL_wrapper 1827365593
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_parts__errors__groups__copies__emits[] = {LBL_parts, LBL_errors, LBL_groups, LBL_copies, LBL_emits};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2ecByte(V, V, V);
V g_heff_2ecompile_2eemitc_2ecByte_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecByte_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2ecallC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallC_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2econvOf(V, V, V);
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econvOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2edefsKept(V, V, V);
V g_heff_2ecompile_2eemitc_2edefsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefsKept_clo;
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efunDecl(V, V, V);
V g_heff_2ecompile_2eemitc_2efunDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDecl_clo;
V g_heff_2ecompile_2eemitc_2efunDef(V, V, V);
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDef_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptParts(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo;
V g_heff_2ecompile_2eemitc_2ekeptPartsCE(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptPartsCE_clo;
V g_heff_2ecompile_2eemitc_2elentOperand(V, V);
V g_heff_2ecompile_2eemitc_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentOperand_clo;
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
V g_heff_2ecompile_2eemitc_2eperformNodes(V, V);
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eemitc_2eplusDone_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eresultLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultLines_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo;
V g_heff_2ecompile_2eemitc_2etagH(V, V, V);
V g_heff_2ecompile_2eemitc_2etagH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagH_clo;
V g_heff_2ecompile_2eemitc_2etupleFunDef(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleFunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleFunDef_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
V g_heff_2ecompile_2eemitc_2evalDef(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evalDef_clo;
V g_heff_2ecompile_2eemitc_2eworkerDecl(V, V);
V g_heff_2ecompile_2eemitc_2eworkerDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eworkerDecl_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eemitc_2ewrapperCode(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_intShow_get(void);
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s982586932x786952770(V, V);
V g_list_2eany_24s982586932x786952770_entry(V self, V *a);
extern Clo g_list_2eany_24s982586932x786952770_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1732572494x729779974(V, V);
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1732572494x729779974_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s842401018x360740028(V, V);
V g_list_2efoldl_24s842401018x360740028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s842401018x360740028_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s353858844x950951807(V, V, V, V);
V g_list_2emap_24s353858844x950951807_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s706961545x2112949112(V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str0, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str2, 1, "_");
Clo g_heff_2ecompile_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2emangleChar(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_dup(v_c_240)));
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_240)));
  } else {
    heff_drop(v_t_241);
    int64_t v_d_242 = (heff_word_mod(heff_peek_word(v_c_240), ((int64_t)256ULL)) / ((int64_t)16ULL));
    V v_t_243 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str0), heff_box_word(v_d_242), heff_box_word((v_d_242 + ((int64_t)1ULL))));
    int64_t v_d_244 = heff_word_mod(heff_unbox_word(v_c_240), ((int64_t)16ULL));
    V v_t_245 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str1), heff_box_word(v_d_244), heff_box_word((v_d_244 + ((int64_t)1ULL))));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str2), heff_strAppend(v_t_243, v_t_245));
  }
}
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength_lent(v_text_241, 0));
  V v_j_245 = heff_strFind_lent(v_pre_240, v_t_244, MK_INT(0LL), 6);
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_i_242);
    heff_drop(v_j_245);
    return v_acc_243;
  } else {
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_245)), heff_strLength_lent(v_pre_240, 0));
    V v_t_248 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_245)), heff_strLength_lent(v_pre_240, 0));
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_245), heff_strLength_lent(v_pre_240, 0));
    V v_t_2410 = ({ V a_0 = v_text_241; V a_1 = v_t_248; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2eemitc_2eidentAt(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_247;
    V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesInGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecBytesGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecBytesGo(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2ecByte(v_s_240, heff_box_word(v_i_241), heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2ecBytesGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str0, 10, "((V)&prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str1, 5, "_clo)");
Clo g_heff_2ecompile_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimLit_str0), heff_strAppend(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemitc_2eprimLit_str1)));
  V v_o_243 = heff_dup(heff_rfield(v_s_241, 0));
  V v_ps_244 = heff_take_field(v_s_241, 7);
  V v_t_245 = (g_heff_2ecompile_2eemitc_2eownHas(v_o_243, v_p_240, v_ps_244));
  V v_t_246;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_p_240);
    heff_drop(v_o_243);
    heff_drop(v_t_245);
    v_t_246 = v_ps_244;
  } else {
    heff_drop(v_t_245);
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_243, v_p_240}), v_ps_244});
  }
  V v_t_247 = ({ V rv_7 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_247});
}
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimLit(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str0, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str1, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str2, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str3, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str4, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str5, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str6, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str7, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str8, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str9, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str10, 2, "_t");
Clo g_heff_2ecompile_2eemitc_2efixedType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedType_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedType(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedType_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_244 = heff_strAppend(heff_intShow(v_t_243), ((V)&g_heff_2ecompile_2eemitc_2efixedType_str10));
    return heff_strAppend(v_t_242, v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedType(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str3, 9, "heff_div_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str8, 9, "heff_rem_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str13, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str14, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str15, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str16, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str17, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str19, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str20, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str21, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str22, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str23, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str24, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str34, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str35, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str36, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str37, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str38, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str39, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str40, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str41, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str42, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str43, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str44, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str45, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str46, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str48, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str49, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str50, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str51, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str52, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str53, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str54, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str57, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str58, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str59, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str60, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str62, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str63, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str64, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str65, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str66, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str67, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str68, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str69, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str70, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str71, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str72, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str73, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str74, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str75, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str76, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str77, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str78, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str79, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str80, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str81, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str82, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str83, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str84, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str85, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str86, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str87, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str88, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str89, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str90, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str91, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str92, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str93, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str94, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str95, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str96, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str97, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str98, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str99, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str100, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str101, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str102, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str103, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str104, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str105, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str106, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str107, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str108, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str109, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str110, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str111, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str112, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str113, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str114, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str115, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str116, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str117, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str118, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str119, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str120, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str121, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str122, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str123, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str124, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str125, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str127, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str128, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str129, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str130, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str131, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str132, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str133, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str134, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str135, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str136, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str137, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str138, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str139, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str140, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str141, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str142, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str143, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str144, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str145, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str146, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str147, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str148, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str149, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str150, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str151, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str152, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str153, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str154, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str155, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str156, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str157, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str158, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str159, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str160, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str161, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str162, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str163, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str164, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str165, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str166, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str167, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str168, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str169, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str170, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str171, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str172, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str173, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str174, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str175, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str176, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str177, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str178, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str179, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str180, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str182, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str183, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str184, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str185, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str186, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str187, 9, "heff_shl_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str188, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str189, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str190, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str191, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str192, 9, "heff_shr_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str193, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str194, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str195, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str196, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str197, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str198, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str199, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str200, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str201, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str202, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str203, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str204, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str205, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str206, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str207, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str208, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str209, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str210, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str211, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str212, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str213, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str214, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str215, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str216, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str217, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str218, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str219, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str220, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str221, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str222, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str223, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str224, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str225, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str226, 14, "heff_from_int_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str227, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str228, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str229, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str230, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str231, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str232, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str233, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str234, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str235, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str236, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str237, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str238, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str239, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str240, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str241, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str242, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str243, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str244, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str245, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str246, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str247, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str248, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str249, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str250, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str251, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str252, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str253, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str254, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str255, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str256, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str257, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str258, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str259, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str260, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str261, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str262, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str263, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str264, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str265, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str266, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str267, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str268, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str269, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str270, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str271, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str272, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str273, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str274, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str275, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str276, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str277, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str278, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str279, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str280, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str281, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str282, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str283, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str284, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str285, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str286, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str287, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str288, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str289, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str290, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str291, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str292, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str293, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str294, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str295, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str296, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str297, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str298, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str299, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str300, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str301, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str302, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str303, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str304, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str305, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str306, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str307, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str308, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str309, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str310, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str311, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str312, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str313, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str314, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str315, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str316, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str317, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str318, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str319, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str320, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str321, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str322, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str323, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str324, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str325, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str326, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str327, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str328, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str329, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str330, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str331, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str332, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str333, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str334, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str335, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str336, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str337, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str338, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str339, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str340, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str341, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str342, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str343, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str344, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str345, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str346, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str347, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str348, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str349, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str350, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str351, 2, "((");
Clo g_heff_2ecompile_2eemitc_2eintU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eintU_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eintU(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str0), v_vs_242);
  }
  case TAG_OpSub: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str1), v_vs_242);
  }
  case TAG_OpMul: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str2), v_vs_242);
  }
  case TAG_OpDiv: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str3), v_t_243);
    V v_t_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_242, 0);
      V v_xs_246 = heff_field(v_vs_242, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str5), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str6), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eintU_str7)));
    return heff_strAppend(v_f_244, v_t_248);
  }
  case TAG_OpRem: {
    V v_t_249 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str8), v_t_249);
    V v_t_2413;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_242, 0);
      V v_xs_2412 = heff_field(v_vs_242, 1);
      v_t_2413 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str10), heff_dup(v_x_2411), v_xs_2412));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str11), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eintU_str12)));
    return heff_strAppend(v_f_2410, v_t_2414);
  }
  case TAG_OpEq: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2418;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_vs_242, 0);
      v_t_2418 = heff_dup(v_x_2416);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2419;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str14);
      break;
    }
    case TAG_OpSub: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str15);
      break;
    }
    case TAG_OpMul: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str16);
      break;
    }
    case TAG_OpDiv: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str17);
      break;
    }
    case TAG_OpRem: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str18);
      break;
    }
    case TAG_OpEq: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str19);
      break;
    }
    case TAG_OpLt: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str20);
      break;
    }
    case TAG_OpLe: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str21);
      break;
    }
    case TAG_OpAnd: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str22);
      break;
    }
    case TAG_OpOr: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str23);
      break;
    }
    case TAG_OpXor: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str24);
      break;
    }
    case TAG_OpShl: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str25);
      break;
    }
    case TAG_OpShr: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str26);
      break;
    }
    case TAG_OpShow: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str27);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str28);
      break;
    }
    case TAG_OpToInt: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str29);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str30);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str31);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str32);
      break;
    }
    case TAG_OpFloor: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str33);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2420 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2427;
    {
      V v_field_2422 = v_t_2420.f[1];
      V v_field_2423 = v_t_2420.f[2];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2425 = v_field_2422;
        V v_x12_2426 = v_field_2423;
        heff_drop(v_x12_2426);
        v_t_2427 = v_x_2425;
      } else {
        heff_drop(v_field_2422);
        heff_drop(v_field_2423);
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str34);
      }
    }
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str35), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eintU_str36)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str37), heff_strAppend(v_t_2419, v_t_2428));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str38), heff_strAppend(v_t_2418, v_t_2429));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str39), heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2eintU_str40)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str41), heff_strAppend(v_t_2415, v_t_2431));
  }
  case TAG_OpLt: {
    V v_t_2432 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2435;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str42);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_vs_242, 0);
      v_t_2435 = heff_dup(v_x_2433);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2436;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str43);
      break;
    }
    case TAG_OpSub: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str44);
      break;
    }
    case TAG_OpMul: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str45);
      break;
    }
    case TAG_OpDiv: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str46);
      break;
    }
    case TAG_OpRem: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str47);
      break;
    }
    case TAG_OpEq: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str48);
      break;
    }
    case TAG_OpLt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str49);
      break;
    }
    case TAG_OpLe: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str50);
      break;
    }
    case TAG_OpAnd: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str51);
      break;
    }
    case TAG_OpOr: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str52);
      break;
    }
    case TAG_OpXor: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str53);
      break;
    }
    case TAG_OpShl: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str54);
      break;
    }
    case TAG_OpShr: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str55);
      break;
    }
    case TAG_OpShow: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str56);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str57);
      break;
    }
    case TAG_OpToInt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str58);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str59);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str60);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str61);
      break;
    }
    case TAG_OpFloor: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str62);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2437 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2444;
    {
      V v_field_2439 = v_t_2437.f[1];
      V v_field_2440 = v_t_2437.f[2];
      int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
      if ((v_tag_2438 == ((int64_t)0ULL))) {
        V v_x_2442 = v_field_2439;
        V v_x12_2443 = v_field_2440;
        heff_drop(v_x12_2443);
        v_t_2444 = v_x_2442;
      } else {
        heff_drop(v_field_2439);
        heff_drop(v_field_2440);
        v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str63);
      }
    }
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str64), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2eintU_str65)));
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str66), heff_strAppend(v_t_2436, v_t_2445));
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str67), heff_strAppend(v_t_2435, v_t_2446));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str68), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemitc_2eintU_str69)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str70), heff_strAppend(v_t_2432, v_t_2448));
  }
  case TAG_OpLe: {
    V v_t_2449 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2452;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str71);
      break;
    }
    case TAG_Cons: {
      V v_x_2450 = heff_field(v_vs_242, 0);
      v_t_2452 = heff_dup(v_x_2450);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2453;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str72);
      break;
    }
    case TAG_OpSub: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str73);
      break;
    }
    case TAG_OpMul: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str74);
      break;
    }
    case TAG_OpDiv: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str75);
      break;
    }
    case TAG_OpRem: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str76);
      break;
    }
    case TAG_OpEq: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str77);
      break;
    }
    case TAG_OpLt: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str78);
      break;
    }
    case TAG_OpLe: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str79);
      break;
    }
    case TAG_OpAnd: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str80);
      break;
    }
    case TAG_OpOr: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str81);
      break;
    }
    case TAG_OpXor: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str82);
      break;
    }
    case TAG_OpShl: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str83);
      break;
    }
    case TAG_OpShr: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str84);
      break;
    }
    case TAG_OpShow: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str85);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str86);
      break;
    }
    case TAG_OpToInt: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str87);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str88);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str89);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str90);
      break;
    }
    case TAG_OpFloor: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str91);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2454 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2461;
    {
      V v_field_2456 = v_t_2454.f[1];
      V v_field_2457 = v_t_2454.f[2];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_x_2459 = v_field_2456;
        V v_x12_2460 = v_field_2457;
        heff_drop(v_x12_2460);
        v_t_2461 = v_x_2459;
      } else {
        heff_drop(v_field_2456);
        heff_drop(v_field_2457);
        v_t_2461 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str92);
      }
    }
    V v_t_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str93), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemitc_2eintU_str94)));
    V v_t_2463 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str95), heff_strAppend(v_t_2453, v_t_2462));
    V v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str96), heff_strAppend(v_t_2452, v_t_2463));
    V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str97), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemitc_2eintU_str98)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str99), heff_strAppend(v_t_2449, v_t_2465));
  }
  case TAG_OpAnd: {
    V v_t_2466 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2469;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str100);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_vs_242, 0);
      v_t_2469 = heff_dup(v_x_2467);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2470;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str101);
      break;
    }
    case TAG_OpSub: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str102);
      break;
    }
    case TAG_OpMul: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str103);
      break;
    }
    case TAG_OpDiv: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str104);
      break;
    }
    case TAG_OpRem: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str105);
      break;
    }
    case TAG_OpEq: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str106);
      break;
    }
    case TAG_OpLt: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str107);
      break;
    }
    case TAG_OpLe: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str108);
      break;
    }
    case TAG_OpAnd: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str109);
      break;
    }
    case TAG_OpOr: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str110);
      break;
    }
    case TAG_OpXor: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str111);
      break;
    }
    case TAG_OpShl: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str112);
      break;
    }
    case TAG_OpShr: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str113);
      break;
    }
    case TAG_OpShow: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str114);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str115);
      break;
    }
    case TAG_OpToInt: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str116);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str117);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str118);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str119);
      break;
    }
    case TAG_OpFloor: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str120);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2471 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2478;
    {
      V v_field_2473 = v_t_2471.f[1];
      V v_field_2474 = v_t_2471.f[2];
      int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
      if ((v_tag_2472 == ((int64_t)0ULL))) {
        V v_x_2476 = v_field_2473;
        V v_x12_2477 = v_field_2474;
        heff_drop(v_x12_2477);
        v_t_2478 = v_x_2476;
      } else {
        heff_drop(v_field_2473);
        heff_drop(v_field_2474);
        v_t_2478 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str121);
      }
    }
    V v_t_2479 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str122), heff_strAppend(v_t_2478, ((V)&g_heff_2ecompile_2eemitc_2eintU_str123)));
    V v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str124), heff_strAppend(v_t_2470, v_t_2479));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str125), heff_strAppend(v_t_2469, v_t_2480));
    V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str126), heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemitc_2eintU_str127)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str128), heff_strAppend(v_t_2466, v_t_2482));
  }
  case TAG_OpOr: {
    V v_t_2483 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2486;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str129);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_vs_242, 0);
      v_t_2486 = heff_dup(v_x_2484);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2487;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str130);
      break;
    }
    case TAG_OpSub: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str131);
      break;
    }
    case TAG_OpMul: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str132);
      break;
    }
    case TAG_OpDiv: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str133);
      break;
    }
    case TAG_OpRem: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str134);
      break;
    }
    case TAG_OpEq: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str135);
      break;
    }
    case TAG_OpLt: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str136);
      break;
    }
    case TAG_OpLe: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str137);
      break;
    }
    case TAG_OpAnd: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str138);
      break;
    }
    case TAG_OpOr: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str139);
      break;
    }
    case TAG_OpXor: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str140);
      break;
    }
    case TAG_OpShl: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str141);
      break;
    }
    case TAG_OpShr: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str142);
      break;
    }
    case TAG_OpShow: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str143);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str144);
      break;
    }
    case TAG_OpToInt: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str145);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str146);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str147);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str148);
      break;
    }
    case TAG_OpFloor: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str149);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2488 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_2495;
    {
      V v_field_2490 = v_t_2488.f[1];
      V v_field_2491 = v_t_2488.f[2];
      int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
      if ((v_tag_2489 == ((int64_t)0ULL))) {
        V v_x_2493 = v_field_2490;
        V v_x12_2494 = v_field_2491;
        heff_drop(v_x12_2494);
        v_t_2495 = v_x_2493;
      } else {
        heff_drop(v_field_2490);
        heff_drop(v_field_2491);
        v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str150);
      }
    }
    V v_t_2496 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str151), heff_strAppend(v_t_2495, ((V)&g_heff_2ecompile_2eemitc_2eintU_str152)));
    V v_t_2497 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str153), heff_strAppend(v_t_2487, v_t_2496));
    V v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str154), heff_strAppend(v_t_2486, v_t_2497));
    V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str155), heff_strAppend(v_t_2498, ((V)&g_heff_2ecompile_2eemitc_2eintU_str156)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str157), heff_strAppend(v_t_2483, v_t_2499));
  }
  case TAG_OpXor: {
    V v_t_24100 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24103;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str158);
      break;
    }
    case TAG_Cons: {
      V v_x_24101 = heff_field(v_vs_242, 0);
      v_t_24103 = heff_dup(v_x_24101);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24104;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str159);
      break;
    }
    case TAG_OpSub: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str160);
      break;
    }
    case TAG_OpMul: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str161);
      break;
    }
    case TAG_OpDiv: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str162);
      break;
    }
    case TAG_OpRem: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str163);
      break;
    }
    case TAG_OpEq: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str164);
      break;
    }
    case TAG_OpLt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str165);
      break;
    }
    case TAG_OpLe: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str166);
      break;
    }
    case TAG_OpAnd: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str167);
      break;
    }
    case TAG_OpOr: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str168);
      break;
    }
    case TAG_OpXor: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str169);
      break;
    }
    case TAG_OpShl: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str170);
      break;
    }
    case TAG_OpShr: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str171);
      break;
    }
    case TAG_OpShow: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str172);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str173);
      break;
    }
    case TAG_OpToInt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str174);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str175);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str176);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str177);
      break;
    }
    case TAG_OpFloor: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str178);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24105 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24112;
    {
      V v_field_24107 = v_t_24105.f[1];
      V v_field_24108 = v_t_24105.f[2];
      int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
      if ((v_tag_24106 == ((int64_t)0ULL))) {
        V v_x_24110 = v_field_24107;
        V v_x12_24111 = v_field_24108;
        heff_drop(v_x12_24111);
        v_t_24112 = v_x_24110;
      } else {
        heff_drop(v_field_24107);
        heff_drop(v_field_24108);
        v_t_24112 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str179);
      }
    }
    V v_t_24113 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str180), heff_strAppend(v_t_24112, ((V)&g_heff_2ecompile_2eemitc_2eintU_str181)));
    V v_t_24114 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str182), heff_strAppend(v_t_24104, v_t_24113));
    V v_t_24115 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str183), heff_strAppend(v_t_24103, v_t_24114));
    V v_t_24116 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str184), heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2eemitc_2eintU_str185)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str186), heff_strAppend(v_t_24100, v_t_24116));
  }
  case TAG_OpShl: {
    V v_t_24117 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_24118 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str187), v_t_24117);
    V v_t_24121;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24121 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str188);
      break;
    }
    case TAG_Cons: {
      V v_x_24119 = heff_field(v_vs_242, 0);
      V v_xs_24120 = heff_field(v_vs_242, 1);
      v_t_24121 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str189), heff_dup(v_x_24119), v_xs_24120));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str190), heff_strAppend(v_t_24121, ((V)&g_heff_2ecompile_2eemitc_2eintU_str191)));
    return heff_strAppend(v_f_24118, v_t_24122);
  }
  case TAG_OpShr: {
    V v_t_24123 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str192), v_t_24123);
    V v_t_24127;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24127 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str193);
      break;
    }
    case TAG_Cons: {
      V v_x_24125 = heff_field(v_vs_242, 0);
      V v_xs_24126 = heff_field(v_vs_242, 1);
      v_t_24127 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str194), heff_dup(v_x_24125), v_xs_24126));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str195), heff_strAppend(v_t_24127, ((V)&g_heff_2ecompile_2eemitc_2eintU_str196)));
    return heff_strAppend(v_f_24124, v_t_24128);
  }
  case TAG_OpShow: {
    V v_t_24129 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24132;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24132 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str197);
      break;
    }
    case TAG_Cons: {
      V v_x_24130 = heff_field(v_vs_242, 0);
      v_t_24132 = heff_dup(v_x_24130);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24133;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str198);
      break;
    }
    case TAG_OpSub: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str199);
      break;
    }
    case TAG_OpMul: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str200);
      break;
    }
    case TAG_OpDiv: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str201);
      break;
    }
    case TAG_OpRem: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str202);
      break;
    }
    case TAG_OpEq: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str203);
      break;
    }
    case TAG_OpLt: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str204);
      break;
    }
    case TAG_OpLe: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str205);
      break;
    }
    case TAG_OpAnd: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str206);
      break;
    }
    case TAG_OpOr: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str207);
      break;
    }
    case TAG_OpXor: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str208);
      break;
    }
    case TAG_OpShl: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str209);
      break;
    }
    case TAG_OpShr: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str210);
      break;
    }
    case TAG_OpShow: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str211);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str212);
      break;
    }
    case TAG_OpToInt: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str213);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str214);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str215);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str216);
      break;
    }
    case TAG_OpFloor: {
      v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str217);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24134 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24141;
    {
      V v_field_24136 = v_t_24134.f[1];
      V v_field_24137 = v_t_24134.f[2];
      int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
      if ((v_tag_24135 == ((int64_t)0ULL))) {
        V v_x_24139 = v_field_24136;
        V v_x12_24140 = v_field_24137;
        heff_drop(v_x12_24140);
        v_t_24141 = v_x_24139;
      } else {
        heff_drop(v_field_24136);
        heff_drop(v_field_24137);
        v_t_24141 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str218);
      }
    }
    V v_t_24142 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str219), heff_strAppend(v_t_24141, ((V)&g_heff_2ecompile_2eemitc_2eintU_str220)));
    V v_t_24143 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str221), heff_strAppend(v_t_24133, v_t_24142));
    V v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str222), heff_strAppend(v_t_24132, v_t_24143));
    V v_t_24145 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str223), heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eemitc_2eintU_str224)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str225), heff_strAppend(v_t_24129, v_t_24145));
  }
  case TAG_OpFromInt: {
    V v_t_24146 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_24147 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str226), v_t_24146);
    V v_t_24150;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24150 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str227);
      break;
    }
    case TAG_Cons: {
      V v_x_24148 = heff_field(v_vs_242, 0);
      V v_xs_24149 = heff_field(v_vs_242, 1);
      v_t_24150 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str228), heff_dup(v_x_24148), v_xs_24149));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24151 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str229), heff_strAppend(v_t_24150, ((V)&g_heff_2ecompile_2eemitc_2eintU_str230)));
    return heff_strAppend(v_f_24147, v_t_24151);
  }
  case TAG_OpToInt: {
    V v_t_24152 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_24153 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str231), v_t_24152);
    V v_t_24156;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str232);
      break;
    }
    case TAG_Cons: {
      V v_x_24154 = heff_field(v_vs_242, 0);
      V v_xs_24155 = heff_field(v_vs_242, 1);
      v_t_24156 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str233), heff_dup(v_x_24154), v_xs_24155));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str234), heff_strAppend(v_t_24156, ((V)&g_heff_2ecompile_2eemitc_2eintU_str235)));
    return heff_strAppend(v_f_24153, v_t_24157);
  }
  case TAG_OpSqrt: {
    V v_t_24158 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24161;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24161 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str236);
      break;
    }
    case TAG_Cons: {
      V v_x_24159 = heff_field(v_vs_242, 0);
      v_t_24161 = heff_dup(v_x_24159);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24162;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str237);
      break;
    }
    case TAG_OpSub: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str238);
      break;
    }
    case TAG_OpMul: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str239);
      break;
    }
    case TAG_OpDiv: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str240);
      break;
    }
    case TAG_OpRem: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str241);
      break;
    }
    case TAG_OpEq: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str242);
      break;
    }
    case TAG_OpLt: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str243);
      break;
    }
    case TAG_OpLe: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str244);
      break;
    }
    case TAG_OpAnd: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str245);
      break;
    }
    case TAG_OpOr: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str246);
      break;
    }
    case TAG_OpXor: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str247);
      break;
    }
    case TAG_OpShl: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str248);
      break;
    }
    case TAG_OpShr: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str249);
      break;
    }
    case TAG_OpShow: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str250);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str251);
      break;
    }
    case TAG_OpToInt: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str252);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str253);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str254);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str255);
      break;
    }
    case TAG_OpFloor: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str256);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24163 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24170;
    {
      V v_field_24165 = v_t_24163.f[1];
      V v_field_24166 = v_t_24163.f[2];
      int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
      if ((v_tag_24164 == ((int64_t)0ULL))) {
        V v_x_24168 = v_field_24165;
        V v_x12_24169 = v_field_24166;
        heff_drop(v_x12_24169);
        v_t_24170 = v_x_24168;
      } else {
        heff_drop(v_field_24165);
        heff_drop(v_field_24166);
        v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str257);
      }
    }
    V v_t_24171 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str258), heff_strAppend(v_t_24170, ((V)&g_heff_2ecompile_2eemitc_2eintU_str259)));
    V v_t_24172 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str260), heff_strAppend(v_t_24162, v_t_24171));
    V v_t_24173 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str261), heff_strAppend(v_t_24161, v_t_24172));
    V v_t_24174 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str262), heff_strAppend(v_t_24173, ((V)&g_heff_2ecompile_2eemitc_2eintU_str263)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str264), heff_strAppend(v_t_24158, v_t_24174));
  }
  case TAG_OpFromFloat: {
    V v_t_24175 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24178;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24178 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str265);
      break;
    }
    case TAG_Cons: {
      V v_x_24176 = heff_field(v_vs_242, 0);
      v_t_24178 = heff_dup(v_x_24176);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24179;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str266);
      break;
    }
    case TAG_OpSub: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str267);
      break;
    }
    case TAG_OpMul: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str268);
      break;
    }
    case TAG_OpDiv: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str269);
      break;
    }
    case TAG_OpRem: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str270);
      break;
    }
    case TAG_OpEq: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str271);
      break;
    }
    case TAG_OpLt: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str272);
      break;
    }
    case TAG_OpLe: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str273);
      break;
    }
    case TAG_OpAnd: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str274);
      break;
    }
    case TAG_OpOr: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str275);
      break;
    }
    case TAG_OpXor: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str276);
      break;
    }
    case TAG_OpShl: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str277);
      break;
    }
    case TAG_OpShr: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str278);
      break;
    }
    case TAG_OpShow: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str279);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str280);
      break;
    }
    case TAG_OpToInt: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str281);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str282);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str283);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str284);
      break;
    }
    case TAG_OpFloor: {
      v_t_24179 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str285);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24180 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24187;
    {
      V v_field_24182 = v_t_24180.f[1];
      V v_field_24183 = v_t_24180.f[2];
      int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
      if ((v_tag_24181 == ((int64_t)0ULL))) {
        V v_x_24185 = v_field_24182;
        V v_x12_24186 = v_field_24183;
        heff_drop(v_x12_24186);
        v_t_24187 = v_x_24185;
      } else {
        heff_drop(v_field_24182);
        heff_drop(v_field_24183);
        v_t_24187 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str286);
      }
    }
    V v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str287), heff_strAppend(v_t_24187, ((V)&g_heff_2ecompile_2eemitc_2eintU_str288)));
    V v_t_24189 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str289), heff_strAppend(v_t_24179, v_t_24188));
    V v_t_24190 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str290), heff_strAppend(v_t_24178, v_t_24189));
    V v_t_24191 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str291), heff_strAppend(v_t_24190, ((V)&g_heff_2ecompile_2eemitc_2eintU_str292)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str293), heff_strAppend(v_t_24175, v_t_24191));
  }
  case TAG_OpToFloat: {
    V v_t_24192 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24195;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24195 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str294);
      break;
    }
    case TAG_Cons: {
      V v_x_24193 = heff_field(v_vs_242, 0);
      v_t_24195 = heff_dup(v_x_24193);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24196;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str295);
      break;
    }
    case TAG_OpSub: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str296);
      break;
    }
    case TAG_OpMul: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str297);
      break;
    }
    case TAG_OpDiv: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str298);
      break;
    }
    case TAG_OpRem: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str299);
      break;
    }
    case TAG_OpEq: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str300);
      break;
    }
    case TAG_OpLt: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str301);
      break;
    }
    case TAG_OpLe: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str302);
      break;
    }
    case TAG_OpAnd: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str303);
      break;
    }
    case TAG_OpOr: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str304);
      break;
    }
    case TAG_OpXor: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str305);
      break;
    }
    case TAG_OpShl: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str306);
      break;
    }
    case TAG_OpShr: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str307);
      break;
    }
    case TAG_OpShow: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str308);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str309);
      break;
    }
    case TAG_OpToInt: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str310);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str311);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str312);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str313);
      break;
    }
    case TAG_OpFloor: {
      v_t_24196 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str314);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24197 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24204;
    {
      V v_field_24199 = v_t_24197.f[1];
      V v_field_24200 = v_t_24197.f[2];
      int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
      if ((v_tag_24198 == ((int64_t)0ULL))) {
        V v_x_24202 = v_field_24199;
        V v_x12_24203 = v_field_24200;
        heff_drop(v_x12_24203);
        v_t_24204 = v_x_24202;
      } else {
        heff_drop(v_field_24199);
        heff_drop(v_field_24200);
        v_t_24204 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str315);
      }
    }
    V v_t_24205 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str316), heff_strAppend(v_t_24204, ((V)&g_heff_2ecompile_2eemitc_2eintU_str317)));
    V v_t_24206 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str318), heff_strAppend(v_t_24196, v_t_24205));
    V v_t_24207 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str319), heff_strAppend(v_t_24195, v_t_24206));
    V v_t_24208 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str320), heff_strAppend(v_t_24207, ((V)&g_heff_2ecompile_2eemitc_2eintU_str321)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str322), heff_strAppend(v_t_24192, v_t_24208));
  }
  case TAG_OpFloor: {
    V v_t_24209 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_24212;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_24212 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str323);
      break;
    }
    case TAG_Cons: {
      V v_x_24210 = heff_field(v_vs_242, 0);
      v_t_24212 = heff_dup(v_x_24210);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_24213;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str324);
      break;
    }
    case TAG_OpSub: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str325);
      break;
    }
    case TAG_OpMul: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str326);
      break;
    }
    case TAG_OpDiv: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str327);
      break;
    }
    case TAG_OpRem: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str328);
      break;
    }
    case TAG_OpEq: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str329);
      break;
    }
    case TAG_OpLt: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str330);
      break;
    }
    case TAG_OpLe: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str331);
      break;
    }
    case TAG_OpAnd: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str332);
      break;
    }
    case TAG_OpOr: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str333);
      break;
    }
    case TAG_OpXor: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str334);
      break;
    }
    case TAG_OpShl: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str335);
      break;
    }
    case TAG_OpShr: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str336);
      break;
    }
    case TAG_OpShow: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str337);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str338);
      break;
    }
    case TAG_OpToInt: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str339);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str340);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str341);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str342);
      break;
    }
    case TAG_OpFloor: {
      v_t_24213 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str343);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_24214 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    V v_t_24221;
    {
      V v_field_24216 = v_t_24214.f[1];
      V v_field_24217 = v_t_24214.f[2];
      int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
      if ((v_tag_24215 == ((int64_t)0ULL))) {
        V v_x_24219 = v_field_24216;
        V v_x12_24220 = v_field_24217;
        heff_drop(v_x12_24220);
        v_t_24221 = v_x_24219;
      } else {
        heff_drop(v_field_24216);
        heff_drop(v_field_24217);
        v_t_24221 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str344);
      }
    }
    V v_t_24222 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str345), heff_strAppend(v_t_24221, ((V)&g_heff_2ecompile_2eemitc_2eintU_str346)));
    V v_t_24223 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str347), heff_strAppend(v_t_24213, v_t_24222));
    V v_t_24224 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str348), heff_strAppend(v_t_24212, v_t_24223));
    V v_t_24225 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str349), heff_strAppend(v_t_24224, ((V)&g_heff_2ecompile_2eemitc_2eintU_str350)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str351), heff_strAppend(v_t_24209, v_t_24225));
  }
  default: return heff_nomatch(v_op_241);
  }
}
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eintU(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str0, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str1, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str2, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str3, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str4, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str5, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str6, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedLit_str7, 7, "MK_INT(");
Clo g_heff_2ecompile_2eemitc_2efixedLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efixedLit(V v_w_240, V v_n_241) {
top: ;
  int64_t v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((v_t_242 == ((int64_t)64ULL))) {
    if (heff_intLt_c_lent(v_n_241, HEFF_BIG("4611686018427387904"), 2)) {
      if (heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_241, 1)) {
        V v_t_246 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str0));
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str1), v_t_246);
      } else {
        V v_t_247 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str2));
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str3), v_t_247);
      }
    } else {
      V v_t_248 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str4));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str5), v_t_248);
    }
  } else {
    V v_t_249 = heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str6));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str7), v_t_249);
  }
}
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedLit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str1, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str3, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str4, 7, "int64_t");
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallLent_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallLent(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_args_244, v_t_246));
  V v_m_2415 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam0, 1, 1, (V[]){heff_dup(v_k_240)}), v_t_247));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam1, 1, 5, (V[]){v_m_2415, v_k_240, heff_dup(v_g_241), heff_dup(v_w_243), heff_dup(v_tr_242)});
}
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallLent(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_248, 1));
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  return (g_heff_2ecompile_2eemitc_2eargC(v_k_240, v_t_2411, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  V v_tr_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_k_240, 3), v_g_241));
    V v_t_2435;
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      V v_t_2425;
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2424 = v_field_2422;
        v_t_2425 = v_x_2424;
      } else {
        heff_drop(v_field_2422);
        v_t_2425 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_2425)) {
        HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_k_240, 3, 6); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          V v_t_2432;
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_x_2431 = v_field_2429;
            v_t_2432 = v_x_2431;
          } else {
            heff_drop(v_field_2429);
            v_t_2432 = MK_INT(0LL);
          }
          v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallLent_str0), heff_intShow(v_t_2432));
        }
      } else {
        heff_drop_rec(v_k_240, 6);
        switch (heff_tag_of(v_w_243)) {
        case TAG_Nothing: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str1);
          break;
        }
        case TAG_Just: {
          V v_r_2433 = heff_dup(heff_field(v_w_243, 0));
          switch (heff_tag_of(v_r_2433)) {
          case TAG_RepV: {
            v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str2);
            break;
          }
          case TAG_RepFix: {
            V v_w_2434 = heff_field(v_r_2433, 0);
            heff_take_n(v_r_2433, 1ULL, 1);
            v_t_2435 = ({ V a_0 = v_w_2434; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2434); r_; });
            break;
          }
          case TAG_RepF64: {
            v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str3);
            break;
          }
          case TAG_RepInt: {
            v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str4);
            break;
          }
          default: heff_nomatch(v_r_2433);
          }
          break;
        }
        default: heff_nomatch(v_w_243);
        }
      }
    }
    V v_x_2436 = ({ V a_0 = v_t_2435; V a_1 = v_g_241; V a_2 = v_tr_242; V a_3 = v_w_243; V a_4 = v_x_2418; V r_ = (g_heff_2ecompile_2eemitc_2ecallBound(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_241); heff_drop(v_tr_242); heff_drop(v_w_243); r_; });
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str0, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str5, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str6, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallC_str10, 2, "))");
V g_heff_2ecompile_2eemitc_2ecallC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallC_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallC(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2eall_24s1793250635x935291087(v_args_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2emap_24s976303750x321235480(v_args_244));
    V v_m_247 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_246));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallC_lam0, 1, 4, (V[]){v_m_247, heff_dup(v_tr_242), heff_dup(v_w_243), heff_dup(v_g_241)});
  } else {
    heff_drop(v_t_245);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecallLent(v_k_240, v_g_241, v_tr_242, v_w_243, v_args_244);
  }
}
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallC(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallC_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_tr_242 = heff_env(self)[1];
  V v_w_243 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412;
    if ((heff_dup(v_tr_242) == NTAG(TAG_True))) {
      heff_drop(v_tr_242);
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str0);
    } else {
      heff_drop(v_tr_242);
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str1);
    }
    V v_t_2416;
    switch (heff_tag_of(v_w_243)) {
    case TAG_Nothing: {
      V v_t_2413 = ({ V a_0 = v_g_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); r_; });
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallC_str3), v_t_2413);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_w_243, 0ULL, 1);
      V v_t_2415 = ({ V a_0 = v_g_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str4); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); r_; });
      v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallC_str5), v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2ecallC_str6));
      break;
    }
    default: heff_nomatch(v_w_243);
    }
    V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2ecallC_str7)));
    V v_t_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x_2410, 0);
      V v_xs_2419 = heff_field(v_x_2410, 1);
      heff_take_n(v_x_2410, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallC_str9); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_x_2421 = heff_strAppend(v_t_2417, heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2ecallC_str10)));
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str0, 5, "V rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str2, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str6, 17, "heff_rfield(rr_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str7, 7, ") = rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str8, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str11, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str12, 7, "rr_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str15, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str16, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str19, 24, "V rr_ = heff_rec_reuse_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eupdateText_str20, 3, "({ ");
Clo g_heff_2ecompile_2eemitc_2eupdateText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eupdateText_entry, 8, 0};

V g_heff_2ecompile_2eemitc_2eupdateText(V v_suffix_240, V v_x_241, V v_shape_242, V v_keep_243, V v_flats_244, V v_n_245, V v_vs_246, V v_changed_247) {
top: ;
  V v_x2_248 = (g_list_2ezipWith_24s706961545x2112949112(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str0), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str1), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str2), v_vs_246, heff_dup(v_changed_247)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str5)));
  V v_x2_2413 = (g_list_2emap_24s353858844x950951807(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str6), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str7), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str8), v_changed_247));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str10); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str11), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str12)));
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str13), heff_strAppend(v_flats_244, v_t_2417));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str14), heff_strAppend(v_shape_242, v_t_2418));
  V v_t_2420 = heff_strAppend(heff_intShow(v_n_245), v_t_2419);
  V v_t_2421 = heff_strAppend(heff_intShow(v_keep_243), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str15), v_t_2420));
  V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str16), v_t_2412), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str17), v_t_2421));
  V v_t_2423 = heff_strAppend(v_suffix_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str18), v_t_2422));
  V v_t_2424 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str19), v_t_2423));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str20), v_t_2424);
}
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eupdateText(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2elentOperand_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentOperand_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2elentOperand(V v_es_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    return NTAG(TAG_False);
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_x1_244 = (g_list_2eany_24s982586932x786952770(v_x_243, v_es_240));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
    heff_drop(v_x1_244);
    return v_ret_24bool;
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2elentOperand_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2elentOperand(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str2, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str3, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str4, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str5, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str6, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str9, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str10, 17, "heff_f64_of_word(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str12, 7, "INT_OF(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str14, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str16, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str17, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str18, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str19, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str20, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str21, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str22, 17, "heff_f64_of_word(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str24, 7, "INT_OF(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str26, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str28, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str29, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str30, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2etupleRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleRead_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleRead(V v_k_240, V v_sv_241, V v_kinds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str0)));
      V v_t_2411;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        v_t_2411 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2420;
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        HeffT3 v_t_2412 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2417 = v_field_2414;
            V v_x12_2418 = v_field_2415;
            heff_drop(v_x12_2418);
            switch (heff_tag_of(v_x_2417)) {
            case TAG_RepV: {
              v_t_2420 = NTAG(TAG_False);
              break;
            }
            case TAG_RepFix: {
              heff_take_n(v_x_2417, 0ULL, 1);
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            case TAG_RepF64: {
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            case TAG_RepInt: {
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
          } else {
            heff_drop(v_field_2414);
            heff_drop(v_field_2415);
            v_t_2420 = NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_t_2411);
        v_t_2420 = NTAG(TAG_False);
      }
      V v_t_2456;
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        HeffT3 v_t_2421 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        V v_t_2429;
        {
          V v_field_2423 = v_t_2421.f[1];
          V v_field_2424 = v_t_2421.f[2];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_x_2426 = v_field_2423;
            V v_x12_2427 = v_field_2424;
            heff_drop(v_x12_2427);
            switch (heff_tag_of(v_x_2426)) {
            case TAG_RepV: {
              v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str1);
              break;
            }
            case TAG_RepFix: {
              V v_w_2428 = heff_field(v_x_2426, 0);
              heff_take_n(v_x_2426, 1ULL, 1);
              v_t_2429 = ({ V a_0 = v_w_2428; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_2428); r_; });
              break;
            }
            case TAG_RepF64: {
              v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str2);
              break;
            }
            case TAG_RepInt: {
              v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str3);
              break;
            }
            default: heff_nomatch(v_x_2426);
            }
          } else {
            heff_drop(v_field_2423);
            heff_drop(v_field_2424);
            v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str4);
          }
        }
        HeffT3 v_t_2430 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        V v_t_2442;
        {
          V v_field_2432 = v_t_2430.f[1];
          V v_field_2433 = v_t_2430.f[2];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          V v_t_2434 = heff_strAppend(heff_intShow(heff_dup(v_i_246)), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str5));
          V v_x2_2435 = heff_strAppend(v_sv_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str6), v_t_2434));
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_x_2437 = v_field_2432;
            V v_x12_2438 = v_field_2433;
            heff_drop(v_x12_2438);
            switch (heff_tag_of(v_x_2437)) {
            case TAG_RepV: {
              v_t_2442 = v_x2_2435;
              break;
            }
            case TAG_RepFix: {
              V v_w_2439 = heff_field(v_x_2437, 0);
              heff_take_n(v_x_2437, 1ULL, 1);
              V v_t_2440 = ({ V a_0 = v_w_2439; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2439); r_; });
              V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str7), heff_strAppend(v_x2_2435, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str8)));
              v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str9), heff_strAppend(v_t_2440, v_t_2441));
              break;
            }
            case TAG_RepF64: {
              v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str10), heff_strAppend(v_x2_2435, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str11)));
              break;
            }
            case TAG_RepInt: {
              v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str12), heff_strAppend(v_x2_2435, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str13)));
              break;
            }
            default: heff_nomatch(v_x_2437);
            }
          } else {
            heff_drop(v_field_2432);
            heff_drop(v_field_2433);
            v_t_2442 = v_x2_2435;
          }
        }
        V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str14), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str15)));
        v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str16), heff_strAppend(v_t_2429, v_t_2443));
      } else {
        heff_drop(v_t_2420);
        HeffT3 v_t_2444 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2446 = v_t_2444.f[1];
          V v_field_2447 = v_t_2444.f[2];
          int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
          V v_t_2448 = heff_strAppend(heff_intShow(heff_dup(v_i_246)), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str17));
          V v_x2_2449 = heff_strAppend(v_sv_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str18), v_t_2448));
          if ((v_tag_2445 == ((int64_t)0ULL))) {
            V v_x_2451 = v_field_2446;
            V v_x12_2452 = v_field_2447;
            heff_drop(v_x12_2452);
            switch (heff_tag_of(v_x_2451)) {
            case TAG_RepV: {
              v_t_2456 = v_x2_2449;
              break;
            }
            case TAG_RepFix: {
              V v_w_2453 = heff_field(v_x_2451, 0);
              heff_take_n(v_x_2451, 1ULL, 1);
              V v_t_2454 = ({ V a_0 = v_w_2453; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2453); r_; });
              V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str19), heff_strAppend(v_x2_2449, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str20)));
              v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str21), heff_strAppend(v_t_2454, v_t_2455));
              break;
            }
            case TAG_RepF64: {
              v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str22), heff_strAppend(v_x2_2449, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str23)));
              break;
            }
            case TAG_RepInt: {
              v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str24), heff_strAppend(v_x2_2449, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str25)));
              break;
            }
            default: heff_nomatch(v_x_2451);
            }
          } else {
            heff_drop(v_field_2446);
            heff_drop(v_field_2447);
            v_t_2456 = v_x2_2449;
          }
        }
      }
      V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str26), heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str27)));
      V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str28), v_t_249), v_t_2457);
      V v_t_2459 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str29), v_t_2458));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str30), v_t_2459);
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2etupleRead(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str2, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_str6, 9, "static V ");
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ewrapperCode_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperCode_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperCode_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ewrapperCode(V v_tu_240, V v_key_241, V v_rs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_tu_240);
    return ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_lam0_clo);
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkWrapper: {
      V v_ws_246 = heff_field(v_x41_245, 0);
      V v_body_247 = heff_field(v_x41_245, 1);
      V v_t_248 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_242, v_tu_240, MK_INT(0LL)));
      V v_m_249 = heff_tr(heff_call(heff_get_n(v_t_248, 1, 6), 1, (V[]){heff_dup(v_body_247)}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2ewrapperCode_lam1, 1, 4, (V[]){v_m_249, heff_dup(v_key_241), heff_dup(v_rs_242), heff_dup(v_ws_246)});
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ewrapperCode(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_244});
}
V g_heff_2ecompile_2eemitc_2ewrapperCode_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_key_241 = heff_env(self)[1];
  V v_rs_242 = heff_env(self)[2];
  V v_ws_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = ({ V a_0 = v_key_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_241); r_; });
    V v_t_2415 = ({ V a_0 = v_rs_242; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_242); r_; });
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2415, v_ws_246));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str1), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str2)));
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str3), v_t_2414), v_t_2417);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str4), NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str5), v_x_2412));
    V v_x_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_str6), v_t_2418), v_t_2420});
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str1, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str2, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str3, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str5, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str7, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_str8, 0, "");
Clo g_heff_2ecompile_2eemitc_2etupleFunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleFunDef_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleFunDef(V v_tu_240, V v_n_241, V v_f_242, V v_z_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_242, 5), heff_dup(v_tu_240), heff_dup(v_n_241)));
  V v_m_245 = heff_tr(heff_call(heff_get_n(v_t_244, 1, 6), 1, (V[]){heff_take_field(v_f_242, 3)}));
  V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_243}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_242, 5), v_tu_240, heff_dup(v_n_241)));
    V v_m_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 1, 6), 1, (V[]){heff_take_field(v_f_242, 4)}));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str0), heff_intShow(heff_dup(v_n_241)));
      V v_t_2415 = heff_dup(heff_rfield(v_f_242, 7));
      V v_t_2417;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2415, 0ULL, 1);
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      V v_t_2418 = ({ V a_0 = heff_rfield(v_f_242, 0); V a_1 = heff_dup(heff_rfield(v_f_242, 1)); V a_2 = heff_rfield(v_f_242, 5); V a_3 = v_t_2414; V a_4 = v_t_2417; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2417); r_; });
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str1)), NTAG(TAG_Nil)});
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str2), heff_intShow(v_n_241));
      V v_t_2421 = heff_take_field(v_f_242, 7);
      V v_t_2423;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        v_t_2423 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2421, 0ULL, 1);
        v_t_2423 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_t_2424 = ({ V b_0 = heff_take_field(v_f_242, 0); V a_1 = heff_take_field(v_f_242, 1); V b_2 = heff_get_n(v_f_242, 5, 8); V a_3 = v_t_2420; V a_4 = v_t_2423; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(b_0, a_1, b_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_2); heff_drop(v_t_2423); r_; });
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str3), NTAG(TAG_Nil)});
      V v_t_2426 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str4), v_x_247));
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str5)), v_t_2426});
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str6), NTAG(TAG_Nil)});
      V v_t_2429 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str7), v_x_2412));
      V v_t_2430 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_str8), v_t_2427}), v_t_2429));
      V v_x_2431 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2419, v_t_2430});
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2etupleFunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etupleFunDef(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2edefC(V v_tu_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DFun: {
    V v_f_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_249;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_246);
        v_t_249 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_249)) {
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
        V v_t_2416;
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            v_t_2416 = v_x_2415;
          } else {
            heff_drop(v_field_2413);
            v_t_2416 = MK_INT(0LL);
          }
        }
        return (g_heff_2ecompile_2eemitc_2etupleFunDef(v_tu_240, v_t_2416, heff_dup(v_f_243), v_z_242));
      } else {
        HEFF_LAST return g_heff_2ecompile_2eemitc_2efunDef(v_tu_240, heff_dup(v_f_243), v_z_242);
      }
    }
  }
  case TAG_DVal: {
    V v_key_2417 = heff_field(v_x2_241, 0);
    V v_body_2418 = heff_field(v_x2_241, 1);
    V v_rs_2419 = heff_field(v_x2_241, 2);
    return (g_heff_2ecompile_2eemitc_2evalDef(v_tu_240, v_key_2417, heff_dup(v_body_2418), v_rs_2419, v_z_242));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2edefC(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2, 34, "(V p, V k) { return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4, 22, "static V heff_perform_");

HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3)));
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_n_241)), v_t_245);
    V v_f_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4), v_t_246), NTAG(TAG_Nil)});
    V v_f_248 = heff_intAdd(v_n_241, MK_INT(1LL));
    return ((HeffT2){{v_f_247, v_f_248}});
  }
  case TAG_Plus: {
    V v_a_249 = heff_field(v_x1_240, 0);
    V v_b_2410 = heff_field(v_x1_240, 1);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_a_249, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_la_2414 = v_field_2412;
      V v_na_2415 = v_field_2413;
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_b_2410, heff_dup(v_na_2415)));
      return (g_heff_2ecompile_2eemitc_2eplusDone_24cpr(v_n_241, v_la_2414, v_na_2415, v_t_2416));
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_CInteger: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CDouble: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CBool: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CString: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_CText: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_COwnedString: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CVoid: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_cell_249;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str0, 20, "heff_int((int64_t)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str1, 19, "heff_flt((double)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str2, 30, "NTAG(c \? TAG_True : TAG_False)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str3, 37, "heff_str_bytes(c, (int64_t)strlen(c))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str4, 16, "heff_str_text(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str5, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str6, 6, "_owned");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str7, 3, "(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str8, 7, "let_go_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str9, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str10, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str12, 16, "heff_foreign(c, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str13, 16, "NTAG(TAG_MkUnit)");
Clo g_heff_2ecompile_2eemitc_2econvOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econvOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2econvOf(V v_leaf_240, V v_ptrs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CInteger: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str0);
  }
  case TAG_CDouble: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str1);
  }
  case TAG_CBool: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str2);
  }
  case TAG_CString: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str3);
  }
  case TAG_CText: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str4);
  }
  case TAG_COwnedString: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str5), heff_strAppend(v_leaf_240, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str6)));
    return heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str7));
  }
  case TAG_CPointer: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_r_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2eletGoIndexGo(MK_INT(0LL), v_ptrs_241, v_t_245, v_r_246));
    V v_what_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str8), heff_intShow(v_t_247));
    V v_t_249 = heff_strAppend(v_leaf_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str9), v_what_248));
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str10), v_t_249), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str11));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str12), v_t_2410);
  }
  case TAG_CVoid: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str13);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2econvOf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str3, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str4, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str6, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str7, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str9, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str10, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str11, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str12, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str13, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str14, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str15, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str16, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str17, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str18, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str19, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str20, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str21, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str22, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str23, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str24, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str25, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str26, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str27, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str28, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str29, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str30, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str31, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str32, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str33, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str34, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str35, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str36, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str37, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str38, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str39, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str40, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str41, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str42, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str43, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str44, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str45, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str46, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str47, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str48, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str49, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str50, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str51, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str52, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str53, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str54, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str55, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str56, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str57, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str58, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str59, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str60, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str61, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str62, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str63, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str64, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str65, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str66, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str67, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str68, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str69, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str70, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str71, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str72, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str73, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str74, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str75, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str76, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str77, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str78, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str79, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str80, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str81, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str82, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str83, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str84, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str85, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str86, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str87, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str88, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str89, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str90, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str91, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str92, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str93, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str94, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str95, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str96, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str97, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str98, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str99, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str100, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str101, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str102, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str103, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str104, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str105, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str106, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str107, 27, "      r = NTAG(TAG_MkUnit);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str108, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str109, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str110, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str111, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str112, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str113, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str114, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str115, 5, " c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str116, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str117, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str118, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str119, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str120, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str121, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str122, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str123, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str124, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str125, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str126, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str127, 5, "_left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str128, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str129, 6, "_right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str130, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str131, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str132, 10, "(errno) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str133, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str134, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str135, 14, "      int c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str136, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str137, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str138, 6, "_right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str139, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str140, 5, "_left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str141, 21, "(NTAG(TAG_MkUnit)) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str142, 8, "(errno);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str143, 19, "      r = c == 0 \? ");
Clo g_heff_2ecompile_2eemitc_2eresultLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eresultLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eresultLines(V v_md_240, V v_leaf_241, V v_ptrs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_b_243, 3));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Gives: {
    V v_it1_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_CInteger: {
      V v_t_2410;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_247 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2410 = v_t_247;
        break;
      }
      case TAG_CDouble: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str0);
        break;
      }
      case TAG_CBool: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str1);
        break;
      }
      case TAG_CString: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str2);
        break;
      }
      case TAG_CText: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str3);
        break;
      }
      case TAG_COwnedString: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str4);
        break;
      }
      case TAG_CPointer: {
        V v_t_248 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2410 = heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str5));
        break;
      }
      case TAG_CVoid: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str6);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2411 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str7), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str8)));
      V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str9), heff_strAppend(v_t_2410, v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_t_2418;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2421;
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        V v_t_2419 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str10));
        V v_t_2420 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str11), v_t_2419));
        v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str12), v_t_2420), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2418);
        v_t_2421 = NTAG(TAG_Nil);
      }
      V v_t_2422 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_it1_245; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop_tag(v_it1_245, 1); r_; });
      V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str13), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str14)));
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2424));
      return (g_prelude_2e_2b_2b(v_t_2414, v_t_2425));
    }
    case TAG_CDouble: {
      V v_t_2429;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_2426 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2429 = v_t_2426;
        break;
      }
      case TAG_CDouble: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str15);
        break;
      }
      case TAG_CBool: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str16);
        break;
      }
      case TAG_CString: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str17);
        break;
      }
      case TAG_CText: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str18);
        break;
      }
      case TAG_COwnedString: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str19);
        break;
      }
      case TAG_CPointer: {
        V v_t_2427 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2429 = heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str20));
        break;
      }
      case TAG_CVoid: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str21);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2430 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str22), heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str23)));
      V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str24), heff_strAppend(v_t_2429, v_t_2431));
      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      V v_t_2437;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2437 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2437 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2437 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2437 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2437 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2440;
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        V v_t_2438 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str25));
        V v_t_2439 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str26), v_t_2438));
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str27), v_t_2439), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2437);
        v_t_2440 = NTAG(TAG_Nil);
      }
      V v_t_2441 = (g_heff_2ecompile_2eemitc_2econvOf(v_leaf_241, v_ptrs_242, v_it1_245));
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str28), heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str29)));
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
      V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2443));
      return (g_prelude_2e_2b_2b(v_t_2433, v_t_2444));
    }
    case TAG_CBool: {
      V v_t_2448;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_2445 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2448 = v_t_2445;
        break;
      }
      case TAG_CDouble: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str30);
        break;
      }
      case TAG_CBool: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str31);
        break;
      }
      case TAG_CString: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str32);
        break;
      }
      case TAG_CText: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str33);
        break;
      }
      case TAG_COwnedString: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str34);
        break;
      }
      case TAG_CPointer: {
        V v_t_2446 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2448 = heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str35));
        break;
      }
      case TAG_CVoid: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str36);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2449 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str37), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str38)));
      V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str39), heff_strAppend(v_t_2448, v_t_2450));
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_t_2456;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2459;
      if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
        heff_drop(v_t_2456);
        V v_t_2457 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str40));
        V v_t_2458 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str41), v_t_2457));
        v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str42), v_t_2458), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2456);
        v_t_2459 = NTAG(TAG_Nil);
      }
      V v_t_2460 = (g_heff_2ecompile_2eemitc_2econvOf(v_leaf_241, v_ptrs_242, v_it1_245));
      V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str43), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str44)));
      V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
      V v_t_2463 = (g_prelude_2e_2b_2b(v_t_2459, v_t_2462));
      return (g_prelude_2e_2b_2b(v_t_2452, v_t_2463));
    }
    case TAG_CString: {
      V v_t_2467;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_2464 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2467 = v_t_2464;
        break;
      }
      case TAG_CDouble: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str45);
        break;
      }
      case TAG_CBool: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str46);
        break;
      }
      case TAG_CString: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str47);
        break;
      }
      case TAG_CText: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str48);
        break;
      }
      case TAG_COwnedString: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str49);
        break;
      }
      case TAG_CPointer: {
        V v_t_2465 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2467 = heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str50));
        break;
      }
      case TAG_CVoid: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str51);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2468 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str52), heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str53)));
      V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str54), heff_strAppend(v_t_2467, v_t_2469));
      V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
      V v_t_2475;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2478;
      if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
        heff_drop(v_t_2475);
        V v_t_2476 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str55));
        V v_t_2477 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str56), v_t_2476));
        v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str57), v_t_2477), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2475);
        v_t_2478 = NTAG(TAG_Nil);
      }
      V v_t_2479 = (g_heff_2ecompile_2eemitc_2econvOf(v_leaf_241, v_ptrs_242, v_it1_245));
      V v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str58), heff_strAppend(v_t_2479, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str59)));
      V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
      V v_t_2482 = (g_prelude_2e_2b_2b(v_t_2478, v_t_2481));
      return (g_prelude_2e_2b_2b(v_t_2471, v_t_2482));
    }
    case TAG_CText: {
      V v_t_2486;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_2483 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2486 = v_t_2483;
        break;
      }
      case TAG_CDouble: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str60);
        break;
      }
      case TAG_CBool: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str61);
        break;
      }
      case TAG_CString: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str62);
        break;
      }
      case TAG_CText: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str63);
        break;
      }
      case TAG_COwnedString: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str64);
        break;
      }
      case TAG_CPointer: {
        V v_t_2484 = heff_dup(heff_field(v_it1_245, 0));
        v_t_2486 = heff_strAppend(v_t_2484, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str65));
        break;
      }
      case TAG_CVoid: {
        v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str66);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2487 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2488 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str67), heff_strAppend(v_t_2487, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str68)));
      V v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str69), heff_strAppend(v_t_2486, v_t_2488));
      V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
      V v_t_2494;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2494 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2494 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2494 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2494 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2497;
      if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
        heff_drop(v_t_2494);
        V v_t_2495 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str70));
        V v_t_2496 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str71), v_t_2495));
        v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str72), v_t_2496), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2494);
        v_t_2497 = NTAG(TAG_Nil);
      }
      V v_t_2498 = (g_heff_2ecompile_2eemitc_2econvOf(v_leaf_241, v_ptrs_242, v_it1_245));
      V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str73), heff_strAppend(v_t_2498, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str74)));
      V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, NTAG(TAG_Nil)});
      V v_t_24101 = (g_prelude_2e_2b_2b(v_t_2497, v_t_24100));
      return (g_prelude_2e_2b_2b(v_t_2490, v_t_24101));
    }
    case TAG_COwnedString: {
      V v_t_24105;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_24102 = heff_dup(heff_field(v_it1_245, 0));
        v_t_24105 = v_t_24102;
        break;
      }
      case TAG_CDouble: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str75);
        break;
      }
      case TAG_CBool: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str76);
        break;
      }
      case TAG_CString: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str77);
        break;
      }
      case TAG_CText: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str78);
        break;
      }
      case TAG_COwnedString: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str79);
        break;
      }
      case TAG_CPointer: {
        V v_t_24103 = heff_dup(heff_field(v_it1_245, 0));
        v_t_24105 = heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str80));
        break;
      }
      case TAG_CVoid: {
        v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str81);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_24106 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_24107 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str82), heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str83)));
      V v_t_24108 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str84), heff_strAppend(v_t_24105, v_t_24107));
      V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
      V v_t_24113;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_24116;
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop(v_t_24113);
        V v_t_24114 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str85));
        V v_t_24115 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str86), v_t_24114));
        v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str87), v_t_24115), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_24113);
        v_t_24116 = NTAG(TAG_Nil);
      }
      V v_t_24117 = (g_heff_2ecompile_2eemitc_2econvOf(v_leaf_241, v_ptrs_242, v_it1_245));
      V v_t_24118 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str88), heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str89)));
      V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
      V v_t_24120 = (g_prelude_2e_2b_2b(v_t_24116, v_t_24119));
      return (g_prelude_2e_2b_2b(v_t_24109, v_t_24120));
    }
    case TAG_CPointer: {
      V v_t_24126;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        V v_t_24123 = heff_dup(heff_field(v_it1_245, 0));
        v_t_24126 = v_t_24123;
        break;
      }
      case TAG_CDouble: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str90);
        break;
      }
      case TAG_CBool: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str91);
        break;
      }
      case TAG_CString: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str92);
        break;
      }
      case TAG_CText: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str93);
        break;
      }
      case TAG_COwnedString: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str94);
        break;
      }
      case TAG_CPointer: {
        V v_t_24124 = heff_dup(heff_field(v_it1_245, 0));
        v_t_24126 = heff_strAppend(v_t_24124, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str95));
        break;
      }
      case TAG_CVoid: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str96);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_24127 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str97), heff_strAppend(v_t_24127, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str98)));
      V v_t_24129 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str99), heff_strAppend(v_t_24126, v_t_24128));
      V v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24129, NTAG(TAG_Nil)});
      V v_t_24134;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_24134 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_24134 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_24134 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_24134 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_24134 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_24134 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_24134 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_24134 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_24137;
      if ((heff_dup(v_t_24134) == NTAG(TAG_True))) {
        heff_drop(v_t_24134);
        V v_t_24135 = heff_strAppend(heff_get_n(v_b_243, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str100));
        V v_t_24136 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str101), v_t_24135));
        v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str102), v_t_24136), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_24134);
        v_t_24137 = NTAG(TAG_Nil);
      }
      V v_t_24138 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_it1_245; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop_tag(v_it1_245, 2); r_; });
      V v_t_24139 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str103), heff_strAppend(v_t_24138, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str104)));
      V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24139, NTAG(TAG_Nil)});
      V v_t_24141 = (g_prelude_2e_2b_2b(v_t_24137, v_t_24140));
      return (g_prelude_2e_2b_2b(v_t_24130, v_t_24141));
    }
    case TAG_CVoid: {
      heff_drop(v_md_240);
      heff_drop(v_leaf_241);
      V v_t_24142 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
      V v_t_24143 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str105), heff_strAppend(v_t_24142, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str106)));
      V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eresultLines_str107), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, v_t_24144});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  case TAG_GivesOrErrno: {
    V v_t_24145 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_md_240);
    V v_t_24149;
    switch (heff_tag_of(v_t_24145)) {
    case TAG_CInteger: {
      V v_t_24146 = heff_dup(heff_field(v_t_24145, 0));
      v_t_24149 = v_t_24146;
      break;
    }
    case TAG_CDouble: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str108);
      break;
    }
    case TAG_CBool: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str109);
      break;
    }
    case TAG_CString: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str110);
      break;
    }
    case TAG_CText: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str111);
      break;
    }
    case TAG_COwnedString: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str112);
      break;
    }
    case TAG_CPointer: {
      V v_t_24147 = heff_dup(heff_field(v_t_24145, 0));
      v_t_24149 = heff_strAppend(v_t_24147, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str113));
      break;
    }
    case TAG_CVoid: {
      v_t_24149 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str114);
      break;
    }
    default: heff_nomatch(v_t_24145);
    }
    V v_t_24150 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_24151 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str115), heff_strAppend(v_t_24150, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str116)));
    V v_t_24152 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str117), heff_strAppend(v_t_24149, v_t_24151));
    V v_t_24156;
    switch (heff_tag_of(v_t_24145)) {
    case TAG_CInteger: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str118);
      break;
    }
    case TAG_CDouble: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str119);
      break;
    }
    case TAG_CBool: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str120);
      break;
    }
    case TAG_CString: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str121);
      break;
    }
    case TAG_CText: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str122);
      break;
    }
    case TAG_COwnedString: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str123);
      break;
    }
    case TAG_CPointer: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str124);
      break;
    }
    case TAG_CVoid: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str125);
      break;
    }
    default: heff_nomatch(v_t_24145);
    }
    V v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str126), heff_strAppend(heff_dup(v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str127)));
    V v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str128), heff_strAppend(heff_dup(v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str129)));
    V v_t_24159 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_t_24145; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop(v_t_24145); r_; });
    V v_t_24160 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str130), heff_strAppend(v_t_24159, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str131)));
    V v_t_24161 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str132), heff_strAppend(v_t_24158, v_t_24160));
    V v_t_24162 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str133), heff_strAppend(v_t_24157, v_t_24161));
    V v_t_24163 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str134), heff_strAppend(v_t_24156, v_t_24162));
    V v_t_24164 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24163, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24152, v_t_24164});
  }
  case TAG_DoneOrErrno: {
    heff_drop(v_md_240);
    V v_t_24165 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_24166 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str135), heff_strAppend(v_t_24165, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str136)));
    V v_t_24167 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str137), heff_strAppend(heff_dup(v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str138)));
    V v_t_24168 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str139), heff_strAppend(v_leaf_241, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str140)));
    V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str141), heff_strAppend(v_t_24168, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str142)));
    V v_t_24170 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str143), heff_strAppend(v_t_24167, v_t_24169));
    V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24170, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24166, v_t_24171});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eresultLines(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_seen_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_248 = v_field_246;
        heff_drop(v_x_248);
        V t_0 = v_seen_240;
        V t_1 = v_xs_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
        V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_seen_240, v_x_242, NTAG(TAG_MkUnit)));
        V v_u_2411 = (g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(v_t_2410, v_xs_243, heff_dup(v_cell_249)));
        heff_drop(v_u_2411);
        return v_cell_249;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonceInOrder(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str1, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str9, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str10, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str13, 5, "_clo;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str14, 11, "extern Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str15, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDecl_str16, 2, "V ");
Clo g_heff_2ecompile_2eemitc_2efunDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDecl_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efunDecl(V v_ce_240, V v_k_241, V v_n_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 4, 10);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_k_241; V r_ = (g_std_2emap_2elookup_24s1963842891x1660122411(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = ({ V a_0 = v_k_241; V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2eemitc_2eworkerDecl(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str0)));
  V v_t_2411;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop(v_n_242);
    v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str1);
  } else {
    V v_x2_248 = (g_list_2ereplicate(v_n_242, ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str2)));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
  }
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str5), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str6)));
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str7), v_t_246), v_t_2412);
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str8)));
  V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str9), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str10));
  V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str11)));
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str12), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2efunDecl_str13));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str14), v_t_2417), NTAG(TAG_Nil)});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str15), v_t_2415), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDecl_str16), v_t_2413), v_t_2419});
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2420));
}
V g_heff_2ecompile_2eemitc_2efunDecl_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2efunDecl(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_str2, 2, ".c");
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulePart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulePart_entry, 9, 0};

V g_heff_2ecompile_2eemitc_2emodulePart(V v_head_240, V v_ce_241, V v_s_242, V v_shapes_243, V v_prims_244, V v_strs_245, V v_protos_246, V v_lams_247, V v_x9_248) {
top: ;
  switch (heff_tag_of(v_x9_248)) {
  case TAG_MkPair: {
    V v_m_249 = heff_field(v_x9_248, 0);
    V v_ps_2410 = heff_field(v_x9_248, 1);
    V v_ru_24x9_248_24MkPair = heff_take_reuse_n(v_x9_248, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x9_248_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2412 = (g_list_2efoldl_24f891411706x655200538(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_t_2413 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2eusedBy(v_shapes_243, heff_dup(v_ps_2410)));
    V v_t_2416 = (g_list_2emap_24s2073083146x1445066245(v_t_2415));
    V v_xs_2417 = (g_heff_2ecompile_2eemitc_2eusedBy(v_prims_244, heff_dup(v_ps_2410)));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
    V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_xs_2421 = (g_list_2efoldl_24s1732572494x729779974(NTAG(TAG_Nil), v_t_2420));
    V v_m_2422 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2421; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_xs_2421); r_; });
    V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2423));
    V v_t_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam0, 2, 1, (V[]){v_ce_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
    V v_t_2433 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam1, 2, 4, (V[]){heff_dup(v_s_242), heff_dup(v_strs_245), heff_dup(v_protos_246), heff_dup(v_lams_247)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2429; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
    V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2433));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2434));
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2435));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2436));
    V v_x2_2438 = (g_prelude_2e_2b_2b(v_head_240, v_t_2437));
    V v_t_2441;
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_Nil: {
      v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2439 = heff_field(v_x2_2438, 0);
      V v_xs_2440 = heff_field(v_x2_2438, 1);
      heff_take_n(v_x2_2438, 3ULL, 2);
      v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str1); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2438);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_249, ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str2)), v_t_2441});
  }
  default: return heff_nomatch(v_x9_248);
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_heff_2ecompile_2eemitc_2emodulePart(a[0], a[1], a2, a3, a4, a5, a6, a7, a[8]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = ({ V a_0 = v_ce_241; V a_1 = v_x_2426; V r_ = (g_heff_2ecompile_2eemitc_2edeclOf(a_0, a_1)); heff_drop(v_x_2426); r_; });
  return (g_prelude_2e_2b_2b(v_t_2427, v_acc_2425));
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_x_2431 = args[1];
  V v_s_242 = heff_env(self)[0];
  V v_strs_245 = heff_env(self)[1];
  V v_protos_246 = heff_env(self)[2];
  V v_lams_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = ({ V a_0 = v_s_242; V a_1 = v_strs_245; V a_2 = v_protos_246; V a_3 = v_lams_247; V a_4 = v_x_2431; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_242); heff_drop(v_strs_245); heff_drop(v_protos_246); heff_drop(v_lams_247); heff_drop(v_x_2431); r_; });
  return (g_prelude_2e_2b_2b(v_t_2432, v_acc_2430));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str0, 18, "#define HEFF_SPLIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str1, 25, "V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str2, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str4, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str5, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str7, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str8, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str9, 6, "heff.h");
Clo g_heff_2ecompile_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_246 = heff_field(v_x6_245, 0);
    V v_s_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str1), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ending_242, 0), heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_t_249})));
    V v_x2_2411 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str2), v_t_248}), v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str4); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2416 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str5); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2418 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str6); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2417); r_; });
    V v_t_2419 = ({ V a_0 = heff_dup(v_ce_244); V b_1 = heff_tag_at_n(v_ru_24x6_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, v_t_2418}); V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2420 = ({ V a_0 = heff_dup(v_ce_244); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); V r_ = (g_heff_2ecompile_2eemitc_2edeclOf(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2421 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2422 = heff_tr(heff_call(heff_get_n(v_ending_242, 1, 2), 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2424));
    V v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str7); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str8); V a_2 = v_t_2419; V a_3 = v_t_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_list_2efoldl_24s842401018x360740028(heff_dup(g_std_2emap_2eempty_get()), heff_dup(heff_rfield(v_s_247, 5))));
    V v_t_2428 = (g_list_2efoldl_24s842401018x360740028(heff_dup(g_std_2emap_2eempty_get()), heff_dup(heff_rfield(v_s_247, 3))));
    V v_t_2429 = (g_list_2efoldl_24s842401018x360740028(heff_dup(g_std_2emap_2eempty_get()), heff_dup(heff_rfield(v_s_247, 2))));
    V v_t_2430 = ({ V a_0 = v_ce_244; V a_1 = v_s_247; V a_2 = v_t_2427; V a_3 = v_t_2428; V a_4 = v_t_2429; V a_5 = v_defs_243; V a_6 = v_ems_246; V r_ = (g_heff_2ecompile_2eemitc_2emodulesParts(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2427); heff_drop(v_t_2428); heff_drop(v_t_2429); r_; });
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eentryPart_get()), v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str9), v_t_2414}), v_t_2431});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagH_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagH_str3, 1, ",");
Clo g_heff_2ecompile_2eemitc_2etagH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etagH(V v_ce_240, V v_t_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 5, 10);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_t_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2410 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2etagH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etagH_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2414 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 6, 10);
  HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_t_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2420;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      v_t_2420 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2421 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2420));
  V v_t_2424;
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2etagH_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etagH_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2421);
  }
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2424}), v_rest_242});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2413}), v_t_2425});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_241}), v_t_2426});
}
V g_heff_2ecompile_2eemitc_2etagH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ekeptPartsCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2ekeptPartsCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_kept_243, V v_lk_244, V v_ce_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_acc_247 = ({ V a_0 = heff_dup(v_ce_245); V a_1 = v_kept_243; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2eemitc_2edefsKept(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_247, 0)));
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_take_field(v_acc_247, 1)});
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2epartsWith(v_runtime_240, v_provs_241, v_ending_242, v_t_248, v_ce_245, v_t_2410));
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 2, 3);
  return heff_rec_n(5, shape_parts__errors__groups__copies__emits, (V[]){v_t_2411, v_t_2412, heff_dup(heff_rfield(v_lk_244, 1)), heff_get_n(v_lk_244, 2, 3), heff_get_n(v_acc_247, 2, 3)});
}
V g_heff_2ecompile_2eemitc_2ekeptPartsCE_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ekeptPartsCE(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptParts_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ekeptParts(V v_runtime_240, V v_provs_241, V v_eff_242, V v_kept_243, V v_lk_244) {
top: ;
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){v_eff_242}));
  V v_t_246 = heff_rec_n(2, shape_prefix__end, (V[]){NTAG(TAG_Nil), v_t_245});
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 1, 3);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lk_244, 0)), 0, 3);
  V v_t_2410 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), v_t_249));
  V v_t_2411 = (g_list_2efoldl_24s1659194469x1936830512(v_t_248, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_t_247; V a_2 = v_t_2411; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  return (g_heff_2ecompile_2eemitc_2ekeptPartsCE(v_runtime_240, v_provs_241, v_t_246, v_kept_243, v_lk_244, v_t_2412));
}
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ekeptParts(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(a[0], a[1]);
}