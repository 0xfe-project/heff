// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_RestoreDelayed 1107
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_rest 9992347
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_var 326049
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_el__ty__var[] = {LBL_el, LBL_ty, LBL_var};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_level__fields__defaults[] = {LBL_level, LBL_fields, LBL_defaults};
static uint32_t shape_name__ty__el__dflt__span[] = {LBL_name, LBL_ty, LBL_el, LBL_dflt, LBL_span};
static uint32_t shape_name__ty__stx__val[] = {LBL_name, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_span__ty__keys__defaults__written[] = {LBL_span, LBL_ty, LBL_keys, LBL_defaults, LBL_written};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_array_2eempty_get(void);
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2eenvironment_2ebindName(V, V, V);
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindName_clo;
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2eglobals_2elookupKey(V, V);
V g_heff_2eelab_2eglobals_2elookupKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupKey_clo;
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2ecode(V);
V g_heff_2eelab_2ememoed_2ecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2ecode_clo;
V g_heff_2eelab_2ememoed_2econs(V, V);
V g_heff_2eelab_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2econs_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ememoed_2erecordM(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2erecordM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2erecordM_clo;
V g_heff_2eelab_2ememoed_2especializeM(V, V, V);
V g_heff_2eelab_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2especializeM_clo;
V g_heff_2eelab_2ememoed_2esumM(V);
V g_heff_2eelab_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2esumM_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eadvanceSelf(V, V, V, V);
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eadvanceSelf_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edefaultChk(V, V, V);
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultChk_clo;
V g_heff_2eelab_2erules_2edefaultFor(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultFor_clo;
V g_heff_2eelab_2erules_2edefaulted(V, V, V, V, V);
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaulted_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2edescribes(V);
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribes_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efixEnv(V, V, V);
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efixEnv_clo;
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultChk(V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eindexOfName(V, V, V);
V g_heff_2eelab_2erules_2eindexOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eindexOfName_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2eintoSilent(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintoSilent_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintoSilent_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2elookupP(V, V);
V g_heff_2eelab_2erules_2elookupP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elookupP_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2ementionsTermF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2enotANumber(V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitDefault(V, V, V, V);
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitDefault_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesSaid(V);
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2erecChk(V, V);
V g_heff_2eelab_2erules_2erecChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecChk_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecordTagIn(V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTagIn_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
V g_heff_2eelab_2erules_2erecoverWith(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecoverWith_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2erules_2esumIntroNow(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etraverseE(V, V);
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etraverseE_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2evarGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evarGo_clo;
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s328645370x374613117(V);
V g_list_2efilter_24s328645370x374613117_entry(V self, V *a);
extern Clo g_list_2efilter_24s328645370x374613117_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1224798844x1489231098(V);
V g_list_2emap_24s1224798844x1489231098_entry(V self, V *a);
extern Clo g_list_2emap_24s1224798844x1489231098_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1445534224x744280941(V, V);
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a);
extern Clo g_list_2emap_24s1445534224x744280941_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s2141157620x437287316(V);
V g_list_2emap_24s2141157620x437287316_entry(V self, V *a);
extern Clo g_list_2emap_24s2141157620x437287316_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s76631343x1276310171(V);
V g_list_2emap_24s76631343x1276310171_entry(V self, V *a);
extern Clo g_list_2emap_24s76631343x1276310171_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2eelab_2erules_2eanyP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyP_entry, 2, 0};

V g_heff_2eelab_2erules_2eanyP(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eanyP(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2erules_2eanyIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyIdxGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), heff_dup(v_x_243)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_i_240);
      heff_drop(v_f_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_f_241;
      V t_2 = v_xs_244;
      v_i_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eanyIdxGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTermF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 2, (V[]){v_d_241, heff_dup(v_i_243)});
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_245 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_245)});
  }
  case TAG_SApp: {
    V v_f_246 = heff_field(v_t_242, 0);
    V v_a_247 = heff_field(v_t_242, 1);
    V v_t_248 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_f_246)}));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_a_247)});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_SLam: {
    V v_dd_249 = heff_field(v_t_242, 0);
    V v_it2_2410 = heff_field(v_t_242, 1);
    switch (heff_tag_of(v_it2_2410)) {
    case TAG_MkAbs: {
      V v_b_2412 = heff_field(v_it2_2410, 1);
      V v_t_2413 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_249)}));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2412)});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_AbsConst: {
      V v_b_2414 = heff_field(v_it2_2410, 0);
      V v_t_2415 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_249)}));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_b_2414)});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_it2_2410);
    }
  }
  case TAG_SCons: {
    V v_dct_2416 = heff_field(v_t_242, 0);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2416, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2416, 2)));
    V v_t_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam0, 1, 2, (V[]){v_r_240, v_d_241}); V a_1 = v_t_2419; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_SProj: {
    V v_e_2423 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2423)});
  }
  case TAG_STag: {
    V v_as_2426 = heff_field(v_t_242, 1);
    V v_t_2427 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2427; V b_1 = heff_arrayToList(heff_dup(v_as_2426)); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2428 = heff_field(v_t_242, 0);
    V v_cs_2429 = heff_field(v_t_242, 1);
    V v_t_2430 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2428)}));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2431 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2429, 0)));
      V v_t_2432 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2429, 2)));
      V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam1, 1, 2, (V[]){v_d_241, v_r_240}); V a_1 = v_t_2433; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2433); r_; });
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_SSpecialize: {
    V v_e_2440 = heff_field(v_t_242, 0);
    V v_v_2442 = heff_field(v_t_242, 2);
    V v_t_2443 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2440)}));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_True: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_v_2442)});
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  case TAG_SIs: {
    V v_e_2444 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2444)});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2445 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2445)});
  }
  case TAG_SFix: {
    V v_dd_2446 = heff_field(v_t_242, 0);
    V v_it2_2447 = heff_field(v_t_242, 1);
    switch (heff_tag_of(v_it2_2447)) {
    case TAG_MkAbs: {
      V v_b_2449 = heff_field(v_it2_2447, 1);
      V v_t_2450 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2446)}));
      switch (heff_tag_of(v_t_2450)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2449)});
      }
      default: return heff_nomatch(v_t_2450);
      }
    }
    case TAG_AbsConst: {
      V v_b_2451 = heff_field(v_it2_2447, 0);
      V v_t_2452 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2446)}));
      switch (heff_tag_of(v_t_2452)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_b_2451)});
      }
      default: return heff_nomatch(v_t_2452);
      }
    }
    default: return heff_nomatch(v_it2_2447);
    }
  }
  case TAG_SImplicit: {
    V v_e_2454 = heff_field(v_t_242, 1);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2454)});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2458 = heff_field(v_t_242, 2);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_ty_2458)});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ementionsTermF(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args) {
  V v_x3_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_MkPair: {
    V v_v_2422 = heff_field(v_x3_2420, 1);
    heff_take_n(v_x3_2420, 2ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, v_v_2422});
  }
  default: return heff_nomatch(v_x3_2420);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args) {
  V v_x3_2434 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2434)) {
  case TAG_MkPair: {
    V v_x32_2436 = heff_field(v_x3_2434, 1);
    heff_take_n(v_x3_2434, 2ULL, 2);
    switch (heff_tag_of(v_x32_2436)) {
    case TAG_MkPair: {
      V v_xs_2437 = heff_field(v_x32_2436, 0);
      V v_b_2438 = heff_field(v_x32_2436, 1);
      heff_take_n(v_x32_2436, 3ULL, 2);
      V v_t_2439 = heff_intAdd(v_d_241, heff_arrayLength(v_xs_2437));
      return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_t_2439, v_b_2438});
    }
    default: return heff_nomatch(v_x32_2436);
    }
  }
  default: return heff_nomatch(v_x3_2434);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTypeF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_244)});
  }
  case TAG_SFunction: {
    V v_dom_246 = heff_field(v_t_242, 1);
    V v_it3_247 = heff_field(v_t_242, 2);
    switch (heff_tag_of(v_it3_247)) {
    case TAG_MkAbs: {
      V v_b_2411 = heff_field(v_it3_247, 1);
      V v_t_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_246)}));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2411)});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_it3_247, 0);
      V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_246)}));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_b_2413)});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it3_247);
    }
  }
  case TAG_SRecord: {
    V v_ft_2416 = heff_field(v_t_242, 1);
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2416, 2)));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam0, 2, 2, (V[]){v_r_240, v_d_241}); V a_2 = v_t_2418; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  }
  case TAG_SSum: {
    V v_vs_2421 = heff_field(v_t_242, 0);
    V v_t_2422 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2421, 0)));
    V v_t_2423 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2421, 2)));
    V v_t_2424 = (g_heff_2eutil_2edict_2ezipKV(v_t_2422, v_t_2423));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam1, 1, 2, (V[]){v_r_240, v_d_241}); V a_1 = v_t_2424; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2424); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2429 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_2429)});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2430 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_2430)});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ementionsTypeF(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_ty_2420 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get_n(v_r_240, 1, 3);
  args[0] = heff_intAdd(v_d_241, v_i_2419);
  args[1] = v_ty_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args) {
  V v_x3_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_MkPair: {
    V v_args_2427 = heff_field(v_x3_2425, 1);
    heff_take_n(v_x3_2425, 2ULL, 2);
    V v_t_2428 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2428; V b_1 = heff_arrayToList(v_args_2427); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2425);
  }
}
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsLocal_entry, 1, 0};

V g_heff_2eelab_2erules_2ementionsLocal(V v_k_240) {
top: ;
  return heff_rec_n(3, shape_el__ty__var, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam1, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam2, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsLocal(a[0]);
}
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_d_241; V a_2 = v_t_242; V r_ = (g_heff_2eelab_2erules_2ementionsTermF(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_d_244; V a_2 = v_t_245; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args) {
  V v_d_247 = args[0];
  V v_i_248 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_i_248, heff_intAdd(v_d_247, v_k_240));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    return heff_intLe(v_d_240, heff_dup(v_i_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_244 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_240, v_a_244);
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_t_241, 0);
    V v_a_246 = heff_field(v_t_241, 1);
    V v_t_247 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_f_245));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_d_240;
      V t_1 = v_a_246;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_SLam: {
    V v_dd_248 = heff_field(v_t_241, 0);
    V v_it2_249 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_it2_249)) {
    case TAG_MkAbs: {
      V v_b_2411 = heff_field(v_it2_249, 1);
      V v_t_2412 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_248));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_it2_249, 0);
      V v_t_2414 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_248));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2413;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it2_249);
    }
  }
  case TAG_SCons: {
    V v_dct_2415 = heff_field(v_t_241, 0);
    V v_t_2416 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2415, 0)));
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2415, 2)));
    V v_t_2418 = (g_heff_2eutil_2edict_2ezipKV(v_t_2416, v_t_2417));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_SProj: {
    V v_e_2422 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2422;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_STag: {
    V v_as_2425 = heff_field(v_t_241, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(heff_dup(v_as_2425)); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2427 = heff_field(v_t_241, 0);
    V v_cs_2428 = heff_field(v_t_241, 1);
    V v_t_2429 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_e_2427));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2428, 0)));
      V v_t_2431 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2428, 2)));
      V v_t_2432 = (g_heff_2eutil_2edict_2ezipKV(v_t_2430, v_t_2431));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2432; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2432); r_; });
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SSpecialize: {
    V v_e_2439 = heff_field(v_t_241, 0);
    V v_v_2441 = heff_field(v_t_241, 2);
    V v_t_2442 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_e_2439));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_d_240;
      V t_1 = v_v_2441;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_SIs: {
    V v_e_2443 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2443;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2444 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2444;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_dd_2445 = heff_field(v_t_241, 0);
    V v_it2_2446 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_it2_2446)) {
    case TAG_MkAbs: {
      V v_b_2448 = heff_field(v_it2_2446, 1);
      V v_t_2449 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_2445));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2448;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    case TAG_AbsConst: {
      V v_b_2450 = heff_field(v_it2_2446, 0);
      V v_t_2451 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_2445));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2450;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    default: return heff_nomatch(v_it2_2446);
    }
  }
  case TAG_SImplicit: {
    V v_e_2453 = heff_field(v_t_241, 1);
    V t_0 = v_d_240;
    V t_1 = v_e_2453;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2457 = heff_field(v_t_241, 2);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_240, v_ty_2457);
  }
  case TAG_SLitInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2419)) {
  case TAG_MkPair: {
    V v_v_2421 = heff_field(v_x3_2419, 1);
    heff_take_n(v_x3_2419, 2ULL, 2);
    return ({ V a_0 = v_d_240; V a_1 = v_v_2421; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_v_2421); r_; });
  }
  default: return heff_nomatch(v_x3_2419);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1(V self, V *args) {
  V v_t_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2426; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_t_2426); r_; });
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2(V self, V *args) {
  V v_x3_2433 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_MkPair: {
    V v_x32_2435 = heff_field(v_x3_2433, 1);
    heff_take_n(v_x3_2433, 2ULL, 2);
    switch (heff_tag_of(v_x32_2435)) {
    case TAG_MkPair: {
      V v_xs_2436 = heff_field(v_x32_2435, 0);
      V v_b_2437 = heff_field(v_x32_2435, 1);
      heff_take_n(v_x32_2435, 3ULL, 2);
      V v_t_2438 = heff_intAdd(v_d_240, heff_arrayLength(v_xs_2436));
      return ({ V a_0 = v_t_2438; V a_1 = v_b_2437; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_b_2437); r_; });
    }
    default: return heff_nomatch(v_x32_2435);
    }
  }
  default: return heff_nomatch(v_x3_2433);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SU: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_240, v_e_243);
  }
  case TAG_SFunction: {
    V v_dom_245 = heff_field(v_t_241, 1);
    V v_it3_246 = heff_field(v_t_241, 2);
    switch (heff_tag_of(v_it3_246)) {
    case TAG_MkAbs: {
      V v_b_2410 = heff_field(v_it3_246, 1);
      V v_t_2411 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dom_245));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2410;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_AbsConst: {
      V v_b_2412 = heff_field(v_it3_246, 0);
      V v_t_2413 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dom_245));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2412;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_it3_246);
    }
  }
  case TAG_SRecord: {
    V v_ft_2415 = heff_field(v_t_241, 1);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2415, 2)));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0, 2, 1, (V[]){v_d_240}); V a_2 = v_t_2417; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  }
  case TAG_SSum: {
    V v_vs_2420 = heff_field(v_t_241, 0);
    V v_t_2421 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2420, 0)));
    V v_t_2422 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2420, 2)));
    V v_t_2423 = (g_heff_2eutil_2edict_2ezipKV(v_t_2421, v_t_2422));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2423; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2423); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2428 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2428;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2429 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2429;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFixed: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0(V self, V *args) {
  V v_i_2418 = args[0];
  V v_ty_2419 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = heff_intAdd(v_d_240, v_i_2418); V a_1 = v_ty_2419; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_ty_2419); r_; });
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2(V self, V *args) {
  V v_t_2427 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2427; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_t_2427); r_; });
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1(V self, V *args) {
  V v_x3_2424 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2424)) {
  case TAG_MkPair: {
    V v_args_2426 = heff_field(v_x3_2424, 1);
    heff_take_n(v_x3_2424, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(v_args_2426); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2424);
  }
}
Clo g_heff_2eelab_2erules_2eintoSilent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintoSilent_entry, 7, 0};

V g_heff_2eelab_2erules_2eintoSilent(V v_e_240, V v_implicit_241, V v_y_242, V v_dom_243, V v_sc_244, V v_v_245, V v_counted_246) {
top: ;
  V v_t_247 = heff_take_field(v_e_240, 2);
  V v_t_2410;
  switch (heff_tag_of(v_t_247)) {
  case TAG_ForNominative: {
    v_t_2410 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_248 = heff_field(v_t_247, 0);
    V v_sp_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24ForDescriptive = heff_take_reuse_n(v_t_247, 3ULL, 2);
    v_t_2410 = heff_tag_at_n(v_ru_24t_247_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_248, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_249, heff_dup(v_v_245)})});
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2411;
  switch (heff_tag_of(v_counted_246)) {
  case TAG_True: {
    v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_e_240, 3)), MK_INT(1LL));
    break;
  }
  case TAG_False: {
    v_t_2411 = heff_dup(heff_rfield(v_e_240, 3));
    break;
  }
  default: heff_nomatch(v_counted_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_implicit_241)) {
  case TAG_Expl: {
    heff_drop(v_y_242);
    heff_drop(v_dom_243);
    heff_drop(v_v_245);
    v_t_2412 = heff_dup(heff_rfield(v_e_240, 5));
    break;
  }
  case TAG_Impl: {
    heff_drop(v_y_242);
    heff_drop(v_dom_243);
    heff_drop(v_v_245);
    v_t_2412 = heff_dup(heff_rfield(v_e_240, 5));
    break;
  }
  case TAG_Inst: {
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_y_242, v_dom_243, v_v_245}), heff_dup(heff_rfield(v_e_240, 5))});
    break;
  }
  default: heff_nomatch(v_implicit_241);
  }
  return ({ V rv_0 = v_sc_244; V rv_2 = v_t_2410; V rv_3 = v_t_2411; V rv_5 = v_t_2412; V rr_ = heff_rec_reuse_n(v_e_240, 18ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2eintoSilent_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eintoSilent(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); heff_drop(a[6]); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args);

static V g_heff_2eelab_2erules_2eerrorOf_val;
static int g_heff_2eelab_2erules_2eerrorOf_st;
static V g_heff_2eelab_2erules_2eerrorOf_init(void) {
  V v_t_240 = (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_a_241 = ({ V a_0 = v_t_240; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_t_240); r_; });
  V v_t_244 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam0, 1, 1, (V[]){v_a_241})});
  V v_t_245 = (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_x_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_t_245); r_; })});
  return heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam2, 2, 1, (V[]){v_x_246});
}
V g_heff_2eelab_2erules_2eerrorOf_get(void) {
  if (g_heff_2eelab_2erules_2eerrorOf_st == 2) return g_heff_2eelab_2erules_2eerrorOf_val;
  if (g_heff_2eelab_2erules_2eerrorOf_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2erules_2eerrorOf_st = 1;
  g_heff_2eelab_2erules_2eerrorOf_val = heff_tr(g_heff_2eelab_2erules_2eerrorOf_init());
  g_heff_2eelab_2erules_2eerrorOf_st = 2;
  return g_heff_2eelab_2erules_2eerrorOf_val;
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args) {
  V v_u_243 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_243);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_242);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_entry, 1, 0};

V g_heff_2eelab_2erules_2edownFrom(V v_n_240) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), (g_heff_2eelab_2erules_2edownFrom(heff_intSub(v_n_240, MK_INT(1LL))))});
  }
}
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom(a[0]);
}
HEFF_STRA(g_heff_2eelab_2erules_2enamesFor_str0, 1, (120));
Clo g_heff_2eelab_2erules_2enamesFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_entry, 1, 0};

V g_heff_2eelab_2erules_2enamesFor(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_t_242 = heff_intShow(heff_intSub(heff_dup(v_n_240), MK_INT(1LL)));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_str0), v_t_242), (g_heff_2eelab_2erules_2enamesFor(heff_intSub(v_n_240, MK_INT(1LL))))});
  }
}
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamesFor(a[0]);
}
HEFF_STRA(g_heff_2eelab_2erules_2efreshMeta_str0, 4, (109, 101, 116, 97));
HEFF_STRA(g_heff_2eelab_2erules_2efreshMeta_str1, 1, (63));
HEFF_STRA(g_heff_2eelab_2erules_2efreshMeta_str2, 2, (32, 40));
HEFF_STRA(g_heff_2eelab_2erules_2efreshMeta_str3, 4, (41, 32, 58, 32));
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam0, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam5, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efreshMeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_entry, 7, 0};

V g_heff_2eelab_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam1, 1, 7, (V[]){v_ty_242, v_len_240, v_name_243, v_sp_244, v_hd_245, heff_dup(v_locals_241), v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efreshMeta(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 4, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_rec_n(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_len_240, v_name_243, v_sp_244});
  V v_mc_2414 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_2411), v_t_2413, heff_take_field(v_c_2412, 3)));
  return ({ V rv_3 = v_mc_2414; V rv_4 = heff_intAdd(v_x_2411, MK_INT(1LL)); V rr_ = heff_rec_reuse_n(v_c_2412, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  return heff_get_n(v_c_2423, 3, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args) {
  V v_u_2428 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2428);
  V v_xs_2429 = (g_heff_2eelab_2erules_2enamesFor(heff_dup(v_len_240)));
  V v_t_2430 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_len_240, v_ty_242));
  V v_t_2431 = ({ V a_0 = v_x_2427; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2427); r_; });
  V v_t_2432 = heff_tr(heff_apply(heff_get_n(v_t_2431, 1, 2), 1, (V[]){v_t_2430}));
  V v_t_2433 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2429; V a_3 = v_t_2432; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); r_; });
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str1), heff_strAppend(heff_intShow(v_x_2411), heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str2), heff_strAppend(v_name_243, heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str3), v_t_2433)))));
}
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args) {
  V v_sp_27_2440 = args[0];
  V v_i_2441 = args[1];
  V v_locals_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_27_2440, ({ V a_0 = v_locals_241; V a_1 = v_i_2441; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_locals_241); r_; })});
}
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args) {
  V v_u_2443 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return v_ty_242;
}
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_locals_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2436);
  V v_t_2437 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(heff_dup(v_len_240), MK_INT(1LL))));
  V v_t_2438 = heff_tag_n(TAG_SMetaApp, 3, (V[]){heff_dup(v_x_2411), heff_arrayFromList(v_t_2437), (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_len_240), heff_dup(v_ty_242)))});
  V v_t_2439 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(v_len_240, MK_INT(1LL))));
  V v_sp_2442 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam9, 2, 1, (V[]){v_locals_241}); V a_1 = NTAG(TAG_SpId); V a_2 = v_t_2439; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
  V v_t_2444 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HMeta, 1, (V[]){v_x_2411}), v_sp_2442, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam10, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_x_2445 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2438, v_t_2444});
  V f_ = v_k_246;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_244, ((V)&g_heff_2eelab_2erules_2efreshMeta_str0), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam7, 1, 5, (V[]){heff_dup(v_len_240), heff_dup(v_ty_242), v_x_2427, heff_dup(v_x_2411), v_name_243})}), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2435, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam8, 1, 5, (V[]){v_len_240, v_x_2411, v_ty_242, v_locals_241, v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2422);
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2425}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2426, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam6, 1, 8, (V[]){v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_hd_245, v_locals_241, v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2421, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam4, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_locals_241, v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_locals_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam2, 1, 5, (V[]){heff_dup(v_ty_242), heff_dup(v_len_240), heff_dup(v_name_243), heff_dup(v_sp_244), heff_dup(v_x_2411)})})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2416}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2417, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam3, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_locals_241, v_k_246})});
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efillHole_entry, 6, 0};

V g_heff_2eelab_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam0, 1, 4, (V[]){v_e_242, v_argStx_243, v_g_240, v_m_241})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam1, 1, 2, (V[]){v_hd_244, v_k_245})});
}
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_s_247 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), heff_dup(v_argStx_243)));
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), v_s_247, NTAG(TAG_LNil)));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){(g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), v_argStx_243))});
  V v_t_2414 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}); V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_e_242, 57ULL, 6, shape_ty__sol__solStx__arity__name__span); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_mc_2415 = (g_map_2einsert_24s1689409319x1710080871(v_m_241, v_t_2414, heff_take_field(v_c_246, 3)));
  return ({ V rv_3 = v_mc_2415; V rr_ = heff_rec_reuse_n(v_c_246, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2422, v_k_245});
}
HEFF_STRA(g_heff_2eelab_2erules_2esolveHole_str0, 5, (115, 111, 108, 118, 101));
HEFF_STRA(g_heff_2eelab_2erules_2esolveHole_str1, 1, (63));
HEFF_STRA(g_heff_2eelab_2erules_2esolveHole_str2, 2, (32, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esolveHole_str3, 5, (41, 32, 58, 61, 32));
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam0, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam3, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esolveHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_entry, 8, 0};

V g_heff_2eelab_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam1, 1, 8, (V[]){v_m_242, v_g_240, v_cs_241, v_holeVal_243, v_argVal_245, v_hd_246, v_k_247, v_argStx_244})});
}
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esolveHole(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get_n(v_c_2418, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args) {
  V v_u_2423 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2423);
  V v_t_2424 = (g_heff_2eelab_2eunify_2elamsU(heff_take_field(v_e_2415, 3), v_argStx_244));
  V v_t_2425 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2422); r_; });
  V v_e_2426 = heff_tr(heff_apply(heff_get_n(v_t_2425, 0, 2), 1, (V[]){v_t_2424}));
  V v_t_2427 = (g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2426));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str1), heff_strAppend(heff_intShow(v_m_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str2), heff_strAppend(heff_get_n(v_e_2415, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str3), v_t_2427)))));
}
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_247;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2428 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_2415, 5)), ((V)&g_heff_2eelab_2erules_2esolveHole_str0), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam5, 1, 4, (V[]){v_e_2415, v_argStx_244, v_x_2422, v_m_242})});
  V v_t_2429 = heff_tag_n(TAG_Trace, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2430, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam6, 1, 1, (V[]){v_k_247})});
}
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_e_2415 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam3_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2420}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2421, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam4, 1, 5, (V[]){v_e_2415, v_argStx_244, v_m_242, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_argVal_245 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_argStx_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = ({ V a_0 = heff_dup(v_m_242); V a_1 = v_x_2412; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_m_242);
    heff_drop(v_argStx_244);
    V v_t_2414 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
    return (g_heff_2eelab_2emeta_2eliftU(v_t_2414, v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2416 = heff_dup(heff_rfield(v_e_2415, 1));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop(v_cs_241);
      heff_drop(v_holeVal_243);
      heff_drop(v_argVal_245);
      return (g_heff_2eelab_2erules_2efillHole(v_g_240, heff_dup(v_m_242), heff_dup(v_e_2415), heff_dup(v_argStx_244), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam2, 1, 5, (V[]){v_hd_246, v_e_2415, v_argStx_244, v_m_242, v_k_247})));
    }
    case TAG_Just: {
      heff_take_n(v_t_2416, 0ULL, 1);
      heff_drop(v_m_242);
      heff_drop(v_argStx_244);
      heff_drop_rec(v_e_2415, 6);
      V v_t_2434 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2434, v_hd_246, v_k_247));
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStr_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_242, v_t_241));
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStr_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2411 = heff_tr(heff_apply(heff_get_n(v_t_2410, 1, 2), 1, (V[]){v_t_243}));
  V v_t_2412 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V a_3 = v_t_2411; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 6);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrM_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStrM(V v_e_240, V v_m_241) {
top: ;
  V v_t_248 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrM_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_249 = heff_tr(heff_apply(heff_get_n(v_t_248, 1, 2), 1, (V[]){heff_get_n(v_m_241, 0, 2)}));
  V v_t_2410 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2410; V a_3 = v_t_249; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrM(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_243 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_242)));
  V v_t_244 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 6);
  V v_t_245 = ({ V a_0 = v_t_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_x2_246 = ({ V a_0 = v_t_245; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_245); r_; });
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    return v_d_243;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    heff_drop(v_d_243);
    return v_x_247;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqTyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqTyStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_take_field(v_cs_241, 0), v_t_242));
  V v_t_249 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqTyStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_t_2410 = heff_tr(heff_apply(heff_get_n(v_t_249, 1, 2), 1, (V[]){v_t_243}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_cs_241, 1, 2); V a_3 = v_t_2410; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
}
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqTyStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqElStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqElStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242) {
top: ;
  V v_e_243 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_241, 0), v_v_242));
  V v_t_249 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqElStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2410 = heff_tr(heff_apply(heff_get_n(v_t_249, 0, 2), 1, (V[]){v_e_243}));
  return (g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_241, 1, 2), v_e_2410));
}
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqElStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqBareStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqBareStr_entry, 4, 0};

V g_heff_2eelab_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243) {
top: ;
  V v_e_244 = (g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(heff_take_field(v_cs_241, 0), v_h_242, v_sp_243));
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqBareStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2411 = heff_tr(heff_apply(heff_get_n(v_t_2410, 0, 2), 1, (V[]){v_e_244}));
  HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_241, 1, 2), v_e_2411);
}
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqBareStr(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_246 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_245)));
  V v_t_247 = ({ V b_0 = heff_get_n(v_g_240, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_245; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_246;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_246);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str0, 6, (116, 121, 112, 101, 115, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str1, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str2, 15, (32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str3, 9, (101, 108, 101, 109, 101, 110, 116, 115, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str4, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str5, 15, (32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str6, 9, (110, 101, 117, 116, 114, 97, 108, 115, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str7, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str8, 15, (32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eprettyEqErr_str9, 47, (97, 32, 115, 111, 108, 117, 116, 105, 111, 110, 32, 119, 111, 117, 108, 100, 32, 109, 101, 110, 116, 105, 111, 110, 32, 119, 104, 97, 116, 32, 100, 105, 100, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101));
Clo g_heff_2eelab_2erules_2eprettyEqErr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprettyEqErr_entry, 2, 0};

V g_heff_2eelab_2erules_2eprettyEqErr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_UnequalTys: {
    V v_cs_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_a2_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2eeqTyStr(heff_dup(v_g_240), heff_dup(v_cs_242), heff_dup(v_a_243)));
    V v_t_246 = (g_heff_2eelab_2erules_2eeqTyStr(v_g_240, heff_dup(v_cs_242), heff_dup(v_a2_244)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str1), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str2)))));
  }
  case TAG_UnequalEls: {
    V v_cs_247 = heff_field(v_x2_241, 0);
    V v_a_248 = heff_field(v_x2_241, 1);
    V v_a2_249 = heff_field(v_x2_241, 2);
    V v_t_2410 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_g_240), heff_dup(v_cs_247), heff_dup(v_a_248)));
    V v_t_2411 = (g_heff_2eelab_2erules_2eeqElStr(v_g_240, heff_dup(v_cs_247), heff_dup(v_a2_249)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str3), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str4), heff_strAppend(v_t_2411, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str5)))));
  }
  case TAG_UnequalNeus: {
    V v_cs_2412 = heff_field(v_x2_241, 0);
    V v_h_2413 = heff_field(v_x2_241, 1);
    V v_sp_2414 = heff_field(v_x2_241, 2);
    V v_h2_2415 = heff_field(v_x2_241, 3);
    V v_sp2_2416 = heff_field(v_x2_241, 4);
    V v_t_2417 = (g_heff_2eelab_2erules_2eeqBareStr(heff_dup(v_g_240), heff_dup(v_cs_2412), heff_dup(v_h_2413), heff_dup(v_sp_2414)));
    V v_t_2418 = (g_heff_2eelab_2erules_2eeqBareStr(v_g_240, heff_dup(v_cs_2412), heff_dup(v_h2_2415), heff_dup(v_sp2_2416)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str6), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str7), heff_strAppend(v_t_2418, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str8)))));
  }
  case TAG_MentionsError: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str9);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eprettyEqErr(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etyStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_lam0, 1, 0};
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_entry, 4, 0};

V g_heff_2eelab_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etyStrZ_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_246}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam1, 1, 3, (V[]){v_e_240, v_t_241, v_k_243})});
}
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get_n(v_c_244, 3, 8);
}
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2414 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2413)));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 6);
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_x2_2417 = ({ V a_0 = v_t_2416; V a_1 = v_x_2413; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2416); r_; });
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nothing: {
    return v_d_2414;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    heff_drop(v_d_2414);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_249, v_t_241));
  V v_t_2411 = ({ V a_0 = v_x_248; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_248); r_; });
  V v_t_2412 = heff_tr(heff_apply(heff_get_n(v_t_2411, 1, 2), 1, (V[]){v_t_2410}));
  V v_t_2419 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam2, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2420 = heff_tr(heff_apply(heff_get_n(v_t_2419, 1, 2), 1, (V[]){v_t_2412}));
  V v_t_2421 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  V v_x_2422 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2421; V a_3 = v_t_2420; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); r_; });
  V f_ = v_k_243;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ekeepRecovered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ekeepRecovered_entry, 5, 0};

V g_heff_2eelab_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam0, 1, 1, (V[]){v_kept_240})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam1, 1, 4, (V[]){v_hd_243, v_saved_241, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ekeepRecovered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_kept_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_kept_240, heff_take_field(v_c_245, 1)});
  return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_n(v_c_245, 253ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args) {
  V v_c_2415 = args[0];
  V v_saved_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_5 = heff_get_n(v_saved_241, 5, 8); V rr_ = heff_rec_reuse_n(v_c_2415, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_RestoreDelayed, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_243, 1, 3), 2, (V[]){v_t_2426, v_k_244});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_waiting_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam5, 1, 3, (V[]){v_waiting_242, v_hd_243, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_saved_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam3, 1, 1, (V[]){v_saved_241})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2417}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam4, 1, 3, (V[]){v_hd_243, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_saved_241 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam2, 1, 4, (V[]){v_saved_241, v_hd_243, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecoverWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecoverWith_entry, 7, 0};

V g_heff_2eelab_2erules_2erecoverWith(V v_e_240, V v_a_241, V v_d_242, V v_saved_243, V v_waiting_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_241), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam0, 1, 6, (V[]){v_d_242, v_saved_243, v_waiting_244, v_hd_245, v_a_241, v_k_246})));
}
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecoverWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args) {
  V v_u_2412 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_a_241;
}
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam3, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2410);
  V v_t_2413 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam2, 1, 1, (V[]){v_a_241})});
  V f_ = v_k_246;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_saved_243 = heff_env(self)[1];
  V v_waiting_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248;
  switch (heff_tag_of(v_x_247)) {
  case TAG_True: {
    v_t_248 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_n(v_d_242, 30ULL, 5, shape_code__severity__msg__span__note); heff_rfield(rr_, 0) = rv_0; rr_; });
    break;
  }
  case TAG_False: {
    v_t_248 = v_d_242;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2ekeepRecovered_clo), 3, (V[]){v_t_248, v_saved_243, v_waiting_244}));
  return heff_tail(v_c_249, 2, (V[]){v_hd_245, heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam1, 1, 2, (V[]){v_a_241, v_k_246})});
}
V g_heff_2eelab_2erules_2erecovering_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_lam1, 1, 0};
V g_heff_2eelab_2erules_2erecovering_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_lam3, 1, 0};
V g_heff_2eelab_2erules_2erecovering_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecovering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_entry, 1, 0};

V g_heff_2eelab_2erules_2erecovering(V v_c_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecovering(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2erecovering_lam1(V self, V *args) {
  V v_c0_245 = args[0];
  return v_c0_245;
}
V g_heff_2eelab_2erules_2erecovering_lam3(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2erecovering_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_241; V a_1 = v_a_242; V a_2 = v_s_2417; V a_3 = v_x_249; V a_4 = v_x_2413; V a_5 = heff_dup(v_hd_243); V a_6 = heff_get_n(v_hd_243, 0, 3); V r_ = (g_heff_2eelab_2erules_2erecoverWith(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_e_241); r_; });
}
V g_heff_2eelab_2erules_2erecovering_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2415;
  switch (heff_tag_of(v_c_240)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    v_m_2415 = heff_tr(heff_apply(v_f_2414, 2, (V[]){heff_dup(v_e_241), heff_dup(v_a_242)}));
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  V v_t_2416 = heff_tr(heff_apply(v_m_2415, 2, (V[]){heff_dup(v_hd_243), heff_dup(heff_rfield(v_hd_243, 0))}));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam5, 1, 5, (V[]){v_e_241, v_a_242, v_x_249, v_x_2413, heff_dup(v_hd_243)})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_243, 1, 3), 2, (V[]){v_t_2420, v_k_244});
}
V g_heff_2eelab_2erules_2erecovering_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam4, 1, 6, (V[]){v_c_240, v_e_241, v_a_242, v_hd_243, v_x_249, v_k_244})});
}
V g_heff_2eelab_2erules_2erecovering_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam2, 1, 5, (V[]){v_hd_243, v_c_240, v_e_241, v_a_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstShown_entry, 3, 0};

V g_heff_2eelab_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_244 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_243, v_goal_242));
  V v_t_245 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_t_246 = heff_tr(heff_apply(heff_get_n(v_t_245, 1, 2), 1, (V[]){v_t_244}));
  V v_t_2413 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2einstShown_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2414 = heff_tr(heff_apply(heff_get_n(v_t_2413, 1, 2), 1, (V[]){v_t_246}));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2einstShown(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 6);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_x2_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_247; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2410); r_; });
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    return v_d_248;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    heff_drop(v_d_248);
    return v_x_2412;
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ewitnessMatches_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewitnessMatches_lam0, 2, 0};
V g_heff_2eelab_2erules_2ewitnessMatches_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ewitnessMatches_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ewitnessMatches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewitnessMatches_entry, 3, 0};

V g_heff_2eelab_2erules_2ewitnessMatches(V v_e_240, V v_goal_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_goal_241);
    return ((V)&g_heff_2eelab_2erules_2ewitnessMatches_lam0_clo);
  }
  case TAG_Cons: {
    V v_w_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = heff_dup(heff_rfield(v_e_240, 0));
    V v_cs_248 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_247, 0), heff_get_n(v_c_247, 1, 4)});
    V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_dup(heff_rfield(v_e_240, 1)), v_cs_248, heff_dup(v_goal_241), heff_dup(heff_rfield(v_w_245, 1))}));
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_249}));
    V v_c_2411 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eattempt_clo), 1, (V[]){v_t_2410}));
    return heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam1, 2, 5, (V[]){v_c_2411, v_e_240, v_goal_241, v_rest_246, v_w_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewitnessMatches(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_w_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_drop_rec(v_w_245, 4);
    V f_ = v_k_2413;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V f_ = v_k_2413;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_w_245, v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  V v_w_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = (g_heff_2eelab_2erules_2ewitnessMatches(v_e_240, v_goal_241, v_rest_246));
  return heff_tail(v_c_2415, 2, (V[]){v_hd_2412, heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam3, 1, 3, (V[]){v_x_2414, v_k_2413, v_w_245})});
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_w_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam2, 1, 6, (V[]){v_e_240, v_goal_241, v_rest_246, v_hd_2412, v_k_2413, v_w_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str0, 52, (97, 110, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 39, 115, 32, 116, 121, 112, 101, 32, 105, 115, 32, 110, 111, 116, 32, 100, 101, 116, 101, 114, 109, 105, 110, 101, 100, 32, 104, 101, 114, 101, 58, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str1, 79, (103, 105, 118, 101, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 101, 120, 112, 108, 105, 99, 105, 116, 108, 121, 44, 32, 111, 114, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 115, 111, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 115, 32, 97, 114, 111, 117, 110, 100, 32, 105, 116, 32, 97, 114, 101, 32, 115, 111, 108, 118, 101, 100));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str2, 16, (110, 111, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 114, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str3, 9, (32, 105, 110, 32, 115, 99, 111, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str4, 72, (98, 105, 110, 100, 32, 111, 110, 101, 44, 32, 96, 123, 123, 120, 32, 58, 32, 84, 125, 125, 32, 45, 62, 32, 46, 46, 46, 96, 44, 32, 119, 104, 101, 114, 101, 32, 116, 104, 105, 115, 32, 105, 115, 32, 117, 115, 101, 100, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 105, 116, 58, 32, 96, 40, 120, 32, 58, 61, 32, 101, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str5, 20, (116, 104, 101, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 117, 110, 100, 44, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str6, 19, (44, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 102, 105, 116, 32, 104, 101, 114, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str7, 8, (105, 110, 115, 116, 97, 110, 99, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str8, 6, (102, 111, 117, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str9, 3, (32, 58, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str10, 0, (0));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str11, 2, (44, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str12, 27, (109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 114, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str13, 11, (32, 105, 110, 32, 115, 99, 111, 112, 101, 58, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eresolveWanted_str14, 100, (116, 104, 101, 121, 32, 99, 97, 110, 110, 111, 116, 32, 98, 101, 32, 116, 111, 108, 100, 32, 97, 112, 97, 114, 116, 32, 98, 121, 32, 116, 121, 112, 101, 32, 40, 115, 109, 97, 108, 108, 32, 118, 97, 108, 117, 101, 115, 32, 97, 114, 101, 32, 115, 116, 97, 116, 105, 99, 97, 108, 108, 121, 32, 111, 112, 97, 113, 117, 101, 41, 58, 32, 103, 105, 118, 101, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 101, 120, 112, 108, 105, 99, 105, 116, 108, 121));
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam0, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eresolveWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_entry, 8, 0};

V g_heff_2eelab_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_final_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam1, 1, 8, (V[]){v_e_240, v_goal_244, heff_dup(v_final_245), v_sp_241, v_hd_246, v_k_247, v_hm_242, v_holeVal_243})});
}
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eresolveWanted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[5]); return r;
}
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args) {
  V v_c_2425 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_stx_2427 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_2426, heff_dup(heff_rfield(v_c_2425, 2))));
  return heff_rec_n(4, shape_name__ty__stx__val, (V[]){heff_dup(heff_rfield(v_c_2425, 0)), heff_dup(heff_rfield(v_c_2425, 1)), v_stx_2427, heff_get_n(v_c_2425, 2, 3)});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_one_2437 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2451);
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str8), heff_strAppend(heff_get_n(v_one_2437, 0, 4), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str9), ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; }))));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_one_2437 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_err_2443 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_goal_244);
    V v_note_2444 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2443; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2443); r_; });
    V v_t_2445 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str5), heff_strAppend(heff_get_n(v_one_2437, 0, 4), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str6)));
    V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2445, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2444})});
    V v_t_2447 = heff_tag_at_n(v_ru_24x_2442_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2449, v_k_247});
  }
  case TAG_Right: {
    heff_take_n(v_x_2442, 0ULL, 1);
    V v_t_2452 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str7), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam5, 1, 4, (V[]){v_one_2437, v_e_240, v_x_2412, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2453, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam6, 1, 1, (V[]){v_k_247})});
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_goal_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_hm_242 = heff_env(self)[6];
  V v_holeVal_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nil: {
    heff_drop(v_hm_242);
    heff_drop(v_holeVal_243);
    V v_t_2431 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
    V v_msg_2432 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str2), heff_strAppend(v_t_2431, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str3)));
    V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(341LL), NTAG(TAG_SError), v_msg_2432, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str4)})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2436, v_k_247});
  }
  case TAG_Cons: {
    V v_one_2437 = heff_dup(heff_field(v_x_2430, 0));
    V v_it2_2438 = heff_dup(heff_field(v_x_2430, 1));
    switch (heff_tag_of(v_it2_2438)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2430, 2);
      V v_c_2439 = heff_dup(heff_rfield(v_e_240, 0));
      V v_t_2440 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2439, 0), heff_get_n(v_c_2439, 1, 4)});
      V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2esolveHole_clo), 6, (V[]){heff_dup(heff_rfield(v_e_240, 1)), v_t_2440, v_hm_242, v_holeVal_243, heff_dup(heff_rfield(v_one_2437, 2)), heff_dup(heff_rfield(v_one_2437, 3))}));
      return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam4, 1, 7, (V[]){v_e_240, v_one_2437, v_sp_241, v_hd_246, v_k_247, v_x_2412, v_goal_244})});
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2438, 0ULL, 2);
      heff_drop(v_hm_242);
      heff_drop(v_holeVal_243);
      heff_drop_rec(v_one_2437, 4);
      V v_t_2457 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
      V v_x2_2458 = (g_list_2emap_24s76631343x1276310171(v_x_2430));
      V v_t_2461;
      switch (heff_tag_of(v_x2_2458)) {
      case TAG_Nil: {
        v_t_2461 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str10);
        break;
      }
      case TAG_Cons: {
        V v_x_2459 = heff_field(v_x2_2458, 0);
        V v_xs_2460 = heff_field(v_x2_2458, 1);
        heff_take_n(v_x2_2458, 3ULL, 2);
        v_t_2461 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str11); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2458);
      }
      V v_msg_2462 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str12), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str13), v_t_2461)));
      V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(342LL), NTAG(TAG_SError), v_msg_2462, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str14)})});
      V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2465}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2466, v_k_247});
    }
    default: return heff_nomatch(v_it2_2438);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_244 = heff_env(self)[1];
  V v_final_245 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_hm_242 = heff_env(self)[6];
  V v_holeVal_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = (g_heff_2eelab_2eunify_2emetasK(v_x_2412));
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_x1_2415 = heff_tr(heff_apply(heff_get_n(v_t_2413, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2414, heff_dup(v_goal_244)}));
  V v_x1_2418;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    v_x1_2418 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_x1_2418 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_True: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2419 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    heff_drop(v_hm_242);
    heff_drop(v_holeVal_243);
    switch (heff_tag_of(v_final_245)) {
    case TAG_True: {
      V v_msg_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str0), ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; }));
      V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(340LL), NTAG(TAG_SError), v_msg_2420, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str1)})});
      V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2423}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2424, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_x_2412);
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_goal_244);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_246, 3);
      V f_ = v_k_247;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_final_245);
    }
  }
  case TAG_False: {
    heff_drop(v_final_245);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam2, 1, 1, (V[]){heff_dup(v_e_240)}), heff_dup(heff_rfield(v_e_240, 5))));
    V v_c_2429 = (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_goal_244), v_t_2428));
    return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam3, 1, 8, (V[]){v_e_240, v_x_2412, v_goal_244, v_sp_241, v_hd_246, v_k_247, v_hm_242, v_holeVal_243})});
  }
  default: return heff_nomatch(v_t_2419);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2einsertInstance_str0, 8, (105, 110, 115, 116, 97, 110, 99, 101));
HEFF_STRA(g_heff_2eelab_2erules_2einsertInstance_str1, 21, (32, 32, 91, 114, 101, 97, 100, 121, 32, 97, 116, 32, 116, 104, 101, 32, 99, 97, 108, 108, 93));
HEFF_STRA(g_heff_2eelab_2erules_2einsertInstance_str2, 23, (32, 32, 91, 119, 97, 105, 116, 115, 32, 102, 111, 114, 32, 105, 109, 112, 108, 105, 99, 105, 116, 115, 93));
HEFF_STRA(g_heff_2eelab_2erules_2einsertInstance_str3, 7, (119, 97, 110, 116, 101, 100, 32));
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam1, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_246; V a_1 = v_t_247; V a_2 = heff_dup(v_goal_242); V a_3 = v_name_243; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_244); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam0, 1, 5, (V[]){v_hd_244, v_sp_241, v_e_240, v_goal_242, v_k_245}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
}
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertInstance(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args) {
  V v_u_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2414);
  V v_t_2415 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)));
  V v_t_2416 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2413); r_; });
  V v_t_2417 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_x1_2418 = heff_tr(heff_apply(heff_get_n(v_t_2416, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2417, v_goal_242}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str1);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2418, 0ULL, 2);
    v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str2);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2einsertInstance_str3), heff_strAppend(v_t_2415, v_t_2421));
}
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args) {
  V v_b_2425 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_take_field(v_x_248, 0);
  V v_t_2461;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2426, 0ULL, 3);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2451 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 3);
    v_t_2461 = v_k_2451;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2461 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V v_c_2462 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 6, (V[]){v_e_240, v_sp_241, v_t_2461, heff_get_n(v_x_248, 1, 2), v_goal_242, v_b_2425}));
  return heff_tail(v_c_2462, 2, (V[]){heff_dup(v_hd_244), heff_get_n(v_hd_244, 0, 3)});
}
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args) {
  V v_u_2467 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_248, 1, 2)});
}
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2468 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam7, 1, 1, (V[]){heff_dup(v_x_248)}); V rr_ = heff_rec_reuse_n(v_x_248, 1ULL, 2, shape_stx__val); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2424);
  V v_t_2463 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam5, 1, 5, (V[]){heff_dup(v_x_248), v_e_240, v_sp_241, v_goal_242, heff_dup(v_hd_244)}), NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2464}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2465, heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam6, 1, 2, (V[]){v_x_248, v_k_245})});
}
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2einsertInstance_str0), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam3, 1, 3, (V[]){heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)})}), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2423, heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam4, 1, 6, (V[]){v_sp_241, v_x_248, v_e_240, v_goal_242, v_hd_244, v_k_245})});
}
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam2, 1, 6, (V[]){v_sp_241, v_e_240, v_goal_242, v_hd_244, v_x_248, v_k_245})});
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitArg_entry, 5, 0};

V g_heff_2eelab_2erules_2eimplicitArg(V v_e_240, V v_sp_241, V v_ty_242, V v_dom_243, V v_x_244) {
top: ;
  V v_t_245 = (g_heff_2eelab_2evalue_2eimplicitDefault(v_ty_242));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam0, 2, 4, (V[]){v_e_240, v_dom_243, v_x_244, v_sp_241});
  }
  case TAG_Just: {
    V v_d_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_dom_243);
    heff_drop(v_x_244);
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam3, 2, 2, (V[]){v_d_2413, v_e_240});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitArg(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam2, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_n(v_x_2410, 1ULL, 2, shape_stx__val); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_dom_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 0, 6), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = v_dom_243; V a_3 = v_x_244; V a_4 = v_sp_241; V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam1, 1, 1, (V[]){v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_get_n(v_e_240, 1, 6), NTAG(TAG_N), v_d_2413, NTAG(TAG_LNil)));
}
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2413), heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam4, 1, 2, (V[]){v_e_240, v_d_2413})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2einsertImplicits_str0, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2einsertImplicits_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2einsertImplicits_str2, 1, (95));
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertImplicits_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam0, 1, 1, (V[]){v_ty0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam1, 1, 5, (V[]){v_k_245, v_m_242, v_e_240, v_sp_241, v_hd_244})});
}
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertImplicits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ty0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_ty0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_apply(heff_get_n(v_x_2423, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2424 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2428 = v_n_2424;
    break;
  }
  case TAG_CloConst: {
    v_t_2428 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2428, v_m_242, heff_dup(v_x_2423)));
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2415, 1);
    V v_body_2432 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam3, 1, 1, (V[]){v_x_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2423, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2429, v_t_2443, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args) {
  V v_u_2455 = args[0];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2455);
  V v_x1_2456 = heff_tr(heff_apply(heff_get_n(v_x_2450, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2456)) {
  case TAG_Nom: {
    V v_x_2457 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2457;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2456, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2459 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2459;
  }
  default: return heff_nomatch(v_x1_2456);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2451 = (g_heff_2eelab_2ememoed_2eapp(v_m_242, heff_dup(v_x_2450)));
  V v_x1_2461;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2453 = heff_field(v_cod_2415, 1);
    V v_body_2454 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2461 = heff_tr(heff_apply(v_body_2454, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2453, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam5, 1, 1, (V[]){v_x_2450})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2460 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2450, 2);
    v_x1_2461 = v_body_2460;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2465;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Nom: {
    V v_x_2462 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2462;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2465 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2464 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2464;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2451, v_t_2465, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_it_2411)) {
  case TAG_LikeU: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_it_2411, 1);
    V v_cod_2415 = heff_field(v_it_2411, 2);
    V v_it4_2416 = heff_field(v_it_2411, 3);
    heff_take_n(v_it_2411, 14ULL, 4);
    switch (heff_tag_of(v_it4_2416)) {
    case TAG_Expl: {
      heff_drop(v_e_240);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Impl: {
      V v_t_2421;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2417 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2421 = v_n_2417;
        break;
      }
      case TAG_CloConst: {
        v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2422 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_x_2410, v_dom_2414, v_t_2421));
      return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam2, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245})});
    }
    case TAG_Inst: {
      heff_drop(v_x_2410);
      V v_t_2448;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2444 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2448 = v_n_2444;
        break;
      }
      case TAG_CloConst: {
        v_t_2448 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str2);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2449 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2einsertInstance_clo), 4, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), v_dom_2414, v_t_2448}));
      return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam4, 1, 6, (V[]){v_m_242, v_cod_2415, v_e_240, v_sp_241, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it4_2416);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_it_2411, 0ULL, 3);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_it_2411);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2eimplicitDefaultChk_str0, 83, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 39, 115, 32, 100, 101, 102, 97, 117, 108, 116, 32, 110, 97, 109, 101, 115, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 32, 111, 110, 108, 121, 44, 32, 110, 111, 116, 32, 116, 104, 101, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 115, 32, 98, 101, 102, 111, 114, 101, 32, 105, 116));
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3, 1, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultChk_entry, 2, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultChk(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0, 2, 2, (V[]){heff_dup(v_c_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eimplicitDefaultChk(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3(V self, V *args) {
  V v_c0_249 = args[0];
  return heff_get_n(v_c0_249, 3, 8);
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2413); r_; });
  V v_stx_2415 = heff_tr(heff_apply(heff_get_n(v_t_2414, 0, 2), 1, (V[]){heff_take_field(v_x_248, 0)}));
  V v_t_2416 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(MK_INT(0LL), v_stx_2415));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop_rec(v_x_248, 2);
    heff_drop(v_stx_2415);
    V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(345LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eimplicitDefaultChk_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2420, v_k_247});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2421 = ({ V rv_0 = v_stx_2415; V rr_ = heff_rec_reuse_n(v_x_248, 2ULL, 2, shape_stx__val); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_247;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4, 1, 4, (V[]){v_x_248, v_sp_240, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2, 1, 3, (V[]){v_hd_246, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_c_241)) {
  case TAG_MkChk: {
    V v_f_244 = heff_field(v_c_241, 0);
    heff_take_n(v_c_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 2, (V[]){v_e_242, v_a_243}));
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1, 2, 2, (V[]){v_c_245, v_sp_240});
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_entry, 3, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultAt(V v_e_240, V v_ty_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_ty_241, 2);
    return ((V)&g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(heff_get_n(v_ty_241, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2410;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_247;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_a_2410 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2411 = ({ V a_0 = heff_take_field(v_d_245, 1); V b_1 = heff_get_n(v_d_245, 0, 2); V r_ = (g_heff_2eelab_2erules_2eimplicitDefaultChk(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_t_2411); r_; });
    V v_c_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkChk: {
      V v_f_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2414 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_c_2415 = heff_tr(heff_apply(v_f_2413, 2, (V[]){v_t_2414, v_a_2410}));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1, 2, 1, (V[]){v_c_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitDefaultAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2418, 0, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2efunctionFormation_str0, 137, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 119, 105, 116, 104, 111, 117, 116, 32, 97, 32, 100, 101, 102, 97, 117, 108, 116, 32, 109, 117, 115, 116, 32, 104, 97, 118, 101, 32, 97, 32, 108, 97, 114, 103, 101, 32, 116, 121, 112, 101, 32, 40, 97, 32, 115, 109, 97, 108, 108, 32, 111, 110, 101, 32, 99, 111, 117, 108, 100, 32, 110, 101, 118, 101, 114, 32, 98, 101, 32, 105, 110, 102, 101, 114, 114, 101, 100, 58, 32, 105, 116, 115, 32, 118, 97, 108, 117, 101, 115, 32, 97, 114, 101, 32, 115, 116, 97, 116, 105, 99, 97, 108, 108, 121, 32, 105, 114, 114, 101, 108, 101, 118, 97, 110, 116, 41));
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_entry, 2, 0};

V g_heff_2eelab_2erules_2efunctionFormation(V v_x1_240, V v_cod_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Anonymous: {
    V v_dom_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Anonymous = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24Anonymous, TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam0, 1, 2, (V[]){v_dom_242, heff_dup(v_cod_241)})});
  }
  case TAG_Named: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    V v_dom_2415 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam4, 1, 3, (V[]){v_dom_2415, v_x_2414, heff_dup(v_cod_241)})});
  }
  case TAG_NamedImplicit: {
    V v_sp_2434 = heff_field(v_x1_240, 0);
    V v_x_2435 = heff_field(v_x1_240, 1);
    V v_dom_2436 = heff_field(v_x1_240, 2);
    V v_dflt_2437 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam8, 1, 5, (V[]){v_dom_2436, v_dflt_2437, v_sp_2434, v_x_2435, heff_dup(v_cod_241)})});
  }
  case TAG_NamedInstance: {
    V v_x_2471 = heff_field(v_x1_240, 1);
    V v_dom_2472 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam13, 1, 3, (V[]){v_dom_2472, v_x_2471, heff_dup(v_cod_241)})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionFormation(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_x_2413 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_243, 1, 6), v_t_2412, v_x_248, heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2411})));
  V f_ = v_k_247;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_cod_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_249 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2410 = heff_tr(heff_apply(v_f_249, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2410, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam3, 1, 3, (V[]){v_e_243, v_x_248, v_k_247})});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam2, 1, 4, (V[]){v_cod_241, v_e_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_242 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_242, 0);
    heff_take_n(v_dom_242, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam1, 2, 3, (V[]){v_c_245, v_cod_241, v_e_243});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_2416, 0)), 2, 4);
  V v_x_2433 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_2416, 1, 6), v_t_2432, v_x_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2414, v_x_2431})));
  V f_ = v_k_2420;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2422 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2421, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_sc_2427 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2414), v_t_2426, heff_dup(heff_rfield(v_e_2416, 0))));
  V v_e_2428 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2427, heff_dup(heff_rfield(v_e_2416, 1)), heff_dup(heff_rfield(v_e_2416, 2)), heff_dup(heff_rfield(v_e_2416, 3)), heff_dup(heff_rfield(v_e_2416, 4)), heff_dup(heff_rfield(v_e_2416, 5))});
  V v_c_2430;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2429 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2430 = heff_tr(heff_apply(v_f_2429, 1, (V[]){v_e_2428}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2430, 2, (V[]){v_hd_2419, heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam7, 1, 4, (V[]){v_e_2416, v_x_2421, v_x_2414, v_k_2420})});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_e_2416 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam6, 1, 5, (V[]){v_x_2414, v_e_2416, v_cod_241, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args) {
  V v_e_2416 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2418;
  switch (heff_tag_of(v_dom_2415)) {
  case TAG_MkTyp: {
    V v_f_2417 = heff_field(v_dom_2415, 0);
    heff_take_n(v_dom_2415, 1ULL, 1);
    v_c_2418 = heff_tr(heff_apply(v_f_2417, 1, (V[]){heff_dup(v_e_2416)}));
    break;
  }
  default: heff_nomatch(v_dom_2415);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam5, 2, 4, (V[]){v_c_2418, v_x_2414, v_e_2416, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args) {
  V v_x_2467 = args[0];
  V v_e_2438 = heff_env(self)[0];
  V v_x_2457 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2442 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_e_2438, 0)), 2, 4);
  V v_x_2469 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Impl), v_x_2457, heff_get_n(v_e_2438, 1, 6), v_t_2468, v_x_2443, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2435, v_x_2467})));
  V f_ = v_k_2442;
  args[0] = v_x_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_e_2438 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  V v_hd_2441 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2458 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2462;
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_t_2462 = v_x_2459;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    v_t_2462 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_t_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x1_2458);
  }
  V v_sc_2463 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2435), v_t_2462, heff_dup(heff_rfield(v_e_2438, 0))));
  V v_e_2464 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2463, heff_dup(heff_rfield(v_e_2438, 1)), heff_dup(heff_rfield(v_e_2438, 2)), heff_dup(heff_rfield(v_e_2438, 3)), heff_dup(heff_rfield(v_e_2438, 4)), heff_dup(heff_rfield(v_e_2438, 5))});
  V v_c_2466;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2465 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2466 = heff_tr(heff_apply(v_f_2465, 1, (V[]){v_e_2464}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2466, 2, (V[]){v_hd_2441, heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam12, 1, 5, (V[]){v_e_2438, v_x_2457, v_x_2443, v_x_2435, v_k_2442})});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_dflt_2437 = heff_env(self)[0];
  V v_sp_2434 = heff_env(self)[1];
  V v_hd_2441 = heff_env(self)[2];
  V v_k_2442 = heff_env(self)[3];
  V v_e_2438 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  V v_cod_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2444 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2448;
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_t_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2446 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2446); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2444);
  }
  V v_t_2451;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_Small: {
    V v_x1_2450;
    switch (heff_tag_of(v_dflt_2437)) {
    case TAG_Nothing: {
      v_x1_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      v_x1_2450 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_dflt_2437);
    }
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_True: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2451 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2450);
    }
    break;
  }
  case TAG_Large: {
    v_t_2451 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2451 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  switch (heff_tag_of(v_t_2451)) {
  case TAG_True: {
    heff_drop_rec(v_x_2443, 2);
    heff_drop(v_dflt_2437);
    heff_drop_rec(v_e_2438, 6);
    heff_drop(v_x_2435);
    heff_drop(v_cod_241);
    V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(324LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionFormation_str0), v_sp_2434, NTAG(TAG_Nothing)});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_apply(heff_take_field(v_hd_2441, 2), 1, (V[]){v_t_2454}));
    return heff_tail(heff_get_n(v_hd_2441, 1, 3), 2, (V[]){v_t_2455, v_k_2442});
  }
  case TAG_False: {
    heff_drop(v_sp_2434);
    V v_c_2456 = (g_heff_2eelab_2erules_2eimplicitDefaultAt(heff_dup(v_e_2438), heff_dup(v_x_2443), v_dflt_2437));
    return heff_tail(v_c_2456, 2, (V[]){heff_dup(v_hd_2441), heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam11, 1, 6, (V[]){v_x_2443, v_x_2435, v_e_2438, v_cod_241, v_hd_2441, v_k_2442})});
  }
  default: return heff_nomatch(v_t_2451);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_e_2438 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_cod_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam10, 1, 7, (V[]){v_dflt_2437, v_sp_2434, v_hd_2441, v_k_2442, v_e_2438, v_x_2435, v_cod_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args) {
  V v_e_2438 = args[0];
  V v_dom_2436 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cod_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2440;
  switch (heff_tag_of(v_dom_2436)) {
  case TAG_MkTyp: {
    V v_f_2439 = heff_field(v_dom_2436, 0);
    heff_take_n(v_dom_2436, 1ULL, 1);
    v_c_2440 = heff_tr(heff_apply(v_f_2439, 1, (V[]){heff_dup(v_e_2438)}));
    break;
  }
  default: heff_nomatch(v_dom_2436);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam9, 2, 6, (V[]){v_c_2440, v_dflt_2437, v_sp_2434, v_e_2438, v_x_2435, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_e_2473 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  V v_x_2471 = heff_env(self)[2];
  V v_k_2477 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2489 = heff_get_n(heff_dup(heff_rfield(v_e_2473, 0)), 2, 4);
  V v_x_2490 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Inst), NTAG(TAG_Nothing), heff_get_n(v_e_2473, 1, 6), v_t_2489, v_x_2478, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2471, v_x_2488})));
  V f_ = v_k_2477;
  args[0] = v_x_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args) {
  V v_x_2478 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_e_2473 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2476 = heff_env(self)[3];
  V v_k_2477 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2479 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2478, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2483;
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_Nom: {
    V v_x_2480 = heff_field(v_x1_2479, 0);
    heff_take_n(v_x1_2479, 1ULL, 1);
    v_t_2483 = v_x_2480;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2479, 0ULL, 1);
    v_t_2483 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2482 = heff_field(v_x1_2479, 0);
    heff_take_n(v_x1_2479, 1ULL, 1);
    v_t_2483 = v_x_2482;
    break;
  }
  default: heff_nomatch(v_x1_2479);
  }
  V v_sc_2484 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2471), v_t_2483, heff_dup(heff_rfield(v_e_2473, 0))));
  V v_e_2485 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2484, heff_dup(heff_rfield(v_e_2473, 1)), heff_dup(heff_rfield(v_e_2473, 2)), heff_dup(heff_rfield(v_e_2473, 3)), heff_dup(heff_rfield(v_e_2473, 4)), heff_dup(heff_rfield(v_e_2473, 5))});
  V v_c_2487;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2486 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2487 = heff_tr(heff_apply(v_f_2486, 1, (V[]){v_e_2485}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2487, 2, (V[]){v_hd_2476, heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam16, 1, 4, (V[]){v_e_2473, v_x_2478, v_x_2471, v_k_2477})});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_c_2475 = heff_env(self)[0];
  V v_x_2471 = heff_env(self)[1];
  V v_e_2473 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2475;
  args[0] = heff_dup(v_hd_2476);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam15, 1, 5, (V[]){v_x_2471, v_e_2473, v_cod_241, v_hd_2476, v_k_2477});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args) {
  V v_e_2473 = args[0];
  V v_dom_2472 = heff_env(self)[0];
  V v_x_2471 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2475;
  switch (heff_tag_of(v_dom_2472)) {
  case TAG_MkTyp: {
    V v_f_2474 = heff_field(v_dom_2472, 0);
    heff_take_n(v_dom_2472, 1ULL, 1);
    v_c_2475 = heff_tr(heff_apply(v_f_2474, 1, (V[]){heff_dup(v_e_2473)}));
    break;
  }
  default: heff_nomatch(v_dom_2472);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam14, 2, 4, (V[]){v_c_2475, v_x_2471, v_e_2473, v_cod_241});
}
HEFF_STRA(g_heff_2eelab_2erules_2eimplicitLams_str0, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2eimplicitLams_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2eimplicitLams_str2, 1, (95));
V g_heff_2eelab_2erules_2eimplicitLams_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitLams_entry, 1, 0};

V g_heff_2eelab_2erules_2eimplicitLams(V v_c_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eimplicitLams(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2eimplicitLams_lam1(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eimplicitLams_lam4(V self, V *args) {
  V v_u_2441 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2441);
  return v_v_2424;
}
V g_heff_2eelab_2erules_2eimplicitLams_lam7(V self, V *args) {
  V v_u_2465 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_249});
}
V g_heff_2eelab_2erules_2eimplicitLams_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_cod_2415 = heff_env(self)[2];
  V v_k_2451 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453 = heff_take_field(v_e_241, 2);
  V v_t_2456;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_ForNominative: {
    v_t_2456 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2456 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 0, 4);
  V v_t_2459 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2458, heff_dup(v_x_249)));
  V v_t_2464;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2460 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 3);
    v_t_2464 = v_n_2460;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2415, 0ULL, 1);
    v_t_2464 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str2);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_x_2466 = (g_heff_2eelab_2ememoed_2elam(v_t_2456, heff_get_n(v_e_241, 1, 6), v_t_2457, heff_rec_n(2, shape_stx__val, (V[]){v_t_2459, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam7, 1, 1, (V[]){v_x_249})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2464, v_x_2452})));
  V f_ = v_k_2451;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_lam5(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_cod_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam6, 1, 4, (V[]){v_e_241, v_x_249, v_cod_2415, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_implicit_2416 = heff_env(self)[3];
  V v_dom_2414 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2426 = ({ V a_0 = v_c_240; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_c_240); r_; });
  V v_y_2431;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2427 = heff_dup(heff_field(v_cod_2415, 0));
    v_y_2431 = v_n_2427;
    break;
  }
  case TAG_CloConst: {
    v_y_2431 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2432 = heff_dup(heff_rfield(v_e_241, 2));
  V v_t_2435;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_ForNominative: {
    v_t_2435 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2433 = heff_field(v_t_2432, 0);
    V v_sp_2434 = heff_field(v_t_2432, 1);
    V v_ru_24t_2432_24ForDescriptive = heff_take_reuse_n(v_t_2432, 3ULL, 2);
    v_t_2435 = heff_tag_at_n(v_ru_24t_2432_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2433, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2434, heff_dup(v_v_2424)})});
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  V v_t_2436;
  switch (heff_tag_of(v_implicit_2416)) {
  case TAG_Expl: {
    heff_drop(v_dom_2414);
    heff_drop(v_y_2431);
    v_t_2436 = heff_dup(heff_rfield(v_e_241, 5));
    break;
  }
  case TAG_Impl: {
    heff_drop(v_dom_2414);
    heff_drop(v_y_2431);
    v_t_2436 = heff_dup(heff_rfield(v_e_241, 5));
    break;
  }
  case TAG_Inst: {
    v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_y_2431, v_dom_2414, heff_dup(v_v_2424)}), heff_dup(heff_rfield(v_e_241, 5))});
    break;
  }
  default: heff_nomatch(v_implicit_2416);
  }
  V v_e_2437 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2425, heff_dup(heff_rfield(v_e_241, 1)), v_t_2435, heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), v_t_2436});
  V v_x1_2443;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2439 = heff_dup(heff_field(v_cod_2415, 1));
    V v_body_2440 = heff_dup(heff_field(v_cod_2415, 2));
    v_x1_2443 = heff_tr(heff_apply(v_body_2440, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2439, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam4, 1, 1, (V[]){v_v_2424})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2442 = heff_dup(heff_field(v_cod_2415, 0));
    heff_drop(v_v_2424);
    v_x1_2443 = v_body_2442;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_a_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_a_2447 = v_x_2444;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    v_a_2447 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_a_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  V v_c_2449;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkChk: {
    V v_f_2448 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_c_2449 = heff_tr(heff_apply(v_f_2448, 2, (V[]){v_e_2437, v_a_2447}));
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam5, 2, 4, (V[]){v_c_2449, v_e_241, v_x_249, v_cod_2415});
}
V g_heff_2eelab_2erules_2eimplicitLams_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_249)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2412, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_t_2410, 1);
    V v_cod_2415 = heff_field(v_t_2410, 2);
    V v_implicit_2416 = heff_field(v_t_2410, 3);
    heff_take_n(v_t_2410, 14ULL, 4);
    V v_t_2417;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      heff_drop(v_implicit_2416);
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkChk: {
        V v_f_2418 = heff_field(v_c_240, 0);
        heff_take_n(v_c_240, 1ULL, 1);
        return heff_tail(v_f_2418, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
      }
      default: return heff_nomatch(v_c_240);
      }
    }
    case TAG_False: {
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_t_2467 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2423, heff_dup(v_dom_2414), heff_dup(heff_rfield(v_e_241, 0)), heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam3, 2, 6, (V[]){v_c_240, v_cod_2415, v_e_241, v_implicit_2416, v_dom_2414, v_x_249})));
      return heff_tail(v_t_2467, 2, (V[]){v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2410, 0ULL, 3);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2471 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2471, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2473 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2473, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2474 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2474, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2475 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2475, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2476 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2476, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeRune: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2477 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2477, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2479 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2479, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2481 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2481, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2482 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2482, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a0_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam1, 1, 1, (V[]){v_a0_242})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam2, 1, 4, (V[]){v_c_240, v_e_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str0, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str2, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str3, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str4, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str5, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str6, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str7, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str8, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str9, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str10, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str11, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntro_str12, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2efunctionIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntro_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntro(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionIntro(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntro_lam4(V self, V *args) {
  V v_u_2434 = args[0];
  V v_v_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return v_v_2423;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam7(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2444 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2446 = heff_take_field(v_e_243, 2);
  V v_t_2449;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_ForNominative: {
    v_t_2449 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2446, 0ULL, 2);
    v_t_2449 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2452 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2451, heff_dup(v_x_2411)));
  V v_x_2454 = (g_heff_2eelab_2ememoed_2elam(v_t_2449, heff_get_n(v_e_243, 1, 6), v_t_2450, heff_rec_n(2, shape_stx__val, (V[]){v_t_2452, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2445})));
  V f_ = v_k_2444;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam3(V self, V *args) {
  V v_v_2423 = args[0];
  V v_scope_27_2424 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_cod_2420 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = heff_dup(heff_rfield(v_e_243, 2));
  V v_t_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_ForNominative: {
    v_t_2428 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2426 = heff_field(v_t_2425, 0);
    V v_sp_2427 = heff_field(v_t_2425, 1);
    V v_ru_24t_2425_24ForDescriptive = heff_take_reuse_n(v_t_2425, 3ULL, 2);
    v_t_2428 = heff_tag_at_n(v_ru_24t_2425_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2426, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2427, heff_dup(v_v_2423)})});
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V v_t_2429 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
  V v_e_2430 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2424, heff_dup(heff_rfield(v_e_243, 1)), v_t_2428, v_t_2429, heff_dup(heff_rfield(v_e_243, 4)), heff_dup(heff_rfield(v_e_243, 5))});
  V v_x1_2436;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2432 = heff_field(v_cod_2420, 1);
    V v_body_2433 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2436 = heff_tr(heff_apply(v_body_2433, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2432, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam4, 1, 1, (V[]){v_v_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2435 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    heff_drop(v_v_2423);
    v_x1_2436 = v_body_2435;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_a_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_a_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_a_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_c_2442;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2441 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2442 = heff_tr(heff_apply(v_f_2441, 2, (V[]){v_e_2430, v_a_2440}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam5, 2, 4, (V[]){v_c_2442, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam9(V self, V *args) {
  V v_u_2473 = args[0];
  V v_v_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_v_2461;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam12(V self, V *args) {
  V v_u_2497 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2497);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam11(V self, V *args) {
  V v_x_2484 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_cod_2420 = heff_env(self)[2];
  V v_k_2483 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2485 = heff_take_field(v_e_243, 2);
  V v_t_2488;
  switch (heff_tag_of(v_t_2485)) {
  case TAG_ForNominative: {
    v_t_2488 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2485, 0ULL, 2);
    v_t_2488 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2485);
  }
  V v_t_2489 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2490 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2491 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2490, heff_dup(v_x_2411)));
  V v_t_2496;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_n_2492 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 3);
    v_t_2496 = v_n_2492;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2420, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str3);
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_x_2498 = (g_heff_2eelab_2ememoed_2elam(v_t_2488, heff_get_n(v_e_243, 1, 6), v_t_2489, heff_rec_n(2, shape_stx__val, (V[]){v_t_2491, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam12, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2496, v_x_2484})));
  V f_ = v_k_2483;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam10(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2481;
  args[0] = v_hd_2482;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam11, 1, 4, (V[]){v_e_243, v_x_2411, v_cod_2420, v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam8(V self, V *args) {
  V v_v_2461 = args[0];
  V v_scope_27_2462 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_implicit_2421 = heff_env(self)[5];
  V v_dom_2419 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2463 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_body_242; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_body_242); r_; });
  V v_t_2468;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_n_2464 = heff_dup(heff_field(v_cod_2420, 0));
    v_t_2468 = v_n_2464;
    break;
  }
  case TAG_CloConst: {
    v_t_2468 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str2);
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_e_2469 = ({ V a_0 = heff_dup(v_e_243); V a_1 = v_implicit_2421; V a_2 = v_t_2468; V a_3 = v_dom_2419; V a_4 = v_scope_27_2462; V a_5 = heff_dup(v_v_2461); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2eelab_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2421); heff_drop(b_6); r_; });
  V v_x1_2475;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2471 = heff_dup(heff_field(v_cod_2420, 1));
    V v_body_2472 = heff_dup(heff_field(v_cod_2420, 2));
    v_x1_2475 = heff_tr(heff_apply(v_body_2472, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2471, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam9, 1, 1, (V[]){v_v_2461})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2474 = heff_dup(heff_field(v_cod_2420, 0));
    heff_drop(v_v_2461);
    v_x1_2475 = v_body_2474;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2479;
  switch (heff_tag_of(v_x1_2475)) {
  case TAG_Nom: {
    V v_x_2476 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_a_2479 = v_x_2476;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2475, 0ULL, 1);
    v_a_2479 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2478 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_a_2479 = v_x_2478;
    break;
  }
  default: heff_nomatch(v_x1_2475);
  }
  V v_c_2481;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_MkChk: {
    V v_f_2480 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_c_2481 = heff_tr(heff_apply(v_f_2480, 2, (V[]){v_e_2469, v_a_2479}));
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam10, 2, 4, (V[]){v_c_2481, v_e_243, v_x_2411, v_cod_2420});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2417, v_k_246});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_sp_240);
      heff_drop(v_implicit_2421);
      V v_t_2455 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_dom_2419, heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam3, 2, 5, (V[]){v_e_243, v_cod_2420, v_body_242, v_x_2411, v_x_241})));
      return heff_tail(v_t_2455, 2, (V[]){v_hd_245, v_k_246});
    }
    case TAG_False: {
      V v_t_2460;
      switch (heff_tag_of(v_cod_2420)) {
      case TAG_MkClo: {
        V v_n_2456 = heff_dup(heff_field(v_cod_2420, 0));
        v_t_2460 = v_n_2456;
        break;
      }
      case TAG_CloConst: {
        v_t_2460 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str1);
        break;
      }
      default: heff_nomatch(v_cod_2420);
      }
      V v_t_2499 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2460, heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam8, 2, 8, (V[]){v_sp_240, v_x_241, v_body_242, v_cod_2420, v_e_243, v_implicit_2421, v_dom_2419, v_x_2411})));
      return heff_tail(v_t_2499, 2, (V[]){v_hd_245, v_k_246});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24105}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24106, v_k_246});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24109 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24110}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24111, v_k_246});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24112 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24114}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24115, v_k_246});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24116 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24118}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24119, v_k_246});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24121 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24122}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24123, v_k_246});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24126}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24127, v_k_246});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24130 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24132, v_k_246});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24135 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24136}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24137, v_k_246});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24140}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24141, v_k_246});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntro_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroSyn_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroSyn(V v_x_240, V v_dom_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam0, 1, 3, (V[]){heff_dup(v_dom_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionIntroSyn(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam3(V self, V *args) {
  V v_v_2414 = args[0];
  V v_scope_27_2415 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_take_field(v_e_243, 2);
  V v_t_2419;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_ForNominative: {
    heff_drop(v_v_2414);
    v_t_2419 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2417 = heff_field(v_t_2416, 0);
    V v_sp_2418 = heff_field(v_t_2416, 1);
    V v_ru_24t_2416_24ForDescriptive = heff_take_reuse_n(v_t_2416, 3ULL, 2);
    v_t_2419 = heff_tag_at_n(v_ru_24t_2416_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2417, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2418, v_v_2414})});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_e_2420 = ({ V rv_0 = v_scope_27_2415; V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_n(v_e_243, 58ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkSyn: {
    V v_f_2421 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V f_ = v_f_2421;
    args[0] = v_e_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam5(V self, V *args) {
  V v_u_2433 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam6(V self, V *args) {
  V v_u_2440 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2440);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_ebody_2424 = heff_field(v_x_2423, 0);
    V v_bty_2425 = heff_field(v_x_2423, 1);
    V v_ru_24x_2423_24MkPair = heff_take_reuse_n(v_x_2423, 3ULL, 2);
    V v_t_2426 = heff_take_field(v_e_243, 2);
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_ForNominative: {
      v_t_2429 = NTAG(TAG_N);
      break;
    }
    case TAG_ForDescriptive: {
      heff_take_n(v_t_2426, 0ULL, 2);
      v_t_2429 = NTAG(TAG_De);
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
    V v_t_2432 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2431, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2434 = heff_tag_at_n(v_ru_24x_2423_24MkPair, TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2432, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam5, 1, 1, (V[]){heff_dup(v_bty_2425)})})});
    V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_t_2436 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2435, heff_dup(v_x_248), v_cod_2434));
    V v_t_2437 = (g_heff_2eelab_2ememoed_2elam(v_t_2429, heff_dup(heff_rfield(v_e_243, 1)), v_t_2430, v_t_2436, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_ebody_2424})));
    V v_t_2438 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
    V v_t_2439 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2438, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2441 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_rec_n(2, shape_stx__val, (V[]){v_t_2439, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam6, 1, 1, (V[]){v_bty_2425})})});
    V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_m_2443 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_243, 1, 6), v_t_2442, v_x_248, v_cod_2441));
    V v_x1_2444 = heff_tr(heff_apply(heff_get_n(v_m_2443, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2448;
    switch (heff_tag_of(v_x1_2444)) {
    case TAG_Nom: {
      V v_x_2445 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2445;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2444, 0ULL, 1);
      v_t_2448 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2447 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2447;
      break;
    }
    default: heff_nomatch(v_x1_2444);
    }
    V v_x_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_t_2448});
    V f_ = v_k_247;
    args[0] = v_x_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2422 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2413, heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam3, 2, 2, (V[]){heff_dup(v_e_243), v_body_242})));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam4, 1, 4, (V[]){v_e_243, v_x_240, v_x_248, v_k_247})});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam2, 1, 5, (V[]){v_x_240, v_e_243, v_body_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_dom_241)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_241, 0);
    heff_take_n(v_dom_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam1, 2, 4, (V[]){v_c_245, v_x_240, v_e_243, v_body_242});
}
HEFF_STRA(g_heff_2eelab_2erules_2erequireAgree_str0, 62, (116, 104, 101, 32, 98, 105, 110, 100, 101, 114, 39, 115, 32, 97, 110, 110, 111, 116, 97, 116, 105, 111, 110, 32, 105, 115, 32, 110, 111, 116, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 116, 121, 112, 101, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 104, 101, 114, 101));
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erequireAgree_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_lam1, 2, 0};
Clo g_heff_2eelab_2erules_2erequireAgree_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_entry, 3, 0};

V g_heff_2eelab_2erules_2erequireAgree(V v_e_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_note_244 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_243; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_243); r_; });
    return heff_clo_n(g_heff_2eelab_2erules_2erequireAgree_lam0, 2, 2, (V[]){v_sp_241, v_note_244});
  }
  case TAG_Right: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    return ((V)&g_heff_2eelab_2erules_2erequireAgree_lam1_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erequireAgree(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_note_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erequireAgree_str0), v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_244})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_249}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  args[0] = v_t_2410;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str0, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str2, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str3, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str4, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str5, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str6, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str7, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str8, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str9, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str10, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str11, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroAnn_str12, 57, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionIntroAnn(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam7(V self, V *args) {
  V v_u_2455 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2455);
  return v_v_2444;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam10(V self, V *args) {
  V v_u_2474 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2474);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2465 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = heff_take_field(v_e_244, 2);
  V v_t_2470;
  switch (heff_tag_of(v_t_2467)) {
  case TAG_ForNominative: {
    v_t_2470 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2467, 0ULL, 2);
    v_t_2470 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2467);
  }
  V v_t_2471 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2472 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2473 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2472, heff_dup(v_x_2412)));
  V v_x_2475 = (g_heff_2eelab_2ememoed_2elam(v_t_2470, heff_get_n(v_e_244, 1, 6), v_t_2471, heff_rec_n(2, shape_stx__val, (V[]){v_t_2473, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam10, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2466})));
  V f_ = v_k_2465;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam8(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_c_2463 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2463;
  args[0] = v_hd_2464;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam9, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_k_2465});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam6(V self, V *args) {
  V v_v_2444 = args[0];
  V v_scope_27_2445 = args[1];
  V v_e_244 = heff_env(self)[0];
  V v_cod_2421 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = heff_dup(heff_rfield(v_e_244, 2));
  V v_t_2449;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_ForNominative: {
    v_t_2449 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2447 = heff_field(v_t_2446, 0);
    V v_sp_2448 = heff_field(v_t_2446, 1);
    V v_ru_24t_2446_24ForDescriptive = heff_take_reuse_n(v_t_2446, 3ULL, 2);
    v_t_2449 = heff_tag_at_n(v_ru_24t_2446_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2447, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2448, heff_dup(v_v_2444)})});
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2450 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
  V v_e_2451 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2445, heff_dup(heff_rfield(v_e_244, 1)), v_t_2449, v_t_2450, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
  V v_x1_2457;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2453 = heff_field(v_cod_2421, 1);
    V v_body_2454 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2457 = heff_tr(heff_apply(v_body_2454, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2453, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam7, 1, 1, (V[]){v_v_2444})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2456 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    heff_drop(v_v_2444);
    v_x1_2457 = v_body_2456;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2461;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_a_2461 = v_x_2458;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    v_a_2461 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_a_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_c_2463;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2462 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    v_c_2463 = heff_tr(heff_apply(v_f_2462, 2, (V[]){v_e_2451, v_a_2461}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam8, 2, 4, (V[]){v_c_2463, v_e_244, v_x_2412, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2438);
  V v_x1_2439 = heff_tr(heff_apply(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  V v_t_2476 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2443, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam6, 2, 5, (V[]){v_e_244, v_cod_2421, v_body_243, v_x_2412, v_x_241})));
  return heff_tail(v_t_2476, 2, (V[]){v_hd_246, v_k_247});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_cod_2421 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2437 = (g_heff_2eelab_2erules_2erequireAgree(heff_dup(v_e_244), v_sp_240, v_x_2436));
  return heff_tail(v_c_2437, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam5, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_cod_2421 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2427 = heff_dup(heff_rfield(v_e_244, 0));
  V v_cs_2428 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2427, 0), heff_get_n(v_c_2427, 1, 4)});
  V v_x1_2429 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2426, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2433;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_Nom: {
    V v_x_2430 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_b_2433 = v_x_2430;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2429, 0ULL, 1);
    v_b_2433 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2432 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_b_2433 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x1_2429);
  }
  V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_dup(heff_rfield(v_e_244, 1)), v_cs_2428, v_fdom_2420, v_b_2433}));
  V v_c_2435 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_2434}));
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam4, 1, 9, (V[]){v_e_244, v_sp_240, v_hd_246, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_k_247})});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam12(V self, V *args) {
  V v_u_2494 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2494);
  return v_v_2482;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam15(V self, V *args) {
  V v_u_24118 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24118);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam14(V self, V *args) {
  V v_x_24105 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24104 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24106 = heff_take_field(v_e_244, 2);
  V v_t_24109;
  switch (heff_tag_of(v_t_24106)) {
  case TAG_ForNominative: {
    v_t_24109 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24106, 0ULL, 2);
    v_t_24109 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24106);
  }
  V v_t_24110 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_24111 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_24112 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_24111, heff_dup(v_x_2412)));
  V v_t_24117;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24113 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24117 = v_n_24113;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24117 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24119 = (g_heff_2eelab_2ememoed_2elam(v_t_24109, heff_get_n(v_e_244, 1, 6), v_t_24110, heff_rec_n(2, shape_stx__val, (V[]){v_t_24112, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam15, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24117, v_x_24105})));
  V f_ = v_k_24104;
  args[0] = v_x_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam13(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_c_24102 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24102;
  args[0] = v_hd_24103;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam14, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24104});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam11(V self, V *args) {
  V v_v_2482 = args[0];
  V v_scope_27_2483 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x1_2484 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  V v_t_2489;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2485 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2489 = v_n_2485;
    break;
  }
  case TAG_CloConst: {
    v_t_2489 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str2);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_e_2490 = ({ V a_0 = heff_dup(v_e_244); V a_1 = v_implicit_2422; V a_2 = v_t_2489; V a_3 = v_fdom_2420; V a_4 = v_scope_27_2483; V a_5 = heff_dup(v_v_2482); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2eelab_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2422); heff_drop(b_6); r_; });
  V v_x1_2496;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2492 = heff_dup(heff_field(v_cod_2421, 1));
    V v_body_2493 = heff_dup(heff_field(v_cod_2421, 2));
    v_x1_2496 = heff_tr(heff_apply(v_body_2493, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2492, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam12, 1, 1, (V[]){v_v_2482})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2495 = heff_dup(heff_field(v_cod_2421, 0));
    heff_drop(v_v_2482);
    v_x1_2496 = v_body_2495;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_24100;
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Nom: {
    V v_x_2497 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_a_24100 = v_x_2497;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2496, 0ULL, 1);
    v_a_24100 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2499 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_a_24100 = v_x_2499;
    break;
  }
  default: heff_nomatch(v_x1_2496);
  }
  V v_c_24102;
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_MkChk: {
    V v_f_24101 = heff_field(v_x1_2484, 0);
    heff_take_n(v_x1_2484, 1ULL, 1);
    v_c_24102 = heff_tr(heff_apply(v_f_24101, 2, (V[]){v_e_2490, v_a_24100}));
    break;
  }
  default: heff_nomatch(v_x1_2484);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam13, 2, 4, (V[]){v_c_24102, v_e_244, v_x_2412, v_cod_2421});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2417}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2418, v_k_247});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_implicit_2422);
      V v_c_2425;
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_apply(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_hd_246, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_k_247})});
    }
    case TAG_False: {
      V v_t_2481;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2477 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2481 = v_n_2477;
        break;
      }
      case TAG_CloConst: {
        v_t_2481 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24120 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2481, heff_dup(v_fdom_2420), heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam11, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, v_e_244, v_implicit_2422, v_fdom_2420, v_x_2412})));
      return heff_tail(v_t_24120, 2, (V[]){v_hd_246, v_k_247});
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24126}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24127, v_k_247});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24130 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24132, v_k_247});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24135}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24136, v_k_247});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24137 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24138 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24139}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24140, v_k_247});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24141 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24142 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24143}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24144, v_k_247});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24145 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24146 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24147}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24148, v_k_247});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24151 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24152}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24153, v_k_247});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24155 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24156 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24155})});
    V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24157}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24158, v_k_247});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24159 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24160 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24159})});
    V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24161}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24162, v_k_247});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str0, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str1, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str2, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str3, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str4, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str5, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str6, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str7, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str8, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str9, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2efunctionIntroImplicit_str10, 82, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116));
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionIntroImplicit(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2439 = args[0];
  V v_v_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2439);
  return v_v_2427;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = heff_take_field(v_e_243, 2);
  V v_t_2454;
  switch (heff_tag_of(v_t_2451)) {
  case TAG_ForNominative: {
    v_t_2454 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2451, 0ULL, 2);
    v_t_2454 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2451);
  }
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2457 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2456, heff_dup(v_x_2411)));
  V v_x_2459 = (g_heff_2eelab_2ememoed_2elam(v_t_2454, heff_get_n(v_e_243, 1, 6), v_t_2455, heff_rec_n(2, shape_stx__val, (V[]){v_t_2457, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2450})));
  V f_ = v_k_2449;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_scope_27_2428 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_implicit_2421 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_dom_2419 = heff_env(self)[3];
  V v_cod_2420 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2429 = heff_dup(heff_rfield(v_e_243, 2));
  V v_t_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_ForNominative: {
    v_t_2432 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2430 = heff_field(v_t_2429, 0);
    V v_sp_2431 = heff_field(v_t_2429, 1);
    V v_ru_24t_2429_24ForDescriptive = heff_take_reuse_n(v_t_2429, 3ULL, 2);
    v_t_2432 = heff_tag_at_n(v_ru_24t_2429_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2430, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2431, heff_dup(v_v_2427)})});
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V v_t_2433 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
  V v_t_2434;
  switch (heff_tag_of(v_implicit_2421)) {
  case TAG_Expl: {
    heff_drop(v_dom_2419);
    v_t_2434 = heff_dup(heff_rfield(v_e_243, 5));
    break;
  }
  case TAG_Impl: {
    heff_drop(v_dom_2419);
    v_t_2434 = heff_dup(heff_rfield(v_e_243, 5));
    break;
  }
  case TAG_Inst: {
    v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){heff_dup(v_x_241), v_dom_2419, heff_dup(v_v_2427)}), heff_dup(heff_rfield(v_e_243, 5))});
    break;
  }
  default: heff_nomatch(v_implicit_2421);
  }
  V v_e_2435 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2428, heff_dup(heff_rfield(v_e_243, 1)), v_t_2432, v_t_2433, heff_dup(heff_rfield(v_e_243, 4)), v_t_2434});
  V v_x1_2441;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2437 = heff_field(v_cod_2420, 1);
    V v_body_2438 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2441 = heff_tr(heff_apply(v_body_2438, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2437, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){v_v_2427})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2440 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    heff_drop(v_v_2427);
    v_x1_2441 = v_body_2440;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_a_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_a_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_a_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_c_2447;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2446 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2447 = heff_tr(heff_apply(v_f_2446, 2, (V[]){v_e_2435, v_a_2445}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5, 2, 4, (V[]){v_c_2447, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2417, v_k_246});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_x_2411);
      heff_drop(v_x_241);
      heff_drop_rec(v_e_243, 6);
      heff_drop(v_body_242);
      heff_drop(v_dom_2419);
      heff_drop(v_cod_2420);
      heff_drop(v_implicit_2421);
      V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2425}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2426, v_k_246});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2460 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3, 2, 7, (V[]){v_e_243, v_implicit_2421, v_x_241, v_dom_2419, v_cod_2420, v_body_242, v_x_2411})));
      return heff_tail(v_t_2460, 2, (V[]){v_hd_245, v_k_246});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2467, v_k_246});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2471}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2472, v_k_246});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2475}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2476, v_k_246});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2479}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2480, v_k_246});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2483}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2484, v_k_246});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2487}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2488, v_k_246});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2492}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2493, v_k_246});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2496 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2497}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2498, v_k_246});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24101}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_24102, v_k_246});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_str0, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_str2, 1, (95));
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_entry, 8, 0};

V g_heff_2eelab_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, heff_dup(v_arg_242), v_e_243, v_m_244})});
}
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2enamedGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_apply(heff_get_n(v_x_2428, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    v_t_2429 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Impl: {
    v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Inst: {
    heff_drop(v_x_241);
    v_t_2429 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2428)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2417, 1);
    V v_body_2432 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam3, 1, 1, (V[]){v_x_2428})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2428, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  V v_x_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_t_2443});
  V f_ = v_k_247;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args) {
  V v_u_2462 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  V v_x1_2463 = heff_tr(heff_apply(heff_get_n(v_x_2452, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_Nom: {
    V v_x_2464 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2464;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2466 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2466;
  }
  default: return heff_nomatch(v_x1_2463);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args) {
  V v_x_2452 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2453 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2457 = v_n_2453;
    break;
  }
  case TAG_CloConst: {
    v_t_2457 = ((V)&g_heff_2eelab_2erules_2enamedGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2458 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2457, v_m_244, heff_dup(v_x_2452)));
  V v_x1_2468;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2460 = heff_field(v_cod_2417, 1);
    V v_body_2461 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_apply(v_body_2461, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2460, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam5, 1, 1, (V[]){v_x_2452})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2452, 2);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_t_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2458; V a_5 = v_t_2472; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args) {
  V v_u_2485 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2485);
  V v_x1_2486 = heff_tr(heff_apply(heff_get_n(v_x_2480, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2486)) {
  case TAG_Nom: {
    V v_x_2487 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2487;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2486, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2489 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2489;
  }
  default: return heff_nomatch(v_x1_2486);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args) {
  V v_x_2480 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_cod_2417 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2480)));
  V v_x1_2491;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2483 = heff_field(v_cod_2417, 1);
    V v_body_2484 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2491 = heff_tr(heff_apply(v_body_2484, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2483, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam7, 1, 1, (V[]){v_x_2480})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2490 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2480, 2);
    v_x1_2491 = v_body_2490;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2495;
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_Nom: {
    V v_x_2492 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2492;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2491, 0ULL, 1);
    v_t_2495 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2494 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2494;
    break;
  }
  default: heff_nomatch(v_x1_2491);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2481; V a_5 = v_t_2495; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_x1_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_x1_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_n_2419});
      break;
    }
    case TAG_CloConst: {
      v_x1_2423 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    V v_t_2425;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_x_241));
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_sp_240);
      V v_c_2427;
      switch (heff_tag_of(v_arg_242)) {
      case TAG_MkChk: {
        V v_f_2426 = heff_field(v_arg_242, 0);
        heff_take_n(v_arg_242, 1ULL, 1);
        v_c_2427 = heff_tr(heff_apply(v_f_2426, 2, (V[]){v_e_243, v_dom_2416}));
        break;
      }
      default: heff_nomatch(v_arg_242);
      }
      return heff_tail(v_c_2427, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247})});
    }
    case TAG_False: {
      V v_t_2445;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      switch (heff_tag_of(v_t_2445)) {
      case TAG_True: {
        heff_drop(v_implicit_2418);
        V v_t_2450;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2446 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2450 = v_n_2446;
          break;
        }
        case TAG_CloConst: {
          v_t_2450 = ((V)&g_heff_2eelab_2erules_2enamedGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2451 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2450));
        return heff_tail(v_c_2451, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam4, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})});
      }
      case TAG_False: {
        heff_drop(v_x_2412);
        V v_t_2473;
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Impl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Inst: {
          v_t_2473 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_implicit_2418);
        }
        switch (heff_tag_of(v_t_2473)) {
        case TAG_True: {
          V v_t_2478;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2474 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2478 = v_n_2474;
            break;
          }
          case TAG_CloConst: {
            v_t_2478 = ((V)&g_heff_2eelab_2erules_2enamedGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          V v_c_2479 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2einsertInstance_clo), 4, (V[]){heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2478}));
          return heff_tail(v_c_2479, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam6, 1, 8, (V[]){v_m_244, v_cod_2417, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})});
        }
        case TAG_False: {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_t_2473);
        }
      }
      default: return heff_nomatch(v_t_2445);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2edelayedCheck_str0, 5, (116, 104, 105, 115, 32));
HEFF_STRA(g_heff_2eelab_2erules_2edelayedCheck_str1, 28, (32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 102, 105, 116, 32, 104, 111, 119, 32, 105, 116, 32, 105, 115, 32, 117, 115, 101, 100));
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_apply(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edelayedCheck(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_note_2422 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2421; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2421); r_; });
    V v_t_2423 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayedCheck_str0), heff_strAppend(v_what_242, ((V)&g_heff_2eelab_2erules_2edelayedCheck_str1)));
    V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2423, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2422})});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tr(heff_apply(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2426}));
    return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2427, v_k_2410});
  }
  case TAG_Right: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_249, 3);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2413 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2412, 0), heff_get_n(v_c_2412, 1, 4)});
  V v_x1_2414 = heff_tr(heff_apply(heff_take_field(v_x_2411, 1), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2418;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nom: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2415;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2414, 0ULL, 1);
    v_t_2418 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2417 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  V v_c_2419 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2esolveHole_clo), 6, (V[]){heff_dup(heff_rfield(v_e_240, 1)), v_t_2413, v_m_245, heff_get_n(v_hole_246, 1, 2), heff_get_n(v_x_2411, 0, 2), v_t_2418}));
  return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})});
}
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2edelayChkOn_str0, 5, (100, 101, 108, 97, 121));
HEFF_STRA(g_heff_2eelab_2erules_2edelayChkOn_str1, 21, (32, 119, 97, 105, 116, 115, 32, 102, 111, 114, 32, 105, 116, 115, 32, 116, 121, 112, 101, 32, 63));
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayChkOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayChkOn_entry, 8, 0};

V g_heff_2eelab_2erules_2edelayChkOn(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_keyTy_244, V v_ty_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = heff_dup(v_ty_245); V a_3 = heff_dup(v_what_242); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam0, 1, 8, (V[]){v_e_240, v_sp_241, v_what_242, heff_dup(v_c_243), v_ty_245, v_keyTy_244, v_hd_246, v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edelayChkOn(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_chk_2447 = heff_env(self)[0];
  V v_keyTy_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tr(heff_apply(v_chk_2447, 2, (V[]){heff_dup(v_hd_2448), heff_dup(heff_rfield(v_hd_2448, 0))}));
  V v_t_2451 = heff_tag_n(TAG_Delay, 3, (V[]){v_keyTy_244, v_t_2450, NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_apply(heff_take_field(v_hd_2448, 2), 1, (V[]){v_t_2452}));
  V f_ = heff_get_n(v_hd_2448, 1, 3);
  args[0] = v_t_2453;
  args[1] = v_k2_2449;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args) {
  V v_u_2456 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2456);
  V v_t_2457 = heff_get_n(v_x_2410, 0, 2);
  V v_t_2492;
  switch (heff_tag_of(v_t_2457)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2457, 0ULL, 3);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2482 = heff_field(v_t_2457, 0);
    heff_take_n(v_t_2457, 1ULL, 3);
    v_t_2492 = v_k_2482;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2457, 0ULL, 2);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_2457, 0ULL, 1);
    v_t_2492 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2457);
  }
  return heff_strAppend(v_what_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayChkOn_str1), heff_intShow(v_t_2492)));
}
V g_heff_2eelab_2erules_2edelayChkOn_lam5(V self, V *args) {
  V v_u_2496 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2496);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2497 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam5, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_n(v_x_2410, 1ULL, 2, shape_stx__val); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2497;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args) {
  V v_x_2455 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2455);
  V v_t_2493 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2edelayChkOn_str0), heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam3, 1, 2, (V[]){heff_dup(v_x_2410), v_what_242})}), NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2494, heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam4, 1, 2, (V[]){v_x_2410, v_k_247})});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_ty_245 = heff_env(self)[4];
  V v_keyTy_244 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = heff_dup(heff_rfield(v_x_2410, 0));
  V v_t_2446;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2411, 0ULL, 3);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2436 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 3);
    v_t_2446 = v_k_2436;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2446 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_chk_2447 = ({ V a_0 = v_e_240; V a_1 = heff_dup(v_sp_241); V a_2 = heff_dup(v_what_242); V a_3 = v_c_243; V a_4 = v_ty_245; V a_5 = v_t_2446; V a_6 = heff_dup(v_x_2410); V r_ = (g_heff_2eelab_2erules_2edelayedCheck(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_243); r_; });
  V v_c_2454 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam1, 2, 2, (V[]){v_chk_2447, v_keyTy_244});
  return heff_tail(v_c_2454, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam2, 1, 5, (V[]){v_sp_241, v_x_2410, v_what_242, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimPlain_entry, 5, 0};

V g_heff_2eelab_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_arg_244)) {
  case TAG_MkChk: {
    V v_f_245 = heff_field(v_arg_244, 0);
    v_c_246 = heff_tr(heff_apply(heff_dup(v_f_245), 2, (V[]){v_e_240, v_dom_242}));
    break;
  }
  default: heff_nomatch(v_arg_244);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam0, 2, 3, (V[]){v_c_246, v_ecallee_241, heff_dup(v_cod_243)});
}
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eelimPlain(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  V v_x1_2415 = heff_tr(heff_apply(heff_get_n(v_x_249, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2416;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ecallee_241 = heff_env(self)[0];
  V v_cod_243 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = (g_heff_2eelab_2ememoed_2eapp(v_ecallee_241, heff_dup(v_x_249)));
  V v_x1_2420;
  switch (heff_tag_of(v_cod_243)) {
  case TAG_MkClo: {
    V v_vs_2412 = heff_field(v_cod_243, 1);
    V v_body_2413 = heff_field(v_cod_243, 2);
    heff_take_n(v_cod_243, 6ULL, 3);
    v_x1_2420 = heff_tr(heff_apply(v_body_2413, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2412, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam2, 1, 1, (V[]){v_x_249})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2419 = heff_field(v_cod_243, 0);
    heff_take_n(v_cod_243, 1ULL, 1);
    heff_drop_rec(v_x_249, 2);
    v_x1_2420 = v_body_2419;
    break;
  }
  default: heff_nomatch(v_cod_243);
  }
  V v_t_2424;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2421;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_t_2424 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_x_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2424});
  V f_ = v_k_248;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ecallee_241 = heff_env(self)[1];
  V v_cod_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam1, 1, 3, (V[]){v_ecallee_241, v_cod_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str0, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str1, 8, (97, 114, 103, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str2, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str3, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str4, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str5, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str6, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str7, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str8, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str9, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eelimGo_str10, 54, (116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_entry, 5, 0};

V g_heff_2eelab_2erules_2eelimGo(V v_checksOnly_240, V v_sp_241, V v_arg_242, V v_e_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_ecallee_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_246)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam0, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeFunction: {
      V v_dom_2417 = heff_field(v_t_247, 1);
      V v_cod_2418 = heff_field(v_t_247, 2);
      heff_take_n(v_t_247, 6ULL, 4);
      heff_drop(v_a_246);
      switch (heff_tag_of(v_checksOnly_240)) {
      case TAG_True: {
        return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam2, 2, 6, (V[]){v_dom_2417, v_e_243, v_ecallee_245, v_cod_2418, heff_dup(v_arg_242), v_sp_241});
      }
      case TAG_False: {
        heff_drop(v_sp_241);
        return ({ V a_0 = v_e_243; V a_1 = v_ecallee_245; V a_2 = v_dom_2417; V a_3 = v_cod_2418; V a_4 = v_arg_242; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2418); r_; });
      }
      default: return heff_nomatch(v_checksOnly_240);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam7, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam9, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeInt: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam11, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeFloat: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam13, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeString: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam15, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeRune: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam17, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam19, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam21, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_NoRules: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam23, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eelimGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_249, v_k_2410});
  }
  case TAG_False: {
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2415, v_k_2410});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam1, 1, 3, (V[]){v_hd_249, v_k_2410, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args) {
  V v_c_2422 = args[0];
  V v_dom_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2422, 3, 8); V a_1 = v_dom_2417; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args) {
  V v_u_2456 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  V v_x1_2457 = heff_tr(heff_apply(heff_get_n(v_x_2451, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2458;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2460;
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_ecallee_245 = heff_env(self)[0];
  V v_cod_2418 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2452 = (g_heff_2eelab_2ememoed_2eapp(v_ecallee_245, heff_dup(v_x_2451)));
  V v_x1_2462;
  switch (heff_tag_of(v_cod_2418)) {
  case TAG_MkClo: {
    V v_vs_2454 = heff_field(v_cod_2418, 1);
    V v_body_2455 = heff_field(v_cod_2418, 2);
    heff_take_n(v_cod_2418, 6ULL, 3);
    v_x1_2462 = heff_tr(heff_apply(v_body_2455, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2454, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam6, 1, 1, (V[]){v_x_2451})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2461 = heff_field(v_cod_2418, 0);
    heff_take_n(v_cod_2418, 1ULL, 1);
    heff_drop_rec(v_x_2451, 2);
    v_x1_2462 = v_body_2461;
    break;
  }
  default: heff_nomatch(v_cod_2418);
  }
  V v_t_2466;
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Nom: {
    V v_x_2463 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    v_t_2466 = v_x_2463;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2462, 0ULL, 1);
    v_t_2466 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2465 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    v_t_2466 = v_x_2465;
    break;
  }
  default: heff_nomatch(v_x1_2462);
  }
  V v_x_2467 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_t_2466});
  V f_ = v_k_2421;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_ecallee_245 = heff_env(self)[1];
  V v_dom_2417 = heff_env(self)[2];
  V v_cod_2418 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2448;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_VU: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2428 = heff_dup(heff_field(v_x_2426, 0));
    switch (heff_tag_of(v_it1_2428)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2448 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_x1_2448 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2428);
    }
    break;
  }
  case TAG_VFunction: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_x1_2448 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2449;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_True: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2449 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  switch (heff_tag_of(v_t_2449)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_241);
    V v_t_2450 = ({ V a_0 = v_e_243; V a_1 = v_ecallee_245; V a_2 = v_dom_2417; V a_3 = v_cod_2418; V a_4 = v_arg_242; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2418); heff_drop(v_arg_242); r_; });
    return heff_tail(v_t_2450, 2, (V[]){v_hd_2420, v_k_2421});
  }
  case TAG_False: {
    heff_drop(v_dom_2417);
    return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2eelimGo_str1); V a_3 = v_arg_242; V a_4 = heff_dup(v_x_2426); V a_5 = v_x_2426; V a_6 = v_hd_2420; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam5, 1, 3, (V[]){v_ecallee_245, v_cod_2418, v_k_2421}); V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
  }
  default: return heff_nomatch(v_t_2449);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_dom_2417 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_ecallee_245 = heff_env(self)[2];
  V v_cod_2418 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam3, 1, 1, (V[]){heff_dup(v_dom_2417)})})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2420, 2)), 1, (V[]){v_t_2424}));
  V f_ = heff_dup(heff_rfield(v_hd_2420, 1));
  args[0] = v_t_2425;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam4, 1, 8, (V[]){v_e_243, v_ecallee_245, v_dom_2417, v_cod_2418, v_arg_242, v_hd_2420, v_k_2421, v_sp_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_hd_2471 = heff_env(self)[0];
  V v_k_2472 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2473)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2471, v_k_2472});
  }
  case TAG_False: {
    V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str2), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_apply(heff_take_field(v_hd_2471, 2), 1, (V[]){v_t_2476}));
    return heff_tail(heff_get_n(v_hd_2471, 1, 3), 2, (V[]){v_t_2477, v_k_2472});
  }
  default: return heff_nomatch(v_x_2473);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2471), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam8, 1, 3, (V[]){v_hd_2471, v_k_2472, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_2479 = heff_env(self)[0];
  V v_k_2480 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2481)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2479, v_k_2480});
  }
  case TAG_False: {
    V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str3), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_apply(heff_take_field(v_hd_2479, 2), 1, (V[]){v_t_2484}));
    return heff_tail(heff_get_n(v_hd_2479, 1, 3), 2, (V[]){v_t_2485, v_k_2480});
  }
  default: return heff_nomatch(v_x_2481);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2479), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam10, 1, 3, (V[]){v_hd_2479, v_k_2480, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_2486 = heff_env(self)[0];
  V v_k_2487 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2488)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2486, v_k_2487});
  }
  case TAG_False: {
    V v_t_2489 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str4), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_apply(heff_take_field(v_hd_2486, 2), 1, (V[]){v_t_2491}));
    return heff_tail(heff_get_n(v_hd_2486, 1, 3), 2, (V[]){v_t_2492, v_k_2487});
  }
  default: return heff_nomatch(v_x_2488);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2486), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam12, 1, 3, (V[]){v_hd_2486, v_k_2487, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_2493 = heff_env(self)[0];
  V v_k_2494 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2495)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2493, v_k_2494});
  }
  case TAG_False: {
    V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str5), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tr(heff_apply(heff_take_field(v_hd_2493, 2), 1, (V[]){v_t_2498}));
    return heff_tail(heff_get_n(v_hd_2493, 1, 3), 2, (V[]){v_t_2499, v_k_2494});
  }
  default: return heff_nomatch(v_x_2495);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2493), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam14, 1, 3, (V[]){v_hd_2493, v_k_2494, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args) {
  V v_x_24102 = args[0];
  V v_hd_24100 = heff_env(self)[0];
  V v_k_24101 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24102)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24100, v_k_24101});
  }
  case TAG_False: {
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str6), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_apply(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24105}));
    return heff_tail(heff_get_n(v_hd_24100, 1, 3), 2, (V[]){v_t_24106, v_k_24101});
  }
  default: return heff_nomatch(v_x_24102);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24100), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam16, 1, 3, (V[]){v_hd_24100, v_k_24101, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args) {
  V v_x_24109 = args[0];
  V v_hd_24107 = heff_env(self)[0];
  V v_k_24108 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24109)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24107, v_k_24108});
  }
  case TAG_False: {
    V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str7), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tr(heff_apply(heff_take_field(v_hd_24107, 2), 1, (V[]){v_t_24112}));
    return heff_tail(heff_get_n(v_hd_24107, 1, 3), 2, (V[]){v_t_24113, v_k_24108});
  }
  default: return heff_nomatch(v_x_24109);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24107), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam18, 1, 3, (V[]){v_hd_24107, v_k_24108, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args) {
  V v_x_24117 = args[0];
  V v_hd_24115 = heff_env(self)[0];
  V v_k_24116 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24117)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24115, v_k_24116});
  }
  case TAG_False: {
    V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str8), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tr(heff_apply(heff_take_field(v_hd_24115, 2), 1, (V[]){v_t_24120}));
    return heff_tail(heff_get_n(v_hd_24115, 1, 3), 2, (V[]){v_t_24121, v_k_24116});
  }
  default: return heff_nomatch(v_x_24117);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24115), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam20, 1, 3, (V[]){v_hd_24115, v_k_24116, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args) {
  V v_x_24125 = args[0];
  V v_hd_24123 = heff_env(self)[0];
  V v_k_24124 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24125)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24123, v_k_24124});
  }
  case TAG_False: {
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str9), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
    V v_t_24129 = heff_tr(heff_apply(heff_take_field(v_hd_24123, 2), 1, (V[]){v_t_24128}));
    return heff_tail(heff_get_n(v_hd_24123, 1, 3), 2, (V[]){v_t_24129, v_k_24124});
  }
  default: return heff_nomatch(v_x_24125);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args) {
  V v_hd_24123 = args[0];
  V v_k_24124 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24123), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam22, 1, 3, (V[]){v_hd_24123, v_k_24124, v_sp_241})));
}
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args) {
  V v_x_24132 = args[0];
  V v_hd_24130 = heff_env(self)[0];
  V v_k_24131 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24132)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24130, v_k_24131});
  }
  case TAG_False: {
    V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eelimGo_str10), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tr(heff_apply(heff_take_field(v_hd_24130, 2), 1, (V[]){v_t_24135}));
    return heff_tail(heff_get_n(v_hd_24130, 1, 3), 2, (V[]){v_t_24136, v_k_24131});
  }
  default: return heff_nomatch(v_x_24132);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24130), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam24, 1, 3, (V[]){v_hd_24130, v_k_24131, v_sp_241})));
}
V g_heff_2eelab_2erules_2efunctionElimC_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionElimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionElimC_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionElimC(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam0, 1, 4, (V[]){heff_dup(v_callee_242), v_sp_241, heff_dup(v_checksOnly_240), heff_dup(v_arg_243)})});
}
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2efunctionElimC(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2efunctionElimC_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_arg_243 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = ({ V a_0 = v_checksOnly_240; V a_1 = v_sp_241; V a_2 = v_arg_243; V a_3 = v_e_244; V a_4 = v_x_2412; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checksOnly_240); heff_drop(v_arg_243); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2eelab_2erules_2efunctionElimC_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_ecallee0_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_241), v_ecallee0_2410, v_a0_2411, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam3, 1, 6, (V[]){v_checksOnly_240, v_sp_241, v_arg_243, v_e_244, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam2, 1, 6, (V[]){v_e_244, v_sp_241, v_hd_247, v_checksOnly_240, v_arg_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_callee_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_callee_242)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_callee_242, 0);
    heff_take_n(v_callee_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_callee_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_241, v_checksOnly_240, v_arg_243});
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFields_lam0, 2, 0};
V g_heff_2eelab_2erules_2echeckFields_lam2(V self, V *args);
V g_heff_2eelab_2erules_2echeckFields_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFields_entry, 3, 0};

V g_heff_2eelab_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    return ((V)&g_heff_2eelab_2erules_2echeckFields_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x31_246, 0);
      V v_g_249 = heff_field(v_x31_246, 1);
      V v_c_2410 = heff_dup(heff_rfield(v_e_240, 0));
      V v_cs_2411 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2410, 0), heff_get_n(v_c_2410, 1, 4)});
      V v_x1_2412 = (g_heff_2eelab_2evalue_2eproj(heff_dup(v_v_241), heff_dup(v_y_248)));
      V v_a_2416;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nom: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 1);
        v_a_2416 = v_x_2413;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_a_2416 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2415 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 1);
        v_a_2416 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_t_2417 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), heff_dup(heff_rfield(v_e_240, 1)), v_cs_2411, v_a_2416, heff_dup(v_g_249)));
      V v_c_2418 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_2417}));
      return heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam1, 2, 4, (V[]){v_c_2418, v_e_240, v_v_241, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2echeckFields(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckFields_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_err_2422 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_2419);
    V f_ = v_k_2420;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2422});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2421, 0ULL, 1);
    V v_t_2424 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2)); heff_drop(v_rest_247); r_; });
    return heff_tail(v_t_2424, 2, (V[]){v_hd_2419, v_k_2420});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2eelab_2erules_2echeckFields_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam2, 1, 5, (V[]){v_k_2420, v_e_240, v_v_241, v_rest_247, v_hd_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2especializedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especializedGo_entry, 10, 0};

V g_heff_2eelab_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249) {
top: ;
  switch (heff_tag_of(v_sp_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam0, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpApp: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam1, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpProj: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam2, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpSpec: {
    V v_sq_2420 = heff_field(v_sp_244, 0);
    V v_x_2421 = heff_field(v_sp_244, 1);
    V v_f_2422 = heff_field(v_sp_244, 2);
    V v_c_2423 = heff_dup(heff_rfield(v_e_240, 0));
    V v_cs_2424 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2423, 0), heff_get_n(v_c_2423, 1, 4)});
    V v_t_2425 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_dup(heff_rfield(v_e_240, 1)), v_cs_2424, heff_tag_n(TAG_VDecode, 5, (V[]){heff_dup(v_h_243), heff_dup(v_sq_2420), heff_dup(v_u_245), heff_dup(v_described_246), heff_dup(v_el_247)}), heff_dup(v_a_27_242)}));
    V v_t_2426 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_2425}));
    V v_c_2427 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eattempt_clo), 1, (V[]){v_t_2426}));
    return heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam3, 2, 13, (V[]){v_c_2427, heff_dup(v_x_2421), heff_dup(v_f_2422), v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, heff_dup(v_sq_2420), v_u_245, v_described_246, v_el_247, v_err_249});
  }
  default: return heff_nomatch(v_sp_244);
  }
}
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2especializedGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especializedGo_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especializedGo_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  V v_fields_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_a_27_242 = heff_env(self)[5];
  V v_h_243 = heff_env(self)[6];
  V v_sq_2420 = heff_env(self)[7];
  V v_u_245 = heff_env(self)[8];
  V v_described_246 = heff_env(self)[9];
  V v_el_247 = heff_env(self)[10];
  V v_err_249 = heff_env(self)[11];
  V v_hd_2428 = heff_env(self)[12];
  V v_k_2429 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2421, v_f_2422}), v_fields_248});
    V v_t_2433 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_a_27_242; V a_3 = v_h_243; V a_4 = v_sq_2420; V a_5 = v_u_245; V a_6 = v_described_246; V a_7 = v_el_247; V a_8 = v_t_2432; V a_9 = v_err_249; V r_ = (g_heff_2eelab_2erules_2especializedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_sq_2420); r_; });
    return heff_tail(v_t_2433, 2, (V[]){v_hd_2428, v_k_2429});
  }
  case TAG_Right: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_sq_2420);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_err_249);
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2421, v_f_2422}), v_fields_248});
    V v_t_2436 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_t_2435; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2)); heff_drop_tag(v_t_2435, 2); r_; });
    return heff_tail(v_t_2436, 2, (V[]){v_hd_2428, v_k_2429});
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2eelab_2erules_2especializedGo_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_f_2422 = heff_env(self)[2];
  V v_fields_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  V v_a_27_242 = heff_env(self)[6];
  V v_h_243 = heff_env(self)[7];
  V v_sq_2420 = heff_env(self)[8];
  V v_u_245 = heff_env(self)[9];
  V v_described_246 = heff_env(self)[10];
  V v_el_247 = heff_env(self)[11];
  V v_err_249 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam4, 1, 14, (V[]){v_x_2421, v_f_2422, v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, v_sq_2420, v_u_245, v_described_246, v_el_247, v_err_249, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2especialized_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam1(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam2(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam3(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam4(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam5(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam6(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam7(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam8(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam9(V self, V *args);
Clo g_heff_2eelab_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especialized_entry, 5, 0};

V g_heff_2eelab_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam0, 2, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return (g_heff_2eelab_2erules_2especializedGo(v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), v_sp_249, heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244));
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam1, 2, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam2, 2, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam3, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam4, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam5, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam6, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam7, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam8, 2, 1, (V[]){v_err_244});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam9, 2, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2especialized(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2especialized_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam6(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam8(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str0, 5, (117, 110, 105, 102, 121));
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str1, 8, (32, 32, 32, 70, 65, 73, 76, 83));
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str2, 5, (32, 32, 32, 111, 107));
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str3, 7, (32, 32, 61, 63, 61, 32, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str4, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eapplyGo_str5, 15, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 121, 112, 101, 32));
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_lam4, 1, 0};
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_entry, 4, 0};

V g_heff_2eelab_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_244 = heff_field(v_x4_243, 0);
    V v_a_27_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_246 = heff_dup(heff_rfield(v_e_241, 0));
    V v_cs_247 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_246, 0), heff_get_n(v_c_246, 1, 4)});
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_dup(heff_rfield(v_e_241, 1)), v_cs_247, heff_dup(v_a_242), heff_dup(v_a_27_245)}));
    V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_248}));
    V v_c_2410 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eattempt_clo), 1, (V[]){v_t_249}));
    return heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam0, 2, 6, (V[]){v_c_2410, v_m_244, v_e_241, v_a_242, v_a_27_245, v_sp_240});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eapplyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_c_2425 = args[0];
  return heff_get_n(v_c_2425, 3, 8);
}
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_u_2430 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2430);
  V v_t_2431 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_241), v_x_2429, v_a_242));
  V v_t_2432 = ({ V a_0 = v_e_241; V a_1 = v_x_2429; V a_2 = v_a_27_245; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2429); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str3), heff_strAppend(v_t_2432, v_t_2435)));
}
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2439 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_note_2442 = ({ V a_0 = heff_get_n(v_e_241, 1, 6); V a_1 = v_err_2439; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2439); r_; });
  V v_t_2443 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str4), heff_strAppend(v_x_2440, heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str5), v_x_2441)));
  V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2443, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2442})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2446}));
  return heff_tail(heff_get_n(v_hd_2411, 1, 3), 2, (V[]){v_t_2447, v_k_2412});
}
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_27_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_err_2439 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_a_27_245, heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam9, 1, 6, (V[]){v_e_241, v_err_2439, v_x_2440, v_sp_240, v_hd_2411, v_k_2412})));
}
V g_heff_2eelab_2erules_2eapplyGo_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V f_ = v_k_2412;
  args[0] = v_m_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2438);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2439 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_a_242, heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam8, 1, 6, (V[]){v_e_241, v_a_27_245, v_hd_2411, v_err_2439, v_sp_240, v_k_2412})));
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_a_242);
    heff_drop(v_a_27_245);
    heff_drop(v_sp_240);
    V v_t_2449 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_apply(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2450}));
    return heff_tail(heff_get_n(v_hd_2411, 1, 3), 2, (V[]){v_t_2451, heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam10, 1, 2, (V[]){v_k_2412, v_m_244})});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2436 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2eapplyGo_str0), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam6, 1, 5, (V[]){heff_dup(v_e_241), v_x_2429, heff_dup(v_a_242), heff_dup(v_a_27_245), heff_dup(v_x_2424)})}), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2411, 1)), 2, (V[]){v_t_2437, heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam7, 1, 8, (V[]){v_x_2424, v_e_241, v_a_242, v_hd_2411, v_a_27_245, v_sp_240, v_k_2412, v_m_244})});
}
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyGo_lam4_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){v_t_2427}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2411, 1)), 2, (V[]){v_t_2428, heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam5, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_245, v_x_2424, v_hd_2411, v_k_2412, v_m_244})});
}
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = heff_tr(heff_apply(heff_dup(heff_rfield(v_m_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    v_c_2423 = (g_heff_2eelab_2erules_2especialized(heff_dup(v_e_241), v_t_2419, v_a_242, heff_dup(v_a_27_245), heff_tag_at_n(v_ru_24x_2413_24Left, TAG_Left, 1, (V[]){v_err_2414})));
    break;
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_c_2423 = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam2, 2, 1, (V[]){v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam3, 1, 7, (V[]){v_hd_2411, v_sp_240, v_e_241, v_a_242, v_a_27_245, v_k_2412, v_m_244})});
}
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_m_244, v_e_241, v_a_242, v_a_27_245, v_hd_2411, v_sp_240, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eapply_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapply_entry, 2, 0};

V g_heff_2eelab_2erules_2eapply(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_lam0, 2, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eapply(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2eapply_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2411, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapply_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m0_249, v_a1_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapply_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2434 = (g_heff_2eelab_2erules_2eapplyGo(v_sp_240, v_e_242, v_x_2415, v_x_2433));
  return heff_tail(v_t_2434, 2, (V[]){v_hd_246, v_k_247});
}
V g_heff_2eelab_2erules_2eapply_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  V v_t_2429;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2421 = heff_field(v_t_2416, 3);
    heff_take_n(v_t_2416, 8ULL, 4);
    V v_x1_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_x1_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_True: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2422);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeRune: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_c_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_True: {
    v_c_2432 = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam5, 2, 2, (V[]){v_m0_249, v_a1_2410});
    break;
  }
  case TAG_False: {
    v_c_2432 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2einsertImplicits_clo), 4, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), v_m0_249, v_a1_2410}));
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eapply_lam6, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2415, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2erules_2eapply_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_a0_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_m0_249 = heff_field(v_x_248, 0);
    V v_a1_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_lam3, 1, 1, (V[]){v_a0_243})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
    return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2erules_2eapply_lam4, 1, 6, (V[]){v_m0_249, v_a1_2410, v_e_242, v_sp_240, v_hd_246, v_k_247})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2eapply_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_a0_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam2, 1, 5, (V[]){v_a0_243, v_hd_246, v_e_242, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eapply_lam1, 2, 4, (V[]){v_c_245, v_a0_243, v_e_242, v_sp_240});
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eannot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eannot_entry, 2, 0};

V g_heff_2eelab_2erules_2eannot(V v_typ_240, V v_chk_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eannot_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})});
}
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eannot(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_apply(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_apply(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  return heff_tail(v_c_2415, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2eannot_lam3, 1, 2, (V[]){v_x_248, v_k_247})});
}
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5))});
    v_c_245 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eannot_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
HEFF_STRA(g_heff_2eelab_2erules_2erecChk_str0, 46, (99, 97, 110, 32, 111, 110, 108, 121, 32, 117, 115, 101, 32, 114, 101, 99, 32, 119, 104, 101, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 97, 116, 32, 97, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecChk_str1, 97, (116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 119, 111, 117, 108, 100, 32, 110, 101, 101, 100, 32, 105, 116, 115, 101, 108, 102, 32, 119, 104, 105, 108, 101, 32, 105, 116, 32, 105, 115, 32, 98, 101, 105, 110, 103, 32, 99, 111, 109, 112, 117, 116, 101, 100, 58, 32, 112, 117, 116, 32, 116, 104, 101, 32, 114, 101, 99, 117, 114, 115, 105, 118, 101, 32, 117, 115, 101, 32, 117, 110, 100, 101, 114, 32, 97, 32, 108, 97, 109, 98, 100, 97));
V g_heff_2eelab_2erules_2erecChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2erecChk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_lam5, 1, 0};
V g_heff_2eelab_2erules_2erecChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_entry, 2, 0};

V g_heff_2eelab_2erules_2erecChk(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam0, 2, 2, (V[]){v_sp_240, heff_dup(v_c_241)})});
}
V g_heff_2eelab_2erules_2erecChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecChk(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2erecChk_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(331LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_take_field(v_hd_2414, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2414, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam5(V self, V *args) {
  V v_u_2430 = args[0];
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2erecChk_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag_n(TAG_SRec, 1, (V[]){heff_get_n(v_x_2428, 0, 2)});
  V f_ = v_k_2427;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2429, ((V)&g_heff_2eelab_2erules_2erecChk_lam5_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecChk_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam4, 1, 1, (V[]){v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2eelab_2evalue_2elevelOf(v_a_243));
  V v_x1_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Small: {
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_246;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam1, 2, 1, (V[]){v_sp_240});
  }
  case TAG_False: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_e_242, 3)), MK_INT(0LL))) {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_a_243);
      heff_drop(v_c_241);
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam2, 2, 1, (V[]){v_sp_240});
    } else {
      heff_drop(v_sp_240);
      V v_sd_2420 = heff_take_field(v_e_242, 0);
      V v_t_2421 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_2420, 3)});
      V v_sc_2422 = ({ V rv_3 = v_t_2421; V rr_ = heff_rec_reuse_n(v_sd_2420, 7ULL, 4, shape_len__names__locals__ctx); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_e_2423 = ({ V rv_0 = v_sc_2422; V rr_ = heff_rec_reuse_n(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_c_2425;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkChk: {
        V v_f_2424 = heff_field(v_c_241, 0);
        heff_take_n(v_c_241, 1ULL, 1);
        v_c_2425 = heff_tr(heff_apply(v_f_2424, 2, (V[]){v_e_2423, v_a_243}));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam3, 2, 1, (V[]){v_c_2425});
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2erules_2evarGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2evarGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evarGo_entry, 6, 0};

V g_heff_2eelab_2erules_2evarGo(V v_x_240, V v_names_241, V v_ctx_242, V v_locals_243, V v_n_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_ctx_242)) {
  case TAG_CEmpty: {
    heff_drop(v_x_240);
    heff_drop(v_names_241);
    heff_drop(v_locals_243);
    heff_drop(v_n_244);
    heff_drop(v_i_245);
    return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
  }
  case TAG_CBind: {
    V v_c_27_246 = heff_field(v_ctx_242, 0);
    V v_it2_247 = heff_field(v_ctx_242, 1);
    V v_a_248 = heff_field(v_ctx_242, 2);
    switch (heff_tag_of(v_it2_247)) {
    case TAG_BDelayedBy: {
      V v_k_249 = heff_field(v_it2_247, 0);
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_x_240);
        heff_drop(v_locals_243);
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
      }
      case TAG_Cons: {
        V v_x_27_2410 = heff_field(v_names_241, 0);
        V v_xs_2411 = heff_field(v_names_241, 1);
        V v_ru_24names_241_24Cons = heff_take_reuse_n(v_names_241, 3ULL, 2);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        case TAG_LSnoc: {
          V v_vs_2412 = heff_field(v_locals_243, 0);
          V v_v_2413 = heff_field(v_locals_243, 1);
          heff_take_n(v_locals_243, 3ULL, 2);
          if (heff_strEq_c(heff_dup(v_x_240), v_x_27_2410)) {
            heff_drop(v_x_240);
            heff_drop(v_xs_2411);
            heff_drop(v_vs_2412);
            if (heff_intLe_c(heff_dup(v_k_249), v_n_244)) {
              V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_i_245}), heff_clo_n(g_heff_2eelab_2erules_2evarGo_lam0, 1, 1, (V[]){v_v_2413})});
              return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24names_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2418, heff_dup(v_a_248)})});
            } else {
              heff_drop(v_i_245);
              heff_drop_cell(v_ru_24names_241_24Cons, 2);
              heff_drop(v_v_2413);
              return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_Delayed2)});
            }
          } else {
            heff_drop_cell(v_ru_24names_241_24Cons, 2);
            heff_drop(v_v_2413);
            V t_0 = v_x_240;
            V t_1 = v_xs_2411;
            V t_2 = v_c_27_246;
            V t_3 = v_vs_2412;
            V t_4 = v_n_244;
            V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
            v_x_240 = t_0;
            v_names_241 = t_1;
            v_ctx_242 = t_2;
            v_locals_243 = t_3;
            v_n_244 = t_4;
            v_i_245 = t_5;
            goto top;
          }
        }
        case TAG_LChunkSnoc: {
          heff_take_n(v_locals_243, 0ULL, 2);
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        default: return heff_nomatch(v_locals_243);
        }
      }
      default: return heff_nomatch(v_names_241);
      }
    }
    default: return heff_nomatch(v_it2_247);
    }
  }
  case TAG_CUndelay: {
    V v_c_27_2421 = heff_field(v_ctx_242, 0);
    V t_0 = v_x_240;
    V t_1 = v_names_241;
    V t_2 = v_c_27_2421;
    V t_3 = v_locals_243;
    V t_4 = heff_intAdd(v_n_244, MK_INT(1LL));
    V t_5 = v_i_245;
    v_x_240 = t_0;
    v_names_241 = t_1;
    v_ctx_242 = t_2;
    v_locals_243 = t_3;
    v_n_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_ctx_242);
  }
}
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2evarGo(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2evarGo_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_apply(v_v_2413, 1, (V[]){v_u_2416}));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eautoRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eautoRec_entry, 3, 0};

V g_heff_2eelab_2erules_2eautoRec(V v_sp_240, V v_x_241, V v_c_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eautoRec_lam0, 2, 3, (V[]){v_x_241, heff_dup(v_c_242), v_sp_240})});
}
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eautoRec(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 4);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 3, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_it_248 = ({ V a_0 = v_x_241; V a_1 = v_t_245; V a_2 = v_t_246; V a_3 = v_t_247; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_it_248)) {
  case TAG_Left: {
    V v_it1_249 = heff_field(v_it_248, 0);
    heff_take_n(v_it_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_NotInScope: {
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_c_242)) {
      case TAG_MkChk: {
        V v_f_2410 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 1);
        V f_ = v_f_2410;
        args[0] = v_e_243;
        args[1] = v_a_244;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_Delayed2: {
      V v_x1_2411 = (g_heff_2eelab_2evalue_2elevelOf(v_a_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Small: {
        V v_t_2412 = ({ V a_0 = v_sp_240; V a_1 = v_c_242; V r_ = (g_heff_2eelab_2erules_2erecChk(a_0, a_1)); heff_drop(v_c_242); r_; });
        switch (heff_tag_of(v_t_2412)) {
        case TAG_MkChk: {
          V v_f_2413 = heff_field(v_t_2412, 0);
          heff_take_n(v_t_2412, 1ULL, 1);
          V f_ = v_f_2413;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_Large: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2414 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2414;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_TopL: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2415 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2415;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Right: {
    heff_take_n(v_it_248, 0ULL, 1);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkChk: {
      V v_f_2417 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      V f_ = v_f_2417;
      args[0] = v_e_243;
      args[1] = v_a_244;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2eabandonChk_str0, 50, (99, 97, 110, 32, 111, 110, 108, 121, 32, 117, 115, 101, 32, 97, 98, 97, 110, 100, 111, 110, 32, 119, 104, 101, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 97, 116, 32, 97, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eabandonChk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_lam1, 2, 0};
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eabandonChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_entry, 1, 0};

V g_heff_2eelab_2erules_2eabandonChk(V v_sp_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam0, 2, 1, (V[]){v_sp_240})});
}
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eabandonChk(a[0]);
}
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eabandonM_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eabandonChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_241);
  V v_x1_243 = ({ V a_0 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_a_242); r_; });
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Small: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return ((V)&g_heff_2eelab_2erules_2eabandonChk_lam1_clo);
  }
  case TAG_False: {
    return heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam2, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimInt_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimInt_val;
static int g_heff_2eelab_2erules_2eprimInt_st;
static V g_heff_2eelab_2erules_2eprimInt_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimInt_get(void) {
  if (g_heff_2eelab_2erules_2eprimInt_st == 2) return g_heff_2eelab_2erules_2eprimInt_val;
  if (g_heff_2eelab_2erules_2eprimInt_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2erules_2eprimInt_st = 1;
  g_heff_2eelab_2erules_2eprimInt_val = heff_tr(g_heff_2eelab_2erules_2eprimInt_init());
  g_heff_2eelab_2erules_2eprimInt_st = 2;
  return g_heff_2eelab_2erules_2eprimInt_val;
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimFloat_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimFloat_val;
static int g_heff_2eelab_2erules_2eprimFloat_st;
static V g_heff_2eelab_2erules_2eprimFloat_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimFloat_get(void) {
  if (g_heff_2eelab_2erules_2eprimFloat_st == 2) return g_heff_2eelab_2erules_2eprimFloat_val;
  if (g_heff_2eelab_2erules_2eprimFloat_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2erules_2eprimFloat_st = 1;
  g_heff_2eelab_2erules_2eprimFloat_val = heff_tr(g_heff_2eelab_2erules_2eprimFloat_init());
  g_heff_2eelab_2erules_2eprimFloat_st = 2;
  return g_heff_2eelab_2erules_2eprimFloat_val;
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eprimArray_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimArray_entry, 1, 0};

V g_heff_2eelab_2erules_2eprimArray(V v_a_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam0, 1, 1, (V[]){heff_dup(v_a_240)})});
}
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eprimArray(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args) {
  V v_u_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_x1_249 = heff_tr(heff_apply(heff_get_n(v_x_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2413})});
}
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_SPrimArray, 1, (V[]){heff_dup(heff_rfield(v_x_246, 0))});
  V f_ = v_k_245;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam3, 1, 1, (V[]){v_x_246})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam2, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_a_240, 0);
    heff_take_n(v_a_240, 1ULL, 1);
    v_c_243 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_e_241}));
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam1, 2, 1, (V[]){v_c_243});
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimString_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimString_val;
static int g_heff_2eelab_2erules_2eprimString_st;
static V g_heff_2eelab_2erules_2eprimString_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimString_get(void) {
  if (g_heff_2eelab_2erules_2eprimString_st == 2) return g_heff_2eelab_2erules_2eprimString_val;
  if (g_heff_2eelab_2erules_2eprimString_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2erules_2eprimString_st = 1;
  g_heff_2eelab_2erules_2eprimString_val = heff_tr(g_heff_2eelab_2erules_2eprimString_init());
  g_heff_2eelab_2erules_2eprimString_st = 2;
  return g_heff_2eelab_2erules_2eprimString_val;
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimRune_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimRune_val;
static int g_heff_2eelab_2erules_2eprimRune_st;
static V g_heff_2eelab_2erules_2eprimRune_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimRune_get(void) {
  if (g_heff_2eelab_2erules_2eprimRune_st == 2) return g_heff_2eelab_2erules_2eprimRune_val;
  if (g_heff_2eelab_2erules_2eprimRune_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2erules_2eprimRune_st = 1;
  g_heff_2eelab_2erules_2eprimRune_val = heff_tr(g_heff_2eelab_2erules_2eprimRune_init());
  g_heff_2eelab_2erules_2eprimRune_st = 2;
  return g_heff_2eelab_2erules_2eprimRune_val;
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2enotANumber_str0, 8, (97, 32, 110, 117, 109, 98, 101, 114));
HEFF_STRA(g_heff_2eelab_2erules_2enotANumber_str1, 7, (97, 32, 102, 108, 111, 97, 116));
HEFF_STRA(g_heff_2eelab_2erules_2enotANumber_str2, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2enotANumber_str3, 22, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 108, 105, 116, 101, 114, 97, 108, 32));
HEFF_STRA(g_heff_2eelab_2erules_2enotANumber_str4, 11, (44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32));
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2enotANumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotANumber_entry, 4, 0};

V g_heff_2eelab_2erules_2enotANumber(V v_sp_240, V v_e_241, V v_a_242, V v_lit_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_245 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_h_245)) {
    case TAG_HLocal: {
      heff_take_n(v_h_245, 0ULL, 1);
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_245, 0ULL, 1);
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_245, 0ULL, 1);
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2425 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_245);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    heff_drop(v_e_241);
    return heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam0, 2, 1, (V[]){v_a_242});
  }
  case TAG_False: {
    return heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam3, 2, 4, (V[]){v_e_241, v_a_242, heff_dup(v_lit_243), v_sp_240});
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2enotANumber(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args) {
  V v_u_2429 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  return v_a_242;
}
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args) {
  V v_u_2428 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam2, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V v_t_2430 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam1, 1, 1, (V[]){v_a_242})});
  V f_ = v_k_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enotANumber_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_lit_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_2431 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    V v_i_2434 = heff_dup(heff_field(v_lit_243, 0));
    v_t_2436 = heff_intShow(v_i_2434);
    break;
  }
  case TAG_FracNum: {
    V v_x_2435 = heff_dup(heff_field(v_lit_243, 0));
    v_t_2436 = heff_floatShow(v_x_2435);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_t_2439;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    heff_take_n(v_lit_243, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2eelab_2erules_2enotANumber_str0);
    break;
  }
  case TAG_FracNum: {
    heff_take_n(v_lit_243, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2eelab_2erules_2enotANumber_str1);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_msg_2440 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str2), heff_strAppend(v_x_2433, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str3), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str4), v_t_2439)))));
  V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2440, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_take_field(v_hd_2431, 2), 1, (V[]){v_t_2443}));
  return heff_tail(heff_get_n(v_hd_2431, 1, 3), 2, (V[]){v_t_2444, v_k_2432});
}
V g_heff_2eelab_2erules_2enotANumber_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_lit_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2erules_2etyStrZ(v_e_241, v_a_242, heff_dup(v_hd_2431), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam4, 1, 4, (V[]){v_lit_243, v_sp_240, v_hd_2431, v_k_2432})));
}
HEFF_STRA(g_heff_2eelab_2erules_2eatFloat32_str0, 70, (32, 105, 115, 32, 111, 117, 116, 32, 111, 102, 32, 114, 97, 110, 103, 101, 32, 102, 111, 114, 32, 70, 108, 111, 97, 116, 51, 50, 44, 32, 119, 104, 111, 115, 101, 32, 103, 114, 101, 97, 116, 101, 115, 116, 32, 105, 115, 32, 51, 46, 52, 48, 50, 56, 50, 51, 52, 54, 54, 51, 56, 53, 50, 56, 56, 54, 101, 43, 51, 56));
HEFF_STRA(g_heff_2eelab_2erules_2eatFloat32_str1, 70, (32, 105, 115, 32, 111, 117, 116, 32, 111, 102, 32, 114, 97, 110, 103, 101, 32, 102, 111, 114, 32, 70, 108, 111, 97, 116, 51, 50, 44, 32, 119, 104, 111, 115, 101, 32, 103, 114, 101, 97, 116, 101, 115, 116, 32, 105, 115, 32, 51, 46, 52, 48, 50, 56, 50, 51, 52, 54, 54, 51, 56, 53, 50, 56, 56, 54, 101, 43, 51, 56));
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat32_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_lam3, 1, 0};
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2eatFloat32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_entry, 3, 0};

V g_heff_2eelab_2erules_2eatFloat32(V v_sp_240, V v_text_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
  V v_t_244 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
  V v_b_245 = heff_floatFromInt(heff_intSub(v_t_243, v_t_244));
  if (heff_floatLe_c(v_b_245, heff_dup(v_x_242))) {
    heff_drop(v_x_242);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam0, 2, 2, (V[]){v_text_241, v_sp_240});
  } else {
    V v_t_2413 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
    V v_t_2414 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
    V v_t_2415 = heff_floatFromInt(heff_intSub(v_t_2413, v_t_2414));
    if (heff_floatLe_c(heff_dup(v_x_242), v_t_2415)) {
      heff_drop(v_x_242);
      return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam1, 2, 2, (V[]){v_text_241, v_sp_240});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_text_241);
      return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam2, 2, 1, (V[]){v_x_242});
    }
  }
}
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat32(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str0)), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str1)), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2421}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2422;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam3(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2423);
  V v_t_2426 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFloat32, 1, (V[]){v_x_242}), ((V)&g_heff_2eelab_2erules_2eatFloat32_lam3_clo)});
  V f_ = v_k_2424;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str0, 4, (73, 110, 116, 56));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str1, 5, (73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str2, 5, (73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str3, 5, (73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str4, 5, (85, 73, 110, 116, 56));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str5, 6, (85, 73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str6, 6, (85, 73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str7, 6, (85, 73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str8, 7, (70, 108, 111, 97, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str9, 19, (44, 32, 119, 104, 111, 115, 101, 32, 118, 97, 108, 117, 101, 115, 32, 97, 114, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str10, 4, (32, 116, 111, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eintAtFixed_str11, 21, (32, 105, 115, 32, 111, 117, 116, 32, 111, 102, 32, 114, 97, 110, 103, 101, 32, 102, 111, 114, 32));
V g_heff_2eelab_2erules_2eintAtFixed_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_lam1, 1, 0};
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eintAtFixed_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2eintAtFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_entry, 3, 0};

V g_heff_2eelab_2erules_2eintAtFixed(V v_sp_240, V v_w_241, V v_i_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_w_241);
    HEFF_LAST return g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_intShow(heff_dup(v_i_242)), heff_floatFromInt(v_i_242));
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
    V v_t_247;
    if (heff_intLe_c(v_t_244, heff_dup(v_i_242))) {
      V v_t_246 = (g_heff_2eelab_2efixed_2efixedMax(v_w_241));
      v_t_247 = heff_intLe(heff_dup(v_i_242), v_t_246);
    } else {
      v_t_247 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_sp_240);
      return heff_clo_n(g_heff_2eelab_2erules_2eintAtFixed_lam0, 2, 2, (V[]){v_w_241, v_i_242});
    }
    case TAG_False: {
      V v_t_2412;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str0);
        break;
      }
      case TAG_I16: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str1);
        break;
      }
      case TAG_I32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str2);
        break;
      }
      case TAG_I64: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str3);
        break;
      }
      case TAG_U8: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str4);
        break;
      }
      case TAG_U16: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str5);
        break;
      }
      case TAG_U32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str6);
        break;
      }
      case TAG_U64: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str7);
        break;
      }
      case TAG_F32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str8);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_t_2413 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
      V v_t_2414 = ({ V a_0 = v_w_241; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_241); r_; });
      V v_why_2415 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str9), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str10), heff_intShow(v_t_2414)))));
      return heff_clo_n(g_heff_2eelab_2erules_2eintAtFixed_lam2, 2, 3, (V[]){v_i_242, v_why_2415, v_sp_240});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eintAtFixed_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_w_241 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_241, v_i_242}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_lam1_clo)});
  V f_ = v_k_249;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintAtFixed_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_i_242 = heff_env(self)[0];
  V v_why_2415 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_strAppend(heff_intShow(v_i_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str11), v_why_2415));
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2418, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_2421}));
  V f_ = heff_get_n(v_hd_2416, 1, 3);
  args[0] = v_t_2422;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enumLitAt_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitAt_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam5, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam4(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_entry, 4, 0};

V g_heff_2eelab_2erules_2enumLitAt(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_245 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_LikeU: {
      heff_take_n(v_t_245, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_245, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_245, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      return heff_clo_n(g_heff_2eelab_2erules_2enumLitAt_lam0, 2, 1, (V[]){v_i_244});
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      return heff_clo_n(g_heff_2eelab_2erules_2enumLitAt_lam2, 2, 1, (V[]){v_i_244});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2424 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      return (g_heff_2eelab_2erules_2eintAtFixed(v_sp_240, v_w_2424, v_i_244));
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_244}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_FracNum: {
    V v_x_2425 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2426 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2426, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2426, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2426, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2426, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      return heff_clo_n(g_heff_2eelab_2erules_2enumLitAt_lam4, 2, 1, (V[]){v_x_2425});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2426, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2441 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_w_2441)) {
      case TAG_I8: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_I16: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_I32: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_I64: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_U8: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_U16: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_U32: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_U64: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_F32: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_w_2441);
      }
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        heff_drop(v_e_241);
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
        return (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_floatShow(heff_dup(v_x_2425)), v_x_2425));
      }
      case TAG_False: {
        return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      }
      default: return heff_nomatch(v_t_2442);
      }
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, (V[]){v_x_2425}); V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_i_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_244}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam1_clo)});
  V f_ = v_k_2416;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitAt_lam3(V self, V *args) {
  V v_u_2422 = args[0];
  heff_drop(v_u_2422);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_i_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_SLitFloat, 1, (V[]){heff_floatFromInt(v_i_244)});
  V f_ = v_k_2420;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2421, ((V)&g_heff_2eelab_2erules_2enumLitAt_lam3_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitAt_lam5(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFloat, 1, (V[]){v_x_2425}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam5_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_entry, 4, 0};

V g_heff_2eelab_2erules_2enumLitDefault(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2411 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam0, 3, 1, (V[]){v_i_244})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return heff_tail(v_f_2412, 2, (V[]){v_e_241, v_a_242});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_FracNum: {
    V v_x_2413 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2420 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam2, 3, 1, (V[]){v_x_2413})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2420)) {
    case TAG_MkChk: {
      V v_f_2421 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      return heff_tail(v_f_2421, 2, (V[]){v_e_241, v_a_242});
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitDefault(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_hd_246 = args[1];
  V v_k_247 = args[2];
  V v_i_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_245);
  heff_drop(v_hd_246);
  V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_244}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam1_clo)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, NTAG(TAG_VPrimInt)});
  V f_ = v_k_247;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args) {
  V v_e_2414 = args[0];
  V v_hd_2415 = args[1];
  V v_k_2416 = args[2];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2414);
  heff_drop(v_hd_2415);
  V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFloat, 1, (V[]){v_x_2413}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam3_clo)});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_2416;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2enumLitWait_str0, 7, (108, 105, 116, 101, 114, 97, 108));
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait(V v_n_240, V v_sp_241, V v_lit_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam0, 4, 3, (V[]){v_sp_241, v_lit_242, v_n_240})});
}
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2433;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_it1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2434;
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_True: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2433);
  }
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    heff_drop(v_n_240);
    V v_t_2435 = (g_heff_2eelab_2erules_2enumLitAt(v_sp_241, v_e_243, v_x_2411, v_lit_242));
    return heff_tail(v_t_2435, 2, (V[]){v_hd_245, v_k_246});
  }
  case TAG_False: {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_n_240))) {
      switch (heff_tag_of(v_lit_242)) {
      case TAG_IntNum: {
        V v_c_2438 = (g_heff_2eelab_2erules_2enumLitWait(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_sp_241), v_lit_242));
        return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitWait_str0); V a_3 = v_c_2438; V a_4 = heff_dup(v_x_2411); V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2438); r_; });
      }
      case TAG_FracNum: {
        heff_drop(v_n_240);
        V v_t_2440 = heff_tr(g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242));
        return heff_tail(v_t_2440, 2, (V[]){v_hd_245, v_k_246});
      }
      default: return heff_nomatch(v_lit_242);
      }
    } else {
      heff_drop(v_n_240);
      V v_t_2441 = heff_tr(g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242));
      return heff_tail(v_t_2441, 2, (V[]){v_hd_245, v_k_246});
    }
  }
  default: return heff_nomatch(v_t_2434);
  }
}
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam2, 1, 6, (V[]){v_sp_241, v_e_243, v_lit_242, v_hd_245, v_k_246, v_n_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2enumLitChk_str0, 7, (108, 105, 116, 101, 114, 97, 108));
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitChk_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitChk(V v_sp_240, V v_lit_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam0, 4, 2, (V[]){v_sp_240, v_lit_241})});
}
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitChk(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  switch (heff_tag_of(v_t_2432)) {
  case TAG_True: {
    V v_c_2433 = (g_heff_2eelab_2erules_2enumLitWait(MK_INT(1LL), heff_dup(v_sp_240), v_lit_241));
    return ({ V a_0 = v_e_242; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitChk_str0); V a_3 = v_c_2433; V a_4 = heff_dup(v_x_2410); V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2433); r_; });
  }
  case TAG_False: {
    V v_t_2434 = (g_heff_2eelab_2erules_2enumLitAt(v_sp_240, v_e_242, v_x_2410, v_lit_241));
    return heff_tail(v_t_2434, 2, (V[]){v_hd_244, v_k_245});
  }
  default: return heff_nomatch(v_t_2432);
  }
}
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam2, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2enumLitSyn_str0, 7, (108, 105, 116, 101, 114, 97, 108));
V g_heff_2eelab_2erules_2enumLitSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitSyn(V v_sp_240, V v_lit_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam0, 3, 2, (V[]){v_sp_240, v_lit_241})});
}
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitSyn(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitSyn_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, ({ V b_0 = heff_get_n(v_x_248, 1, 2); V r_ = (g_heff_2eelab_2evalue_2edecodeN(b_0)); heff_drop(b_0); r_; })});
  V f_ = v_k_244;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitSyn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_a_249 = (g_heff_2eelab_2evalue_2edecodeN(heff_rfield(v_x_248, 1)));
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitChk(v_sp_240, v_lit_241));
  V v_c_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_MkChk: {
    V v_f_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    v_c_2412 = heff_tr(heff_apply(v_f_2411, 2, (V[]){v_e_242, v_a_249}));
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return heff_tail(v_c_2412, 2, (V[]){v_hd_243, heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam2, 1, 2, (V[]){v_x_248, v_k_244})});
}
V g_heff_2eelab_2erules_2enumLitSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_hd_243 = args[1];
  V v_k_244 = args[2];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_247 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return ({ V a_0 = v_t_245; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitSyn_str0); V a_4 = heff_dup(v_sp_240); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam1, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_243, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_246); r_; });
}
HEFF_STRA(g_heff_2eelab_2erules_2edefaultChk_str0, 87, (97, 32, 102, 105, 101, 108, 100, 39, 115, 32, 100, 101, 102, 97, 117, 108, 116, 32, 110, 97, 109, 101, 115, 32, 116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 98, 101, 102, 111, 114, 101, 32, 105, 116, 32, 97, 110, 100, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 44, 32, 110, 111, 116, 32, 116, 104, 101, 32, 116, 121, 112, 101, 39, 115, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 115));
V g_heff_2eelab_2erules_2edefaultChk_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultChk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultChk_lam3, 1, 0};
V g_heff_2eelab_2erules_2edefaultChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultChk_entry, 3, 0};

V g_heff_2eelab_2erules_2edefaultChk(V v_sp_240, V v_i_241, V v_c_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam0, 2, 3, (V[]){heff_dup(v_c_242), v_i_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edefaultChk(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2edefaultChk_lam3(V self, V *args) {
  V v_c0_2410 = args[0];
  return heff_get_n(v_c0_2410, 3, 8);
}
V g_heff_2eelab_2erules_2edefaultChk_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = ({ V a_0 = v_x_2414; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2414); r_; });
  V v_stx_2416 = heff_tr(heff_apply(heff_get_n(v_t_2415, 0, 2), 1, (V[]){heff_take_field(v_x_249, 0)}));
  V v_t_2417 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_i_241, v_stx_2416));
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop_rec(v_x_249, 2);
    heff_drop(v_stx_2416);
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(343LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2edefaultChk_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2420}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2421, v_k_248});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2422 = ({ V rv_0 = v_stx_2416; V rr_ = heff_rec_reuse_n(v_x_249, 2ULL, 2, shape_stx__val); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_248;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2erules_2edefaultChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2edefaultChk_lam3_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam4, 1, 5, (V[]){v_x_249, v_i_241, v_sp_240, v_hd_247, v_k_248})});
}
V g_heff_2eelab_2erules_2edefaultChk_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam2, 1, 4, (V[]){v_hd_247, v_i_241, v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edefaultChk_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_c_242)) {
  case TAG_MkChk: {
    V v_f_245 = heff_field(v_c_242, 0);
    heff_take_n(v_c_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 2, (V[]){v_e_243, v_a_244}));
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam1, 2, 3, (V[]){v_c_246, v_i_241, v_sp_240});
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultAt(V v_e_240, V v_i_241, V v_ty_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_i_241);
    heff_drop_rec(v_ty_242, 2);
    return ((V)&g_heff_2eelab_2erules_2edefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(heff_get_n(v_ty_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2411;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_a_2411 = v_x_248;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_247, 0ULL, 1);
      v_a_2411 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2410 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_a_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2412 = ({ V a_0 = heff_take_field(v_d_246, 1); V a_1 = v_i_241; V b_2 = heff_get_n(v_d_246, 0, 2); V r_ = (g_heff_2eelab_2erules_2edefaultChk(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_t_2412); r_; });
    V v_c_2415;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_MkChk: {
      V v_f_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      v_c_2415 = heff_tr(heff_apply(v_f_2414, 2, (V[]){v_e_240, v_a_2411}));
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam1, 2, 1, (V[]){v_c_2415});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaultAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2418, 0, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam2, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eformGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eformGo(V v_e_27_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_27_240, 6);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2eformGo_lam0_clo);
  }
  case TAG_Cons: {
    V v_fd_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_fd_246, 1));
    V v_c_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkTyp: {
      V v_f_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_c_2410 = heff_tr(heff_apply(v_f_249, 1, (V[]){heff_dup(v_e_27_240)}));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam1, 2, 5, (V[]){v_c_2410, v_e_27_240, v_i_241, v_fd_246, v_rest_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eformGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(3, shape_level__fields__defaults, (V[]){NTAG(TAG_Small), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_fd_246 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_l1_2425 = heff_take_field(v_x_2424, 0);
  V v_x1_2426 = heff_tr(heff_apply(heff_take_field(v_x_2413, 1), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_l2_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_t_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2427); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2428 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2428); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2429); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_t_2431;
  switch (heff_tag_of(v_l1_2425)) {
  case TAG_Small: {
    v_t_2431 = v_l2_2430;
    break;
  }
  case TAG_Large: {
    switch (heff_tag_of(v_l2_2430)) {
    case TAG_Small: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_Large: {
      v_t_2431 = v_l2_2430;
      break;
    }
    case TAG_TopL: {
      v_t_2431 = v_l2_2430;
      break;
    }
    default: heff_nomatch(v_l2_2430);
    }
    break;
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_l2_2430)) {
    case TAG_Small: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_Large: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_TopL: {
      v_t_2431 = v_l2_2430;
      break;
    }
    default: heff_nomatch(v_l2_2430);
    }
    break;
  }
  default: heff_nomatch(v_l1_2425);
  }
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_fd_246, 0)), heff_get_n(v_x_2413, 0, 2)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_take_field(v_x_2424, 1)});
  V v_ds_2434 = heff_get_n(v_x_2424, 2, 3);
  V v_t_2437;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop_rec(v_fd_246, 3);
    v_t_2437 = v_ds_2434;
    break;
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_fd_246, 0, 3), v_d_2435});
    v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_ds_2434});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_x_2438 = heff_rec_n(3, shape_level__fields__defaults, (V[]){v_t_2431, v_t_2433, v_t_2437});
  V f_ = v_k_2412;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_fd_246 = heff_env(self)[1];
  V v_e_27_240 = heff_env(self)[2];
  V v_i_241 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2416 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2413, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2420;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nom: {
    V v_x_2417 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = v_x_2417;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2420 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2419 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_sc_2421 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(heff_rfield(v_fd_246, 0)), v_t_2420, heff_take_field(v_e_27_240, 0)));
  V v_t_2422 = ({ V rv_0 = v_sc_2421; V rr_ = heff_rec_reuse_n(v_e_27_240, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_c_2423 = (g_heff_2eelab_2erules_2eformGo(v_t_2422, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_247));
  return heff_tail(v_c_2423, 2, (V[]){v_hd_2411, heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam4, 1, 4, (V[]){v_x_2413, v_fd_246, v_x_2415, v_k_2412})});
}
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_27_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_fd_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2414 = (g_heff_2eelab_2erules_2edefaultAt(heff_dup(v_e_27_240), heff_dup(v_i_241), heff_dup(v_x_2413), heff_dup(heff_rfield(v_fd_246, 2))));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam3, 1, 7, (V[]){v_x_2413, v_fd_246, v_e_27_240, v_i_241, v_rest_247, v_hd_2411, v_k_2412})});
}
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_27_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  V v_fd_246 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam2, 1, 6, (V[]){v_e_27_240, v_i_241, v_fd_246, v_hd_2411, v_rest_247, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2erecordFormation(V v_fieldTyps_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam0, 1, 1, (V[]){v_fieldTyps_240})});
}
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordFormation(a[0]);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  V v_pairs_2412 = heff_take_field(v_x_2410, 1);
  V v_t_2413 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_pairs_2412)));
  V v_t_2414 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2412));
  V v_t_2415 = (g_list_2emap_24s366344330x1145113647(v_pairs_2412));
  V v_t_2416 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2413), v_t_2414, heff_arrayFromList(v_t_2415)});
  V v_pairs_2417 = heff_take_field(v_x_2410, 2);
  V v_t_2418 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_pairs_2417)));
  V v_t_2419 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2417));
  V v_t_2420 = (g_list_2emap_24s366344330x1145113647(v_pairs_2417));
  V v_t_2421 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2418), v_t_2419, heff_arrayFromList(v_t_2420)});
  V v_x_2422 = (g_heff_2eelab_2ememoed_2erecordM(heff_get_n(v_e_241, 1, 6), v_t_2411, heff_get_n(v_x_2410, 0, 3), v_t_2416, v_t_2421));
  V f_ = v_k_249;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam2, 1, 2, (V[]){v_e_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_fieldTyps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_242 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_241, 0)), heff_dup(heff_rfield(v_e_241, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), heff_dup(heff_rfield(v_e_241, 5))});
  V v_sd_243 = heff_dup(heff_rfield(v_e_241, 0));
  V v_t_244 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_243, 3)});
  V v_sc_245 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_n(v_sd_243, 7ULL, 4, shape_len__names__locals__ctx); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_246 = ({ V rv_0 = v_sc_245; V rr_ = heff_rec_reuse_n(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_c_247 = (g_heff_2eelab_2erules_2eformGo(v_t_246, MK_INT(0LL), v_fieldTyps_240));
  return heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam1, 2, 2, (V[]){v_c_247, v_e_241});
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erecordName_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordName_entry, 7, 0};

V g_heff_2eelab_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VDecode: {
    V v_it1_248 = heff_field(v_a_241, 0);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_HLocal: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HGlobal: {
      V v_k_2414 = heff_field(v_it1_248, 0);
      V v_t_2415 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
      if (heff_intEq_c(v_t_2415, heff_strLength(heff_dup(v_x_242)))) {
        V v_t_2418 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam0, 1, 2, (V[]){v_e_240, v_ty_244})});
        V v_t_2419 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
        V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_p_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
        return heff_tail(heff_get_n(v_p_245, 1, 3), 2, (V[]){v_t_2420, v_p_246});
      } else {
        V v_t_2421 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
        V v_t_2422 = heff_intAdd(heff_strLength(heff_dup(v_x_242)), MK_INT(1LL));
        if (heff_intEq_c(v_t_2421, v_t_2422)) {
          V v_t_2425 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam1, 1, 2, (V[]){v_e_240, v_ty_244})});
          V v_t_2426 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
          V v_t_2427 = heff_tr(heff_apply(heff_take_field(v_p_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
          return heff_tail(heff_get_n(v_p_245, 1, 3), 2, (V[]){v_t_2427, v_p_246});
        } else {
          heff_drop(v_e_240);
          heff_drop(v_x_242);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_ty_244);
          heff_drop_rec(v_p_245, 3);
          return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
        }
      }
    }
    case TAG_HMeta: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HError: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecordName(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2417);
  return (g_heff_2eelab_2erules_2etyStr(v_e_240, v_ty_244));
}
V g_heff_2eelab_2erules_2erecordName_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2424);
  return (g_heff_2eelab_2erules_2etyStr(v_e_240, v_ty_244));
}
Clo g_heff_2eelab_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2erules_2eappendP(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2elookupP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elookupP_entry, 2, 0};

V g_heff_2eelab_2erules_2elookupP(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c(heff_dup(v_y_244), heff_dup(v_x_241))) {
        heff_drop(v_x_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2elookupP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2elookupP(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erebottom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erebottom_entry, 2, 0};

V g_heff_2eelab_2erules_2erebottom(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LNil: {
    heff_drop(v_v_240);
    return NTAG(TAG_LNil);
  }
  case TAG_LSnoc: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LNil: {
      heff_drop(v_x_243);
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam0, 1, 1, (V[]){v_v_240})});
    }
    case TAG_LSnoc: {
      V v_t_247 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_247, v_x_243});
    }
    case TAG_LChunkSnoc: {
      V v_t_2410 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_2410, v_x_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_LChunkSnoc: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_xs_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LChunkSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_LNil: {
      if (heff_intEq_c(heff_arrayLength(heff_dup(v_xs_2412)), MK_INT(1LL))) {
        heff_drop(v_xs_2412);
        return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam1, 1, 1, (V[]){v_v_240})});
      } else {
        heff_drop(v_v_240);
        return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){NTAG(TAG_LNil), v_xs_2412});
      }
    }
    case TAG_LSnoc: {
      V v_t_2417 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2417, v_xs_2412});
    }
    case TAG_LChunkSnoc: {
      V v_t_2420 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2420, v_xs_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erebottom(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_v_240;
}
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return v_v_240;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eadvanceSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eadvanceSelf_entry, 4, 0};

V g_heff_2eelab_2erules_2eadvanceSelf(V v_gk_240, V v_a_241, V v_fieldTypes_242, V v_done_243) {
top: ;
  V v_xs_244 = heff_dup(heff_rfield(v_fieldTypes_242, 0));
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_244)), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam0, 1, 4, (V[]){v_xs_244, heff_dup(v_done_243), heff_dup(v_gk_240), heff_dup(v_a_241)}));
  V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_fieldTypes_242, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2413 = heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VCons, 1, (V[]){v_t_2412})});
  V v_edesc_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  switch (heff_tag_of(v_edesc_2414)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam2, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing));
  }
  case TAG_Just: {
    V v_it1_2416 = heff_field(v_edesc_2414, 0);
    V v_ru_24edesc_2414_24Just = heff_take_reuse_n(v_edesc_2414, 1ULL, 1);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_it1_2416, 0);
      heff_take_n(v_it1_2416, 1ULL, 1);
      heff_drop(v_gk_240);
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24edesc_2414_24Just, 1);
      return v_v_2417;
    }
    case TAG_Describe: {
      V v_desc_2418 = heff_field(v_it1_2416, 0);
      V v_ru_24it1_2416_24Describe = heff_take_reuse_n(v_it1_2416, 1ULL, 1);
      HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_at_n(v_ru_24edesc_2414_24Just, TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam3, 1, 1, (V[]){v_a_241}), heff_tag_at_n(v_ru_24it1_2416_24Describe, TAG_Just, 1, (V[]){v_desc_2418}));
    }
    case TAG_Become: {
      V v_v_2420 = heff_field(v_it1_2416, 0);
      heff_take_n(v_it1_2416, 1ULL, 1);
      heff_drop(v_gk_240);
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24edesc_2414_24Just, 1);
      return v_v_2420;
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  default: return heff_nomatch(v_edesc_2414);
  }
}
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eadvanceSelf(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  V v_gk_240 = heff_env(self)[2];
  V v_a_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_246 = heff_arrayIndex(v_xs_244, v_i_245);
  V v_t_247 = ({ V a_0 = v_done_243; V a_1 = heff_dup(v_f_246); V r_ = (g_heff_2eelab_2erules_2elookupP(a_0, a_1)); heff_drop(v_done_243); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
    return (g_heff_2eelab_2evalue_2eproj(v_t_249, v_f_246));
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_gk_240);
    heff_drop(v_a_241);
    heff_drop(v_f_246);
    return heff_tag_at_n(v_ru_24t_247_24Just, TAG_Nom, 1, (V[]){v_v_2410});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args) {
  V v_u_2415 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eselfAdvance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_lam0, 1, 0};
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_entry, 5, 0};

V g_heff_2eelab_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    heff_drop(v_a_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){v_e_240});
  }
  case TAG_ForDescriptive: {
    V v_it1_246 = heff_field(v_t_245, 0);
    V v_it2_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HGlobal: {
      V v_gk_249 = heff_field(v_it1_246, 0);
      V v_ru_24it1_246_24HGlobal = heff_take_reuse_n(v_it1_246, 1ULL, 1);
      switch (heff_tag_of(v_it2_247)) {
      case TAG_SpId: {
        V v_t_2411 = heff_tag_at_n(v_ru_24it1_246_24HGlobal, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eselfAdvance_lam0_clo)})});
        V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tr(heff_apply(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2412}));
        return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam1, 1, 5, (V[]){v_a_241, v_p_244, v_e_240, v_gk_249, heff_dup(v_done_242)})});
      }
      case TAG_SpApp: {
        heff_take_n(v_it2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpProj: {
        heff_take_n(v_it2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpSpec: {
        heff_take_n(v_it2_247, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      default: return heff_nomatch(v_it2_247);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HError: {
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eselfAdvance(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 7, 8);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_gk_249 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2415, 0ULL, 4);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2423 = heff_field(v_t_2415, 2);
    heff_take_n(v_t_2415, 4ULL, 3);
    V v_t_2425;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x_2414, 0);
      heff_take_n(v_x_2414, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_gk_249));
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      V v_sc_2426 = heff_take_field(v_e_240, 0);
      V v_v_2427 = ({ V a_0 = v_gk_249; V a_1 = v_a_241; V a_2 = v_fieldTypes_2423; V a_3 = v_done_242; V r_ = (g_heff_2eelab_2erules_2eadvanceSelf(a_0, a_1, a_2, a_3)); heff_drop(v_done_242); r_; });
      V v_t_2428 = (g_heff_2eelab_2erules_2erebottom(v_v_2427, heff_take_field(v_sc_2426, 2)));
      V v_sc_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_n(v_sc_2426, 11ULL, 4, shape_len__names__locals__ctx); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_x_2430 = ({ V rv_0 = v_sc_2429; V rr_ = heff_rec_reuse_n(v_e_240, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
      V f_ = v_p_244;
      args[0] = v_x_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_a_241);
      heff_drop(v_gk_249);
      heff_drop(v_done_242);
      heff_drop(v_fieldTypes_2423);
      V f_ = v_p_244;
      args[0] = v_e_240;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2echeckFixed_str0, 15, (101, 120, 112, 101, 99, 116, 101, 100, 32, 118, 97, 108, 117, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2echeckFixed_str1, 16, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 118, 97, 108, 117, 101, 32));
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_lam0, 2, 0};
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args);
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_entry, 4, 0};

V g_heff_2eelab_2erules_2echeckFixed(V v_e_240, V v_sp_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2eelab_2erules_2echeckFixed_lam0_clo);
  }
  case TAG_Just: {
    V v_expected_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_c_247 = heff_dup(heff_rfield(v_e_240, 0));
    V v_cs_248 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_247, 0), heff_get_n(v_c_247, 1, 4)});
    V v_t_249 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), heff_dup(heff_rfield(v_e_240, 1)), v_cs_248, heff_dup(v_v_242), heff_dup(v_expected_246)));
    V v_c_2410 = heff_tr(heff_apply(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_249}));
    return heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_expected_246, v_v_242, v_sp_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckFixed(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_expected_246 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_c_2415 = heff_dup(heff_rfield(v_e_240, 0));
    V v_t_2416 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2415, 0), heff_get_n(v_c_2415, 1, 4)});
    V v_t_2417 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(heff_rfield(v_e_240, 1)), v_t_2416, v_expected_246));
    V v_c_2418 = heff_take_field(v_e_240, 0);
    V v_t_2419 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2418, 0), heff_get_n(v_c_2418, 1, 4)});
    V v_msg_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str0), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str1), (g_heff_2eelab_2erules_2eeqElStr(heff_dup(heff_rfield(v_e_240, 1)), v_t_2419, v_v_242)))));
    V v_note_2421 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2414; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2414); r_; });
    V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2420, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2421})});
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get_n(v_hd_2411, 1, 3), 2, (V[]){v_t_2425, v_k_2412});
  }
  case TAG_Right: {
    heff_take_n(v_x_2413, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_expected_246);
    heff_drop(v_v_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_2411, 3);
    V f_ = v_k_2412;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_expected_246 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam2, 1, 6, (V[]){v_e_240, v_expected_246, v_v_242, v_sp_241, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2eandList_str0, 0, (0));
HEFF_STRA(g_heff_2eelab_2erules_2eandList_str1, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eandList_str2, 2, (44, 32));
Clo g_heff_2eelab_2erules_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_entry, 1, 0};

V g_heff_2eelab_2erules_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_str2), (g_heff_2eelab_2erules_2eandList(v_x12_242))));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eandList(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str0, 0, (0));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str1, 2, (44, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str2, 0, (0));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str3, 2, (32, 40));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str4, 17, (32, 109, 97, 121, 32, 98, 101, 32, 108, 101, 102, 116, 32, 111, 117, 116, 41));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str5, 15, (116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 97, 114, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efieldsNote_str6, 15, (44, 32, 105, 110, 32, 116, 104, 105, 115, 32, 111, 114, 100, 101, 114));
Clo g_heff_2eelab_2erules_2efieldsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldsNote_entry, 1, 0};

V g_heff_2eelab_2erules_2efieldsNote(V v_it_240) {
top: ;
  V v_t_241 = heff_take_field(v_it_240, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_t_241, 0);
    V v_xs_243 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_it_240, 3)), 2, 3);
  V v_t_249;
  if (heff_intEq_c(heff_arrayLength(v_t_245), MK_INT(0LL))) {
    heff_drop_rec(v_it_240, 5);
    v_t_249 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str2);
  } else {
    V v_t_247 = heff_get_n(heff_get_n(v_it_240, 3, 5), 0, 3);
    V v_t_248 = ({ V b_0 = heff_arrayToList(v_t_247); V r_ = (g_heff_2eelab_2erules_2eandList(b_0)); heff_drop(b_0); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str3), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2erules_2efieldsNote_str4)));
  }
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str5), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str6), v_t_249)));
}
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldsNote(a[0]);
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args);
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultFor_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultFor(V v_x1_240, V v_g_241, V v_vs_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ForNominative: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_243), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam0, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  case TAG_ForDescriptive: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_243)}), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam1, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edefaultFor(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
}
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_247);
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2412});
}
HEFF_STRA(g_heff_2eelab_2erules_2enotGiven_str0, 21, (109, 105, 115, 115, 105, 110, 103, 32, 114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2enotGiven_str1, 22, (101, 120, 112, 101, 99, 116, 101, 100, 32, 114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2enotGiven_str2, 6, (32, 103, 111, 116, 58, 32));
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enotGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotGiven_entry, 3, 0};

V g_heff_2eelab_2erules_2enotGiven(V v_it_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_note_243 = (g_heff_2eelab_2erules_2efieldsNote(heff_dup(v_it_240)));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam0, 2, 3, (V[]){v_x_241, v_it_240, v_note_243});
  }
  case TAG_Cons: {
    V v_fs_2410 = heff_field(v_x3_242, 0);
    V v_note_2412 = (g_heff_2eelab_2erules_2efieldsNote(v_it_240));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam1, 2, 3, (V[]){v_x_241, heff_dup(v_fs_2410), v_note_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2enotGiven(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_it_240 = heff_env(self)[1];
  V v_note_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str0), v_x_241), heff_get_n(v_it_240, 0, 5), heff_tag_n(TAG_Just, 1, (V[]){v_note_243})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_248}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  args[0] = v_t_249;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_fs_2410 = heff_env(self)[1];
  V v_note_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str1), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str2), heff_dup(heff_rfield(v_fs_2410, 0)))));
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), v_t_2415, heff_get_n(v_fs_2410, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2412})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaulted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaulted_entry, 5, 0};

V g_heff_2eelab_2erules_2edefaulted(V v_e_240, V v_it_241, V v_x_242, V v_vs_243, V v_settings_244) {
top: ;
  V v_d_245 = heff_dup(heff_rfield(v_it_241, 3));
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_d_245, 1)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_vs_243);
    heff_drop_rec(v_d_245, 3);
    return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_xs_248 = heff_get_n(v_d_245, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_247))) {
      if (heff_intLt_c(heff_dup(v_i_247), heff_arrayLength(heff_dup(v_xs_248)))) {
        V v_d_2411 = heff_arrayIndex(v_xs_248, v_i_247);
        V v_t_2412 = heff_take_field(v_e_240, 2);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_ForNominative: {
          heff_drop(v_x_242);
          v_t_2415 = NTAG(TAG_ForNominative);
          break;
        }
        case TAG_ForDescriptive: {
          V v_h_2413 = heff_field(v_t_2412, 0);
          V v_sp_2414 = heff_field(v_t_2412, 1);
          V v_ru_24t_2412_24ForDescriptive = heff_take_reuse_n(v_t_2412, 3ULL, 2);
          v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2413, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2414, v_x_242})});
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = heff_get_n(v_e_240, 1, 6); V a_2 = v_vs_243; V a_3 = v_d_2411; V r_ = (g_heff_2eelab_2erules_2edefaultFor(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
        V v_x_2417 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_t_2416, heff_get_n(v_it_241, 0, 5), NTAG(TAG_True), v_settings_244});
        return heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam0, 2, 1, (V[]){v_x_2417});
      } else {
        heff_drop_rec(v_e_240, 6);
        heff_drop(v_vs_243);
        heff_drop(v_i_247);
        heff_drop(v_xs_248);
        return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
      }
    } else {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_vs_243);
      heff_drop(v_i_247);
      heff_drop(v_xs_248);
      return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaulted(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewritten_entry, 8, 0};

V g_heff_2eelab_2erules_2ewritten(V v_e_240, V v_it_241, V v_x_242, V v_fty_243, V v_fs_244, V v_rest_245, V v_hd_246, V v_k_247) {
top: ;
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_get_n(v_it_241, 1, 5); V a_2 = heff_dup(heff_rfield(v_fs_244, 0)); V a_3 = heff_dup(heff_rfield(v_fs_244, 3)); V a_4 = heff_dup(v_fty_243); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam0, 1, 7, (V[]){v_e_240, v_x_242, v_fs_244, v_fty_243, v_hd_246, v_rest_245, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewritten(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_x_2417, heff_get_n(v_fs_244, 2, 4), NTAG(TAG_False), v_rest_245});
  V f_ = v_k_247;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fs_244 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  V v_t_249 = heff_take_field(v_e_240, 2);
  V v_ef_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_ForNominative: {
    heff_drop(v_x_242);
    v_ef_2412 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2410 = heff_field(v_t_249, 0);
    V v_sp_2411 = heff_field(v_t_249, 1);
    V v_ru_24t_249_24ForDescriptive = heff_take_reuse_n(v_t_249, 3ULL, 2);
    v_ef_2412 = heff_tag_at_n(v_ru_24t_249_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2410, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2411, v_x_242})});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_e_2413 = ({ V rv_2 = v_ef_2412; V rr_ = heff_rec_reuse_n(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2414 = heff_dup(heff_rfield(v_fs_244, 1));
  V v_c_2416;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_MkChk: {
    V v_f_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    v_c_2416 = heff_tr(heff_apply(v_f_2415, 2, (V[]){v_e_2413, v_fty_243}));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  return heff_tail(v_c_2416, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam1, 1, 3, (V[]){v_fs_244, v_rest_245, v_k_247})});
}
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str0, 13, (114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str1, 15, (32, 105, 115, 32, 103, 105, 118, 101, 110, 32, 116, 119, 105, 99, 101));
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str2, 13, (114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str3, 16, (32, 105, 115, 32, 111, 117, 116, 32, 111, 102, 32, 111, 114, 100, 101, 114));
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str4, 14, (110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eleftOver_str5, 9, (32, 105, 110, 32, 116, 121, 112, 101, 32));
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eleftOver_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_lam0, 2, 0};
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam4(V self, V *args);
Clo g_heff_2eelab_2erules_2eleftOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_entry, 3, 0};

V g_heff_2eelab_2erules_2eleftOver(V v_e_240, V v_it_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_it_241, 5);
    return ((V)&g_heff_2eelab_2erules_2eleftOver_lam0_clo);
  }
  case TAG_Cons: {
    V v_fs_245 = heff_field(v_x3_242, 0);
    V v_xs_248 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam1, 1, 1, (V[]){heff_dup(v_fs_245)}), heff_dup(heff_rfield(v_it_241, 4))));
    V v_a_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    if (heff_intLt_c(MK_INT(1LL), v_a_249)) {
      heff_drop(v_e_240);
      V v_note_2411 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
      return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam2, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2411});
    } else {
      V v_t_2419 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_fs_245, 0))}));
      V v_t_2420 = (g_list_2eany(v_t_2419, heff_rfield(v_it_241, 2)));
      switch (heff_tag_of(v_t_2420)) {
      case TAG_True: {
        heff_drop(v_e_240);
        V v_note_2421 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam3, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2421});
      }
      case TAG_False: {
        V v_msg_2429 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str4), heff_strAppend(heff_dup(heff_rfield(v_fs_245, 0)), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str5), (g_heff_2eelab_2erules_2etyStr(v_e_240, heff_dup(heff_rfield(v_it_241, 1)))))));
        V v_note_2430 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam4, 2, 3, (V[]){v_msg_2429, heff_dup(v_fs_245), v_note_2430});
      }
      default: return heff_nomatch(v_t_2420);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eleftOver(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_fs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_x_247, heff_get_n(v_fs_245, 0, 4));
}
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str0), heff_strAppend(heff_dup(heff_rfield(v_fs_245, 0)), ((V)&g_heff_2eelab_2erules_2eleftOver_str1)));
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2414, heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2411})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str2), heff_strAppend(heff_dup(heff_rfield(v_fs_245, 0)), ((V)&g_heff_2eelab_2erules_2eleftOver_str3)));
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2424, heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2421})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_take_field(v_hd_2422, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2422, 1, 3);
  args[0] = v_t_2428;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_msg_2429 = heff_env(self)[0];
  V v_fs_245 = heff_env(self)[1];
  V v_note_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2429, heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2430})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_take_field(v_hd_2431, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2431, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eintroGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintroGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eintroGo(V v_e_240, V v_it_241, V v_done_242, V v_vs_243, V v_settings_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_done_242);
    heff_drop(v_vs_243);
    return ({ V a_0 = v_e_240; V a_1 = v_it_241; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2eleftOver(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_fieldC_249 = heff_field(v_x61_246, 1);
      heff_take_n(v_x61_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_apply(v_fieldC_249, 1, (V[]){heff_dup(v_vs_243)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_t_2410, 0);
        V v_fvalue_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_c_2416;
        switch (heff_tag_of(v_settings_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x6_245_24Cons, 2);
          v_c_2416 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), NTAG(TAG_Nil)));
          break;
        }
        case TAG_Cons: {
          V v_fs_2413 = heff_field(v_settings_244, 0);
          V v_rest_2414 = heff_field(v_settings_244, 1);
          heff_take_n(v_settings_244, 3ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_fs_2413, 0)), heff_dup(v_x_248))) {
            heff_drop_cell(v_ru_24x6_245_24Cons, 2);
            v_c_2416 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2ewritten_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_fty_2411), v_fs_2413, v_rest_2414}));
          } else {
            v_c_2416 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_fs_2413, v_rest_2414})));
          }
          break;
        }
        default: heff_nomatch(v_settings_244);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam0, 2, 9, (V[]){v_c_2416, v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_done_242, v_it_241, v_vs_243, v_rest_247});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintroGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args) {
  V v_u_2433 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_fty_2411;
}
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args) {
  V v_u_2444 = args[0];
  V v_v_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return v_v_2435;
}
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_fty_2411 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2447 = heff_rec_n(5, shape_name__ty__el__dflt__span, (V[]){v_x_248, v_fty_2411, heff_take_field(v_x_2419, 0), heff_take_field(v_x_2419, 2), heff_get_n(v_x_2419, 1, 4)});
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_it_241 = heff_env(self)[3];
  V v_vs_243 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  V v_hd_2417 = heff_env(self)[7];
  V v_fty_2411 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2435)}), NTAG(TAG_Nil)});
  V v_t_2443 = (g_heff_2eelab_2erules_2eappendP(v_done_242, v_t_2442));
  V v_c_2445 = (g_heff_2eelab_2erules_2eintroGo(v_x_2441, v_it_241, v_t_2443, heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam5, 1, 1, (V[]){v_v_2435})}), heff_dup(heff_rfield(v_x_2419, 3)), v_rest_247));
  return heff_tail(v_c_2445, 2, (V[]){v_hd_2417, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam6, 1, 4, (V[]){v_x_248, v_fty_2411, v_x_2419, v_k_2418})});
}
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_hd_2417 = heff_env(self)[5];
  V v_vs_243 = heff_env(self)[6];
  V v_x_2419 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_fty_2411 = heff_env(self)[9];
  V v_k_2418 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2435)}), NTAG(TAG_Nil)});
  V v_t_2439 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_done_242), v_t_2438));
  V v_c_2440 = heff_tr(heff_apply(((V)&g_heff_2eelab_2erules_2eselfAdvance_clo), 3, (V[]){v_e_240, heff_dup(heff_rfield(v_it_241, 1)), v_t_2439}));
  return heff_tail(v_c_2440, 2, (V[]){heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam4, 1, 10, (V[]){v_x_248, v_v_2435, v_done_242, v_it_241, v_vs_243, v_x_2419, v_rest_247, v_hd_2417, v_fty_2411, v_k_2418})});
}
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fty_2411 = heff_env(self)[2];
  V v_fvalue_2412 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2420 = heff_dup(heff_rfield(v_e_240, 2));
  V v_x1_2423;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_ForNominative: {
    v_x1_2423 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2421 = heff_field(v_t_2420, 0);
    V v_sp_2422 = heff_field(v_t_2420, 1);
    V v_ru_24t_2420_24ForDescriptive = heff_take_reuse_n(v_t_2420, 3ULL, 2);
    v_x1_2423 = heff_tag_at_n(v_ru_24t_2420_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2421, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2422, heff_dup(v_x_248)})});
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_x_2419, 0)), 1, 2);
  V v_x2_2425 = heff_tr(heff_apply(v_t_2424, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_v_2435;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_ForNominative: {
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nom: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = v_x_2426;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x2_2425, 0ULL, 1);
      v_v_2435 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2428 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2429 = heff_field(v_x1_2423, 0);
    V v_sp_2430 = heff_field(v_x1_2423, 1);
    heff_take_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nom: {
      V v_v_2431 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      heff_drop(v_h_2429);
      heff_drop(v_sp_2430);
      v_v_2435 = v_v_2431;
      break;
    }
    case TAG_Describe: {
      V v_desc_2432 = heff_field(v_x2_2425, 0);
      V v_ru_24x2_2425_24Describe = heff_take_reuse_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2429, v_sp_2430, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam2, 1, 1, (V[]){heff_dup(v_fty_2411)}), heff_tag_at_n(v_ru_24x2_2425_24Describe, TAG_Just, 1, (V[]){v_desc_2432})));
      break;
    }
    case TAG_Become: {
      V v_v_2434 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      heff_drop(v_h_2429);
      heff_drop(v_sp_2430);
      v_v_2435 = v_v_2434;
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  V v_c_2436 = (g_heff_2eelab_2erules_2echeckFixed(heff_dup(v_e_240), heff_dup(heff_rfield(v_x_2419, 1)), heff_dup(v_v_2435), v_fvalue_2412));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam3, 1, 11, (V[]){v_x_248, v_v_2435, v_done_242, v_e_240, v_it_241, v_hd_2417, v_vs_243, v_x_2419, v_rest_247, v_fty_2411, v_k_2418})});
}
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fty_2411 = heff_env(self)[3];
  V v_fvalue_2412 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam1, 1, 10, (V[]){v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_hd_2417, v_done_242, v_it_241, v_vs_243, v_rest_247, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2enamedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedFrom_entry, 3, 0};

V g_heff_2eelab_2erules_2enamedFrom(V v_x1_240, V v_i_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = heff_dup(heff_rfield(v_m_243, 3));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_242));
      V v_t_247 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_246));
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_m_243, 2)), 0, 2);
      V v_t_249 = heff_tr(heff_apply(heff_get_n(v_t_247, 0, 3), 2, (V[]){MK_INT(0LL), v_t_248}));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_i_241);
        heff_drop(v_j_242);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_244;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        v_x1_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_False: {
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2enamedFrom(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2erules_2eboundGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eboundGo(V v_all_240, V v_x2_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_all_240);
    heff_drop(v_j_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_245 = (g_list_2edrop(heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)), heff_dup(v_all_240)));
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)); V a_2 = heff_dup(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eelab_2erules_2eboundGo(v_all_240, v_rest_244, heff_intAdd(v_j_242, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eboundGo(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eplacesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesGo(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_b_242)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), (g_heff_2eelab_2erules_2eplacesGo(v_rest_243, heff_intAdd(v_k_241, MK_INT(1LL))))});
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), (g_heff_2eelab_2erules_2eplacesGo(v_rest_243, v_k_241))});
    }
    default: return heff_nomatch(v_b_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_entry, 2, 0};

V g_heff_2eelab_2erules_2efieldIdxs(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), (g_heff_2eelab_2erules_2efieldIdxs(v_at_240, v_rest_243))});
    }
    case TAG_Just: {
      V v_p_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_244);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eelab_2erules_2efieldIdxs(v_at_240, v_rest_243))});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs(a[0], a[1]);
}
V g_heff_2eelab_2erules_2ecodeAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecodeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecodeAt_entry, 5, 0};

V g_heff_2eelab_2erules_2ecodeAt(V v_n_240, V v_at_241, V v_places_242, V v_m_243, V v_i_244) {
top: ;
  V v_t_245 = heff_take_field(v_m_243, 3);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_n_240);
    V v_t_246 = (g_list_2etake(v_i_244, v_places_242));
    V v_t_247 = (g_heff_2eelab_2erules_2efieldIdxs(v_at_241, v_t_246));
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2esubstOf(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = heff_get_n(heff_get_n(v_m_243, 2, 5), 0, 2);
    return heff_tail(heff_get_n(v_t_248, 0, 2), 2, (V[]){MK_INT(0LL), v_t_249});
  }
  case TAG_False: {
    heff_drop(v_places_242);
    heff_drop(v_i_244);
    V v_t_2410 = heff_get_n(heff_get_n(v_m_243, 2, 5), 0, 2);
    if (heff_intEq_c(heff_dup(v_at_241), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_at_241);
      return v_t_2410;
    } else {
      V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(heff_dup(v_n_240), MK_INT(1LL))));
      V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2ecodeAt_lam0, 1, 2, (V[]){v_n_240, v_at_241}), v_t_2412));
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2eunify_2esubstOf(a_0)); heff_drop(v_t_2415); r_; });
      return heff_tail(heff_get_n(v_t_2416, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2410});
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecodeAt(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ecodeAt_lam0(V self, V *args) {
  V v_m_2413 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_at_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_intSub(heff_intSub(v_n_240, MK_INT(1LL)), v_m_2413);
  return heff_intAdd(v_t_2414, v_at_241);
}
Clo g_heff_2eelab_2erules_2eentriesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eentriesGo(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_246, 5);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_pl_248 = heff_field(v_x5_244, 0);
      V v_pls_249 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_pl_248)) {
      case TAG_Nothing: {
        v_t_2412 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_246), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_pl_248, 0);
        V v_ru_24pl_248_24Just = heff_take_reuse_n(v_pl_248, 1ULL, 1);
        V v_t_2411 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2410);
        v_t_2412 = heff_tag_at_n(v_ru_24pl_248_24Just, TAG_SLocal, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_pl_248);
      }
      V v_t_2413 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_246, 0, 5), v_t_2412});
      return heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, (g_heff_2eelab_2erules_2eentriesGo(v_n_240, v_k_241, v_places_242, v_rest_247, v_pls_249, heff_intAdd(v_i_245, MK_INT(1LL))))});
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_entry, 5, 0};

V g_heff_2eelab_2erules_2evaluesGo(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_245);
      heff_drop(v_rest_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_pls_248 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_Nothing: {
        heff_drop(v_m_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_246;
        V t_3 = v_pls_248;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        goto top;
      }
      case TAG_Just: {
        V v_p_249 = heff_field(v_x41_247, 0);
        heff_take_n(v_x41_247, 1ULL, 1);
        V v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_m_245), heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_249, heff_dup(v_places_241), v_m_245, heff_dup(v_i_244)))});
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eelab_2erules_2evaluesGo(v_n_240, v_places_241, v_rest_246, v_pls_248, heff_intAdd(v_i_244, MK_INT(1LL))))});
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2erules_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletsAround_entry, 5, 0};

V g_heff_2eelab_2erules_2eletsAround(V v_n_240, V v_a_241, V v_x3_242, V v_p_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_p_243);
    return v_body_244;
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_v_248 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_249 = (g_heff_2eelab_2evalue_2elevelOf(v_a_241));
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_take_field(v_m_247, 1)));
      V v_t_2411 = heff_tag_n(TAG_AbsConst, 1, (V[]){(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_dup(v_a_241)))});
      V v_t_2412 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_249, v_t_2410, v_t_2411, NTAG(TAG_Expl), NTAG(TAG_Nothing)});
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkAbs, 2, (V[]){heff_get_n(v_m_247, 0, 5), (g_heff_2eelab_2erules_2eletsAround(v_n_240, v_a_241, v_rest_246, heff_intAdd(v_p_243, MK_INT(1LL)), v_body_244))});
      return heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_t_2412, v_t_2413}), v_v_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletsAround(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2erules_2edescribes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribes_entry, 1, 0};

V g_heff_2eelab_2erules_2edescribes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_SU: {
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      return NTAG(TAG_False);
    }
    case TAG_SFunction: {
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edescribes(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2eelab_2erules_2edescribedBound_str0, 1, (96));
HEFF_STRA(g_heff_2eelab_2erules_2edescribedBound_str1, 107, (96, 32, 105, 115, 32, 97, 32, 116, 121, 112, 101, 32, 119, 114, 105, 116, 116, 101, 110, 32, 105, 110, 32, 112, 108, 97, 99, 101, 44, 32, 97, 110, 100, 32, 97, 32, 100, 101, 102, 97, 117, 108, 116, 32, 116, 104, 105, 115, 32, 114, 101, 99, 111, 114, 100, 32, 105, 115, 32, 103, 105, 118, 101, 110, 32, 110, 97, 109, 101, 115, 32, 105, 116, 58, 32, 100, 101, 102, 105, 110, 101, 32, 116, 104, 101, 32, 116, 121, 112, 101, 32, 97, 112, 97, 114, 116, 44, 32, 97, 110, 100, 32, 115, 101, 116, 32, 96));
HEFF_STRA(g_heff_2eelab_2erules_2edescribedBound_str2, 13, (96, 32, 116, 111, 32, 105, 116, 115, 32, 110, 97, 109, 101));
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam0, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam1, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2edescribedBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_entry, 2, 0};

V g_heff_2eelab_2erules_2edescribedBound(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam1_clo);
    }
    case TAG_Cons: {
      V v_b_248 = heff_field(v_x2_241, 0);
      V v_bs_249 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_b_248)) {
      case TAG_True: {
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_m_244, 2)), 0, 2);
        V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2edescribes(a_0)); heff_drop(v_t_2410); r_; });
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          return heff_clo_n(g_heff_2eelab_2erules_2edescribedBound_lam2, 2, 1, (V[]){heff_dup(v_m_244)});
        }
        case TAG_False: {
          V t_0 = v_rest_245;
          V t_1 = v_bs_249;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_2411);
        }
      }
      case TAG_False: {
        V t_0 = v_rest_245;
        V t_1 = v_bs_249;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_b_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2edescribedBound(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str0), heff_strAppend(heff_dup(heff_rfield(v_m_244, 0)), heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str1), heff_strAppend(heff_dup(heff_rfield(v_m_244, 0)), ((V)&g_heff_2eelab_2erules_2edescribedBound_str2)))));
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(344LL), NTAG(TAG_SError), v_t_2414, heff_get_n(v_m_244, 4, 5), NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elettedAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elettedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elettedAt_entry, 6, 0};

V g_heff_2eelab_2erules_2elettedAt(V v_e_240, V v_a_241, V v_made_242, V v_record_243, V v_bound_244, V v_places_245) {
top: ;
  V v_c_246 = (g_heff_2eelab_2erules_2edescribedBound(v_made_242, v_bound_244));
  return heff_clo_n(g_heff_2eelab_2erules_2elettedAt_lam0, 2, 7, (V[]){v_c_246, v_e_240, v_places_245, v_made_242, v_bound_244, v_a_241, v_record_243});
}
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elettedAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2elettedAt_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_places_245 = heff_env(self)[1];
  V v_made_242 = heff_env(self)[2];
  V v_bound_244 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_record_243 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2412 = (g_heff_2eelab_2erules_2evaluesGo(v_t_2411, heff_dup(v_places_245), heff_dup(v_made_242), heff_dup(v_places_245), MK_INT(0LL)));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_xs_2414 = (g_list_2efilter_24s328645370x374613117(v_bound_244));
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2414; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
  V v_pairs_2416 = (g_heff_2eelab_2erules_2eentriesGo(v_t_2413, v_t_2415, heff_dup(v_places_245), v_made_242, v_places_245, MK_INT(0LL)));
  V v_t_2417 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_pairs_2416)));
  V v_t_2418 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2416));
  V v_t_2419 = (g_list_2emap_24s366344330x1145113647(v_pairs_2416));
  V v_t_2420 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2417), v_t_2418, heff_arrayFromList(v_t_2419)});
  V v_t_2421 = (g_heff_2eelab_2erules_2eletsAround(v_t_2410, v_a_241, v_t_2412, MK_INT(0LL), heff_tag_n(TAG_SCons, 1, (V[]){v_t_2420})));
  V v_x_2422 = ({ V rv_0 = v_t_2421; V rr_ = heff_rec_reuse_n(v_record_243, 2ULL, 2, shape_stx__val); heff_rfield(rr_, 0) = rv_0; rr_; });
  V f_ = v_k_248;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_places_245 = heff_env(self)[2];
  V v_made_242 = heff_env(self)[3];
  V v_bound_244 = heff_env(self)[4];
  V v_a_241 = heff_env(self)[5];
  V v_record_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elettedAt_lam1, 1, 7, (V[]){v_e_240, v_places_245, v_made_242, v_bound_244, v_a_241, v_record_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eletted_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eletted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_entry, 3, 0};

V g_heff_2eelab_2erules_2eletted(V v_e_240, V v_a_241, V v_made_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_e_240, 2));
  V v_t_246;
  switch (heff_tag_of(v_t_243)) {
  case TAG_ForNominative: {
    v_t_246 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_243, 0ULL, 2);
    v_t_246 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_pairs_247 = (g_list_2emap_24s1224798844x1489231098(heff_dup(v_made_242)));
  V v_t_248 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_pairs_247)));
  V v_t_249 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_247));
  V v_t_2410 = (g_list_2emap_24s366344330x1145113647(v_pairs_247));
  V v_t_2411 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_248), v_t_249, heff_arrayFromList(v_t_2410)});
  V v_record_2412 = ({ V a_0 = v_t_246; V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2ememoed_2econs(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_bound_2413 = (g_heff_2eelab_2erules_2eboundGo(heff_dup(v_made_242), heff_dup(v_made_242), MK_INT(0LL)));
  V v_t_2414 = (g_list_2eany_24s228396297x1310020012(v_bound_2413));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    V v_t_2415 = (g_heff_2eelab_2erules_2eplacesGo(heff_dup(v_bound_2413), MK_INT(0LL)));
    return (g_heff_2eelab_2erules_2elettedAt(v_e_240, v_a_241, v_made_242, v_record_2412, v_bound_2413, v_t_2415));
  }
  case TAG_False: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_made_242);
    heff_drop(v_bound_2413);
    return heff_clo_n(g_heff_2eelab_2erules_2eletted_lam0, 2, 1, (V[]){v_record_2412});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eletted_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_record_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_record_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str0, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str1, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str2, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str3, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str4, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str5, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str6, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str7, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str8, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordIntro_str9, 55, (116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2erecordIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam0, 4, 2, (V[]){v_sp_240, v_fieldSettings_241})});
}
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordIntro(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordIntro_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e0_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436 = (g_heff_2eelab_2erules_2eletted(v_e0_242, v_x_2410, v_x_2435));
  return heff_tail(v_t_2436, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eelab_2erules_2erecordIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_fieldSettings_241 = heff_env(self)[3];
  V v_e0_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_LikeU: {
    V v_ru_24t_2411_24LikeU = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2416, v_k_245});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2411, 0ULL, 4);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2424, v_k_245});
  }
  case TAG_LikeRecord: {
    V v_capture_2426 = heff_field(v_t_2411, 1);
    V v_fieldTypes_2427 = heff_field(v_t_2411, 2);
    heff_take_n(v_t_2411, 6ULL, 3);
    V v_t_2428 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2427, 0)));
    V v_t_2429 = (g_heff_2eelab_2evalue_2edefaultsOf(heff_dup(v_x_2410)));
    V v_t_2430 = (g_list_2emap_24s2141157620x437287316(heff_dup(v_fieldSettings_241)));
    V v_t_2431 = heff_arrayToList(heff_take_field(v_fieldTypes_2427, 0));
    V v_t_2432 = heff_arrayToList(heff_get_n(v_fieldTypes_2427, 2, 3));
    V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
    V v_c_2434 = (g_heff_2eelab_2erules_2eintroGo(heff_dup(v_e0_242), heff_rec_n(5, shape_span__ty__keys__defaults__written, (V[]){v_sp_240, heff_dup(v_x_2410), v_t_2428, v_t_2429, v_t_2430}), NTAG(TAG_Nil), v_capture_2426, v_fieldSettings_241, v_t_2433));
    return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam3, 1, 4, (V[]){v_e0_242, v_x_2410, v_hd_244, v_k_245})});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2411_24LikeSum = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2439 = heff_tag_at_n(v_ru_24t_2411_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2440}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2441, v_k_245});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2444}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2445, v_k_245});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2449, v_k_245});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2452}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2453, v_k_245});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2456}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2457, v_k_245});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2411_24LikeArray = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2460 = heff_tag_at_n(v_ru_24t_2411_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2461}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2462, v_k_245});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2411_24LikeFixed = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_at_n(v_ru_24t_2411_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2467, v_k_245});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2468 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2470}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2471, v_k_245});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eelab_2erules_2erecordIntro_lam0(V self, V *args) {
  V v_e0_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_fieldSettings_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam2, 1, 5, (V[]){v_sp_240, v_hd_244, v_k_245, v_fieldSettings_241, v_e0_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efieldTyAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efieldTyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldTyAt_entry, 6, 0};

V g_heff_2eelab_2erules_2efieldTyAt(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_245), heff_dup(v_i_243))) {
    V v_t_247 = heff_arrayIndex(heff_dup(heff_rfield(v_fieldTypes_242, 2)), heff_dup(v_j_245));
    V v_t_248 = heff_tr(heff_apply(v_t_247, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){heff_dup(v_capture_241), heff_dup(v_before_244)})}));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkField: {
      V v_fty_249 = heff_field(v_t_248, 0);
      V v_fvalue_2410 = heff_field(v_t_248, 1);
      V v_ru_24t_248_24MkField = heff_take_reuse_n(v_t_248, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_fvalue_2410)) {
      case TAG_Nothing: {
        V v_t_2411 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_intAdd(heff_dup(v_len_240), heff_dup(v_j_245))});
        v_t_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2411, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efieldTyAt_lam0, 1, 1, (V[]){v_fty_249}), NTAG(TAG_Nothing)));
        break;
      }
      case TAG_Just: {
        V v_v_2413 = heff_field(v_fvalue_2410, 0);
        heff_take_n(v_fvalue_2410, 1ULL, 1);
        heff_drop(v_fty_249);
        v_t_2414 = v_v_2413;
        break;
      }
      default: heff_nomatch(v_fvalue_2410);
      }
      V v_t_2415 = heff_tag_at_n(v_ru_24t_248_24MkField, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2eelab_2erules_2eappendP(heff_arrayToList(v_before_244), v_t_2415));
      V t_0 = v_len_240;
      V t_1 = v_capture_241;
      V t_2 = v_fieldTypes_242;
      V t_3 = v_i_243;
      V t_4 = heff_arrayFromList(v_t_2416);
      V t_5 = heff_intAdd(v_j_245, MK_INT(1LL));
      v_len_240 = t_0;
      v_capture_241 = t_1;
      v_fieldTypes_242 = t_2;
      v_i_243 = t_3;
      v_before_244 = t_4;
      v_j_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  } else {
    heff_drop(v_j_245);
    V v_t_2417 = heff_arrayIndex(heff_get_n(v_fieldTypes_242, 2, 3), heff_dup(v_i_243));
    V v_t_2418 = heff_tr(heff_apply(v_t_2417, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_241, v_before_244})}));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_MkField: {
      V v_fty_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 2);
      V v_t_2421 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_len_240, v_i_243), heff_dup(v_fty_2419)));
      V v_t_2422 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2421; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_t_2421); r_; });
      switch (heff_tag_of(v_t_2422)) {
      case TAG_True: {
        heff_drop(v_fty_2419);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        return heff_tag_n(TAG_Just, 1, (V[]){v_fty_2419});
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
}
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldTyAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efieldTyAt_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_fty_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_fty_249;
}
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str0, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str1, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str2, 14, (110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str3, 9, (32, 105, 110, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str4, 14, (116, 104, 101, 32, 116, 121, 112, 101, 32, 111, 102, 32, 96, 46));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str5, 79, (96, 32, 100, 101, 112, 101, 110, 100, 115, 32, 111, 110, 32, 116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 98, 101, 102, 111, 114, 101, 32, 105, 116, 44, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 116, 104, 105, 115, 32, 114, 101, 99, 111, 114, 100, 39, 115, 32, 97, 114, 101, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 32, 104, 101, 114, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str6, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str7, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str8, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str9, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str10, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str11, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str12, 59, (116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str13, 45, (116, 104, 101, 32, 114, 101, 99, 111, 114, 100, 39, 115, 32, 115, 104, 97, 112, 101, 32, 105, 115, 32, 110, 111, 116, 32, 105, 110, 32, 104, 97, 110, 100, 32, 104, 101, 114, 101, 32, 102, 111, 114, 32, 96, 46));
HEFF_STRA(g_heff_2eelab_2erules_2erecordElim_str14, 84, (96, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 116, 104, 101, 32, 98, 105, 110, 100, 101, 114, 44, 32, 96, 92, 40, 120, 32, 58, 32, 84, 41, 32, 45, 62, 32, 46, 46, 46, 96, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 96, 40, 97, 32, 58, 61, 32, 84, 41, 96));
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_entry, 3, 0};

V g_heff_2eelab_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam0, 1, 3, (V[]){heff_dup(v_projectee_241), v_sp_240, v_x_242})});
}
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecordElim(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2411, 3, 8); V a_1 = v_a0_2410; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2422, v_k_247});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2431, v_k_247});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_eprojectee_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fieldTy_2461 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2462);
  V v_t_2463 = (g_heff_2eelab_2ememoed_2eprojAt(v_eprojectee_249, v_x_242, heff_dup(v_fieldTy_2461)));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_fieldTy_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_eprojectee_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_fieldTy_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2465);
  V v_t_2466 = (g_heff_2eelab_2ememoed_2eproj(v_eprojectee_249, v_x_242));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2466, v_fieldTy_2464});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2468)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2471}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2472, v_k_247});
  }
  default: return heff_nomatch(v_x_2468);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args) {
  V v_x_2473 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2473)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2476}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2477, v_k_247});
  }
  default: return heff_nomatch(v_x_2473);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2478)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2481}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2482, v_k_247});
  }
  default: return heff_nomatch(v_x_2478);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2483)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2486}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2487, v_k_247});
  }
  default: return heff_nomatch(v_x_2483);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2488)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2489 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2491}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2492, v_k_247});
  }
  default: return heff_nomatch(v_x_2488);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2494)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2497}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2498, v_k_247});
  }
  default: return heff_nomatch(v_x_2494);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args) {
  V v_x_24100 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24100)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_24101 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24103}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24104, v_k_247});
  }
  default: return heff_nomatch(v_x_24100);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24105)) {
  case TAG_True: {
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_24106 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str13), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str14)));
    V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_24106, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24109}));
    return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24110, v_k_247});
  }
  default: return heff_nomatch(v_x_24105);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_eprojectee_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam5, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2416, 0ULL, 4);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam6, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeRecord: {
    V v_capture_2433 = heff_field(v_t_2416, 1);
    V v_fieldTypes_2434 = heff_field(v_t_2416, 2);
    heff_take_n(v_t_2416, 6ULL, 3);
    V v_x3_2435 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2434, 1)));
    V v_x1_2437;
    switch (heff_tag_of(v_x3_2435)) {
    case TAG_Nothing: {
      v_x1_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2435, 0ULL, 1);
      v_x1_2437 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2435);
    }
    V v_t_2438;
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_True: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2437);
    }
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      heff_drop_rec(v_eprojectee_249, 2);
      heff_drop(v_capture_2433);
      heff_drop_rec(v_fieldTypes_2434, 3);
      V v_msg_2439 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str2), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str3), (g_heff_2eelab_2erules_2etyStr(v_e_243, v_x_2415)))));
      V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2439, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2442}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2443, v_k_247});
    }
    case TAG_False: {
      V v_x1_2444 = heff_tr(heff_apply(heff_dup(heff_rfield(v_eprojectee_249, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_v_2448;
      switch (heff_tag_of(v_x1_2444)) {
      case TAG_Nom: {
        V v_x_2445 = heff_field(v_x1_2444, 0);
        heff_take_n(v_x1_2444, 1ULL, 1);
        v_v_2448 = v_x_2445;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2444, 0ULL, 1);
        v_v_2448 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2447 = heff_field(v_x1_2444, 0);
        heff_take_n(v_x1_2444, 1ULL, 1);
        v_v_2448 = v_x_2447;
        break;
      }
      default: heff_nomatch(v_x1_2444);
      }
      V v_t_2449 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_2448));
      V v_t_2450 = (g_heff_2eelab_2evalue_2eprojTyWith(heff_dup(v_x_2415), v_t_2449, heff_dup(v_x_242)));
      switch (heff_tag_of(v_t_2450)) {
      case TAG_Nothing: {
        V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
        V v_t_2452 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2434, 1)));
        V v_t_2454;
        switch (heff_tag_of(v_t_2452)) {
        case TAG_Nothing: {
          v_t_2454 = heff_abandon();
          break;
        }
        case TAG_Just: {
          V v_i_2453 = heff_field(v_t_2452, 0);
          heff_take_n(v_t_2452, 1ULL, 1);
          v_t_2454 = v_i_2453;
          break;
        }
        default: heff_nomatch(v_t_2452);
        }
        V v_t_2455 = (g_heff_2eelab_2erules_2efieldTyAt(v_t_2451, v_capture_2433, v_fieldTypes_2434, v_t_2454, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_t_2455)) {
        case TAG_Nothing: {
          heff_drop(v_x_2415);
          heff_drop_rec(v_e_243, 6);
          heff_drop_rec(v_eprojectee_249, 2);
          V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str4), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str5)));
          V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2456, v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
          V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
          V v_t_2460 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2459}));
          return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2460, v_k_247});
        }
        case TAG_Just: {
          V v_fieldTy_2461 = heff_field(v_t_2455, 0);
          heff_take_n(v_t_2455, 1ULL, 1);
          return ({ V a_0 = v_e_243; V a_1 = v_x_2415; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2461); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam7, 1, 4, (V[]){v_eprojectee_249, v_x_242, v_fieldTy_2461, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2415); r_; });
        }
        default: return heff_nomatch(v_t_2455);
        }
      }
      case TAG_Just: {
        V v_fieldTy_2464 = heff_field(v_t_2450, 0);
        heff_take_n(v_t_2450, 1ULL, 1);
        heff_drop(v_capture_2433);
        heff_drop_rec(v_fieldTypes_2434, 3);
        return ({ V a_0 = v_e_243; V a_1 = v_x_2415; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2464); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam8, 1, 4, (V[]){v_eprojectee_249, v_x_242, v_k_247, v_fieldTy_2464}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2415); r_; });
      }
      default: return heff_nomatch(v_t_2450);
      }
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam9, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam10, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam11, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeString: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam12, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam13, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam14, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam15, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_249, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam16, 1, 4, (V[]){v_hd_246, v_k_247, v_x_242, v_sp_240})));
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_eprojectee_249 = heff_field(v_x_248, 0);
    V v_a0_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam3, 1, 1, (V[]){v_a0_2410})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
    return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam4, 1, 6, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243, v_eprojectee_249})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam2, 1, 5, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_projectee_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_projectee_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_projectee_241, 0);
    heff_take_n(v_projectee_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_projectee_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam1, 2, 4, (V[]){v_c_245, v_sp_240, v_x_242, v_e_243});
}
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str0, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str1, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str2, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str3, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str4, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str5, 14, (110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str6, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str7, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str8, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str9, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str10, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str11, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str12, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str13, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str14, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str15, 45, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str16, 27, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str17, 27, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str18, 27, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108));
HEFF_STRA(g_heff_2eelab_2erules_2erecordSpec_str19, 27, (99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108));
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordSpec_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_x_242, heff_dup(v_c_243)})});
}
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecordSpec(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args) {
  V v_x_2480 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2especializeM(v_g_2410, v_x_242, v_x_2480));
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2481, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_c_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x_249, 0);
    V v_a_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_x1_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_g_2410, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2413;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      v_t_2416 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_VNeu: {
      V v_desc_2421 = heff_field(v_t_2416, 4);
      heff_take_n(v_t_2416, 16ULL, 5);
      V v_it_2422 = heff_tr(heff_apply(v_desc_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_it_2422)) {
      case TAG_Nothing: {
        heff_drop(v_x_242);
        heff_drop_rec(v_e_244, 6);
        heff_drop(v_c_243);
        heff_drop_rec(v_g_2410, 2);
        heff_drop(v_a_2411);
        V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str0), v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
        return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2426, v_k_248});
      }
      case TAG_Just: {
        V v_it1_2427 = heff_field(v_it_2422, 0);
        V v_ru_24it_2422_24Just = heff_take_reuse_n(v_it_2422, 1ULL, 1);
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_VNeu: {
          heff_take_n(v_it1_2427, 0ULL, 5);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str1), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2434 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2435}));
          return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2436, v_k_248});
        }
        case TAG_VCode: {
          V v_it11_2437 = heff_field(v_it1_2427, 0);
          V v_ru_24it1_2427_24VCode = heff_take_reuse_n(v_it1_2427, 1ULL, 1);
          switch (heff_tag_of(v_it11_2437)) {
          case TAG_VU: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str2), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
            V v_t_2441 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
            V v_t_2442 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2441}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2442, v_k_248});
          }
          case TAG_VDecode: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str3), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2449 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
            V v_t_2450 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2450}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2451, v_k_248});
          }
          case TAG_VFunction: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str4), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2458 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2459}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2460, v_k_248});
          }
          case TAG_VRecord: {
            V v_capture_2462 = heff_field(v_it11_2437, 1);
            V v_fieldTypes_2463 = heff_field(v_it11_2437, 2);
            heff_take_n(v_it11_2437, 6ULL, 4);
            V v_x3_2465 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2463, 1)));
            V v_t_2467;
            switch (heff_tag_of(v_x3_2465)) {
            case TAG_Nothing: {
              v_t_2467 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2465, 0ULL, 1);
              v_t_2467 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2465);
            }
            switch (heff_tag_of(v_t_2467)) {
            case TAG_True: {
              heff_drop(v_sp_240);
              heff_drop_cell(v_ru_24it1_2427_24VCode, 1);
              V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
              V v_t_2469 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2463, 0)));
              V v_t_2470 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2463, 2)));
              V v_t_2471 = (g_heff_2eutil_2edict_2ezipKV(v_t_2469, v_t_2470));
              V v_xs_2472 = (g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(heff_dup(v_capture_2462), heff_tag_at_n(v_ru_24it_2422_24Just, TAG_HLocal, 1, (V[]){v_t_2468}), NTAG(TAG_SpId), NTAG(TAG_Nothing), v_t_2471, NTAG(TAG_Nil)));
              V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2472));
              V v_t_2474 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_2463, 0)), heff_dup(heff_rfield(v_fieldTypes_2463, 1)), heff_arrayFromList(v_t_2473)});
              V v_t_2475 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2462, v_fieldTypes_2463, heff_dup(v_x_242), v_t_2474));
              switch (heff_tag_of(v_t_2475)) {
              case TAG_MkField: {
                V v_fty_2476 = heff_field(v_t_2475, 0);
                heff_take_n(v_t_2475, 1ULL, 2);
                V v_c_2479;
                switch (heff_tag_of(v_c_243)) {
                case TAG_MkChk: {
                  V v_f_2478 = heff_field(v_c_243, 0);
                  heff_take_n(v_c_243, 1ULL, 1);
                  v_c_2479 = heff_tr(heff_apply(v_f_2478, 2, (V[]){v_e_244, v_fty_2476}));
                  break;
                }
                default: heff_nomatch(v_c_243);
                }
                return heff_tail(v_c_2479, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam3, 1, 4, (V[]){v_g_2410, v_x_242, v_k_248, v_a_2411})});
              }
              default: return heff_nomatch(v_t_2475);
              }
            }
            case TAG_False: {
              heff_drop_rec(v_e_244, 6);
              heff_drop(v_c_243);
              heff_drop_rec(v_g_2410, 2);
              heff_drop(v_a_2411);
              heff_drop(v_capture_2462);
              heff_drop_rec(v_fieldTypes_2463, 3);
              V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordSpec_str5), v_x_242), v_sp_240, NTAG(TAG_Nothing)});
              V v_t_2483 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
              V v_t_2484 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
              V v_t_2485 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2484}));
              return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2485, v_k_248});
            }
            default: return heff_nomatch(v_t_2467);
            }
          }
          case TAG_VSum: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2487 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str6), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2488 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2487})});
            V v_t_2489 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
            V v_t_2490 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2489}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2490, v_k_248});
          }
          case TAG_VPrimInt: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str7), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2492 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
            V v_t_2493 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
            V v_t_2494 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2493}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2494, v_k_248});
          }
          case TAG_VPrimFloat: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str8), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2496 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
            V v_t_2497 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
            V v_t_2498 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2497}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2498, v_k_248});
          }
          case TAG_VPrimString: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str9), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24100 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
            V v_t_24101 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
            V v_t_24102 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24101}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24102, v_k_248});
          }
          case TAG_VPrimRune: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str10), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24104 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
            V v_t_24105 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
            V v_t_24106 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24105}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24106, v_k_248});
          }
          case TAG_VPrimArray: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str11), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24109 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
            V v_t_24110 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
            V v_t_24111 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24110}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24111, v_k_248});
          }
          case TAG_VFixed: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str12), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24114 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
            V v_t_24115 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
            V v_t_24116 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24115}));
            return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24116, v_k_248});
          }
          default: return heff_nomatch(v_it11_2437);
          }
        }
        case TAG_VLam: {
          heff_take_n(v_it1_2427, 0ULL, 2);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24119 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str13), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24120 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24119})});
          V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
          V v_t_24122 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24121}));
          return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24122, v_k_248});
        }
        case TAG_VCons: {
          V v_ru_24it1_2427_24VCons = heff_take_reuse_n(v_it1_2427, 0ULL, 1);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str14), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24125 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24124})});
          V v_t_24126 = heff_tag_at_n(v_ru_24it1_2427_24VCons, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
          V v_t_24127 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24126}));
          return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24127, v_k_248});
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str15), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24129 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
          V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
          V v_t_24131 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24130}));
          return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24131, v_k_248});
        }
        default: return heff_nomatch(v_it1_2427);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_VCode: {
      V v_ru_24t_2416_24VCode = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str16), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24134 = heff_tag_at_n(v_ru_24t_2416_24VCode, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24135}));
      return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24136, v_k_248});
    }
    case TAG_VLam: {
      heff_take_n(v_t_2416, 0ULL, 2);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str17), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
      V v_t_24142 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24141}));
      return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24142, v_k_248});
    }
    case TAG_VCons: {
      V v_ru_24t_2416_24VCons = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str18), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24145 = heff_tag_at_n(v_ru_24t_2416_24VCons, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24144})});
      V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
      V v_t_24147 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24146}));
      return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24147, v_k_248});
    }
    case TAG_VOpaque: {
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str19), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24149 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24148})});
      V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
      V v_t_24151 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24150}));
      return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24151, v_k_248});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_c_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam2, 1, 6, (V[]){v_sp_240, v_hd_247, v_k_248, v_x_242, v_e_244, v_c_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_x_242, v_e_244, v_c_243});
}
V g_heff_2eelab_2erules_2etraverseE_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etraverseE_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etraverseE_lam0, 2, 0};
V g_heff_2eelab_2erules_2etraverseE_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etraverseE_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etraverseE_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etraverseE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etraverseE_entry, 2, 0};

V g_heff_2eelab_2erules_2etraverseE(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2erules_2etraverseE_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etraverseE(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etraverseE_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etraverseE_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etraverseE_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2erules_2etraverseE(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eelab_2erules_2etraverseE_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2esumFormation(V v_vs_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam0, 1, 1, (V[]){v_vs_240})});
}
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation(a[0]);
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args) {
  V v_t_248 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_249 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_241, 0)), heff_take_field(v_e_241, 1), NTAG(TAG_ForNominative), heff_take_field(v_e_241, 3), heff_take_field(v_e_241, 4), heff_take_field(v_e_241, 5)});
  V v_sd_2410 = heff_get_n(v_e_241, 0, 6);
  V v_t_2411 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_2410, 3)});
  V v_sc_2412 = ({ V rv_3 = v_t_2411; V rr_ = heff_rec_reuse_n(v_sd_2410, 7ULL, 4, shape_len__names__locals__ctx); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_e_2413 = ({ V rv_0 = v_sc_2412; V rr_ = heff_rec_reuse_n(v_e_249, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_MkSmallTyp: {
    V v_f_2414 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V f_ = v_f_2414;
    args[0] = v_e_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, heff_arrayFromList(v_x_2418)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam4, 1, 2, (V[]){v_k_246, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args) {
  V v_p_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_ts_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_c_2415 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam2, 1, 1, (V[]){v_e_241}), heff_arrayToList(v_ts_247)));
    return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam3, 2, 2, (V[]){v_c_2415, v_k_246});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_x_2423)));
  V v_t_2425 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2423));
  V v_t_2426 = (g_list_2emap_24s366344330x1145113647(v_x_2423));
  V v_t_2427 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2424), v_t_2425, heff_arrayFromList(v_t_2426)});
  V v_x_2428 = (g_heff_2eelab_2ememoed_2esumM(v_t_2427));
  V f_ = v_k_2422;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam6, 1, 1, (V[]){v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_vs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_arrayToList(heff_take_field(v_vs_240, 0));
  V v_t_243 = heff_arrayToList(heff_get_n(v_vs_240, 2, 3));
  V v_t_244 = (g_heff_2eutil_2edict_2ezipKV(v_t_242, v_t_243));
  V v_c_2420 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam1, 1, 1, (V[]){v_e_241}), v_t_244));
  return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam5, 2, 1, (V[]){v_c_2420});
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam1, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam2, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2etagArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_entry, 3, 0};

V g_heff_2eelab_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam0_clo);
    }
    case TAG_Cons: {
      heff_take_n(v_x3_242, 0ULL, 2);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam1_clo);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Cons: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_cs_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_c_249);
      heff_drop(v_cs_2410);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam2_clo);
    }
    case TAG_Cons: {
      V v_t_2413 = heff_field(v_x3_242, 0);
      V v_ts_2414 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2415 = heff_tr(heff_apply(v_t_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_c_2417;
      switch (heff_tag_of(v_c_249)) {
      case TAG_MkChk: {
        V v_f_2416 = heff_field(v_c_249, 0);
        heff_take_n(v_c_249, 1ULL, 1);
        v_c_2417 = heff_tr(heff_apply(v_f_2416, 2, (V[]){heff_dup(v_e_240), v_a_2415}));
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam3, 2, 4, (V[]){v_c_2417, v_e_240, v_cs_2410, v_ts_2414});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagArgsGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cs_2410 = heff_env(self)[1];
  V v_ts_2414 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2421 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_240, v_cs_2410, v_ts_2414));
  return heff_tail(v_c_2421, 2, (V[]){v_hd_2418, heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam5, 1, 2, (V[]){v_k_2419, v_x_2420})});
}
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cs_2410 = heff_env(self)[2];
  V v_ts_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam4, 1, 5, (V[]){v_e_240, v_cs_2410, v_ts_2414, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str0, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str1, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str2, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str3, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str4, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str5, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str6, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str7, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str8, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str9, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str10, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str11, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str12, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str13, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str14, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str15, 12, (110, 111, 32, 115, 117, 99, 104, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str16, 9, (32, 105, 110, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str17, 34, (119, 114, 111, 110, 103, 32, 110, 117, 109, 98, 101, 114, 32, 111, 102, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 102, 111, 114, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str18, 9, (32, 105, 110, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str19, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str20, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str21, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str22, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str23, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str24, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str25, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str26, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str27, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str28, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str29, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str30, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str31, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str32, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str33, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str34, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str35, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str36, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str37, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str38, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str39, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str40, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str41, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str42, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str43, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str44, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str45, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str46, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str47, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str48, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str49, 74, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str50, 10, (32, 46, 46, 46, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str51, 14, (101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str52, 18, (44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumIntroNow_str53, 63, (32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103));
V g_heff_2eelab_2erules_2esumIntroNow_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_lam6, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumIntroNow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_entry, 4, 0};

V g_heff_2eelab_2erules_2esumIntroNow(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam0, 4, 4, (V[]){v_x_242, v_sp_240, v_tsp_241, v_cs_243})});
}
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntroNow(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntroNow_lam5(V self, V *args) {
  V v_i_24144 = args[0];
  V v_gs_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_24145 = heff_arrayIndex(v_gs_24143, v_i_24144);
  return heff_get_n(v_m_24145, 0, 2);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam6(V self, V *args) {
  V v_u_24147 = args[0];
  heff_drop(v_u_24147);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2esumIntroNow_lam4(V self, V *args) {
  V v_x_24142 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_24143 = heff_arrayFromList(v_x_24142);
  V v_t_24146 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_gs_24143)), heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam5, 1, 1, (V[]){v_gs_24143}));
  V v_x_24148 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_x_242, v_t_24146}), ((V)&g_heff_2eelab_2erules_2esumIntroNow_lam6_clo)});
  V f_ = v_k_247;
  args[0] = v_x_24148;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam3(V self, V *args) {
  V v_x_24140 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_24137 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24140);
  V v_c_24141 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_24137)));
  return heff_tail(v_c_24141, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam4, 1, 2, (V[]){v_x_242, v_k_247})});
}
V g_heff_2eelab_2erules_2esumIntroNow_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_cs_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_2436;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2416 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2416);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str0), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str1)));
      V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2437, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2440}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2441, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2442 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_2443 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str2), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str3), heff_dup(v_x_242))));
      V v_t_2444 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str4))});
      V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2443, v_tsp_241, v_t_2444});
      V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2447}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2448, v_k_247});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_cs_243);
    V v_t_2474;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2454 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2454, 0ULL, 1);
        v_t_2474 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2454);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_2474)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_2475 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str5), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str6)));
      V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2475, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2478}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2479, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2480 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_2481 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str7), heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str8), heff_dup(v_x_242))));
      V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str9))});
      V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2481, v_tsp_241, v_t_2482});
      V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2485}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2486, v_k_247});
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_cs_243);
    V v_t_24111;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2491 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2491)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2491, 0ULL, 1);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2491, 0ULL, 1);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2491, 0ULL, 1);
        v_t_24111 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2491);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24111)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24112 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str10), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str11)));
      V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24112, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
      V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
      V v_t_24116 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24115}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24116, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24117 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24118 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str12), heff_strAppend(v_t_24117, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str13), heff_dup(v_x_242))));
      V v_t_24119 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str14))});
      V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24118, v_tsp_241, v_t_24119});
      V v_t_24121 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24120})});
      V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
      V v_t_24123 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24122}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24123, v_k_247});
    }
    default: return heff_nomatch(v_t_24111);
    }
  }
  case TAG_LikeSum: {
    V v_vs_24124 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_24125 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_vs_24124, 1)));
    V v_t_24131;
    switch (heff_tag_of(v_t_24125)) {
    case TAG_Nothing: {
      heff_drop_rec(v_vs_24124, 3);
      heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
      v_t_24131 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_24126 = heff_field(v_t_24125, 0);
      heff_take_n(v_t_24125, 1ULL, 1);
      V v_xs_24127 = heff_get_n(v_vs_24124, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_24126))) {
        if (heff_intLt_c(heff_dup(v_i_24126), heff_arrayLength(heff_dup(v_xs_24127)))) {
          V v_t_24130 = heff_arrayIndex(v_xs_24127, v_i_24126);
          v_t_24131 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_Just, 1, (V[]){v_t_24130});
        } else {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          heff_drop(v_i_24126);
          heff_drop(v_xs_24127);
          v_t_24131 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
        heff_drop(v_i_24126);
        heff_drop(v_xs_24127);
        v_t_24131 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_24125);
    }
    switch (heff_tag_of(v_t_24131)) {
    case TAG_Nothing: {
      heff_drop(v_tsp_241);
      heff_drop(v_cs_243);
      V v_msg_24132 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str15), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str16), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412)))));
      V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_24132, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24135}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24136, v_k_247});
    }
    case TAG_Just: {
      V v_ts_24137 = heff_field(v_t_24131, 0);
      V v_ru_24t_24131_24Just = heff_take_reuse_n(v_t_24131, 1ULL, 1);
      V v_t_24138 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_cs_243));
      if (heff_intEq_c(heff_arrayLength(heff_dup(v_ts_24137)), v_t_24138)) {
        heff_drop(v_sp_240);
        heff_drop_cell(v_ru_24t_24131_24Just, 1);
        return (g_heff_2eelab_2erules_2erecordName(heff_dup(v_e_244), v_x_2412, heff_dup(v_x_242), v_tsp_241, v_x_2412, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam3, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_24137, v_hd_246, v_x_242, v_k_247})));
      } else {
        heff_drop(v_tsp_241);
        heff_drop(v_cs_243);
        heff_drop(v_ts_24137);
        V v_msg_24149 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str17), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str18), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412)))));
        V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_24149, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_24151 = heff_tag_at_n(v_ru_24t_24131_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24150})});
        V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
        V v_t_24153 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24152}));
        return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24153, v_k_247});
      }
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_cs_243);
    V v_t_24175;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24155 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24155)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        v_t_24175 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24175 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24155);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24175 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24175)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24176 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str19), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str20)));
      V v_t_24177 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24176, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24178 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24177})});
      V v_t_24179 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24178})});
      V v_t_24180 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24179}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24180, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24181 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24182 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str21), heff_strAppend(v_t_24181, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str22), heff_dup(v_x_242))));
      V v_t_24183 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str23))});
      V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24182, v_tsp_241, v_t_24183});
      V v_t_24185 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24184})});
      V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24185})});
      V v_t_24187 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24186}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24187, v_k_247});
    }
    default: return heff_nomatch(v_t_24175);
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_cs_243);
    V v_t_24209;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24189 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24189)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24189, 0ULL, 1);
        v_t_24209 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24189, 0ULL, 1);
        v_t_24209 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24189, 0ULL, 1);
        v_t_24209 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24209 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24189);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24209 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24209)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24210 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str24), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str25)));
      V v_t_24211 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24210, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24212 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24211})});
      V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24212})});
      V v_t_24214 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24213}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24214, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24215 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24216 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str26), heff_strAppend(v_t_24215, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str27), heff_dup(v_x_242))));
      V v_t_24217 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str28))});
      V v_t_24218 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24216, v_tsp_241, v_t_24217});
      V v_t_24219 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24218})});
      V v_t_24220 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24219})});
      V v_t_24221 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24220}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24221, v_k_247});
    }
    default: return heff_nomatch(v_t_24209);
    }
  }
  case TAG_LikeString: {
    heff_drop(v_cs_243);
    V v_t_24243;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24223 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24223)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24223, 0ULL, 1);
        v_t_24243 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24223, 0ULL, 1);
        v_t_24243 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24223, 0ULL, 1);
        v_t_24243 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24243 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24223);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24243)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24244 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str29), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str30)));
      V v_t_24245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24244, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24245})});
      V v_t_24247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24246})});
      V v_t_24248 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24247}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24248, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24249 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24250 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str31), heff_strAppend(v_t_24249, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str32), heff_dup(v_x_242))));
      V v_t_24251 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str33))});
      V v_t_24252 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24250, v_tsp_241, v_t_24251});
      V v_t_24253 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24252})});
      V v_t_24254 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24253})});
      V v_t_24255 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24254}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24255, v_k_247});
    }
    default: return heff_nomatch(v_t_24243);
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_cs_243);
    V v_t_24277;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24257 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24257)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        v_t_24277 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        v_t_24277 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        v_t_24277 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24277 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24257);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24277 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24277)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24278 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str34), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str35)));
      V v_t_24279 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24278, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24280 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24279})});
      V v_t_24281 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24280})});
      V v_t_24282 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24281}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24282, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24283 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24284 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str36), heff_strAppend(v_t_24283, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str37), heff_dup(v_x_242))));
      V v_t_24285 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str38))});
      V v_t_24286 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24284, v_tsp_241, v_t_24285});
      V v_t_24287 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24286})});
      V v_t_24288 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24287})});
      V v_t_24289 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24288}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24289, v_k_247});
    }
    default: return heff_nomatch(v_t_24277);
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24312;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24292 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24292)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24292, 0ULL, 1);
        v_t_24312 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24292, 0ULL, 1);
        v_t_24312 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24292, 0ULL, 1);
        v_t_24312 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24312 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24292);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24312)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24313 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str39), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str40)));
      V v_t_24314 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24313, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24315 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24314})});
      V v_t_24316 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24315})});
      V v_t_24317 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24316}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24317, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24318 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24319 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str41), heff_strAppend(v_t_24318, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str42), heff_dup(v_x_242))));
      V v_t_24320 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str43))});
      V v_t_24321 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24319, v_tsp_241, v_t_24320});
      V v_t_24322 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24321})});
      V v_t_24323 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24322})});
      V v_t_24324 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24323}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24324, v_k_247});
    }
    default: return heff_nomatch(v_t_24312);
    }
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24347;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24327 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24327)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24327, 0ULL, 1);
        v_t_24347 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24327, 0ULL, 1);
        v_t_24347 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24327, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24347 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24327);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24347 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24347)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24348 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str44), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str45)));
      V v_t_24349 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24348, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24350 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24349})});
      V v_t_24351 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24350})});
      V v_t_24352 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24351}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24352, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24353 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24354 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str46), heff_strAppend(v_t_24353, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str47), heff_dup(v_x_242))));
      V v_t_24355 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str48))});
      V v_t_24356 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24354, v_tsp_241, v_t_24355});
      V v_t_24357 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24356})});
      V v_t_24358 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24357})});
      V v_t_24359 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24358}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24359, v_k_247});
    }
    default: return heff_nomatch(v_t_24347);
    }
  }
  case TAG_NoRules: {
    heff_drop(v_cs_243);
    V v_t_24381;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24361 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24361)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24361, 0ULL, 1);
        v_t_24381 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24361, 0ULL, 1);
        v_t_24381 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24361, 0ULL, 1);
        v_t_24381 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24381 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24361);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24381 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24381)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24382 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str49), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str50)));
      V v_t_24383 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24382, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24384 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24383})});
      V v_t_24385 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24384})});
      V v_t_24386 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24385}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24386, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24387 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24388 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str51), heff_strAppend(v_t_24387, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str52), heff_dup(v_x_242))));
      V v_t_24389 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str53))});
      V v_t_24390 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24388, v_tsp_241, v_t_24389});
      V v_t_24391 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24390})});
      V v_t_24392 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24391})});
      V v_t_24393 = heff_tr(heff_apply(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24392}));
      return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_24393, v_k_247});
    }
    default: return heff_nomatch(v_t_24381);
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam2, 1, 7, (V[]){v_x_242, v_sp_240, v_hd_246, v_k_247, v_e_244, v_tsp_241, v_cs_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2esumIntro_str0, 3, (116, 97, 103));
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntro_entry, 4, 0};

V g_heff_2eelab_2erules_2esumIntro(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam0, 4, 4, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243})});
}
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntro(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2414 = heff_dup(heff_field(v_x_2412, 0));
    switch (heff_tag_of(v_it1_2414)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2414);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    V v_t_2435 = (g_heff_2eelab_2erules_2esumIntroNow(heff_dup(v_sp_240), v_tsp_241, v_x_242, v_cs_243));
    return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumIntro_str0); V a_3 = v_t_2435; V a_4 = heff_dup(v_x_2412); V a_5 = v_x_2412; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2435); r_; });
  }
  case TAG_False: {
    V v_t_2436 = (g_heff_2eelab_2erules_2esumIntroNow(v_sp_240, v_tsp_241, v_x_242, v_cs_243));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_MkChk: {
      V v_f_2437 = heff_field(v_t_2436, 0);
      heff_take_n(v_t_2436, 1ULL, 1);
      return heff_tail(v_f_2437, 4, (V[]){v_e_244, v_x_2412, v_hd_246, v_k_247});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  default: return heff_nomatch(v_t_2434);
  }
}
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam2, 1, 7, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243, v_e_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam1, 2, 0};
V g_heff_2eelab_2erules_2erecordTagIn_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam2, 2, 0};
Clo g_heff_2eelab_2erules_2erecordTagIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_entry, 5, 0};

V g_heff_2eelab_2erules_2erecordTagIn(V v_e_240, V v_a_241, V v_vs_242, V v_x_243, V v_tsp_244) {
top: ;
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_vs_242, 1)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop_rec(v_vs_242, 3);
    heff_drop(v_x_243);
    heff_drop(v_tsp_244);
    return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam0_clo);
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_xs_249 = heff_get_n(v_vs_242, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_xs_249)))) {
        V v_x_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        heff_drop(v_x_2412);
        return heff_tail(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_240, heff_dup(v_a_241), v_x_243, v_tsp_244, v_a_241});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_a_241);
        heff_drop(v_x_243);
        heff_drop(v_tsp_244);
        heff_drop(v_i_248);
        heff_drop(v_xs_249);
        return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam1_clo);
      }
    } else {
      heff_drop(v_e_240);
      heff_drop(v_a_241);
      heff_drop(v_x_243);
      heff_drop(v_tsp_244);
      heff_drop(v_i_248);
      heff_drop(v_xs_249);
      return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam2_clo);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordTagIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    return ((V)&g_heff_2eelab_2erules_2erecordTags_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      V v_c_2410 = heff_tr(g_heff_2eelab_2erules_2erecordTagIn(heff_dup(v_e_240), heff_dup(v_a_241), heff_dup(v_vs_242), heff_dup(v_x_248), heff_dup(v_tsp_249)));
      return heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2erecordTags(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2erecordTags(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  return heff_tail(v_t_2414, 2, (V[]){v_hd_2411, v_k_2412});
}
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam2, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2ecaseArm_str0, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2ecaseArm_str1, 25, (110, 111, 32, 99, 97, 115, 101, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 102, 111, 114, 32, 116, 97, 103, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ecaseArm_str2, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2ecaseArm_str3, 1, (95));
HEFF_STRA(g_heff_2eelab_2erules_2ecaseArm_str4, 43, (119, 114, 111, 110, 103, 32, 110, 117, 109, 98, 101, 114, 32, 111, 102, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 102, 111, 114, 32, 116, 97, 103, 32));
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseArm_entry, 7, 0};

V g_heff_2eelab_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_x_244, V v_ts_245, V v_casesChk_246) {
top: ;
  V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_244), heff_rfield(v_casesChk_246, 1)));
  V v_it_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_it_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    V v_xs_249 = heff_dup(heff_rfield(v_casesChk_246, 2));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_xs_249)))) {
        V v_t_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        v_it_2413 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_i_248);
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        heff_drop(v_xs_249);
        v_it_2413 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_i_248);
      heff_drop_cell(v_ru_24t_247_24Just, 1);
      heff_drop(v_xs_249);
      v_it_2413 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_it_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = (g_map_2elookup_24s1546226666x2146984184(((V)&g_heff_2eelab_2erules_2ecaseArm_str0), heff_rfield(v_casesChk_246, 1)));
    V v_it_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      heff_drop_rec(v_casesChk_246, 3);
      v_it_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_2415 = heff_field(v_t_2414, 0);
      V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
      V v_xs_2416 = heff_get_n(v_casesChk_246, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2415))) {
        if (heff_intLt_c(heff_dup(v_i_2415), heff_arrayLength(heff_dup(v_xs_2416)))) {
          V v_t_2419 = heff_arrayIndex(v_xs_2416, v_i_2415);
          v_it_2420 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_i_2415);
          heff_drop_cell(v_ru_24t_2414_24Just, 1);
          heff_drop(v_xs_2416);
          v_it_2420 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_2415);
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        heff_drop(v_xs_2416);
        v_it_2420 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    switch (heff_tag_of(v_it_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_241, 6);
      heff_drop(v_b_242);
      heff_drop(v_ts_245);
      return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam0, 2, 2, (V[]){v_x_244, v_sp_240});
    }
    case TAG_Just: {
      V v_it1_2427 = heff_field(v_it_2420, 0);
      heff_take_n(v_it_2420, 1ULL, 1);
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_it1_2427)) {
      case TAG_MkPair: {
        V v_bodyChk_2429 = heff_field(v_it1_2427, 1);
        heff_take_n(v_it1_2427, 2ULL, 2);
        V v_t_2430 = (g_list_2emap_24s1445534224x744280941(((V)&g_heff_2eelab_2erules_2ecaseArm_str2), heff_dup(v_ts_245)));
        V v_t_2431 = (g_list_2emap_24s1990719097x1419059608(heff_dup(v_ts_245)));
        V v_sc_2432 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V a_2 = heff_take_field(v_e_241, 0); V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(a_0, a_1, a_2)); heff_drop(v_t_2430); heff_drop(v_t_2431); r_; });
        V v_e_2433 = ({ V rv_0 = v_sc_2432; V rr_ = heff_rec_reuse_n(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_c_2435;
        switch (heff_tag_of(v_bodyChk_2429)) {
        case TAG_MkChk: {
          V v_f_2434 = heff_field(v_bodyChk_2429, 0);
          heff_take_n(v_bodyChk_2429, 1ULL, 1);
          v_c_2435 = heff_tr(heff_apply(v_f_2434, 2, (V[]){v_e_2433, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2429);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam1, 2, 3, (V[]){v_c_2435, v_ts_245, v_x_244});
      }
      default: return heff_nomatch(v_it1_2427);
      }
    }
    default: return heff_nomatch(v_it_2420);
    }
  }
  case TAG_Just: {
    V v_it1_2442 = heff_field(v_it_2413, 0);
    heff_take_n(v_it_2413, 1ULL, 1);
    heff_drop_rec(v_casesChk_246, 3);
    switch (heff_tag_of(v_it1_2442)) {
    case TAG_MkPair: {
      V v_xs_2443 = heff_field(v_it1_2442, 0);
      V v_bodyChk_2444 = heff_field(v_it1_2442, 1);
      heff_take_n(v_it1_2442, 3ULL, 2);
      V v_t_2445 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ts_245));
      if (heff_intEq_c(heff_arrayLength(heff_dup(v_xs_2443)), v_t_2445)) {
        heff_drop(v_sp_240);
        V v_t_2447 = (g_list_2emap_24s1990719097x1419059608(v_ts_245));
        V v_sc_2448 = ({ V b_0 = heff_arrayToList(heff_dup(v_xs_2443)); V a_1 = v_t_2447; V a_2 = heff_take_field(v_e_241, 0); V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2447); r_; });
        V v_e_2449 = ({ V rv_0 = v_sc_2448; V rr_ = heff_rec_reuse_n(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_c_2451;
        switch (heff_tag_of(v_bodyChk_2444)) {
        case TAG_MkChk: {
          V v_f_2450 = heff_field(v_bodyChk_2444, 0);
          heff_take_n(v_bodyChk_2444, 1ULL, 1);
          v_c_2451 = heff_tr(heff_apply(v_f_2450, 2, (V[]){v_e_2449, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2444);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam3, 2, 3, (V[]){v_c_2451, v_xs_2443, v_x_244});
      } else {
        heff_drop_rec(v_e_241, 6);
        heff_drop(v_b_242);
        heff_drop(v_ts_245);
        heff_drop(v_xs_2443);
        heff_drop(v_bodyChk_2444);
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam5, 2, 2, (V[]){v_x_244, v_sp_240});
      }
    }
    default: return heff_nomatch(v_it1_2442);
    }
  }
  default: return heff_nomatch(v_it_2413);
  }
}
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ecaseArm(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str1), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_take_field(v_hd_2421, 2), 1, (V[]){v_t_2425}));
  V f_ = heff_get_n(v_hd_2421, 1, 3);
  args[0] = v_t_2426;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_ts_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = (g_list_2emap_24s1445534224x744280941(((V)&g_heff_2eelab_2erules_2ecaseArm_str3), v_ts_245));
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2439), heff_get_n(v_x_2438, 0, 2)});
  V v_x_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2440});
  V f_ = v_k_2437;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_ts_245 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam2, 1, 3, (V[]){v_ts_245, v_x_244, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_xs_2443 = heff_env(self)[0];
  V v_k_2453 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_2443, heff_get_n(v_x_2454, 0, 2)});
  V f_ = v_k_2453;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_xs_2443 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam4, 1, 3, (V[]){v_xs_2443, v_k_2453, v_x_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str4), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesAt_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_lam4, 1, 0};
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_entry, 8, 0};

V g_heff_2eelab_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247) {
top: ;
  V v_c_248 = (g_heff_2eelab_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_245), v_tags_246));
  return heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam0, 2, 8, (V[]){v_c_248, v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_scrut_243});
}
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[6]); return r;
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_casesChk_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ts_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_x_2416; V a_5 = heff_arrayToList(v_ts_2417); V a_6 = v_casesChk_247; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_244); r_; });
  }
  default: return heff_nomatch(v_p_2415);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_x_2419)));
  V v_t_2421 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2419));
  V v_t_2422 = (g_list_2emap_24s366344330x1145113647(v_x_2419));
  V v_cases_2423 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2420), v_t_2421, heff_arrayFromList(v_t_2422)});
  V v_t_2424 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_get_n(v_scrut_243, 0, 2), v_cases_2423});
  V v_x_2426 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2424, ((V)&g_heff_2eelab_2erules_2ecasesAt_lam4_clo)});
  V f_ = v_k_2410;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_vs_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_b_242 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_casesChk_247 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_arrayToList(heff_take_field(v_vs_245, 0));
  V v_t_2413 = heff_arrayToList(heff_get_n(v_vs_245, 2, 3));
  V v_t_2414 = (g_heff_2eutil_2edict_2ezipKV(v_t_2412, v_t_2413));
  V v_c_2418 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam2, 1, 5, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247}), v_t_2414));
  return heff_tail(v_c_2418, 2, (V[]){v_hd_249, heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam3, 1, 2, (V[]){v_scrut_243, v_k_2410})});
}
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_vs_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_b_242 = heff_env(self)[4];
  V v_a_244 = heff_env(self)[5];
  V v_casesChk_247 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam1, 1, 9, (V[]){v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_hd_249, v_scrut_243, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str0, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str1, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str2, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str3, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str4, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str5, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str6, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str7, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str8, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2ematchLater_str9, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ematchLater_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ematchLater_entry, 5, 0};

V g_heff_2eelab_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam0, 4, 5, (V[]){v_a_242, v_sp_240, v_scrut_241, heff_dup(v_tags_243), v_casesChk_244})});
}
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ematchLater(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args) {
  V v_u_2418 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam5, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2419 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam4, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str0), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2420, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2424, v_k_248});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args) {
  V v_u_2431 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam8, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam7, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2433 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str1), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2433, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2436}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2437, v_k_248});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args) {
  V v_u_2443 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args) {
  V v_u_2442 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam11, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2441)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2444 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam10, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2445 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str2), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2445, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2449, v_k_248});
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args) {
  V v_u_2454 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args) {
  V v_u_2453 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam14, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args) {
  V v_x_2452 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2452)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2455 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam13, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str3), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2456, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2459}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2460, v_k_248});
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args) {
  V v_u_2463 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2463);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args) {
  V v_u_2462 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam17, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args) {
  V v_x_2461 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2461)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2464 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam16, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2465 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str4), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2465, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2468}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2469, v_k_248});
  }
  default: return heff_nomatch(v_x_2461);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args) {
  V v_u_2472 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2472);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args) {
  V v_u_2471 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2471);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam20, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args) {
  V v_x_2470 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2470)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2473 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam19, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2473;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2474 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str5), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2474, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2477}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2478, v_k_248});
  }
  default: return heff_nomatch(v_x_2470);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args) {
  V v_u_2481 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args) {
  V v_u_2480 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2480);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam23, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args) {
  V v_x_2479 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2479)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2482 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam22, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2482;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str6), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2483, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2486}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2487, v_k_248});
  }
  default: return heff_nomatch(v_x_2479);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args) {
  V v_u_2491 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args) {
  V v_u_2490 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2490);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam26, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args) {
  V v_x_2489 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2489)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2492 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam25, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2492;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2493 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str7), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2493, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2496}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2497, v_k_248});
  }
  default: return heff_nomatch(v_x_2489);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args) {
  V v_u_24101 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24101);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args) {
  V v_u_24100 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24100);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam29, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args) {
  V v_x_2499 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2499)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24102 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam28, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24102;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_24103 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str8), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24103, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
    V v_t_24107 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24106}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24107, v_k_248});
  }
  default: return heff_nomatch(v_x_2499);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args) {
  V v_u_24110 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24110);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args) {
  V v_u_24109 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24109);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam32, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args) {
  V v_x_24108 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_24108)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24111 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam31, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24111;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_24112 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str9), (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24112, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24115}));
    return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_24116, v_k_248});
  }
  default: return heff_nomatch(v_x_24108);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_b2_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_e2_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_scrut_241 = heff_env(self)[5];
  V v_tags_243 = heff_env(self)[6];
  V v_casesChk_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam3, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam6, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam9, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeSum: {
    V v_vs_2450 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_t_2451 = ({ V a_0 = v_sp_240; V a_1 = v_e2_245; V a_2 = v_b2_246; V a_3 = v_scrut_241; V a_4 = v_x_2413; V a_5 = v_vs_2450; V a_6 = v_tags_243; V a_7 = v_casesChk_244; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_tags_243); r_; });
    return heff_tail(v_t_2451, 2, (V[]){v_hd_247, v_k_248});
  }
  case TAG_LikeInt: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam12, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam15, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeString: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam18, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRune: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam21, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam24, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam27, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_NoRules: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam30, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args) {
  V v_e2_245 = args[0];
  V v_b2_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_a_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_scrut_241 = heff_env(self)[2];
  V v_tags_243 = heff_env(self)[3];
  V v_casesChk_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam1, 1, 1, (V[]){v_a_242})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam2, 1, 8, (V[]){v_hd_247, v_b2_246, v_k_248, v_e2_245, v_sp_240, v_scrut_241, v_tags_243, v_casesChk_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str0, 46, (99, 97, 110, 110, 111, 116, 32, 101, 108, 105, 109, 105, 110, 97, 116, 101, 32, 102, 114, 111, 109, 32, 115, 117, 109, 32, 116, 121, 112, 101, 32, 105, 110, 116, 111, 32, 108, 97, 114, 103, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str1, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str2, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str3, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str4, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str5, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str6, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str7, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str8, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str9, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str10, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str11, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str12, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str13, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str14, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str15, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str16, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str17, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str18, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str19, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2eelab_2erules_2esumElim_str20, 34, (99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32));
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumElim_entry, 4, 0};

V g_heff_2eelab_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam0, 2, 4, (V[]){v_sp_240, heff_dup(v_scrutSyn_241), heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2esumElim(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2413}));
  V f_ = heff_get_n(v_hd_249, 1, 3);
  args[0] = v_t_2414;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args) {
  V v_c_2422 = args[0];
  V v_a0_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2422, 3, 8); V a_1 = v_a0_2421; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args) {
  V v_u_2431 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam8, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2454;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2434 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_2434)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2434);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      V v_t_2455 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str1); V a_3 = v_t_2455; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2455); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str2), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2456, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2459}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_2460, v_k_2418});
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args) {
  V v_u_2467 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args) {
  V v_u_2466 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam11, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args) {
  V v_x_2465 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2465)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_2468 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam10, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_2468;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2490;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2470 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_2470)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2470, 0ULL, 1);
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2470, 0ULL, 1);
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2470, 0ULL, 1);
        v_t_2490 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2470);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_2490)) {
    case TAG_True: {
      V v_t_2491 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str3); V a_3 = v_t_2491; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2491); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_2492 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str4), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2492, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2495}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_2496, v_k_2418});
    }
    default: return heff_nomatch(v_t_2490);
    }
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args) {
  V v_u_24102 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24102);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args) {
  V v_u_24101 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24101);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam14, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args) {
  V v_x_24100 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24100)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24103 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam13, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24103;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24125;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24105 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24105)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24105);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24125)) {
    case TAG_True: {
      V v_t_24126 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str5); V a_3 = v_t_24126; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24126); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24127 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str6), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24127, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
      V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24130}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24131, v_k_2418});
    }
    default: return heff_nomatch(v_t_24125);
    }
  }
  default: return heff_nomatch(v_x_24100);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args) {
  V v_u_24136 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24136);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args) {
  V v_u_24135 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24135);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam17, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args) {
  V v_x_24134 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24134)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24137 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam16, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24137;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24159;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24139 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24139)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24139, 0ULL, 1);
        v_t_24159 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24139, 0ULL, 1);
        v_t_24159 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24139, 0ULL, 1);
        v_t_24159 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24159 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24139);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24159 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24159)) {
    case TAG_True: {
      V v_t_24160 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str7); V a_3 = v_t_24160; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24160); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24161 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str8), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24162 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24161, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24162})});
      V v_t_24164 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24163})});
      V v_t_24165 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24164}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24165, v_k_2418});
    }
    default: return heff_nomatch(v_t_24159);
    }
  }
  default: return heff_nomatch(v_x_24134);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args) {
  V v_u_24168 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24168);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args) {
  V v_u_24167 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24167);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam20, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args) {
  V v_x_24166 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24166)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24169 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam19, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24169;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24191;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24171 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24171)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24171);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24191)) {
    case TAG_True: {
      V v_t_24192 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str9); V a_3 = v_t_24192; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24192); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24193 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str10), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24193, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24195 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24194})});
      V v_t_24196 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24195})});
      V v_t_24197 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24196}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24197, v_k_2418});
    }
    default: return heff_nomatch(v_t_24191);
    }
  }
  default: return heff_nomatch(v_x_24166);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args) {
  V v_u_24200 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24200);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args) {
  V v_u_24199 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24199);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam23, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args) {
  V v_x_24198 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24198)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24201 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam22, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24201;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24223;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24203 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24203)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24203, 0ULL, 1);
        v_t_24223 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24203, 0ULL, 1);
        v_t_24223 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24203, 0ULL, 1);
        v_t_24223 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24223 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24203);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24223 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24223)) {
    case TAG_True: {
      V v_t_24224 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str11); V a_3 = v_t_24224; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24224); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24225 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str12), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24226 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24225, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24227 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24226})});
      V v_t_24228 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24227})});
      V v_t_24229 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24228}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24229, v_k_2418});
    }
    default: return heff_nomatch(v_t_24223);
    }
  }
  default: return heff_nomatch(v_x_24198);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args) {
  V v_u_24232 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24232);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args) {
  V v_u_24231 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24231);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam26, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args) {
  V v_x_24230 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24230)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24233 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam25, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24233;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24255;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24235 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24235)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24235);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24255)) {
    case TAG_True: {
      V v_t_24256 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str13); V a_3 = v_t_24256; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24256); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24257 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str14), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24258 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24257, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24259 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24258})});
      V v_t_24260 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24259})});
      V v_t_24261 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24260}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24261, v_k_2418});
    }
    default: return heff_nomatch(v_t_24255);
    }
  }
  default: return heff_nomatch(v_x_24230);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args) {
  V v_u_24265 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24265);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args) {
  V v_u_24264 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24264);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam29, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args) {
  V v_x_24263 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24263)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24266 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam28, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24266;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24288;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24268 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24268)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24268, 0ULL, 1);
        v_t_24288 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24268, 0ULL, 1);
        v_t_24288 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24268, 0ULL, 1);
        v_t_24288 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24288 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24268);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24288 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24288)) {
    case TAG_True: {
      V v_t_24289 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str15); V a_3 = v_t_24289; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24289); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24290 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str16), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24291 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24290, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24292 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24291})});
      V v_t_24293 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24292})});
      V v_t_24294 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24293}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24294, v_k_2418});
    }
    default: return heff_nomatch(v_t_24288);
    }
  }
  default: return heff_nomatch(v_x_24263);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args) {
  V v_u_24298 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24298);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args) {
  V v_u_24297 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24297);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam32, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args) {
  V v_x_24296 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24296)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24299 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam31, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24299;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24321;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24301 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24301)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24301, 0ULL, 1);
        v_t_24321 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24301, 0ULL, 1);
        v_t_24321 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24301, 0ULL, 1);
        v_t_24321 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24321 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24301);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24321 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24321)) {
    case TAG_True: {
      V v_t_24322 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str17); V a_3 = v_t_24322; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24322); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24323 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str18), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24324 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24323, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24325 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24324})});
      V v_t_24326 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24325})});
      V v_t_24327 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24326}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24327, v_k_2418});
    }
    default: return heff_nomatch(v_t_24321);
    }
  }
  default: return heff_nomatch(v_x_24296);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args) {
  V v_u_24330 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24330);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args) {
  V v_u_24329 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24329);
  return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam35, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args) {
  V v_x_24328 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24328)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_24331 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam34, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24331;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24353;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24333 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24333)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24333, 0ULL, 1);
        v_t_24353 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24333, 0ULL, 1);
        v_t_24353 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24333, 0ULL, 1);
        v_t_24353 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24353 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24333);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24353)) {
    case TAG_True: {
      V v_t_24354 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str19); V a_3 = v_t_24354; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24354); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24355 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str20), (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24356 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24355, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24357 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24356})});
      V v_t_24358 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24357})});
      V v_t_24359 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_24358}));
      return heff_tail(heff_get_n(v_hd_2417, 1, 3), 2, (V[]){v_t_24359, v_k_2418});
    }
    default: return heff_nomatch(v_t_24353);
    }
  }
  default: return heff_nomatch(v_x_24328);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2427 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2426)));
  switch (heff_tag_of(v_t_2427)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2427, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam6, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2427, 0ULL, 4);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam9, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2427, 0ULL, 3);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam12, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeSum: {
    V v_vs_24132 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    V v_t_24133 = ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2420; V a_4 = v_x_2426; V a_5 = v_vs_24132; V a_6 = v_tags_242; V a_7 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_tags_242); r_; });
    return heff_tail(v_t_24133, 2, (V[]){v_hd_2417, v_k_2418});
  }
  case TAG_LikeInt: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam15, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeFloat: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam18, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeString: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam21, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeRune: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam24, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2427, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam27, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2427, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam30, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_NoRules: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam33, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  default: return heff_nomatch(v_t_2427);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_scrut_2420 = heff_field(v_x_2419, 0);
    V v_a0_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam4, 1, 1, (V[]){v_a0_2421})})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2424}));
    return heff_tail(heff_dup(heff_rfield(v_hd_2417, 1)), 2, (V[]){v_t_2425, heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam5, 1, 8, (V[]){v_hd_2417, v_b_245, v_k_2418, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244})});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_tags_242 = heff_env(self)[3];
  V v_casesChk_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam3, 1, 7, (V[]){v_hd_2417, v_b_245, v_k_2418, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_scrutSyn_241 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = (g_heff_2eelab_2evalue_2elevelOf(v_b_245));
  V v_x1_247;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    v_x1_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam1, 2, 1, (V[]){v_sp_240});
  }
  case TAG_False: {
    V v_c_2416;
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_2415 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_2416 = heff_tr(heff_apply(v_f_2415, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam2, 2, 6, (V[]){v_c_2416, v_b_245, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseLet_entry, 3, 0};

V g_heff_2eelab_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam0, 2, 3, (V[]){heff_dup(v_scrutSyn_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2ecaseLet(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a0_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_a0_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args) {
  V v_v_2417 = args[0];
  V v_scope_27_2418 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2417);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2420 = ({ V rv_0 = v_scope_27_2418; V rr_ = heff_rec_reuse_n(v_e_243, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2419;
    args[0] = v_t_2420;
    args[1] = v_b_244;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2416});
}
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args) {
  V v_u_2434 = args[0];
  V v_b_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_244});
}
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_scrut_2410 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_take_field(v_e_243, 2);
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    v_t_2426 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2423, 0ULL, 2);
    v_t_2426 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2429 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2428, heff_dup(v_x_2416)));
  V v_dom_2431 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2429, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam7, 1, 1, (V[]){v_x_2416})});
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2433 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2432, MK_INT(1LL)), heff_dup(v_b_244)));
  V v_cod_2435 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam8, 1, 1, (V[]){v_b_244})})});
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2437 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2436, v_dom_2431, v_cod_2435));
  V v_t_2438 = (g_heff_2eelab_2ememoed_2elam(v_t_2426, heff_get_n(v_e_243, 1, 6), v_t_2427, v_t_2437, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, v_x_2422})));
  V v_x_2439 = (g_heff_2eelab_2ememoed_2eapp(v_t_2438, v_scrut_2410));
  V f_ = v_k_248;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_b_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_scrut_2410 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2421 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), heff_dup(v_x_2416), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam5, 2, 3, (V[]){v_body_242, heff_dup(v_e_243), heff_dup(v_b_244)})));
  return heff_tail(v_c_2421, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam6, 1, 6, (V[]){v_e_243, v_x_2416, v_b_244, v_x_240, v_scrut_2410, v_k_248})});
}
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_scrut_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam3, 1, 1, (V[]){v_a0_2411})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2414}));
    return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam4, 1, 7, (V[]){v_x_240, v_e_243, v_body_242, v_b_244, v_hd_247, v_scrut_2410, v_k_248})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam2, 1, 6, (V[]){v_hd_247, v_x_240, v_e_243, v_body_242, v_b_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_b_244 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_scrutSyn_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_scrutSyn_241, 0);
    heff_take_n(v_scrutSyn_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_scrutSyn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam1, 2, 5, (V[]){v_c_246, v_x_240, v_e_243, v_body_242, v_b_244});
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efixEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efixEnv_entry, 3, 0};

V g_heff_2eelab_2erules_2efixEnv(V v_e_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
  V v_c_246 = heff_take_field(v_e_240, 0);
  V v_t_247 = heff_intAdd(heff_take_field(v_c_246, 0), MK_INT(1LL));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, heff_take_field(v_c_246, 1)});
  V v_t_2410 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_246, 2), heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_2411 = heff_tag_n(TAG_CBind, 3, (V[]){heff_get_n(v_c_246, 3, 4), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_a_242});
  return ({ V rv_0 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){v_t_247, v_t_248, v_t_2410, v_t_2411}); V rv_2 = NTAG(TAG_ForNominative); V rv_3 = MK_INT(0LL); V rr_ = heff_rec_reuse_n(v_e_240, 50ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efixEnv(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_a_242;
}
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_245;
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2elocalDef_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_lam7, 1, 0};
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elocalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_entry, 4, 0};

V g_heff_2eelab_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam0, 2, 4, (V[]){heff_dup(v_typ_241), v_x_240, heff_dup(v_body_242), heff_dup(v_rest_243)})});
}
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2elocalDef(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_scope_27_2432 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2431);
  switch (heff_tag_of(v_rest_243)) {
  case TAG_MkChk: {
    V v_f_2433 = heff_field(v_rest_243, 0);
    heff_take_n(v_rest_243, 1ULL, 1);
    V v_t_2434 = ({ V rv_0 = v_scope_27_2432; V rr_ = heff_rec_reuse_n(v_e_244, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2433;
    args[0] = v_t_2434;
    args[1] = v_b_245;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_rest_243);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args) {
  V v_u_2444 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_245});
}
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args) {
  V v_u_2451 = args[0];
  heff_drop(v_u_2451);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_take_field(v_e_244, 2);
  V v_t_2440;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_ForNominative: {
    v_t_2440 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2440 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2442, MK_INT(1LL)), heff_dup(v_b_245)));
  V v_cod_2445 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2443, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam6, 1, 1, (V[]){v_b_245})})});
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2447 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_244, 1)), v_t_2446, heff_dup(v_x_2411), v_cod_2445));
  V v_t_2448 = (g_heff_2eelab_2ememoed_2elam(v_t_2440, heff_get_n(v_e_244, 1, 6), v_t_2441, v_t_2447, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_x_2436})));
  V v_t_2449 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_get_n(v_x_2425, 0, 2)});
  V v_t_2450 = heff_tag_n(TAG_SFix, 2, (V[]){heff_get_n(v_x_2411, 0, 2), v_t_2449});
  V v_x_2452 = (g_heff_2eelab_2ememoed_2eapp(v_t_2448, heff_rec_n(2, shape_stx__val, (V[]){v_t_2450, ((V)&g_heff_2eelab_2erules_2elocalDef_lam7_clo)})));
  V f_ = v_k_2410;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2426 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_c_2435 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2430, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam4, 2, 3, (V[]){v_rest_243, heff_dup(v_e_244), heff_dup(v_b_245)})));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_249, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam5, 1, 6, (V[]){v_e_244, v_b_245, v_x_240, v_x_2411, v_x_2425, v_k_2410})});
}
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_e_2417 = (g_heff_2eelab_2erules_2efixEnv(heff_dup(v_e_244), heff_dup(v_x_240), v_t_2416));
  V v_x1_2418 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_a_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2424;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2423 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2424 = heff_tr(heff_apply(v_f_2423, 2, (V[]){v_e_2417, v_a_2422}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam3, 1, 7, (V[]){v_x_2411, v_x_240, v_e_244, v_rest_243, v_b_245, v_hd_249, v_k_2410})});
}
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam2, 1, 7, (V[]){v_e_244, v_x_240, v_body_242, v_hd_249, v_rest_243, v_b_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_typ_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_248;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_246 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    V v_t_247 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_244, 0)), heff_dup(heff_rfield(v_e_244, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_244, 3)), heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_248 = heff_tr(heff_apply(v_f_246, 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_x_240, v_body_242, v_rest_243, v_b_245});
}
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str0, 5, (116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str1, 27, (32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 102, 111, 114, 32, 105, 116, 115, 32, 117, 110, 105, 118, 101, 114, 115, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str2, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str3, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str4, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str5, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str6, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str7, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str8, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str9, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str10, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str11, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str12, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str13, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str14, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str15, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str16, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str17, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str18, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str19, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str20, 18, (99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseIntro_str21, 22, (32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32));
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseIntro(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam0, 4, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2euniverseIntro(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    V v_u_2415 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24LikeU = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    heff_drop(v_x_2410);
    V v_x1_2416 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_2413, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x1_2420;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nom: {
      V v_t_2417 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2417); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2418 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2418); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2419 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    V v_x2_2421;
    switch (heff_tag_of(v_u_2415)) {
    case TAG_SmallU: {
      v_x2_2421 = NTAG(TAG_Small);
      break;
    }
    case TAG_LargeU: {
      v_x2_2421 = NTAG(TAG_Large);
      break;
    }
    default: heff_nomatch(v_u_2415);
    }
    V v_t_2422;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Small: {
      heff_drop(v_x2_2421);
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Small: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Large: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      case TAG_TopL: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Small: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Large: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_TopL: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop(v_sp_240);
      heff_drop_rec(v_hd_244, 3);
      heff_drop_cell(v_ru_24t_2414_24LikeU, 1);
      V v_t_2423 = (g_heff_2eelab_2ememoed_2ecode(v_x_2413));
      V f_ = v_k_245;
      args[0] = v_t_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      V v_t_2424 = (g_heff_2eelab_2erules_2etyStrM(v_e_242, v_x_2413));
      V v_msg_2425 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str0), heff_strAppend(v_t_2424, ((V)&g_heff_2eelab_2erules_2euniverseIntro_str1)));
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_2425, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_at_n(v_ru_24t_2414_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2428}));
      return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2429, v_k_245});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    V v_t_2434 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2435 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str2), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str3), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2435, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2438}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2439, v_k_245});
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    V v_t_2443 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2444 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str4), heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str5), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2444, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2447}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2448, v_k_245});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2414_24LikeSum = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    V v_t_2450 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2451 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str6), heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str7), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2451, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2453 = heff_tag_at_n(v_ru_24t_2414_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2454}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2455, v_k_245});
  }
  case TAG_LikeInt: {
    V v_t_2456 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2457 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str8), heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str9), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2457, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2460}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2461, v_k_245});
  }
  case TAG_LikeFloat: {
    V v_t_2462 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str10), heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str11), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2463, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2467, v_k_245});
  }
  case TAG_LikeString: {
    V v_t_2468 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2469 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str12), heff_strAppend(v_t_2468, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str13), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2469, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2472}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2473, v_k_245});
  }
  case TAG_LikeRune: {
    V v_t_2474 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2475 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str14), heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str15), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2475, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2478}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2479, v_k_245});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2414_24LikeArray = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    V v_t_2481 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2482 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str16), heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str17), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2482, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2484 = heff_tag_at_n(v_ru_24t_2414_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2485}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2486, v_k_245});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2414_24LikeFixed = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    V v_t_2488 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2489 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str18), heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str19), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2489, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag_at_n(v_ru_24t_2414_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2492}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2493, v_k_245});
  }
  case TAG_NoRules: {
    V v_t_2494 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str20), heff_strAppend(v_t_2494, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseIntro_str21), (g_heff_2eelab_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2495, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tr(heff_apply(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2498}));
    return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2499, v_k_245});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_2411 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_2412 = heff_tr(heff_apply(v_f_2411, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam3, 1, 5, (V[]){v_x_2410, v_k_245, v_e_242, v_sp_240, v_hd_244})});
}
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam2, 1, 5, (V[]){v_typ_241, v_e_242, v_hd_244, v_k_245, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str0, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str1, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str2, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str3, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str4, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str5, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str6, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str7, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str8, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2euniverseElimSyn_str9, 45, (99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2euniverseElimSyn(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_m_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      heff_take_n(v_a_249, 0ULL, 1);
      heff_drop(v_sp_240);
      heff_drop_rec(v_hd_245, 3);
      V v_t_2411 = (g_heff_2eelab_2ememoed_2edecode(v_m_248));
      V f_ = v_k_246;
      args[0] = v_t_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_VDecode: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2419}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2420, v_k_246});
    }
    case TAG_VFunction: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2428}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2429, v_k_246});
    }
    case TAG_VRecord: {
      heff_take_n(v_a_249, 0ULL, 4);
      heff_drop(v_m_248);
      V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2436}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2437, v_k_246});
    }
    case TAG_VSum: {
      V v_ru_24a_249_24VSum = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2440 = heff_tag_at_n(v_ru_24a_249_24VSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2441}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2442, v_k_246});
    }
    case TAG_VPrimInt: {
      heff_drop(v_m_248);
      V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2445}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2446, v_k_246});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_m_248);
      V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2449}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2450, v_k_246});
    }
    case TAG_VPrimString: {
      heff_drop(v_m_248);
      V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2453}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2454, v_k_246});
    }
    case TAG_VPrimRune: {
      heff_drop(v_m_248);
      V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2457}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2458, v_k_246});
    }
    case TAG_VPrimArray: {
      V v_ru_24a_249_24VPrimArray = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str8), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tag_at_n(v_ru_24a_249_24VPrimArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2462}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2463, v_k_246});
    }
    case TAG_VFixed: {
      V v_ru_24a_249_24VFixed = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str9), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2466 = heff_tag_at_n(v_ru_24a_249_24VFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2467}));
      return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2468, v_k_246});
    }
    default: return heff_nomatch(v_a_249);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
HEFF_STRA(g_heff_2eelab_2erules_2easSmall_str0, 19, (101, 120, 112, 101, 99, 116, 101, 100, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101));
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2easSmall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2easSmall_entry, 2, 0};

V g_heff_2eelab_2erules_2easSmall(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkSmallTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam0, 1, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2easSmall(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_apply(heff_dup(heff_rfield(v_x_247, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_t_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_249; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2410 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Small: {
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_245, 3);
    V f_ = v_k_246;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop_rec(v_x_247, 2);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2easSmall_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2417, v_k_246});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
Clo g_heff_2eelab_2erules_2eindexOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eindexOfName_entry, 3, 0};

V g_heff_2eelab_2erules_2eindexOfName(V v_x1_240, V v_x_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(v_y_243), heff_dup(v_x_241))) {
      heff_drop(v_x_241);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_242});
    } else {
      V t_0 = v_ys_244;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x1_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eindexOfName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eindexOfName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2eelab_2erules_2eplacesSaid_str0, 0, (0));
HEFF_STRA(g_heff_2eelab_2erules_2eplacesSaid_str1, 6, (44, 32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2eplacesSaid_str2, 2, (44, 32));
Clo g_heff_2eelab_2erules_2eplacesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesSaid_entry, 1, 0};

V g_heff_2eelab_2erules_2eplacesSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eplacesSaid_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_str2), (g_heff_2eelab_2erules_2eplacesSaid(v_x12_242))));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2eplacesSaid(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2eelab_2erules_2efind_str0, 5, (117, 115, 101, 115, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str1, 26, (44, 32, 119, 104, 105, 99, 104, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str2, 17, (110, 111, 32, 115, 117, 99, 104, 32, 118, 97, 114, 105, 97, 98, 108, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str3, 9, (32, 105, 110, 32, 115, 99, 111, 112, 101));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str4, 1, (96));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str5, 13, (96, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str6, 9, (118, 97, 114, 105, 97, 98, 108, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efind_str7, 162, (32, 105, 115, 32, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 98, 101, 105, 110, 103, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101, 100, 58, 32, 105, 116, 32, 105, 115, 32, 105, 110, 32, 104, 97, 110, 100, 32, 111, 110, 108, 121, 32, 117, 110, 100, 101, 114, 32, 97, 32, 108, 97, 109, 98, 100, 97, 44, 32, 119, 104, 101, 114, 101, 32, 97, 32, 116, 121, 112, 101, 32, 105, 115, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 111, 102, 32, 105, 116, 32, 40, 97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 97, 32, 98, 114, 97, 110, 99, 104, 44, 32, 116, 104, 101, 32, 114, 101, 115, 117, 108, 116, 32, 45, 45, 32, 110, 111, 116, 32, 97, 32, 99, 97, 115, 101, 32, 115, 99, 114, 117, 116, 105, 110, 101, 101, 41));
V g_heff_2eelab_2erules_2efind_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efind_entry, 2, 0};

V g_heff_2eelab_2erules_2efind(V v_sp_240, V v_x_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efind_lam0, 1, 2, (V[]){v_x_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2efind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efind(a[0], a[1]);
}
V g_heff_2eelab_2erules_2efind_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str0), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str1)));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2421, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str2), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str3)));
  V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2428, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_apply(heff_take_field(v_hd_2426, 2), 1, (V[]){v_t_2431}));
  V f_ = heff_get_n(v_hd_2426, 1, 3);
  args[0] = v_t_2432;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam4(V self, V *args) {
  V v_u_2438 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ge_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2438);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, heff_get_n(v_ge_2435, 3, 4)));
}
V g_heff_2eelab_2erules_2efind_lam6(V self, V *args) {
  V v_u_2443 = args[0];
  V v_ge_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_ge_2435, 2, 4)});
}
V g_heff_2eelab_2erules_2efind_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_key_2434 = heff_env(self)[0];
  V v_ge_2435 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2442);
  V v_t_2444 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_2434}), heff_clo_n(g_heff_2eelab_2erules_2efind_lam6, 1, 1, (V[]){heff_dup(v_ge_2435)})});
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, heff_get_n(v_ge_2435, 3, 4)});
  V f_ = v_k_2437;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_key_2434 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_ge_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2439 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_2434)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_lam4, 1, 2, (V[]){v_e_242, heff_dup(v_ge_2435)})});
  V v_t_2440 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tr(heff_apply(heff_take_field(v_hd_2436, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2441;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_lam5, 1, 3, (V[]){v_key_2434, v_ge_2435, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam7(V self, V *args) {
  V v_k_2447 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_get_n(heff_get_n(v_e_242, 1, 6), 5, 6);
  V v_t_2449 = ({ V a_0 = heff_dup(v_k_2447); V a_1 = v_t_2448; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2448); r_; });
  switch (heff_tag_of(v_t_2449)) {
  case TAG_Nothing: {
    return v_k_2447;
  }
  case TAG_Just: {
    V v_place_2450 = heff_field(v_t_2449, 0);
    heff_take_n(v_t_2449, 1ULL, 1);
    heff_drop(v_k_2447);
    return v_place_2450;
  }
  default: return heff_nomatch(v_t_2449);
  }
}
V g_heff_2eelab_2erules_2efind_lam8(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_msg_2452 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_msg_2452, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2457}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2458;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k2_2460 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str6), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str7)));
  V v_t_2462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(319LL), NTAG(TAG_SError), v_t_2461, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_apply(heff_take_field(v_hd_2459, 2), 1, (V[]){v_t_2464}));
  V f_ = heff_get_n(v_hd_2459, 1, 3);
  args[0] = v_t_2465;
  args[1] = v_k2_2460;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam10(V self, V *args) {
  V v_u_2475 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ty_2468 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2475);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, v_ty_2468));
}
V g_heff_2eelab_2erules_2efind_lam11(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k2_2478 = args[1];
  V v_i_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_tag_n(TAG_Record, 2, (V[]){v_i_2476, NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tr(heff_apply(heff_take_field(v_hd_2477, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
  V f_ = heff_get_n(v_hd_2477, 1, 3);
  args[0] = v_t_2480;
  args[1] = v_k2_2478;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam13(V self, V *args) {
  V v_x_2484 = args[0];
  V v_k_2483 = heff_env(self)[0];
  V v_m_2467 = heff_env(self)[1];
  V v_ty_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2484);
  V f_ = v_k_2483;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2467, v_ty_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_lam12(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_m_2467 = heff_env(self)[1];
  V v_ty_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2481;
  args[0] = v_hd_2482;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_lam13, 1, 3, (V[]){v_k_2483, v_m_2467, v_ty_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 3, 4);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_it_246 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_t_243; V a_2 = v_t_244; V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_246)) {
  case TAG_Left: {
    V v_it1_247 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_NotInScope: {
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 4, 6);
      V v_t_249 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_t_248; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_248); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_it_2410 = (g_heff_2eelab_2eglobals_2elookupKey(heff_dup(heff_rfield(v_e_242, 1)), heff_dup(v_x_241)));
        switch (heff_tag_of(v_it_2410)) {
        case TAG_Nothing: {
          V v_g_2411 = heff_get_n(v_e_242, 1, 6);
          V v_t_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_241), heff_rfield(v_g_2411, 2)));
          V v_t_2418;
          switch (heff_tag_of(v_t_2412)) {
          case TAG_Nothing: {
            V v_x3_2413 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get_n(v_g_2411, 3, 6); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_x3_2413)) {
            case TAG_Nothing: {
              v_t_2418 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2413, 0ULL, 1);
              v_t_2418 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2413);
            }
            break;
          }
          case TAG_Just: {
            V v_k_2415 = heff_field(v_t_2412, 0);
            heff_take_n(v_t_2412, 1ULL, 1);
            V v_x3_2416 = ({ V a_0 = v_k_2415; V b_1 = heff_get_n(v_g_2411, 3, 6); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_x3_2416)) {
            case TAG_Nothing: {
              v_t_2418 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2416, 0ULL, 1);
              v_t_2418 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2416);
            }
            break;
          }
          default: heff_nomatch(v_t_2412);
          }
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam1, 2, 2, (V[]){v_x_241, v_sp_240});
          }
          case TAG_False: {
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam2, 2, 2, (V[]){v_x_241, v_sp_240});
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        case TAG_Just: {
          V v_it1_2433 = heff_field(v_it_2410, 0);
          heff_take_n(v_it_2410, 1ULL, 1);
          switch (heff_tag_of(v_it1_2433)) {
          case TAG_MkPair: {
            V v_key_2434 = heff_field(v_it1_2433, 0);
            V v_ge_2435 = heff_field(v_it1_2433, 1);
            heff_take_n(v_it1_2433, 3ULL, 2);
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam3, 2, 5, (V[]){v_sp_240, v_x_241, v_key_2434, v_e_242, v_ge_2435});
          }
          default: return heff_nomatch(v_it1_2433);
          }
        }
        default: return heff_nomatch(v_it_2410);
        }
      }
      case TAG_Just: {
        V v_ks_2446 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2451 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2efind_lam7, 1, 1, (V[]){v_e_242}), v_ks_2446));
        V v_msg_2452 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str4), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str5), ({ V a_0 = v_t_2451; V r_ = (g_heff_2eelab_2erules_2eplacesSaid(a_0)); heff_drop(v_t_2451); r_; }))));
        return heff_clo_n(g_heff_2eelab_2erules_2efind_lam8, 2, 2, (V[]){v_msg_2452, v_sp_240});
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_Delayed2: {
      heff_drop_rec(v_e_242, 6);
      return heff_clo_n(g_heff_2eelab_2erules_2efind_lam9, 2, 2, (V[]){v_x_241, v_sp_240});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  case TAG_Right: {
    V v_it1_2466 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_2466)) {
    case TAG_MkPair: {
      V v_m_2467 = heff_field(v_it1_2466, 0);
      V v_ty_2468 = heff_field(v_it1_2466, 1);
      heff_take_n(v_it1_2466, 3ULL, 2);
      V v_t_2469 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
      V v_t_2470 = ({ V a_0 = v_t_2469; V a_1 = heff_dup(v_x_241); V a_2 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2eindexOfName(a_0, a_1, a_2)); heff_drop(v_t_2469); r_; });
      V v_t_2474;
      switch (heff_tag_of(v_t_2470)) {
      case TAG_Nothing: {
        v_t_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2471 = heff_field(v_t_2470, 0);
        heff_take_n(v_t_2470, 1ULL, 1);
        V v_t_2472 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
        if (heff_intEq_c(v_i_2471, heff_intSub(v_t_2472, MK_INT(1LL)))) {
          v_t_2474 = heff_dup(heff_rfield(v_e_242, 4));
        } else {
          v_t_2474 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_t_2470);
      }
      V v_i_2476 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, v_t_2474, NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_lam10, 1, 2, (V[]){v_e_242, heff_dup(v_ty_2468)})});
      V v_c_2481 = heff_clo_n(g_heff_2eelab_2erules_2efind_lam11, 2, 1, (V[]){v_i_2476});
      return heff_clo_n(g_heff_2eelab_2erules_2efind_lam12, 2, 3, (V[]){v_c_2481, v_m_2467, v_ty_2468});
    }
    default: return heff_nomatch(v_it1_2466);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2efindPrim_str0, 17, (110, 111, 32, 115, 117, 99, 104, 32, 118, 97, 114, 105, 97, 98, 108, 101, 32));
HEFF_STRA(g_heff_2eelab_2erules_2efindPrim_str1, 9, (32, 105, 110, 32, 115, 99, 111, 112, 101));
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efindPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efindPrim_entry, 2, 0};

V g_heff_2eelab_2erules_2efindPrim(V v_sp_240, V v_p_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam0, 1, 2, (V[]){v_p_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efindPrim(a[0], a[1]);
}
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efindPrim_str0), heff_strAppend(v_p_241, ((V)&g_heff_2eelab_2erules_2efindPrim_str1)));
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_249, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ge_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2419);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, heff_get_n(v_ge_2416, 3, 4)));
}
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args) {
  V v_u_2424 = args[0];
  V v_ge_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_ge_2416, 2, 4)});
}
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_key_2415 = heff_env(self)[0];
  V v_ge_2416 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_2415}), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam5, 1, 1, (V[]){heff_dup(v_ge_2416)})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, heff_get_n(v_ge_2416, 3, 4)});
  V f_ = v_k_2418;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_key_2415 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_ge_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_p_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_2415)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam3, 1, 2, (V[]){v_e_242, heff_dup(v_ge_2416)})});
  V v_t_2421 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam4, 1, 3, (V[]){v_key_2415, v_ge_2416, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 1, 6);
  V v_t_244 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_it_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_it_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    v_it_246 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_p_241), v_e_245})});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_it_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_242, 6);
    return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam1, 2, 2, (V[]){v_p_241, v_sp_240});
  }
  case TAG_Just: {
    V v_it1_2414 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_2414)) {
    case TAG_MkPair: {
      V v_key_2415 = heff_field(v_it1_2414, 0);
      V v_ge_2416 = heff_field(v_it1_2414, 1);
      heff_take_n(v_it1_2414, 3ULL, 2);
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam2, 2, 5, (V[]){v_sp_240, v_p_241, v_key_2415, v_e_242, v_ge_2416});
    }
    default: return heff_nomatch(v_it1_2414);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str0, 5, (105, 110, 116, 69, 113));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str1, 7, (102, 108, 111, 97, 116, 69, 113));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str2, 5, (115, 116, 114, 69, 113));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str3, 6, (114, 117, 110, 101, 69, 113));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str4, 4, (105, 110, 116, 56));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str5, 5, (105, 110, 116, 49, 54));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str6, 5, (105, 110, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str7, 5, (105, 110, 116, 54, 52));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str8, 5, (117, 105, 110, 116, 56));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str9, 6, (117, 105, 110, 116, 49, 54));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str10, 6, (117, 105, 110, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str11, 6, (117, 105, 110, 116, 54, 52));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str12, 7, (102, 108, 111, 97, 116, 51, 50));
HEFF_STRA(g_heff_2eelab_2erules_2elitEq_str13, 2, (69, 113));
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitEq_entry, 5, 0};

V g_heff_2eelab_2erules_2elitEq(V v_sp_240, V v_x_241, V v_xsp_242, V v_eq_243, V v_lit_244) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam0, 1, 5, (V[]){v_xsp_242, v_x_241, v_eq_243, v_sp_240, heff_dup(v_lit_244)})});
}
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2erules_2elitEq(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  V v_t_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2417, 3, 8); V a_1 = v_t_2414; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam4, 1, 1, (V[]){v_t_2414})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_hd_2415, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitEq_lam6(V self, V *args) {
  V v_e2_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2438);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_eq_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_xsp_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2422));
  V v_t_2436;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2436 = v_eq_243;
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2423, 0ULL, 4);
    v_t_2436 = v_eq_243;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2423, 0ULL, 3);
    v_t_2436 = v_eq_243;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2436 = v_eq_243;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_eq_243);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str0);
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_eq_243);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str1);
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_eq_243);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str2);
    break;
  }
  case TAG_LikeRune: {
    heff_drop(v_eq_243);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2elitEq_str3);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2436 = v_eq_243;
    break;
  }
  case TAG_LikeFixed: {
    V v_w_2434 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    heff_drop(v_eq_243);
    V v_t_2435;
    switch (heff_tag_of(v_w_2434)) {
    case TAG_I8: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str4);
      break;
    }
    case TAG_I16: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str5);
      break;
    }
    case TAG_I32: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str6);
      break;
    }
    case TAG_I64: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str7);
      break;
    }
    case TAG_U8: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str8);
      break;
    }
    case TAG_U16: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str9);
      break;
    }
    case TAG_U32: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str10);
      break;
    }
    case TAG_U64: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str11);
      break;
    }
    case TAG_F32: {
      v_t_2435 = ((V)&g_heff_2eelab_2erules_2elitEq_str12);
      break;
    }
    default: heff_nomatch(v_w_2434);
    }
    v_t_2436 = heff_strAppend(v_t_2435, ((V)&g_heff_2eelab_2erules_2elitEq_str13));
    break;
  }
  case TAG_NoRules: {
    v_t_2436 = v_eq_243;
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_callee_2437 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), v_t_2436));
  V v_t_2441 = ({ V a_0 = v_xsp_242; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam6, 3, 1, (V[]){v_x_2411})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
  V v_callee_2442 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_240); V a_2 = v_callee_2437; V a_3 = v_t_2441; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_callee_2437); heff_drop(v_t_2441); r_; });
  V v_x1_2443 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_240; V a_2 = v_callee_2442; V a_3 = v_lit_244; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_callee_2442); heff_drop(v_lit_244); r_; });
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_MkSyn: {
    V v_f_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    return heff_tail(v_f_2444, 3, (V[]){v_e_245, v_hd_249, v_k_2410});
  }
  default: return heff_nomatch(v_x1_2443);
  }
}
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_c_2421 = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam3, 2, 1, (V[]){v_t_2414});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam5, 1, 8, (V[]){v_eq_243, v_sp_240, v_xsp_242, v_x_2411, v_lit_244, v_e_245, v_hd_249, v_k_2410})});
}
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam2, 1, 7, (V[]){v_hd_249, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_xsp_242 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(heff_dup(v_xsp_242), v_x_241));
  V v_c_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkSyn: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_c_248 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_dup(v_e_245)}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam1, 2, 6, (V[]){v_c_248, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245});
}