// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_ByFields 9073
#define TAG_ByTags 55317
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IntWord 51777
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define LBL_aliases 1464806715
#define LBL_args 9498020
#define LBL_cmt 308164
#define LBL_decls 296817955
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_equals 651658986
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_i 323
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_uses 10094739
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__span__start__equals__end[] = {LBL_name, LBL_span, LBL_start, LBL_equals, LBL_end};
static uint32_t shape_title__start__end__text[] = {LBL_title, LBL_start, LBL_end, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2equery_2eisNameChar(V);
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisNameChar_clo;
V g_heff_2eelab_2eglobals_2elookupKey(V, V);
V g_heff_2eelab_2eglobals_2elookupKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupKey_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2esplit_2ealiasedTag(V, V);
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ealiasedTag_clo;
V g_heff_2elsp_2esplit_2eapplied(V, V, V);
V g_heff_2elsp_2esplit_2eapplied_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eapplied_clo;
V g_heff_2elsp_2esplit_2earrowOutside(V, V, V);
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2earrowOutside_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS(V);
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps(V, V);
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_24dps_clo;
V g_heff_2elsp_2esplit_2edeclsOf(V);
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2edeclsOf_clo;
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2elsp_2esplit_2eextentEnd(V, V, V);
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eextentEnd_clo;
V g_heff_2elsp_2esplit_2efirstJust(V);
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efirstJust_clo;
V g_heff_2elsp_2esplit_2efresh(V, V);
V g_heff_2elsp_2esplit_2efresh_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efresh_clo;
V g_heff_2elsp_2esplit_2efreshNames(V, V);
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_clo;
V g_heff_2elsp_2esplit_2efreshNames_24dps(V, V, V);
V g_heff_2elsp_2esplit_2efreshNames_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_24dps_clo;
V g_heff_2elsp_2esplit_2ehasOperator(V, V);
V g_heff_2elsp_2esplit_2ehasOperator_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehasOperator_clo;
V g_heff_2elsp_2esplit_2ehintOf(V, V);
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehintOf_clo;
V g_heff_2elsp_2esplit_2einScopeAs(V, V, V);
V g_heff_2elsp_2esplit_2einScopeAs_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2einScopeAs_clo;
V g_heff_2elsp_2esplit_2eindentEnd(V, V);
V g_heff_2elsp_2esplit_2eindentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eindentEnd_clo;
V g_heff_2elsp_2esplit_2elastPart(V, V, V);
V g_heff_2elsp_2esplit_2elastPart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elastPart_clo;
V g_heff_2elsp_2esplit_2elineStart(V, V);
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elineStart_clo;
V g_heff_2elsp_2esplit_2elowerInitial(V);
V g_heff_2elsp_2esplit_2elowerInitial_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elowerInitial_clo;
V g_heff_2elsp_2esplit_2emadeBy(V, V, V);
V g_heff_2elsp_2esplit_2emadeBy_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2emadeBy_clo;
V g_heff_2elsp_2esplit_2emadeOf(V, V);
V g_heff_2elsp_2esplit_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2emadeOf_clo;
V g_heff_2elsp_2esplit_2enameEnd(V, V);
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enameEnd_clo;
V g_heff_2elsp_2esplit_2enextContent(V, V);
V g_heff_2elsp_2esplit_2enextContent_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enextContent_clo;
V g_heff_2elsp_2esplit_2enumbered(V, V, V);
V g_heff_2elsp_2esplit_2enumbered_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enumbered_clo;
V g_heff_2elsp_2esplit_2eoperatorOf(V, V, V);
V g_heff_2elsp_2esplit_2eoperatorOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eoperatorOf_clo;
V g_heff_2elsp_2esplit_2eoperators(V, V);
V g_heff_2elsp_2esplit_2eoperators_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eoperators_clo;
V g_heff_2elsp_2esplit_2epatternsOf(V, V, V, V, V);
V g_heff_2elsp_2esplit_2epatternsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2epatternsOf_clo;
V g_heff_2elsp_2esplit_2esplit(V, V, V, V);
V g_heff_2elsp_2esplit_2esplit_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2esplit_clo;
V g_heff_2elsp_2esplit_2esplittable(V);
V g_heff_2elsp_2esplit_2esplittable_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2esplittable_clo;
V g_heff_2elsp_2esplit_2espotInDecl(V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotInDecl_clo;
V g_heff_2elsp_2esplit_2espotOf(V, V, V, V);
V g_heff_2elsp_2esplit_2espotOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotOf_clo;
V g_heff_2elsp_2esplit_2etagPatterns(V, V, V, V, V, V);
V g_heff_2elsp_2esplit_2etagPatterns_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2etagPatterns_clo;
V g_heff_2elsp_2esplit_2etypeHead(V);
V g_heff_2elsp_2esplit_2etypeHead_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2etypeHead_clo;
V g_heff_2elsp_2esplit_2etypeUsedAt(V, V, V);
V g_heff_2elsp_2esplit_2etypeUsedAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2etypeUsedAt_clo;
V g_heff_2elsp_2esplit_2eusedType(V, V);
V g_heff_2elsp_2esplit_2eusedType_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eusedType_clo;
V g_heff_2elsp_2esplit_2evarIn(V, V);
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2evarIn_clo;
V g_heff_2elsp_2esplit_2ewordsIn(V, V, V, V);
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ewordsIn_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1109331425x852844386(V, V, V);
V g_list_2efilter_24s1109331425x852844386_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1184231137x30317987(V, V);
V g_list_2efind_24s1184231137x30317987_entry(V self, V *a);
extern Clo g_list_2efind_24s1184231137x30317987_clo;
V g_list_2efind_24s1504327023x469120796(V, V);
V g_list_2efind_24s1504327023x469120796_entry(V self, V *a);
extern Clo g_list_2efind_24s1504327023x469120796_clo;
V g_list_2efind_24s2097374064x1697419390(V, V);
V g_list_2efind_24s2097374064x1697419390_entry(V self, V *a);
extern Clo g_list_2efind_24s2097374064x1697419390_clo;
V g_list_2efind_24s988189774x1593035904(V, V);
V g_list_2efind_24s988189774x1593035904_entry(V self, V *a);
extern Clo g_list_2efind_24s988189774x1593035904_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2092573095x552609762(V, V);
V g_list_2efoldl_24s2092573095x552609762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092573095x552609762_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1372232877x278600396(V);
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1943354043x700174004(V, V, V);
V g_list_2emap_24s1943354043x700174004_entry(V self, V *a);
extern Clo g_list_2emap_24s1943354043x700174004_clo;
V g_list_2emap_24s499193121x1224230698(V);
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strEq_get(void);
Clo g_heff_2elsp_2esplit_2efirstJust_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efirstJust_entry, 1, 0};

V g_heff_2elsp_2esplit_2efirstJust(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2efirstJust(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ecatMaybesS_entry, 1, 0};

V g_heff_2elsp_2esplit_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2esplit_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ecatMaybesS(a[0]);
}
Clo g_heff_2elsp_2esplit_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2elsp_2esplit_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ecatMaybesS_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2enameEnd_entry, 2, 0};

V g_heff_2elsp_2esplit_2enameEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    V v_t_243 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(46LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        return v_i_241;
      }
    }
  } else {
    heff_drop(v_s_240);
    return v_i_241;
  }
}
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2enameEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2esplit_2edeclsOf_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2edeclsOf_str1, 0, "");
Clo g_heff_2elsp_2esplit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2edeclsOf_entry, 1, 0};

V g_heff_2elsp_2esplit_2edeclsOf(V v_c_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_c_240, 4));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    V v_src_242 = heff_take_field(v_c_240, 3);
    V v_t_243 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_get_n(v_c_240, 11, 13), NTAG(TAG_True), ((V)&g_heff_2elsp_2esplit_2edeclsOf_str0), ((V)&g_heff_2elsp_2esplit_2edeclsOf_str1)});
    V v_t_244 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_t_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_242), v_t_244, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_246 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_242, v_t_243, v_t_245));
    return heff_get_n(v_t_246, 0, 4);
  }
  case TAG_Cons: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_get_n(v_c_240, 4, 13);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2edeclsOf(a[0]);
}
Clo g_heff_2elsp_2esplit_2elineStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2elineStart_entry, 2, 0};

V g_heff_2elsp_2esplit_2elineStart(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_241), MK_INT(0LL))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(10LL))) {
      heff_drop(v_src_240);
      return v_i_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2elineStart(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2eindentEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eindentEnd_entry, 2, 0};

V g_heff_2elsp_2esplit_2eindentEnd(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_src_240, 0))) {
    V v_c_243 = heff_strByteAt_lent(v_src_240, v_i_241, 0);
    if (heff_intEq_c(heff_dup(v_c_243), MK_INT(32LL))) {
      heff_drop(v_c_243);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_c_243, MK_INT(9LL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_src_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_src_240);
        return v_i_241;
      }
    }
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2elsp_2esplit_2eindentEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2eindentEnd(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2enextContent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2enextContent_entry, 2, 0};

V g_heff_2elsp_2esplit_2enextContent(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2elsp_2esplit_2eindentEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), v_x_242)) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_244 = (g_heff_2elsp_2esplit_2eindentEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
    if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_t_244, 2), MK_INT(10LL))) {
      V v_t_246 = (g_heff_2elsp_2esplit_2eindentEnd(heff_dup(v_src_240), v_i_241));
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_246, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_src_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    }
  }
}
V g_heff_2elsp_2esplit_2enextContent_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2enextContent(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2esplit_2eextentEnd_str0, 1, "\012");
Clo g_heff_2elsp_2esplit_2eextentEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eextentEnd_entry, 3, 0};

V g_heff_2elsp_2esplit_2eextentEnd(V v_src_240, V v_col_241, V v_i_242) {
top: ;
  V v_t_243 = (g_heff_2elsp_2esplit_2enextContent(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_242), MK_INT(1LL))));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_col_241);
    return v_i_242;
  }
  case TAG_Just: {
    V v_s_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = (g_heff_2elsp_2esplit_2eindentEnd(heff_dup(v_src_240), heff_dup(v_s_244)));
    V v_x_246 = heff_intSub(v_t_245, heff_dup(v_s_244));
    if (heff_intLt_c(heff_dup(v_col_241), v_x_246)) {
      heff_drop(v_i_242);
      V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2esplit_2eextentEnd_str0), v_src_240, v_s_244, 5);
      V v_t_2410;
      if (heff_intLt_c(heff_dup(v_j_248), MK_INT(0LL))) {
        heff_drop(v_j_248);
        v_t_2410 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2410 = v_j_248;
      }
      V t_0 = v_src_240;
      V t_1 = v_col_241;
      V t_2 = v_t_2410;
      v_src_240 = t_0;
      v_col_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      heff_drop(v_src_240);
      heff_drop(v_col_241);
      heff_drop(v_s_244);
      return v_i_242;
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2eextentEnd(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2esplit_2esplittable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2esplittable_entry, 1, 0};

V g_heff_2elsp_2esplit_2esplittable(V v_x_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0)) && ({ V v_c_242 = heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2); int c_ = (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_242)) ? (heff_intLe_c(heff_dup(v_c_242), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_242)) && heff_intLe_c(heff_dup(v_c_242), MK_INT(90LL)))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_242)) && heff_intLe_c(heff_dup(v_c_242), MK_INT(90LL)))); heff_drop(v_c_242); c_; })));
  heff_drop(v_x_240);
  return v_ret_24bool;
}
V g_heff_2elsp_2esplit_2esplittable_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2esplittable(a[0]);
}
V g_heff_2elsp_2esplit_2evarIn_lam0(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_lam1(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_lam2(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_lam3(V self, V *args);
Clo g_heff_2elsp_2esplit_2evarIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2evarIn_entry, 2, 0};

V g_heff_2elsp_2esplit_2evarIn(V v_off_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      if (heff_intLe_c(heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(v_off_240))) {
        if (heff_intLe_c(v_off_240, heff_dup(heff_rfield(v_sp_243, 1)))) {
          V v_t_247 = (g_heff_2elsp_2esplit_2esplittable(heff_dup(v_x_244)));
          if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
            heff_drop(v_t_247);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){heff_dup(v_x_244), heff_dup(v_sp_243)})});
          } else {
            heff_drop(v_t_247);
            return NTAG(TAG_Nothing);
          }
        } else {
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_off_240);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_x21_242, 2);
      V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_lam0, 1, 1, (V[]){v_off_240}), heff_dup(v_ps_2410)));
      return ({ V a_0 = v_t_2412; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_x21_242, 2);
      V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_lam1, 1, 1, (V[]){v_off_240}), heff_dup(v_ps_2415)));
      return ({ V a_0 = v_t_2417; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2417); r_; });
    }
    case TAG_PatInt: {
      heff_drop(v_off_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_PatFloat: {
      heff_drop(v_off_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_PatString: {
      heff_drop(v_off_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_x21_242, 0);
      V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_lam2, 1, 1, (V[]){v_off_240}), heff_dup(v_segs_2421)));
      return ({ V a_0 = v_t_2430; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2430); r_; });
    }
    case TAG_PatRune: {
      heff_drop(v_off_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_PatRecord: {
      V v_fs_2432 = heff_field(v_x21_242, 0);
      V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_lam3, 1, 1, (V[]){v_off_240}), heff_dup(v_fs_2432)));
      return ({ V a_0 = v_t_2437; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2437); r_; });
    }
    case TAG_PatWord: {
      heff_drop(v_off_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_PatAs: {
      V v_p_2441 = heff_field(v_x21_242, 2);
      V t_0 = v_off_240;
      V t_1 = v_p_2441;
      v_off_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2esplit_2evarIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2esplit_2evarIn_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_240; V a_1 = v_p_2411; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2411); r_; });
}
V g_heff_2elsp_2esplit_2evarIn_lam1(V self, V *args) {
  V v_p_2416 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_240; V a_1 = v_p_2416; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2416); r_; });
}
V g_heff_2elsp_2esplit_2evarIn_lam2(V self, V *args) {
  V v_m_2422 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2422)) {
  case TAG_At: {
    V v_it1_2423 = heff_field(v_m_2422, 0);
    heff_take_n(v_m_2422, 1ULL, 2);
    switch (heff_tag_of(v_it1_2423)) {
    case TAG_MkSegment: {
      V v_v_2425 = heff_field(v_it1_2423, 0);
      heff_take_n(v_it1_2423, 1ULL, 5);
      return ({ V a_0 = v_off_240; V a_1 = v_v_2425; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_v_2425); r_; });
    }
    default: return heff_nomatch(v_it1_2423);
    }
  }
  default: return heff_nomatch(v_m_2422);
  }
}
V g_heff_2elsp_2esplit_2evarIn_lam3(V self, V *args) {
  V v_f_2433 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_f_2433)) {
  case TAG_MkFieldPat: {
    V v_p_2435 = heff_field(v_f_2433, 1);
    heff_take_n(v_f_2433, 2ULL, 2);
    v_t_2436 = v_p_2435;
    break;
  }
  default: heff_nomatch(v_f_2433);
  }
  return ({ V a_0 = v_off_240; V a_1 = v_t_2436; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_t_2436); r_; });
}
HEFF_LIT(g_heff_2elsp_2esplit_2espotOf_str0, 1, "=");
HEFF_LIT(g_heff_2elsp_2esplit_2espotOf_str1, 1, "\012");
Clo g_heff_2elsp_2esplit_2espotOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2espotOf_entry, 4, 0};

V g_heff_2elsp_2esplit_2espotOf(V v_src_240, V v_v_241, V v_sp_242, V v_ps_243) {
top: ;
  V v_i_244 = (g_list_2efoldl_24s2092573095x552609762(heff_dup(heff_rfield(v_sp_242, 0)), v_ps_243));
  V v_j_245 = heff_strFind_lent(((V)&g_heff_2elsp_2esplit_2espotOf_str0), v_src_240, v_i_244, 5);
  if (heff_intLt_c(heff_dup(v_j_245), MK_INT(0LL))) {
    heff_drop(v_src_240);
    heff_drop_rec(v_v_241, 2);
    heff_drop_rec(v_sp_242, 2);
    heff_drop(v_j_245);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_247 = (g_heff_2elsp_2esplit_2elineStart(heff_dup(v_src_240), heff_dup(heff_rfield(v_sp_242, 0))));
    V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_sp_242, 0)), v_t_247);
    V v_j_249 = heff_strFind(((V)&g_heff_2elsp_2esplit_2espotOf_str1), heff_dup(v_src_240), heff_take_field(v_sp_242, 1));
    V v_t_2411;
    if (heff_intLt_c(heff_dup(v_j_249), MK_INT(0LL))) {
      heff_drop(v_j_249);
      v_t_2411 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_2411 = v_j_249;
    }
    V v_t_2412 = (g_heff_2elsp_2esplit_2eextentEnd(v_src_240, v_t_248, v_t_2411));
    V v_t_2413 = heff_rec_n(5, shape_name__span__start__equals__end, (V[]){heff_take_field(v_v_241, 0), heff_get_n(v_v_241, 1, 2), heff_get_n(v_sp_242, 0, 2), heff_intAdd(v_j_245, MK_INT(1LL)), v_t_2412});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  }
}
V g_heff_2elsp_2esplit_2espotOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2esplit_2espotOf(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2elsp_2esplit_2espotInDecl_lam1(V self, V *args);
V g_heff_2elsp_2esplit_2espotInDecl_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2espotInDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2espotInDecl_entry, 3, 0};

V g_heff_2elsp_2esplit_2espotInDecl(V v_src_240, V v_off_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_DeclEquations: {
      V v_eqs_249 = heff_field(v_x31_243, 4);
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2espotInDecl_lam0, 1, 2, (V[]){v_off_241, v_src_240}), heff_dup(v_eqs_249)));
      return ({ V a_0 = v_t_2421; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2421); r_; });
    }
    case TAG_DeclDefine: {
      heff_drop(v_src_240);
      heff_drop(v_off_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_drop(v_src_240);
      heff_drop(v_off_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_drop(v_src_240);
      heff_drop(v_off_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_drop(v_src_240);
      heff_drop(v_off_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_drop(v_src_240);
      heff_drop(v_off_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2esplit_2espotInDecl(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2esplit_2espotInDecl_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_off_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_241; V a_1 = v_p_2417; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2417); r_; });
}
V g_heff_2elsp_2esplit_2espotInDecl_lam0(V self, V *args) {
  V v_e_2410 = args[0];
  V v_off_241 = heff_env(self)[0];
  V v_src_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_e_2410)) {
  case TAG_At: {
    V v_x31_2411 = heff_field(v_e_2410, 0);
    V v_sp_2412 = heff_field(v_e_2410, 1);
    heff_take_n(v_e_2410, 3ULL, 2);
    switch (heff_tag_of(v_x31_2411)) {
    case TAG_MkEquation: {
      V v_ps_2415 = heff_field(v_x31_2411, 2);
      heff_take_n(v_x31_2411, 4ULL, 4);
      V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2espotInDecl_lam1, 1, 1, (V[]){v_off_241}), heff_dup(v_ps_2415)));
      V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2418); r_; });
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        heff_drop(v_src_240);
        heff_drop(v_sp_2412);
        heff_drop(v_ps_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_v_2420 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        return ({ V a_0 = v_src_240; V a_1 = v_v_2420; V a_2 = v_sp_2412; V a_3 = v_ps_2415; V r_ = (g_heff_2elsp_2esplit_2espotOf(a_0, a_1, a_2, a_3)); heff_drop(v_ps_2415); r_; });
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    default: return heff_nomatch(v_x31_2411);
    }
  }
  default: return heff_nomatch(v_e_2410);
  }
}
Clo g_heff_2elsp_2esplit_2etypeUsedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2etypeUsedAt_entry, 3, 0};

V g_heff_2elsp_2esplit_2etypeUsedAt(V v_c_240, V v_x_241, V v_off_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_c_240, 5, 13), 7, 9);
  V v_t_244 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), v_off_242, v_t_243));
  V v_x1_245 = (g_list_2esortBy_24s1681607803x465385494(v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), v_x_241)) {
      V v_t_249 = heff_take_field(v_x_246, 2);
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_t_2410 = heff_tr(heff_call(heff_get_n(v_x_246, 4, 5), 1, (V[]){NTAG(TAG_MkUnit)}));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
      }
      case TAG_Just: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop_rec(v_x_246, 5);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_249);
      }
    } else {
      heff_drop_rec(v_x_246, 5);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2elsp_2esplit_2etypeUsedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2etypeUsedAt(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2esplit_2eusedType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eusedType_entry, 2, 0};

V g_heff_2elsp_2esplit_2eusedType(V v_c_240, V v_s_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_240, 4)));
  V v_t_243 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_242));
  V v_t_244 = ({ V a_0 = heff_dup(v_s_241); V b_1 = heff_get_n(v_t_243, 0, 2); V r_ = (g_list_2efind_24s1504327023x469120796(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 13);
    heff_drop_rec(v_s_241, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_l_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_get_n(v_l_245, 2, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_c_240, 13);
      heff_drop_rec(v_s_241, 5);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      V v_t_249 = heff_get_n(heff_get_n(v_c_240, 5, 13), 7, 9);
      V v_t_2410 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), heff_get_n(v_x_247, 0, 2), v_t_249));
      V v_x1_2411 = (g_list_2esortBy_24s1681607803x465385494(v_t_2410));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_241, 5);
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), heff_get_n(v_s_241, 0, 5))) {
          V v_t_2415 = heff_take_field(v_x_2412, 2);
          switch (heff_tag_of(v_t_2415)) {
          case TAG_Nothing: {
            V v_t_2416 = heff_tr(heff_call(heff_get_n(v_x_2412, 4, 5), 1, (V[]){NTAG(TAG_MkUnit)}));
            return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2416});
          }
          case TAG_Just: {
            heff_take_n(v_t_2415, 0ULL, 1);
            heff_drop_cell(v_ru_24t_244_24Just, 1);
            heff_drop_rec(v_x_2412, 5);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2415);
          }
        } else {
          heff_drop_cell(v_ru_24t_244_24Just, 1);
          heff_drop_rec(v_x_2412, 5);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2esplit_2eusedType_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2eusedType(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2earrowOutside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2earrowOutside_entry, 3, 0};

V g_heff_2elsp_2esplit_2earrowOutside(V v_s_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_d_242);
    return NTAG(TAG_False);
  } else {
    V v_t_246 = heff_bool((heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(40LL)) || (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(91LL)) || heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(123LL)))));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_d_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_t_249 = heff_bool((heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(41LL)) || (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(93LL)) || heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(125LL)))));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = heff_intSub(v_d_242, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_249);
        if (heff_intEq_c(heff_dup(v_d_242), MK_INT(0LL))) {
          if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(45LL))) {
            V v_t_2412 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
            if (heff_intEq_c(v_t_2412, MK_INT(62LL))) {
              heff_drop(v_s_240);
              heff_drop(v_i_241);
              heff_drop(v_d_242);
              return NTAG(TAG_True);
            } else {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
              V t_2 = v_d_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_d_242 = t_2;
              goto top;
            }
          } else {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            V t_2 = v_d_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_d_242 = t_2;
            goto top;
          }
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_d_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_d_242 = t_2;
          goto top;
        }
      }
    }
  }
}
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2earrowOutside(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2esplit_2etypeHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2etypeHead_entry, 1, 0};

V g_heff_2elsp_2esplit_2etypeHead(V v_t_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_t_240, 0))) {
    V v_c_242 = heff_strByteAt_lent(v_t_240, MK_INT(0LL), 2);
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_242))) {
      if (heff_intLe_c(v_c_242, MK_INT(90LL))) {
        V v_x1_245 = (g_heff_2elsp_2esplit_2earrowOutside(heff_dup(v_t_240), MK_INT(0LL), MK_INT(0LL)));
        if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
          heff_drop(v_t_240);
          heff_drop(v_x1_245);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_245);
          V v_t_246 = (g_heff_2elsp_2esplit_2enameEnd(heff_dup(v_t_240), MK_INT(0LL)));
          return heff_tag_n(TAG_Just, 1, (V[]){heff_strSlice(v_t_240, MK_INT(0LL), v_t_246)});
        }
      } else {
        heff_drop(v_t_240);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_t_240);
      heff_drop(v_c_242);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2elsp_2esplit_2etypeHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2etypeHead(a[0]);
}
Clo g_heff_2elsp_2esplit_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2emadeOf_entry, 2, 0};

V g_heff_2elsp_2esplit_2emadeOf(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      V v_fs_2428 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      switch (heff_tag_of(v_fs_2428)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x21_242_24ESig, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_t_2431 = (g_list_2emap_24s1387309293x1990579214(v_fs_2428));
        V v_t_2432 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_2431));
        return heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_Just, 1, (V[]){heff_tag_n(TAG_ByFields, 1, (V[]){v_t_2432})});
      }
      default: return heff_nomatch(v_fs_2428);
      }
    }
    case TAG_ESum: {
      V v_vs_2433 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_vs_2433)) {
      case TAG_Nil: {
        heff_drop(v_ps_240);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        heff_drop_cell(v_ru_24x21_242_24ESum, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_t_2436 = (g_list_2emap_24s580776739x648604941(v_vs_2433));
        V v_t_2437 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_2436));
        return heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_ByTags, 2, (V[]){v_ps_240, v_t_2437})});
      }
      default: return heff_nomatch(v_vs_2433);
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_ps_240);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2emadeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2emadeOf(a[0], a[1]);
}
V g_heff_2elsp_2esplit_2emadeBy_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2emadeBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2emadeBy_entry, 3, 0};

V g_heff_2elsp_2esplit_2emadeBy(V v_program_240, V v_c_241, V v_x_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
  V v_it_244 = (g_heff_2eelab_2eglobals_2elookupKey(v_t_243, v_x_242));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_MkPair: {
      V v_k_246 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 2);
      V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2emadeBy_lam0, 1, 1, (V[]){v_k_246}), v_program_240));
      V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2412); r_; });
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_d_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        switch (heff_tag_of(v_d_2414)) {
        case TAG_At: {
          V v_x11_2415 = heff_field(v_d_2414, 0);
          heff_take_n(v_d_2414, 1ULL, 2);
          switch (heff_tag_of(v_x11_2415)) {
          case TAG_DeclEquations: {
            heff_take_n(v_x11_2415, 0ULL, 5);
            return NTAG(TAG_Nothing);
          }
          case TAG_DeclDefine: {
            V v_ps_2424 = heff_field(v_x11_2415, 2);
            V v_body_2426 = heff_field(v_x11_2415, 4);
            heff_take_n(v_x11_2415, 20ULL, 5);
            V v_t_2427 = (g_list_2emap_24s1170504272x1852564147(v_ps_2424));
            return (g_heff_2elsp_2esplit_2emadeOf(v_t_2427, v_body_2426));
          }
          case TAG_DeclTheory: {
            heff_take_n(v_x11_2415, 0ULL, 4);
            return NTAG(TAG_Nothing);
          }
          case TAG_DeclPrimitive: {
            heff_take_n(v_x11_2415, 0ULL, 3);
            return NTAG(TAG_Nothing);
          }
          case TAG_DeclTest: {
            heff_take_n(v_x11_2415, 0ULL, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_DeclWatch: {
            heff_take_n(v_x11_2415, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x11_2415);
          }
        }
        default: return heff_nomatch(v_d_2414);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2elsp_2esplit_2emadeBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2emadeBy(a[0], a[1], a[2]);
}
V g_heff_2elsp_2esplit_2emadeBy_lam0(V self, V *args) {
  V v_c2_248 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_list_2efind_24s988189774x1593035904(v_k_246, heff_rfield(v_c2_248, 7)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c2_248, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_o_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2411 = (g_heff_2elsp_2esplit_2edeclsOf(v_c2_248));
    return ({ V a_0 = v_o_2410; V a_1 = v_t_2411; V r_ = (g_list_2efind_24s2097374064x1697419390(a_0, a_1)); heff_drop(v_t_2411); r_; });
  }
  default: return heff_nomatch(v_t_249);
  }
}
Clo g_heff_2elsp_2esplit_2eexprName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eexprName_entry, 1, 0};

V g_heff_2elsp_2esplit_2eexprName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_245)});
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2eexprName(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2ealiasedTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ealiasedTag_entry, 2, 0};

V g_heff_2elsp_2esplit_2ealiasedTag(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EImplicitVar: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      V v_f_2413 = heff_field(v_x21_242, 0);
      V v_args_2414 = heff_field(v_x21_242, 1);
      V v_x1_2415 = (g_list_2emap_24s499193121x1224230698(v_ps_240));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Nil: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_x12_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Nothing: {
          heff_drop(v_x12_2417);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_a_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          switch (heff_tag_of(v_x12_2417)) {
          case TAG_Nil: {
            heff_drop(v_a_2418);
            return NTAG(TAG_Nothing);
          }
          case TAG_Cons: {
            V v_x121_2419 = heff_field(v_x12_2417, 0);
            V v_x122_2420 = heff_field(v_x12_2417, 1);
            heff_take_n(v_x12_2417, 3ULL, 2);
            switch (heff_tag_of(v_x121_2419)) {
            case TAG_Nothing: {
              heff_drop(v_a_2418);
              heff_drop(v_x122_2420);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_b_2421 = heff_field(v_x121_2419, 0);
              heff_take_n(v_x121_2419, 1ULL, 1);
              switch (heff_tag_of(v_x122_2420)) {
              case TAG_Nil: {
                V v_x1_2422 = (g_list_2emap_24s1372232877x278600396(heff_dup(v_args_2414)));
                switch (heff_tag_of(v_x1_2422)) {
                case TAG_Nil: {
                  heff_drop(v_a_2418);
                  heff_drop(v_b_2421);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Cons: {
                  V v_x11_2423 = heff_field(v_x1_2422, 0);
                  V v_x12_2424 = heff_field(v_x1_2422, 1);
                  heff_take_n(v_x1_2422, 3ULL, 2);
                  switch (heff_tag_of(v_x11_2423)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_2418);
                    heff_drop(v_b_2421);
                    heff_drop(v_x12_2424);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_a_2425 = heff_field(v_x11_2423, 0);
                    heff_take_n(v_x11_2423, 1ULL, 1);
                    switch (heff_tag_of(v_x12_2424)) {
                    case TAG_Nil: {
                      heff_drop(v_a_2418);
                      heff_drop(v_b_2421);
                      heff_drop(v_a_2425);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Cons: {
                      V v_x121_2426 = heff_field(v_x12_2424, 0);
                      V v_x122_2427 = heff_field(v_x12_2424, 1);
                      heff_take_n(v_x12_2424, 3ULL, 2);
                      switch (heff_tag_of(v_x121_2426)) {
                      case TAG_Nothing: {
                        heff_drop(v_a_2418);
                        heff_drop(v_b_2421);
                        heff_drop(v_a_2425);
                        heff_drop(v_x122_2427);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_b_2428 = heff_field(v_x121_2426, 0);
                        heff_take_n(v_x121_2426, 1ULL, 1);
                        switch (heff_tag_of(v_x122_2427)) {
                        case TAG_Nil: {
                          if (heff_strEq_c(v_a_2418, v_a_2425)) {
                            if (heff_strEq_c(v_b_2421, v_b_2428)) {
                              return (g_heff_2elsp_2esplit_2eexprName(v_f_2413));
                            } else {
                              return NTAG(TAG_Nothing);
                            }
                          } else {
                            heff_drop(v_b_2421);
                            heff_drop(v_b_2428);
                            return NTAG(TAG_Nothing);
                          }
                        }
                        case TAG_Cons: {
                          heff_take_n(v_x122_2427, 0ULL, 2);
                          heff_drop(v_a_2418);
                          heff_drop(v_b_2421);
                          heff_drop(v_a_2425);
                          heff_drop(v_b_2428);
                          return NTAG(TAG_Nothing);
                        }
                        default: return heff_nomatch(v_x122_2427);
                        }
                      }
                      default: return heff_nomatch(v_x121_2426);
                      }
                    }
                    default: return heff_nomatch(v_x12_2424);
                    }
                  }
                  default: return heff_nomatch(v_x11_2423);
                  }
                }
                default: return heff_nomatch(v_x1_2422);
                }
              }
              case TAG_Cons: {
                heff_take_n(v_x122_2420, 0ULL, 2);
                heff_drop(v_a_2418);
                heff_drop(v_b_2421);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_x122_2420);
              }
            }
            default: return heff_nomatch(v_x121_2419);
            }
          }
          default: return heff_nomatch(v_x12_2417);
          }
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    case TAG_EProject: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2esplit_2ealiasedTag(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2esplit_2einScopeAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2einScopeAs_entry, 3, 0};

V g_heff_2elsp_2esplit_2einScopeAs(V v_g_240, V v_c_241, V v_x_242) {
top: ;
  V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_c_241, 7, 13); V r_ = (g_list_2efind_24s1184231137x30317987(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_g_240, 7);
    heff_drop(v_x_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_o_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_k_245 = heff_get_n(v_o_244, 1, 2);
    V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_g_240, 2)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop(v_x_242);
        heff_drop(v_k_245);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_247, 0ULL, 1);
        return heff_strEq(v_k_245, v_x_242);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_Just: {
      V v_k_249 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      heff_drop(v_x_242);
      V v_t_2410 = ({ V a_0 = heff_dup(v_k_249); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_k_245);
        heff_drop(v_k_249);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_2410, 0ULL, 1);
        return heff_strEq(v_k_245, v_k_249);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2esplit_2einScopeAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2einScopeAs(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2esplit_2eoperatorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eoperatorOf_entry, 3, 0};

V g_heff_2elsp_2esplit_2eoperatorOf(V v_g_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 1ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_DeclEquations: {
      V v_op_245 = heff_field(v_x31_243, 0);
      V v_x315_249 = heff_field(v_x31_243, 4);
      heff_take_n(v_x31_243, 17ULL, 5);
      switch (heff_tag_of(v_x315_249)) {
      case TAG_Nil: {
        heff_drop(v_g_240);
        heff_drop(v_c_241);
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop(v_op_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_e_2410 = heff_field(v_x315_249, 0);
        V v_x3152_2411 = heff_field(v_x315_249, 1);
        heff_take_n(v_x315_249, 3ULL, 2);
        switch (heff_tag_of(v_x3152_2411)) {
        case TAG_Nil: {
          if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_op_245, 0))) {
            V v_x1_2413 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_op_245, MK_INT(0LL), 2)));
            if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
              heff_drop(v_g_240);
              heff_drop(v_c_241);
              heff_drop_cell(v_ru_24x3_242_24At, 2);
              heff_drop(v_op_245);
              heff_drop(v_e_2410);
              heff_drop(v_x1_2413);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_x1_2413);
              V v_t_2414 = (g_heff_2elsp_2esplit_2einScopeAs(v_g_240, v_c_241, heff_dup(v_op_245)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_t_2414);
                V v_t_2421;
                switch (heff_tag_of(v_e_2410)) {
                case TAG_At: {
                  V v_x11_2415 = heff_field(v_e_2410, 0);
                  heff_take_n(v_e_2410, 1ULL, 2);
                  switch (heff_tag_of(v_x11_2415)) {
                  case TAG_MkEquation: {
                    V v_ps_2419 = heff_field(v_x11_2415, 2);
                    V v_body_2420 = heff_field(v_x11_2415, 3);
                    heff_take_n(v_x11_2415, 12ULL, 4);
                    v_t_2421 = ({ V a_0 = v_ps_2419; V a_1 = v_body_2420; V r_ = (g_heff_2elsp_2esplit_2ealiasedTag(a_0, a_1)); heff_drop(v_body_2420); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_2415);
                  }
                  break;
                }
                default: heff_nomatch(v_e_2410);
                }
                switch (heff_tag_of(v_t_2421)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24x3_242_24At, 2);
                  heff_drop(v_op_245);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_t_2422 = heff_field(v_t_2421, 0);
                  V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
                  return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24At, TAG_MkPair, 2, (V[]){v_t_2422, v_op_245})});
                }
                default: return heff_nomatch(v_t_2421);
                }
              } else {
                heff_drop_cell(v_ru_24x3_242_24At, 2);
                heff_drop(v_op_245);
                heff_drop(v_e_2410);
                heff_drop(v_t_2414);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_g_240);
            heff_drop(v_c_241);
            heff_drop_cell(v_ru_24x3_242_24At, 2);
            heff_drop(v_op_245);
            heff_drop(v_e_2410);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x3152_2411, 0ULL, 2);
          heff_drop(v_g_240);
          heff_drop(v_c_241);
          heff_drop_cell(v_ru_24x3_242_24At, 2);
          heff_drop(v_op_245);
          heff_drop(v_e_2410);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x3152_2411);
        }
      }
      default: return heff_nomatch(v_x315_249);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2esplit_2eoperatorOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2eoperatorOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2esplit_2ehasOperator_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2ehasOperator_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ehasOperator_entry, 2, 0};

V g_heff_2elsp_2esplit_2ehasOperator(V v_g_240, V v_c_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2elsp_2esplit_2ehasOperator_lam0, 1, 2, (V[]){v_g_240, heff_dup(v_c_241)}); V b_1 = heff_get_n(v_c_241, 7, 13); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2elsp_2esplit_2ehasOperator_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ehasOperator(a[0], a[1]);
}
V g_heff_2elsp_2esplit_2ehasOperator_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_243 = heff_dup(heff_rfield(v_o_242, 0));
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_243, 0))) {
    V v_x1_245 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt(v_x_243, MK_INT(0LL))));
    if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_o_242, 2);
      heff_drop(v_g_240);
      heff_drop_rec(v_c_241, 13);
      heff_drop(v_x1_245);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_245);
      return (g_heff_2elsp_2esplit_2einScopeAs(v_g_240, v_c_241, heff_get_n(v_o_242, 0, 2)));
    }
  } else {
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_g_240);
    heff_drop_rec(v_c_241, 13);
    heff_drop(v_x_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2esplit_2eoperators_lam1(V self, V *args);
V g_heff_2elsp_2esplit_2eoperators_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2eoperators_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eoperators_entry, 2, 0};

V g_heff_2elsp_2esplit_2eoperators(V v_program_240, V v_c_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
  return ({ V a_0 = heff_clo_n(g_heff_2elsp_2esplit_2eoperators_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2elsp_2esplit_2eoperators_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2eoperators(a[0], a[1]);
}
V g_heff_2elsp_2esplit_2eoperators_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2esplit_2eoperatorOf(v_g_245, v_x_244, v_d_248));
}
V g_heff_2elsp_2esplit_2eoperators_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_245 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
  V v_t_246 = (g_heff_2elsp_2esplit_2ehasOperator(heff_dup(v_g_245), heff_dup(v_x_244)));
  V v_t_2410;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = (g_heff_2elsp_2esplit_2edeclsOf(heff_dup(v_x_244)));
    V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2eoperators_lam1, 1, 2, (V[]){v_g_245, v_x_244}), v_t_247));
    v_t_2410 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_249));
  } else {
    heff_drop(v_x_244);
    heff_drop(v_g_245);
    heff_drop(v_t_246);
    v_t_2410 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_243));
}
Clo g_heff_2elsp_2esplit_2elowerInitial_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2elowerInitial_entry, 1, 0};

V g_heff_2elsp_2esplit_2elowerInitial(V v_x_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0))) {
    V v_c_242 = heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2);
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_242))) {
      if (heff_intLe_c(v_c_242, MK_INT(90LL))) {
        V v_t_245 = heff_intAdd(heff_strByteAt(v_x_240, MK_INT(0LL)), MK_INT(32LL));
        return heff_strFromByte(heff_box_u8(heff_from_int_u8(v_t_245)));
      } else {
        return heff_strSlice(v_x_240, MK_INT(0LL), MK_INT(1LL));
      }
    } else {
      heff_drop(v_c_242);
      return heff_strSlice(v_x_240, MK_INT(0LL), MK_INT(1LL));
    }
  } else {
    return heff_strSlice(v_x_240, MK_INT(0LL), MK_INT(1LL));
  }
}
V g_heff_2elsp_2esplit_2elowerInitial_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2elowerInitial(a[0]);
}
Clo g_heff_2elsp_2esplit_2elastPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2elastPart_entry, 3, 0};

V g_heff_2elsp_2esplit_2elastPart(V v_x_240, V v_i_241, V v_from_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_x_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strSlice(heff_dup(v_x_240), v_from_242, heff_strLength(v_x_240));
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_x_240, v_i_241, 0), MK_INT(46LL))) {
      heff_drop(v_from_242);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_from_242 = t_2;
      goto top;
    } else {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_from_242;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_from_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2elastPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2elastPart(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str0, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str1, 4, "List");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str2, 2, "xs");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str3, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str4, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str5, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str6, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str7, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str8, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str9, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str10, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str11, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str12, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str13, 1, "s");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str14, 1, "c");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str15, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str16, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str17, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str18, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str19, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str20, 1, "f");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str21, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str22, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str23, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str24, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str25, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str26, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str27, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str28, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str29, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str30, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str31, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str32, 1, "x");
Clo g_heff_2elsp_2esplit_2ehintOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ehintOf_entry, 2, 0};

V g_heff_2elsp_2esplit_2ehintOf(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_244)}));
      V v_t_246 = (g_list_2eany(v_t_245, v_ps_240));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str0);
      } else {
        heff_drop(v_t_246);
        if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2elsp_2esplit_2ehintOf_str1), 2)) {
          return ((V)&g_heff_2elsp_2esplit_2ehintOf_str2);
        } else {
          V v_t_248 = (g_heff_2elsp_2esplit_2elastPart(heff_dup(v_x_244), MK_INT(0LL), MK_INT(0LL)));
          return (g_heff_2elsp_2esplit_2elowerInitial(v_t_248));
        }
      }
    }
    case TAG_EImplicitVar: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str3);
    }
    case TAG_ETag: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str4);
    }
    case TAG_EInt: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str5);
    }
    case TAG_EFloat: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str6);
    }
    case TAG_EString: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str7);
    }
    case TAG_EBinary: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str8);
    }
    case TAG_ERune: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str9);
    }
    case TAG_EWord: {
      V v_w_2416 = heff_field(v_x21_242, 0);
      switch (heff_tag_of(v_w_2416)) {
      case TAG_TypeWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str10);
      }
      case TAG_IntWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str11);
      }
      case TAG_FloatWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str12);
      }
      case TAG_StringWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str13);
      }
      case TAG_RuneWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str14);
      }
      case TAG_ArrayWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str15);
      }
      case TAG_AbandonWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str16);
      }
      case TAG_FixedWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str17);
      }
      default: return heff_nomatch(v_w_2416);
      }
    }
    case TAG_EApp: {
      V v_f_2418 = heff_field(v_x21_242, 0);
      V t_0 = v_ps_240;
      V t_1 = v_f_2418;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProject: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str18);
    }
    case TAG_ENamed: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str19);
    }
    case TAG_EPi: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str20);
    }
    case TAG_ELam: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str21);
    }
    case TAG_EAnn: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str22);
    }
    case TAG_ESpec: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str23);
    }
    case TAG_ESig: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str24);
    }
    case TAG_ESum: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str25);
    }
    case TAG_EStruct: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str26);
    }
    case TAG_EUpdate: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str27);
    }
    case TAG_EMatch: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str28);
    }
    case TAG_ELetIn: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str29);
    }
    case TAG_EDo: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str30);
    }
    case TAG_ELocal: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str31);
    }
    case TAG_EInvalid: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str32);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2elsp_2esplit_2ehintOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2esplit_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2enumbered_entry, 3, 0};

V g_heff_2elsp_2esplit_2enumbered(V v_taken_240, V v_b_241, V v_i_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(v_b_241), heff_intShow(heff_dup(v_i_242)));
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_243}));
  V v_t_245 = (g_list_2eany(v_t_244, v_taken_240));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V t_0 = v_taken_240;
    V t_1 = v_b_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_b_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    heff_drop(v_t_245);
    return heff_strAppend(v_b_241, heff_intShow(v_i_242));
  }
}
V g_heff_2elsp_2esplit_2enumbered_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2enumbered(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str0, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str1, 1, "z");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str2, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str3, 1, "y");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str4, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str5, 1, "k");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str6, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efresh_str7, 1, "m");
V g_heff_2elsp_2esplit_2efresh_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2efresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efresh_entry, 2, 0};

V g_heff_2elsp_2esplit_2efresh(V v_taken_240, V v_b_241) {
top: ;
  V v_t_246;
  if (heff_strEq_c_lent(v_b_241, ((V)&g_heff_2elsp_2esplit_2efresh_str0), 2)) {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str1), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str3), v_t_243})});
  } else {
    if (heff_strEq_c_lent(v_b_241, ((V)&g_heff_2elsp_2esplit_2efresh_str4), 2)) {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str5), NTAG(TAG_Nil)});
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efresh_str7), v_t_245})});
    } else {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
    }
  }
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2esplit_2efresh_lam0, 1, 1, (V[]){heff_dup(v_taken_240)}); V a_1 = v_t_246; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2esplit_2enumbered(v_taken_240, v_b_241, MK_INT(1LL)));
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    heff_drop(v_b_241);
    return v_x_2411;
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2elsp_2esplit_2efresh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2efresh(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2esplit_2efresh_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_taken_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_247}));
  V v_x1_249 = ({ V a_0 = v_t_248; V a_1 = v_taken_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_taken_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
Clo g_heff_2elsp_2esplit_2efreshNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efreshNames_entry, 2, 0};

V g_heff_2elsp_2esplit_2efreshNames(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_bs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = (g_heff_2elsp_2esplit_2efresh(v_taken_240, v_b_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_244), heff_hole()});
    V v_u_246 = (g_heff_2elsp_2esplit_2efreshNames_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_taken_240}), v_bs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2efreshNames(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2efreshNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efreshNames_24dps_entry, 3, 0};

V g_heff_2elsp_2esplit_2efreshNames_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_bs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = (g_heff_2elsp_2esplit_2efresh(v_taken_240, v_b_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_245), heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_taken_240});
    V t_1 = v_bs_244;
    V t_2 = v_cell_246;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2efreshNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2efreshNames_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2esplit_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ewordsIn_entry, 4, 0};

V g_heff_2elsp_2esplit_2ewordsIn(V v_src_240, V v_i_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_e_242), heff_dup(v_i_241))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_t_245 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_src_240, v_i_241, 0)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2elsp_2esplit_2enameEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
      V v_t_247 = (g_heff_2elsp_2esplit_2enameEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_src_240, v_i_241, v_t_247, 6), v_acc_243});
      V t_0 = v_src_240;
      V t_1 = v_t_246;
      V t_2 = v_e_242;
      V t_3 = v_t_248;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = v_acc_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ewordsIn(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str1, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str2, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str4, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str5, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str7, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str12, 1, " ");
HEFF_LIT(g_heff_2elsp_2esplit_2eapplied_str13, 1, " ");
Clo g_heff_2elsp_2esplit_2eapplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eapplied_entry, 3, 0};

V g_heff_2elsp_2esplit_2eapplied(V v_x1_240, V v_t_241, V v_xs_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_245;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2elsp_2esplit_2eapplied_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_xs_242, 0);
      V v_xs_244 = heff_field(v_xs_242, 1);
      v_t_245 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2elsp_2esplit_2eapplied_str1), heff_dup(v_x_243), v_xs_244));
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str2), v_t_245));
  }
  case TAG_Just: {
    V v_op_246 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      V v_t_249;
      switch (heff_tag_of(v_xs_242)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2elsp_2esplit_2eapplied_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_xs_242, 0);
        V v_xs_248 = heff_field(v_xs_242, 1);
        v_t_249 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2elsp_2esplit_2eapplied_str4), heff_dup(v_x_247), v_xs_248));
        break;
      }
      default: heff_nomatch(v_xs_242);
      }
      return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str5), v_t_249));
    }
    case TAG_Cons: {
      V v_a_2410 = heff_field(v_xs_242, 0);
      V v_xs2_2411 = heff_field(v_xs_242, 1);
      switch (heff_tag_of(v_xs2_2411)) {
      case TAG_Nil: {
        V v_t_2414;
        switch (heff_tag_of(v_xs_242)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2elsp_2esplit_2eapplied_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_xs_242, 0);
          V v_xs_2413 = heff_field(v_xs_242, 1);
          v_t_2414 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2elsp_2esplit_2eapplied_str7), heff_dup(v_x_2412), v_xs_2413));
          break;
        }
        default: heff_nomatch(v_xs_242);
        }
        return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str8), v_t_2414));
      }
      case TAG_Cons: {
        V v_b_2415 = heff_field(v_xs2_2411, 0);
        V v_xs22_2416 = heff_field(v_xs2_2411, 1);
        switch (heff_tag_of(v_xs22_2416)) {
        case TAG_Nil: {
          heff_drop(v_t_241);
          V v_t_2417 = heff_strAppend(heff_dup(v_op_246), heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str9), heff_dup(v_b_2415)));
          return heff_strAppend(heff_dup(v_a_2410), heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str10), v_t_2417));
        }
        case TAG_Cons: {
          V v_t_2422;
          switch (heff_tag_of(v_xs_242)) {
          case TAG_Nil: {
            v_t_2422 = ((V)&g_heff_2elsp_2esplit_2eapplied_str11);
            break;
          }
          case TAG_Cons: {
            V v_x_2420 = heff_field(v_xs_242, 0);
            V v_xs_2421 = heff_field(v_xs_242, 1);
            v_t_2422 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2elsp_2esplit_2eapplied_str12), heff_dup(v_x_2420), v_xs_2421));
            break;
          }
          default: heff_nomatch(v_xs_242);
          }
          return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2elsp_2esplit_2eapplied_str13), v_t_2422));
        }
        default: return heff_nomatch(v_xs22_2416);
        }
      }
      default: return heff_nomatch(v_xs2_2411);
      }
    }
    default: return heff_nomatch(v_xs_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2eapplied_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2esplit_2eapplied(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str0, 1, "(");
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str1, 1, ")");
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str2, 1, "(");
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str3, 1, ")");
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str4, 1, "(");
HEFF_LIT(g_heff_2elsp_2esplit_2etagPatterns_str5, 1, ")");
V g_heff_2elsp_2esplit_2etagPatterns_lam1(V self, V *args);
V g_heff_2elsp_2esplit_2etagPatterns_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2etagPatterns_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2etagPatterns_entry, 6, 0};

V g_heff_2elsp_2esplit_2etagPatterns(V v_ops_240, V v_src_241, V v_s_242, V v_taken_243, V v_ps_244, V v_tags_245) {
top: ;
  return (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2etagPatterns_lam0, 1, 5, (V[]){heff_dup(v_ops_240), heff_dup(v_ps_244), v_taken_243, v_s_242, v_src_241}), v_tags_245));
}
V g_heff_2elsp_2esplit_2etagPatterns_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2elsp_2esplit_2etagPatterns(a0, a[1], a[2], a[3], a4, a[5]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2elsp_2esplit_2etagPatterns_lam1(V self, V *args) {
  V v_a_249 = args[0];
  V v_ps_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_ps_244; V a_1 = v_a_249; V r_ = (g_heff_2elsp_2esplit_2ehintOf(a_0, a_1)); heff_drop(v_ps_244); heff_drop(v_a_249); r_; });
}
V g_heff_2elsp_2esplit_2etagPatterns_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_ops_240 = heff_env(self)[0];
  V v_ps_244 = heff_env(self)[1];
  V v_taken_243 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_src_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_op_247 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = heff_dup(heff_rfield(v_t_246, 0)); V a_2 = v_ops_240; V r_ = (g_list_2elookupBy(a_0, a_1, a_2)); heff_drop(v_ops_240); r_; });
  V v_t_248 = heff_take_field(v_t_246, 0);
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2etagPatterns_lam1, 1, 1, (V[]){v_ps_244}), heff_get_n(v_t_246, 1, 2)));
  V v_xs_2411 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_243, v_t_2410));
  switch (heff_tag_of(v_xs_2411)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_src_241);
    heff_drop(v_op_247);
    return v_t_248;
  }
  case TAG_Cons: {
    V v_p_2414 = ({ V a_0 = v_op_247; V a_1 = v_t_248; V a_2 = v_xs_2411; V r_ = (g_heff_2elsp_2esplit_2eapplied(a_0, a_1, a_2)); heff_drop(v_op_247); heff_drop_tag(v_xs_2411, 2); r_; });
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_s_242, 1)), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_t_2415)) {
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_242, 1)), 0, 2);
      V v_t_2418 = heff_strByteAt(heff_dup(v_src_241), heff_intSub(v_t_2417, MK_INT(1LL)));
      if (heff_intEq_c(v_t_2418, MK_INT(40LL))) {
        V v_t_2420 = heff_get_n(heff_get_n(v_s_242, 1, 5), 1, 2);
        if (heff_intEq_c(heff_strByteAt(v_src_241, v_t_2420), MK_INT(41LL))) {
          return v_p_2414;
        } else {
          return heff_strAppend(((V)&g_heff_2elsp_2esplit_2etagPatterns_str0), heff_strAppend(v_p_2414, ((V)&g_heff_2elsp_2esplit_2etagPatterns_str1)));
        }
      } else {
        heff_drop_rec(v_s_242, 5);
        heff_drop(v_src_241);
        return heff_strAppend(((V)&g_heff_2elsp_2esplit_2etagPatterns_str2), heff_strAppend(v_p_2414, ((V)&g_heff_2elsp_2esplit_2etagPatterns_str3)));
      }
    } else {
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_src_241);
      return heff_strAppend(((V)&g_heff_2elsp_2esplit_2etagPatterns_str4), heff_strAppend(v_p_2414, ((V)&g_heff_2elsp_2esplit_2etagPatterns_str5)));
    }
  }
  default: return heff_nomatch(v_xs_2411);
  }
}
HEFF_LIT(g_heff_2elsp_2esplit_2epatternsOf_str0, 3, " = ");
HEFF_LIT(g_heff_2elsp_2esplit_2epatternsOf_str1, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2epatternsOf_str2, 2, ", ");
HEFF_LIT(g_heff_2elsp_2esplit_2epatternsOf_str3, 2, "{ ");
HEFF_LIT(g_heff_2elsp_2esplit_2epatternsOf_str4, 2, " }");
Clo g_heff_2elsp_2esplit_2epatternsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2epatternsOf_entry, 5, 0};

V g_heff_2elsp_2esplit_2epatternsOf(V v_program_240, V v_c_241, V v_s_242, V v_taken_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_ByTags: {
    V v_ps_245 = heff_field(v_x5_244, 0);
    V v_tags_246 = heff_field(v_x5_244, 1);
    V v_t_247 = (g_heff_2elsp_2esplit_2eoperators(v_program_240, heff_dup(v_c_241)));
    return ({ V a_0 = v_t_247; V a_1 = heff_get_n(v_c_241, 3, 13); V a_2 = v_s_242; V a_3 = v_taken_243; V a_4 = v_ps_245; V a_5 = heff_dup(v_tags_246); V r_ = (g_heff_2elsp_2esplit_2etagPatterns(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
  }
  case TAG_ByFields: {
    V v_fs_248 = heff_field(v_x5_244, 0);
    heff_drop(v_program_240);
    heff_drop_rec(v_c_241, 13);
    heff_drop(v_s_242);
    V v_xs_249 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_243, heff_dup(v_fs_248)));
    V v_x2_2410 = (g_list_2ezipWith_24s1149721393x617397893(((V)&g_heff_2elsp_2esplit_2epatternsOf_str0), heff_dup(v_fs_248), v_xs_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2elsp_2esplit_2epatternsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2elsp_2esplit_2epatternsOf_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2elsp_2esplit_2epatternsOf_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2esplit_2epatternsOf_str4)));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2esplit_2epatternsOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2elsp_2esplit_2epatternsOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2esplit_str0, 12, "` into cases");
HEFF_LIT(g_heff_2elsp_2esplit_2esplit_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2esplit_2esplit_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2esplit_str3, 7, "Split `");
Clo g_heff_2elsp_2esplit_2esplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2esplit_entry, 4, 0};

V g_heff_2elsp_2esplit_2esplit(V v_program_240, V v_c_241, V v_s_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2elsp_2esplit_2etypeHead(v_ty_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    heff_drop_rec(v_c_241, 13);
    heff_drop_rec(v_s_242, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_h_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = (g_heff_2elsp_2esplit_2emadeBy(heff_dup(v_program_240), heff_dup(v_c_241), v_h_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_program_240);
      heff_drop_rec(v_c_241, 13);
      heff_drop_rec(v_s_242, 5);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), ((V)&g_heff_2elsp_2esplit_2esplit_str0));
      V v_t_249 = (g_heff_2elsp_2esplit_2elineStart(heff_dup(heff_rfield(v_c_241, 3)), heff_dup(heff_rfield(v_s_242, 2))));
      V v_t_2410 = heff_strSlice(heff_dup(heff_rfield(v_c_241, 3)), v_t_249, heff_dup(heff_rfield(v_s_242, 2)));
      V v_sep_2411 = heff_strAppend(((V)&g_heff_2elsp_2esplit_2esplit_str1), v_t_2410);
      V v_t_2412 = (g_heff_2elsp_2esplit_2ewordsIn(heff_dup(heff_rfield(v_c_241, 3)), heff_dup(heff_rfield(v_s_242, 2)), heff_dup(heff_rfield(v_s_242, 4)), NTAG(TAG_Nil)));
      V v_t_2413 = ({ V a_0 = v_program_240; V a_1 = heff_dup(v_c_241); V a_2 = heff_dup(v_s_242); V a_3 = v_t_2412; V a_4 = v_m_247; V r_ = (g_heff_2elsp_2esplit_2epatternsOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_m_247); r_; });
      V v_x2_2414 = (g_list_2emap_24s1943354043x700174004(v_c_241, heff_dup(v_s_242), v_t_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        heff_drop(v_sep_2411);
        v_t_2417 = ((V)&g_heff_2elsp_2esplit_2esplit_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = v_sep_2411; V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_t_2418 = heff_rec_n(4, shape_title__start__end__text, (V[]){heff_strAppend(((V)&g_heff_2elsp_2esplit_2esplit_str3), v_t_248), heff_take_field(v_s_242, 2), heff_get_n(v_s_242, 4, 5), v_t_2417});
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2418});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2esplit_2esplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2esplit(a[0], a[1], a[2], a[3]);
}