// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IntWord 51777
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define LBL_cmt 308164
#define LBL_decls 296817955
#define LBL_end 310101
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
V g_heff_2elsp_2esplit_2ealiasedTag(V, V);
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ealiasedTag_clo;
V g_heff_2elsp_2esplit_2earrowOutside(V, V, V);
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2earrowOutside_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS(V);
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps(V, V);
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_24dps_clo;
V g_heff_2elsp_2esplit_2edeclsOf(V);
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2edeclsOf_clo;
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2elsp_2esplit_2eexprName_24tok1(V, V);
V g_heff_2elsp_2esplit_2eexprName_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_24tok1_clo;
V g_heff_2elsp_2esplit_2eextentEnd(V, V, V);
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eextentEnd_clo;
V g_heff_2elsp_2esplit_2efirstJust(V);
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efirstJust_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
V g_heff_2elsp_2esplit_2efreshNames(V, V);
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_clo;
V g_heff_2elsp_2esplit_2efreshNames_24dps(V, V, V);
V g_heff_2elsp_2esplit_2efreshNames_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_24dps_clo;
V g_heff_2elsp_2esplit_2ehintOf(V, V);
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehintOf_clo;
V g_heff_2elsp_2esplit_2eindentEnd(V, V);
V g_heff_2elsp_2esplit_2eindentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eindentEnd_clo;
V g_heff_2elsp_2esplit_2eisOperator(V);
V g_heff_2elsp_2esplit_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eisOperator_clo;
V g_heff_2elsp_2esplit_2elastPart(V, V, V);
V g_heff_2elsp_2esplit_2elastPart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elastPart_clo;
V g_heff_2elsp_2esplit_2elineStart(V, V);
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elineStart_clo;
V g_heff_2elsp_2esplit_2enameEnd(V, V);
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enameEnd_clo;
HeffT2 g_heff_2elsp_2esplit_2enextContent_24cpr(V, V);
V g_heff_2elsp_2esplit_2enumbered(V, V, V);
V g_heff_2elsp_2esplit_2enumbered_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enumbered_clo;
V g_heff_2elsp_2esplit_2evarIn(V, V);
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2evarIn_clo;
HeffT2 g_heff_2elsp_2esplit_2evarIn_24cpr(V, V);
V g_heff_2elsp_2esplit_2ewordsIn(V, V, V, V);
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ewordsIn_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s695184589x587274465(V, V, V);
V g_list_2eany_24s695184589x587274465_entry(V self, V *a);
extern Clo g_list_2eany_24s695184589x587274465_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1372232877x278600396(V);
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_clo;
V g_list_2emap_24s499193121x1224230698(V);
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;

HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_243)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2elsp_2esplit_2efirstJust_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efirstJust_entry, 1, 0};

V g_heff_2elsp_2esplit_2efirstJust(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2elsp_2esplit_2efirstJust_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2efirstJust(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ecatMaybesS_entry, 1, 0};

V g_heff_2elsp_2esplit_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2esplit_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ecatMaybesS(a[0]);
}
Clo g_heff_2elsp_2esplit_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2elsp_2esplit_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2ecatMaybesS_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2esplit_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2enameEnd_entry, 2, 0};

V g_heff_2elsp_2esplit_2enameEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0)) && ({ V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0); int c_ = (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)47ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))))))) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL))); heff_drop(v_c_242); c_; }))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2edeclsOf_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2esplit_2edeclsOf_str1, 0, "");
Clo g_heff_2elsp_2esplit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2edeclsOf_entry, 1, 0};

V g_heff_2elsp_2esplit_2edeclsOf(V v_c_240) {
top: ;
  V v_decls_241 = heff_take_field(v_c_240, 4);
  V v_fixities_242 = heff_take_field(v_c_240, 11);
  V v_source_243 = heff_get_n(v_c_240, 3, 14);
  switch (heff_tag_of(v_decls_241)) {
  case TAG_Nil: {
    V v_o_244 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), v_fixities_242, NTAG(TAG_True), ((V)&g_heff_2elsp_2esplit_2edeclsOf_str0), ((V)&g_heff_2elsp_2esplit_2edeclsOf_str1)});
    V v_t_245 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_source_243, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_src_246 = heff_get_n(v_t_245, 3, 4);
    V v_t_247 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_t_248 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_246), v_t_247, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_249 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_246, v_o_244, v_t_248));
    return heff_get_n(v_t_249, 0, 5);
  }
  case TAG_Cons: {
    heff_drop(v_fixities_242);
    heff_drop(v_source_243);
    return v_decls_241;
  }
  default: return heff_nomatch(v_decls_241);
  }
}
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2edeclsOf(a[0]);
}
Clo g_heff_2elsp_2esplit_2elineStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2elineStart_entry, 2, 0};

V g_heff_2elsp_2esplit_2elineStart(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(v_i_241, MK_INT(0LL), 2)) {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  } else {
    V v_t_242 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_242) == ((int64_t)10ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2elineStart(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2eindentEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eindentEnd_entry, 2, 0};

V g_heff_2elsp_2esplit_2eindentEnd(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_src_240, 0))) {
    V v_c_242 = heff_strByteAt_lent(v_src_240, v_i_241, 0);
    if (((heff_peek_word(v_c_242) == ((int64_t)32ULL)) || (heff_peek_word(v_c_242) == ((int64_t)9ULL)))) {
      heff_drop(v_c_242);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2esplit_2eindentEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2eindentEnd(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2elsp_2esplit_2enextContent_24cpr(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2elsp_2esplit_2eindentEnd(v_src_240, heff_dup(v_i_241)));
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), v_x_242)) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_243 = (g_heff_2elsp_2esplit_2eindentEnd(v_src_240, heff_dup(v_i_241)));
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_t_243, 2)) == ((int64_t)10ULL))) {
      V v_t_244 = (g_heff_2elsp_2esplit_2eindentEnd(v_src_240, v_i_241));
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    }
  }
}
HEFF_LIT(g_heff_2elsp_2esplit_2eextentEnd_str0, 1, "\012");
Clo g_heff_2elsp_2esplit_2eextentEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eextentEnd_entry, 3, 0};

V g_heff_2elsp_2esplit_2eextentEnd(V v_src_240, V v_col_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2elsp_2esplit_2enextContent_24cpr(v_src_240, heff_intAdd(heff_dup(v_i_242), MK_INT(1LL))));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_s_246 = v_field_245;
      V v_t_247 = (g_heff_2elsp_2esplit_2eindentEnd(v_src_240, heff_dup(v_s_246)));
      V v_x_248 = heff_intSub(v_t_247, heff_dup(v_s_246));
      if (heff_intLt_c_lent(v_col_241, v_x_248, 2)) {
        heff_drop(v_i_242);
        V v_d_249 = heff_strLength_lent(v_src_240, 0);
        V v_j_2410 = heff_strFind_lent(((V)&g_heff_2elsp_2esplit_2eextentEnd_str0), v_src_240, v_s_246, 5);
        V v_t_2411;
        if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
          heff_drop(v_j_2410);
          v_t_2411 = v_d_249;
        } else {
          heff_drop(v_d_249);
          v_t_2411 = v_j_2410;
        }
        V t_0 = v_src_240;
        V t_1 = v_col_241;
        V t_2 = v_t_2411;
        v_src_240 = t_0;
        v_col_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        heff_drop(v_col_241);
        heff_drop(v_s_246);
        return v_i_242;
      }
    } else {
      heff_drop(v_col_241);
      heff_drop(v_field_245);
      return v_i_242;
    }
  }
}
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2eextentEnd(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam0(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam1(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam2(V self, V *args);
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2elsp_2esplit_2evarIn_24cpr(V v_off_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      if ((heff_intLe_c(heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(v_off_240)) && heff_intLe_c(heff_dup(v_off_240), heff_dup(heff_rfield(v_sp_243, 1))))) {
        heff_drop(v_off_240);
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_244, 0)))) {
          V v_c_245 = heff_strByteAt_lent(v_x_244, MK_INT(0LL), 2);
          if ((((((int64_t)97ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)122ULL))) || ((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL))))) {
            heff_drop(v_c_245);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_name__span, (V[]){heff_dup(v_x_244), heff_dup(v_sp_243)})}});
          } else {
            heff_drop(v_c_245);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_off_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x21_242, 2);
      V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_24cpr_lam0, 1, 1, (V[]){v_off_240}), heff_dup(v_ps_248)));
      return ({ V a_0 = v_t_2410; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2410); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x21_242, 2);
      V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_24cpr_lam1, 1, 1, (V[]){v_off_240}), heff_dup(v_ps_2413)));
      return ({ V a_0 = v_t_2415; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2415); r_; });
    }
    case TAG_PatInt: {
      heff_drop(v_off_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_PatFloat: {
      heff_drop(v_off_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_PatString: {
      heff_drop(v_off_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_PatBinary: {
      V v_segs_2419 = heff_field(v_x21_242, 0);
      V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_24cpr_lam2, 1, 1, (V[]){v_off_240}), heff_dup(v_segs_2419)));
      return ({ V a_0 = v_t_2428; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2428); r_; });
    }
    case TAG_PatRune: {
      heff_drop(v_off_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_PatRecord: {
      V v_fs_2430 = heff_field(v_x21_242, 0);
      V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2esplit_2evarIn_24cpr_lam3, 1, 1, (V[]){v_off_240}), heff_dup(v_fs_2430)));
      return ({ V a_0 = v_t_2435; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2435); r_; });
    }
    case TAG_PatWord: {
      heff_drop(v_off_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_PatAs: {
      V v_p_2439 = heff_field(v_x21_242, 2);
      V t_0 = v_off_240;
      V t_1 = v_p_2439;
      v_off_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_240; V a_1 = v_p_249; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_249); r_; });
}
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_240; V a_1 = v_p_2414; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2414); r_; });
}
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2420)) {
  case TAG_At: {
    V v_it1_2421 = heff_field(v_m_2420, 0);
    heff_take_n(v_m_2420, 1ULL, 2);
    switch (heff_tag_of(v_it1_2421)) {
    case TAG_MkSegment: {
      V v_v_2423 = heff_field(v_it1_2421, 0);
      heff_take_n(v_it1_2421, 1ULL, 5);
      return ({ V a_0 = v_off_240; V a_1 = v_v_2423; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_v_2423); r_; });
    }
    default: return heff_nomatch(v_it1_2421);
    }
  }
  default: return heff_nomatch(v_m_2420);
  }
}
V g_heff_2elsp_2esplit_2evarIn_24cpr_lam3(V self, V *args) {
  V v_f_2431 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434;
  switch (heff_tag_of(v_f_2431)) {
  case TAG_MkFieldPat: {
    V v_p_2433 = heff_field(v_f_2431, 1);
    heff_take_n(v_f_2431, 2ULL, 2);
    v_t_2434 = v_p_2433;
    break;
  }
  default: heff_nomatch(v_f_2431);
  }
  return ({ V a_0 = v_off_240; V a_1 = v_t_2434; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_t_2434); r_; });
}
Clo g_heff_2elsp_2esplit_2evarIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2evarIn_entry, 2, 0};

V g_heff_2elsp_2esplit_2evarIn(V v_off_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2elsp_2esplit_2evarIn_24cpr(v_off_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2esplit_2evarIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2esplit_2earrowOutside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2earrowOutside_entry, 3, 0};

V g_heff_2elsp_2esplit_2earrowOutside(V v_s_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
    heff_drop(v_i_241);
    heff_drop(v_d_242);
    return NTAG(TAG_False);
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)40ULL)) || ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)91ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)123ULL))))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_d_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)41ULL)) || ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)93ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)125ULL))))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = heff_intSub(v_d_242, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        if ((heff_intEq_c_lent(v_d_242, MK_INT(0LL), 2) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)62ULL))))) {
          heff_drop(v_i_241);
          heff_drop(v_d_242);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_d_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_d_242 = t_2;
          goto top;
        }
      }
    }
  }
}
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2earrowOutside(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2eexprName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eexprName_entry, 1, 0};

V g_heff_2elsp_2esplit_2eexprName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      V v_x_248 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_248)});
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAssign: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWhile: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFor: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EReturn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENest: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELazy: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETuple: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETry: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWith: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2eexprName(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2ealiasedTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ealiasedTag_entry, 2, 0};

V g_heff_2elsp_2esplit_2ealiasedTag(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EImplicitVar: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENotationVar: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      V v_f_2416 = heff_field(v_x21_242, 0);
      V v_args_2417 = heff_field(v_x21_242, 1);
      V v_x1_2418 = (g_list_2emap_24s499193121x1224230698(v_ps_240));
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_Nil: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_x12_2420 = heff_field(v_x1_2418, 1);
        heff_take_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Nothing: {
          heff_drop(v_x12_2420);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_a_2421 = heff_field(v_x11_2419, 0);
          V v_ru_24x11_2419_24Just = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
          switch (heff_tag_of(v_x12_2420)) {
          case TAG_Nil: {
            heff_drop(v_a_2421);
            heff_drop_cell(v_ru_24x11_2419_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Cons: {
            V v_x121_2422 = heff_field(v_x12_2420, 0);
            V v_x122_2423 = heff_field(v_x12_2420, 1);
            heff_take_n(v_x12_2420, 3ULL, 2);
            switch (heff_tag_of(v_x121_2422)) {
            case TAG_Nothing: {
              heff_drop(v_a_2421);
              heff_drop_cell(v_ru_24x11_2419_24Just, 1);
              heff_drop(v_x122_2423);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_b_2424 = heff_field(v_x121_2422, 0);
              heff_take_n(v_x121_2422, 1ULL, 1);
              switch (heff_tag_of(v_x122_2423)) {
              case TAG_Nil: {
                V v_a_2425 = v_a_2421;
                V v_b_2426 = v_b_2424;
                V v_x1_2427 = (g_list_2emap_24s1372232877x278600396(heff_dup(v_args_2417)));
                switch (heff_tag_of(v_x1_2427)) {
                case TAG_Nil: {
                  heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                  heff_drop(v_a_2425);
                  heff_drop(v_b_2426);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Cons: {
                  V v_x11_2428 = heff_field(v_x1_2427, 0);
                  V v_x12_2429 = heff_field(v_x1_2427, 1);
                  heff_take_n(v_x1_2427, 3ULL, 2);
                  switch (heff_tag_of(v_x11_2428)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                    heff_drop(v_a_2425);
                    heff_drop(v_b_2426);
                    heff_drop(v_x12_2429);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_a_2430 = heff_field(v_x11_2428, 0);
                    heff_take_n(v_x11_2428, 1ULL, 1);
                    switch (heff_tag_of(v_x12_2429)) {
                    case TAG_Nil: {
                      heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                      heff_drop(v_a_2425);
                      heff_drop(v_b_2426);
                      heff_drop(v_a_2430);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Cons: {
                      V v_x121_2431 = heff_field(v_x12_2429, 0);
                      V v_x122_2432 = heff_field(v_x12_2429, 1);
                      heff_take_n(v_x12_2429, 3ULL, 2);
                      switch (heff_tag_of(v_x121_2431)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                        heff_drop(v_a_2425);
                        heff_drop(v_b_2426);
                        heff_drop(v_a_2430);
                        heff_drop(v_x122_2432);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_b_2433 = heff_field(v_x121_2431, 0);
                        heff_take_n(v_x121_2431, 1ULL, 1);
                        switch (heff_tag_of(v_x122_2432)) {
                        case TAG_Nil: {
                          if ((heff_strEq_c_lent(v_a_2425, v_a_2430, 0) && heff_strEq_c_lent(v_b_2426, v_b_2433, 0))) {
                            heff_drop(v_a_2425);
                            heff_drop(v_b_2426);
                            heff_drop(v_a_2430);
                            heff_drop(v_b_2433);
                            HEFF_LAST return g_heff_2elsp_2esplit_2eexprName_24tok1(v_ru_24x11_2419_24Just, v_f_2416);
                          } else {
                            heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                            heff_drop(v_a_2425);
                            heff_drop(v_b_2426);
                            heff_drop(v_a_2430);
                            heff_drop(v_b_2433);
                            return NTAG(TAG_Nothing);
                          }
                        }
                        case TAG_Cons: {
                          heff_take_n(v_x122_2432, 0ULL, 2);
                          heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                          heff_drop(v_a_2425);
                          heff_drop(v_b_2426);
                          heff_drop(v_a_2430);
                          heff_drop(v_b_2433);
                          return NTAG(TAG_Nothing);
                        }
                        default: return heff_nomatch(v_x122_2432);
                        }
                      }
                      default: return heff_nomatch(v_x121_2431);
                      }
                    }
                    default: return heff_nomatch(v_x12_2429);
                    }
                  }
                  default: return heff_nomatch(v_x11_2428);
                  }
                }
                default: return heff_nomatch(v_x1_2427);
                }
              }
              case TAG_Cons: {
                heff_take_n(v_x122_2423, 0ULL, 2);
                heff_drop(v_a_2421);
                heff_drop_cell(v_ru_24x11_2419_24Just, 1);
                heff_drop(v_b_2424);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_x122_2423);
              }
            }
            default: return heff_nomatch(v_x121_2422);
            }
          }
          default: return heff_nomatch(v_x12_2420);
          }
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    case TAG_EProject: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAssign: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWhile: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFor: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EIfThen: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBreak: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EContinue: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EReturn: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENest: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELazy: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETuple: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETry: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWith: {
      heff_drop(v_ps_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2esplit_2ealiasedTag(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2esplit_2eisOperator_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eisOperator_entry, 1, 0};

V g_heff_2elsp_2esplit_2eisOperator(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    V v_c_241 = heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2);
    V v_ret_24bool = heff_bool(((heff_peek_word(v_c_241) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_241) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_241) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_241)) && (heff_peek_word(v_c_241) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_241)) && (heff_peek_word(v_c_241) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_241)) ? !(heff_peek_word(v_c_241) <= ((int64_t)57ULL)) : 1)))))));
    heff_drop(v_c_241);
    return v_ret_24bool;
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2esplit_2eisOperator_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2eisOperator(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2elastPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2elastPart_entry, 3, 0};

V g_heff_2elsp_2esplit_2elastPart(V v_x_240, V v_box_24i_241, V v_from_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return heff_strSlice(heff_dup(v_x_240), v_from_242, heff_strLength_lent(v_x_240, 0));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      heff_drop(v_from_242);
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_box_word((v_i_241 + ((int64_t)1ULL)));
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_from_242 = t_2;
      goto top;
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_from_242;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_from_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2elastPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2elastPart(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str0, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str1, 4, "List");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str2, 2, "xs");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str3, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str4, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str5, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str6, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str7, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str8, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str9, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str10, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str11, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str12, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str13, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str14, 1, "s");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str15, 1, "c");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str16, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str17, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str18, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str19, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str20, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str21, 1, "f");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str22, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str23, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str24, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str25, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str26, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str27, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str28, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str29, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str30, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str31, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str32, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str33, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str34, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str35, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str36, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str37, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str38, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str39, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str40, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str41, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str42, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str43, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str44, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2ehintOf_str45, 1, "x");
Clo g_heff_2elsp_2esplit_2ehintOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ehintOf_entry, 2, 0};

V g_heff_2elsp_2esplit_2ehintOf(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_x_244, v_ps_240));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str0);
      } else {
        heff_drop(v_t_245);
        if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2elsp_2esplit_2ehintOf_str1), 2)) {
          return ((V)&g_heff_2elsp_2esplit_2ehintOf_str2);
        } else {
          V v_x_246 = (g_heff_2elsp_2esplit_2elastPart(v_x_244, MK_INT(0LL), MK_INT(0LL)));
          if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_246, 0)))) {
            V v_c_247 = heff_strByteAt_lent(v_x_246, MK_INT(0LL), 2);
            if (((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)90ULL)))) {
              heff_drop(v_c_247);
              int64_t v_t_248 = (heff_unbox_word(heff_strByteAt(v_x_246, MK_INT(0LL))) + ((int64_t)32ULL));
              return heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_248))));
            } else {
              heff_drop(v_c_247);
              return heff_strSlice(v_x_246, MK_INT(0LL), MK_INT(1LL));
            }
          } else {
            return heff_strSlice(v_x_246, MK_INT(0LL), MK_INT(1LL));
          }
        }
      }
    }
    case TAG_EImplicitVar: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str3);
    }
    case TAG_ENotationVar: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str4);
    }
    case TAG_ETag: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str5);
    }
    case TAG_EInt: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str6);
    }
    case TAG_EFloat: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str7);
    }
    case TAG_EString: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str8);
    }
    case TAG_EBinary: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str9);
    }
    case TAG_ERune: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str10);
    }
    case TAG_EWord: {
      V v_w_2419 = heff_field(v_x21_242, 0);
      switch (heff_tag_of(v_w_2419)) {
      case TAG_TypeWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str11);
      }
      case TAG_IntWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str12);
      }
      case TAG_FloatWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str13);
      }
      case TAG_StringWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str14);
      }
      case TAG_RuneWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str15);
      }
      case TAG_ArrayWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str16);
      }
      case TAG_AbandonWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str17);
      }
      case TAG_FixedWord: {
        return ((V)&g_heff_2elsp_2esplit_2ehintOf_str18);
      }
      default: return heff_nomatch(v_w_2419);
      }
    }
    case TAG_EApp: {
      V v_f_2421 = heff_field(v_x21_242, 0);
      V t_0 = v_ps_240;
      V t_1 = v_f_2421;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProject: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str19);
    }
    case TAG_ENamed: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str20);
    }
    case TAG_EPi: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str21);
    }
    case TAG_ELam: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str22);
    }
    case TAG_EAnn: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str23);
    }
    case TAG_ESpec: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str24);
    }
    case TAG_ESig: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str25);
    }
    case TAG_ESum: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str26);
    }
    case TAG_EStruct: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str27);
    }
    case TAG_EUpdate: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str28);
    }
    case TAG_EMatch: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str29);
    }
    case TAG_ELetIn: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str30);
    }
    case TAG_EDo: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str31);
    }
    case TAG_ELocal: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str32);
    }
    case TAG_EInvalid: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str33);
    }
    case TAG_EAssign: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str34);
    }
    case TAG_EWhile: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str35);
    }
    case TAG_EFor: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str36);
    }
    case TAG_EIfThen: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str37);
    }
    case TAG_EBreak: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str38);
    }
    case TAG_EContinue: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str39);
    }
    case TAG_EReturn: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str40);
    }
    case TAG_ENest: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str41);
    }
    case TAG_ELazy: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str42);
    }
    case TAG_ETuple: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str43);
    }
    case TAG_ETry: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str44);
    }
    case TAG_EWith: {
      return ((V)&g_heff_2elsp_2esplit_2ehintOf_str45);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2elsp_2esplit_2ehintOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2esplit_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2enumbered_entry, 3, 0};

V g_heff_2elsp_2esplit_2enumbered(V v_taken_240, V v_b_241, V v_i_242) {
top: ;
  V v_t_243 = (g_list_2eany_24s695184589x587274465(heff_dup(v_b_241), heff_dup(v_i_242), v_taken_240));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V t_0 = v_taken_240;
    V t_1 = v_b_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_b_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    heff_drop(v_t_243);
    return heff_strAppend(v_b_241, heff_intShow(v_i_242));
  }
}
V g_heff_2elsp_2esplit_2enumbered_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2enumbered(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str0, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str1, 1, "z");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str2, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str3, 1, "y");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str4, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str5, 1, "k");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str6, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_str7, 1, "m");
V g_heff_2elsp_2esplit_2efreshNames_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2efreshNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efreshNames_entry, 2, 0};

V g_heff_2elsp_2esplit_2efreshNames(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_bs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_taken_244 = heff_dup(v_taken_240);
    V v_b_245 = v_b_242;
    V v_t_248;
    if (heff_strEq_c_lent(v_b_245, ((V)&g_heff_2elsp_2esplit_2efreshNames_str0), 2)) {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str1), NTAG(TAG_Nil)});
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str3), v_t_246})});
    } else {
      if (heff_strEq_c_lent(v_b_245, ((V)&g_heff_2elsp_2esplit_2efreshNames_str4), 2)) {
        V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str5), NTAG(TAG_Nil)});
        v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_str7), v_t_247})});
      } else {
        v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_245), NTAG(TAG_Nil)});
      }
    }
    HeffT2 v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2esplit_2efreshNames_lam0, 1, 1, (V[]){heff_dup(v_taken_244)}); V a_1 = v_t_248; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_x_2415;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop(v_taken_244);
        heff_drop(v_b_245);
        V v_x_2414 = v_field_2413;
        v_x_2415 = v_x_2414;
      } else {
        heff_drop(v_field_2413);
        v_x_2415 = ({ V a_0 = v_taken_244; V a_1 = v_b_245; V a_2 = MK_INT(1LL); V r_ = (g_heff_2elsp_2esplit_2enumbered(a_0, a_1, a_2)); heff_drop(v_taken_244); r_; });
      }
    }
    V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2415), heff_hole()});
    V v_u_2417 = (g_heff_2elsp_2esplit_2efreshNames_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_taken_240}), v_bs_243, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2efreshNames(a[0], a[1]);
}
V g_heff_2elsp_2esplit_2efreshNames_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_taken_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_x_249; V a_1 = v_taken_244; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_249); heff_drop(v_taken_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str0, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str1, 1, "z");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str2, 1, "x");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str3, 1, "y");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str4, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str5, 1, "k");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str6, 1, "n");
HEFF_LIT(g_heff_2elsp_2esplit_2efreshNames_24dps_str7, 1, "m");
V g_heff_2elsp_2esplit_2efreshNames_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2esplit_2efreshNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2efreshNames_24dps_entry, 3, 0};

V g_heff_2elsp_2esplit_2efreshNames_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_bs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_taken_245 = heff_dup(v_taken_240);
    V v_b_246 = v_b_243;
    V v_t_249;
    if (heff_strEq_c_lent(v_b_246, ((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str0), 2)) {
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str1), NTAG(TAG_Nil)});
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str3), v_t_247})});
    } else {
      if (heff_strEq_c_lent(v_b_246, ((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str4), 2)) {
        V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str5), NTAG(TAG_Nil)});
        v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2esplit_2efreshNames_24dps_str7), v_t_248})});
      } else {
        v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_246), NTAG(TAG_Nil)});
      }
    }
    HeffT2 v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2esplit_2efreshNames_24dps_lam0, 1, 1, (V[]){heff_dup(v_taken_245)}); V a_1 = v_t_249; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_x_2416;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_taken_245);
        heff_drop(v_b_246);
        V v_x_2415 = v_field_2414;
        v_x_2416 = v_x_2415;
      } else {
        heff_drop(v_field_2414);
        v_x_2416 = ({ V a_0 = v_taken_245; V a_1 = v_b_246; V a_2 = MK_INT(1LL); V r_ = (g_heff_2elsp_2esplit_2enumbered(a_0, a_1, a_2)); heff_drop(v_taken_245); r_; });
      }
    }
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2416), heff_hole()});
    V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_taken_240});
    V t_1 = v_bs_244;
    V t_2 = v_cell_2417;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2esplit_2efreshNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esplit_2efreshNames_24dps(a[0], a[1], a[2]);
}
V g_heff_2elsp_2esplit_2efreshNames_24dps_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_taken_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_x_2410; V a_1 = v_taken_245; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_2410); heff_drop(v_taken_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
Clo g_heff_2elsp_2esplit_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2ewordsIn_entry, 4, 0};

V g_heff_2elsp_2esplit_2ewordsIn(V v_src_240, V v_i_241, V v_e_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_e_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_e_242);
    return v_acc_243;
  } else {
    V v_c_244 = heff_strByteAt_lent(v_src_240, v_i_241, 0);
    if (((heff_peek_word(v_c_244) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_244) == ((int64_t)39ULL)) || ((heff_peek_word(v_c_244) == ((int64_t)47ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_244);
      V v_t_245 = (g_heff_2elsp_2esplit_2enameEnd(v_src_240, heff_dup(v_i_241)));
      V v_t_246 = (g_heff_2elsp_2esplit_2enameEnd(v_src_240, heff_dup(v_i_241)));
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_src_240, v_i_241, v_t_246, 6), v_acc_243});
      V t_0 = v_src_240;
      V t_1 = v_t_245;
      V t_2 = v_e_242;
      V t_3 = v_t_247;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_c_244);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = v_acc_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2esplit_2ewordsIn(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2esplit_2eexprName_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esplit_2eexprName_24tok1_entry, 2, 0};

V g_heff_2elsp_2esplit_2eexprName_24tok1(V v_tok_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_dup(v_x_244)});
    }
    case TAG_EImplicitVar: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENotationVar: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      V v_x_249 = heff_field(v_x11_242, 0);
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_dup(v_x_249)});
    }
    case TAG_EInt: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAssign: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWhile: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFor: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EIfThen: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBreak: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EContinue: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EReturn: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENest: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELazy: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETuple: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETry: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EWith: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2esplit_2eexprName_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2esplit_2eexprName_24tok1(a[0], a1); heff_drop(a1); return r;
}