// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_fixed 298804110
#define LBL_js 10160
#define LBL_op 10312
static uint32_t shape_arity__js[] = {LBL_arity, LBL_js};
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2easciiFrom(V, V);
V g_heff_2ecompile_2eprims_2easciiFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2easciiFrom_clo;
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
V g_heff_2ecompile_2eprims_2ebytePrims_get(void);
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2eprims_2efixedJs(V);
V g_heff_2ecompile_2eprims_2efixedJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedJs_clo;
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void);
V g_heff_2ecompile_2eprims_2eintOpJs(V, V);
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eintOpJs_clo;
V g_heff_2ecompile_2eprims_2einternal_get(void);
V g_heff_2ecompile_2eprims_2enarrowJs(V, V);
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2enarrowJs_clo;
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2ecompile_2eprims_2eshiftMaskJs(V);
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo;
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void);
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2efixedPrims_get(void);
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2eprims_2easciiFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2easciiFrom_entry, 2, 0};

V g_heff_2ecompile_2eprims_2easciiFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    if (heff_intLt_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(128LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eprims_2easciiFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eprims_2easciiFrom(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str0, 21, (114, 101, 116, 117, 114, 110, 32, 91, 99, 44, 32, 109, 32, 43, 32, 49, 93, 59, 32, 125, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str1, 78, (102, 111, 114, 32, 40, 108, 101, 116, 32, 107, 32, 61, 32, 49, 59, 32, 107, 32, 60, 61, 32, 109, 59, 32, 107, 43, 43, 41, 32, 123, 32, 99, 111, 110, 115, 116, 32, 100, 32, 61, 32, 105, 32, 43, 32, 107, 32, 60, 32, 110, 32, 63, 32, 115, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 105, 32, 43, 32, 107, 41, 32, 58, 32, 45, 49, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str2, 85, (105, 102, 32, 40, 100, 32, 60, 32, 108, 111, 32, 124, 124, 32, 100, 32, 62, 32, 104, 105, 41, 32, 114, 101, 116, 117, 114, 110, 32, 91, 54, 53, 53, 51, 51, 44, 32, 107, 93, 59, 32, 108, 111, 32, 61, 32, 49, 50, 56, 59, 32, 104, 105, 32, 61, 32, 49, 57, 49, 59, 32, 99, 32, 61, 32, 99, 32, 42, 32, 54, 52, 32, 43, 32, 40, 100, 32, 38, 32, 54, 51, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str3, 107, (101, 108, 115, 101, 32, 105, 102, 32, 40, 98, 32, 62, 61, 32, 50, 52, 48, 32, 38, 38, 32, 98, 32, 60, 61, 32, 50, 52, 52, 41, 32, 123, 32, 109, 32, 61, 32, 51, 59, 32, 99, 32, 61, 32, 98, 32, 38, 32, 55, 59, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 50, 52, 48, 41, 32, 108, 111, 32, 61, 32, 49, 52, 52, 59, 32, 101, 108, 115, 101, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 50, 52, 52, 41, 32, 104, 105, 32, 61, 32, 49, 52, 51, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str4, 23, (101, 108, 115, 101, 32, 114, 101, 116, 117, 114, 110, 32, 91, 54, 53, 53, 51, 51, 44, 32, 49, 93, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str5, 48, (105, 102, 32, 40, 98, 32, 62, 61, 32, 49, 57, 52, 32, 38, 38, 32, 98, 32, 60, 61, 32, 50, 50, 51, 41, 32, 123, 32, 109, 32, 61, 32, 49, 59, 32, 99, 32, 61, 32, 98, 32, 38, 32, 51, 49, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str6, 108, (101, 108, 115, 101, 32, 105, 102, 32, 40, 98, 32, 62, 61, 32, 50, 50, 52, 32, 38, 38, 32, 98, 32, 60, 61, 32, 50, 51, 57, 41, 32, 123, 32, 109, 32, 61, 32, 50, 59, 32, 99, 32, 61, 32, 98, 32, 38, 32, 49, 53, 59, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 50, 50, 52, 41, 32, 108, 111, 32, 61, 32, 49, 54, 48, 59, 32, 101, 108, 115, 101, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 50, 51, 55, 41, 32, 104, 105, 32, 61, 32, 49, 53, 57, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str7, 54, (99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 115, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 105, 41, 59, 32, 105, 102, 32, 40, 98, 32, 60, 32, 49, 50, 56, 41, 32, 114, 101, 116, 117, 114, 110, 32, 91, 98, 44, 32, 49, 93, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str8, 29, (108, 101, 116, 32, 109, 44, 32, 99, 44, 32, 108, 111, 32, 61, 32, 49, 50, 56, 44, 32, 104, 105, 32, 61, 32, 49, 57, 49, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str9, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eutf8AtJs_str10, 75, (40, 40, 115, 44, 32, 105, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 110, 32, 61, 32, 115, 46, 108, 101, 110, 103, 116, 104, 59, 32, 105, 102, 32, 40, 33, 40, 105, 32, 62, 61, 32, 48, 32, 38, 38, 32, 105, 32, 60, 32, 110, 41, 41, 32, 114, 101, 116, 117, 114, 110, 32, 91, 54, 53, 53, 51, 51, 44, 32, 48, 93, 59));

static V g_heff_2ecompile_2eprims_2eutf8AtJs_val;
static int g_heff_2ecompile_2eprims_2eutf8AtJs_st;
static V g_heff_2ecompile_2eprims_2eutf8AtJs_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str9); V a_1 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void) {
  if (g_heff_2ecompile_2eprims_2eutf8AtJs_st == 2) return g_heff_2ecompile_2eprims_2eutf8AtJs_val;
  if (g_heff_2ecompile_2eprims_2eutf8AtJs_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2eutf8AtJs_st = 1;
  g_heff_2ecompile_2eprims_2eutf8AtJs_val = heff_tr(g_heff_2ecompile_2eprims_2eutf8AtJs_init());
  g_heff_2ecompile_2eprims_2eutf8AtJs_st = 2;
  return g_heff_2ecompile_2eprims_2eutf8AtJs_val;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str0, 9, (115, 116, 114, 66, 121, 116, 101, 65, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str1, 85, (40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 41, 32, 58, 32, 45, 49, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str2, 11, (115, 116, 114, 70, 114, 111, 109, 66, 121, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str3, 73, (40, 99, 41, 32, 61, 62, 32, 99, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 99, 32, 60, 61, 32, 50, 53, 53, 110, 32, 63, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101, 40, 78, 117, 109, 98, 101, 114, 40, 99, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str4, 14, (40, 115, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str5, 17, (40, 115, 44, 32, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 91, 48, 93));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str6, 9, (115, 116, 114, 82, 117, 110, 101, 65, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str7, 21, (40, 115, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str8, 18, (40, 115, 44, 32, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 91, 49, 93, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str9, 12, (115, 116, 114, 82, 117, 110, 101, 87, 105, 100, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str10, 20, (40, 115, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 97, 116, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str11, 85, (59, 32, 108, 101, 116, 32, 110, 32, 61, 32, 48, 59, 32, 102, 111, 114, 32, 40, 108, 101, 116, 32, 105, 32, 61, 32, 48, 59, 32, 105, 32, 60, 32, 115, 46, 108, 101, 110, 103, 116, 104, 59, 32, 105, 32, 43, 61, 32, 97, 116, 40, 115, 44, 32, 105, 41, 91, 49, 93, 41, 32, 110, 43, 43, 59, 32, 114, 101, 116, 117, 114, 110, 32, 66, 105, 103, 73, 110, 116, 40, 110, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str12, 12, (115, 116, 114, 82, 117, 110, 101, 67, 111, 117, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str13, 7, (115, 116, 114, 84, 111, 74, 83));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str14, 15, (40, 115, 41, 32, 61, 62, 32, 36, 116, 111, 74, 115, 40, 115, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str15, 9, (115, 116, 114, 70, 114, 111, 109, 74, 83));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebytePrims_str16, 17, (40, 116, 41, 32, 61, 62, 32, 36, 102, 114, 111, 109, 74, 115, 40, 116, 41));

static V g_heff_2ecompile_2eprims_2ebytePrims_val;
static int g_heff_2ecompile_2eprims_2ebytePrims_st;
static V g_heff_2ecompile_2eprims_2ebytePrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str3)})});
  V v_js_242 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str4), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str5)));
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), v_js_242})});
  V v_js_244 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str7), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str8)));
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str9), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), v_js_244})});
  V v_js_246 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str10), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str11)));
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str12), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_js_246})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str13), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str14)})});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str15), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str16)})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_2412})});
}
V g_heff_2ecompile_2eprims_2ebytePrims_get(void) {
  if (g_heff_2ecompile_2eprims_2ebytePrims_st == 2) return g_heff_2ecompile_2eprims_2ebytePrims_val;
  if (g_heff_2ecompile_2eprims_2ebytePrims_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2ebytePrims_st = 1;
  g_heff_2ecompile_2eprims_2ebytePrims_val = heff_tr(g_heff_2ecompile_2eprims_2ebytePrims_init());
  g_heff_2ecompile_2eprims_2ebytePrims_st = 2;
  return g_heff_2ecompile_2eprims_2ebytePrims_val;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str0, 6, (105, 110, 116, 65, 100, 100));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str1, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str2, 6, (105, 110, 116, 83, 117, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str3, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str4, 6, (105, 110, 116, 77, 117, 108));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str5, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str6, 6, (105, 110, 116, 68, 105, 118));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str7, 133, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 113, 32, 61, 32, 97, 32, 47, 32, 98, 44, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 113, 32, 45, 32, 49, 110, 32, 58, 32, 113, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str8, 6, (105, 110, 116, 77, 111, 100));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str9, 121, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 114, 32, 43, 32, 98, 32, 58, 32, 114, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str10, 5, (105, 110, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str11, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str12, 5, (105, 110, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str13, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str14, 5, (105, 110, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str15, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str16, 7, (105, 110, 116, 83, 104, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str17, 19, (40, 97, 41, 32, 61, 62, 32, 97, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str18, 6, (105, 110, 116, 65, 110, 100));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str19, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 38, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str20, 5, (105, 110, 116, 79, 114));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str21, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 124, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str22, 6, (105, 110, 116, 88, 111, 114));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str23, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 94, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str24, 6, (105, 110, 116, 83, 104, 108));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str25, 42, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 98, 32, 60, 32, 48, 110, 32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32, 97, 32, 60, 60, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str26, 6, (105, 110, 116, 83, 104, 114));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str27, 42, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 98, 32, 60, 32, 48, 110, 32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32, 97, 32, 62, 62, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str28, 8, (102, 108, 111, 97, 116, 65, 100, 100));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str29, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str30, 8, (102, 108, 111, 97, 116, 83, 117, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str31, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str32, 8, (102, 108, 111, 97, 116, 77, 117, 108));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str33, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str34, 8, (102, 108, 111, 97, 116, 68, 105, 118));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str35, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 47, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str36, 7, (102, 108, 111, 97, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str37, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str38, 7, (102, 108, 111, 97, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str39, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str40, 7, (102, 108, 111, 97, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str41, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str42, 9, (102, 108, 111, 97, 116, 83, 104, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str43, 70, (40, 97, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 83, 116, 114, 105, 110, 103, 40, 97, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 105, 115, 78, 97, 78, 40, 115, 32, 43, 32, 34, 46, 48, 34, 41, 32, 63, 32, 115, 32, 58, 32, 115, 32, 43, 32, 34, 46, 48, 34, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str44, 12, (102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str45, 16, (40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str46, 9, (102, 108, 111, 97, 116, 83, 113, 114, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str47, 19, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 113, 114, 116, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str48, 10, (102, 108, 111, 97, 116, 70, 108, 111, 111, 114));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str49, 62, (40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 97, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str50, 8, (102, 108, 111, 97, 116, 83, 105, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str51, 18, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 105, 110, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str52, 8, (102, 108, 111, 97, 116, 67, 111, 115));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str53, 18, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 99, 111, 115, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str54, 8, (102, 108, 111, 97, 116, 84, 97, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str55, 18, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 116, 97, 110, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str56, 9, (102, 108, 111, 97, 116, 65, 115, 105, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str57, 19, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 115, 105, 110, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str58, 9, (102, 108, 111, 97, 116, 65, 99, 111, 115));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str59, 19, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 99, 111, 115, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str60, 9, (102, 108, 111, 97, 116, 65, 116, 97, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str61, 19, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str62, 10, (102, 108, 111, 97, 116, 65, 116, 97, 110, 50));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str63, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 50, 40, 97, 44, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str64, 8, (102, 108, 111, 97, 116, 69, 120, 112));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str65, 18, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 101, 120, 112, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str66, 8, (102, 108, 111, 97, 116, 76, 111, 103));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str67, 18, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 108, 111, 103, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str68, 8, (102, 108, 111, 97, 116, 80, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str69, 84, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 49, 32, 124, 124, 32, 40, 97, 32, 61, 61, 61, 32, 45, 49, 32, 38, 38, 32, 77, 97, 116, 104, 46, 97, 98, 115, 40, 98, 41, 32, 61, 61, 61, 32, 73, 110, 102, 105, 110, 105, 116, 121, 41, 32, 63, 32, 49, 32, 58, 32, 77, 97, 116, 104, 46, 112, 111, 119, 40, 97, 44, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str70, 11, (97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str71, 23, (40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str72, 10, (97, 114, 114, 97, 121, 73, 110, 100, 101, 120));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str73, 73, (40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 97, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str74, 8, (97, 114, 114, 97, 121, 83, 101, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str75, 132, (40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 120, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 33, 40, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 41, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 97, 46, 115, 108, 105, 99, 101, 40, 41, 59, 32, 98, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 61, 32, 120, 59, 32, 114, 101, 116, 117, 114, 110, 32, 98, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str76, 13, (97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str77, 89, (40, 110, 41, 32, 61, 62, 32, 40, 102, 41, 32, 61, 62, 32, 65, 114, 114, 97, 121, 46, 102, 114, 111, 109, 40, 123, 32, 108, 101, 110, 103, 116, 104, 58, 32, 110, 32, 62, 32, 48, 110, 32, 63, 32, 78, 117, 109, 98, 101, 114, 40, 110, 41, 32, 58, 32, 48, 32, 125, 44, 32, 40, 95, 44, 32, 107, 41, 32, 61, 62, 32, 36, 116, 114, 40, 102, 40, 66, 105, 103, 73, 110, 116, 40, 107, 41, 41, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str78, 13, (97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str79, 89, (40, 108, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 91, 93, 59, 32, 119, 104, 105, 108, 101, 32, 40, 108, 46, 36, 32, 61, 61, 61, 32, 34, 67, 111, 110, 115, 34, 41, 32, 123, 32, 114, 46, 112, 117, 115, 104, 40, 108, 46, 97, 91, 48, 93, 41, 59, 32, 108, 32, 61, 32, 108, 46, 97, 91, 49, 93, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 114, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str80, 11, (97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str81, 85, (40, 97, 41, 32, 61, 62, 32, 97, 46, 114, 101, 100, 117, 99, 101, 82, 105, 103, 104, 116, 40, 40, 114, 101, 115, 116, 44, 32, 120, 41, 32, 61, 62, 32, 40, 123, 32, 36, 58, 32, 34, 67, 111, 110, 115, 34, 44, 32, 97, 58, 32, 91, 120, 44, 32, 114, 101, 115, 116, 93, 32, 125, 41, 44, 32, 123, 32, 36, 58, 32, 34, 78, 105, 108, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str82, 9, (115, 116, 114, 65, 112, 112, 101, 110, 100));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str83, 19, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str84, 9, (115, 116, 114, 76, 101, 110, 103, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str85, 23, (40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str86, 8, (115, 116, 114, 83, 108, 105, 99, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str87, 50, (40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 106, 41, 32, 61, 62, 32, 97, 46, 115, 108, 105, 99, 101, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 44, 32, 78, 117, 109, 98, 101, 114, 40, 106, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str88, 5, (115, 116, 114, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str89, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str90, 5, (115, 116, 114, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str91, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str92, 11, (115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str93, 85, (40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 41, 32, 58, 32, 45, 49, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str94, 15, (115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str95, 67, (40, 99, 41, 32, 61, 62, 32, 99, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 99, 32, 60, 61, 32, 54, 53, 53, 51, 53, 110, 32, 63, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101, 40, 78, 117, 109, 98, 101, 114, 40, 99, 41, 41, 32, 58, 32, 34, 34));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str96, 6, (114, 117, 110, 101, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str97, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str98, 6, (114, 117, 110, 101, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str99, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str100, 6, (114, 117, 110, 101, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str101, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str102, 9, (114, 117, 110, 101, 84, 111, 73, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str103, 16, (40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str104, 11, (114, 117, 110, 101, 70, 114, 111, 109, 73, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str105, 35, (40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 66, 105, 103, 73, 110, 116, 46, 97, 115, 73, 110, 116, 78, 40, 51, 50, 44, 32, 97, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str106, 8, (115, 116, 114, 82, 117, 110, 101, 115));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str107, 236, (40, 115, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 91, 93, 59, 32, 102, 111, 114, 32, 40, 99, 111, 110, 115, 116, 32, 117, 32, 111, 102, 32, 115, 41, 32, 123, 32, 99, 111, 110, 115, 116, 32, 99, 32, 61, 32, 117, 46, 99, 111, 100, 101, 80, 111, 105, 110, 116, 65, 116, 40, 48, 41, 59, 32, 114, 46, 112, 117, 115, 104, 40, 99, 32, 62, 61, 32, 48, 120, 68, 56, 48, 48, 32, 38, 38, 32, 99, 32, 60, 61, 32, 48, 120, 68, 70, 70, 70, 32, 63, 32, 48, 120, 70, 70, 70, 68, 32, 58, 32, 99, 41, 59, 32, 125, 32, 108, 101, 116, 32, 108, 32, 61, 32, 123, 32, 36, 58, 32, 34, 78, 105, 108, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 59, 32, 102, 111, 114, 32, 40, 108, 101, 116, 32, 105, 32, 61, 32, 114, 46, 108, 101, 110, 103, 116, 104, 32, 45, 32, 49, 59, 32, 105, 32, 62, 61, 32, 48, 59, 32, 105, 45, 45, 41, 32, 108, 32, 61, 32, 123, 32, 36, 58, 32, 34, 67, 111, 110, 115, 34, 44, 32, 97, 58, 32, 91, 114, 91, 105, 93, 44, 32, 108, 93, 32, 125, 59, 32, 114, 101, 116, 117, 114, 110, 32, 108, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str108, 10, (115, 116, 114, 79, 102, 82, 117, 110, 101, 115));
HEFF_STRA(g_heff_2ecompile_2eprims_2ebasicPrims_str109, 205, (40, 108, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 115, 32, 61, 32, 34, 34, 59, 32, 119, 104, 105, 108, 101, 32, 40, 108, 46, 36, 32, 61, 61, 61, 32, 34, 67, 111, 110, 115, 34, 41, 32, 123, 32, 99, 111, 110, 115, 116, 32, 99, 32, 61, 32, 108, 46, 97, 91, 48, 93, 59, 32, 115, 32, 43, 61, 32, 99, 32, 62, 61, 32, 48, 32, 38, 38, 32, 99, 32, 60, 61, 32, 48, 120, 49, 48, 70, 70, 70, 70, 32, 38, 38, 32, 40, 99, 32, 60, 32, 48, 120, 68, 56, 48, 48, 32, 124, 124, 32, 99, 32, 62, 32, 48, 120, 68, 70, 70, 70, 41, 32, 63, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 111, 100, 101, 80, 111, 105, 110, 116, 40, 99, 41, 32, 58, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101, 40, 48, 120, 70, 70, 70, 68, 41, 59, 32, 108, 32, 61, 32, 108, 46, 97, 91, 49, 93, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 115, 59, 32, 125));

static V g_heff_2ecompile_2eprims_2ebasicPrims_val;
static int g_heff_2ecompile_2eprims_2ebasicPrims_st;
static V g_heff_2ecompile_2eprims_2ebasicPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str4), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str8), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str10), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str11)})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str12), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str13)})});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str14), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str15)})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str16), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str17)})});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str18), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str19)})});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str20), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str21)})});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str22), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str23)})});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str24), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str25)})});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str26), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str27)})});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str28), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str29)})});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str30), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str31)})});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str32), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str33)})});
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str34), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str35)})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str36), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str37)})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str38), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str39)})});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str40), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str41)})});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str42), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str43)})});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str44), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str45)})});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str46), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str47)})});
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str48), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str49)})});
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str50), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str51)})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str52), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str53)})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str54), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str55)})});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str56), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str57)})});
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str58), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str59)})});
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str60), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str61)})});
  V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str62), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str63)})});
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str64), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str65)})});
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str66), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str67)})});
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str68), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str69)})});
  V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str70), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str71)})});
  V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str72), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str73)})});
  V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str74), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str75)})});
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str76), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str77)})});
  V v_t_2439 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str78), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str79)})});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str80), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str81)})});
  V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str82), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str83)})});
  V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str84), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str85)})});
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str86), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str87)})});
  V v_t_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str88), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str89)})});
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str90), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str91)})});
  V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str92), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str93)})});
  V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str94), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str95)})});
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str96), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str97)})});
  V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str98), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str99)})});
  V v_t_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str100), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str101)})});
  V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str102), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str103)})});
  V v_t_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str104), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str105)})});
  V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str106), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str107)})});
  V v_t_2454 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str108), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str109)})});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2480})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_2481})});
}
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void) {
  if (g_heff_2ecompile_2eprims_2ebasicPrims_st == 2) return g_heff_2ecompile_2eprims_2ebasicPrims_val;
  if (g_heff_2ecompile_2eprims_2ebasicPrims_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2ebasicPrims_st = 1;
  g_heff_2ecompile_2eprims_2ebasicPrims_val = heff_tr(g_heff_2ecompile_2eprims_2ebasicPrims_init());
  g_heff_2ecompile_2eprims_2ebasicPrims_st = 2;
  return g_heff_2ecompile_2eprims_2ebasicPrims_val;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str1, 13, (41, 32, 60, 60, 32, 50, 52, 32, 62, 62, 32, 50, 52));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str2, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str3, 13, (41, 32, 60, 60, 32, 49, 54, 32, 62, 62, 32, 49, 54));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str4, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str5, 5, (41, 32, 124, 32, 48));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str6, 18, (66, 105, 103, 73, 110, 116, 46, 97, 115, 73, 110, 116, 78, 40, 54, 52, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str7, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str8, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str9, 7, (41, 32, 38, 32, 50, 53, 53));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str10, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str11, 9, (41, 32, 38, 32, 54, 53, 53, 51, 53));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str12, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str13, 7, (41, 32, 62, 62, 62, 32, 48));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str14, 19, (66, 105, 103, 73, 110, 116, 46, 97, 115, 85, 105, 110, 116, 78, 40, 54, 52, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str15, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str16, 12, (77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2enarrowJs_str17, 1, (41));
Clo g_heff_2ecompile_2eprims_2enarrowJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2enarrowJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2enarrowJs(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_I8: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str0), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str1)));
  }
  case TAG_I16: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str2), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str3)));
  }
  case TAG_I32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str4), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str5)));
  }
  case TAG_I64: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str6), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str7)));
  }
  case TAG_U8: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str8), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str9)));
  }
  case TAG_U16: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str10), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str11)));
  }
  case TAG_U32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str12), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str13)));
  }
  case TAG_U64: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str14), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str15)));
  }
  case TAG_F32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str16), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str17)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eprims_2enarrowJs(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2eshiftMaskJs_str0, 1, (110));
HEFF_STRA(g_heff_2ecompile_2eprims_2eshiftMaskJs_str1, 0, (0));
Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eshiftMaskJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2eshiftMaskJs(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_241 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_241 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_241 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_241 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_241 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_242 = heff_intShow(heff_intSub(v_t_241, MK_INT(1LL)));
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245;
  if (heff_intEq_c(v_t_243, MK_INT(64LL))) {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str0);
  } else {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str1);
  }
  return heff_strAppend(v_t_242, v_t_245);
}
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eprims_2eshiftMaskJs(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str0, 5, (97, 32, 43, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str1, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str2, 5, (97, 32, 45, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str3, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str4, 5, (97, 32, 42, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str5, 15, (77, 97, 116, 104, 46, 105, 109, 117, 108, 40, 97, 44, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str6, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str7, 5, (97, 32, 47, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str8, 17, (77, 97, 116, 104, 46, 116, 114, 117, 110, 99, 40, 97, 32, 47, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str9, 2, (48, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str10, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str11, 6, (98, 32, 61, 61, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str12, 16, (32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str13, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str14, 5, (97, 32, 37, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str15, 2, (48, 110));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str16, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str17, 6, (98, 32, 61, 61, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str18, 16, (32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str19, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str20, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str21, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str22, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str23, 5, (97, 32, 38, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str24, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str25, 5, (97, 32, 124, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str26, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str27, 5, (97, 32, 94, 32, 98));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str28, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str29, 10, (97, 32, 60, 60, 32, 40, 98, 32, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str30, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str31, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str32, 2, (62, 62));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str33, 2, (62, 62));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str34, 3, (62, 62, 62));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str35, 2, (97, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str36, 6, (32, 40, 98, 32, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str37, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str38, 14, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str39, 19, (40, 97, 41, 32, 61, 62, 32, 97, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str40, 7, (40, 97, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str41, 1, (97));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str42, 5, (73, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str43, 5, (73, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str44, 5, (73, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str45, 5, (73, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str46, 6, (85, 105, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str47, 6, (85, 105, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str48, 6, (85, 105, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str49, 6, (85, 105, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str50, 5, (73, 110, 116, 78, 40));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str51, 23, (40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 66, 105, 103, 73, 110, 116, 46, 97, 115));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str52, 5, (44, 32, 97, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str53, 8, (40, 97, 41, 32, 61, 62, 32, 97));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str54, 16, (40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str55, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str56, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str57, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2eintOpJs_str58, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
Clo g_heff_2ecompile_2eprims_2eintOpJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eintOpJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2eintOpJs(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_body_242 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str0)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str1), v_body_242);
  }
  case TAG_OpSub: {
    V v_body_243 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str2)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str3), v_body_243);
  }
  case TAG_OpMul: {
    V v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_246;
    if (heff_intEq_c(v_t_244, MK_INT(64LL))) {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str4);
    } else {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str5);
    }
    V v_body_247 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_246));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str6), v_body_247);
  }
  case TAG_OpDiv: {
    V v_t_248;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_248 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_248 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_248 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_248 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_248 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_248 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2410;
    if (heff_intEq_c(v_t_248, MK_INT(64LL))) {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str7);
    } else {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str8);
    }
    V v_e_2411 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2410));
    V v_t_2412;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2412 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2412 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2412 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2412 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2412 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2412 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2414;
    if (heff_intEq_c(v_t_2412, MK_INT(64LL))) {
      v_t_2414 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str9);
    } else {
      v_t_2414 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str10);
    }
    V v_body_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str11), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str12), v_e_2411)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str13), v_body_2415);
  }
  case TAG_OpRem: {
    V v_e_2416 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str14)));
    V v_t_2417;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2417 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2417 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2417 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2417 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2417 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2417 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2419;
    if (heff_intEq_c(v_t_2417, MK_INT(64LL))) {
      v_t_2419 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str15);
    } else {
      v_t_2419 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str16);
    }
    V v_body_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str17), heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str18), v_e_2416)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str19), v_body_2420);
  }
  case TAG_OpEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str20);
  }
  case TAG_OpLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str21);
  }
  case TAG_OpLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str22);
  }
  case TAG_OpAnd: {
    V v_body_2421 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str23)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str24), v_body_2421);
  }
  case TAG_OpOr: {
    V v_body_2422 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str25)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str26), v_body_2422);
  }
  case TAG_OpXor: {
    V v_body_2423 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str27)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str28), v_body_2423);
  }
  case TAG_OpShl: {
    V v_t_2424 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str29), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str30)));
    V v_body_2426 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2425));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str31), v_body_2426);
  }
  case TAG_OpShr: {
    V v_t_2427;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I16: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I32: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I64: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_U8: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str32);
      break;
    }
    case TAG_False: {
      V v_t_2428;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2428 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2428 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2428 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2428 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2428 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2428 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      if (heff_intEq_c(v_t_2428, MK_INT(64LL))) {
        v_t_2430 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str33);
      } else {
        v_t_2430 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str34);
      }
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    V v_t_2431 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str35), heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str36), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str37)))));
    V v_body_2433 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2432));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str38), v_body_2433);
  }
  case TAG_OpShow: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str39);
  }
  case TAG_OpFromInt: {
    V v_t_2434;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2434 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2434 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2434 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2434 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2434 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2434 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if (heff_intEq_c(v_t_2434, MK_INT(64LL))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str40), (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str41))));
    } else {
      V v_t_2436;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str42);
        break;
      }
      case TAG_I16: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str43);
        break;
      }
      case TAG_I32: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str44);
        break;
      }
      case TAG_I64: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str45);
        break;
      }
      case TAG_U8: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str46);
        break;
      }
      case TAG_U16: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str47);
        break;
      }
      case TAG_U32: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str48);
        break;
      }
      case TAG_U64: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str49);
        break;
      }
      case TAG_F32: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str50);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2437;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str51), heff_strAppend(v_t_2436, heff_strAppend(heff_intShow(v_t_2437), ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str52))));
    }
  }
  case TAG_OpToInt: {
    V v_t_2438;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2438 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2438 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2438 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2438 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2438 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2438 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if (heff_intEq_c(v_t_2438, MK_INT(64LL))) {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str53);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str54);
    }
  }
  case TAG_OpSqrt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str55);
  }
  case TAG_OpFromFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str56);
  }
  case TAG_OpToFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str57);
  }
  case TAG_OpFloor: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str58);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eprims_2eintOpJs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str0, 61, (99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 83, 116, 114, 105, 110, 103, 40, 116, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 105, 115, 78, 97, 78, 40, 115, 32, 43, 32, 34, 46, 48, 34, 41, 32, 63, 32, 115, 32, 58, 32, 115, 32, 43, 32, 34, 46, 48, 34, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str1, 45, (99, 111, 110, 115, 116, 32, 99, 32, 61, 32, 78, 117, 109, 98, 101, 114, 40, 113, 32, 43, 32, 34, 101, 34, 32, 43, 32, 115, 41, 32, 42, 32, 77, 97, 116, 104, 46, 115, 105, 103, 110, 40, 97, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str2, 47, (105, 102, 32, 40, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 99, 41, 32, 61, 61, 61, 32, 97, 41, 32, 123, 32, 116, 32, 61, 32, 99, 59, 32, 98, 114, 101, 97, 107, 59, 32, 125, 32, 125, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str3, 47, (108, 101, 116, 32, 113, 32, 61, 32, 110, 117, 109, 32, 47, 32, 100, 101, 110, 59, 32, 99, 111, 110, 115, 116, 32, 114, 50, 32, 61, 32, 50, 110, 32, 42, 32, 40, 110, 117, 109, 32, 37, 32, 100, 101, 110, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str4, 46, (105, 102, 32, 40, 114, 50, 32, 62, 32, 100, 101, 110, 32, 124, 124, 32, 40, 114, 50, 32, 61, 61, 61, 32, 100, 101, 110, 32, 38, 38, 32, 40, 113, 32, 38, 32, 49, 110, 41, 41, 41, 32, 113, 43, 43, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str5, 51, (102, 111, 114, 32, 40, 108, 101, 116, 32, 112, 32, 61, 32, 49, 59, 32, 112, 32, 60, 61, 32, 57, 59, 32, 112, 43, 43, 41, 32, 123, 32, 99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 107, 32, 45, 32, 112, 32, 43, 32, 49, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str6, 88, (99, 111, 110, 115, 116, 32, 110, 117, 109, 32, 61, 32, 115, 32, 62, 61, 32, 48, 32, 63, 32, 110, 32, 58, 32, 110, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 45, 115, 41, 44, 32, 100, 101, 110, 32, 61, 32, 115, 32, 62, 61, 32, 48, 32, 63, 32, 100, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 115, 41, 32, 58, 32, 100, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str7, 82, (99, 111, 110, 115, 116, 32, 103, 101, 32, 61, 32, 40, 107, 41, 32, 61, 62, 32, 107, 32, 62, 61, 32, 48, 32, 63, 32, 110, 32, 62, 61, 32, 100, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 107, 41, 32, 58, 32, 110, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 45, 107, 41, 32, 62, 61, 32, 100, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str8, 87, (108, 101, 116, 32, 107, 32, 61, 32, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 77, 97, 116, 104, 46, 108, 111, 103, 49, 48, 40, 77, 97, 116, 104, 46, 97, 98, 115, 40, 97, 41, 41, 41, 59, 32, 119, 104, 105, 108, 101, 32, 40, 33, 103, 101, 40, 107, 41, 41, 32, 107, 45, 45, 59, 32, 119, 104, 105, 108, 101, 32, 40, 103, 101, 40, 107, 32, 43, 32, 49, 41, 41, 32, 107, 43, 43, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str9, 82, (99, 111, 110, 115, 116, 32, 109, 32, 61, 32, 66, 105, 103, 73, 110, 116, 40, 98, 101, 32, 63, 32, 40, 98, 32, 38, 32, 56, 51, 56, 56, 54, 48, 55, 41, 32, 124, 32, 56, 51, 56, 56, 54, 48, 56, 32, 58, 32, 98, 32, 38, 32, 56, 51, 56, 56, 54, 48, 55, 41, 44, 32, 101, 32, 61, 32, 40, 98, 101, 32, 124, 124, 32, 49, 41, 32, 45, 32, 49, 53, 48, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str10, 74, (99, 111, 110, 115, 116, 32, 110, 32, 61, 32, 101, 32, 62, 61, 32, 48, 32, 63, 32, 109, 32, 60, 60, 32, 66, 105, 103, 73, 110, 116, 40, 101, 41, 32, 58, 32, 109, 44, 32, 100, 32, 61, 32, 101, 32, 62, 61, 32, 48, 32, 63, 32, 49, 110, 32, 58, 32, 49, 110, 32, 60, 60, 32, 66, 105, 103, 73, 110, 116, 40, 45, 101, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str11, 73, (99, 111, 110, 115, 116, 32, 118, 32, 61, 32, 110, 101, 119, 32, 68, 97, 116, 97, 86, 105, 101, 119, 40, 110, 101, 119, 32, 65, 114, 114, 97, 121, 66, 117, 102, 102, 101, 114, 40, 52, 41, 41, 59, 32, 118, 46, 115, 101, 116, 70, 108, 111, 97, 116, 51, 50, 40, 48, 44, 32, 77, 97, 116, 104, 46, 97, 98, 115, 40, 97, 41, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str12, 40, (99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 118, 46, 103, 101, 116, 85, 105, 110, 116, 51, 50, 40, 48, 41, 44, 32, 98, 101, 32, 61, 32, 98, 32, 62, 62, 62, 32, 50, 51, 59));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str13, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eprims_2efloat32ShowJs_str14, 56, (40, 97, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 116, 32, 61, 32, 97, 59, 32, 105, 102, 32, 40, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 38, 38, 32, 97, 32, 33, 61, 61, 32, 48, 41, 32, 123));

static V g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
static int g_heff_2ecompile_2eprims_2efloat32ShowJs_st;
static V g_heff_2ecompile_2eprims_2efloat32ShowJs_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str12), v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str13); V a_1 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str14); V a_2 = v_t_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_246, 2); r_; });
}
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void) {
  if (g_heff_2ecompile_2eprims_2efloat32ShowJs_st == 2) return g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
  if (g_heff_2ecompile_2eprims_2efloat32ShowJs_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2efloat32ShowJs_st = 1;
  g_heff_2ecompile_2eprims_2efloat32ShowJs_val = heff_tr(g_heff_2ecompile_2eprims_2efloat32ShowJs_init());
  g_heff_2ecompile_2eprims_2efloat32ShowJs_st = 2;
  return g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str0, 32, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 43, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str1, 32, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 45, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str2, 32, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 42, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str3, 32, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 47, 32, 98, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str4, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str5, 31, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str6, 29, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str7, 30, (40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str8, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str9, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str10, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str11, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str12, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str13, 29, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 78, 117, 109, 98, 101, 114, 40, 97, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str14, 17, (40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str15, 32, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 77, 97, 116, 104, 46, 115, 113, 114, 116, 40, 97, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str16, 21, (40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 41));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str17, 8, (40, 97, 41, 32, 61, 62, 32, 97));
HEFF_STRA(g_heff_2ecompile_2eprims_2efixedJs_str18, 62, (40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 97, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
Clo g_heff_2ecompile_2eprims_2efixedJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2efixedJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2efixedJs(V v_p_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_p_240, 0));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get_n(v_p_240, 1, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str0);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str1);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str2);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str3);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str4);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str5);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str6);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str7);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str8);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str9);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str10);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str11);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str12);
    }
    case TAG_OpShow: {
      return heff_dup(g_heff_2ecompile_2eprims_2efloat32ShowJs_get());
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str13);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str14);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str15);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str16);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str17);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str18);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    return ({ V b_0 = heff_dup(heff_rfield(v_p_240, 0)); V b_1 = heff_get_n(v_p_240, 1, 2); V r_ = (g_heff_2ecompile_2eprims_2eintOpJs(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eprims_2efixedJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eprims_2efixedJs(a[0]);
}
Clo g_heff_2ecompile_2eprims_2efixedImpl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2efixedImpl_entry, 1, 0};

V g_heff_2ecompile_2eprims_2efixedImpl(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_dup(v_p_240)));
  V v_t_242 = heff_dup(heff_rfield(v_p_240, 1));
  V v_arity_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_OpAdd: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpSub: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpMul: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpDiv: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpRem: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpEq: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpLt: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpLe: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpAnd: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpOr: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpXor: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShl: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShr: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShow: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromInt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpToInt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpSqrt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromFloat: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpToFloat: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFloor: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_js_244 = (g_heff_2ecompile_2eprims_2efixedJs(v_p_240));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241, heff_rec_n(2, shape_arity__js, (V[]){v_arity_243, v_js_244})});
}
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eprims_2efixedImpl(a[0]);
}

static V g_heff_2ecompile_2eprims_2eprims_val;
static int g_heff_2ecompile_2eprims_2eprims_st;
static V g_heff_2ecompile_2eprims_2eprims_init(void) {
  V v_t_240 = (g_list_2emap_24s1543151117x629172256(heff_dup(g_heff_2eelab_2efixed_2efixedPrims_get())));
  V v_t_241 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebytePrims_get()), v_t_240));
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get()), v_t_241));
}
V g_heff_2ecompile_2eprims_2eprims_get(void) {
  if (g_heff_2ecompile_2eprims_2eprims_st == 2) return g_heff_2ecompile_2eprims_2eprims_val;
  if (g_heff_2ecompile_2eprims_2eprims_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2eprims_st = 1;
  g_heff_2ecompile_2eprims_2eprims_val = heff_tr(g_heff_2ecompile_2eprims_2eprims_init());
  g_heff_2ecompile_2eprims_2eprims_st = 2;
  return g_heff_2ecompile_2eprims_2eprims_val;
}
HEFF_STRA(g_heff_2ecompile_2eprims_2einternal_str0, 7, (112, 101, 114, 102, 111, 114, 109));
HEFF_STRA(g_heff_2ecompile_2eprims_2einternal_str1, 30, (40, 112, 41, 32, 61, 62, 32, 40, 107, 41, 32, 61, 62, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 40, 112, 44, 32, 107, 41));

static V g_heff_2ecompile_2eprims_2einternal_val;
static int g_heff_2ecompile_2eprims_2einternal_st;
static V g_heff_2ecompile_2eprims_2einternal_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2einternal_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2einternal_str1)})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eprims_2einternal_get(void) {
  if (g_heff_2ecompile_2eprims_2einternal_st == 2) return g_heff_2ecompile_2eprims_2einternal_val;
  if (g_heff_2ecompile_2eprims_2einternal_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2einternal_st = 1;
  g_heff_2ecompile_2eprims_2einternal_val = heff_tr(g_heff_2ecompile_2eprims_2einternal_init());
  g_heff_2ecompile_2eprims_2einternal_st = 2;
  return g_heff_2ecompile_2eprims_2einternal_val;
}

static V g_heff_2ecompile_2eprims_2eallPrims_val;
static int g_heff_2ecompile_2eprims_2eallPrims_st;
static V g_heff_2ecompile_2eprims_2eallPrims_init(void) {
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2eprims_get()), heff_dup(g_heff_2ecompile_2eprims_2einternal_get())));
}
V g_heff_2ecompile_2eprims_2eallPrims_get(void) {
  if (g_heff_2ecompile_2eprims_2eallPrims_st == 2) return g_heff_2ecompile_2eprims_2eallPrims_val;
  if (g_heff_2ecompile_2eprims_2eallPrims_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eprims_2eallPrims_st = 1;
  g_heff_2ecompile_2eprims_2eallPrims_val = heff_tr(g_heff_2ecompile_2eprims_2eallPrims_init());
  g_heff_2ecompile_2eprims_2eallPrims_st = 2;
  return g_heff_2ecompile_2eprims_2eallPrims_val;
}
Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eprimArityGo_entry, 2, 0};

V g_heff_2ecompile_2eprims_2eprimArityGo(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_i_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_p_240))) {
        heff_drop(v_p_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_i_245, 0))});
      } else {
        V t_0 = v_p_240;
        V t_1 = v_rest_243;
        v_p_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eprims_2eprimArityGo(a[0], a[1]); heff_drop(a[1]); return r;
}