// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_fixed 298804110
#define LBL_js 10160
#define LBL_op 10312
static uint32_t shape_arity__js[] = {LBL_arity, LBL_js};
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
V g_heff_2ecompile_2eprims_2ebitsJs_get(void);
V g_heff_2ecompile_2eprims_2ebitsPrims_get(void);
V g_heff_2ecompile_2eprims_2ebyNonZero(V, V, V);
V g_heff_2ecompile_2eprims_2ebyNonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2ebyNonZero_clo;
V g_heff_2ecompile_2eprims_2ebytePrims_get(void);
V g_heff_2ecompile_2eprims_2ebytesPrims_get(void);
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2eprims_2efixedJs(V);
V g_heff_2ecompile_2eprims_2efixedJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedJs_clo;
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void);
V g_heff_2ecompile_2eprims_2efmixJs_get(void);
V g_heff_2ecompile_2eprims_2ehashPrims_get(void);
V g_heff_2ecompile_2eprims_2eintOpJs(V, V);
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eintOpJs_clo;
V g_heff_2ecompile_2eprims_2einternal_get(void);
V g_heff_2ecompile_2eprims_2enarrowJs(V, V);
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2enarrowJs_clo;
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
HeffT2 g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(V, V);
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2ecompile_2eprims_2erightJs(V);
V g_heff_2ecompile_2eprims_2erightJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2erightJs_clo;
V g_heff_2ecompile_2eprims_2eshiftJs(V, V, V);
V g_heff_2ecompile_2eprims_2eshiftJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eshiftJs_clo;
V g_heff_2ecompile_2eprims_2eshiftMaskJs(V);
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo;
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void);
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2efixedPrims_get(void);
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str0, 21, "return [c, m + 1]; })");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str1, 78, "for (let k = 1; k <= m; k++) { const d = i + k < n \? s.charCodeAt(i + k) : -1;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str2, 85, "if (d < lo || d > hi) return [65533, k]; lo = 128; hi = 191; c = c * 64 + (d & 63); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str3, 107, "else if (b >= 240 && b <= 244) { m = 3; c = b & 7; if (b === 240) lo = 144; else if (b === 244) hi = 143; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str4, 23, "else return [65533, 1];");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str5, 48, "if (b >= 194 && b <= 223) { m = 1; c = b & 31; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str6, 108, "else if (b >= 224 && b <= 239) { m = 2; c = b & 15; if (b === 224) lo = 160; else if (b === 237) hi = 159; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str7, 54, "const b = s.charCodeAt(i); if (b < 128) return [b, 1];");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str8, 29, "let m, c, lo = 128, hi = 191;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str9, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str10, 75, "((s, i) => { const n = s.length; if (!(i >= 0 && i < n)) return [65533, 0];");

static V g_heff_2ecompile_2eprims_2eutf8AtJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eutf8AtJs_st;
static V g_heff_2ecompile_2eprims_2eutf8AtJs_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str9); V a_1 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eutf8AtJs_st)) return g_heff_2ecompile_2eprims_2eutf8AtJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eutf8AtJs_val, &g_heff_2ecompile_2eprims_2eutf8AtJs_st, g_heff_2ecompile_2eprims_2eutf8AtJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str0, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str1, 85, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? BigInt(a.charCodeAt(Number(i))) : -1n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str2, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str3, 29, "(c) => String.fromCharCode(c)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str4, 14, "(s) => (i) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str5, 17, "(s, Number(i))[0]");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str6, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str7, 21, "(s) => (i) => BigInt(");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str8, 18, "(s, Number(i))[1])");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str9, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str10, 20, "(s) => { const at = ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str11, 85, "; let n = 0; for (let i = 0; i < s.length; i += at(s, i)[1]) n++; return BigInt(n); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str12, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str13, 20, "(s) => { const at = ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str14, 277, "; const r = []; for (let i = 0; i < s.length;) { const b = s.charCodeAt(i); if (b < 128) { r.push(b); i++; } else { const [c, w] = at(s, i); r.push(c); i += w; } } let l = { $: \"Nil\", a: [] }; for (let i = r.length - 1; i >= 0; i--) l = { $: \"Cons\", a: [r[i], l] }; return l; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str15, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str16, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str17, 446, "(l) => { let s = \"\"; while (l.$ === \"Cons\") { let c = l.a[0]; if (!(c >= 0 && c <= 0x10FFFF && (c < 0xD800 || c > 0xDFFF))) c = 0xFFFD; s += c < 0x80 \? String.fromCharCode(c) : c < 0x800 \? String.fromCharCode(0xC0 | c >> 6, 0x80 | c & 63) : c < 0x10000 \? String.fromCharCode(0xE0 | c >> 12, 0x80 | c >> 6 & 63, 0x80 | c & 63) : String.fromCharCode(0xF0 | c >> 18, 0x80 | c >> 12 & 63, 0x80 | c >> 6 & 63, 0x80 | c & 63); l = l.a[1]; } return s; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str18, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str19, 15, "(s) => $toJs(s)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str20, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytePrims_str21, 17, "(t) => $fromJs(t)");

static V g_heff_2ecompile_2eprims_2ebytePrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebytePrims_st;
static V g_heff_2ecompile_2eprims_2ebytePrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str3)})});
  V v_js_242 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str4), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str5)));
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), v_js_242})});
  V v_js_244 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str7), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str8)));
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str9), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), v_js_244})});
  V v_js_246 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str10), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str11)));
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str12), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_js_246})});
  V v_js_248 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytePrims_str13), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str14)));
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str15), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_js_248})});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str16), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str17)})});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str18), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str19)})});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytePrims_str20), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytePrims_str21)})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2415})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_2416})});
}
V g_heff_2ecompile_2eprims_2ebytePrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebytePrims_st)) return g_heff_2ecompile_2eprims_2ebytePrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebytePrims_val, &g_heff_2ecompile_2eprims_2ebytePrims_st, g_heff_2ecompile_2eprims_2ebytePrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str0, 283, "const cp = (d, at, s, from, n) => { let i = 0; if (at % 8 === 0 && from % 8 === 0) { d.set(s.subarray(from / 8, from / 8 + (n >> 3)), at / 8); i = n - (n & 7); } for (; i < n; i++) if ((s[(from + i) >> 3] >> (7 - ((from + i) & 7))) & 1) d[(at + i) >> 3] |= 0x80 >> ((at + i) & 7); };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str1, 139, "const wr = (a, at, w, n) => { for (let i = 0; i < n; i++) if ((w >> BigInt(n - 1 - i)) & 1n) a[(at + i) >> 3] |= 0x80 >> ((at + i) & 7); };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str2, 84, "const mk = (n) => { const r = new Uint8Array((n + 7) >> 3); r.bits = n; return r; };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str3, 131, "const int = (a, at, n, f) => { let u = rd(a, at, n); if (f & 1n) u = le(u, n, false); return (f & 2n) \? BigInt.asIntN(n, u) : u; };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str4, 100, "const word = (v, n, f) => { const u = BigInt.asUintN(n, v); return (f & 1n) \? le(u, n, true) : u; };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str5, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str6, 263, "const rd = (a, at, n) => { let u = 0n; if (at % 8 === 0 && n % 8 === 0) { for (let i = at / 8; i < (at + n) / 8; i++) u = (u << 8n) | BigInt(a[i]); } else { for (let i = at; i < at + n; i++) u = (u << 1n) | BigInt((a[i >> 3] >> (7 - (i & 7))) & 1); } return u; };");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str7, 402, "const le = (u, n, out) => { const k = n >> 3, r = n & 7; let w = 0n; if (out) { for (let i = 0; i < k; i++) w = (w << 8n) | ((u >> BigInt(8 * i)) & 255n); if (r) w = (w << BigInt(r)) | ((u >> BigInt(8 * k)) & BigInt((1 << r) - 1)); } else { if (r) w = (u & BigInt((1 << r) - 1)) << BigInt(8 * k); for (let i = 0; i < k; i++) w |= ((u >> BigInt(n - 8 * (i + 1))) & 255n) << BigInt(8 * i); } return w; };");

static V g_heff_2ecompile_2eprims_2ebitsJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebitsJs_st;
static V g_heff_2ecompile_2eprims_2ebitsJs_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str4), v_t_241})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2ebitsJs_str5); V a_1 = ((V)&g_heff_2ecompile_2eprims_2ebitsJs_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsJs_str7), v_t_242}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2eprims_2ebitsJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebitsJs_st)) return g_heff_2ecompile_2eprims_2ebitsJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebitsJs_val, &g_heff_2ecompile_2eprims_2ebitsJs_st, g_heff_2ecompile_2eprims_2ebitsJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str0, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str1, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str2, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str3, 73, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? a[Number(i)] : $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str4, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str5, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str6, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str7, 104, "(a) => (b) => { const r = new Uint8Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str8, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str9, 210, "(l) => { let n = 0; for (let c = l; c.$ === \"Cons\"; c = c.a[1]) n += c.a[0].length; const r = new Uint8Array(n); for (let k = 0; l.$ === \"Cons\"; l = l.a[1]) { r.set(l.a[0], k); k += l.a[0].length; } return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str10, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str11, 131, "(a) => (b) => { if (a.length !== b.length) return $F; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return $F; return $T; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str12, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str13, 106, "(l) => { const r = []; while (l.$ === \"Cons\") { r.push(l.a[0]); l = l.a[1]; } return Uint8Array.from(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str14, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str15, 122, "(a) => { let l = { $: \"Nil\", a: [] }; for (let i = a.length - 1; i >= 0; i--) l = { $: \"Cons\", a: [a[i], l] }; return l; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str16, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str17, 115, "(s) => { const r = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) r[i] = s.charCodeAt(i); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str18, 13, "bytesAsString");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str19, 136, "(a) => { let s = \"\"; for (let i = 0; i < a.length; i += 8192) s += String.fromCharCode.apply(null, a.subarray(i, i + 8192)); return s; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str20, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str21, 71, "(a) => $fromJs(new TextDecoder(\"utf-8\", { ignoreBOM: true }).decode(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str22, 30, "(a) => (o) => (n) => (f) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str23, 146, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && m <= 64 && at + m <= a.length * 8)) return $abandon(); return int(a, at, m, f); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str24, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str25, 23, "(n) => (f) => (v) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str26, 154, " const m = Number(n); if (!(m >= 0 && m <= 64 && m % 8 === 0)) return $abandon(); const r = new Uint8Array(m / 8); wr(r, 0, word(v, m, f), m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str27, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str28, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebytesPrims_str29, 183, "(a) => (o) => (b) => { const at = Number(o); if (!(at >= 0 && at <= a.length - b.length)) return $F; for (let i = 0; i < b.length; i++) if (a[at + i] !== b[i]) return $F; return $T; }");

static V g_heff_2ecompile_2eprims_2ebytesPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebytesPrims_st;
static V g_heff_2ecompile_2eprims_2ebytesPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str4), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str8), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str10), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str11)})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str12), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str13)})});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str14), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str15)})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str16), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str17)})});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str18), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str19)})});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str20), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str21)})});
  V v_js_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str22), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str23)));
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str24), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(4LL), v_js_2411})});
  V v_js_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str25), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str26)));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str27), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), v_js_2413})});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str28), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebytesPrims_str29)})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2421})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2422});
}
V g_heff_2ecompile_2eprims_2ebytesPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebytesPrims_st)) return g_heff_2ecompile_2eprims_2ebytesPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebytesPrims_val, &g_heff_2ecompile_2eprims_2ebytesPrims_st, g_heff_2ecompile_2eprims_2ebytesPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str0, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str1, 21, "(a) => BigInt(a.bits)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str2, 30, "(a) => (o) => (n) => (f) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str3, 140, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && m <= 64 && at + m <= a.bits)) return $abandon(); return int(a, at, m, f); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str4, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str5, 23, "(n) => (f) => (v) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str6, 123, " const m = Number(n); if (!(m >= 0 && m <= 64)) return $abandon(); const r = mk(m); wr(r, 0, word(v, m, f), m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str7, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str8, 9, "(l) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str9, 202, " let n = 0; for (let c = l; c.$ === \"Cons\"; c = c.a[1]) n += c.a[0].bits; const r = mk(n); for (let k = 0; l.$ === \"Cons\"; l = l.a[1]) { cp(r, k, l.a[0], 0, l.a[0].bits); k += l.a[0].bits; } return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str10, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str11, 23, "(a) => (o) => (n) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str12, 151, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && at + m <= a.bits)) return $abandon(); const r = mk(m); cp(r, 0, a, at, m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str13, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str14, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str15, 103, "(a) => { const r = new Uint8Array(a.buffer, a.byteOffset, a.length); r.bits = a.length * 8; return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str16, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str17, 87, "(a) => a.bits % 8 !== 0 \? $abandon() : new Uint8Array(a.buffer, a.byteOffset, a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str18, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str19, 127, "(a) => (b) => { if (a.bits !== b.bits) return $F; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return $F; return $T; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str20, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str21, 289, "(n) => (x) => { const v = new DataView(new ArrayBuffer(8)); if (n === 64n) { if (x !== x) return 0x7ff8000000000000n; v.setFloat64(0, x); return v.getBigUint64(0); } if (n === 32n) { if (x !== x) return 0x7fc00000n; v.setFloat32(0, x); return BigInt(v.getUint32(0)); } return $abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str22, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsPrims_str23, 255, "(n) => (u) => { const v = new DataView(new ArrayBuffer(8)); if (n === 64n) { v.setBigUint64(0, BigInt.asUintN(64, u)); return v.getFloat64(0); } if (n === 32n) { v.setUint32(0, Number(BigInt.asUintN(32, u))); return v.getFloat32(0); } return $abandon(); }");

static V g_heff_2ecompile_2eprims_2ebitsPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebitsPrims_st;
static V g_heff_2ecompile_2eprims_2ebitsPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str1)})});
  V v_js_241 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str2), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str3)));
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str4), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(4LL), v_js_241})});
  V v_js_243 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str5), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str6)));
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str7), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), v_js_243})});
  V v_js_245 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str8), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str9)));
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str10), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_js_245})});
  V v_js_247 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str11), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get()), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str12)));
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str13), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), v_js_247})});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str14), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str15)})});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str16), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str17)})});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str18), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str19)})});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str20), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str21)})});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str22), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebitsPrims_str23)})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2417})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418});
}
V g_heff_2ecompile_2eprims_2ebitsPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebitsPrims_st)) return g_heff_2ecompile_2eprims_2ebitsPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebitsPrims_val, &g_heff_2ecompile_2eprims_2ebitsPrims_st, g_heff_2ecompile_2eprims_2ebitsPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str1, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str2, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str3, 19, "(a) => (b) => a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str4, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str5, 19, "(a) => (b) => a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str6, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str7, 128, "(a) => (b) => { if (b === 0n) return a * b; const q = a / b, r = a % b; return r !== 0n && (r < 0n) !== (b < 0n) \? q - 1n : q; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str8, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str9, 116, "(a) => (b) => { if (b === 0n) return a - b; const r = a % b; return r !== 0n && (r < 0n) !== (b < 0n) \? r + b : r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str10, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str11, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str12, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str13, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str14, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str15, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str16, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str17, 19, "(a) => a.toString()");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str18, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str19, 19, "(a) => (b) => a & b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str20, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str21, 19, "(a) => (b) => a | b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str22, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str23, 19, "(a) => (b) => a ^ b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str24, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str25, 39, "(a) => (b) => b < 0n \? a >> -b : a << b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str26, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str27, 39, "(a) => (b) => b < 0n \? a << -b : a >> b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str28, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str29, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str30, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str31, 19, "(a) => (b) => a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str32, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str33, 19, "(a) => (b) => a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str34, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str35, 19, "(a) => (b) => a / b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str36, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str37, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str38, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str39, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str40, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str41, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str42, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str43, 70, "(a) => { const s = String(a); return isNaN(s + \".0\") \? s : s + \".0\"; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str44, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str45, 16, "(a) => Number(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str46, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str47, 19, "(a) => Math.sqrt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str48, 9, "onWindows");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str49, 79, "(u) => typeof process !== \"undefined\" && process.platform === \"win32\" \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str50, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str51, 54, "(a) => Number.isFinite(a) \? BigInt(Math.floor(a)) : 0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str52, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str53, 18, "(a) => Math.sin(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str54, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str55, 18, "(a) => Math.cos(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str56, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str57, 18, "(a) => Math.tan(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str58, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str59, 19, "(a) => Math.asin(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str60, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str61, 19, "(a) => Math.acos(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str62, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str63, 19, "(a) => Math.atan(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str64, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str65, 30, "(a) => (b) => Math.atan2(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str66, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str67, 18, "(a) => Math.exp(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str68, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str69, 18, "(a) => Math.log(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str70, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str71, 84, "(a) => (b) => a === 1 || (a === -1 && Math.abs(b) === Infinity) \? 1 : Math.pow(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str72, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str73, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str74, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str75, 73, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? a[Number(i)] : $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str76, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str77, 123, "(a) => (i) => (x) => { if (!(i >= 0n && i < BigInt(a.length))) return a; const b = a.slice(); b[Number(i)] = x; return b; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str78, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str79, 167, "(n) => (f) => ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(Array.from({ length: n > 0n \? Number(n) : 0 }, (_, k) => $tr(f(BigInt(k)))))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str80, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str81, 167, "(l) => { const r = []; while (l.$ === \"Cons\") { r.push(l.a[0]); l = l.a[1]; } return ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str82, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str83, 85, "(a) => a.reduceRight((rest, x) => ({ $: \"Cons\", a: [x, rest] }), { $: \"Nil\", a: [] })");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str84, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str85, 134, "(n) => (x) => { const m = n > 0n \? Number(n) : 0; return typeof x === \"number\" \? new Float64Array(m).fill(x) : new Array(m).fill(x); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str86, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str87, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str88, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str89, 220, "(a) => (b) => { if (b.length === 0) return a; if (a.length === 0) return b; if (!(a instanceof Float64Array)) return a.concat(b); const r = new Float64Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str90, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str91, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str92, 8, "setField");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str93, 46, "(d) => (i) => (v) => { d.a[i] = v; return d; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str94, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str95, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str96, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str97, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str98, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str99, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str100, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str101, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str102, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str103, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str104, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str105, 45, "(a) => (b) => a < b \? -1n : a === b \? 0n : 1n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str106, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str107, 122, "(n) => (s) => (i) => { const k = i < 0n \? 0 : Number(i); return k + n.length > s.length \? -1n : BigInt(s.indexOf(n, k)); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str108, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str109, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str110, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str111, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str112, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str113, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str114, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str115, 16, "(a) => BigInt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str116, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str117, 35, "(a) => Number(BigInt.asIntN(32, a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str118, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebasicPrims_str119, 8, "(x) => x");

static V g_heff_2ecompile_2eprims_2ebasicPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebasicPrims_st;
static V g_heff_2ecompile_2eprims_2ebasicPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str4), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str8), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str10), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str11)})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str12), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str13)})});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str14), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str15)})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str16), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str17)})});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str18), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str19)})});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str20), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str21)})});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str22), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str23)})});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str24), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str25)})});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str26), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str27)})});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str28), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str29)})});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str30), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str31)})});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str32), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str33)})});
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str34), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str35)})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str36), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str37)})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str38), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str39)})});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str40), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str41)})});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str42), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str43)})});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str44), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str45)})});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str46), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str47)})});
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str48), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str49)})});
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str50), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str51)})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str52), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str53)})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str54), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str55)})});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str56), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str57)})});
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str58), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str59)})});
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str60), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str61)})});
  V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str62), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str63)})});
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str64), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str65)})});
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str66), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str67)})});
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str68), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str69)})});
  V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str70), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str71)})});
  V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str72), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str73)})});
  V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str74), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str75)})});
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str76), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str77)})});
  V v_t_2439 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str78), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str79)})});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str80), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str81)})});
  V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str82), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str83)})});
  V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str84), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str85)})});
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str86), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str87)})});
  V v_t_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str88), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str89)})});
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str90), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str91)})});
  V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str92), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str93)})});
  V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str94), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str95)})});
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str96), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str97)})});
  V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str98), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str99)})});
  V v_t_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str100), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str101)})});
  V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str102), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str103)})});
  V v_t_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str104), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str105)})});
  V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str106), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str107)})});
  V v_t_2454 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str108), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str109)})});
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str110), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str111)})});
  V v_t_2456 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str112), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str113)})});
  V v_t_2457 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str114), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str115)})});
  V v_t_2458 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str116), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str117)})});
  V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str118), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2ecompile_2eprims_2ebasicPrims_str119)})});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2488})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2489});
}
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebasicPrims_st)) return g_heff_2ecompile_2eprims_2ebasicPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebasicPrims_val, &g_heff_2ecompile_2eprims_2ebasicPrims_st, g_heff_2ecompile_2eprims_2ebasicPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str1, 13, ") << 24 >> 24");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str3, 13, ") << 16 >> 16");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str5, 5, ") | 0");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str6, 18, "BigInt.asIntN(64, ");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str9, 7, ") & 255");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str11, 9, ") & 65535");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str13, 7, ") >>> 0");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str14, 19, "BigInt.asUintN(64, ");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str16, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str17, 1, ")");
Clo g_heff_2ecompile_2eprims_2enarrowJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2enarrowJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2enarrowJs(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_I8: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str0), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str1)));
  }
  case TAG_I16: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str2), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str3)));
  }
  case TAG_I32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str4), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str5)));
  }
  case TAG_I64: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str6), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str7)));
  }
  case TAG_U8: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str8), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str9)));
  }
  case TAG_U16: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str10), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str11)));
  }
  case TAG_U32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str12), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str13)));
  }
  case TAG_U64: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str14), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str15)));
  }
  case TAG_F32: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str16), heff_strAppend(v_e_241, ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str17)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2enarrowJs(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftMaskJs_str0, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftMaskJs_str1, 0, "");
Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eshiftMaskJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2eshiftMaskJs(V v_w_240) {
top: ;
  int64_t v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_241 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_241 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_241 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_241 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_241 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_242 = heff_intShow(heff_box_word((v_t_241 - ((int64_t)1ULL))));
  int64_t v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245;
  if ((v_t_243 == ((int64_t)64ULL))) {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str0);
  } else {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str1);
  }
  return heff_strAppend(v_t_242, v_t_245);
}
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eshiftMaskJs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str0, 2, "0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str2, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str3, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str4, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str5, 6, "b === ");
Clo g_heff_2ecompile_2eprims_2ebyNonZero_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2ebyNonZero_entry, 3, 0};

V g_heff_2ecompile_2eprims_2ebyNonZero(V v_w_240, V v_byZero_241, V v_e_242) {
top: ;
  int64_t v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245;
  if ((v_t_243 == ((int64_t)64ULL))) {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str0);
  } else {
    v_t_245 = ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str1);
  }
  V v_t_246 = heff_strAppend(v_byZero_241, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str2), v_e_242));
  V v_t_247 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str3), v_t_246));
  return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str4), heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str5), v_t_247));
}
V g_heff_2ecompile_2eprims_2ebyNonZero_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2ebyNonZero(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str0, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str1, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str2, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str3, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str4, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str5, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str6, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str7, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str8, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str9, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str10, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str11, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2erightJs_str12, 2, ">>");
Clo g_heff_2ecompile_2eprims_2erightJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2erightJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2erightJs(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    return ((V)&g_heff_2ecompile_2eprims_2erightJs_str0);
  }
  case TAG_I16: {
    return ((V)&g_heff_2ecompile_2eprims_2erightJs_str1);
  }
  case TAG_I32: {
    return ((V)&g_heff_2ecompile_2eprims_2erightJs_str2);
  }
  case TAG_I64: {
    return ((V)&g_heff_2ecompile_2eprims_2erightJs_str3);
  }
  case TAG_U8: {
    int64_t v_t_241;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_241 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_241 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_241 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_241 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_241 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_241 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_241 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_241 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_241 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_241 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str4);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str5);
    }
  }
  case TAG_U16: {
    int64_t v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_243 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str6);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str7);
    }
  }
  case TAG_U32: {
    int64_t v_t_245;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_245 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_245 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_245 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_245 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_245 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_245 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_245 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_245 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_245 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_245 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str8);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str9);
    }
  }
  case TAG_U64: {
    int64_t v_t_247;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_247 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str10);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2erightJs_str11);
    }
  }
  case TAG_F32: {
    return ((V)&g_heff_2ecompile_2eprims_2erightJs_str12);
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2ecompile_2eprims_2erightJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2erightJs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str0, 2, "0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str2, 7, " (-b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str4, 2, "a ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str5, 6, " (b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str7, 2, "a ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str8, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str9, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str10, 4, "b < ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str11, 6, " (b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str13, 2, "a ");
Clo g_heff_2ecompile_2eprims_2eshiftJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eshiftJs_entry, 3, 0};

V g_heff_2ecompile_2eprims_2eshiftJs(V v_w_240, V v_op_241, V v_back_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    int64_t v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_246;
    if ((v_t_244 == ((int64_t)64ULL))) {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str0);
    } else {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str1);
    }
    V v_t_247 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str2), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str3)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str4), heff_strAppend(v_back_242, v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_249));
    V v_t_2411 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str5), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str6)));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str7), heff_strAppend(v_op_241, v_t_2412));
    V v_t_2414 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2413));
    V v_t_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str8), v_t_2414));
    V v_t_2416 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str9), v_t_2415));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str10), v_t_2416);
  } else {
    heff_drop(v_back_242);
    heff_drop(v_t_243);
    V v_t_2417 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str11), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str12)));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str13), heff_strAppend(v_op_241, v_t_2418));
    return (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2419));
  }
}
V g_heff_2ecompile_2eprims_2eshiftJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eshiftJs(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str0, 5, "a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str1, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str2, 5, "a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str3, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str4, 5, "a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str5, 15, "Math.imul(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str6, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str7, 5, "a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str9, 5, "a / b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str10, 17, "Math.trunc(a / b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str11, 5, "a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str12, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str13, 5, "a % b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str14, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str15, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str16, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str17, 5, "a & b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str18, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str19, 5, "a | b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str20, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str21, 5, "a ^ b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str22, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str23, 2, "<<");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str24, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str25, 2, "<<");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str26, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str27, 19, "(a) => a.toString()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str28, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str29, 7, "(a) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str30, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str31, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str32, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str33, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str34, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str35, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str36, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str37, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str38, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str39, 5, ", a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str40, 23, "(a) => Number(BigInt.as");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str41, 8, "(a) => a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str42, 16, "(a) => BigInt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str43, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str44, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str45, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str46, 17, "(a) => $abandon()");
Clo g_heff_2ecompile_2eprims_2eintOpJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eintOpJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2eintOpJs(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_body_242 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str0)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str1), v_body_242);
  }
  case TAG_OpSub: {
    V v_body_243 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str2)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str3), v_body_243);
  }
  case TAG_OpMul: {
    int64_t v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_246;
    if ((v_t_244 == ((int64_t)64ULL))) {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str4);
    } else {
      v_t_246 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str5);
    }
    V v_body_247 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_246));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str6), v_body_247);
  }
  case TAG_OpDiv: {
    int64_t v_t_248;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_248 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_248 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_248 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_248 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_248 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_248 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_248 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_248 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_248 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2410;
    if ((v_t_248 == ((int64_t)64ULL))) {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str7);
    } else {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str8);
    }
    int64_t v_t_2411;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2411 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2411 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2411 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2411 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2411 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2411 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2411 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2411 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2411 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2413;
    if ((v_t_2411 == ((int64_t)64ULL))) {
      v_t_2413 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str9);
    } else {
      v_t_2413 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str10);
    }
    V v_t_2414 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2413));
    return (g_heff_2ecompile_2eprims_2ebyNonZero(v_w_240, v_t_2410, v_t_2414));
  }
  case TAG_OpRem: {
    int64_t v_t_2415;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2415 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2415 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2415 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2415 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2415 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2415 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2415 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2415 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2415 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2417;
    if ((v_t_2415 == ((int64_t)64ULL))) {
      v_t_2417 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str11);
    } else {
      v_t_2417 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str12);
    }
    V v_t_2418 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str13)));
    return (g_heff_2ecompile_2eprims_2ebyNonZero(v_w_240, v_t_2417, v_t_2418));
  }
  case TAG_OpEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str14);
  }
  case TAG_OpLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str15);
  }
  case TAG_OpLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str16);
  }
  case TAG_OpAnd: {
    V v_body_2419 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str17)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str18), v_body_2419);
  }
  case TAG_OpOr: {
    V v_body_2420 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str19)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str20), v_body_2420);
  }
  case TAG_OpXor: {
    V v_body_2421 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str21)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str22), v_body_2421);
  }
  case TAG_OpShl: {
    V v_t_2422 = (g_heff_2ecompile_2eprims_2erightJs(v_w_240));
    V v_body_2423 = (g_heff_2ecompile_2eprims_2eshiftJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str23), v_t_2422));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str24), v_body_2423);
  }
  case TAG_OpShr: {
    V v_t_2424 = (g_heff_2ecompile_2eprims_2erightJs(v_w_240));
    V v_body_2425 = (g_heff_2ecompile_2eprims_2eshiftJs(v_w_240, v_t_2424, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str25)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str26), v_body_2425);
  }
  case TAG_OpShow: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str27);
  }
  case TAG_OpFromInt: {
    int64_t v_t_2426;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2426 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2426 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2426 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2426 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2426 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2426 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2426 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2426 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2426 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_2426 == ((int64_t)64ULL))) {
      V v_t_2428 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str28)));
      return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str29), v_t_2428);
    } else {
      V v_t_2429;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str30);
        break;
      }
      case TAG_I16: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str31);
        break;
      }
      case TAG_I32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str32);
        break;
      }
      case TAG_I64: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str33);
        break;
      }
      case TAG_U8: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str34);
        break;
      }
      case TAG_U16: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str35);
        break;
      }
      case TAG_U32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str36);
        break;
      }
      case TAG_U64: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str37);
        break;
      }
      case TAG_F32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str38);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2430;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2430 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2430 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2430 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2430 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2430 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2430 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2430 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2430 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2430 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2431 = heff_strAppend(heff_intShow(v_t_2430), ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str39));
      return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str40), heff_strAppend(v_t_2429, v_t_2431));
    }
  }
  case TAG_OpToInt: {
    int64_t v_t_2432;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2432 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2432 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2432 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2432 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2432 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2432 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2432 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2432 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2432 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_2432 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str41);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str42);
    }
  }
  case TAG_OpSqrt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str43);
  }
  case TAG_OpFromFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str44);
  }
  case TAG_OpToFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str45);
  }
  case TAG_OpFloor: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str46);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eprims_2eintOpJs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str0, 61, "const s = String(t); return isNaN(s + \".0\") \? s : s + \".0\"; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str1, 45, "const c = Number(q + \"e\" + s) * Math.sign(a);");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str2, 47, "if (Math.fround(c) === a) { t = c; break; } } }");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str3, 47, "let q = num / den; const r2 = 2n * (num % den);");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str4, 46, "if (r2 > den || (r2 === den && (q & 1n))) q++;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str5, 51, "for (let p = 1; p <= 9; p++) { const s = k - p + 1;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str6, 88, "const num = s >= 0 \? n : n * 10n ** BigInt(-s), den = s >= 0 \? d * 10n ** BigInt(s) : d;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str7, 82, "const ge = (k) => k >= 0 \? n >= d * 10n ** BigInt(k) : n * 10n ** BigInt(-k) >= d;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str8, 87, "let k = Math.floor(Math.log10(Math.abs(a))); while (!ge(k)) k--; while (ge(k + 1)) k++;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str9, 82, "const m = BigInt(be \? (b & 8388607) | 8388608 : b & 8388607), e = (be || 1) - 150;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str10, 74, "const n = e >= 0 \? m << BigInt(e) : m, d = e >= 0 \? 1n : 1n << BigInt(-e);");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str11, 73, "const v = new DataView(new ArrayBuffer(4)); v.setFloat32(0, Math.abs(a));");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str12, 40, "const b = v.getUint32(0), be = b >>> 23;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str14, 56, "(a) => { let t = a; if (Number.isFinite(a) && a !== 0) {");

static V g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2efloat32ShowJs_st;
static V g_heff_2ecompile_2eprims_2efloat32ShowJs_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str12), v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str13); V a_1 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str14); V a_2 = v_t_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_246, 2); r_; });
}
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2efloat32ShowJs_st)) return g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2efloat32ShowJs_val, &g_heff_2ecompile_2eprims_2efloat32ShowJs_st, g_heff_2ecompile_2eprims_2efloat32ShowJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str0, 32, "(a) => (b) => Math.fround(a + b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str1, 32, "(a) => (b) => Math.fround(a - b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str2, 32, "(a) => (b) => Math.fround(a * b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str3, 32, "(a) => (b) => Math.fround(a / b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str4, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str5, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str6, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str7, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str8, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str9, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str10, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str11, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str12, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str13, 29, "(a) => Math.fround(Number(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str14, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str15, 32, "(a) => Math.fround(Math.sqrt(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str16, 21, "(a) => Math.fround(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str17, 8, "(a) => a");
HEFF_LIT(g_heff_2ecompile_2eprims_2efixedJs_str18, 54, "(a) => Number.isFinite(a) \? BigInt(Math.floor(a)) : 0n");
Clo g_heff_2ecompile_2eprims_2efixedJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2efixedJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2efixedJs(V v_p_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_p_240, 0));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_t_243 = heff_get_n(v_p_240, 1, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str0);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str1);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str2);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str3);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str4);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str5);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str6);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str7);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str8);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str9);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str10);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str11);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str12);
    }
    case TAG_OpShow: {
      return heff_dup(g_heff_2ecompile_2eprims_2efloat32ShowJs_get());
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str13);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str14);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str15);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str16);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str17);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2ecompile_2eprims_2efixedJs_str18);
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    heff_drop(v_t_242);
    return ({ V b_0 = heff_dup(heff_rfield(v_p_240, 0)); V b_1 = heff_get_n(v_p_240, 1, 2); V r_ = (g_heff_2ecompile_2eprims_2eintOpJs(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
}
V g_heff_2ecompile_2eprims_2efixedJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eprims_2efixedJs(a[0]);
}
Clo g_heff_2ecompile_2eprims_2efixedImpl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2efixedImpl_entry, 1, 0};

V g_heff_2ecompile_2eprims_2efixedImpl(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_dup(v_p_240)));
  V v_js_242 = (g_heff_2ecompile_2eprims_2efixedJs(heff_dup(v_p_240)));
  V v_t_243 = heff_get_n(v_p_240, 1, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_OpAdd: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpSub: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpMul: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpDiv: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpRem: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpEq: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpLt: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpLe: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpAnd: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpOr: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpXor: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpShl: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpShr: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_OpShow: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromInt: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpToInt: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpSqrt: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpToFloat: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_OpFloor: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241, heff_rec_n(2, shape_arity__js, (V[]){v_t_244, v_js_242})});
}
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eprims_2efixedImpl(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2efmixJs_str0, 162, "((h) => { const M = 0xffffffffffffffffn; h ^= h >> 33n; h = h * 0xff51afd7ed558ccdn & M; h ^= h >> 33n; h = h * 0xc4ceb9fe1a85ec53n & M; return h ^ (h >> 33n); })");

static V g_heff_2ecompile_2eprims_2efmixJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2efmixJs_st;
static V g_heff_2ecompile_2eprims_2efmixJs_init(void) {
  return ((V)&g_heff_2ecompile_2eprims_2efmixJs_str0);
}
V g_heff_2ecompile_2eprims_2efmixJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2efmixJs_st)) return g_heff_2ecompile_2eprims_2efmixJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2efmixJs_val, &g_heff_2ecompile_2eprims_2efmixJs_st, g_heff_2ecompile_2eprims_2efmixJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str0, 382, "(s) => { const M = 0xffffffffffffffffn, n = s.length; let h = BigInt(n), i = 0; const half = (j, e) => { let x = 0; for (let k = Math.min(j + 4, e) - 1; k >= j; k--) x = x * 256 + s.charCodeAt(k); return BigInt(x); }; const step = (w) => { h = ((((h << 5n) | (h >> 59n)) & M) ^ w) * 0x517cc1b727220a95n & M; }; for (; i < n; i += 8) step(half(i, n) | half(i + 4, n) << 32n); return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str1, 12, "(h) >> 2n; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str2, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str3, 7, "(a) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str4, 29, "(BigInt.asUintN(64, a)) >> 2n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str5, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str6, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2eprims_2ehashPrims_str7, 157, "(bm) => (h) => (s) => { const bit = 1n << ((h >> s) & 31n); let m = bm & (bit - 1n), c = 0n; while (m) { m &= m - 1n; c++; } return bm & bit \? c : -1n - c; }");

static V g_heff_2ecompile_2eprims_2ehashPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ehashPrims_st;
static V g_heff_2ecompile_2eprims_2ehashPrims_init(void) {
  V v_t_240 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ehashPrims_str0), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2efmixJs_get()), ((V)&g_heff_2ecompile_2eprims_2ehashPrims_str1)));
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ehashPrims_str2), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_t_240})});
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ehashPrims_str3), heff_strAppend(heff_dup(g_heff_2ecompile_2eprims_2efmixJs_get()), ((V)&g_heff_2ecompile_2eprims_2ehashPrims_str4)));
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ehashPrims_str5), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(1LL), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2ehashPrims_str6), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2ecompile_2eprims_2ehashPrims_str7)})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_245})});
}
V g_heff_2ecompile_2eprims_2ehashPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ehashPrims_st)) return g_heff_2ecompile_2eprims_2ehashPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ehashPrims_val, &g_heff_2ecompile_2eprims_2ehashPrims_st, g_heff_2ecompile_2eprims_2ehashPrims_init);
}

static V g_heff_2ecompile_2eprims_2eprims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eprims_st;
static V g_heff_2ecompile_2eprims_2eprims_init(void) {
  V v_t_240 = (g_list_2emap_24s1543151117x629172256(heff_dup(g_heff_2eelab_2efixed_2efixedPrims_get())));
  V v_t_241 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ehashPrims_get()), v_t_240));
  V v_t_242 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebitsPrims_get()), v_t_241));
  V v_t_243 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebytesPrims_get()), v_t_242));
  V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebytePrims_get()), v_t_243));
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get()), v_t_244));
}
V g_heff_2ecompile_2eprims_2eprims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eprims_st)) return g_heff_2ecompile_2eprims_2eprims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eprims_val, &g_heff_2ecompile_2eprims_2eprims_st, g_heff_2ecompile_2eprims_2eprims_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2einternal_str0, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2eprims_2einternal_str1, 30, "(p) => (k) => $performer(p, k)");

static V g_heff_2ecompile_2eprims_2einternal_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2einternal_st;
static V g_heff_2ecompile_2eprims_2einternal_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2einternal_str0), heff_rec_n(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2ecompile_2eprims_2einternal_str1)})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eprims_2einternal_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2einternal_st)) return g_heff_2ecompile_2eprims_2einternal_val;
  return heff_global(&g_heff_2ecompile_2eprims_2einternal_val, &g_heff_2ecompile_2eprims_2einternal_st, g_heff_2ecompile_2eprims_2einternal_init);
}

static V g_heff_2ecompile_2eprims_2eallPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eallPrims_st;
static V g_heff_2ecompile_2eprims_2eallPrims_init(void) {
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eprims_2eprims_get()), heff_dup(g_heff_2ecompile_2eprims_2einternal_get())));
}
V g_heff_2ecompile_2eprims_2eallPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eallPrims_st)) return g_heff_2ecompile_2eprims_2eallPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eallPrims_val, &g_heff_2ecompile_2eprims_2eallPrims_st, g_heff_2ecompile_2eprims_2eallPrims_init);
}

HeffT2 g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_i_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_244, v_p_240, 1)) {
        heff_drop(v_rest_243);
        V v_f_247 = heff_get_n(v_i_245, 0, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
      } else {
        heff_drop_rec(v_i_245, 2);
        V t_0 = v_p_240;
        V t_1 = v_rest_243;
        v_p_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eprimArityGo_entry, 2, 0};

V g_heff_2ecompile_2eprims_2eprimArityGo(V v_p_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(v_p_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eprimArityGo(a0, a[1]); heff_drop(a0); return r;
}