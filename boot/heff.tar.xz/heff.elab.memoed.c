// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SFunction 64505
#define TAG_SImplicit 59448
#define TAG_SLam 1658
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_stx 323761
#define LBL_val 326043
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(V, V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
HeffT2 g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eprojAt_24tok1(V, V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo;
V g_heff_2eelab_2ememoed_2eiapp_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2eiapp_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2eiapp_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eiapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eiapp_entry, 3, 0};

V g_heff_2eelab_2ememoed_2eiapp(V v_x_240, V v_g0_241, V v_g1_242) {
top: ;
  V v_stx_243 = heff_take_field(v_g1_242, 0);
  V v_val_244 = heff_get_n(v_g1_242, 1, 2);
  V v_stx_245 = heff_take_field(v_g0_241, 0);
  V v_val_246 = heff_get_n(v_g0_241, 1, 2);
  V v_t_247 = heff_tag_n(TAG_SApp, 2, (V[]){v_stx_245, heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_240, v_stx_243})});
  return heff_rec_n(2, shape_stx__val, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam0, 1, 2, (V[]){v_val_246, v_val_244})});
}
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eiapp(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ememoed_2eiapp_lam2(V self, V *args) {
  V v_u2_2411 = args[0];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2411);
  V v_x1_2412 = heff_tr(heff_call(v_val_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2413;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eelab_2ememoed_2eiapp_lam1(V self, V *args) {
  V v_f_2410 = args[0];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2410, heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam2, 1, 1, (V[]){v_val_244})));
}
V g_heff_2eelab_2ememoed_2eiapp_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_val_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_248);
  V v_t_249 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam1, 1, 1, (V[]){v_val_244}), v_t_249));
}
V g_heff_2eelab_2ememoed_2elam_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam4(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam3(V self, V *args);
Clo g_heff_2eelab_2ememoed_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2elam_entry, 5, 0};

V g_heff_2eelab_2ememoed_2elam(V v_c_240, V v_g_241, V v_vs_242, V v_gdom_243, V v_x5_244) {
top: ;
  V v_stx_245 = heff_take_field(v_gdom_243, 0);
  V v_val_246 = heff_get_n(v_gdom_243, 1, 2);
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkAbs: {
    V v_x_247 = heff_field(v_x5_244, 0);
    V v_gbody_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkAbs = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24x5_244_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_247), heff_dup(heff_rfield(v_gbody_248, 0))});
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_stx_245, v_t_249}), heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam0, 1, 6, (V[]){v_val_246, v_x_247, v_vs_242, v_g_241, v_c_240, v_gbody_248})});
  }
  case TAG_AbsConst: {
    V v_gbody_2418 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24AbsConst = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_g_241);
    heff_drop(v_vs_242);
    V v_stx_2419 = heff_take_field(v_gbody_2418, 0);
    V v_val_2420 = heff_get_n(v_gbody_2418, 1, 2);
    V v_t_2421 = heff_tag_n(TAG_SLam, 2, (V[]){v_stx_245, heff_tag_at_n(v_ru_24x5_244_24AbsConst, TAG_AbsConst, 1, (V[]){v_stx_2419})});
    return heff_rec_n(2, shape_stx__val, (V[]){v_t_2421, heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam3, 1, 3, (V[]){v_val_2420, v_val_246, v_c_240})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2elam(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2ememoed_2elam_lam1(V self, V *args) {
  V v_u2_2411 = args[0];
  V v_val_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2411);
  V v_x1_2412 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2413;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam2(V self, V *args) {
  V v_vs2_2416 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_gbody_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_241, v_c_240, heff_get_n(v_gbody_248, 0, 2), v_vs2_2416));
}
V g_heff_2eelab_2ememoed_2elam_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_c_240 = heff_env(self)[4];
  V v_gbody_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2410);
  V v_x_2417 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam1, 1, 1, (V[]){v_val_246}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_247, v_vs_242, heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam2, 1, 3, (V[]){v_g_241, heff_dup(v_c_240), v_gbody_248})})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2417});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam4(V self, V *args) {
  V v_u2_2424 = args[0];
  V v_val_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2424);
  V v_x1_2425 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Nom: {
    V v_x_2426 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    return v_x_2426;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2428 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    return v_x_2428;
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam3(V self, V *args) {
  V v_u_2422 = args[0];
  V v_val_2420 = heff_env(self)[0];
  V v_val_246 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_call(v_val_2420, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x_2429 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam4, 1, 1, (V[]){v_val_246}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2423})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2429});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2429});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2ememoed_2eproj_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2eproj_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eproj_entry, 2, 0};

V g_heff_2eelab_2ememoed_2eproj(V v_g_240, V v_x_241) {
top: ;
  V v_stx_242 = heff_take_field(v_g_240, 0);
  V v_val_243 = heff_get_n(v_g_240, 1, 2);
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_stx_242, heff_dup(v_x_241)}), heff_clo_n(g_heff_2eelab_2ememoed_2eproj_lam0, 1, 2, (V[]){v_val_243, v_x_241})});
}
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eproj(a[0], a[1]);
}
V g_heff_2eelab_2ememoed_2eproj_lam1(V self, V *args) {
  V v_v_246 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_246)) {
  case TAG_VNeu: {
    V v_t_2412 = ({ V a_0 = v_v_246; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_246, 5); r_; });
    return ({ V a_0 = v_t_2412; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VCode: {
    V v_t_2414 = ({ V a_0 = v_v_246; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_246, 1); r_; });
    return ({ V a_0 = v_t_2414; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VLam: {
    V v_t_2417 = ({ V a_0 = v_v_246; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_246, 2); r_; });
    return ({ V a_0 = v_t_2417; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VCons: {
    V v_t_2419 = ({ V a_0 = v_v_246; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_246, 1); r_; });
    return ({ V a_0 = v_t_2419; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_246);
  }
}
V g_heff_2eelab_2ememoed_2eproj_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_val_243 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_244);
  V v_t_245 = heff_tr(heff_call(v_val_243, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2ememoed_2eproj_lam1, 1, 1, (V[]){v_x_241}), v_t_245));
}
V g_heff_2eelab_2ememoed_2eprojAt_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprojAt_entry, 3, 0};

V g_heff_2eelab_2ememoed_2eprojAt(V v_g_240, V v_x_241, V v_a_242) {
top: ;
  V v_stx_243 = heff_take_field(v_g_240, 0);
  V v_val_244 = heff_get_n(v_g_240, 1, 2);
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_stx_243, heff_dup(v_x_241)}), heff_clo_n(g_heff_2eelab_2ememoed_2eprojAt_lam0, 1, 3, (V[]){v_val_244, v_x_241, v_a_242})});
}
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ememoed_2eprojAt_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_val_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_245);
  V v_x2_246 = heff_tr(heff_call(v_val_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Nom = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eprojAt_24tok1(v_ru_24x2_246_24Nom, v_x_247, v_x_241, v_a_242));
  }
  case TAG_Describe: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Describe = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eprojAt_24tok1(v_ru_24x2_246_24Describe, v_x_248, v_x_241, v_a_242));
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Become = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    V v_x1_2410 = (g_heff_2eelab_2evalue_2eprojAt(v_x_249, v_x_241, v_a_242));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Nom: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      v_t_2414 = v_x_2411;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_2414 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2413 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    return heff_tag_at_n(v_ru_24x2_246_24Become, TAG_Become, 1, (V[]){v_t_2414});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eelab_2ememoed_2eabandonM_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eabandonM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eabandonM_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eabandonM_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eabandonM_st;
static V g_heff_2eelab_2ememoed_2eabandonM_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2ememoed_2eabandonM_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eabandonM_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eabandonM_st)) return g_heff_2eelab_2ememoed_2eabandonM_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eabandonM_val, &g_heff_2eelab_2ememoed_2eabandonM_st, g_heff_2eelab_2ememoed_2eabandonM_init);
}
V g_heff_2eelab_2ememoed_2eabandonM_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V v_implicit_240, V v_dflt_241, V v_g_242, V v_vs_243, V v_dom_244, V v_x6_245) {
top: ;
  V v_stx_246 = heff_take_field(v_dom_244, 0);
  V v_val_247 = heff_get_n(v_dom_244, 1, 2);
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkAbs: {
    V v_x_248 = heff_field(v_x6_245, 0);
    V v_body_249 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkAbs = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_val_2410 = heff_take_field(v_body_249, 1);
    V v_stx_2411 = heff_get_n(v_body_249, 0, 2);
    V v_x1_2412 = heff_tr(heff_call(heff_dup(v_val_2410), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_t_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2413); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2414 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2414); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    V v_f_2417 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2416, v_stx_246, heff_tag_at_n(v_ru_24x6_245_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_248), heff_dup(v_stx_2411)}), heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return ((HeffT2){{v_f_2417, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0, 1, 8, (V[]){v_val_2410, v_val_247, v_x_248, v_vs_243, v_g_242, v_stx_2411, v_implicit_240, v_dflt_241})}});
  }
  case TAG_AbsConst: {
    V v_body_2431 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24AbsConst = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    heff_drop(v_g_242);
    heff_drop(v_vs_243);
    V v_val_2432 = heff_take_field(v_body_2431, 1);
    V v_stx_2433 = heff_get_n(v_body_2431, 0, 2);
    V v_x1_2434 = heff_tr(heff_call(heff_dup(v_val_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2438;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nom: {
      V v_t_2435 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2435); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2436 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2436); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2437 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2437; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    V v_f_2439 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2438, v_stx_246, heff_tag_at_n(v_ru_24x6_245_24AbsConst, TAG_AbsConst, 1, (V[]){v_stx_2433}), heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return ((HeffT2){{v_f_2439, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2, 1, 4, (V[]){v_val_2432, v_val_247, v_implicit_240, v_dflt_241})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x6_245)}});
  }
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1(V self, V *args) {
  V v_vs2_2429 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_stx_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_242, NTAG(TAG_N), v_stx_2411, v_vs2_2429));
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_val_2410 = heff_env(self)[0];
  V v_val_247 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  V v_g_242 = heff_env(self)[4];
  V v_stx_2411 = heff_env(self)[5];
  V v_implicit_240 = heff_env(self)[6];
  V v_dflt_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_u_2418);
  V v_x1_2419 = heff_tr(heff_call(v_val_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nom: {
    V v_t_2420 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2420); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2421 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2421); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2422 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2419);
  }
  V v_x1_2424 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nom: {
    V v_x_2425 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_t_2428 = v_x_2425;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    v_t_2428 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  V v_t_2430 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2423, v_t_2428, heff_tag_n(TAG_MkClo, 3, (V[]){v_x_248, v_vs_243, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1, 1, 2, (V[]){v_g_242, v_stx_2411})}), v_implicit_240, v_dflt_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2430});
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_val_2432 = heff_env(self)[0];
  V v_val_247 = heff_env(self)[1];
  V v_implicit_240 = heff_env(self)[2];
  V v_dflt_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2440);
  V v_x1_2441 = heff_tr(heff_call(heff_dup(v_val_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_t_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2442; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2442); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2443 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2443; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2443); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2444); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_x1_2446 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2450;
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x1_2446);
  }
  V v_t_2451 = heff_tr(heff_call(v_val_2432, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2452 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2445, v_t_2450, heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2451}), v_implicit_240, v_dflt_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2452});
}
Clo g_heff_2eelab_2ememoed_2efunctionD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2efunctionD_entry, 6, 0};

V g_heff_2eelab_2ememoed_2efunctionD(V v_implicit_240, V v_dflt_241, V v_g_242, V v_vs_243, V v_dom_244, V v_x6_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2eelab_2ememoed_2efunctionD_24cpr(v_implicit_240, v_dflt_241, v_g_242, v_vs_243, v_dom_244, v_x6_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_rec_n(2, shape_stx__val, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2efunctionD(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2ememoed_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimInt_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimInt_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimInt_st;
static V g_heff_2eelab_2ememoed_2eprimInt_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimInt), ((V)&g_heff_2eelab_2ememoed_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimInt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimInt_st)) return g_heff_2eelab_2ememoed_2eprimInt_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimInt_val, &g_heff_2eelab_2ememoed_2eprimInt_st, g_heff_2eelab_2ememoed_2eprimInt_init);
}
V g_heff_2eelab_2ememoed_2eprimInt_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
}
V g_heff_2eelab_2ememoed_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimFloat_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimFloat_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimFloat_st;
static V g_heff_2eelab_2ememoed_2eprimFloat_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimFloat), ((V)&g_heff_2eelab_2ememoed_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimFloat_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimFloat_st)) return g_heff_2eelab_2ememoed_2eprimFloat_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimFloat_val, &g_heff_2eelab_2ememoed_2eprimFloat_st, g_heff_2eelab_2ememoed_2eprimFloat_init);
}
V g_heff_2eelab_2ememoed_2eprimFloat_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
}
V g_heff_2eelab_2ememoed_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimString_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimString_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimString_st;
static V g_heff_2eelab_2ememoed_2eprimString_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimString), ((V)&g_heff_2eelab_2ememoed_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimString_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimString_st)) return g_heff_2eelab_2ememoed_2eprimString_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimString_val, &g_heff_2eelab_2ememoed_2eprimString_st, g_heff_2eelab_2ememoed_2eprimString_init);
}
V g_heff_2eelab_2ememoed_2eprimString_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
}
V g_heff_2eelab_2ememoed_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimRune_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimRune_st;
static V g_heff_2eelab_2ememoed_2eprimRune_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimRune), ((V)&g_heff_2eelab_2ememoed_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimRune_st)) return g_heff_2eelab_2ememoed_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimRune_val, &g_heff_2eelab_2ememoed_2eprimRune_st, g_heff_2eelab_2ememoed_2eprimRune_init);
}
V g_heff_2eelab_2ememoed_2eprimRune_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
}
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_entry, 7, 0};

V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(V v_lit_240, V v_lit_241, V v_implicit_242, V v_dflt_243, V v_g_244, V v_vs_245, V v_dom_246) {
top: ;
  V v_stx_247 = heff_take_field(v_dom_246, 0);
  V v_val_248 = heff_get_n(v_dom_246, 1, 2);
  V v_val_249 = heff_take_field(v_lit_241, 1);
  V v_stx_2410 = heff_get_n(v_lit_241, 0, 2);
  V v_x1_2411 = heff_tr(heff_call(heff_dup(v_val_249), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_t_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2412); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2413 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2413); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_t_2416 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2415, v_stx_247, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_stx_2410)}), heff_dup(v_implicit_242), heff_dup(v_dflt_243)});
  return heff_rec_n(2, shape_stx__val, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam0, 1, 8, (V[]){v_val_249, v_val_248, v_lit_240, v_vs_245, v_g_244, v_stx_2410, v_implicit_242, v_dflt_243})});
}
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam1(V self, V *args) {
  V v_vs2_2428 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_stx_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_244, NTAG(TAG_N), v_stx_2410, v_vs2_2428));
}
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_val_249 = heff_env(self)[0];
  V v_val_248 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_vs_245 = heff_env(self)[3];
  V v_g_244 = heff_env(self)[4];
  V v_stx_2410 = heff_env(self)[5];
  V v_implicit_242 = heff_env(self)[6];
  V v_dflt_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_u_2417);
  V v_x1_2418 = heff_tr(heff_call(v_val_249, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_t_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2419); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2420 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2420); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2421); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_x1_2423 = heff_tr(heff_call(v_val_248, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2427;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2424;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2423, 0ULL, 1);
    v_t_2427 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  V v_t_2429 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2422, v_t_2427, heff_tag_n(TAG_MkClo, 3, (V[]){v_lit_240, v_vs_245, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_lam1, 1, 2, (V[]){v_g_244, v_stx_2410})}), v_implicit_242, v_dflt_243, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2429});
}
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(V v_lit_240, V v_lit_241, V v_c_242, V v_g_243, V v_vs_244, V v_gdom_245) {
top: ;
  V v_stx_246 = heff_take_field(v_gdom_245, 0);
  V v_val_247 = heff_get_n(v_gdom_245, 1, 2);
  V v_t_248 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_lit_240), heff_dup(heff_rfield(v_lit_241, 0))});
  V v_f_249 = heff_tag_n(TAG_SLam, 2, (V[]){v_stx_246, v_t_248});
  return ((HeffT2){{v_f_249, heff_clo_n(g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam0, 1, 6, (V[]){v_val_247, v_lit_240, v_vs_244, v_g_243, v_c_242, v_lit_241})}});
}
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam1(V self, V *args) {
  V v_u2_2411 = args[0];
  V v_val_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2411);
  V v_x1_2412 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2413;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam2(V self, V *args) {
  V v_vs2_2416 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_243, v_c_242, heff_get_n(v_lit_241, 0, 2), v_vs2_2416));
}
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_val_247 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_vs_244 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2410);
  V v_x_2417 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam1, 1, 1, (V[]){v_val_247}), heff_tag_n(TAG_MkClo, 3, (V[]){v_lit_240, v_vs_244, heff_clo_n(g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr_lam2, 1, 3, (V[]){v_g_243, heff_dup(v_c_242), v_lit_241})})});
  switch (heff_tag_of(v_c_242)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2417});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_c_242);
  }
}
Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry, 6, 0};

V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V v_lit_240, V v_lit_241, V v_c_242, V v_g_243, V v_vs_244, V v_gdom_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(v_lit_240, v_lit_241, v_c_242, v_g_243, v_vs_244, v_gdom_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_rec_n(2, shape_stx__val, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(a[0], a[1], a[2], a[3], a[4], a[5]);
}