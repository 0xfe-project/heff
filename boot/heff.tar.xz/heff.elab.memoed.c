// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCons 58684
#define TAG_SFunction 64505
#define TAG_SImplicit 59448
#define TAG_SLam 1658
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_stx 323761
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
HeffT2 g_heff_2eelab_2ememoed_2eapp_24cpr(V, V);
V g_heff_2eelab_2ememoed_2econs(V, V);
V g_heff_2eelab_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2econs_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ememoed_2erecordM(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2erecordM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2erecordM_clo;
V g_heff_2eelab_2ememoed_2especializeM(V, V, V);
V g_heff_2eelab_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2especializeM_clo;
V g_heff_2eelab_2ememoed_2esumM(V);
V g_heff_2eelab_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2esumM_clo;
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834(V);
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eprojAt_24tok1(V, V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2ememoed_2eapp_24cpr(V v_g0_240, V v_g1_241) {
top: ;
  V v_stx_242 = heff_take_field(v_g1_241, 0);
  V v_val_243 = heff_get_n(v_g1_241, 1, 2);
  V v_stx_244 = heff_take_field(v_g0_240, 0);
  V v_val_245 = heff_get_n(v_g0_240, 1, 2);
  V v_f_246 = heff_tag_n(TAG_SApp, 2, (V[]){v_stx_244, v_stx_242});
  return ((HeffT2){{v_f_246, heff_clo_n(g_heff_2eelab_2ememoed_2eapp_24cpr_lam0, 1, 2, (V[]){v_val_243, v_val_245})}});
}
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam2(V self, V *args) {
  V v_u2_249 = args[0];
  V v_val_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_249);
  V v_x1_2410 = heff_tr(heff_call(v_val_243, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_x_2411;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam1(V self, V *args) {
  V v_f_248 = args[0];
  V v_val_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_248, heff_clo_n(g_heff_2eelab_2ememoed_2eapp_24cpr_lam2, 1, 1, (V[]){v_val_243})));
}
V g_heff_2eelab_2ememoed_2eapp_24cpr_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_val_243 = heff_env(self)[0];
  V v_val_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_247);
  V v_f_2414 = heff_clo_n(g_heff_2eelab_2ememoed_2eapp_24cpr_lam1, 1, 1, (V[]){v_val_243});
  V v_x2_2415 = heff_tr(heff_call(v_val_245, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    V f_ = v_f_2414;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Describe: {
    V v_x_2417 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    V f_ = v_f_2414;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Become = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    V v_x1_2419 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_x_2418}));
    V v_t_2423;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nom: {
      V v_x_2420 = heff_field(v_x1_2419, 0);
      heff_take_n(v_x1_2419, 1ULL, 1);
      v_t_2423 = v_x_2420;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2419, 0ULL, 1);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2422 = heff_field(v_x1_2419, 0);
      heff_take_n(v_x1_2419, 1ULL, 1);
      v_t_2423 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag_at_n(v_ru_24x2_2415_24Become, TAG_Become, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2eelab_2ememoed_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eapp_entry, 2, 0};

V g_heff_2eelab_2ememoed_2eapp(V v_g0_240, V v_g1_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2ememoed_2eapp_24cpr(v_g0_240, v_g1_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_rec_n(2, shape_stx__val, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eapp(a[0], a[1]);
}
V g_heff_2eelab_2ememoed_2eiapp_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2eiapp_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2eiapp_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eiapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eiapp_entry, 3, 0};

V g_heff_2eelab_2ememoed_2eiapp(V v_x_240, V v_g0_241, V v_g1_242) {
top: ;
  V v_stx_243 = heff_take_field(v_g1_242, 0);
  V v_val_244 = heff_get_n(v_g1_242, 1, 2);
  V v_stx_245 = heff_take_field(v_g0_241, 0);
  V v_val_246 = heff_get_n(v_g0_241, 1, 2);
  V v_t_247 = heff_tag_n(TAG_SApp, 2, (V[]){v_stx_245, heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_240, v_stx_243})});
  return heff_rec_n(2, shape_stx__val, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam0, 1, 2, (V[]){v_val_244, v_val_246})});
}
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eiapp(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ememoed_2eiapp_lam2(V self, V *args) {
  V v_u2_2410 = args[0];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2410);
  V v_x1_2411 = heff_tr(heff_call(v_val_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_x_2412;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_x_2414;
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2eelab_2ememoed_2eiapp_lam1(V self, V *args) {
  V v_f_249 = args[0];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_249, heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam2, 1, 1, (V[]){v_val_244})));
}
V g_heff_2eelab_2ememoed_2eiapp_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_val_244 = heff_env(self)[0];
  V v_val_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_248);
  V v_f_2415 = heff_clo_n(g_heff_2eelab_2ememoed_2eiapp_lam1, 1, 1, (V[]){v_val_244});
  V v_x2_2416 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nom: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    V f_ = v_f_2415;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Describe: {
    V v_x_2418 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    V f_ = v_f_2415;
    args[0] = v_x_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Become: {
    V v_x_2419 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Become = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    V v_x1_2420 = heff_tr(heff_call(v_f_2415, 1, (V[]){v_x_2419}));
    V v_t_2424;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nom: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 1);
      v_t_2424 = v_x_2421;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2424 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2423 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 1);
      v_t_2424 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    return heff_tag_at_n(v_ru_24x2_2416_24Become, TAG_Become, 1, (V[]){v_t_2424});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam4(V self, V *args);
V g_heff_2eelab_2ememoed_2elam_lam3(V self, V *args);
Clo g_heff_2eelab_2ememoed_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2elam_entry, 5, 0};

V g_heff_2eelab_2ememoed_2elam(V v_c_240, V v_g_241, V v_vs_242, V v_gdom_243, V v_x5_244) {
top: ;
  V v_stx_245 = heff_take_field(v_gdom_243, 0);
  V v_val_246 = heff_get_n(v_gdom_243, 1, 2);
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkAbs: {
    V v_x_247 = heff_field(v_x5_244, 0);
    V v_gbody_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkAbs = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24x5_244_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_247), heff_dup(heff_rfield(v_gbody_248, 0))});
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_stx_245, v_t_249}), heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam0, 1, 6, (V[]){v_val_246, v_x_247, v_vs_242, v_g_241, v_c_240, v_gbody_248})});
  }
  case TAG_AbsConst: {
    V v_gbody_2418 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24AbsConst = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_g_241);
    heff_drop(v_vs_242);
    V v_stx_2419 = heff_take_field(v_gbody_2418, 0);
    V v_val_2420 = heff_get_n(v_gbody_2418, 1, 2);
    V v_t_2421 = heff_tag_n(TAG_SLam, 2, (V[]){v_stx_245, heff_tag_at_n(v_ru_24x5_244_24AbsConst, TAG_AbsConst, 1, (V[]){v_stx_2419})});
    return heff_rec_n(2, shape_stx__val, (V[]){v_t_2421, heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam3, 1, 3, (V[]){v_val_2420, v_val_246, v_c_240})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2elam(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2ememoed_2elam_lam1(V self, V *args) {
  V v_u2_2411 = args[0];
  V v_val_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2411);
  V v_x1_2412 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2413;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam2(V self, V *args) {
  V v_vs2_2416 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_gbody_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, v_c_240, heff_get_n(v_gbody_248, 0, 2), v_vs2_2416));
}
V g_heff_2eelab_2ememoed_2elam_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_c_240 = heff_env(self)[4];
  V v_gbody_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2410);
  V v_x_2417 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam1, 1, 1, (V[]){v_val_246}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_247, v_vs_242, heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam2, 1, 3, (V[]){v_g_241, heff_dup(v_c_240), v_gbody_248})})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2417});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam4(V self, V *args) {
  V v_u2_2424 = args[0];
  V v_val_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2424);
  V v_x1_2425 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Nom: {
    V v_x_2426 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    return v_x_2426;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2428 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    return v_x_2428;
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2eelab_2ememoed_2elam_lam3(V self, V *args) {
  V v_u_2422 = args[0];
  V v_val_2420 = heff_env(self)[0];
  V v_val_246 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_call(v_val_2420, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x_2429 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2ememoed_2elam_lam4, 1, 1, (V[]){v_val_246}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2423})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2429});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2429});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2ememoed_2econs_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2econs_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2econs_lam1(V self, V *args);
Clo g_heff_2eelab_2ememoed_2econs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2econs_entry, 2, 0};

V g_heff_2eelab_2ememoed_2econs(V v_c_240, V v_d_241) {
top: ;
  V v_keys_242 = heff_take_field(v_d_241, 0);
  V v_byName_243 = heff_take_field(v_d_241, 1);
  V v_values_244 = heff_get_n(v_d_241, 2, 3);
  V v_xs_245 = heff_dup(v_values_244);
  V v_t_248 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_245, 0), heff_clo_n(g_heff_2eelab_2ememoed_2econs_lam0, 1, 1, (V[]){v_xs_245}));
  V v_t_249 = heff_tag_n(TAG_SCons, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(v_keys_242), heff_dup(v_byName_243), v_t_248})});
  return heff_rec_n(2, shape_stx__val, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2ememoed_2econs_lam1, 1, 4, (V[]){v_values_244, v_keys_242, v_byName_243, heff_dup(v_c_240)})});
}
V g_heff_2eelab_2ememoed_2econs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ememoed_2econs(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2ememoed_2econs_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_xs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_247 = heff_arrayIndex(v_xs_245, v_i_246);
  return heff_get_n(v_m_247, 0, 2);
}
V g_heff_2eelab_2ememoed_2econs_lam2(V self, V *args) {
  V v_i_2412 = args[0];
  V v_xs_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2413 = heff_arrayIndex(v_xs_2411, v_i_2412);
  V f_ = heff_get_n(v_m_2413, 1, 2);
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2ememoed_2econs_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_values_244 = heff_env(self)[0];
  V v_keys_242 = heff_env(self)[1];
  V v_byName_243 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2410);
  V v_xs_2411 = v_values_244;
  V v_t_2414 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2411, 0), heff_clo_n(g_heff_2eelab_2ememoed_2econs_lam2, 1, 1, (V[]){v_xs_2411}));
  V v_x_2415 = heff_tag_n(TAG_VCons, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_242, v_byName_243, v_t_2414})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2415});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2415});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2ememoed_2eproj_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2eproj_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eproj_entry, 2, 0};

V g_heff_2eelab_2ememoed_2eproj(V v_g_240, V v_x_241) {
top: ;
  V v_stx_242 = heff_take_field(v_g_240, 0);
  V v_val_243 = heff_get_n(v_g_240, 1, 2);
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_stx_242, heff_dup(v_x_241)}), heff_clo_n(g_heff_2eelab_2ememoed_2eproj_lam0, 1, 2, (V[]){v_x_241, v_val_243})});
}
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eproj(a[0], a[1]);
}
V g_heff_2eelab_2ememoed_2eproj_lam1(V self, V *args) {
  V v_v_245 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_245)) {
  case TAG_VNeu: {
    V v_t_2411 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_245));
    return ({ V a_0 = v_t_2411; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VCode: {
    V v_t_2413 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_245));
    return ({ V a_0 = v_t_2413; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VLam: {
    V v_t_2416 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_245));
    return ({ V a_0 = v_t_2416; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VCons: {
    V v_t_2418 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_245));
    return ({ V a_0 = v_t_2418; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_245);
  }
}
V g_heff_2eelab_2ememoed_2eproj_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_val_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_244);
  V v_f_2419 = heff_clo_n(g_heff_2eelab_2ememoed_2eproj_lam1, 1, 1, (V[]){v_x_241});
  V v_x2_2420 = heff_tr(heff_call(v_val_243, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    heff_take_n(v_x2_2420, 1ULL, 1);
    V f_ = v_f_2419;
    args[0] = v_x_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Describe: {
    V v_x_2422 = heff_field(v_x2_2420, 0);
    heff_take_n(v_x2_2420, 1ULL, 1);
    V f_ = v_f_2419;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x2_2420, 0);
    V v_ru_24x2_2420_24Become = heff_take_reuse_n(v_x2_2420, 1ULL, 1);
    V v_x1_2424 = heff_tr(heff_call(v_f_2419, 1, (V[]){v_x_2423}));
    V v_t_2428;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_Nom: {
      V v_x_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2425;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2424, 0ULL, 1);
      v_t_2428 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2427 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2427;
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    return heff_tag_at_n(v_ru_24x2_2420_24Become, TAG_Become, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2eelab_2ememoed_2eprojAt_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprojAt_entry, 3, 0};

V g_heff_2eelab_2ememoed_2eprojAt(V v_g_240, V v_x_241, V v_a_242) {
top: ;
  V v_stx_243 = heff_take_field(v_g_240, 0);
  V v_val_244 = heff_get_n(v_g_240, 1, 2);
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_stx_243, heff_dup(v_x_241)}), heff_clo_n(g_heff_2eelab_2ememoed_2eprojAt_lam0, 1, 3, (V[]){v_val_244, v_x_241, v_a_242})});
}
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ememoed_2eprojAt_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_val_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_245);
  V v_x2_246 = heff_tr(heff_call(v_val_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Nom = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eprojAt_24tok1(v_ru_24x2_246_24Nom, v_x_247, v_x_241, v_a_242));
  }
  case TAG_Describe: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Describe = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eprojAt_24tok1(v_ru_24x2_246_24Describe, v_x_248, v_x_241, v_a_242));
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Become = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    V v_x1_2410 = (g_heff_2eelab_2evalue_2eprojAt(v_x_249, v_x_241, v_a_242));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Nom: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      v_t_2414 = v_x_2411;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_2414 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2413 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    return heff_tag_at_n(v_ru_24x2_246_24Become, TAG_Become, 1, (V[]){v_t_2414});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eelab_2ememoed_2especializeM_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2especializeM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2especializeM_entry, 3, 0};

V g_heff_2eelab_2ememoed_2especializeM(V v_g_240, V v_x_241, V v_g_27_242) {
top: ;
  V v_stx_243 = heff_take_field(v_g_27_242, 0);
  V v_val_244 = heff_get_n(v_g_27_242, 1, 2);
  V v_stx_245 = heff_take_field(v_g_240, 0);
  V v_val_246 = heff_get_n(v_g_240, 1, 2);
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_stx_245, heff_dup(v_x_241), v_stx_243}), heff_clo_n(g_heff_2eelab_2ememoed_2especializeM_lam0, 1, 3, (V[]){v_val_246, v_val_244, v_x_241})});
}
V g_heff_2eelab_2ememoed_2especializeM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2especializeM(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ememoed_2especializeM_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_val_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_247);
  V v_x1_248 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_x1_2413 = heff_tr(heff_call(v_val_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2414;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2417 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2418 = (g_heff_2eelab_2evalue_2especialize(v_t_2412, v_x_241, v_t_2417));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2418});
}
V g_heff_2eelab_2ememoed_2eabandonM_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eabandonM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eabandonM_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eabandonM_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eabandonM_st;
static V g_heff_2eelab_2ememoed_2eabandonM_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2ememoed_2eabandonM_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eabandonM_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eabandonM_st)) return g_heff_2eelab_2ememoed_2eabandonM_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eabandonM_val, &g_heff_2eelab_2ememoed_2eabandonM_st, g_heff_2eelab_2ememoed_2eabandonM_init);
}
V g_heff_2eelab_2ememoed_2eabandonM_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V v_implicit_240, V v_dflt_241, V v_g_242, V v_vs_243, V v_dom_244, V v_x6_245) {
top: ;
  V v_stx_246 = heff_take_field(v_dom_244, 0);
  V v_val_247 = heff_get_n(v_dom_244, 1, 2);
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkAbs: {
    V v_x_248 = heff_field(v_x6_245, 0);
    V v_body_249 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkAbs = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_val_2410 = heff_take_field(v_body_249, 1);
    V v_stx_2411 = heff_get_n(v_body_249, 0, 2);
    V v_x1_2412 = heff_tr(heff_call(heff_dup(v_val_2410), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_t_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2413); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2414 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2414); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    V v_f_2417 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2416, v_stx_246, heff_tag_at_n(v_ru_24x6_245_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_248), heff_dup(v_stx_2411)}), heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return ((HeffT2){{v_f_2417, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0, 1, 8, (V[]){v_val_2410, v_val_247, v_x_248, v_vs_243, v_g_242, v_stx_2411, v_implicit_240, v_dflt_241})}});
  }
  case TAG_AbsConst: {
    V v_body_2431 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24AbsConst = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    heff_drop(v_g_242);
    heff_drop(v_vs_243);
    V v_val_2432 = heff_take_field(v_body_2431, 1);
    V v_stx_2433 = heff_get_n(v_body_2431, 0, 2);
    V v_x1_2434 = heff_tr(heff_call(heff_dup(v_val_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2438;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nom: {
      V v_t_2435 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2435); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2436 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2436); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2437 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      v_t_2438 = ({ V a_0 = v_t_2437; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    V v_f_2439 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2438, v_stx_246, heff_tag_at_n(v_ru_24x6_245_24AbsConst, TAG_AbsConst, 1, (V[]){v_stx_2433}), heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return ((HeffT2){{v_f_2439, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2, 1, 4, (V[]){v_val_2432, v_val_247, v_implicit_240, v_dflt_241})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x6_245)}});
  }
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1(V self, V *args) {
  V v_vs2_2429 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_stx_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_242, NTAG(TAG_N), v_stx_2411, v_vs2_2429));
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_val_2410 = heff_env(self)[0];
  V v_val_247 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  V v_g_242 = heff_env(self)[4];
  V v_stx_2411 = heff_env(self)[5];
  V v_implicit_240 = heff_env(self)[6];
  V v_dflt_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_u_2418);
  V v_x1_2419 = heff_tr(heff_call(v_val_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nom: {
    V v_t_2420 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2420); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2421 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2421); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2422 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2419);
  }
  V v_x1_2424 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nom: {
    V v_x_2425 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_t_2428 = v_x_2425;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    v_t_2428 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  V v_t_2430 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2423, v_t_2428, heff_tag_n(TAG_MkClo, 3, (V[]){v_x_248, v_vs_243, heff_clo_n(g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam1, 1, 2, (V[]){v_g_242, v_stx_2411})}), v_implicit_240, v_dflt_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2430});
}
V g_heff_2eelab_2ememoed_2efunctionD_24cpr_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_val_2432 = heff_env(self)[0];
  V v_val_247 = heff_env(self)[1];
  V v_implicit_240 = heff_env(self)[2];
  V v_dflt_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2440);
  V v_x1_2441 = heff_tr(heff_call(heff_dup(v_val_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_t_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2442; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2442); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2443 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2443; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2443); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2444); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_x1_2446 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2450;
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x1_2446);
  }
  V v_t_2451 = heff_tr(heff_call(v_val_2432, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2452 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2445, v_t_2450, heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2451}), v_implicit_240, v_dflt_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2452});
}
Clo g_heff_2eelab_2ememoed_2efunctionD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2efunctionD_entry, 6, 0};

V g_heff_2eelab_2ememoed_2efunctionD(V v_implicit_240, V v_dflt_241, V v_g_242, V v_vs_243, V v_dom_244, V v_x6_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2eelab_2ememoed_2efunctionD_24cpr(v_implicit_240, v_dflt_241, v_g_242, v_vs_243, v_dom_244, v_x6_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_rec_n(2, shape_stx__val, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2efunctionD(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2ememoed_2erecordM_lam2(V self, V *args);
V g_heff_2eelab_2ememoed_2erecordM_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2erecordM_lam0(V self, V *args);
Clo g_heff_2eelab_2ememoed_2erecordM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2erecordM_entry, 5, 0};

V g_heff_2eelab_2ememoed_2erecordM(V v_g_240, V v_vs_241, V v_level_242, V v_fieldTypes_243, V v_defaults_244) {
top: ;
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){heff_dup(v_level_242), heff_dup(v_fieldTypes_243), heff_dup(v_defaults_244)}), heff_clo_n(g_heff_2eelab_2ememoed_2erecordM_lam0, 1, 5, (V[]){v_fieldTypes_243, v_g_240, v_level_242, v_vs_241, v_defaults_244})});
}
V g_heff_2eelab_2ememoed_2erecordM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2erecordM(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2ememoed_2erecordM_lam2(V self, V *args) {
  V v_vs2_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_248, v_vs2_249));
  V v_t_2416;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2416 = v_x_2413;
    } else {
      if ((v_tag_2411 == ((int64_t)1ULL))) {
        V v_x11_2414 = v_field_2412;
        heff_drop(v_x11_2414);
        v_t_2416 = heff_abandon();
      } else {
        V v_x_2415 = v_field_2412;
        v_t_2416 = v_x_2415;
      }
    }
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2416, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2ememoed_2erecordM_lam1(V self, V *args) {
  V v_i_247 = args[0];
  V v_xs_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_arrayIndex(v_xs_246, v_i_247);
  return heff_clo_n(g_heff_2eelab_2ememoed_2erecordM_lam2, 1, 2, (V[]){v_g_240, v_t_248});
}
V g_heff_2eelab_2ememoed_2erecordM_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_fieldTypes_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_level_242 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_defaults_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_245);
  V v_xs_246 = heff_take_field(v_fieldTypes_243, 2);
  V v_t_2417 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_246, 0), heff_clo_n(g_heff_2eelab_2ememoed_2erecordM_lam1, 1, 2, (V[]){v_xs_246, v_g_240}));
  V v_t_2418 = ({ V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_fieldTypes_243, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_242, v_vs_241, v_t_2418, v_defaults_244})});
}
V g_heff_2eelab_2ememoed_2esumM_lam1(V self, V *args);
V g_heff_2eelab_2ememoed_2esumM_lam0(V self, V *args);
V g_heff_2eelab_2ememoed_2esumM_lam2(V self, V *args);
Clo g_heff_2eelab_2ememoed_2esumM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2esumM_entry, 1, 0};

V g_heff_2eelab_2ememoed_2esumM(V v_st_240) {
top: ;
  V v_xs_241 = heff_dup(heff_rfield(v_st_240, 2));
  V v_t_246 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_241, 0), heff_clo_n(g_heff_2eelab_2ememoed_2esumM_lam0, 1, 1, (V[]){v_xs_241}));
  V v_t_247 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_246});
  return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_t_247}), heff_clo_n(g_heff_2eelab_2ememoed_2esumM_lam2, 1, 1, (V[]){v_st_240})});
}
V g_heff_2eelab_2ememoed_2esumM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ememoed_2esumM(a[0]);
}
V g_heff_2eelab_2ememoed_2esumM_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_xs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_245 = heff_arrayIndex(v_xs_243, v_i_244);
  return heff_get_n(v_m_245, 0, 2);
}
V g_heff_2eelab_2ememoed_2esumM_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_xs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_243 = heff_arrayIndex(v_xs_241, v_i_242);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_243, 0), heff_clo_n(g_heff_2eelab_2ememoed_2esumM_lam1, 1, 1, (V[]){v_xs_243}));
}
V g_heff_2eelab_2ememoed_2esumM_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_t_249 = (g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834(v_st_240));
  return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_249})});
}
V g_heff_2eelab_2ememoed_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimInt_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimInt_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimInt_st;
static V g_heff_2eelab_2ememoed_2eprimInt_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimInt), ((V)&g_heff_2eelab_2ememoed_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimInt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimInt_st)) return g_heff_2eelab_2ememoed_2eprimInt_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimInt_val, &g_heff_2eelab_2ememoed_2eprimInt_st, g_heff_2eelab_2ememoed_2eprimInt_init);
}
V g_heff_2eelab_2ememoed_2eprimInt_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
}
V g_heff_2eelab_2ememoed_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimFloat_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimFloat_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimFloat_st;
static V g_heff_2eelab_2ememoed_2eprimFloat_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimFloat), ((V)&g_heff_2eelab_2ememoed_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimFloat_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimFloat_st)) return g_heff_2eelab_2ememoed_2eprimFloat_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimFloat_val, &g_heff_2eelab_2ememoed_2eprimFloat_st, g_heff_2eelab_2ememoed_2eprimFloat_init);
}
V g_heff_2eelab_2ememoed_2eprimFloat_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
}
V g_heff_2eelab_2ememoed_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimString_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimString_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimString_st;
static V g_heff_2eelab_2ememoed_2eprimString_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimString), ((V)&g_heff_2eelab_2ememoed_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimString_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimString_st)) return g_heff_2eelab_2ememoed_2eprimString_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimString_val, &g_heff_2eelab_2ememoed_2eprimString_st, g_heff_2eelab_2ememoed_2eprimString_init);
}
V g_heff_2eelab_2ememoed_2eprimString_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
}
V g_heff_2eelab_2ememoed_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2ememoed_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ememoed_2eprimRune_lam0, 1, 0};

static V g_heff_2eelab_2ememoed_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2ememoed_2eprimRune_st;
static V g_heff_2eelab_2ememoed_2eprimRune_init(void) {
  return heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SPrimRune), ((V)&g_heff_2eelab_2ememoed_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2ememoed_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2ememoed_2eprimRune_st)) return g_heff_2eelab_2ememoed_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2ememoed_2eprimRune_val, &g_heff_2eelab_2ememoed_2eprimRune_st, g_heff_2eelab_2ememoed_2eprimRune_init);
}
V g_heff_2eelab_2ememoed_2eprimRune_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
}