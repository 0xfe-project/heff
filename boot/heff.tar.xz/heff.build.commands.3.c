// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_PathStatus 29154
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_bin 307073
#define LBL_bytes 295582853
#define LBL_copies 592412158
#define LBL_emits 297985818
#define LBL_errors 652506774
#define LBL_fuel 9649789
#define LBL_groups 709681407
#define LBL_heff 9694020
#define LBL_jss 315076
#define LBL_memo 9843201
#define LBL_modified 129625309
#define LBL_mods 9852536
#define LBL_modules 1459291593
#define LBL_olds 9909235
#define LBL_output 941629484
#define LBL_paths 307797256
#define LBL_size 10026184
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_sure 10037468
#define LBL_works 314677148
static uint32_t shape_groups__copies__emits__jss__works[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss, LBL_works};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_clo;
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_clo;
V g_heff_2ebuild_2ecommands_2elinkOf(V);
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkOf_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249(V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_u_247;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ecommands_2erunProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunProgram_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunProgram(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam1(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      heff_take_n(v_y_2414, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_241;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      HeffT2 v_t_2417 = ({ V a_0 = v_x_2416; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_x_2416); r_; });
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        V v_x_2427;
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x_2412_24Right, 1);
          V v_p_2420 = v_field_2419;
          heff_drop(v_p_2420);
          v_x_2427 = NTAG(TAG_Nothing);
        } else {
          V v_x_2421 = v_field_2419;
          HeffT2 v_t_2422 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x_2412_24Right, 1);
              V v_x_2425 = v_field_2424;
              heff_drop(v_x_2425);
              v_x_2427 = NTAG(TAG_Nothing);
            } else {
              V v_p_2426 = v_field_2424;
              v_x_2427 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_2426, 1, 4)});
            }
          }
        }
        heff_clo_take(self, 1);
        V f_ = v_k_241;
        args[0] = v_x_2427;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_242));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam1_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_lam2, 1, 1, (V[]){v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_247), v_d_246));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_247), heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_str0))));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_s_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam2, 2, 4, (V[]){v_a_2415, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_x_2429}), v_x_2431});
  V f_ = v_k_2417;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_m_244 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_m_244);
    V v_t_2425 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(v_ps_240, v_rest_245));
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2426 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    switch (heff_tag_of(v_y_2426)) {
    case TAG_Left: {
      heff_take_n(v_y_2426, 0ULL, 1);
      heff_clo_take(self, 5);
      heff_drop(v_m_244);
      V v_t_2428 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(v_ps_240, v_rest_245));
      V f_ = v_t_2428;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_y_2426, 0);
      heff_take_n(v_y_2426, 1ULL, 1);
      heff_clo_take(self, 5);
      V v_t_2430 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(v_ps_240, v_rest_245));
      V f_ = v_t_2430;
      heff_room[0] = v_hd_2416;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam4, 1, 3, (V[]){v_m_244, v_x_2429, v_k_2417});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2426);
    }
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_a_2415 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2422, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_2416, v_k_2417, v_m_244})));
}
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449(V v_path_240, V v_p_241, V v_z_242, V v_z_243) {
top: ;
  V v_sure_244 = heff_take_field(v_p_241, 2);
  V v_memo_245 = heff_get_n(v_p_241, 1, 3);
  V v_t_246 = v_sure_244;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
    V v_a_2410 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_248, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam0_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2415, v_z_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam1, 1, 2, (V[]){v_memo_245, v_z_243})));
  } else {
    heff_drop(v_path_240);
    heff_drop(v_z_242);
    heff_drop(v_memo_245);
    heff_drop(v_t_246);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_False)});
  }
}
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2ekeptOnDisk_24s1806198285x1639195449_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_memo_245 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    heff_take_n(v_x_2416, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2418 = v_memo_245;
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_2418, 0ULL, 1);
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V f_ = v_z_243;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      heff_take_n(v_y_2421, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2423 = v_memo_245;
      V v_t_2425;
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        v_t_2425 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2423, 0ULL, 1);
        v_t_2425 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      V f_ = v_z_243;
      args[0] = v_t_2425;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2426 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      V v_size_2427 = heff_take_field(v_x_2426, 1);
      V v_modified_2428 = heff_get_n(v_x_2426, 2, 4);
      heff_clo_take(self, 2);
      V v_t_2429 = v_memo_245;
      V v_t_2433;
      switch (heff_tag_of(v_t_2429)) {
      case TAG_Nothing: {
        heff_drop(v_size_2427);
        heff_drop(v_modified_2428);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_m_2430 = heff_field(v_t_2429, 0);
        heff_take_n(v_t_2429, 1ULL, 1);
        V v_bytes_2431 = heff_take_field(v_m_2430, 9);
        V v_modified_2432 = heff_get_n(v_m_2430, 10, 11);
        v_t_2433 = heff_bool((heff_intEq_c_lent(v_size_2427, v_bytes_2431, 0) && heff_intEq_c_lent(v_modified_2428, v_modified_2432, 0)));
        heff_drop(v_size_2427);
        heff_drop(v_modified_2428);
        heff_drop(v_bytes_2431);
        heff_drop(v_modified_2432);
        break;
      }
      default: heff_nomatch(v_t_2429);
      }
      V f_ = v_z_243;
      args[0] = v_t_2433;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str2, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_errors_245 = heff_take_field(v_o_242, 1);
  V v_source_246 = heff_get_n(v_o_242, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(heff_dup(v_errors_245), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam0, 1, 6, (V[]){v_errors_245, v_outPath_240, v_source_246, v_hd_243, v_k_244, v_done_241})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam1(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_done_241);
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str1));
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    switch (heff_tag_of(v_y_2434)) {
    case TAG_Left: {
      V v_ru_24y_2434_24Left = heff_take_reuse_n(v_y_2434, 0ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_done_241);
      V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str2), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_str3));
      V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
      V v_t_2438 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2434_24Left, TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
    }
    case TAG_Right: {
      heff_take_n(v_y_2434, 0ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_outPath_240);
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      V f_ = v_done_241;
      heff_room[0] = v_hd_243;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2434);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_245 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_source_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_done_241 = heff_env(self)[5];
  heff_drop(v_x_247);
  heff_clo_take(self, 6);
  V v_t_248 = v_errors_245;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_240)));
    V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
    V v_a_2412 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2410, v_source_246, ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam1_clo)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2417, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471_lam2, 1, 4, (V[]){v_outPath_240, v_hd_243, v_k_244, v_done_241})));
  }
  case TAG_Cons: {
    V v_ru_24t_248_24Cons = heff_take_reuse_n(v_t_248, 0ULL, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_source_246);
    heff_drop(v_done_241);
    V v_t_2453 = heff_tag_at_n(v_ru_24t_248_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_str1, 4, ".zig");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice_lent(v_outPath_240, heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0), 6);
  V v_t_249;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_249 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_248), 6);
  } else {
    v_t_249 = heff_dup(v_outPath_240);
  }
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_str1))));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
  V v_a_2413 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2411, v_zig_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam0_clo)});
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam1, 2, 3, (V[]){v_a_2413, v_outPath_240, v_done_242}), v_o_243, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_x_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    heff_clo_take(self, 4);
    return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(v_outPath_240, v_hd_2414, v_k_2415, v_done_242, heff_tag_re_n(v_ru_24x_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2422})));
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Left: {
      V v_err_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24Left = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2421_24Right, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(v_outPath_240, v_hd_2414, v_k_2415, v_done_242, heff_tag_re_n(v_ru_24y_2423_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2424})));
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_2ek_24l0(v_outPath_240, v_hd_2414, v_k_2415, v_done_242, heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Right, 1, (V[]){v_x_2425})));
    }
    default: return heff_nomatch(v_y_2423);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_a_2413 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2420, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_lam2, 1, 4, (V[]){v_outPath_240, v_hd_2414, v_k_2415, v_done_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str3, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_groups_249 = heff_take_field(v_out_246, 1);
  V v_copies_2410 = heff_take_field(v_out_246, 2);
  V v_jss_2411 = heff_take_field(v_out_246, 3);
  V v_output_2412 = heff_get_n(v_out_246, 0, 4);
  V v_paths_2413 = heff_take_field(v_bi_240, 0);
  V v_modules_2414 = heff_get_n(v_bi_240, 2, 4);
  V v_t_2450;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str0), 2)) {
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    heff_drop(v_groups_249);
    heff_drop(v_copies_2410);
    heff_drop(v_jss_2411);
    heff_drop(v_paths_2413);
    heff_drop(v_modules_2414);
    v_t_2450 = v_done_245;
  } else {
    V v_s_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2413)));
    V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2415));
    V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2416); r_; });
    V v_a_2419 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam0_clo)});
    v_t_2450 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam1, 2, 10, (V[]){v_a_2419, heff_dup(v_texts_243), v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s973781264x77604471(v_outPath_241, v_t_2450, v_output_2412, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam0(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_drop(v_x_2434);
  heff_clo_take(self, 3);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_drop(v_x_2442);
  heff_clo_take(self, 3);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_drop(v_x_2449);
  heff_clo_take(self, 3);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_modules_2414 = heff_env(self)[1];
  V v_groups_249 = heff_env(self)[2];
  V v_copies_2410 = heff_env(self)[3];
  V v_jss_2411 = heff_env(self)[4];
  V v_id_242 = heff_env(self)[5];
  V v_backs_244 = heff_env(self)[6];
  V v_paths_2413 = heff_env(self)[7];
  V v_hd_2420 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  V v_k_2421 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_clo_take(self, 11);
    V v_t_2429 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_243); r_; });
    V v_t_2430 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str1), NTAG(TAG_MkUnit)));
    V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_modules_2414; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2414); r_; });
    V v_t_2432 = heff_rec_n(5, shape_groups__copies__emits__jss__works, (V[]){v_groups_249, v_copies_2410, NTAG(TAG_Nil), v_jss_2411, NTAG(TAG_Nil)});
    V v_t_2433 = ({ V a_0 = v_id_242; V b_1 = heff_rec_n(2, shape_mods__olds, (V[]){v_t_2431, v_backs_244}); V a_2 = v_t_2432; V r_ = (g_heff_2ebuild_2ebackcache_2ebackTexts(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    return ({ V a_0 = v_paths_2413; V a_1 = v_t_2429; V a_2 = v_t_2433; V a_3 = heff_dup(v_hd_2420); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam3, 1, 3, (V[]){v_done_245, v_hd_2420, v_k_2421}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2429); heff_drop(v_t_2433); r_; });
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    switch (heff_tag_of(v_y_2435)) {
    case TAG_Left: {
      heff_take_n(v_y_2435, 0ULL, 1);
      heff_clo_take(self, 11);
      V v_t_2437 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_243); r_; });
      V v_t_2438 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str2), NTAG(TAG_MkUnit)));
      V v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = v_modules_2414; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2414); r_; });
      V v_t_2440 = heff_rec_n(5, shape_groups__copies__emits__jss__works, (V[]){v_groups_249, v_copies_2410, NTAG(TAG_Nil), v_jss_2411, NTAG(TAG_Nil)});
      V v_t_2441 = ({ V a_0 = v_id_242; V b_1 = heff_rec_n(2, shape_mods__olds, (V[]){v_t_2439, v_backs_244}); V a_2 = v_t_2440; V r_ = (g_heff_2ebuild_2ebackcache_2ebackTexts(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      return ({ V a_0 = v_paths_2413; V a_1 = v_t_2437; V a_2 = v_t_2441; V a_3 = heff_dup(v_hd_2420); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam4, 1, 3, (V[]){v_done_245, v_hd_2420, v_k_2421}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2437); heff_drop(v_t_2441); r_; });
    }
    case TAG_Right: {
      heff_take_n(v_y_2435, 0ULL, 1);
      heff_clo_take(self, 11);
      V v_t_2444 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_243); r_; });
      V v_t_2445 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_str3), NTAG(TAG_MkUnit)));
      V v_t_2446 = ({ V a_0 = v_t_2445; V a_1 = v_modules_2414; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2414); r_; });
      V v_t_2447 = heff_rec_n(5, shape_groups__copies__emits__jss__works, (V[]){v_groups_249, v_copies_2410, NTAG(TAG_Nil), v_jss_2411, NTAG(TAG_Nil)});
      V v_t_2448 = ({ V a_0 = v_id_242; V b_1 = heff_rec_n(2, shape_mods__olds, (V[]){v_t_2446, v_backs_244}); V a_2 = v_t_2447; V r_ = (g_heff_2ebuild_2ebackcache_2ebackTexts(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      return ({ V a_0 = v_paths_2413; V a_1 = v_t_2444; V a_2 = v_t_2448; V a_3 = heff_dup(v_hd_2420); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam5, 1, 3, (V[]){v_done_245, v_hd_2420, v_k_2421}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2444); heff_drop(v_t_2448); r_; });
    }
    default: return heff_nomatch(v_y_2435);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_a_2419 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_modules_2414 = heff_env(self)[2];
  V v_groups_249 = heff_env(self)[3];
  V v_copies_2410 = heff_env(self)[4];
  V v_jss_2411 = heff_env(self)[5];
  V v_id_242 = heff_env(self)[6];
  V v_backs_244 = heff_env(self)[7];
  V v_paths_2413 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2426, heff_dup(v_hd_2420), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_lam2, 1, 11, (V[]){v_texts_243, v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_hd_2420, v_done_245, v_k_2421})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_checked_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_str0), heff_dup(v_sources_241)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam0, 1, 10, (V[]){v_sources_241, v_checked_247, v_bi_240, v_z_248, heff_dup(v_badL_246), v_z_249, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953(a[0], a[1], a[2], a3, a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam1(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = ({ V a_0 = v_c_2414; V a_1 = v_sources_241; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_241); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2418 = v_field_2417;
      V v_t_2419 = ({ V a_0 = v_x_2413; V a_1 = v_s_2418; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2413); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2419));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_cs_2422 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_sources_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_drop(v_x_2423);
  if ((heff_dup(v_badL_246) == NTAG(TAG_True))) {
    heff_clo_take(self, 10);
    heff_drop(v_badL_246);
    heff_drop(v_cs_2422);
    heff_drop_rec(v_bi_240, 4);
    heff_drop(v_sources_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_z_248, v_z_249));
  } else {
    heff_clo_take(self, 10);
    heff_drop(v_badL_246);
    V v_t_2430 = (g_list_2eany_24s1740858080x874135214(v_cs_2422));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_cs_2422);
      heff_drop_rec(v_bi_240, 4);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_t_2430);
      V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_z_248, v_z_249));
    } else {
      heff_drop(v_t_2430);
      return ({ V a_0 = v_bi_240; V a_1 = v_sources_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_cs_2422; V a_7 = v_z_248; V a_8 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); heff_drop(v_cs_2422); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_checked_247 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_badL_246 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  V v_t_2412 = (g_list_2emap_24s159228909x554161698(((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_str1), heff_dup(v_sources_241), v_x_2411, heff_dup(v_sources_241)));
  V v_x_2413 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2412));
  heff_clo_take(self, 10);
  V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam1, 1, 2, (V[]){heff_dup(v_sources_241), v_x_2413}), v_checked_247));
  V v_t_2421 = heff_dup(heff_rfield(v_bi_240, 3));
  V v_cs_2422;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_cs_2422 = v_x_2420;
  } else {
    heff_drop(v_t_2421);
    v_cs_2422 = (g_list_2emap_24s107931167x1978109134(v_x_2420));
  }
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2422), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_lam2, 1, 10, (V[]){v_badL_246, v_z_248, v_z_249, v_cs_2422, v_bi_240, v_sources_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str0, 24, "putting the programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str1, 24, "putting the programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str2, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(V v_st_240, V v_t_241, V v_next_242, V v_progs_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam1, 2, 5, (V[]){v_a_247, heff_dup(v_progs_243), v_t_241, heff_dup(v_st_240), v_next_242});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam3(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_drop(v_x_2427);
  heff_clo_take(self, 3);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2422, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam6, 1, 3, (V[]){v_next_242, v_hd_2423, v_k_2424})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2422; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam5, 2, 2, (V[]){heff_dup(v_x_2422), v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2422); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2428;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam7(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam10(V self, V *args) {
  V v_x_2441 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2437 = heff_env(self)[1];
  V v_k_2438 = heff_env(self)[2];
  heff_drop(v_x_2441);
  heff_clo_take(self, 3);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2437;
  heff_room[1] = v_k_2438;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam9(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_End, 2, (V[]){v_x_2436, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_2437), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam10, 1, 3, (V[]){v_next_242, v_hd_2437, v_k_2438})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2442 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2436; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam9, 2, 2, (V[]){heff_dup(v_x_2436), v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2436); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2442;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam11(V self, V *args) {
  V v_t_2446 = args[0];
  return v_t_2446;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam14(V self, V *args) {
  V v_x_2454 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_drop(v_x_2454);
  heff_clo_take(self, 3);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2450;
  heff_room[1] = v_k_2451;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam13(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_x_2449 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_tag_n(TAG_End, 2, (V[]){v_x_2449, NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), heff_dup(v_hd_2450), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam14, 1, 3, (V[]){v_next_242, v_hd_2450, v_k_2451})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam12(V self, V *args) {
  V v_x_2449 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2455 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2449; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam13, 2, 2, (V[]){heff_dup(v_x_2449), v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2449); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2455;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    V v_total_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str0), heff_dup(heff_rfield(v_t_241, 1)));
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2415_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2418, v_total_2417, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam3_clo)})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    heff_clo_take(self, 6);
    return (g_co_2eop_24s535099379x685970669(v_t_2421, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam4, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_248, v_k_249})));
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Left: {
      V v_ru_24y_2429_24Left = heff_take_reuse_n(v_y_2429, 0ULL, 1);
      V v_total_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
      V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str1), heff_dup(heff_rfield(v_t_241, 1)));
      V v_t_2434 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2432, v_total_2431, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam7_clo)})});
      V v_t_2435 = heff_tag_at_n(v_ru_24y_2429_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      heff_clo_take(self, 6);
      return (g_co_2eop_24s535099379x685970669(v_t_2435, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam8, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_248, v_k_249})));
    }
    case TAG_Right: {
      V v_ru_24y_2429_24Right = heff_take_reuse_n(v_y_2429, 0ULL, 1);
      V v_total_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
      V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_str2), heff_dup(heff_rfield(v_t_241, 1)));
      V v_t_2447 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2445, v_total_2444, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam11_clo)})});
      V v_t_2448 = heff_tag_at_n(v_ru_24y_2429_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
      heff_clo_take(self, 6);
      return (g_co_2eop_24s535099379x685970669(v_t_2448, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam12, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_248, v_k_249})));
    }
    default: return heff_nomatch(v_y_2429);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_lam2, 1, 6, (V[]){v_progs_243, v_t_241, v_hd_248, v_st_240, v_next_242, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249(V v_outPath_240, V v_flags_241) {
top: ;
  switch (heff_tag_of(v_flags_241)) {
  case TAG_Nil: {
    V v_s_242 = (g_heff_2ebuild_2ecommands_2elinkOf(v_outPath_240));
    V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_242));
    V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
    V v_a_246 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam1, 2, 1, (V[]){v_a_246});
  }
  case TAG_Cons: {
    V v_s_2421 = (g_heff_2ebuild_2ecommands_2elinkOf(heff_dup(v_outPath_240)));
    V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2421));
    V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
    V v_a_2425 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam3_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam4, 2, 3, (V[]){v_a_2425, v_outPath_240, v_flags_241});
  }
  default: return heff_nomatch(v_flags_241);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_248 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_248;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Left: {
      heff_take_n(v_y_2416, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2416, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2416);
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2413, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam2, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam3(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_flags_241 = heff_env(self)[1];
  V v_hd_2426 = heff_env(self)[2];
  V v_k_2427 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_x_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2426; V a_3 = v_k_2427; V a_4 = heff_tag_re_n(v_ru_24x_2433_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2434}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_flags_241, 2); r_; });
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    switch (heff_tag_of(v_y_2435)) {
    case TAG_Left: {
      V v_err_2436 = heff_field(v_y_2435, 0);
      V v_ru_24y_2435_24Left = heff_take_reuse_n(v_y_2435, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2433_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2426; V a_3 = v_k_2427; V a_4 = heff_tag_re_n(v_ru_24y_2435_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2436}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_flags_241, 2); r_; });
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_y_2435, 0);
      heff_take_n(v_y_2435, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2426; V a_3 = v_k_2427; V a_4 = heff_tag_at_n(v_ru_24x_2433_24Right, TAG_Right, 1, (V[]){v_x_2437}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_flags_241, 2); r_; });
    }
    default: return heff_nomatch(v_y_2435);
    }
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_a_2425 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_flags_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2432, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_lam5, 1, 4, (V[]){v_outPath_240, v_flags_241, v_hd_2426, v_k_2427})));
}