// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_copies 592412158
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_library 398066429
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_segments 1801007612
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_units 312791945
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s1572002051x1780290637(V, V, V, V, V);
V g_co_2eop_24s1572002051x1780290637_entry(V self, V *a);
extern Clo g_co_2eop_24s1572002051x1780290637_clo;
V g_co_2eop_24s719845521x2133218584(V, V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s719845521x2133218584_entry(V self, V *a);
extern Clo g_co_2eop_24s719845521x2133218584_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo;
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517(V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750(V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2efindRunnable(V, V, V);
V g_heff_2ebuild_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindRunnable_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind_24s1230956425x1562898054(V, V);
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a);
extern Clo g_list_2efind_24s1230956425x1562898054_clo;
V g_list_2efoldl_24f1048217315x1968986417(V, V, V);
V g_list_2efoldl_24f1048217315x1968986417_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1048217315x1968986417_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1842223007x322637159(V, V);
V g_list_2efoldl_24s1842223007x322637159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1842223007x322637159_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s671692426x586469947(V, V);
V g_list_2efoldl_24s671692426x586469947_entry(V self, V *a);
extern Clo g_list_2efoldl_24s671692426x586469947_clo;
V g_list_2efoldl_24s809624008x2043497973(V, V);
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a);
extern Clo g_list_2efoldl_24s809624008x2043497973_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1819215186x476901667(V, V, V, V);
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s170418522x132668694(V);
V g_list_2emap_24s170418522x132668694_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_clo;
V g_map_2eempty_get(void);
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(v_x_243), v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f1048217315x1968986417(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = heff_intShow(heff_intSub(v_t_243, v_t_244));
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1), heff_intShow(v_t_246));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2), heff_strAppend(v_t_245, v_t_247));
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str3, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c_lent(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0), 2)) {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get_n(v_t_244, 2, 3);
      V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        return v_x_247;
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    case TAG_Just: {
      V v_pwd_249 = heff_field(v_x3_242, 0);
      heff_drop(v_dir_241);
      V v_t_2410 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_pwd_249)));
      V v_xs_2411 = heff_get_n(v_t_2410, 2, 3);
      V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 2);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  } else {
    V v_t_2415 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2416 = heff_get_n(v_t_2415, 2, 3);
    V v_x1_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str3);
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 2);
      return v_x_2418;
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str3, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args) {
  V v_d_2416 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_src_2415 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = (g_heff_2elsp_2erender_2ediagWhere(heff_get_n(v_c_243, 1, 13), heff_dup(v_src_2415), heff_dup(v_d_2416)));
  V v_t_2418 = ({ V a_0 = v_x_248; V a_1 = v_src_2415; V a_2 = v_d_2416; V r_ = (g_heff_2elsp_2erender_2erenderDiag(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1)));
  return heff_strAppend(v_t_2417, v_t_2419);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_dup(heff_rfield(v_c_243, 6));
  V v_t_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_249, 0ULL, 2);
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_c_2428;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_drop_rec(v_c_243, 13);
    heff_drop(v_t_2412);
    v_c_2428 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo);
  } else {
    heff_drop(v_t_2412);
    V v_src_2415 = heff_dup(heff_rfield(v_c_243, 3));
    V v_x2_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3, 1, 3, (V[]){heff_dup(v_c_243), v_src_2415, v_x_248}), heff_get_n(v_c_243, 6, 13)));
    V v_str_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_str_2423 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_str_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_str_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    v_c_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2427}));
  }
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badLoad_240)})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2416);
  if ((heff_dup(v_badLoad_240) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_240);
    heff_drop(v_cs_241);
    V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, v_hd_242, v_k_243));
  } else {
    heff_drop(v_badLoad_240);
    V v_t_2421 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_242, v_k_243));
    } else {
      heff_drop(v_hd_242);
      heff_drop(v_t_2421);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badLoad_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2410 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_str_2411 = (g_heff_2ebuild_2edriver_2einterface(v_c_2410));
    V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})));
  }
  default: return heff_nomatch(v_t_245);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_241;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6, 1, 1, (V[]){v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    V v_t_2417 = (g_std_2epath_2ejoin(v_st_249, v_x_242, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3)));
    V v_t_2418 = ({ V a_0 = v_st_249; V a_1 = v_t_2417; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_249); r_; });
    V v_str_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5), v_t_2418);
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2419, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6)), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_text_2430 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_drop(v_st_249);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_text_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_249;
  if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0))) {
    v_st_249 = NTAG(TAG_Windows);
  } else {
    v_st_249 = NTAG(TAG_Posix);
  }
  V v_t_2410 = (g_std_2epath_2ejoin(v_st_249, heff_dup(v_x_242), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1)));
  V v_path_2411 = (g_std_2epath_2ejoin(v_st_249, v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2)));
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4, 1, 4, (V[]){v_st_249, v_x_242, v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str2, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_d_243 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0)));
  V v_path_244 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_243, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0, 2, 4, (V[]){v_path_244, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V f_ = v_k_246;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V v_d_2412 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_take_field(v_ps_240, 0), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1)));
  V v_d_2413 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2412, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_2414 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2413; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str2); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2415 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str3), v_b_241));
  return (g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(v_t_2414, v_t_2415, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3, 1, 2, (V[]){v_k_246, v_id_242})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_244, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_245, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(V v_l_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str0), heff_dup(heff_rfield(v_l_240, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam0, 1, 7, (V[]){v_l_240, v_hd_245, v_k_246, v_file_243, v_name_241, v_outPath_242, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_sources_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = heff_dup(v_c_2412); V a_1 = v_sources_2410; V r_ = (g_list_2efind_24s1230956425x1562898054(a_0, a_1)); heff_drop(v_sources_2410); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_x_2411);
    return v_c_2412;
  }
  case TAG_Just: {
    V v_s_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = ({ V a_0 = v_x_2411; V a_1 = v_s_2414; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2411); r_; });
    return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2412, v_t_2415));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_l_240 = heff_env(self)[5];
  V v_file_243 = heff_env(self)[6];
  V v_name_241 = heff_env(self)[7];
  V v_outPath_242 = heff_env(self)[8];
  V v_done_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2417);
  if (heff_intLt_c(MK_INT(0LL), v_x_247)) {
    heff_drop(v_x_2416);
    heff_drop_rec(v_x_249, 2);
    heff_drop_rec(v_l_240, 5);
    heff_drop(v_file_243);
    heff_drop(v_name_241);
    heff_drop(v_outPath_242);
    heff_drop(v_done_244);
    V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_245, v_k_246));
  } else {
    V v_t_2423 = (g_list_2eany_24s1996724342x1838336560(v_x_2416));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2416);
      heff_drop_rec(v_x_249, 2);
      heff_drop_rec(v_l_240, 5);
      heff_drop(v_file_243);
      heff_drop(v_name_241);
      heff_drop(v_outPath_242);
      heff_drop(v_done_244);
      heff_drop(v_t_2423);
      V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      return (g_co_2eop_24s954557541x749476273(v_t_2427, v_hd_245, v_k_246));
    } else {
      heff_drop(v_t_2423);
      V v_t_2428 = (g_list_2emap_24s170418522x132668694(heff_take_field(v_x_249, 0)));
      V v_t_2429 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_240, 2), heff_get_n(v_x_249, 1, 2), v_t_2428});
      return ({ V a_0 = v_t_2429; V b_1 = heff_get_n(v_l_240, 0, 5); V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V a_6 = v_x_2416; V a_7 = v_hd_245; V a_8 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(b_1); heff_drop(v_x_2416); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_name_241 = heff_env(self)[5];
  V v_outPath_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sources_2410 = heff_dup(heff_rfield(v_l_240, 0));
  V v_x_2411 = (g_list_2emap_24f1819215186x476901667(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_str2), heff_dup(v_sources_2410)));
  V v_x_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam2, 1, 2, (V[]){v_sources_2410, v_x_2411}), heff_dup(heff_rfield(v_x_249, 0))));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_x_2416), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam3, 1, 10, (V[]){v_x_247, v_hd_245, v_k_246, v_x_2416, v_x_249, v_l_240, v_file_243, v_name_241, v_outPath_242, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_l_240)));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_lam1, 1, 8, (V[]){v_l_240, v_hd_245, v_x_247, v_k_246, v_file_243, v_name_241, v_outPath_242, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str1, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str2, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str5, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str6, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str7, 8, "heff run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str8, 3, "-O1");
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750(V v_file_240, V v_progArgs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_progArgs_241});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam2(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam4(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_cmd_2423 = heff_env(self)[0];
  V v_progArgs_241 = heff_env(self)[1];
  V v_hd_2427 = heff_env(self)[2];
  V v_k_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2423, v_progArgs_241, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s954557541x749476273(v_t_2434, v_hd_2427, v_k_2428));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam7(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_248 = heff_env(self)[0];
  V v_cmd_2423 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2429 = heff_tag_n(TAG_End, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2429}), heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam8, 1, 4, (V[]){v_cmd_2423, v_progArgs_241, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_t_2413 = heff_env(self)[3];
  V v_t_2418 = heff_env(self)[4];
  V v_cmd_2423 = heff_env(self)[5];
  V v_progArgs_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s719845521x2133218584(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str7), v_x_245, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str8), heff_dup(v_x_248), v_t_2413, v_t_2418, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam7, 2, 3, (V[]){v_x_248, v_cmd_2423, v_progArgs_241}), heff_dup(v_hd_2424), v_k_2425, heff_tag_n(TAG_InL, 1, (V[]){v_t_2426}), v_hd_2424));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam5(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_t_2413 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_paths_2414 = heff_dup(heff_rfield(v_x_245, 2));
  V v_d_2415 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2414), heff_dup(v_file_240)));
  V v_t_2416 = heff_dup(heff_rfield(v_paths_2414, 5));
  V v_t_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Posix: {
    v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str1);
    break;
  }
  case TAG_Windows: {
    v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str2);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2418 = ({ V b_0 = heff_get_n(v_paths_2414, 5, 6); V a_1 = v_d_2415; V a_2 = v_t_2417; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_paths_2419 = heff_dup(heff_rfield(v_x_245, 2));
  V v_d_2420 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2419), heff_dup(v_file_240)));
  V v_t_2421 = heff_dup(heff_rfield(v_paths_2419, 5));
  V v_t_2422;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Posix: {
    v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str4);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_cmd_2423 = ({ V b_0 = heff_get_n(v_paths_2419, 5, 6); V a_1 = v_d_2420; V a_2 = v_t_2422; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return (g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(heff_dup(v_x_245), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str5)}), heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str6)), v_file_240, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam6, 2, 7, (V[]){v_x_2411, v_x_245, v_x_248, v_t_2413, v_t_2418, v_cmd_2423, v_progArgs_241}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_248), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam4_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam5, 1, 6, (V[]){v_x_245, v_file_240, v_x_248, v_progArgs_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_240), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam3, 1, 5, (V[]){v_hd_243, v_x_245, v_file_240, v_progArgs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s731882315x500924750_lam1, 1, 4, (V[]){v_file_240, v_hd_243, v_progArgs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    return (g_co_2eop_24s1572002051x1780290637(v_rest_244, heff_dup(v_p_241), v_p_242, v_t_248, v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V v_seed_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_seed_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_src_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_src_2412 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_src_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_j_2413 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str1), v_src_2412, MK_INT(0LL), 5);
  V v_t_2415;
  if (heff_intLt_c(heff_dup(v_j_2413), MK_INT(0LL))) {
    heff_drop(v_j_2413);
    v_t_2415 = heff_strLength_lent(v_src_2412, 0);
  } else {
    v_t_2415 = v_j_2413;
  }
  V v_t_2416 = heff_strEq(heff_strSlice(v_src_2412, MK_INT(0LL), v_t_2415), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = v_t_2416; V a_3 = v_x_2410; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2416); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_249 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2, 1, 5, (V[]){v_x_248, v_seed_240, v_f_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_host_240);
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(heff_dup(v_host_240), v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam1, 2, 3, (V[]){v_c_246, v_s_244, v_host_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 7), v_x_249});
  } else {
    heff_drop(v_x_2413);
    heff_drop_rec(v_s_244, 7);
    v_t_2414 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_dup(heff_rfield(v_s_244, 6));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_str0))) {
      return (g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272(v_host_240, heff_dup(v_s_244), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248})));
    } else {
      heff_drop_rec(v_s_244, 7);
      heff_drop(v_host_240);
      heff_drop(v_hd_247);
      V f_ = v_k_248;
      args[0] = v_x_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_s_244, 7);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    heff_drop(v_t_2410);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam0, 1, 8, (V[]){v_bi_240, v_hd_246, v_c_243, heff_dup(v_available_244), v_r_245, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_r_245 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(heff_dup(v_x_248), v_x_2414));
  V v_t_2416 = heff_get_n(heff_get_n(v_c_243, 5, 13), 0, 9);
  V v_m_2417 = (g_heff_2ebuild_2ecommands_2ebacksOf(heff_dup(v_x_248), v_x_2414));
  V v_t_2418 = ({ V a_0 = v_m_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2417); r_; });
  V v_bs_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1842223007x322637159(heff_dup(g_map_2eempty_get()), v_bs_2419));
  V v_t_2421 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2419; V r_ = (g_list_2efoldl_24s809624008x2043497973(a_0, a_1)); heff_drop(v_bs_2419); r_; });
  V v_m_2422 = (g_heff_2ebuild_2ecommands_2ebacksOf(heff_dup(v_x_248), v_x_2414));
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_bs_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2424; V r_ = (g_list_2efoldl_24s671692426x586469947(a_0, a_1)); heff_drop(v_bs_2424); r_; });
  V v_t_2426 = ({ V a_0 = v_available_244; V a_1 = v_t_2416; V a_2 = heff_take_field(v_r_245, 0); V a_3 = heff_get_n(v_r_245, 1, 2); V a_4 = heff_dup(heff_rfield(v_bi_240, 1)); V a_5 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2420, v_t_2421}); V a_6 = v_t_2425; V r_ = (g_heff_2ecompile_2eemit_2ecompileProgramKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_available_244); heff_drop(v_t_2425); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_248; V a_3 = v_x_2414; V a_4 = v_t_2415; V a_5 = v_done_242; V a_6 = v_t_2426; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_available_244 = heff_env(self)[3];
  V v_r_245 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2412));
  }
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598_lam2, 1, 9, (V[]){v_x_248, v_c_243, v_available_244, v_r_245, v_bi_240, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(heff_rfield(v_c_245, 7))));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
  V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2416));
  V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; V r_ = (g_heff_2ebuild_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Left: {
    V v_why_2420 = heff_field(v_t_2419, 0);
    V v_ru_24t_2419_24Left = heff_take_reuse_n(v_t_2419, 1ULL, 1);
    heff_drop(v_bi_240);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop_rec(v_c_245, 13);
    V v_t_2421 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str0), v_why_2420));
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str1), v_t_2421), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str2));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_at_n(v_ru_24t_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
  }
  case TAG_Right: {
    V v_r_2432 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    heff_drop(v_file_241);
    return (g_heff_2ebuild_2ecommands_2ejsKept_24s1976755583x1962061598(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2432, v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_245, heff_dup(heff_rfield(v_o_249, 1))));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_249, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2411 = heff_field(v_t_2410, 0);
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
    V v_t_2412 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_249, 0), heff_get_n(v_o_249, 1, 2), v_eff_2411});
    return heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1(V self, V *args) {
  V v_k_2417 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2417; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_str0, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_checked_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517(((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_str0), heff_dup(v_sources_241), v_checked_247));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0, 1, 9, (V[]){v_z_248, heff_dup(v_badL_246), v_z_249, v_bi_240, v_sources_241, v_file_242, v_name_243, v_outPath_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_sources_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2412);
  if ((heff_dup(v_badL_246) == NTAG(TAG_True))) {
    heff_drop(v_badL_246);
    heff_drop(v_x_2411);
    heff_drop(v_bi_240);
    heff_drop(v_sources_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(v_t_2416, v_z_248, v_z_249));
  } else {
    heff_drop(v_badL_246);
    V v_t_2417 = (g_list_2eany_24s1996724342x1838336560(v_x_2411));
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_x_2411);
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_t_2417);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s954557541x749476273(v_t_2421, v_z_248, v_z_249));
    } else {
      heff_drop(v_t_2417);
      return ({ V a_0 = v_bi_240; V a_1 = v_sources_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_x_2411; V a_7 = v_z_248; V a_8 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_sources_241); heff_drop(v_x_2411); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_badL_246 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_bi_240 = heff_env(self)[3];
  V v_sources_241 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_x_2411), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam1, 1, 10, (V[]){v_badL_246, v_z_248, v_z_249, v_x_2411, v_bi_240, v_sources_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0, 1, 5, (V[]){v_cs_243, v_hd_244, v_k_245, heff_dup(v_badL_242), v_outPath_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_badL_242 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    V v_t_248 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2413;
    if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      v_t_2413 = NTAG(TAG_True);
    } else {
      heff_drop(v_badL_242);
      v_t_2413 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_243); r_; });
    }
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 0, 9);
    V v_t_2415 = (g_list_2emap_24s1234524601x742515152(heff_get_n(v_c_2412, 7, 13)));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2414, v_t_2415));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2413; V a_2 = v_t_2416; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2420, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4, 1, 3, (V[]){v_x_2420, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0))) {
    v_t_2414 = NTAG(TAG_Windows);
  } else {
    v_t_2414 = NTAG(TAG_Posix);
  }
  V v_path_2415 = ({ V a_0 = v_t_2414; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_f_246); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V v_chk_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1, 2, 3, (V[]){v_c_247, v_chk_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_chk_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_chk_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2, 1, 4, (V[]){v_chk_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2412, 0ULL, 1);
    v_t_2414 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_242;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}