// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_absolute 325777132
#define LBL_copies 592412158
#define LBL_diags 296935042
#define LBL_drive 297211300
#define LBL_effect 641056956
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_segments 1801007612
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_units 312791945
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackD(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackD_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunPath(V, V);
V g_heff_2ebuild_2ecommands_2erunPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunPath_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo;
V g_heff_2ebuild_2edecoder_2erun(V, V);
V g_heff_2ebuild_2edecoder_2erun_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2erun_clo;
V g_heff_2ebuild_2edecoder_2ewhole(V, V, V);
V g_heff_2ebuild_2edecoder_2ewhole_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewhole_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
V g_list_2eany_24s4993167x1503961568(V);
V g_list_2eany_24s4993167x1503961568_entry(V self, V *a);
extern Clo g_list_2eany_24s4993167x1503961568_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1130343625x1326436643(V, V, V);
V g_list_2efoldl_24f1130343625x1326436643_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1130343625x1326436643_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1842223007x322637159(V, V);
V g_list_2efoldl_24s1842223007x322637159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1842223007x322637159_clo;
V g_list_2efoldl_24s616126380x659562620(V, V);
V g_list_2efoldl_24s616126380x659562620_entry(V self, V *a);
extern Clo g_list_2efoldl_24s616126380x659562620_clo;
V g_list_2efoldl_24s951167157x158080085(V, V);
V g_list_2efoldl_24s951167157x158080085_entry(V self, V *a);
extern Clo g_list_2efoldl_24s951167157x158080085_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1052938345x548264065(V, V, V, V, V);
V g_list_2emap_24s1052938345x548264065_entry(V self, V *a);
extern Clo g_list_2emap_24s1052938345x548264065_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(v_x_243), v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str2, 4, ".mjs");
Clo g_heff_2ebuild_2ecommands_2erunPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunPath_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunPath(V v_paths_240, V v_file_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_240)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_x2_244 = ({ V a_0 = heff_take_field(v_p_243, 1); V b_1 = heff_get_n(v_p_243, 2, 3); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2erunPath_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunPath_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return (g_heff_2ebuild_2eload_2eunder(v_paths_240, v_t_242, heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2erunPath_str2))));
}
V g_heff_2ebuild_2ecommands_2erunPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunPath(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f1130343625x1326436643(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = heff_intShow(heff_intSub(v_t_243, v_t_244));
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1), heff_intShow(v_t_246));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2), heff_strAppend(v_t_245, v_t_247));
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str3, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0))) {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get_n(v_t_244, 2, 3);
      V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
      V v_x2_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_x2_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_x2_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        return v_x_2410;
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Just: {
      V v_pwd_2411 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      heff_drop(v_dir_241);
      V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_pwd_2411));
      V v_xs_2413 = heff_get_n(v_t_2412, 2, 3);
      V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
      V v_x2_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        v_x2_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 2);
        v_x2_2417 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        heff_take_n(v_x2_2417, 1ULL, 1);
        return v_x_2418;
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  } else {
    heff_drop(v_x3_242);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2420 = heff_get_n(v_t_2419, 2, 3);
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    V v_x2_2424;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_x2_2424 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_x2_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str3);
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      return v_x_2425;
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 71, "-- Node.js program of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Node` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str3, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args) {
  V v_d_2416 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_src_2415 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = (g_heff_2elsp_2erender_2ediagWhere(heff_get_n(v_c_243, 1, 13), heff_dup(v_src_2415), heff_dup(v_d_2416)));
  V v_t_2418 = ({ V a_0 = v_x_248; V a_1 = v_src_2415; V a_2 = v_d_2416; V r_ = (g_heff_2elsp_2erender_2erenderDiag(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1)));
  return heff_strAppend(v_t_2417, v_t_2419);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_dup(heff_rfield(v_c_243, 6));
  V v_t_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_249, 0ULL, 2);
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_c_2428;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_drop_rec(v_c_243, 13);
    heff_drop(v_t_2412);
    v_c_2428 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo);
  } else {
    heff_drop(v_t_2412);
    V v_src_2415 = heff_dup(heff_rfield(v_c_243, 3));
    V v_x2_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3, 1, 3, (V[]){heff_dup(v_c_243), v_src_2415, v_x_248}), heff_get_n(v_c_243, 6, 13)));
    V v_str_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_str_2423 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_str_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_str_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    v_c_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2427}));
  }
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badLoad_240)})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2416);
  if ((heff_dup(v_badLoad_240) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_240);
    heff_drop(v_cs_241);
    V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, v_hd_242, v_k_243));
  } else {
    heff_drop(v_badLoad_240);
    V v_t_2421 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s4993167x1503961568(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_242, v_k_243));
    } else {
      heff_drop(v_hd_242);
      heff_drop(v_t_2421);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badLoad_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2410 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_str_2411 = (g_heff_2ebuild_2edriver_2einterface(v_c_2410));
    V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})));
  }
  default: return heff_nomatch(v_t_245);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_path_243 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0, 2, 4, (V[]){v_path_243, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_k_245;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_t_2412 = (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0)));
  V v_t_2413 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1), v_b_241));
  return (g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(v_t_2412, v_t_2413, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3, 1, 2, (V[]){v_k_245, v_id_242})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726(V v_bi_240, V v_host_241, V v_outPath_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_c_244, v_host_241, heff_dup(v_available_245), v_r_246, v_outPath_242, v_done_243, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_p_2417 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_p_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_text_2423;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_text_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2ebackD_clo), 1, (V[]){v_x_249}));
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2ewhole_clo), 1, (V[]){v_t_2424}));
  V v_x2_2426 = (g_heff_2ebuild_2edecoder_2erun(v_t_2425, v_text_2423));
  V v_t_2428;
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Nothing: {
    v_t_2428 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x2_2426);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_2420, v_t_2428, v_m_2416));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam4(V self, V *args) {
  V v_m_2431 = args[0];
  V v_p_2432 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_p_2432, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_text_2438;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_y_2437 = heff_field(v_p_2432, 1);
    heff_take_n(v_p_2432, 2ULL, 2);
    v_text_2438 = v_y_2437;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2ebackD_clo), 1, (V[]){v_x_249}));
  V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2ewhole_clo), 1, (V[]){v_t_2439}));
  V v_x2_2441 = (g_heff_2ebuild_2edecoder_2erun(v_t_2440, v_text_2438));
  V v_t_2443;
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_Nothing: {
    v_t_2443 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    heff_take_n(v_x2_2441, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x2_2441);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_2435, v_t_2443, v_m_2431));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam5(V self, V *args) {
  V v_m_2449 = args[0];
  V v_p_2450 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453;
  switch (heff_tag_of(v_p_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_dup(heff_field(v_p_2450, 0));
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_p_2450);
  }
  V v_text_2456;
  switch (heff_tag_of(v_p_2450)) {
  case TAG_MkPair: {
    V v_y_2455 = heff_field(v_p_2450, 1);
    heff_take_n(v_p_2450, 2ULL, 2);
    v_text_2456 = v_y_2455;
    break;
  }
  default: heff_nomatch(v_p_2450);
  }
  V v_t_2457 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2ebackD_clo), 1, (V[]){v_x_249}));
  V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2ewhole_clo), 1, (V[]){v_t_2457}));
  V v_x2_2459 = (g_heff_2ebuild_2edecoder_2erun(v_t_2458, v_text_2456));
  V v_t_2461;
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_Nothing: {
    v_t_2461 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    heff_take_n(v_x2_2459, 1ULL, 1);
    v_t_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x2_2459);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_2453, v_t_2461, v_m_2449));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_host_241 = heff_env(self)[2];
  V v_available_245 = heff_env(self)[3];
  V v_r_246 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_outPath_242 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2429 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam3, 2, 1, (V[]){heff_dup(v_x_249)}), heff_dup(g_map_2eempty_get()), v_x_2415));
  V v_t_2430 = heff_get_n(heff_get_n(v_c_244, 5, 13), 0, 9);
  V v_m_2444 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam4, 2, 1, (V[]){heff_dup(v_x_249)}), heff_dup(g_map_2eempty_get()), v_x_2415));
  V v_t_2445 = ({ V a_0 = v_m_2444; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2444); r_; });
  V v_bs_2446 = (g_list_2emap_24s1173914895x100384474(v_t_2445));
  V v_t_2447 = (g_list_2efoldl_24s1842223007x322637159(heff_dup(g_map_2eempty_get()), v_bs_2446));
  V v_t_2448 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2446; V r_ = (g_list_2efoldl_24s951167157x158080085(a_0, a_1)); heff_drop(v_bs_2446); r_; });
  V v_m_2462 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam5, 2, 1, (V[]){heff_dup(v_x_249)}), heff_dup(g_map_2eempty_get()), v_x_2415));
  V v_t_2463 = ({ V a_0 = v_m_2462; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2462); r_; });
  V v_bs_2464 = (g_list_2emap_24s1173914895x100384474(v_t_2463));
  V v_t_2465 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2464; V r_ = (g_list_2efoldl_24s616126380x659562620(a_0, a_1)); heff_drop(v_bs_2464); r_; });
  V v_t_2466 = ({ V a_0 = v_host_241; V a_1 = v_available_245; V a_2 = v_t_2430; V a_3 = heff_take_field(v_r_246, 0); V a_4 = heff_get_n(v_r_246, 1, 2); V a_5 = heff_dup(heff_rfield(v_bi_240, 1)); V a_6 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2447, v_t_2448}); V a_7 = v_t_2465; V r_ = (g_heff_2ecompile_2eemit_2ecompileProgramKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_available_245); heff_drop(v_t_2465); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_242; V a_2 = v_x_249; V a_3 = v_x_2415; V a_4 = v_t_2429; V a_5 = v_done_243; V a_6 = v_t_2466; V a_7 = v_hd_247; V a_8 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  V v_host_241 = heff_env(self)[3];
  V v_available_245 = heff_env(self)[4];
  V v_r_246 = heff_env(self)[5];
  V v_outPath_242 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c(heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_str0))) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_lam2, 1, 10, (V[]){v_x_249, v_c_244, v_host_241, v_available_245, v_r_246, v_bi_240, v_outPath_242, v_done_243, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str0, 15, "no files given\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893(V v_bi_240, V v_sources_241, V v_host_242, V v_file_243, V v_name_244, V v_outPath_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_247));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_bi_240);
    heff_drop(v_host_242);
    heff_drop(v_file_243);
    heff_drop(v_name_244);
    heff_drop(v_outPath_245);
    heff_drop(v_done_246);
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str0), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam0, 1, 2, (V[]){v_z_248, v_z_249})));
  }
  case TAG_Just: {
    V v_c_2420 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam1, 1, 1, (V[]){heff_dup(v_c_2420)}), heff_dup(heff_rfield(v_c_2420, 7))));
    V v_t_2426 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2425));
    V v_t_2427 = ({ V a_0 = v_t_2426; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2426); r_; });
    V v_t_2428 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2427));
    V v_xs_2429 = (g_list_2emap_24s1052938345x548264065(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str3), v_t_2428));
    V v_t_2430 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2429));
    V v_c_2431 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(v_sources_241, v_t_2430));
    return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam2, 1, 9, (V[]){v_host_242, v_bi_240, v_file_243, v_name_244, v_outPath_245, v_done_246, v_c_2420, v_z_248, v_z_249})});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893(a[0], a1, a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a1); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam1(V self, V *args) {
  V v_o_2421 = args[0];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_2420, heff_dup(heff_rfield(v_o_2421, 1))));
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2421, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2423 = heff_field(v_t_2422, 0);
    V v_ru_24t_2422_24Just = heff_take_reuse_n(v_t_2422, 1ULL, 1);
    V v_t_2424 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2421, 0), heff_get_n(v_o_2421, 1, 2), v_eff_2423});
    return heff_tag_at_n(v_ru_24t_2422_24Just, TAG_Just, 1, (V[]){v_t_2424});
  }
  default: return heff_nomatch(v_t_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam3(V self, V *args) {
  V v_p_2433 = args[0];
  V v_host_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_str4), heff_get_n(v_p_2433, 1, 2), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2435 = (g_list_2emap_24s649333309x1802289391(v_t_2434));
  V v_x1_2436 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nil: {
    heff_drop(v_host_242);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 2);
    return heff_strEq(v_x_2437, v_host_242);
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_host_242 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_244 = heff_env(self)[3];
  V v_outPath_245 = heff_env(self)[4];
  V v_done_246 = heff_env(self)[5];
  V v_c_2420 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2439 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1424051610x123382893_lam3, 1, 1, (V[]){heff_dup(v_host_242)}), v_x_2432));
  return ({ V a_0 = v_bi_240; V a_1 = v_host_242; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = v_done_246; V a_6 = v_c_2420; V a_7 = v_t_2439; V a_8 = v_z_248; V a_9 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_t_2439); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_248, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_rest_244, v_p_241, v_p_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V v_seed_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_seed_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_src_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_src_2412 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_src_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_x2_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_str1), heff_dup(v_src_2412), MK_INT(0LL)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = heff_strLength(heff_dup(v_src_2412));
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2416 = heff_strEq(heff_strSlice(v_src_2412, MK_INT(0LL), v_t_2415), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = v_t_2416; V a_3 = v_x_2410; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2416); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_249 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_lam2, 1, 5, (V[]){v_x_248, v_seed_240, v_f_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0, 1, 5, (V[]){v_cs_243, v_hd_244, v_k_245, heff_dup(v_badL_242), v_outPath_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_badL_242 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    V v_t_248 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2413;
    if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      v_t_2413 = NTAG(TAG_True);
    } else {
      heff_drop(v_badL_242);
      v_t_2413 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s4993167x1503961568(a_0)); heff_drop(v_cs_243); r_; });
    }
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 0, 9);
    V v_t_2415 = (g_list_2emap_24s1234524601x742515152(heff_get_n(v_c_2412, 7, 13)));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2414, v_t_2415));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2413; V a_2 = v_t_2416; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  V f_ = v_k_241;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s954557541x749476273(v_t_2448, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6, 1, 1, (V[]){v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Nothing: {
    V v_t_2427 = (g_std_2epath_2eparse(v_x_249, v_x_242));
    V v_t_2428 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3)));
    V v_p_2429 = (g_std_2epath_2ejoin_2eonto_240(v_t_2427, v_t_2428));
    V v_t_2430 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2429, 1)), heff_rfield(v_p_2429, 2)));
    V v_t_2431 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_p_2429, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_a_2432 = (g_std_2epath_2erender(v_x_249, v_t_2431));
    V v_t_2433 = (g_std_2epath_2eparse(v_x_249, v_a_2432));
    V v_t_2434 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4)));
    V v_p_2435 = (g_std_2epath_2ejoin_2eonto_240(v_t_2433, v_t_2434));
    V v_t_2436 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2435, 1)), heff_rfield(v_p_2435, 2)));
    V v_t_2437 = ({ V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_p_2435, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2438 = ({ V a_0 = v_x_249; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_249); r_; });
    V v_str_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5), v_t_2438);
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2439, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6)), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s954557541x749476273(v_t_2443, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_text_2450 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_text_2450;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_249;
  if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0))) {
    v_x_249 = NTAG(TAG_Windows);
  } else {
    v_x_249 = NTAG(TAG_Posix);
  }
  V v_t_2410 = (g_std_2epath_2eparse(v_x_249, heff_dup(v_x_242)));
  V v_t_2411 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1)));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2412, 1)), heff_rfield(v_p_2412, 2)));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_p_2412, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_a_2415 = (g_std_2epath_2erender(v_x_249, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_249, v_a_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2418, 1)), heff_rfield(v_p_2418, 2)));
  V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_p_2418, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2421 = (g_std_2epath_2erender(v_x_249, v_t_2420));
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2421, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4, 1, 4, (V[]){v_x_249, v_x_242, v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2425, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2426});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4, 1, 3, (V[]){v_x_2425, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0))) {
    v_x_2414 = NTAG(TAG_Windows);
  } else {
    v_x_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_f_246)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_p_2417, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2420 = ({ V a_0 = v_x_2414; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2420, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V v_chk_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1, 2, 3, (V[]){v_c_247, v_chk_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_chk_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_chk_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2, 1, 4, (V[]){v_chk_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2414;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_x_2414 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2412, 0ULL, 1);
    v_x_2414 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_242;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}