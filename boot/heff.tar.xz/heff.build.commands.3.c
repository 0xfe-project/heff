// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_library 398066429
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_outcome 1272833429
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_sources 357464573
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_update 1108295668
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo;
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo;
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2emap_24f1730403549x1479772376(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_clo;
V g_list_2emap_24s320194436x1336304593(V, V);
V g_list_2emap_24s320194436x1336304593_entry(V self, V *a);
extern Clo g_list_2emap_24s320194436x1336304593_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V, V);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_owner_242 = heff_take_field(v_j_240, 0);
  V v_place_243 = heff_take_field(v_j_240, 2);
  V v_top_244 = heff_take_field(v_j_240, 3);
  V v_path_245 = heff_get_n(v_j_240, 4, 6);
  V v_name_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebrokenJob_str0); V a_1 = v_top_244; V a_2 = v_path_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_path_245); r_; });
  V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_248 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_246, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){v_owner_242, v_place_243, v_t_248, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c_lent(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0), 2)) {
    heff_drop(v_dir_241);
    HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(v_st_240, v_x3_242));
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      V v_x11_247 = v_field_244;
      heff_drop(v_x11_247);
      V v_x12_248 = v_field_245;
      heff_drop(v_x12_248);
      V v_xs_249 = v_field_246;
      V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x1_2410, 0);
        heff_take_n(v_x1_2410, 1ULL, 2);
        return v_x_2411;
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
  } else {
    heff_drop(v_x3_242);
    HeffT3 v_t_2413 = (g_std_2epath_2eparse_24cpr(v_st_240, v_dir_241));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_field_2416 = v_t_2413.f[2];
      V v_x11_2417 = v_field_2414;
      heff_drop(v_x11_2417);
      V v_x12_2418 = v_field_2415;
      heff_drop(v_x12_2418);
      V v_xs_2419 = v_field_2416;
      V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 2);
        return v_x_2421;
      }
      default: return heff_nomatch(v_x1_2420);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str5, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str8, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str9, 4, "_app");
Clo g_heff_2ebuild_2ecommands_2enameLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameLike_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2enameLike(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
  V v_x2_242 = (g_list_2emap_24s320194436x1336304593(v_x_240, v_t_241));
  V v_s_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_s_245 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_s_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str2); V a_1 = v_s_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enameLike_str3), v_s_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_245); r_; });
  V v_x2_247 = (g_list_2ekeepIf_24s1552018029x993523539(MK_INT(0LL), v_t_246));
  V v_x_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_x_2410 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_x_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str5); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_x_2411;
  if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str6), 2)) {
    heff_drop(v_x_2410);
    v_x_2411 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str7);
  } else {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_2410, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_2410, MK_INT(0LL), 2)) <= ((int64_t)57ULL)))) {
      v_x_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enameLike_str8), v_x_2410);
    } else {
      v_x_2411 = v_x_2410;
    }
  }
  HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2411));
  V v_t_2416;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    v_t_2416 = heff_bool(((v_tag_2413 == ((int64_t)0ULL)) ? ({ V v_x_2415 = heff_dup(v_field_2414); int c_ = 0; heff_drop(v_x_2415); c_; }) : 1));
    heff_drop(v_field_2414);
  }
  if (((heff_dup(v_t_2416) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(v_x_2411), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get())))) {
    heff_drop(v_t_2416);
    return v_x_2411;
  } else {
    heff_drop(v_t_2416);
    return heff_strAppend(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str9));
  }
}
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameLike(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(V v_rep_240, V v_badLoad_241, V v_cs_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0, 1, 4, (V[]){v_cs_242, v_z_243, heff_dup(v_badLoad_241), v_z_244})});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_badLoad_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2420);
  if ((heff_dup(v_badLoad_241) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_241);
    heff_drop(v_cs_242);
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_243, v_z_244));
  } else {
    heff_drop(v_badLoad_241);
    V v_t_2428 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_243, v_z_244));
    } else {
      heff_drop_rec(v_z_243, 3);
      heff_drop(v_t_2428);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_badLoad_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2410 = v_field_249;
      V v_str_2411 = (g_heff_2ebuild_2edriver_2einterface(v_c_2410));
      V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
      V f_ = heff_dup(heff_rfield(v_z_243, 1));
      heff_room[0] = v_t_2419;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1, 1, 4, (V[]){v_badLoad_241, v_z_243, v_z_244, v_cs_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badLoad_241);
      heff_drop(v_field_249);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, v_z_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_2414}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1, 1, 6, (V[]){heff_dup(v_n_245), heff_dup(v_parts_241), v_dir_240, v_p_243, heff_dup(v_rest_246), v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2433, 0ULL, 1);
    v_t_2436 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V f_ = v_k_2432;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2438);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); heff_drop(v_rest_246); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany_24s130813166x1111413304(v_n_245, v_parts_241));
  V v_c_2437;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_n_245);
    heff_drop(v_st_2417);
    heff_drop(v_t_2418);
    v_c_2437 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2417, heff_dup(v_dir_240)));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2417, v_n_245));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_s_2424 = ({ V a_0 = v_st_2417; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2423); r_; });
    V v_path_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2424; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2426 = ({ V a_0 = v_path_2425; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2425); r_; });
    V v_c_2430 = heff_tr(heff_call(v_c_2426, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3_clo)}));
    v_c_2437 = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4, 2, 1, (V[]){v_c_2430});
  }
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str1, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str2, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str6, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str7, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str8, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(V v_ex_240, V v_argv_241, V v_n_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2414;
  if ((heff_peek_word(v_n_242) == ((int64_t)0ULL))) {
    v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0_clo);
  } else {
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str0), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    v_t_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  }
  return heff_tail(v_t_2414, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1, 1, 5, (V[]){v_hd_243, v_argv_241, v_ex_240, v_n_242, v_k_244})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2438);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V f_ = v_k_2420;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_intShow(heff_box_word((heff_peek_word(v_n_242) + ((int64_t)1ULL))));
  V v_t_2423 = heff_get_n(v_x_2421, 0, 3);
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    if (heff_intEq_c(v_n_2424, MK_INT(0LL))) {
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str1);
    } else {
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str2);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str3);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str4);
    break;
  }
  case TAG_NotRun: {
    v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str5);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str6), heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str7)));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str8), heff_strAppend(v_t_2422, v_t_2427));
  V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str9)), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  heff_room[0] = v_t_2436;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5, 1, 2, (V[]){v_k_2420, v_n_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4, 1, 3, (V[]){v_n_242, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2455);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2443 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2454);
  V f_ = v_k_2443;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7(V self, V *args) {
  V v_err_2441 = args[0];
  V v_hd_2442 = args[1];
  V v_k_2443 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_err_2441);
  V v_bind_2444 = heff_take_field(v_hd_2442, 1);
  V v_malg_2445 = heff_get_n(v_hd_2442, 2, 3);
  V v_t_2446 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str10), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(v_malg_2445, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})}));
  V f_ = v_bind_2444;
  args[0] = v_t_2453;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8, 1, 2, (V[]){v_k_2443, v_n_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2459;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2416, v_argv_241, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2418 = (g_std_2eprocess_2ewithProcess_24s1345957496x637138289(heff_dup(v_ex_240), v_t_2417));
  V v_t_2458 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3, 2, 2, (V[]){v_c_2418, heff_dup(v_n_242)}), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7, 3, 1, (V[]){v_n_242})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2458, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2, 1, 5, (V[]){v_argv_241, v_ex_240, v_n_242, v_hd_243, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412;
  if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 8), v_x_249});
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_s_244, 8);
    v_t_2412 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (((heff_dup(heff_rfield(v_s_244, 7)) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0)))) {
    V v_c_2410 = ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(a_0, a_1)); heff_drop(v_host_240); r_; });
    V f_ = v_c_2410;
    heff_room[0] = v_hd_247;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_s_244, 8);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_245 = v_field_244;
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_path_245), heff_box_word(v_t_246), heff_strLength_lent(v_path_245, 0));
      V v_t_249;
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0))) {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
        v_t_249 = heff_strSlice(v_path_245, MK_INT(0LL), heff_box_word(v_t_248));
      } else {
        v_t_249 = v_path_245;
      }
      V v_path_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2411 = ({ V a_0 = v_path_2410; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2410); r_; });
      V v_c_2415 = heff_tr(heff_call(v_c_2411, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0_clo)}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1, 2, 2, (V[]){v_c_2415, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_m_241);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_y_2420})});
    V f_ = v_k_2417;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2, 1, 2, (V[]){v_k_2417, v_m_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V v_checkOnly_240, V v_f_241) {
top: ;
  V v_path_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = ({ V a_0 = v_path_242; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_242); r_; });
  V v_c_247 = heff_tr(heff_call(v_c_243, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1, 2, 3, (V[]){v_c_247, v_f_241, heff_dup(v_checkOnly_240)});
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_245 = args[1];
  V v_k_246 = args[2];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_249;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_y_2422 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2424, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_y_2422; V a_3 = v_t_2425; V a_4 = v_hd_248; V a_5 = v_k_249; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    heff_drop(v_checkOnly_240);
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1));
    V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
    V f_ = heff_get_n(v_hd_248, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3, 1, 1, (V[]){v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_c_2423 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_241)));
    V f_ = v_c_2423;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_y_2422, v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_checkOnly_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2, 1, 4, (V[]){v_f_241, v_hd_248, v_k_249, v_checkOnly_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(V v_rep_240, V v_prog_241, V v_chk_242, V v_x2_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_chk_242);
    V v_x_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_f_248 = heff_field(v_x2_243, 0);
    V v_rest_249 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_chk_242), heff_dup(v_f_248), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2, 2, 7, (V[]){v_t_2411, v_f_248, v_rep_240, v_prog_241, v_acc_244, v_chk_242, v_rest_249});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_cs_2420 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2412 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2428);
  V v_t_2435;
  if (heff_intLt_c(MK_INT(0LL), v_x_2417)) {
    V v_found_2429 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_2420));
    heff_drop(v_found_2429);
    v_t_2435 = v_acc_244;
  } else {
    V v_bad_2430 = (g_list_2eany_24s1740858080x874135214(v_cs_2420));
    HeffT2 v_t_2431 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2420));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((heff_dup(v_bad_2430) == NTAG(TAG_True))) {
        heff_drop(v_bad_2430);
        heff_drop(v_field_2433);
        v_t_2435 = v_acc_244;
      } else {
        heff_drop(v_bad_2430);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_c_2434 = v_field_2433;
          v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2434, v_acc_244});
        } else {
          heff_drop(v_field_2433);
          v_t_2435 = v_acc_244;
        }
      }
    }
  }
  V v_t_2436 = (g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(v_rep_240, v_prog_241, v_chk_242, v_rest_249, v_t_2435));
  V f_ = v_t_2436;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_cs_2420 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_chk_242 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  V v_k_2413 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2426}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2427, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9, 1, 9, (V[]){v_x_2417, v_cs_2420, v_acc_244, v_rep_240, v_prog_241, v_chk_242, v_rest_249, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_chk_242 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_cs_2420 = heff_get_n(v_x_2419, 0, 2);
  V v_t_2421 = (g_list_2eany_24s1740858080x874135214(v_cs_2420));
  V v_c_2424;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_c_2424 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(heff_dup(v_rep_240), heff_dup(v_cs_2420)));
  } else {
    heff_drop(v_t_2421);
    v_c_2424 = ((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7_clo);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8, 1, 10, (V[]){v_x_2414, v_prog_241, v_hd_2412, v_x_2417, v_cs_2420, v_acc_244, v_rep_240, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_chk_242 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2418 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_2416));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6, 1, 9, (V[]){v_rep_240, v_hd_2412, v_x_2414, v_prog_241, v_x_2417, v_acc_244, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_str0), heff_dup(heff_rfield(v_x_2416, 1)), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5, 1, 9, (V[]){v_x_2416, v_hd_2412, v_rep_240, v_x_2414, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2415 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_f_248));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4, 1, 8, (V[]){v_hd_2412, v_rep_240, v_x_2414, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3, 1, 8, (V[]){v_f_248, v_hd_2412, v_rep_240, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str1, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str3, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str5, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str12, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str13, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str14, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str15, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str16, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str17, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str18, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str19, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str20, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str21, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str22, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str23, 17, "the commit is of ");
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V v_path_240, V v_v_241, V v_time_242, V v_hash_243, V v_dir_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str0), v_t_245), ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str1));
  V v_t_247 = heff_strAppend(heff_dup(v_hash_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str2), v_t_246));
  V v_t_248 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str3), v_t_247));
  V v_t_249 = heff_strAppend(heff_dup(v_path_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str4), v_t_248));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str5), v_t_249);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0, 2, 5, (V[]){v_path_240, v_dir_244, v_x_2410, v_hash_243, v_time_242});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3(V self, V *args) {
  V v_r_2448 = args[0];
  return v_r_2448;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_ended_2458 = heff_env(self)[0];
  V v_err_2459 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464;
  switch (heff_tag_of(v_ended_2458)) {
  case TAG_Exited: {
    V v_n_2462 = heff_field(v_ended_2458, 0);
    heff_take_n(v_ended_2458, 1ULL, 1);
    v_t_2464 = heff_bool(!heff_intEq_c_lent(v_n_2462, MK_INT(0LL), 2));
    heff_drop(v_n_2462);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2458, 0ULL, 1);
    v_t_2464 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2464 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2464 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2458);
  }
  V v_x_2475;
  if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
    heff_drop(v_x_2461);
    heff_drop(v_time_242);
    heff_drop(v_t_2464);
    V v_s_2465 = v_err_2459;
    V v_t_2466 = (g_prelude_2eskipSpaces(v_s_2465, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2467 = (heff_unbox_word(heff_strLength_lent(v_s_2465, 0)) - ((int64_t)1ULL));
    V v_t_2468 = (g_prelude_2eskipSpaces(v_s_2465, heff_box_word(v_t_2467), MK_INT(-1LL)));
    V v_t_2469 = heff_strSlice(v_s_2465, v_t_2466, heff_intAdd(v_t_2468, MK_INT(1LL)));
    v_x_2475 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2469)});
  } else {
    heff_drop(v_err_2459);
    heff_drop(v_t_2464);
    switch (heff_tag_of(v_x_2461)) {
    case TAG_Nothing: {
      heff_drop(v_time_242);
      v_x_2475 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str21))});
      break;
    }
    case TAG_Just: {
      V v_it1_2470 = heff_field(v_x_2461, 0);
      V v_ru_24x_2461_24Just = heff_take_reuse_n(v_x_2461, 1ULL, 1);
      switch (heff_tag_of(v_it1_2470)) {
      case TAG_MkPair: {
        V v_t_2471 = heff_field(v_it1_2470, 0);
        heff_take_n(v_it1_2470, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2471, v_time_242, 0)) {
          heff_drop(v_x_2410);
          heff_drop(v_time_242);
          heff_drop_cell(v_ru_24x_2461_24Just, 1);
          heff_drop(v_t_2471);
          v_x_2475 = NTAG(TAG_Nothing);
        } else {
          V v_t_2473 = heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str22), v_time_242));
          V v_t_2474 = heff_strAppend(v_x_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str23), v_t_2473));
          v_x_2475 = heff_tag_at_n(v_ru_24x_2461_24Just, TAG_Just, 1, (V[]){v_t_2474});
        }
        break;
      }
      default: heff_nomatch(v_it1_2470);
      }
      break;
    }
    default: heff_nomatch(v_x_2461);
    }
  }
  V f_ = v_k_2412;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4(V self, V *args) {
  V v_x_2457 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ended_2458 = heff_take_field(v_x_2457, 0);
  V v_err_2459 = heff_get_n(v_x_2457, 2, 3);
  V v_c_2460 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(v_dir_244, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str20)));
  V f_ = v_c_2460;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5, 1, 5, (V[]){v_ended_2458, v_err_2459, v_x_2410, v_time_242, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_time_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_2431 = heff_take_field(v_x_2430, 0);
  V v_err_2432 = heff_get_n(v_x_2430, 2, 3);
  V v_t_2435;
  switch (heff_tag_of(v_ended_2431)) {
  case TAG_Exited: {
    V v_n_2433 = heff_field(v_ended_2431, 0);
    heff_take_n(v_ended_2431, 1ULL, 1);
    v_t_2435 = heff_bool(!heff_intEq_c_lent(v_n_2433, MK_INT(0LL), 2));
    heff_drop(v_n_2433);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2431, 0ULL, 1);
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2431);
  }
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_dir_244);
    heff_drop(v_hash_243);
    heff_drop_rec(v_hd_2411, 3);
    heff_drop(v_time_242);
    heff_drop(v_t_2435);
    V v_s_2436 = v_err_2432;
    V v_t_2437 = (g_prelude_2eskipSpaces(v_s_2436, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_s_2436, 0)) - ((int64_t)1ULL));
    V v_t_2439 = (g_prelude_2eskipSpaces(v_s_2436, heff_box_word(v_t_2438), MK_INT(-1LL)));
    V v_t_2440 = heff_strSlice(v_s_2436, v_t_2437, heff_intAdd(v_t_2439, MK_INT(1LL)));
    V v_x_2441 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2440)});
    V f_ = v_k_2412;
    args[0] = v_x_2441;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_err_2432);
    heff_drop(v_t_2435);
    V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_243, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str13)), NTAG(TAG_Nil)});
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str15), v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str17), v_t_2444})});
    V v_t_2446 = ({ V a_0 = v_t_2442; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2442); r_; });
    V v_t_2447 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str19), v_t_2445}), v_t_2446, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2449 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3_clo)});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
    V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
    heff_room[0] = v_t_2456;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4, 1, 5, (V[]){v_dir_244, v_hd_2411, v_x_2410, v_time_242, v_k_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_240 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_time_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_244), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str6), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str8), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str10), v_t_2416})});
  V v_t_2418 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str11);
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str12), v_t_2417, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2422 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
  V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
  args[0] = v_t_2429;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2, 1, 6, (V[]){v_x_2410, v_k_2412, v_dir_244, v_hash_243, v_hd_2411, v_time_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_str0, 10, "heff build");
Clo g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(V v_prog_240, V v_st_241, V v_t_242, V v_p_243, V v_x_244, V v_next_245) {
top: ;
  V v_dir_246 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_a_247 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_t_248 = (g_std_2epath_2eparse(v_st_241, v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_241, v_x_244));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_out_2411 = ({ V a_0 = v_st_241; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_242, 5, 6), NTAG(TAG_Nil)});
  return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(MK_INT(1LL), v_prog_240, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_str0), v_st_241, v_t_2412, v_p_243, v_dir_246, v_out_2411, v_next_245));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(V v_lit_240, V v_lit_241, V v_lit_242, V v_rep_243, V v_f_244) {
top: ;
  V v_path_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_246 = ({ V a_0 = v_path_245; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_245); r_; });
  V v_c_2410 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1, 2, 6, (V[]){v_c_2410, v_f_244, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_rep_243)});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_rep_243 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_j_2418 = heff_strFind(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str0), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str1), MK_INT(0LL));
  V v_t_2419;
  if (heff_intLt_c_lent(v_j_2418, MK_INT(0LL), 2)) {
    heff_drop(v_j_2418);
    v_t_2419 = MK_INT(0LL);
  } else {
    v_t_2419 = v_j_2418;
  }
  V v_t_2420 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str2), MK_INT(0LL), v_t_2419, 3), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get())));
  heff_drop(v_t_2419);
  return ({ V a_0 = v_rep_243; V a_1 = v_t_2417; V a_2 = v_f_244; V a_3 = v_t_2420; V a_4 = v_x_2416; V a_5 = v_hd_2411; V a_6 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_243); heff_drop(v_t_2420); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_y_2421 = heff_env(self)[3];
  V v_rep_243 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2424 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str3), v_y_2421, MK_INT(0LL), 5);
  V v_t_2426;
  if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
    heff_drop(v_j_2425);
    v_t_2426 = heff_strLength_lent(v_y_2421, 0);
  } else {
    v_t_2426 = v_j_2425;
  }
  V v_t_2427 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2421, MK_INT(0LL), v_t_2426, 2), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get())));
  heff_drop(v_y_2421);
  heff_drop(v_t_2426);
  return ({ V a_0 = v_rep_243; V a_1 = v_t_2424; V a_2 = v_f_244; V a_3 = v_t_2427; V a_4 = v_x_2423; V a_5 = v_hd_2411; V a_6 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_243); heff_drop(v_t_2427); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_rep_243 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    V v_c_2415 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_244)));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_2411);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam3, 1, 7, (V[]){v_lit_240, v_lit_241, v_lit_242, v_rep_243, v_f_244, v_hd_2411, v_k_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_c_2422 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_244)));
    V f_ = v_c_2422;
    heff_room[0] = heff_dup(v_hd_2411);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam4, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_y_2421, v_rep_243, v_f_244, v_hd_2411, v_k_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_rep_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2, 1, 7, (V[]){v_f_244, v_hd_2411, v_lit_240, v_lit_241, v_lit_242, v_rep_243, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str1, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_dup(heff_rfield(v_c_244, 7)); V r_ = (g_list_2emap_24f1730403549x1479772376(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str1), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(heff_get_n(v_c_244, 0, 14), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}