// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TemporaryDirectory 61563
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define LBL_absolute 325777132
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_job 314935
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_outcome 1272833429
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_proc 9945117
#define LBL_program 2069953735
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_segments 1801007612
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_value 313331083
#define LBL_watch 314261737
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_job__proc__dir[] = {LBL_job, LBL_proc, LBL_dir};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s158212438x2079511520(V, V, V, V, V, V, V);
V g_co_2eop_24s158212438x2079511520_entry(V self, V *a);
extern Clo g_co_2eop_24s158212438x2079511520_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_clo;
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_clo;
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862(V, V, V);
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_clo;
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eall_24s523006110x1088755562(V);
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a);
extern Clo g_list_2eall_24s523006110x1088755562_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1564977489x772952072(V, V);
V g_list_2efilter_24s1564977489x772952072_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s148011877x1447840770(V, V, V, V);
V g_list_2efoldl_24s148011877x1447840770_entry(V self, V *a);
extern Clo g_list_2efoldl_24s148011877x1447840770_clo;
V g_list_2emap_24f74587876x194913022(V, V, V);
V g_list_2emap_24f74587876x194913022_entry(V self, V *a);
extern Clo g_list_2emap_24f74587876x194913022_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c_lent(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0), 2)) {
    heff_drop(v_dir_241);
    V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_x3_242));
    V v_xs_245 = heff_get_n(v_t_244, 2, 3);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      return v_x_247;
    }
    default: return heff_nomatch(v_x1_246);
    }
  } else {
    heff_drop(v_x3_242);
    V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2410 = heff_get_n(v_t_249, 2, 3);
    V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      heff_take_n(v_x1_2411, 1ULL, 2);
      return v_x_2412;
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str5, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str8, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str9, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str10, 4, "_app");
Clo g_heff_2ebuild_2ecommands_2enameLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameLike_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2enameLike(V v_x_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24f74587876x194913022(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str2); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enameLike_str3), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  V v_x2_246 = (g_list_2efilter_24s1564977489x772952072(MK_INT(0LL), v_t_245));
  V v_x_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_x_249 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_x_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str6), 2)) {
    heff_drop(v_x_249);
    v_x_2413 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str7);
  } else {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
        v_x_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enameLike_str8), v_x_249);
      } else {
        v_x_2413 = v_x_249;
      }
    } else {
      v_x_2413 = v_x_249;
    }
  }
  HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2413));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str9));
    } else {
      heff_drop(v_field_2416);
      if (heff_strEq_c(heff_dup(v_x_2413), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str10));
      } else {
        return v_x_2413;
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameLike(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam1, 1, 0};
Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693(V v_path_240, V v_text_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_240, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), v_p_243, v_p_244));
  }
  case TAG_Just: {
    V v_was_2411 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2411, v_text_241, 1)) {
      heff_drop(v_path_240);
      heff_drop(v_text_241);
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_True)});
    } else {
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_240, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam1_clo)})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), v_p_243, v_p_244));
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_lam1(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam1(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2414);
    heff_drop(v_done_241);
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_str1));
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_take_field(v_o_242, 1);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    V v_t_248 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get_n(v_o_242, 0, 2), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam1_clo)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})));
  }
  case TAG_Cons: {
    V v_ru_24t_246_24Cons = heff_take_reuse_n(v_t_246, 0ULL, 2);
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2431 = heff_tag_at_n(v_ru_24t_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str3, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str6, 0, "");
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_update_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_241, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2435;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2410;
      v_c_2435 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam0, 2, 2, (V[]){heff_dup(v_pattern_241), v_why_2412});
    } else {
      V v_x_2432 = v_field_2410;
      heff_drop(v_x_2432);
      v_c_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam3, 2, 5, (V[]){v_c_2435, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242), v_update_243});
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_241 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str2), v_why_2412));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str3), v_t_2417), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam1, 1, 2, (V[]){v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam2(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam5(V self, V *args) {
  V v_n_2439 = args[0];
  return v_n_2439;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam7(V self, V *args) {
  V v_v_2447 = args[0];
  return v_v_2447;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2437 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2461;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_2461 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2455 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    HeffT2 v_t_2456 = ({ V a_0 = v_s_2455; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2455); r_; });
    {
      V v_field_2458 = v_t_2456.f[1];
      int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
      if ((v_tag_2457 == ((int64_t)0ULL))) {
        V v_x_2460 = v_field_2458;
        v_t_2461 = v_x_2460;
      } else {
        heff_drop(v_field_2458);
        v_t_2461 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2463;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2463 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_fallback_2465;
  if (heff_intLt_c(heff_intDiv(heff_dup(v_x_2446), MK_INT(2LL)), MK_INT(1LL))) {
    heff_drop(v_x_2446);
    v_fallback_2465 = MK_INT(1LL);
  } else {
    v_fallback_2465 = heff_intDiv(v_x_2446, MK_INT(2LL));
  }
  V v_fallback_2473;
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    v_fallback_2473 = v_fallback_2465;
    break;
  }
  case TAG_Just: {
    V v_n_2466 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    HeffT2 v_t_2467 = ({ V a_0 = v_n_2466; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2466); r_; });
    {
      V v_field_2469 = v_t_2467.f[1];
      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
      if ((v_tag_2468 == ((int64_t)0ULL))) {
        V v_k_2471 = v_field_2469;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2471, 1)) {
          heff_drop(v_fallback_2465);
          v_fallback_2473 = v_k_2471;
        } else {
          heff_drop(v_k_2471);
          v_fallback_2473 = v_fallback_2465;
        }
      } else {
        heff_drop(v_field_2469);
        v_fallback_2473 = v_fallback_2465;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2454);
  }
  V v_t_2481;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2481 = v_fallback_2473;
    break;
  }
  case TAG_Just: {
    V v_n_2474 = heff_field(v_jobs_242, 0);
    heff_take_n(v_jobs_242, 1ULL, 1);
    HeffT2 v_t_2475 = ({ V a_0 = v_n_2474; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2474); r_; });
    {
      V v_field_2477 = v_t_2475.f[1];
      int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
      if ((v_tag_2476 == ((int64_t)0ULL))) {
        V v_k_2479 = v_field_2477;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2479, 1)) {
          heff_drop(v_fallback_2473);
          v_t_2481 = v_k_2479;
        } else {
          heff_drop(v_k_2479);
          v_t_2481 = v_fallback_2473;
        }
      } else {
        heff_drop(v_field_2477);
        v_t_2481 = v_fallback_2473;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_x_2482 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_t_2461, v_t_2463, v_t_2481, v_update_243});
  V f_ = v_k_2437;
  args[0] = v_x_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2437 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_str5), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam7_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s94900133x232571340(v_t_2453, v_hd_2436, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam8, 1, 6, (V[]){v_seed_240, v_pattern_241, v_x_2446, v_jobs_242, v_update_243, v_k_2437})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2437 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2438);
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam5_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s94900133x232571340(v_t_2445, heff_dup(v_hd_2436), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam6, 1, 6, (V[]){v_hd_2436, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2437})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_lam4, 1, 6, (V[]){v_hd_2436, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str0, 10, "heff-test-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str1, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str2, 21, "no directory for it: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str3, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str4, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str5, 28, "its program could not be run");
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862(V v_j_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TemporaryDirectory, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str0), ((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam1, 1, 3, (V[]){v_j_240, v_k_242, v_hd_241}));
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam4(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_j_240 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_name_2438 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str4), heff_take_field(v_j_240, 3), heff_rfield(v_j_240, 4)));
  V v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str5)})});
  V v_t_2440 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_2438, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2439, MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_2441 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_240, 0), heff_get_n(v_j_240, 2, 6), v_t_2440, NTAG(TAG_Nil)});
  V v_x_2442 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2441});
  V f_ = v_k_242;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_dir_2417 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_j_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nothing: {
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_dir_2417, ((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam4_clo)})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam5, 1, 2, (V[]){v_j_240, v_k_242})));
  }
  case TAG_Just: {
    V v_proc_2443 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Just = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_drop(v_hd_241);
    V v_t_2444 = heff_tag_at_n(v_ru_24x_2430_24Just, TAG_Right, 1, (V[]){heff_rec_n(3, shape_job__proc__dir, (V[]){v_j_240, v_proc_2443, v_dir_2417})});
    V f_ = v_k_242;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_j_240 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_err_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    heff_drop(v_hd_241);
    V v_name_2411 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str1), heff_take_field(v_j_240, 3), heff_rfield(v_j_240, 4)));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str2), heff_get_n(v_err_2410, 2, 3));
    V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_2411, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2413, MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_2415 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_240, 0), heff_get_n(v_j_240, 2, 6), v_t_2414, NTAG(TAG_Nil)});
    V v_x_2416 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_Left, 1, (V[]){v_t_2415});
    V f_ = v_k_242;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_dir_2417 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Right = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_j_240, 1)), 0, 2);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_240, 3)), heff_dup(heff_rfield(v_j_240, 4))});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_2417), ((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_str3))});
    V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_j_240, 1)), 1, 2);
    V v_t_2422 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_2418, v_t_2419, heff_dup(v_dir_2417), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2421}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_240, 5)), MK_INT(0LL), NTAG(TAG_True)});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_249_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam2_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s94900133x232571340(v_t_2429, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2estartJob_24s520652640x230074862_lam3, 1, 4, (V[]){v_dir_2417, v_hd_241, v_j_240, v_k_242})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str4, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str5, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str6, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str8, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str10, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str11, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str12, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str13, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str0); V a_1 = v_name_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str1), v_name_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s523006110x1088755562(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam0, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_2453 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str9); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str10), heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str11)));
      V v_x_2455 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str12), v_t_2454), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str13)})});
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam5, 2, 1, (V[]){v_x_2455});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam1(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam3(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_st_2418 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2433 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2432), heff_strLength_lent(v_f_241, 0));
  V v_t_2436;
  if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str5))) {
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2436 = heff_strSlice_lent(v_f_241, MK_INT(0LL), heff_box_word(v_t_2435), 6);
  } else {
    v_t_2436 = heff_dup(v_f_241);
  }
  V v_s_2437 = (g_std_2epath_2ejoin(v_st_2418, heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str6)), heff_dup(v_name_243)));
  HeffT3 v_t_2438 = (g_std_2epath_2eparse_24cpr(v_st_2418, v_s_2437));
  V v_t_2445;
  {
    V v_field_2439 = v_t_2438.f[0];
    V v_field_2440 = v_t_2438.f[1];
    V v_field_2441 = v_t_2438.f[2];
    V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2441));
    V v_xs_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2442; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2442); r_; });
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
    v_t_2445 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2439, v_field_2440, v_t_2444});
  }
  V v_t_2446 = (g_std_2epath_2erender(v_st_2418, v_t_2445));
  int64_t v_t_2447 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2448 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2447), heff_strLength_lent(v_f_241, 0));
  V v_t_2451;
  if (heff_strEq_c(v_t_2448, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str7))) {
    int64_t v_t_2450 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2451 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_2450));
  } else {
    v_t_2451 = v_f_241;
  }
  V v_t_2452 = ({ V a_0 = v_st_2418; V a_1 = heff_strAppend(v_t_2451, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str8)); V a_2 = v_name_243; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2418); r_; });
  return ({ V a_0 = v_update_240; V a_1 = v_t_2446; V a_2 = v_t_2452; V a_3 = v_text_244; V a_4 = v_x_2431; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str2))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2420 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2419), heff_strLength_lent(v_f_241, 0));
  V v_t_2423;
  if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str3))) {
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2423 = heff_strSlice_lent(v_f_241, MK_INT(0LL), heff_box_word(v_t_2422), 6);
  } else {
    v_t_2423 = heff_dup(v_f_241);
  }
  V v_path_2424 = (g_std_2epath_2ejoin(v_st_2418, heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_str4)), heff_dup(v_name_243)));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2424, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam3_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam4, 1, 7, (V[]){v_f_241, v_st_2418, v_name_243, v_update_240, v_text_244, v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s94900133x232571340(v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam2, 1, 6, (V[]){v_f_241, v_name_243, v_hd_247, v_update_240, v_text_244, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_x_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = ({ V a_0 = v_color_241; V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop(v_t_2410); r_; });
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V a_3 = heff_dup(v_hd_2413); V a_4 = v_k_2414; V a_5 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}); V a_6 = v_hd_2413; V r_ = (g_co_2eop_24s158212438x2079511520(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_color_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str2, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str4, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str5, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str6, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str8, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str9, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str10, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str11, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str12, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str15, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str16, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str17, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str18, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str19, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str20, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str21, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str22, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str23, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str24, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str25, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str27, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str28, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str30, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str31, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str32, 12, "cannot keep ");
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(V v_prog_240, V v_ps_241, V v_path_242, V v_v_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), heff_dup(v_v_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_path_242, v_v_243, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam1(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam3(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam5(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam7(V self, V *args) {
  V v_t_2440 = args[0];
  return v_t_2440;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam9(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam12(V self, V *args) {
  V v_ok_2468 = args[0];
  return v_ok_2468;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam13(V self, V *args) {
  V v_x_2474 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_v_243 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2474);
  V v_t_2475 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_s_2476 = heff_get_n(v_x_2459, 2, 3);
  V v_t_2477 = (g_prelude_2eskipSpaces(v_s_2476, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2478 = (heff_unbox_word(heff_strLength_lent(v_s_2476, 0)) - ((int64_t)1ULL));
  V v_t_2479 = (g_prelude_2eskipSpaces(v_s_2476, heff_box_word(v_t_2478), MK_INT(-1LL)));
  V v_t_2480 = heff_strSlice(v_s_2476, v_t_2477, heff_intAdd(v_t_2479, MK_INT(1LL)));
  V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str14), v_t_2475), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str15), v_t_2480));
  V v_t_2482 = heff_strAppend(heff_dup(v_v_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str16), v_t_2481));
  V v_t_2483 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str17), v_t_2482));
  V v_t_2484 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str18), v_t_2483));
  V v_x_2485 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str19), v_t_2484)});
  V f_ = v_k_246;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam14(V self, V *args) {
  V v_r_2488 = args[0];
  return v_r_2488;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam16(V self, V *args) {
  V v_ok_2497 = args[0];
  return v_ok_2497;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam18(V self, V *args) {
  V v_ok_24104 = args[0];
  return v_ok_24104;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam20(V self, V *args) {
  V v_ok_24117 = args[0];
  return v_ok_24117;
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam22(V self, V *args) {
  V v_x_24138 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24116 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24138);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24116});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam21(V self, V *args) {
  V v_x_24124 = args[0];
  V v_x_2495 = heff_env(self)[0];
  V v_x_24110 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_x_24116 = heff_env(self)[6];
  V v_x_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24125 = heff_get_n(v_x_2495, 0, 3);
  V v_t_24129;
  switch (heff_tag_of(v_t_24125)) {
  case TAG_Exited: {
    V v_n_24126 = heff_field(v_t_24125, 0);
    heff_take_n(v_t_24125, 1ULL, 1);
    if (heff_intEq_c(v_n_24126, MK_INT(0LL))) {
      if ((heff_dup(v_x_24110) == NTAG(TAG_True))) {
        heff_drop(v_x_24110);
        v_t_24129 = v_x_24124;
      } else {
        heff_drop(v_x_24124);
        heff_drop(v_x_24110);
        v_t_24129 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_24124);
      heff_drop(v_x_24110);
      v_t_24129 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_24125, 0ULL, 1);
    heff_drop(v_x_24124);
    heff_drop(v_x_24110);
    v_t_24129 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_x_24124);
    heff_drop(v_x_24110);
    v_t_24129 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_drop(v_x_24124);
    heff_drop(v_x_24110);
    v_t_24129 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24125);
  }
  if ((heff_dup(v_t_24129) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    heff_drop(v_t_24129);
    V v_t_24130 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str27), v_v_243));
    V v_t_24131 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str28), v_t_24130), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str29));
    V v_t_24132 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24131, NTAG(TAG_MkUnit)});
    V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24137}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam22, 1, 2, (V[]){v_k_246, v_x_24116})));
  } else {
    heff_drop(v_hd_245);
    heff_drop(v_x_24116);
    heff_drop(v_t_24129);
    V v_t_24139 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str30), v_x_244));
    V v_t_24140 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str31), v_t_24139));
    V v_t_24141 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str32), v_t_24140)});
    V f_ = v_k_246;
    args[0] = v_t_24141;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam19(V self, V *args) {
  V v_x_24110 = args[0];
  V v_x_2495 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_24111 = heff_dup(heff_rfield(v_x_2495, 1));
  V v_t_24112 = (g_prelude_2eskipSpaces(v_s_24111, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_24113 = (heff_unbox_word(heff_strLength_lent(v_s_24111, 0)) - ((int64_t)1ULL));
  V v_t_24114 = (g_prelude_2eskipSpaces(v_s_24111, heff_box_word(v_t_24113), MK_INT(-1LL)));
  V v_t_24115 = heff_strSlice(v_s_24111, v_t_24112, heff_intAdd(v_t_24114, MK_INT(1LL)));
  V v_x_24116 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str24), v_t_24115);
  V v_t_24118 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str25)), heff_strAppend(heff_dup(v_x_24116), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str26)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam20_clo)});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  return (g_co_2eop_24s94900133x232571340(v_t_24123, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam21, 1, 8, (V[]){v_x_2495, v_x_24110, v_path_242, v_v_243, v_hd_245, v_k_246, v_x_24116, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam17(V self, V *args) {
  V v_x_24103 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_2495 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24103);
  V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam18_clo)})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam19, 1, 6, (V[]){v_x_2495, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam15(V self, V *args) {
  V v_x_2495 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2496 = ({ V b_0 = heff_get_n(v_ps_241, 5, 6); V a_1 = heff_dup(v_x_244); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str23); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2496, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam16_clo)})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam17, 1, 6, (V[]){v_x_244, v_hd_245, v_x_2495, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2462);
  V v_t_2463 = heff_dup(heff_rfield(v_x_2459, 0));
  V v_t_2467;
  switch (heff_tag_of(v_t_2463)) {
  case TAG_Exited: {
    V v_n_2464 = heff_field(v_t_2463, 0);
    heff_take_n(v_t_2463, 1ULL, 1);
    v_t_2467 = heff_bool(!heff_intEq_c_lent(v_n_2464, MK_INT(0LL), 2));
    heff_drop(v_n_2464);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2463, 0ULL, 1);
    v_t_2467 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2467 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2467 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2463);
  }
  if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_t_2467);
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_244, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam12_clo)})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam13, 1, 4, (V[]){v_path_242, v_x_2459, v_v_243, v_k_246})));
  } else {
    heff_drop_rec(v_x_2459, 3);
    heff_drop(v_t_2467);
    V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str20), NTAG(TAG_Nil)});
    V v_t_2487 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str22), v_t_2486}), heff_dup(v_x_244), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2487, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam14_clo)})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    return (g_co_2eop_24s94900133x232571340(v_t_2494, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam15, 1, 6, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2460 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2460}));
  return (g_co_2eop_24s94900133x232571340(v_t_2461, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam11, 1, 7, (V[]){v_x_2459, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_v_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2444 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str3), v_t_2444), v_t_2445});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str4), heff_dup(v_v_243)), v_t_2446});
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str6), v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str8), v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str10), v_t_2449})});
  V v_c_2451 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str12), v_t_2450}), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str13), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_c_2451, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam9_clo)})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s94900133x232571340(v_t_2458, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam10, 1, 8, (V[]){v_x_2443, v_prog_240, v_hd_245, v_x_244, v_path_242, v_v_243, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_strAppend(heff_dup(v_path_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str1), heff_dup(v_v_243)));
  V v_t_2441 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str2), v_t_2439), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam7_clo)});
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2441}));
  return (g_co_2eop_24s94900133x232571340(v_t_2442, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam8, 1, 7, (V[]){v_path_242, v_x_244, v_v_243, v_hd_245, v_prog_240, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2421);
  V v_st_2422 = heff_dup(heff_rfield(v_ps_241, 5));
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(v_st_2422, heff_dup(v_x_244)));
  V v_t_2430;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2426));
    V v_xs_2428 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2427; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2427); r_; });
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2428));
    v_t_2430 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2424, v_field_2425, v_t_2429});
  }
  V v_path_2431 = ({ V a_0 = v_st_2422; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); r_; });
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2431, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam5_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam6, 1, 7, (V[]){v_path_242, v_v_243, v_prog_240, v_hd_245, v_x_244, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam3_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam4, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_prog_240, v_k_246})));
  }
  case TAG_Just: {
    V v_h_24142 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop(v_x_244);
    heff_drop(v_hd_245);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    heff_drop(v_prog_240);
    V v_t_24143 = (g_prelude_2eskipSpaces(v_h_24142, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24144 = (heff_unbox_word(heff_strLength_lent(v_h_24142, 0)) - ((int64_t)1ULL));
    V v_t_24145 = (g_prelude_2eskipSpaces(v_h_24142, heff_box_word(v_t_24144), MK_INT(-1LL)));
    V v_t_24146 = heff_strSlice(v_h_24142, v_t_24143, heff_intAdd(v_t_24145, MK_INT(1LL)));
    V v_x_24147 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_Right, 1, (V[]){v_t_24146});
    V f_ = v_k_246;
    args[0] = v_x_24147;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_str0)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam1_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_lam2, 1, 7, (V[]){v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_prog_240, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_str1, 1, ".");
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338(V v_prog_240, V v_chk_241, V v_acc_242, V v_f_243) {
top: ;
  V v_c_244 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam0, 2, 5, (V[]){v_c_244, v_f_243, v_acc_242, v_chk_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam4(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam9(V self, V *args) {
  V v_c_2424 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ps_2425 = heff_dup(heff_rfield(v_x_2420, 2));
  V v_d_2426 = heff_get_n(heff_get_n(v_x_2420, 2, 5), 1, 6);
  V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_d_2426, ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_str1), 2) ? ({ V v_x1_2428 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2424, 0), heff_rfield(v_acc_242, 0))); int c_ = !(heff_dup(v_x1_2428) == NTAG(TAG_True)); heff_drop(v_x1_2428); c_; }) : ({ V v_t_2429 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2425, 5), heff_dup(heff_rfield(v_ps_2425, 4)), heff_dup(v_d_2426))); int c_ = ({ V v_t_2430 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2425, 5), heff_dup(heff_rfield(v_ps_2425, 4)), heff_dup(heff_rfield(v_c_2424, 1)))); int c_ = ({ V v_t_2431 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_2425, 5), heff_dup(v_t_2429), heff_dup(v_t_2430))); int c_ = ((heff_dup(v_t_2431) == NTAG(TAG_True)) ? ({ V v_x1_2432 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2424, 0), heff_rfield(v_acc_242, 0))); int c_ = !(heff_dup(v_x1_2432) == NTAG(TAG_True)); heff_drop(v_x1_2432); c_; }) : ({ V v_t_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_249), heff_dup(v_f_243))); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_c_2424, 0)), heff_dup(v_t_2433)) && ({ V v_x1_2435 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2424, 0), heff_rfield(v_acc_242, 0))); int c_ = !(heff_dup(v_x1_2435) == NTAG(TAG_True)); heff_drop(v_x1_2435); c_; })); heff_drop(v_t_2433); c_; })); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2430); c_; }); heff_drop(v_t_2429); c_; })));
  heff_drop_rec(v_c_2424, 14);
  heff_drop_rec(v_acc_242, 2);
  heff_drop(v_x_249);
  heff_drop(v_f_243);
  heff_drop_rec(v_ps_2425, 6);
  heff_drop(v_d_2426);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_t_2441 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_242, 0), heff_dup(v_x_2436)));
  V v_t_2442 = heff_intAdd(heff_get_n(v_acc_242, 1, 2), v_x_2421);
  V v_t_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2436; V r_ = (g_list_2efoldl_24s148011877x1447840770(a_0, a_1, a_2, a_3)); heff_drop(v_x_2436); r_; });
  V v_x_2444 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2441, heff_intAdd(v_t_2442, v_t_2443)});
  V f_ = v_k_246;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam10(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2438}));
  return (g_co_2eop_24s94900133x232571340(v_t_2439, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam11, 1, 4, (V[]){v_acc_242, v_x_2436, v_x_2421, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2436 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam9, 1, 4, (V[]){v_x_2420, heff_dup(v_acc_242), v_x_249, v_f_243}), heff_get_n(v_x_2423, 0, 2)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_x_2436), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam10, 1, 7, (V[]){v_x_2418, v_prog_240, v_hd_245, v_acc_242, v_x_2436, v_x_2421, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2422 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_x_2420)));
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam8, 1, 9, (V[]){v_x_2420, v_acc_242, v_x_249, v_f_243, v_hd_245, v_x_2418, v_prog_240, v_x_2421, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_str0), heff_dup(heff_rfield(v_x_2420, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam7, 1, 8, (V[]){v_x_2420, v_hd_245, v_acc_242, v_x_249, v_f_243, v_x_2418, v_prog_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_f_243)));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam6, 1, 7, (V[]){v_hd_245, v_acc_242, v_x_249, v_f_243, v_x_2418, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_chk_241 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_249), heff_dup(v_f_243)));
  V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = heff_rfield(v_acc_242, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2410); r_; });
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_x_249);
    heff_drop(v_f_243);
    heff_drop(v_t_2411);
    V v_t_2412 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_241, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2412}));
    return (g_co_2eop_24s94900133x232571340(v_t_2413, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam3, 1, 2, (V[]){v_k_246, v_acc_242})));
  } else {
    heff_drop(v_t_2411);
    V v_name_2415 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_249), heff_dup(v_f_243)));
    V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_241, v_name_2415, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam4_clo)})}));
    return (g_co_2eop_24s94900133x232571340(v_t_2417, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam5, 1, 6, (V[]){v_f_243, v_hd_245, v_acc_242, v_x_249, v_prog_240, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_chk_241 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_248 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(v_x_247, heff_dup(v_f_243)));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam2, 1, 6, (V[]){v_f_243, v_acc_242, v_chk_241, v_prog_240, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_chk_241 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s962232928x907942338_lam1, 1, 6, (V[]){v_f_243, v_hd_245, v_acc_242, v_chk_241, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str1, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str2, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800(V v_v_240, V v_pk_241, V v_r_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_2410;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 3)))) {
    v_t_2410 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 6)))) {
      v_t_2410 = NTAG(TAG_True);
    } else {
      V v_t_247 = heff_dup(heff_rfield(v_r_242, 4));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_247, 0ULL, 2);
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
    }
  }
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_intShow(heff_take_field(v_r_242, 3));
    V v_t_2412 = heff_intShow(heff_take_field(v_r_242, 2));
    V v_t_2413 = heff_intShow(heff_take_field(v_r_242, 6));
    V v_t_2414 = heff_intShow(heff_get_n(v_r_242, 5, 8));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str0), heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str1)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str2), heff_strAppend(v_t_2413, v_t_2415));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str3), heff_strAppend(v_t_2412, v_t_2416));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str4), heff_strAppend(v_t_2411, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_str5)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_lam0, 1, 2, (V[]){v_p_243, v_p_244})));
  } else {
    heff_drop_rec(v_r_242, 8);
    heff_drop(v_t_2410);
    return (g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961(v_v_240, v_pk_241, v_p_243, v_p_244));
  }
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s537881288x1027040800_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_243, v_p_244));
}