// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_from 9647217
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_jss 315076
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_message 1186782793
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_note 9882809
#define LBL_olds 9909235
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_watches 1357821955
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(V, V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(V, V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(V, V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457(V, V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(V, V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318(V, V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2elsp_2erender_2elineStartFrom(V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineStartFrom_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2eoneLineIn(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLineIn_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espanLines_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eascending_24s1013929174x440984754(V, V, V, V, V);
V g_list_2eascending_24s1013929174x440984754_entry(V self, V *a);
extern Clo g_list_2eascending_24s1013929174x440984754_clo;
V g_list_2edescending_24s1467056061x388427999(V, V, V, V, V);
V g_list_2edescending_24s1467056061x388427999_entry(V self, V *a);
extern Clo g_list_2edescending_24s1467056061x388427999_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s370525507x1787909101(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s370525507x1787909101_entry(V self, V *a);
extern Clo g_list_2efoldl_24s370525507x1787909101_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s810789954x1170958779(V, V, V, V);
V g_list_2emergeRuns_24s810789954x1170958779_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s810789954x1170958779_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ecommands_2erunProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunProgram_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2423 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2421), v_x_2422));
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2421), v_a_2423));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_2421), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str2)));
  V v_t_2426 = (g_std_2epath_2ejoin(v_t_2424, v_t_2425));
  V v_x_2427 = ({ V a_0 = v_st_2421; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2421); heff_drop(v_t_2426); r_; });
  V f_ = v_k_242;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2421;
  if (heff_strEq_c(v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_str1))) {
    v_st_2421 = NTAG(TAG_Windows);
  } else {
    v_st_2421 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(v_e_240, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam4, 1, 2, (V[]){v_st_2421, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam2_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940_lam3, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_lib_2428 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_lib_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam7, 3, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam9, 3, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s586971778x583361940(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam0, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam3(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam10(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_k_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2443 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2415), v_x_2416));
  V v_t_2446;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2445 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    v_t_2446 = heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Just, 1, (V[]){v_y_2445});
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2446); r_; });
  V v_t_2450;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    heff_take_n(v_x_2442, 0ULL, 1);
    v_t_2450 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Right = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    v_t_2450 = heff_tag_at_n(v_ru_24x_2442_24Right, TAG_Just, 1, (V[]){v_y_2449});
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_t_2451 = ({ V a_0 = v_t_2450; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2450); r_; });
  V v_t_2452 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2451));
  V v_x_2453 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_243, v_x_244, v_x_245, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2452})});
  V f_ = v_k_242;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_x_245 = heff_env(self)[7];
  V v_k_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_x_2417));
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2415), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str2)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_s_2434 = ({ V a_0 = v_st_2415; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2434));
  V v_c_2436 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2435; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2435); r_; });
  V v_t_2437 = (g_exception_2eattempted(v_e_240));
  V v_c_2441 = heff_tr(heff_call(v_c_2436, 2, (V[]){v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam9_clo)}));
  V f_ = v_c_2441;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam10, 1, 7, (V[]){v_st_2415, v_x_2416, v_x_2430, v_x_243, v_x_244, v_x_245, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_k_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_home_2418 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2415), heff_dup(v_x_2416)));
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_home_2418));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2415), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str1)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2423); r_; });
  V v_t_2425 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam7_clo)}));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam8, 1, 9, (V[]){v_st_2415, v_x_2417, v_e_240, v_hd_241, v_x_2416, v_x_243, v_x_244, v_x_245, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_st_2415 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_k_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam6, 1, 8, (V[]){v_st_2415, v_x_2416, v_e_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam5, 1, 7, (V[]){v_e_240, v_hd_241, v_st_2415, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam3_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam4, 1, 6, (V[]){v_e_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam2, 1, 5, (V[]){v_e_240, v_hd_241, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_lam1, 1, 4, (V[]){v_e_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str0, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str1, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str2, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str3, 2, "\033[");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str4, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str5, 4, "\033[0m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str7, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str8, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str9, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str17, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str19, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V v_e_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_diags_246 = heff_take_field(v_c_244, 6);
    V v_path_247 = heff_take_field(v_c_244, 1);
    V v_source_248 = heff_get_n(v_c_244, 3, 14);
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam0_clo)})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam1, 1, 7, (V[]){v_diags_246, v_path_247, v_source_248, v_e_240, v_p_242, v_rest_245, v_p_243}));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam0(V self, V *args) {
  V v_b_249 = args[0];
  return v_b_249;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam3(V self, V *args) {
  V v_d_2425 = args[0];
  V v_path_2422 = heff_env(self)[0];
  V v_src_2423 = heff_env(self)[1];
  V v_color_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = (g_heff_2elsp_2erender_2ediagWhere(v_path_2422, v_src_2423, heff_dup(v_d_2425)));
  V v_color_2427 = v_color_2421;
  V v_src_2428 = v_src_2423;
  V v_d_2429 = v_d_2425;
  V v_s_2430 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_2429)));
  V v_t_2434;
  if ((heff_dup(v_color_2427) == NTAG(TAG_True))) {
    V v_t_2431 = heff_dup(heff_rfield(v_d_2429, 1));
    V v_t_2432;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_SError: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str0);
      break;
    }
    case TAG_SWarning: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str1);
      break;
    }
    case TAG_SDebug: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str2);
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str3), v_t_2432), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str4));
    v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, v_s_2430), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str5));
  } else {
    v_t_2434 = v_s_2430;
  }
  V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str6)), heff_take_field(v_d_2429, 2));
  V v_color_2436 = v_color_2427;
  V v_t_2437 = heff_take_field(v_d_2429, 1);
  V v_code_2438;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_SError: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str7);
    break;
  }
  case TAG_SWarning: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str8);
    break;
  }
  case TAG_SDebug: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str9);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_src_2439 = v_src_2428;
  V v_sp_2440 = heff_take_field(v_d_2429, 3);
  V v_color_2441 = v_color_2436;
  V v_code_2442 = v_code_2438;
  V v_src_2443 = heff_dup(v_src_2439);
  V v_sp_2444 = heff_dup(v_sp_2440);
  V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str10), v_src_2439, MK_INT(0LL), 5);
  V v_t_2446;
  if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
    heff_drop(v_j_2445);
    v_t_2446 = NTAG(TAG_Nothing);
  } else {
    v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2445});
  }
  V v_s_2447 = (g_heff_2elsp_2erender_2elineColAt(v_src_2439, heff_dup(heff_rfield(v_sp_2440, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2446));
  V v_x_2448 = heff_take_field(v_sp_2440, 0);
  V v_y_2449 = heff_intSub(heff_get_n(v_sp_2440, 1, 2), MK_INT(1LL));
  V v_t_2450;
  if (heff_intLe_c_lent(v_x_2448, v_y_2449, 0)) {
    heff_drop(v_x_2448);
    v_t_2450 = v_y_2449;
  } else {
    heff_drop(v_y_2449);
    v_t_2450 = v_x_2448;
  }
  V v_j_2451 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str11), v_src_2439, MK_INT(0LL), 5);
  V v_t_2452;
  if (heff_intLt_c_lent(v_j_2451, MK_INT(0LL), 2)) {
    heff_drop(v_j_2451);
    v_t_2452 = NTAG(TAG_Nothing);
  } else {
    v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2451});
  }
  V v_e_2453 = ({ V a_0 = v_src_2439; V a_1 = v_t_2450; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2452; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2439); r_; });
  V v_t_2474;
  if (heff_intEq_c(heff_dup(heff_rfield(v_s_2447, 0)), heff_dup(heff_rfield(v_e_2453, 0)))) {
    heff_drop_rec(v_e_2453, 3);
    V v_color_2454 = v_color_2441;
    V v_code_2455 = v_code_2442;
    V v_src_2456 = v_src_2443;
    V v_sp_2457 = v_sp_2444;
    V v_start_2458 = heff_take_field(v_sp_2457, 0);
    V v_end_2459 = heff_get_n(v_sp_2457, 1, 2);
    V v_t_2460 = heff_intAdd(heff_dup(heff_rfield(v_s_2447, 0)), MK_INT(1LL));
    V v_w_2461 = (g_heff_2elsp_2erender_2enumDigits(v_t_2460));
    V v_l_2462 = heff_get_n(v_s_2447, 0, 3);
    V v_t_2463;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_t_2463 = MK_INT(0LL);
    } else {
      v_t_2463 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_x_2464;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_x_2464 = MK_INT(0LL);
    } else {
      v_x_2464 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_y_2465 = v_start_2458;
    V v_t_2466;
    if (heff_intLe_c_lent(v_x_2464, v_y_2465, 0)) {
      heff_drop(v_x_2464);
      v_t_2466 = v_y_2465;
    } else {
      heff_drop(v_y_2465);
      v_t_2466 = v_x_2464;
    }
    V v_start_2467;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_start_2467 = MK_INT(0LL);
    } else {
      v_start_2467 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_j_2468 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str12), v_src_2456, v_start_2467, 5);
    V v_x_2469;
    if (heff_intLt_c_lent(v_j_2468, MK_INT(0LL), 2)) {
      heff_drop(v_j_2468);
      v_x_2469 = heff_strLength_lent(v_src_2456, 0);
    } else {
      v_x_2469 = v_j_2468;
    }
    V v_y_2470 = v_end_2459;
    V v_t_2471;
    if (heff_intLe_c_lent(v_x_2469, v_y_2470, 0)) {
      heff_drop(v_y_2470);
      v_t_2471 = v_x_2469;
    } else {
      heff_drop(v_x_2469);
      v_t_2471 = v_y_2470;
    }
    v_t_2474 = ({ V a_0 = v_color_2454; V a_1 = v_code_2455; V a_2 = v_src_2456; V a_3 = v_w_2461; V a_4 = v_l_2462; V a_5 = v_t_2463; V a_6 = v_t_2466; V a_7 = v_t_2471; V r_ = (g_heff_2elsp_2erender_2eoneLineIn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_color_2454); heff_drop(v_src_2456); r_; });
  } else {
    heff_drop(v_sp_2444);
    V v_t_2472 = heff_intAdd(heff_dup(heff_rfield(v_e_2453, 0)), MK_INT(1LL));
    V v_t_2473 = (g_heff_2elsp_2erender_2enumDigits(v_t_2472));
    v_t_2474 = (g_heff_2elsp_2erender_2espanLines(v_color_2441, v_code_2442, v_src_2443, v_t_2473, v_s_2447, v_e_2453));
  }
  V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str13)), v_t_2474);
  V v_t_2476 = heff_get_n(v_d_2429, 4, 5);
  V v_t_2478;
  switch (heff_tag_of(v_t_2476)) {
  case TAG_Nothing: {
    v_t_2478 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str14);
    break;
  }
  case TAG_Just: {
    V v_n_2477 = heff_field(v_t_2476, 0);
    heff_take_n(v_t_2476, 1ULL, 1);
    v_t_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str15), v_n_2477);
    break;
  }
  default: heff_nomatch(v_t_2476);
  }
  V v_t_2479 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str16)), heff_strAppend(v_t_2475, v_t_2478));
  return heff_strAppend(v_t_2479, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str17));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam4(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2492);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(v_e_240, v_rest_245, v_p_242, v_p_243));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_diags_246 = heff_env(self)[0];
  V v_path_247 = heff_env(self)[1];
  V v_source_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2491;
  switch (heff_tag_of(v_diags_246)) {
  case TAG_Nil: {
    heff_drop(v_x_2416);
    heff_drop(v_path_247);
    heff_drop(v_source_248);
    v_c_2491 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam2_clo);
    break;
  }
  case TAG_Cons: {
    V v_color_2421 = v_x_2416;
    V v_path_2422 = v_path_247;
    V v_src_2423 = v_source_248;
    V v_ds_2424 = v_diags_246;
    V v_x2_2480 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam3, 1, 3, (V[]){v_path_2422, v_src_2423, v_color_2421}), v_ds_2424));
    V v_str_2483;
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_Nil: {
      v_str_2483 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_xs_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      v_str_2483 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_str19); V a_1 = v_x_2481; V a_2 = v_xs_2482; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2482); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2480);
    }
    V v_t_2484 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_str_2483, NTAG(TAG_MkUnit)});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
    v_c_2491 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
    break;
  }
  default: heff_nomatch(v_diags_246);
  }
  V f_ = v_c_2491;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_lam4, 1, 4, (V[]){v_e_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str13, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str14, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str15, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str16, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str17, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str22, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str24, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str25, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str26, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(V v_lit_240, V v_e_241, V v_failed_242, V v_who_243, V v_st_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_246)));
  V v_c_2410 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_241), v_path_249));
  V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_241)));
  V v_c_2416 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam2, 2, 10, (V[]){v_c_2416, v_st_244, v_dir_246, v_p_245, v_e_241, v_lit_240, v_out_247, v_next_248, v_who_243, v_failed_242});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2413 = (g_list_2emap_24s219049803x1458391381(v_x_2412));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam1, 2, 1, (V[]){v_x_2413});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam4(V self, V *args) {
  V v_n_2426 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_dir_246));
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_n_2426));
  V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
  return ({ V a_0 = v_st_244; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_2429); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam5(V self, V *args) {
  V v_n_2434 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_dir_246));
  V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_n_2434));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  return ({ V a_0 = v_st_244; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_2437); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam6(V self, V *args) {
  V v_t_2442 = args[0];
  return v_t_2442;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_r_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = v_r_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam10(V self, V *args) {
  V v_r_2465 = args[0];
  return v_r_2465;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam14(V self, V *args) {
  V v_x_24104 = args[0];
  V v_who_243 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_242 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24104);
  V v_t_24105 = heff_strAppend(heff_strAppend(v_who_243, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str26)), v_out_247);
  V f_ = v_failed_242;
  heff_room[0] = v_t_24105;
  heff_room[1] = v_hd_2417;
  heff_room[2] = v_k_2418;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam13(V self, V *args) {
  V v_x_2495 = args[0];
  V v_who_243 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_failed_242 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_strAppend(heff_strAppend(heff_dup(v_who_243), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str24)), heff_dup(v_out_247));
  V v_t_2497 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2496, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str25)), NTAG(TAG_MkUnit)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
  return (g_co_2eop_24s310169282x2049378029(v_e_241, heff_tag_n(TAG_InR, 1, (V[]){v_t_24103}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam14, 1, 5, (V[]){v_who_243, v_out_247, v_failed_242, v_hd_2417, v_k_2418})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam12(V self, V *args) {
  V v_x_2474 = args[0];
  V v_ended_2470 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_err_2471 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  V v_who_243 = heff_env(self)[6];
  V v_out_247 = heff_env(self)[7];
  V v_failed_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2474);
  V v_t_2478;
  switch (heff_tag_of(v_ended_2470)) {
  case TAG_Exited: {
    V v_n_2475 = heff_dup(heff_field(v_ended_2470, 0));
    v_t_2478 = heff_bool(heff_intEq_c_lent(v_n_2475, MK_INT(0LL), 2));
    heff_drop(v_n_2475);
    break;
  }
  case TAG_Signalled: {
    v_t_2478 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2478 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2478 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2470);
  }
  if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
    heff_drop(v_ended_2470);
    heff_drop(v_err_2471);
    heff_drop(v_e_241);
    heff_drop(v_who_243);
    heff_drop(v_out_247);
    heff_drop(v_failed_242);
    heff_drop(v_t_2478);
    V f_ = v_next_248;
    heff_room[0] = v_hd_2417;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2478);
    V v_t_2487;
    switch (heff_tag_of(v_ended_2470)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2470, 0ULL, 1);
      v_t_2487 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str18);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2470, 0ULL, 1);
      v_t_2487 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str19);
      break;
    }
    case TAG_TimedOut: {
      v_t_2487 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str20);
      break;
    }
    case TAG_NotRun: {
      V v_err_2481 = heff_field(v_ended_2470, 0);
      heff_take_n(v_ended_2470, 1ULL, 1);
      V v_path_2482 = heff_take_field(v_err_2481, 3);
      V v_name_2483 = heff_take_field(v_err_2481, 1);
      V v_message_2484 = heff_get_n(v_err_2481, 2, 4);
      V v_t_2485 = heff_strAppend(heff_strAppend(v_path_2482, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str21)), v_name_2483);
      V v_t_2486 = heff_strAppend(heff_strAppend(v_t_2485, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str22)), v_message_2484);
      v_t_2487 = heff_strAppend(v_t_2486, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str23));
      break;
    }
    default: heff_nomatch(v_ended_2470);
    }
    V v_t_2488 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2487, v_err_2471), NTAG(TAG_MkUnit)});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam13, 1, 6, (V[]){v_who_243, v_out_247, v_e_241, v_hd_2417, v_failed_242, v_k_2418})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam11(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2445 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  V v_who_243 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ended_2470 = heff_take_field(v_x_2469, 0);
  V v_err_2471 = heff_get_n(v_x_2469, 2, 3);
  V v_t_2472 = heff_tag_n(TAG_End, 2, (V[]){v_x_2445, NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam12, 1, 9, (V[]){v_ended_2470, v_next_248, v_hd_2417, v_k_2418, v_err_2471, v_e_241, v_who_243, v_out_247, v_failed_242})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam8(V self, V *args) {
  V v_x_2448 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_2445 = heff_env(self)[2];
  V v_x_2430 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_hd_2417 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2418 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_lit_2449 = v_lit_240;
  V v_e_2450 = heff_dup(v_e_241);
  V v_z_2451 = heff_dup(v_x_2445);
  V v_files_2452 = v_x_2430;
  V v_out_2453 = heff_dup(v_out_247);
  V v_x5_2454 = v_x_2448;
  V v_c_2468;
  switch (heff_tag_of(v_x5_2454)) {
  case TAG_Left: {
    V v_r_2455 = heff_field(v_x5_2454, 0);
    heff_take_n(v_x5_2454, 1ULL, 1);
    heff_drop(v_lit_2449);
    heff_drop(v_e_2450);
    heff_drop(v_z_2451);
    heff_drop(v_files_2452);
    heff_drop(v_out_2453);
    v_c_2468 = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam9, 2, 1, (V[]){v_r_2455});
    break;
  }
  case TAG_Right: {
    V v_os_2458 = heff_field(v_x5_2454, 0);
    V v_ru_24x5_2454_24Right = heff_take_reuse_n(v_x5_2454, 1ULL, 1);
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str13), NTAG(TAG_Nil)});
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_out_2453, v_t_2459})});
    V v_t_2461 = (g_prelude_2e_2b_2b(v_os_2458, v_t_2460));
    V v_t_2462 = (g_prelude_2e_2b_2b(v_files_2452, v_t_2461));
    V v_ys_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str15), v_t_2462});
    V v_argv_2464 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2449, v_ys_2463})});
    V v_t_2466 = heff_tag_at_n(v_ru_24x5_2454_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){v_z_2451, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str17), v_argv_2464, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam10_clo)})});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
    v_c_2468 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_2450, v_t_2467}));
    break;
  }
  default: heff_nomatch(v_x5_2454);
  }
  V f_ = v_c_2468;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam11, 1, 8, (V[]){v_x_2445, v_e_241, v_hd_2417, v_next_248, v_k_2418, v_who_243, v_out_247, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2418 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2446;
  if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str3), 2)) {
    v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str4);
  } else {
    if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str5), 2)) {
      v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str6);
    } else {
      if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str7), 2)) {
        v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str8);
      } else {
        if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str9), 2) || heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str10), 2))) {
          v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str11);
        } else {
          v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str12);
        }
      }
    }
  }
  V v_c_2447 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(heff_dup(v_e_241), heff_dup(v_x_2445), v_t_2446, v_x_2438, NTAG(TAG_Nil)));
  V f_ = v_c_2447;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam8, 1, 10, (V[]){v_lit_240, v_e_241, v_x_2445, v_x_2430, v_out_247, v_hd_2417, v_next_248, v_k_2418, v_who_243, v_failed_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2418 = heff_env(self)[8];
  V v_who_243 = heff_env(self)[9];
  V v_failed_242 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_x_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    v_x_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    v_x_2422 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Just, 1, (V[]){v_y_2421});
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_dup(heff_field(v_x_2422, 0));
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_t_2425 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str0); V a_1 = v_t_2424; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2430 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam4, 1, 2, (V[]){heff_dup(v_st_244), heff_dup(v_dir_246)}), v_t_2425));
  V v_t_2432;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    v_t_2432 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    v_t_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_t_2433 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str1); V a_1 = v_t_2432; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2438 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam5, 1, 2, (V[]){v_st_244, v_dir_246}), v_t_2433));
  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2430));
  V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2438));
  V v_total_2441 = heff_intAdd(heff_intAdd(v_t_2439, v_t_2440), MK_INT(1LL));
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_str2), v_total_2441, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam6_clo)})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), v_t_2444, heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam7, 1, 10, (V[]){v_lit_240, v_e_241, v_x_2438, v_hd_2417, v_x_2430, v_out_247, v_next_248, v_k_2418, v_who_243, v_failed_242})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_st_244 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_lam3, 1, 11, (V[]){v_st_244, v_dir_246, v_p_245, v_e_241, v_hd_2417, v_lit_240, v_out_247, v_next_248, v_k_2418, v_who_243, v_failed_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470(V v_e_240, V v_ps_241, V v_b_242, V v_x3_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_242, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(v_e_240, v_ps_241, v_b_242, v_t_246, v_z_244, v_z_245);
  }
  case TAG_Just: {
    V v_kept_247 = heff_field(v_x3_243, 0);
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_str0), v_kept_247, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      V v_t_249 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_242, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(v_e_240, v_ps_241, v_b_242, v_t_249, v_z_244, v_z_245);
    } else {
      V v_t_2410 = heff_intSub(heff_strLength_lent(v_kept_247, 0), heff_dup(v_j_248));
      if ((heff_intEq_c(heff_intSub(heff_dup(v_t_2410), MK_INT(1LL)), heff_strLength_lent(v_b_242, 0)) && heff_strEq_c(heff_strSlice(heff_dup(v_kept_247), heff_intAdd(heff_dup(v_j_248), MK_INT(1LL)), heff_strLength_lent(v_kept_247, 0)), heff_dup(v_b_242)))) {
        heff_drop(v_e_240);
        heff_drop(v_ps_241);
        heff_drop(v_b_242);
        heff_drop(v_z_244);
        heff_drop(v_t_2410);
        return heff_tail(v_z_245, 1, (V[]){heff_strSlice_lent(v_kept_247, MK_INT(0LL), v_j_248, 6)});
      } else {
        heff_drop(v_j_248);
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_242, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
        HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(v_e_240, v_ps_241, v_b_242, v_t_2411, v_z_244, v_z_245);
      }
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(V v_e_240, V v_ps_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam0, 1, 4, (V[]){v_e_240, v_hd_242, v_k_243, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2425 = args[1];
  V v_k_2426 = args[2];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_y_2414 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    heff_take_n(v_x_2428, 0ULL, 1);
    v_t_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Right = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    v_t_2431 = heff_tag_at_n(v_ru_24x_2428_24Right, TAG_Just, 1, (V[]){v_y_2430});
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  return ({ V a_0 = v_e_240; V a_1 = v_ps_241; V a_2 = v_y_2414; V a_3 = v_t_2431; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2eselfFrom_24s2035493895x1783305470(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2431); r_; });
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_e_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V v_d_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
    V v_st_2416 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_d_2415));
    V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_str1)));
    V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
    V v_s_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
    V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2420));
    V v_c_2422 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2421; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2421); r_; });
    V v_t_2423 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2427 = heff_tr(heff_call(v_c_2422, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam3_clo)}));
    V f_ = v_c_2427;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam4, 1, 5, (V[]){v_e_240, v_ps_241, v_y_2414, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_244));
  V v_c_246 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_245; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_245); r_; });
  V v_t_247 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2411 = heff_tr(heff_call(v_c_246, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam1_clo)}));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_lam2, 1, 4, (V[]){v_k_243, v_ps_241, v_e_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(V v_e_240, V v_ps_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_ps_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_d_247 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
    V v_st_248 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
    V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_strAppend(heff_dup(v_m_245), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_str0))));
    V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
    V v_s_2412 = ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
    V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
    V v_c_2414 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2413; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2413); r_; });
    V v_t_2415 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2419 = heff_tr(heff_call(v_c_2414, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam2, 2, 5, (V[]){v_c_2419, v_e_240, v_ps_241, v_rest_246, v_m_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_2425 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_245, v_y_2425}), v_x_2427});
  V f_ = v_k_2421;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2420 = heff_env(self)[3];
  V v_k_2421 = heff_env(self)[4];
  V v_m_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    heff_drop(v_m_245);
    V v_c_2424 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(v_e_240, v_ps_241, v_rest_246));
    V f_ = v_c_2424;
    heff_room[0] = v_hd_2420;
    heff_room[1] = v_k_2421;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_c_2426 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(v_e_240, v_ps_241, v_rest_246));
    V f_ = v_c_2426;
    heff_room[0] = v_hd_2420;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam4, 1, 3, (V[]){v_m_245, v_y_2425, v_k_2421});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_m_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_lam3, 1, 6, (V[]){v_e_240, v_ps_241, v_rest_246, v_hd_2420, v_k_2421, v_m_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str4, 27, "heff promote: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732(V v_e_240, V v_file_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam0, 1, 6, (V[]){v_cs_243, heff_dup(v_badL_242), v_e_240, v_hd_244, v_k_245, v_file_241})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2449 = args[1];
  V v_k_2450 = args[2];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam3(V self, V *args) {
  V v_x_2462 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2462);
  V v_t_2463 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam2(V self, V *args) {
  V v_x_2452 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2452)) {
  case TAG_Left: {
    V v_ru_24x_2452_24Left = heff_take_reuse_n(v_x_2452, 0ULL, 1);
    V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str4), v_file_241), ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str5));
    V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2454, NTAG(TAG_MkUnit)});
    V v_t_2456 = heff_tag_at_n(v_ru_24x_2452_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2461}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam3, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2452, 0ULL, 1);
    heff_drop(v_file_241);
    heff_drop(v_e_240);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_badL_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_file_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_243));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2410 = v_field_249;
      if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
        heff_drop(v_cs_243);
        heff_drop(v_badL_242);
        heff_drop(v_file_241);
        heff_drop(v_c_2410);
        V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
        V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_244, v_k_245));
      } else {
        heff_drop(v_badL_242);
        V v_t_2418 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_243); r_; });
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_file_241);
          heff_drop(v_c_2410);
          heff_drop(v_t_2418);
          V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
          V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
          V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
          V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
          return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_244, v_k_245));
        } else {
          heff_drop(v_t_2418);
          V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_file_241)));
          V v_c_2427 = v_c_2410;
          V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_c_2427, 5)), 4, 10);
          V v_x2_2429 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2427), v_t_2428));
          V v_t_2444;
          switch (heff_tag_of(v_x2_2429)) {
          case TAG_Nil: {
            v_t_2444 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_2430 = heff_field(v_x2_2429, 0);
            V v_xs_2431 = heff_field(v_x2_2429, 1);
            V v_ru_24x2_2429_24Cons = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
            V v_lit_2432 = MK_INT(0LL);
            V v_lit_2433 = MK_INT(0LL);
            V v_x_2434 = v_x_2430;
            V v_x3_2435 = v_xs_2431;
            V v_t_2443;
            switch (heff_tag_of(v_x3_2435)) {
            case TAG_Nil: {
              heff_drop(v_lit_2432);
              heff_drop(v_lit_2433);
              V v_t_2436 = heff_tag_at_n(v_ru_24x2_2429_24Cons, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
              v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
              break;
            }
            case TAG_Cons: {
              V v_y_2437 = heff_field(v_x3_2435, 0);
              V v_ys_2438 = heff_field(v_x3_2435, 1);
              V v_ru_24x3_2435_24Cons = heff_take_reuse_n(v_x3_2435, 3ULL, 2);
              V v_t_2439 = heff_intSub(heff_dup(v_lit_2432), heff_dup(heff_rfield(v_x_2434, 0)));
              V v_t_2440 = heff_intSub(heff_dup(v_lit_2433), heff_dup(heff_rfield(v_y_2437, 0)));
              if (heff_intLe_c(v_t_2439, v_t_2440)) {
                V v_t_2441 = heff_tag_at_n(v_ru_24x2_2429_24Cons, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
                v_t_2443 = (g_list_2eascending_24s1013929174x440984754(v_lit_2432, v_lit_2433, heff_dup(v_y_2437), heff_tag_at_n(v_ru_24x3_2435_24Cons, TAG_Cons, 2, (V[]){v_y_2437, v_t_2441}), v_ys_2438));
              } else {
                V v_t_2442 = heff_tag_at_n(v_ru_24x2_2429_24Cons, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
                v_t_2443 = (g_list_2edescending_24s1467056061x388427999(v_lit_2432, v_lit_2433, heff_dup(v_y_2437), heff_tag_at_n(v_ru_24x3_2435_24Cons, TAG_Cons, 2, (V[]){v_y_2437, v_t_2442}), v_ys_2438));
              }
              break;
            }
            default: heff_nomatch(v_x3_2435);
            }
            v_t_2444 = (g_list_2emergeRuns_24s810789954x1170958779(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2443));
            break;
          }
          default: heff_nomatch(v_x2_2429);
          }
          V v_text_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str1); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str2); V a_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_str3); V b_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2427, 3, 14); V a_7 = v_t_2444; V r_ = (g_list_2efoldl_24s370525507x1787909101(a_0, a_1, b_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(v_t_2444); r_; });
          V v_c_2446 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2426; V a_2 = v_text_2445; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2426); r_; });
          V v_t_2447 = (g_exception_2eattempted(heff_dup(v_e_240)));
          V v_c_2451 = heff_tr(heff_call(v_c_2446, 2, (V[]){v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam1_clo)}));
          V f_ = v_c_2451;
          heff_room[0] = heff_dup(v_hd_244);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_lam2, 1, 4, (V[]){v_file_241, v_e_240, v_hd_244, v_k_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    } else {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      heff_drop(v_file_241);
      heff_drop(v_field_249);
      V v_t_2471 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), v_hd_244, v_k_245));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(V v_e_240, V v_sources_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sources_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_e_247 = heff_dup(v_e_240);
    V v_sources_248 = heff_dup(v_sources_241);
    V v_m_249 = v_m_245;
    HeffT2 v_t_2410 = ({ V a_0 = v_sources_248; V a_1 = v_m_249; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(a_0, a_1)); heff_drop(v_sources_248); r_; });
    V v_c_2433;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_path_2413 = v_field_2412;
        int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_path_2413, 0)) - ((int64_t)3ULL));
        V v_t_2415 = heff_strSlice(heff_dup(v_path_2413), heff_box_word(v_t_2414), heff_strLength_lent(v_path_2413, 0));
        V v_t_2417;
        if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_str0))) {
          int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_path_2413, 0)) - ((int64_t)3ULL));
          v_t_2417 = heff_strSlice(v_path_2413, MK_INT(0LL), heff_box_word(v_t_2416));
        } else {
          v_t_2417 = v_path_2413;
        }
        V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_str1))));
        V v_c_2419 = ({ V a_0 = heff_dup(v_e_247); V a_1 = v_path_2418; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2418); r_; });
        V v_t_2420 = (g_exception_2eattempted(v_e_247));
        V v_c_2424 = heff_tr(heff_call(v_c_2419, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam1_clo)}));
        v_c_2433 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam2, 2, 2, (V[]){v_c_2424, v_m_249});
      } else {
        heff_drop(v_e_247);
        heff_drop(v_m_249);
        heff_drop(v_field_2412);
        v_c_2433 = ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam4_clo);
      }
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam5, 2, 4, (V[]){v_c_2433, v_e_240, v_sources_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_drop(v_m_249);
    V f_ = v_k_2426;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_249, v_y_2429})});
    V f_ = v_k_2426;
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam3, 1, 2, (V[]){v_k_2426, v_m_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Nothing: {
    v_t_2440 = v_x_2438;
    break;
  }
  case TAG_Just: {
    V v_pr_2439 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2439, v_x_2438});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V f_ = v_k_2435;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sources_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2437 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099(v_e_240, v_sources_241, v_rest_246));
  V f_ = v_c_2437;
  heff_room[0] = v_hd_2434;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam7, 1, 2, (V[]){v_x_2436, v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sources_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s298232391x1095394099_lam6, 1, 5, (V[]){v_e_240, v_sources_241, v_rest_246, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str2, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str3, 5, "error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str4, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str5, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str6, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str7, 2, "  ");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584(V v_e_240, V v_file_241, V v_hd_242, V v_k_243) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), v_file_241, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam0, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam4(V self, V *args) {
  V v_ev_2418 = args[0];
  V v_source_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2419 = heff_take_field(v_ev_2418, 0);
  V v_kind_2420 = heff_take_field(v_ev_2418, 1);
  V v_text_2421 = heff_get_n(v_ev_2418, 2, 3);
  V v_t_2422 = ({ V a_0 = v_source_2415; V a_1 = v_span_2419; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2415); r_; });
  V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str1)), v_kind_2420);
  V v_t_2424 = heff_tr(heff_call(v_text_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str2)), v_t_2424);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam5(V self, V *args) {
  V v_d_2426 = args[0];
  V v_source_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2427 = heff_take_field(v_d_2426, 3);
  V v_severity_2428 = heff_take_field(v_d_2426, 1);
  V v_msg_2429 = heff_get_n(v_d_2426, 2, 5);
  V v_t_2430 = ({ V a_0 = v_source_2415; V a_1 = v_span_2427; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2415); r_; });
  V v_t_2431;
  switch (heff_tag_of(v_severity_2428)) {
  case TAG_SError: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str5);
    break;
  }
  default: heff_nomatch(v_severity_2428);
  }
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str6)), v_t_2431);
  return heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str7)), v_msg_2429);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_cs_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_249);
  HeffT2 v_t_2410 = ({ V a_0 = v_cs_248; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_248); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_c_2414 = v_c_2413;
      V v_source_2415 = heff_take_field(v_c_2414, 3);
      V v_top_2416 = heff_take_field(v_c_2414, 5);
      V v_diags_2417 = heff_get_n(v_c_2414, 6, 14);
      V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam4, 1, 1, (V[]){heff_dup(v_source_2415)}), heff_get_n(v_top_2416, 8, 10)));
      V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam5, 1, 1, (V[]){v_source_2415}), v_diags_2417));
      V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2433));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(v_e_240, v_t_2434, v_hd_242, v_k_243));
    } else {
      heff_drop(v_field_2412);
      V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_242, v_k_243));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_248 = heff_get_n(v_x_247, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_cs_248), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam3, 1, 4, (V[]){v_cs_248, v_e_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam2, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_lam1, 1, 4, (V[]){v_e_240, v_x_244, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam6(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(V v_e_240, V v_checkOnly_241, V v_x2_242, V v_bad_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_checkOnly_241);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam0, 2, 1, (V[]){v_bad_243});
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x2_242, 0);
    V v_rest_247 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_e_248 = heff_dup(v_e_240);
    V v_checkOnly_249 = heff_dup(v_checkOnly_241);
    V v_f_2410 = v_f_246;
    V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_2410)));
    V v_c_2412 = ({ V a_0 = heff_dup(v_e_248); V a_1 = v_path_2411; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2411); r_; });
    V v_t_2413 = (g_exception_2eattempted(heff_dup(v_e_248)));
    V v_c_2417 = heff_tr(heff_call(v_c_2412, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam1_clo)}));
    V v_c_2434 = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam2, 2, 4, (V[]){v_c_2417, v_f_2410, v_e_248, v_checkOnly_249});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam6, 2, 5, (V[]){v_c_2434, v_e_240, v_checkOnly_241, v_rest_247, v_bad_243});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_bad_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_bad_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2415 = args[1];
  V v_k_2416 = args[2];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_2419;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_248 = heff_env(self)[0];
  V v_checkOnly_249 = heff_env(self)[1];
  V v_f_2410 = heff_env(self)[2];
  V v_y_2431 = heff_env(self)[3];
  V v_hd_2418 = heff_env(self)[4];
  V v_k_2419 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2433 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2432, 0, 5)));
  return ({ V a_0 = v_e_248; V a_1 = v_checkOnly_249; V a_2 = v_f_2410; V a_3 = v_y_2431; V a_4 = v_t_2433; V a_5 = v_hd_2418; V a_6 = v_k_2419; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_checkOnly_249); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2410 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  V v_k_2419 = heff_env(self)[3];
  V v_checkOnly_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 0ULL, 1);
    heff_drop(v_checkOnly_249);
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_str0), v_f_2410), ((V)&g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_str1));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s310169282x2049378029(v_e_248, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_2418, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam4, 1, 1, (V[]){v_k_2419})));
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_248), heff_dup(v_f_2410), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam5, 1, 6, (V[]){v_e_248, v_checkOnly_249, v_f_2410, v_y_2431, v_hd_2418, v_k_2419})));
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2410 = heff_env(self)[1];
  V v_e_248 = heff_env(self)[2];
  V v_checkOnly_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam3, 1, 5, (V[]){v_f_2410, v_e_248, v_hd_2418, v_k_2419, v_checkOnly_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_checkOnly_241 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_bad_243 = heff_env(self)[3];
  V v_hd_2435 = heff_env(self)[4];
  V v_k_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2438 = (g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(v_e_240, v_checkOnly_241, v_rest_247, heff_intAdd(v_bad_243, v_x_2437)));
  V f_ = v_t_2438;
  heff_room[0] = v_hd_2435;
  heff_room[1] = v_k_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_checkOnly_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_bad_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_lam7, 1, 6, (V[]){v_e_240, v_checkOnly_241, v_rest_247, v_bad_243, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(V v_e_240, V v_x1_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    V v_x_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam0, 2, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x1_241, 0);
    V v_rest_247 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_246)));
    V v_c_249 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_248));
    V v_t_2410 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2415 = heff_tr(heff_call(v_c_249, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam3, 2, 5, (V[]){v_c_2415, v_p_246, v_e_240, v_rest_247, v_acc_242});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2411));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam2, 2, 1, (V[]){v_x_2412});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam5(V self, V *args) {
  V v_s_2425 = args[0];
  return v_s_2425;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam7(V self, V *args) {
  V v_n_2436 = args[0];
  V v_st_2434 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_p_246));
  V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_n_2436));
  V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
  return ({ V a_0 = v_st_2434; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2439); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_y_2424 = heff_env(self)[0];
  V v_rest_247 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2434;
  if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str1))) {
    v_st_2434 = NTAG(TAG_Windows);
  } else {
    v_st_2434 = NTAG(TAG_Posix);
  }
  V v_t_2435 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str2); V a_3 = v_y_2424; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2440 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam7, 1, 2, (V[]){v_st_2434, v_p_246}), v_t_2435));
  V v_t_2441 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(v_e_240, v_t_2440, v_acc_242));
  V f_ = v_t_2441;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_246, 0)) - ((int64_t)3ULL));
    V v_t_2421 = heff_strSlice(heff_dup(v_p_246), heff_box_word(v_t_2420), heff_strLength_lent(v_p_246, 0));
    if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_str0))) {
      V v_t_2422 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(v_e_240, v_rest_247, heff_tag_n(TAG_Cons, 2, (V[]){v_p_246, v_acc_242})));
      V f_ = v_t_2422;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_246);
      V v_t_2423 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(v_e_240, v_rest_247, v_acc_242));
      V f_ = v_t_2423;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam5_clo)})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2432, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam6, 1, 7, (V[]){v_y_2424, v_rest_247, v_p_246, v_e_240, v_acc_242, v_hd_2416, v_k_2417})));
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_lam4, 1, 6, (V[]){v_p_246, v_e_240, v_rest_247, v_acc_242, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str3, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str4, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam0, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2412 = v_x_243;
  V v_x2_2415;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    heff_take_n(v_x_2411, 0ULL, 1);
    v_x2_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Right = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    v_x2_2415 = heff_tag_at_n(v_ru_24x_2411_24Right, TAG_Just, 1, (V[]){v_y_2414});
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2430;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    v_t_2430 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str0), v_path_2412)});
    break;
  }
  case TAG_Just: {
    V v_src_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Just = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_2416)));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_p_2420 = v_field_2419;
        V v_t_2421 = ({ V a_0 = v_path_2412; V a_1 = v_src_2416; V a_2 = v_p_2420; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2416); r_; });
        v_t_2430 = heff_tag_at_n(v_ru_24x2_2415_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str1), v_t_2421)});
      } else {
        V v_x_2422 = v_field_2419;
        HeffT2 v_t_2423 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_p_2426 = v_field_2425;
            V v_t_2427 = ({ V a_0 = v_path_2412; V a_1 = v_src_2416; V a_2 = v_p_2426; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2416); r_; });
            v_t_2430 = heff_tag_at_n(v_ru_24x2_2415_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str2), v_t_2427)});
          } else {
            heff_drop(v_path_2412);
            heff_drop(v_src_2416);
            V v_p_2428 = v_field_2425;
            V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str3), heff_get_n(v_p_2428, 1, 4));
            v_t_2430 = heff_tag_at_n(v_ru_24x2_2415_24Just, TAG_Right, 1, (V[]){v_t_2429});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Left: {
    V v_why_2431 = heff_field(v_t_2430, 0);
    V v_ru_24t_2430_24Left = heff_take_reuse_n(v_t_2430, 1ULL, 1);
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str4), v_why_2431), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str5));
    V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2432, NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_at_n(v_ru_24t_2430_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam3, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_line_2448 = heff_field(v_t_2430, 0);
    V v_ru_24t_2430_24Right = heff_take_reuse_n(v_t_2430, 1ULL, 1);
    V v_t_2449 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2448, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_str6)), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_at_n(v_ru_24t_2430_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_t_2430);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
  V v_c_245 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_244; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_244); r_; });
  V v_t_246 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2410 = heff_tr(heff_call(v_c_245, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam1_clo)}));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_lam2, 1, 4, (V[]){v_x_243, v_e_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(V v_e_240, V v_before_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_before_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_245)));
    V v_c_248 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_247); r_; });
    V v_t_249 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2413 = heff_tr(heff_call(v_c_248, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam2, 2, 5, (V[]){v_c_2413, v_path_245, v_e_240, v_before_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_2414, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam5, 1, 1, (V[]){v_k_2415})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  return v_s_2436;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam10(V self, V *args) {
  V v_i_2461 = args[0];
  V v_before_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2461; V a_1 = v_before_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_i_2461); heff_drop(v_before_241); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_2445 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_lib_2447 = heff_env(self)[2];
  V v_mod_2448 = heff_env(self)[3];
  V v_cwd_2449 = heff_env(self)[4];
  V v_style_2450 = heff_env(self)[5];
  V v_before_241 = heff_env(self)[6];
  V v_y_2435 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_m_2454 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str12), v_st_2445}), heff_dup(v_path_245)));
  V v_ps_2455 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str14), v_lib_2447, v_mod_2448, v_cwd_2449, v_style_2450});
  HeffT2 v_t_2456 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2455), heff_get_n(v_ps_2455, 2, 6), heff_dup(v_path_245)));
  V v_library_2460;
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    v_library_2460 = heff_bool(((v_tag_2457 == ((int64_t)0ULL)) && ({ V v_x_2459 = heff_dup(v_field_2458); int c_ = 1; heff_drop(v_x_2459); c_; })));
    heff_drop(v_field_2458);
  }
  V v_t_2462 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam10, 1, 1, (V[]){v_before_241}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2463 = heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_2454), v_m_2454, heff_dup(v_path_245), v_path_245, v_y_2435, NTAG(TAG_Nil), v_t_2462, v_library_2460});
  V v_x_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_x_2453});
  V f_ = v_k_2415;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_2445 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_before_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_y_2435 = heff_env(self)[6];
  V v_k_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_lib_2447 = heff_take_field(v_x_2446, 0);
  V v_mod_2448 = heff_take_field(v_x_2446, 1);
  V v_cwd_2449 = heff_take_field(v_x_2446, 2);
  V v_style_2450 = heff_get_n(v_x_2446, 3, 5);
  V v_t_2451 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str7), heff_dup(v_st_2445)}), heff_dup(v_path_245)));
  V v_c_2452 = (g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(v_e_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, heff_dup(v_before_241)}), v_rest_246));
  V f_ = v_c_2452;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam9, 1, 9, (V[]){v_st_2445, v_path_245, v_lib_2447, v_mod_2448, v_cwd_2449, v_style_2450, v_before_241, v_y_2435, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_before_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_y_2435 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2445;
  if (heff_strEq_c(v_x_2444, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str2))) {
    v_st_2445 = NTAG(TAG_Windows);
  } else {
    v_st_2445 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam8, 1, 8, (V[]){v_st_2445, v_path_245, v_e_240, v_before_241, v_rest_246, v_hd_2414, v_y_2435, v_k_2415})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_path_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2414 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  V v_before_241 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 0ULL, 1);
    heff_drop(v_before_241);
    heff_drop(v_rest_246);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str0), v_path_245), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_str1));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam4, 1, 3, (V[]){v_e_240, v_hd_2414, v_k_2415})));
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam6_clo)})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2443, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam7, 1, 7, (V[]){v_e_240, v_hd_2414, v_path_245, v_before_241, v_rest_246, v_y_2435, v_k_2415})));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_before_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_lam3, 1, 6, (V[]){v_path_245, v_e_240, v_hd_2414, v_k_2415, v_before_241, v_rest_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str2, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534(V v_e_240, V v_bi_241, V v_dir_242, V v_zig_243, V v_id_244, V v_texts_245, V v_backs_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_groups_2410 = heff_take_field(v_out_247, 2);
  V v_copies_2411 = heff_take_field(v_out_247, 3);
  V v_emits_2412 = heff_take_field(v_out_247, 4);
  V v_parts_2413 = heff_take_field(v_out_247, 0);
  V v_errors_2414 = heff_get_n(v_out_247, 1, 5);
  V v_paths_2415 = heff_take_field(v_bi_241, 0);
  V v_modules_2416 = heff_get_n(v_bi_241, 2, 3);
  V v_t_2437;
  if (heff_strEq_c_lent(v_id_244, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str0), 2)) {
    heff_drop(v_id_244);
    heff_drop(v_backs_246);
    heff_drop(v_groups_2410);
    heff_drop(v_copies_2411);
    heff_drop(v_emits_2412);
    heff_drop(v_paths_2415);
    heff_drop(v_modules_2416);
    v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam0_clo);
  } else {
    V v_s_2419 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2415)));
    V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2419));
    V v_c_2421 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2420; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2420); r_; });
    V v_t_2422 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2426 = heff_tr(heff_call(v_c_2421, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam1_clo)}));
    v_t_2437 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam2, 2, 10, (V[]){v_c_2426, heff_dup(v_texts_245), v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_244, v_backs_246, heff_dup(v_e_240), v_paths_2415});
  }
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str2), v_zig_243}), v_parts_2413});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(v_e_240, v_dir_242, v_t_2437, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_errors_2414}), v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8], a[9]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_a_2418 = args[1];
  heff_drop(v_a_2417);
  V f_ = v_a_2418;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2436);
  V f_ = v_k_2428;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_texts_245 = heff_env(self)[0];
  V v_modules_2416 = heff_env(self)[1];
  V v_groups_2410 = heff_env(self)[2];
  V v_copies_2411 = heff_env(self)[3];
  V v_emits_2412 = heff_env(self)[4];
  V v_id_244 = heff_env(self)[5];
  V v_backs_246 = heff_env(self)[6];
  V v_e_240 = heff_env(self)[7];
  V v_paths_2415 = heff_env(self)[8];
  V v_hd_2427 = heff_env(self)[9];
  V v_k_2428 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2429);
  V v_t_2430 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_245; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_245); r_; });
  V v_t_2431 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_str1), NTAG(TAG_MkUnit)));
  V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = v_modules_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2416); r_; });
  V v_t_2433 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
  V v_t_2434 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_244, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2432, v_backs_246}), v_t_2433));
  V v_c_2435 = ({ V a_0 = v_e_240; V a_1 = v_paths_2415; V a_2 = v_t_2430; V a_3 = v_t_2434; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); heff_drop(v_t_2434); r_; });
  V f_ = v_c_2435;
  heff_room[0] = v_hd_2427;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam4, 1, 1, (V[]){v_k_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_texts_245 = heff_env(self)[1];
  V v_modules_2416 = heff_env(self)[2];
  V v_groups_2410 = heff_env(self)[3];
  V v_copies_2411 = heff_env(self)[4];
  V v_emits_2412 = heff_env(self)[5];
  V v_id_244 = heff_env(self)[6];
  V v_backs_246 = heff_env(self)[7];
  V v_e_240 = heff_env(self)[8];
  V v_paths_2415 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_lam3, 1, 11, (V[]){v_texts_245, v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_244, v_backs_246, v_e_240, v_paths_2415, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741(V v_e_240, V v_failed_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam0, 1, 8, (V[]){v_e_240, v_l_242, v_hd_246, v_file_245, v_failed_241, v_k_247, v_name_243, v_outPath_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_2413; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2413); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_done_2411 = heff_env(self)[6];
  V v_l_242 = heff_env(self)[7];
  V v_hashes_2412 = heff_env(self)[8];
  V v_e_240 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop(v_done_2411);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2412);
    heff_drop(v_e_240);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    HeffT2 v_t_2423 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
    V v_t_2427;
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2426 = v_field_2425;
        v_t_2427 = v_x_2426;
      } else {
        heff_drop(v_field_2425);
        v_t_2427 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str3));
      }
    }
    V f_ = v_failed_241;
    heff_room[0] = v_t_2427;
    heff_room[1] = v_hd_246;
    heff_room[2] = v_k_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2428 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_done_2411);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2412);
      heff_drop(v_e_240);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_t_2428);
      HeffT2 v_t_2429 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
      V v_t_2433;
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2432 = v_field_2431;
          v_t_2433 = v_x_2432;
        } else {
          heff_drop(v_field_2431);
          v_t_2433 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str4));
        }
      }
      V f_ = v_failed_241;
      heff_room[0] = v_t_2433;
      heff_room[1] = v_hd_246;
      heff_room[2] = v_k_247;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2428);
      V v_t_2434 = (g_list_2emap_24s1698496827x1884878103(v_done_2411));
      V v_t_2435 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), v_hashes_2412, v_t_2434});
      return ({ V a_0 = v_e_240; V a_1 = v_t_2435; V a_2 = heff_get_n(v_l_242, 0, 5); V a_3 = v_file_245; V a_4 = v_name_243; V a_5 = v_outPath_244; V a_6 = v_failed_241; V a_7 = v_x_2421; V a_8 = v_hd_246; V a_9 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_x_2421); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_done_2411 = heff_take_field(v_x_2410, 0);
  V v_hashes_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_sources_2413 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2414 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_str2), heff_dup(v_sources_2413)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam2, 1, 2, (V[]){v_sources_2413, v_x_2414}), heff_dup(v_done_2411)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_x_2421), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam3, 1, 12, (V[]){v_x_248, v_x_2421, v_file_245, v_failed_241, v_hd_246, v_k_247, v_done_2411, v_l_242, v_hashes_2412, v_e_240, v_name_243, v_outPath_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_241 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_l_242)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_lam1, 1, 9, (V[]){v_l_242, v_e_240, v_hd_246, v_x_248, v_file_245, v_failed_241, v_k_247, v_name_243, v_outPath_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}