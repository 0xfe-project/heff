// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_Move 53768
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_c 317
#define LBL_cwd 308458
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_heff 9694020
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_own 320000
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1772383553x418719539(V, V, V);
V g_co_2eop_24s1772383553x418719539_entry(V self, V *a);
extern Clo g_co_2eop_24s1772383553x418719539_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1730403549x1479772376(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ecommands_2erunProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunProgram_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ecommands_2erunProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam11(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam13(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_x_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2459);
  V f_ = v_k_2460;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2458});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    V v_err_2456 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Left = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    V v_t_2457 = heff_tag_at_n(v_ru_24x_2455_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2456})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2457));
  }
  case TAG_Right: {
    V v_x_2458 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam13, 2, 1, (V[]){v_x_2458});
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam14(V self, V *args) {
  V v_x_2462 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2463 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2415), v_x_2416));
  V v_t_2466;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2465 = heff_field(v_x_2440, 0);
    V v_ru_24x_2440_24Right = heff_take_reuse_n(v_x_2440, 1ULL, 1);
    v_t_2466 = heff_tag_at_n(v_ru_24x_2440_24Right, TAG_Just, 1, (V[]){v_y_2465});
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_t_2467 = ({ V a_0 = v_t_2466; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2466); r_; });
  V v_t_2470;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    heff_take_n(v_x_2462, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2469 = heff_field(v_x_2462, 0);
    V v_ru_24x_2462_24Right = heff_take_reuse_n(v_x_2462, 1ULL, 1);
    v_t_2470 = heff_tag_at_n(v_ru_24x_2462_24Right, TAG_Just, 1, (V[]){v_y_2469});
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V v_t_2471 = ({ V a_0 = v_t_2470; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2470); r_; });
  V v_t_2472 = (g_prelude_2e_2b_2b(v_t_2467, v_t_2471));
  V v_x_2473 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_244, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2472})});
  V f_ = v_k_241;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_x_2417));
  V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2415), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2)));
  V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
  V v_s_2444 = ({ V a_0 = v_st_2415; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2443); r_; });
  V v_path_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2444));
  V v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2445; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2445); r_; });
  V v_a_2448 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam11_clo)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_c_2461 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam12_clo)));
  V f_ = v_c_2461;
  heff_room[0] = v_hd_240;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam14, 1, 7, (V[]){v_st_2415, v_x_2416, v_x_2440, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2418 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2415), heff_dup(v_x_2416)));
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_home_2418));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2415), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8_clo)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10, 1, 8, (V[]){v_st_2415, v_x_2417, v_hd_240, v_x_2416, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6, 1, 7, (V[]){v_st_2415, v_x_2416, v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5, 1, 6, (V[]){v_hd_240, v_st_2415, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str21, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(V v_lit_240, V v_lit_241, V v_who_242, V v_st_243, V v_p_244, V v_dir_245, V v_out_246, V v_next_247) {
top: ;
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2435 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam1, 3, 1, (V[]){v_path_248})));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam5, 2, 9, (V[]){v_c_2435, v_st_243, v_dir_245, v_p_244, v_lit_241, v_out_246, v_next_247, v_who_242, v_lit_240});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam3(V self, V *args) {
  V v_n_2426 = args[0];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2426));
  return (g_std_2epath_2ejoin(v_path_248, v_t_2427));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_2424 = args[1];
  V v_z_2425 = args[2];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2424);
  V v_x_2428 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam3, 1, 1, (V[]){v_path_248}), v_x_2423));
  V v_x_2429 = (g_list_2emap_24s219049803x1458391381(v_x_2428));
  V f_ = v_z_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam4(V self, V *args) {
  V v_n_2431 = args[0];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2431));
  return (g_std_2epath_2ejoin(v_path_248, v_t_2432));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_2419 = args[1];
  V v_z_2420 = args[2];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2421})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam2, 3, 1, (V[]){v_path_248}), v_z_2419, v_z_2420));
  }
  case TAG_Right: {
    V v_x_2430 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_z_2419);
    V v_x_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam4, 1, 1, (V[]){v_path_248}), v_x_2430));
    V v_x_2434 = (g_list_2emap_24s219049803x1458391381(v_x_2433));
    V f_ = v_z_2420;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2434});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam7(V self, V *args) {
  V v_n_2445 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_dir_245));
  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_n_2445));
  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2448); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam8(V self, V *args) {
  V v_n_2453 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_dir_245));
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_n_2453));
  V v_t_2456 = (g_std_2epath_2ejoin(v_t_2454, v_t_2455));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2456; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2456); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam9(V self, V *args) {
  V v_t_2461 = args[0];
  return v_t_2461;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam12(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  heff_drop(v_hd_2469);
  V v_t_2471 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str14)});
  V f_ = v_k_2470;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam13(V self, V *args) {
  V v_r_2479 = args[0];
  return v_r_2479;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam17(V self, V *args) {
  V v_x_24111 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24111);
  return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_hd_2436, v_k_2437));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam16(V self, V *args) {
  V v_x_24101 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_246 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24101);
  V v_t_24102 = heff_strAppend(heff_strAppend(v_who_242, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str20)), v_out_246);
  V v_t_24103 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24102, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str21)), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_24110;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam17, 1, 3, (V[]){v_lit_240, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam15(V self, V *args) {
  V v_x_2489 = args[0];
  V v_ended_2484 = heff_env(self)[0];
  V v_next_247 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  V v_err_2485 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_246 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2489);
  V v_t_2492;
  switch (heff_tag_of(v_ended_2484)) {
  case TAG_Exited: {
    V v_n_2490 = heff_field(v_ended_2484, 0);
    heff_take_n(v_ended_2484, 1ULL, 1);
    v_t_2492 = heff_bool(heff_intEq_c_lent(v_n_2490, MK_INT(0LL), 2));
    heff_drop(v_n_2490);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2484, 0ULL, 1);
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2484);
  }
  if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
    heff_drop(v_err_2485);
    heff_drop(v_who_242);
    heff_drop(v_out_246);
    heff_drop(v_lit_240);
    heff_drop(v_t_2492);
    V f_ = v_next_247;
    heff_room[0] = v_hd_2436;
    heff_room[1] = v_k_2437;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_247);
    heff_drop(v_t_2492);
    V v_t_2493 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2485, NTAG(TAG_MkUnit)});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
    V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
    heff_room[0] = v_t_24100;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam16, 1, 5, (V[]){v_who_242, v_out_246, v_hd_2436, v_lit_240, v_k_2437});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam14(V self, V *args) {
  V v_x_2483 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2484 = heff_take_field(v_x_2483, 0);
  V v_err_2485 = heff_get_n(v_x_2483, 2, 3);
  V v_t_2486 = heff_tag_n(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_2488;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam15, 1, 8, (V[]){v_ended_2484, v_next_247, v_hd_2436, v_k_2437, v_err_2485, v_who_242, v_out_246, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_out_246 = heff_env(self)[0];
  V v_x_2449 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_x_2465 = heff_env(self)[3];
  V v_hd_2436 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2482;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Nothing: {
    heff_drop(v_x_2449);
    heff_drop(v_lit_241);
    v_c_2482 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam12_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2472 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Just = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str15), NTAG(TAG_Nil)});
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_246), v_t_2473})});
    V v_t_2475 = (g_prelude_2e_2b_2b(v_os_2472, v_t_2474));
    V v_t_2476 = (g_prelude_2e_2b_2b(v_x_2449, v_t_2475));
    V v_ys_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str17), v_t_2476});
    V v_argv_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str18), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, v_ys_2477})});
    V v_t_2480 = heff_tag_at_n(v_ru_24x_2468_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2465), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str19), v_argv_2478, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam13_clo)})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
    v_c_2482 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2481}));
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam14, 1, 7, (V[]){v_x_2465, v_hd_2436, v_next_247, v_k_2437, v_who_242, v_out_246, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_lit_241 = heff_env(self)[0];
  V v_x_2457 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_x_2449 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2466;
  if (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str3), 2)) {
    v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str4);
  } else {
    if (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str5), 2)) {
      v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str6);
    } else {
      if (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str7), 2)) {
        v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str8);
      } else {
        if ((heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str9), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str10), 2))) {
          v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str11);
        } else {
          v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str12);
        }
      }
    }
  }
  V v_c_2467 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(heff_dup(v_x_2465), v_t_2466, v_x_2457, NTAG(TAG_Nil)));
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam11, 1, 9, (V[]){v_out_246, v_x_2449, v_lit_241, v_x_2465, v_hd_2436, v_next_247, v_k_2437, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_2436 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_k_2437 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    v_x_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    V v_ru_24x_2438_24Right = heff_take_reuse_n(v_x_2438, 1ULL, 1);
    v_x_2441 = heff_tag_at_n(v_ru_24x_2438_24Right, TAG_Just, 1, (V[]){v_y_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_dup(heff_field(v_x_2441, 0));
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str0); V a_1 = v_t_2443; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2449 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam7, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_245)}), v_t_2444));
  V v_t_2451;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    v_t_2451 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2450 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    v_t_2451 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_t_2452 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str1); V a_1 = v_t_2451; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2457 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam8, 1, 2, (V[]){v_st_243, v_dir_245}), v_t_2452));
  V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2449));
  V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2457));
  V v_total_2460 = heff_intAdd(heff_intAdd(v_t_2458, v_t_2459), MK_INT(1LL));
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_str2), v_total_2460, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam9_clo)})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam10, 1, 9, (V[]){v_lit_241, v_x_2457, v_hd_2436, v_out_246, v_x_2449, v_next_247, v_k_2437, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_lam6, 1, 10, (V[]){v_st_243, v_dir_245, v_p_244, v_hd_2436, v_lit_241, v_out_246, v_next_247, v_k_2437, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_2414}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_err_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2436})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2437));
  }
  case TAG_Right: {
    V v_x_2438 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam5, 2, 1, (V[]){v_x_2438});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447;
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    heff_take_n(v_x_2444, 0ULL, 1);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2444, 0ULL, 1);
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2444);
  }
  V f_ = v_k_2443;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_c_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2441;
  args[0] = v_hd_2442;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam7, 1, 1, (V[]){v_k_2443});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2449);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany_24s130813166x1111413304(v_n_245, v_parts_241));
  V v_c_2448;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_n_245);
    heff_drop(v_st_2417);
    heff_drop(v_t_2418);
    v_c_2448 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_dir_240)));
    V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_n_245));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_s_2424 = ({ V a_0 = v_st_2417; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2423); r_; });
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
    V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
    V v_a_2428 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3_clo)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_c_2441 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam4_clo)));
    v_c_2448 = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam6, 2, 1, (V[]){v_c_2441});
  }
  V f_ = v_c_2448;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam8, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str0, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str1, 14, "no definition ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str5, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str7, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112(V v_lit_240, V v_bi_241, V v_file_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_247)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_handled_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam0, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2413));
  HeffT2 v_t_2416 = (g_list_2efind_24s279352081x1530195138_24cpr(v_lit_240, heff_rfield(v_c_247, 7)));
  V v_t_2425;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_o_2419 = v_field_2418;
      HeffT2 v_t_2420 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(heff_dup(v_c_247), heff_rfield(v_o_2419, 1)));
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_eff_2423 = v_field_2422;
          V v_t_2424 = heff_rec_n(3, shape_name__key__effect, (V[]){v_lit_240, heff_get_n(v_o_2419, 1, 2), v_eff_2423});
          v_t_2425 = ({ V a_0 = v_handled_2415; V a_1 = v_t_2424; V r_ = (g_heff_2ebuild_2edriver_2efits(a_0, a_1)); heff_drop(v_handled_2415); r_; });
        } else {
          heff_drop(v_handled_2415);
          heff_drop_rec(v_o_2419, 2);
          heff_drop(v_field_2422);
          v_t_2425 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str0))});
        }
      }
    } else {
      heff_drop(v_handled_2415);
      heff_drop(v_field_2418);
      v_t_2425 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str1), v_lit_240)});
    }
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Left: {
    V v_why_2426 = heff_field(v_t_2425, 0);
    V v_ru_24t_2425_24Left = heff_take_reuse_n(v_t_2425, 1ULL, 1);
    heff_drop(v_bi_241);
    heff_drop(v_outPath_243);
    heff_drop_rec(v_rt_244, 2);
    heff_drop(v_done_246);
    heff_drop_rec(v_c_247, 14);
    heff_drop(v_available_248);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str2), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str3));
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, heff_dup(v_why_2426)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str4));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_at_n(v_ru_24t_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_249, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
    return heff_tail(heff_dup(heff_rfield(v_z_249, 1)), 2, (V[]){v_t_2436, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam1, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2426, v_z_249, v_z_2410})});
  }
  case TAG_Right: {
    V v_r_2439 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
    V v_t_2441 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2440), heff_strLength_lent(v_outPath_243, 0));
    if (heff_strEq_c(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str7))) {
      int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      return (g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(v_bi_241, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2442)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2439, v_z_249, v_z_2410));
    } else {
      heff_drop(v_bi_241);
      V v_t_2443 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 10);
      V v_t_2444 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_take_field(v_rt_244, 0), v_available_248, v_t_2443, heff_take_field(v_r_2439, 0), heff_get_n(v_r_2439, 1, 2)));
      return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(v_outPath_243, heff_get_n(v_rt_244, 1, 2), v_done_246, v_t_2444, v_z_249, v_z_2410));
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam0(V self, V *args) {
  V v_k_2414 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_lam1(V self, V *args) {
  V v_x_2437 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2426 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str5), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_str6));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2438, v_why_2426);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412;
  if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 8), v_x_249});
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_s_244, 8);
    v_t_2412 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (((heff_dup(heff_rfield(v_s_244, 7)) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0)))) {
    V v_c_2410 = ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(a_0, a_1)); heff_drop(v_host_240); r_; });
    V f_ = v_c_2410;
    heff_room[0] = v_hd_247;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_s_244, 8);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam5, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_245 = v_field_244;
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_path_245), heff_box_word(v_t_246), heff_strLength_lent(v_path_245, 0));
      V v_t_249;
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0))) {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_path_245, 0)) - ((int64_t)3ULL));
        v_t_249 = heff_strSlice(v_path_245, MK_INT(0LL), heff_box_word(v_t_248));
      } else {
        v_t_249 = v_path_245;
      }
      V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1))));
      V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
      V v_a_2413 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0_clo)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_c_2426 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1_clo)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3, 2, 2, (V[]){v_c_2426, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam5_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2421})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2422));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2, 2, 1, (V[]){v_x_2423});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_drop(v_m_241);
    V f_ = v_k_2428;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    V v_t_2432 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_y_2431})});
    V f_ = v_k_2428;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam4, 1, 2, (V[]){v_k_2428, v_m_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str2, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str3, 5, "error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str4, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str5, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str6, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str7, 2, "  ");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam0, 2, 1, (V[]){v_c_241});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072(a[0]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam5(V self, V *args) {
  V v_ev_2418 = args[0];
  V v_source_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2419 = heff_take_field(v_ev_2418, 0);
  V v_kind_2420 = heff_take_field(v_ev_2418, 1);
  V v_text_2421 = heff_get_n(v_ev_2418, 2, 3);
  V v_t_2422 = ({ V a_0 = v_source_2415; V a_1 = v_span_2419; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2415); r_; });
  V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str1)), v_kind_2420);
  V v_t_2424 = heff_tr(heff_call(v_text_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str2)), v_t_2424);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam6(V self, V *args) {
  V v_d_2426 = args[0];
  V v_source_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2427 = heff_take_field(v_d_2426, 3);
  V v_severity_2428 = heff_take_field(v_d_2426, 1);
  V v_msg_2429 = heff_get_n(v_d_2426, 2, 5);
  V v_t_2430 = ({ V a_0 = v_source_2415; V a_1 = v_span_2427; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2415); r_; });
  V v_t_2431;
  switch (heff_tag_of(v_severity_2428)) {
  case TAG_SError: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str5);
    break;
  }
  default: heff_nomatch(v_severity_2428);
  }
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str6)), v_t_2431);
  return heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str7)), v_msg_2429);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_cs_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  HeffT2 v_t_2410 = ({ V a_0 = v_cs_248; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_248); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_c_2414 = v_c_2413;
      V v_source_2415 = heff_take_field(v_c_2414, 3);
      V v_top_2416 = heff_take_field(v_c_2414, 5);
      V v_diags_2417 = heff_get_n(v_c_2414, 6, 14);
      V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam5, 1, 1, (V[]){heff_dup(v_source_2415)}), heff_get_n(v_top_2416, 8, 10)));
      V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam6, 1, 1, (V[]){v_source_2415}), v_diags_2417));
      V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2433));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2434, v_hd_242, v_k_243));
    } else {
      heff_drop(v_field_2412);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_242, v_k_243));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_cs_248 = heff_get_n(v_x_247, 0, 2);
  return ({ V a_0 = v_cs_248; V a_1 = heff_dup(v_hd_242); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam4, 1, 3, (V[]){heff_dup(v_cs_248), v_hd_242, v_k_243}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_248); r_; });
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam3, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam2, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s394213526x1739333072_lam1, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V v_checkOnly_240, V v_f_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_241)));
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_242); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_c_2418 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3, 2, 3, (V[]){v_c_2418, v_f_241, heff_dup(v_checkOnly_240)});
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2414));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2, 2, 1, (V[]){v_x_2415});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_k_2420;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_y_2433 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2436 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2435, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_y_2433; V a_3 = v_t_2436; V a_4 = v_hd_2419; V a_5 = v_k_2420; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    heff_drop(v_checkOnly_240);
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2421_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
    V f_ = heff_get_n(v_hd_2419, 1, 3);
    heff_room[0] = v_t_2431;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam5, 1, 1, (V[]){v_k_2420});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_c_2434 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_241)));
    V f_ = v_c_2434;
    heff_room[0] = heff_dup(v_hd_2419);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam6, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_y_2433, v_hd_2419, v_k_2420});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_checkOnly_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam4, 1, 4, (V[]){v_f_241, v_hd_2419, v_k_2420, v_checkOnly_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 0)));
    V v_x_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_243, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_s_2411 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_str0)));
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam1_clo)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    V v_c_2428 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam2_clo)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam4, 2, 7, (V[]){v_c_2428, v_st_240, v_t_241, v_acc_243, v_x_249, v_rd_242, v_rest_2410});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2423})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2424));
  }
  case TAG_Right: {
    V v_x_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam3, 2, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam7(V self, V *args) {
  V v_a_2451 = args[0];
  V v_lit_2438 = heff_env(self)[0];
  V v_lit_2439 = heff_env(self)[1];
  V v_lit_2440 = heff_env(self)[2];
  V v_lit_2441 = heff_env(self)[3];
  V v_lit_2442 = heff_env(self)[4];
  V v_lit_2443 = heff_env(self)[5];
  V v_lit_2444 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_a_2451);
  V v_t_2452 = (g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(v_lit_2438, v_lit_2439, v_lit_2440, v_lit_2441, v_lit_2442));
  V f_ = v_t_2452;
  heff_room[0] = v_lit_2443;
  heff_room[1] = v_lit_2444;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_hd_2429 = heff_env(self)[4];
  V v_k_2430 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_lit_2437 = heff_dup(v_rd_242);
  V v_lit_2438 = v_st_240;
  V v_lit_2439 = v_t_241;
  V v_lit_2440 = v_rd_242;
  V v_lit_2441 = v_x_2436;
  V v_lit_2442 = v_rest_2410;
  V v_lit_2443 = heff_dup(v_hd_2429);
  V v_lit_2444 = v_k_2430;
  V v_hd_2445 = v_hd_2429;
  V v_bind_2446 = heff_take_field(v_hd_2445, 1);
  V v_malg_2447 = heff_get_n(v_hd_2445, 2, 3);
  V v_t_2448 = heff_tag_n(TAG_Complete, 2, (V[]){v_lit_2437, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(v_malg_2447, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})}));
  V f_ = v_bind_2446;
  heff_room[0] = v_t_2450;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam7, 1, 7, (V[]){v_lit_2438, v_lit_2439, v_lit_2440, v_lit_2441, v_lit_2442, v_lit_2443, v_lit_2444});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_hd_2429 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_k_2430 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    heff_take_n(v_x_2431, 0ULL, 1);
    v_t_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    v_t_2434 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Just, 1, (V[]){v_y_2433});
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V v_c_2435 = (g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(heff_dup(v_st_240), heff_dup(v_t_241), v_acc_243, v_x_249, v_t_2434));
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam6, 1, 6, (V[]){v_rd_242, v_st_240, v_t_241, v_rest_2410, v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_lam5, 1, 8, (V[]){v_st_240, v_t_241, v_acc_243, v_x_249, v_hd_2429, v_rd_242, v_rest_2410, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bp_242);
    return v_done_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_name_247 = heff_dup(heff_rfield(v_a_245, 0));
    V v_build_248 = heff_dup(heff_rfield(v_a_245, 1));
    V v_t_249 = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_clo), 6, (V[]){v_st_240, v_t_241, v_bp_242, v_name_247, v_build_248, v_t_249});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str4, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str5, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam19(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam19, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam23(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam23, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam25(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam24(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam24, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam28(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam27(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam26(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam1, 1, 7, (V[]){v_st_240, v_home_242, v_n_245, v_hd_246, v_t_241, v_k_247, v_next_244})});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam2(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam4, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam6(V self, V *args) {
  V v_r_2443 = args[0];
  return v_r_2443;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam8(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2454});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Left: {
    V v_err_2452 = heff_field(v_x_2451, 0);
    V v_ru_24x_2451_24Left = heff_take_reuse_n(v_x_2451, 1ULL, 1);
    V v_t_2453 = heff_tag_at_n(v_ru_24x_2451_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2452})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2453));
  }
  case TAG_Right: {
    V v_x_2454 = heff_field(v_x_2451, 0);
    heff_take_n(v_x_2451, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam8, 2, 1, (V[]){v_x_2454});
  }
  default: return heff_nomatch(v_x_2451);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam10(V self, V *args) {
  V v_r_2467 = args[0];
  return v_r_2467;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam12(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_x_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2479);
  V f_ = v_k_2480;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2478});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam11(V self, V *args) {
  V v_x_2475 = args[0];
  switch (heff_tag_of(v_x_2475)) {
  case TAG_Left: {
    V v_err_2476 = heff_field(v_x_2475, 0);
    V v_ru_24x_2475_24Left = heff_take_reuse_n(v_x_2475, 1ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x_2475_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2476})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2477));
  }
  case TAG_Right: {
    V v_x_2478 = heff_field(v_x_2475, 0);
    heff_take_n(v_x_2475, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam12, 2, 1, (V[]){v_x_2478});
  }
  default: return heff_nomatch(v_x_2475);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam14(V self, V *args) {
  V v_r_2486 = args[0];
  return v_r_2486;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam16(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  V v_x_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2498);
  V f_ = v_k_2499;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2497});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam15(V self, V *args) {
  V v_x_2494 = args[0];
  switch (heff_tag_of(v_x_2494)) {
  case TAG_Left: {
    V v_err_2495 = heff_field(v_x_2494, 0);
    V v_ru_24x_2494_24Left = heff_take_reuse_n(v_x_2494, 1ULL, 1);
    V v_t_2496 = heff_tag_at_n(v_ru_24x_2494_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2495})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2496));
  }
  case TAG_Right: {
    V v_x_2497 = heff_field(v_x_2494, 0);
    heff_take_n(v_x_2494, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam16, 2, 1, (V[]){v_x_2497});
  }
  default: return heff_nomatch(v_x_2494);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam18(V self, V *args) {
  V v_x_24117 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24117);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam17(V self, V *args) {
  V v_x_24101 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24101);
  V v_t_24102 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_24103 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_245));
  V v_t_24104 = (g_std_2epath_2ejoin(v_t_24102, v_t_24103));
  V v_t_24105 = ({ V a_0 = v_st_240; V a_1 = v_t_24104; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24104); r_; });
  V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str4), v_t_24105), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str5));
  V v_why_24107 = heff_strAppend(v_t_24106, v_x_2417);
  V v_t_24108 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str6), v_why_24107), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str7));
  V v_t_24109 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24108, NTAG(TAG_MkUnit)});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24115})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_24116;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam18, 1, 2, (V[]){v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam19(V self, V *args) {
  V v_r_24127 = args[0];
  return v_r_24127;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam21(V self, V *args) {
  V v_hd_24139 = args[0];
  V v_k_24140 = args[1];
  V v_x_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24139);
  V f_ = v_k_24140;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24138});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam20(V self, V *args) {
  V v_x_24135 = args[0];
  switch (heff_tag_of(v_x_24135)) {
  case TAG_Left: {
    V v_err_24136 = heff_field(v_x_24135, 0);
    V v_ru_24x_24135_24Left = heff_take_reuse_n(v_x_24135, 1ULL, 1);
    V v_t_24137 = heff_tag_at_n(v_ru_24x_24135_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24136})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24137));
  }
  case TAG_Right: {
    V v_x_24138 = heff_field(v_x_24135, 0);
    heff_take_n(v_x_24135, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam21, 2, 1, (V[]){v_x_24138});
  }
  default: return heff_nomatch(v_x_24135);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam23(V self, V *args) {
  V v_r_24151 = args[0];
  return v_r_24151;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam25(V self, V *args) {
  V v_hd_24163 = args[0];
  V v_k_24164 = args[1];
  V v_x_24162 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24163);
  V f_ = v_k_24164;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24162});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam24(V self, V *args) {
  V v_x_24159 = args[0];
  switch (heff_tag_of(v_x_24159)) {
  case TAG_Left: {
    V v_err_24160 = heff_field(v_x_24159, 0);
    V v_ru_24x_24159_24Left = heff_take_reuse_n(v_x_24159, 1ULL, 1);
    V v_t_24161 = heff_tag_at_n(v_ru_24x_24159_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24160})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24161));
  }
  case TAG_Right: {
    V v_x_24162 = heff_field(v_x_24159, 0);
    heff_take_n(v_x_24159, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam25, 2, 1, (V[]){v_x_24162});
  }
  default: return heff_nomatch(v_x_24159);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam28(V self, V *args) {
  V v_x_24176 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_24174 = heff_env(self)[1];
  V v_k_24175 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24176);
  V f_ = v_next_244;
  heff_room[0] = v_hd_24174;
  heff_room[1] = v_k_24175;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam27(V self, V *args) {
  V v_hd_24174 = args[0];
  V v_k_24175 = args[1];
  V v_x_2412 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2412, heff_dup(v_hd_24174), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam28, 1, 3, (V[]){v_next_244, v_hd_24174, v_k_24175})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam26(V self, V *args) {
  V v_x_24166 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24167 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_home_242));
  V v_t_24168 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_245));
  V v_t_24169 = (g_std_2epath_2ejoin(v_t_24167, v_t_24168));
  V v_t_24170 = ({ V a_0 = v_st_240; V a_1 = v_t_24169; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24169); r_; });
  V v_t_24173;
  switch (heff_tag_of(v_x_24166)) {
  case TAG_Left: {
    heff_take_n(v_x_24166, 0ULL, 1);
    v_t_24173 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24166, 0ULL, 1);
    v_t_24173 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24166);
  }
  return ({ V a_0 = v_t_241; V a_1 = v_x_2417; V a_2 = v_x_2422; V a_3 = v_t_24170; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam27, 2, 2, (V[]){v_x_2412, v_next_244}); V a_5 = v_t_24173; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24173); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam22(V self, V *args) {
  V v_x_24142 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_home_242 = heff_env(self)[2];
  V v_n_245 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2422 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24142);
  V v_path_24143 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_t_24144 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_24145 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_245)));
  V v_t_24146 = (g_std_2epath_2ejoin(v_t_24144, v_t_24145));
  V v_s_24147 = ({ V a_0 = v_st_240; V a_1 = v_t_24146; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24146); r_; });
  V v_to_24148 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24147));
  V v_t_24149 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24143; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24143); r_; });
  V v_t_24150 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_24148; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_24148); r_; });
  V v_a_24152 = heff_tag_n(TAG_Move, 3, (V[]){v_t_24149, v_t_24150, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam23_clo)});
  V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24152})});
  V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
  V v_t_24155 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24154})});
  V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
  V v_t_24157 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
  V v_t_24158 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})});
  V v_c_24165 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24158}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam24_clo)));
  V f_ = v_c_24165;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam26, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_t_241, v_x_2417, v_x_2422, v_x_2412, v_next_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam13(V self, V *args) {
  V v_x_2482 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2422 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  V v_next_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2482)) {
  case TAG_Left: {
    V v_ru_24x_2482_24Left = heff_take_reuse_n(v_x_2482, 0ULL, 1);
    heff_drop(v_home_242);
    heff_drop(v_x_2422);
    heff_drop(v_x_2412);
    heff_drop(v_next_244);
    V v_path_2484 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
    V v_t_2485 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2484; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2484); r_; });
    V v_a_2487 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2485, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam14_clo)});
    V v_t_2488 = heff_tag_at_n(v_ru_24x_2482_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
    V v_c_24100 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2493}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam15_clo)));
    V f_ = v_c_24100;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam17, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2482_24Right = heff_take_reuse_n(v_x_2482, 0ULL, 1);
    V v_t_24119 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
    V v_t_24120 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_245)));
    V v_t_24121 = (g_std_2epath_2ejoin(v_t_24119, v_t_24120));
    V v_s_24122 = ({ V a_0 = v_st_240; V a_1 = v_t_24121; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24121); r_; });
    V v_path_24123 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24122));
    V v_to_24124 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2422)));
    V v_t_24125 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24123; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24123); r_; });
    V v_t_24126 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_24124; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_24124); r_; });
    V v_a_24128 = heff_tag_n(TAG_Move, 3, (V[]){v_t_24125, v_t_24126, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam19_clo)});
    V v_t_24129 = heff_tag_at_n(v_ru_24x_2482_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24128})});
    V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
    V v_c_24141 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24134}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam20_clo)));
    V f_ = v_c_24141;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam22, 1, 10, (V[]){v_x_2417, v_st_240, v_home_242, v_n_245, v_hd_246, v_t_241, v_x_2422, v_x_2412, v_next_244, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2482);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam9(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2422 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  V v_next_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_245)));
  V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
  V v_s_2462 = ({ V a_0 = v_st_240; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2461); r_; });
  V v_path_2463 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2462));
  V v_to_2464 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_t_2465 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2463; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2463); r_; });
  V v_t_2466 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2464; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2464); r_; });
  V v_a_2468 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2465, v_t_2466, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam10_clo)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  V v_c_2481 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam11_clo)));
  V f_ = v_c_2481;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam13, 1, 10, (V[]){v_x_2417, v_hd_246, v_st_240, v_t_241, v_n_245, v_k_247, v_home_242, v_x_2422, v_x_2412, v_next_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_home_242 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  V v_next_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2440);
  V v_path_2441 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2422)));
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2441; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2441); r_; });
  V v_a_2444 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam6_clo)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_c_2457 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam7_clo)));
  V f_ = v_c_2457;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam9, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_k_247, v_home_242, v_x_2422, v_x_2412, v_next_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str0), heff_dup(v_n_245)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str1));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2414));
  V v_t_2416 = (g_std_2epath_2ejoin(v_t_2413, v_t_2415));
  V v_x_2417 = ({ V a_0 = v_st_240; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str2), heff_dup(v_n_245)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_str3));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2419));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2418, v_t_2420));
  V v_x_2422 = ({ V a_0 = v_st_240; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam2_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam3_clo)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_lam5, 1, 10, (V[]){v_x_2422, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2417, v_k_247, v_home_242, v_x_2412, v_next_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str1, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_dup(heff_rfield(v_c_244, 7)); V r_ = (g_list_2emap_24f1730403549x1479772376(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str1), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(heff_get_n(v_c_244, 0, 14), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}