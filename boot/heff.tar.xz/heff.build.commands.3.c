// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Replace 14236
#define TAG_Settled 45257
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bug 307438
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_hashes 722717031
#define LBL_labels 836724522
#define LBL_library 398066429
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcome 1272833429
#define LBL_outcomes 803130769
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_segments 1801007612
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_value 313331083
#define LBL_wrong 314763719
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794_clo;
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_clo;
V g_heff_2ebuild_2ecommands_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestArgs_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo;
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1365429013x2045809870(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1365429013x2045809870_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1365429013x2045809870_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
V g_list_2eall_24s523006110x1088755562(V);
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a);
extern Clo g_list_2eall_24s523006110x1088755562_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1564977489x772952072(V, V);
V g_list_2efilter_24s1564977489x772952072_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f74587876x194913022(V, V, V);
V g_list_2emap_24f74587876x194913022_entry(V self, V *a);
extern Clo g_list_2emap_24f74587876x194913022_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_name_242 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2ebrokenJob_str0), heff_take_field(v_j_240, 3), heff_rfield(v_j_240, 4)));
  V v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_244 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_242, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_243, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_dup(heff_rfield(v_j_240, 0)), heff_get_n(v_j_240, 2, 6), v_t_244, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c_lent(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0), 2)) {
    heff_drop(v_dir_241);
    V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_x3_242));
    V v_xs_245 = heff_get_n(v_t_244, 2, 3);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      return v_x_247;
    }
    default: return heff_nomatch(v_x1_246);
    }
  } else {
    heff_drop(v_x3_242);
    V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2410 = heff_get_n(v_t_249, 2, 3);
    V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      heff_take_n(v_x1_2411, 1ULL, 2);
      return v_x_2412;
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str5, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str8, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str9, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str10, 4, "_app");
Clo g_heff_2ebuild_2ecommands_2enameLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameLike_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2enameLike(V v_x_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24f74587876x194913022(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str2); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enameLike_str3), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  V v_x2_246 = (g_list_2efilter_24s1564977489x772952072(MK_INT(0LL), v_t_245));
  V v_x_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_x_249 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_x_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str6), 2)) {
    heff_drop(v_x_249);
    v_x_2413 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str7);
  } else {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
        v_x_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enameLike_str8), v_x_249);
      } else {
        v_x_2413 = v_x_249;
      }
    } else {
      v_x_2413 = v_x_249;
    }
  }
  HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2413));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str9));
    } else {
      heff_drop(v_field_2416);
      if (heff_strEq_c(heff_dup(v_x_2413), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str10));
      } else {
        return v_x_2413;
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameLike(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str1, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str3, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V v_rep_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_rep_240), 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam2, 2, 4, (V[]){v_t_247, v_c_244, v_rep_240, v_rest_245});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam1(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam5(V self, V *args) {
  V v_d_2417 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_src_2416 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = (g_heff_2elsp_2erender_2ediagWhere(heff_get_n(v_c_244, 1, 14), v_src_2416, heff_dup(v_d_2417)));
  V v_t_2419 = ({ V a_0 = v_x_2410; V a_1 = v_src_2416; V a_2 = v_d_2417; V r_ = (g_heff_2elsp_2erender_2erenderDiag(a_0, a_1, a_2)); heff_drop(v_x_2410); heff_drop(v_src_2416); r_; });
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str0), heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str1)));
  return heff_strAppend(v_t_2418, v_t_2420);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, v_rest_245));
  V f_ = v_t_2434;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_dup(heff_rfield(v_c_244, 6));
  V v_c_2432;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    heff_drop(v_x_2410);
    heff_drop_rec(v_c_244, 14);
    v_c_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam4_clo);
    break;
  }
  case TAG_Cons: {
    V v_ru_24t_2411_24Cons = heff_take_reuse_n(v_t_2411, 0ULL, 2);
    V v_src_2416 = heff_dup(heff_rfield(v_c_244, 3));
    V v_x2_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam5, 1, 3, (V[]){heff_dup(v_c_244), v_src_2416, v_x_2410}), heff_get_n(v_c_244, 6, 14)));
    V v_str_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_str_2424 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_str_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag_at_n(v_ru_24t_2411_24Cons, TAG_WriteErr, 2, (V[]){v_str_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    v_c_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam6, 1, 4, (V[]){v_rep_240, v_rest_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_co_2eop_24s495635622x733177935(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_lam3, 1, 5, (V[]){v_c_244, v_hd_248, v_rep_240, v_rest_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str1)));
  V v_t_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_245), heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam1, 1, 4, (V[]){v_text_241, v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam2(V self, V *args) {
  V v_ok_2417 = args[0];
  return v_ok_2417;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_text_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    V v_t_2415 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str2), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_str3)));
    V v_t_2418 = heff_tag_n(TAG_Replace, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_2416), v_path_240, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_lam2_clo)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s495635622x733177935(v_t_2424, v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2414);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str0, 46, "heff test: --watch is not given with --update\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str2, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str5, 4, "test");
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703(V v_clock_240, V v_ex_241, V v_seed_242, V v_pattern_243, V v_jobs_244, V v_x4_245, V v_given_246) {
top: ;
  if ((heff_dup(v_x4_245) == NTAG(TAG_True))) {
    heff_drop(v_clock_240);
    heff_drop(v_ex_241);
    heff_drop(v_given_246);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam0_clo);
  } else {
    V v_c_2424 = (g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(v_seed_242, v_pattern_243, v_jobs_244, NTAG(TAG_False)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam2, 2, 7, (V[]){v_c_2424, v_given_246, heff_dup(v_seed_242), heff_dup(v_pattern_243), heff_dup(v_jobs_244), v_ex_241, v_clock_240});
  }
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703(a[0], a[1], a2, a3, a4, a5, a[6]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_249 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str0), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam1, 1, 2, (V[]){v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam5(V self, V *args) {
  V v_s_2430 = args[0];
  return v_s_2430;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_seed_242 = heff_env(self)[1];
  V v_pattern_243 = heff_env(self)[2];
  V v_jobs_244 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_st_2440 = heff_env(self)[6];
  V v_x_2447 = heff_env(self)[7];
  V v_hd_2425 = heff_env(self)[8];
  V v_k_2426 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2452;
  switch (heff_tag_of(v_given_246)) {
  case TAG_Nil: {
    v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str5), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_t_2452 = (g_prelude_2e_2b_2b(heff_dup(v_given_246), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_246);
  }
  V v_t_2453 = ({ V a_0 = v_seed_242; V a_1 = v_pattern_243; V a_2 = v_jobs_244; V a_3 = v_given_246; V r_ = (g_heff_2ebuild_2ecommands_2etestArgs(a_0, a_1, a_2, a_3)); heff_drop(v_seed_242); heff_drop(v_pattern_243); heff_drop(v_jobs_244); r_; });
  V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_clo), 2, (V[]){v_ex_241, v_t_2453}));
  return ({ V a_0 = v_clock_240; V a_1 = v_st_2440; V a_2 = v_t_2452; V a_3 = v_t_2454; V a_4 = v_x_2447; V a_5 = v_x_2449; V a_6 = v_hd_2425; V a_7 = v_k_2426; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1365429013x2045809870(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_2440); heff_drop(v_x_2447); heff_drop(v_k_2426); r_; });
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_seed_242 = heff_env(self)[0];
  V v_pattern_243 = heff_env(self)[1];
  V v_jobs_244 = heff_env(self)[2];
  V v_given_246 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_hd_2425 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_st_2440 = heff_env(self)[7];
  V v_k_2426 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2447;
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Nil: {
    v_x_2447 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2445 = heff_field(v_x_2444, 0);
    V v_xs_2446 = heff_field(v_x_2444, 1);
    heff_take_n(v_x_2444, 3ULL, 2);
    v_x_2447 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str4); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
    break;
  }
  default: heff_nomatch(v_x_2444);
  }
  V v_t_2448 = (g_heff_2ebuild_2ecommands_2etestArgs(v_seed_242, v_pattern_243, v_jobs_244, heff_dup(v_given_246)));
  return (g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744(heff_dup(v_ex_241), v_t_2448, MK_INT(0LL), heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam8, 1, 10, (V[]){v_given_246, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_st_2440, v_x_2447, v_hd_2425, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2440;
  if (heff_strEq_c(v_x_2438, ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str1))) {
    v_st_2440 = NTAG(TAG_Windows);
  } else {
    v_st_2440 = NTAG(TAG_Posix);
  }
  V v_paths_2443;
  switch (heff_tag_of(v_given_246)) {
  case TAG_Nil: {
    v_paths_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_str2), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_paths_2443 = (g_prelude_2e_2b_2b(heff_dup(v_given_246), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_246);
  }
  return ({ V a_0 = v_st_2440; V a_1 = NTAG(TAG_Nil); V a_2 = v_paths_2443; V a_3 = heff_dup(v_hd_2425); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam7, 1, 9, (V[]){v_seed_242, v_pattern_243, v_jobs_244, v_given_246, v_ex_241, v_hd_2425, v_clock_240, heff_dup(v_st_2440), v_k_2426}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2440); r_; });
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_given_246 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2429);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam5_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s495635622x733177935(v_t_2437, heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam6, 1, 8, (V[]){v_given_246, v_hd_2425, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2427);
  V v_c_2428 = (g_heff_2ebuild_2ecommands_2etestFiles_24s128002016x1644131443(heff_dup(v_given_246)));
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_hd_2425);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam4, 1, 8, (V[]){v_hd_2425, v_given_246, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_given_246 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s907508274x1620843703_lam3, 1, 8, (V[]){v_given_246, v_hd_2425, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str4, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str5, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str6, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str8, 7, ".golden");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str10, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str11, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str12, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str13, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str0); V a_1 = v_name_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str1), v_name_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s523006110x1088755562(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam0, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_2455 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str9); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_2456 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str10), heff_strAppend(v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str11)));
      V v_x_2457 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str12), v_t_2456), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str13)})});
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam5, 2, 1, (V[]){v_x_2457});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam1(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam3(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_st_2419 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2435 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2434), heff_strLength_lent(v_f_241, 0));
  V v_t_2438;
  if (heff_strEq_c(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str5))) {
    int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2438 = heff_strSlice_lent(v_f_241, MK_INT(0LL), heff_box_word(v_t_2437), 6);
  } else {
    v_t_2438 = heff_dup(v_f_241);
  }
  V v_s_2439 = (g_std_2epath_2ejoin(v_st_2419, heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str6)), heff_dup(v_name_243)));
  HeffT3 v_t_2440 = (g_std_2epath_2eparse_24cpr(v_st_2419, v_s_2439));
  V v_t_2447;
  {
    V v_field_2441 = v_t_2440.f[0];
    V v_field_2442 = v_t_2440.f[1];
    V v_field_2443 = v_t_2440.f[2];
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2443));
    V v_xs_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2444; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2444); r_; });
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2445));
    v_t_2447 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2441, v_field_2442, v_t_2446});
  }
  V v_t_2448 = (g_std_2epath_2erender(v_st_2419, v_t_2447));
  int64_t v_t_2449 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2450 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2449), heff_strLength_lent(v_f_241, 0));
  V v_t_2453;
  if (heff_strEq_c(v_t_2450, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str7))) {
    int64_t v_t_2452 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2453 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_2452));
  } else {
    v_t_2453 = v_f_241;
  }
  V v_t_2454 = ({ V a_0 = v_st_2419; V a_1 = heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str8)); V a_2 = v_name_243; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2419); r_; });
  return ({ V a_0 = v_update_240; V a_1 = v_t_2448; V a_2 = v_t_2454; V a_3 = v_text_244; V a_4 = v_x_2433; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2egoldenAgainst_24s1305568975x1392006300(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2419;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str2))) {
    v_st_2419 = NTAG(TAG_Windows);
  } else {
    v_st_2419 = NTAG(TAG_Posix);
  }
  int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_2421 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_2420), heff_strLength_lent(v_f_241, 0));
  V v_t_2424;
  if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str3))) {
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_2424 = heff_strSlice_lent(v_f_241, MK_INT(0LL), heff_box_word(v_t_2423), 6);
  } else {
    v_t_2424 = heff_dup(v_f_241);
  }
  V v_path_2425 = (g_std_2epath_2ejoin(v_st_2419, heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_str4)), heff_dup(v_name_243)));
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2425, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam3_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam4, 1, 7, (V[]){v_f_241, v_st_2419, v_name_243, v_update_240, v_text_244, v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam2, 1, 6, (V[]){v_f_241, v_name_243, v_hd_247, v_update_240, v_text_244, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_lam5(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_x_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = v_x_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str3, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str4, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str6, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ws_244 = heff_dup(heff_rfield(v_acc_241, 4));
  V v_t_2420;
  switch (heff_tag_of(v_ws_244)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_t_2420 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam1, 2, 1, (V[]){v_ws_244});
    break;
  }
  default: heff_nomatch(v_ws_244);
  }
  return heff_tail(v_t_2420, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam3, 1, 4, (V[]){v_opts_240, v_acc_241, v_p_242, v_p_243})});
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ws_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2418);
  V v_t_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str1), v_ws_244));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(v_t_2419, v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_ws_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str0), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam2, 1, 3, (V[]){v_ws_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2426, v_k_2427));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_opts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_strAppend(heff_get_n(v_opts_240, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str3));
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str4), v_t_2428), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str5));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam6, 1, 2, (V[]){v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam9(V self, V *args) {
  V v_x_2463 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2463);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_drop_rec(v_acc_241, 8);
    V v_t_2465 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_drop_rec(v_acc_241, 8);
      V v_t_2473 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), v_p_242, v_p_243));
    } else {
      V v_t_2480 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2480)) {
      case TAG_Nil: {
        heff_drop(v_p_242);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2480_24Cons = heff_take_reuse_n(v_t_2480, 0ULL, 2);
        V v_t_2483 = heff_tag_at_n(v_ru_24t_2480_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
        V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
        V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
        V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
        V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
        V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2480);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam8(V self, V *args) {
  V v_x_2448 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
  V v_t_2450 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
  V v_t_2451 = (g_heff_2ebuild_2ecommands_2etestsHeld(heff_dup(heff_rfield(v_acc_241, 5)), heff_dup(heff_rfield(v_acc_241, 6)), heff_dup(heff_rfield(v_acc_241, 7))));
  V v_t_2452 = (g_heff_2ebuild_2ecommands_2efilesSaid(heff_dup(v_acc_241)));
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str6), heff_strAppend(v_t_2451, v_t_2452));
  V v_t_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str7), heff_strAppend(v_t_2450, v_t_2453));
  V v_str_2455 = heff_strAppend(heff_intShow(v_t_2449), v_t_2454);
  V v_t_2456 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2455, ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str8)), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam9, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2421);
  V v_t_2447;
  if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_str2))) {
    heff_drop_rec(v_opts_240, 4);
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam4_clo);
  } else {
    if (heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 5)), MK_INT(0LL))) {
      v_t_2447 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam5, 2, 1, (V[]){v_opts_240});
    } else {
      heff_drop_rec(v_opts_240, 4);
      v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam7_clo);
    }
  }
  V f_ = v_t_2447;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_lam8, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_str1, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(V v_rep_240, V v_opts_241, V v_f_242, V v_x3_243, V v_l_244, V v_z_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x3_243) == NTAG(TAG_True))) {
    if (heff_strEq_c(heff_get_n(v_opts_241, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_str0))) {
      V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_l_244)));
      return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam0, 1, 4, (V[]){v_l_244, v_f_242, v_z_245, v_z_246})});
    } else {
      heff_drop(v_f_242);
      heff_drop_rec(v_l_244, 5);
      heff_drop(v_z_245);
      return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_str1), heff_dup(heff_rfield(v_l_244, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam2, 1, 6, (V[]){v_l_244, v_z_245, heff_dup(v_rep_240), v_opts_241, v_f_242, v_z_246})));
  }
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_get_n(v_l_244, 1, 5);
  V v_t_2413;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    v_t_2413 = ({ V b_0 = heff_get_n(v_x_249, 0, 2); V r_ = (g_list_2eany_24s469495312x865582084(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2410, 0ULL, 2);
    heff_drop_rec(v_x_249, 2);
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2413; V a_2 = v_z_245; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam1, 1, 1, (V[]){v_z_246}); V r_ = (g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_l_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_l_244; V a_4 = heff_get_n(v_x_2417, 0, 2); V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_c_2416 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_l_244)));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_lam3, 1, 6, (V[]){v_rep_240, v_opts_241, v_f_242, v_l_244, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 8), v_x_249});
  } else {
    heff_drop(v_x_2413);
    heff_drop_rec(v_s_244, 8);
    v_t_2414 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_dup(heff_rfield(v_s_244, 7));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_str0))) {
      return ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V a_2 = v_hd_247; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385(a_0, a_1, a_2, a_3)); heff_drop(v_host_240); r_; });
    } else {
      heff_drop_rec(v_s_244, 8);
      heff_drop(v_host_240);
      heff_drop(v_hd_247);
      V f_ = v_k_248;
      args[0] = v_x_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_s_244, 8);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    heff_drop(v_t_2410);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(V v_rep_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam0, 2, 6, (V[]){v_c_245, v_rep_240, v_file_243, heff_dup(v_name_241), v_outPath_242, v_done_244});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_249 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2412 = (g_list_2emap_24s1698496827x1884878103(heff_dup(heff_rfield(v_x_2411, 0))));
  V v_t_2413 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_248, 2), heff_take_field(v_x_2411, 1), v_t_2412});
  return ({ V a_0 = v_rep_240; V a_1 = v_t_2413; V a_2 = heff_get_n(v_x_248, 0, 5); V a_3 = v_file_243; V a_4 = v_name_241; V a_5 = v_outPath_242; V a_6 = v_done_244; V b_7 = heff_intLt(MK_INT(0LL), v_x_249); V a_8 = heff_get_n(v_x_2411, 0, 2); V a_9 = v_hd_246; V a_10 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7, a_8, a_9, a_10)); heff_drop(v_name_241); heff_drop(b_7); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_x_248)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam3, 1, 9, (V[]){v_x_248, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_249, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_str0), heff_dup(heff_rfield(v_x_248, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam2, 1, 8, (V[]){v_x_248, v_hd_246, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_lam1, 1, 7, (V[]){v_hd_246, v_rep_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644(V v_rep_240, V v_file_241, V v_outPath_242, V v_badL_243, V v_cs_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_244)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_lam0, 1, 5, (V[]){v_cs_244, heff_dup(v_badL_243), v_outPath_242, v_z_245, v_z_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s1421835334x1871252644_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_cs_244 = heff_env(self)[0];
  V v_badL_243 = heff_env(self)[1];
  V v_outPath_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_248);
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_244)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2414;
      if ((heff_dup(v_badL_243) == NTAG(TAG_True))) {
        heff_drop(v_cs_244);
        heff_drop(v_badL_243);
        v_t_2414 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_243);
        v_t_2414 = ({ V a_0 = v_cs_244; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_244); r_; });
      }
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 9);
      V v_t_2416 = (g_list_2emap_24s1234524601x742515152(heff_get_n(v_c_2413, 7, 14)));
      V v_t_2417 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2415, v_t_2416));
      return ({ V a_0 = v_outPath_242; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_z_245; V a_4 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
    } else {
      heff_drop(v_cs_244);
      heff_drop(v_badL_243);
      heff_drop(v_outPath_242);
      heff_drop(v_field_2411);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_z_245, v_z_246));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210(V v_rep_240, V v_prog_241, V v_st_242, V v_cmd_243, V v_t_244, V v_none_245, V v_done_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str0)));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_2410, NTAG(TAG_Nil)));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam0, 1, 9, (V[]){v_prog_241, v_z_247, v_rep_240, v_cmd_243, v_z_248, v_st_242, v_t_244, v_none_245, v_done_246})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam7(V self, V *args) {
  V v_ns_2459 = args[0];
  return v_ns_2459;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam9(V self, V *args) {
  V v_t_2470 = args[0];
  return v_t_2470;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam13(V self, V *args) {
  V v_x_2495 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam12(V self, V *args) {
  V v_x_2480 = args[0];
  V v_x_2477 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_none_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_st_242 = heff_env(self)[7];
  V v_t_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2480);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2477, 1)))) {
    heff_drop(v_none_245);
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_done_246);
    V v_n_2482 = heff_get_n(v_x_2477, 1, 2);
    V v_t_2484;
    if (heff_intEq_c_lent(v_n_2482, MK_INT(1LL), 2)) {
      heff_drop(v_n_2482);
      v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str17);
    } else {
      v_t_2484 = heff_strAppend(heff_intShow(v_n_2482), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str18));
    }
    V v_what_2485 = heff_strAppend(v_t_2484, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str19));
    V v_t_2486 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str20), heff_strAppend(v_what_2485, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str21)));
    V v_t_2487 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str22), heff_strAppend(v_cmd_243, v_t_2486));
    V v_t_2488 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2487, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str23)), NTAG(TAG_MkUnit)});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam13, 1, 2, (V[]){v_z_247, v_z_248})));
  } else {
    heff_drop(v_cmd_243);
    V v_t_24103 = heff_dup(heff_rfield(v_x_2477, 0));
    switch (heff_tag_of(v_t_24103)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2477, 2);
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_244, 6);
      heff_drop(v_done_246);
      V f_ = v_none_245;
      heff_room[0] = v_z_247;
      heff_room[1] = v_z_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_24103, 0ULL, 2);
      heff_drop(v_none_245);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883(v_rep_240, v_prog_241, v_st_242, v_t_244, v_done_246, heff_get_n(v_x_2477, 0, 2), v_z_247, v_z_248));
    }
    default: return heff_nomatch(v_t_24103);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam11(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2472 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_none_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_st_242 = heff_env(self)[7];
  V v_t_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2478 = heff_tag_n(TAG_End, 2, (V[]){v_x_2472, NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2478}));
  return (g_co_2eop_24s495635622x733177935(v_t_2479, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam12, 1, 10, (V[]){v_x_2477, v_cmd_243, v_z_247, v_z_248, v_none_245, v_rep_240, v_prog_241, v_st_242, v_t_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam10(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_cmd_243 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2473 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2475;
  switch (heff_tag_of(v_x_2466)) {
  case TAG_Nothing: {
    v_t_2475 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2474 = heff_field(v_x_2466, 0);
    heff_take_n(v_x_2466, 1ULL, 1);
    v_t_2475 = v_x_2474;
    break;
  }
  default: heff_nomatch(v_x_2466);
  }
  V v_c_2476 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_244), heff_dup(v_x_2472), v_t_2473, v_t_2475));
  V f_ = v_c_2476;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam11, 1, 10, (V[]){v_x_2472, v_prog_241, v_z_247, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_st_242, v_t_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam8(V self, V *args) {
  V v_x_2466 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_none_245 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2468;
  switch (heff_tag_of(v_x_2466)) {
  case TAG_Nothing: {
    v_t_2468 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2467 = heff_dup(heff_field(v_x_2466, 0));
    v_t_2468 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_x_2466);
  }
  V v_total_2469 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2468; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
  V v_t_2471 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str16), v_total_2469, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam9_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2471, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam10, 1, 10, (V[]){v_x_2466, v_prog_241, v_st_242, v_t_244, v_z_247, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam6(V self, V *args) {
  V v_x_2457 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_none_245 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2457);
  V v_path_2458 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str15)));
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_2458, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam7_clo)})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam8, 1, 9, (V[]){v_prog_241, v_z_247, v_st_242, v_t_244, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_st_242 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2419, 1)))) {
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_prog_241);
    heff_drop(v_none_245);
    heff_drop(v_rep_240);
    heff_drop(v_done_246);
    V v_n_2424 = heff_get_n(v_x_2419, 1, 2);
    V v_t_2426;
    if (heff_intEq_c_lent(v_n_2424, MK_INT(1LL), 2)) {
      heff_drop(v_n_2424);
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str2);
    } else {
      v_t_2426 = heff_strAppend(heff_intShow(v_n_2424), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str3));
    }
    V v_what_2427 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str4));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str5), heff_strAppend(v_what_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str6)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str7), heff_strAppend(v_cmd_243, v_t_2428));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str8)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam5, 1, 2, (V[]){v_z_247, v_z_248})));
  } else {
    V v_n_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2419, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2447;
    if (heff_intEq_c_lent(v_n_2445, MK_INT(1LL), 2)) {
      heff_drop(v_n_2445);
      v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str9);
    } else {
      v_t_2447 = heff_strAppend(heff_intShow(v_n_2445), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str10));
    }
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str11), heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str12)));
    V v_str_2449 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str13), heff_strAppend(heff_dup(v_cmd_243), v_t_2448));
    V v_t_2450 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2449, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str14)), NTAG(TAG_MkUnit)});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam6, 1, 9, (V[]){v_st_242, v_t_244, v_z_247, v_prog_241, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2420}));
  return (g_co_2eop_24s495635622x733177935(v_t_2421, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam4, 1, 10, (V[]){v_x_2419, v_cmd_243, v_z_247, v_z_248, v_st_242, v_t_244, v_prog_241, v_none_245, v_rep_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  V v_none_245 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2418 = ({ V a_0 = heff_dup(v_rep_240); V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_x_2416); V a_3 = v_t_2417; V a_4 = v_x_2412; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2412); r_; });
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam3, 1, 10, (V[]){v_x_2416, v_prog_241, v_z_247, v_cmd_243, v_z_248, v_st_242, v_t_244, v_none_245, v_rep_240, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_total_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2412));
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_str1), v_total_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam1_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_lam2, 1, 10, (V[]){v_rep_240, v_prog_241, v_x_2412, v_z_247, v_cmd_243, v_z_248, v_st_242, v_t_244, v_none_245, v_done_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_str0, 0, "");
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(V v_rep_240, V v_x1_241, V v_acc_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x1_241, 0);
    V v_rest_246 = heff_field(v_x1_241, 1);
    return ({ V a_0 = MK_INT(2026LL); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_str0); V a_2 = MK_INT(1LL); V a_3 = v_rep_240; V a_4 = heff_dup(v_f_245); V a_5 = heff_dup(v_p_243); V a_6 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam0, 1, 5, (V[]){heff_dup(v_rep_240), v_p_243, v_acc_242, heff_dup(v_rest_246), v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); r_; });
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_r_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_p_2411 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_2411, 0)), heff_dup(heff_rfield(v_p_2411, 1)), heff_get_n(v_p_2411, 2, 7), v_x_2415, v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_p_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam3, 1, 4, (V[]){v_rep_240, v_p_2411, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_242, v_x_2417));
  return ({ V a_0 = v_rep_240; V a_1 = v_rest_246; V a_2 = v_t_2418; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Settled: {
    V v_r_248 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    v_c_2416 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam1, 2, 1, (V[]){v_r_248});
    break;
  }
  case TAG_Pend: {
    V v_p_2411 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    V v_c_2412 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(heff_rfield(v_p_2411, 0)); V a_2 = heff_dup(heff_rfield(v_p_2411, 3)); V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_c_2416 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam2, 2, 3, (V[]){v_c_2412, heff_dup(v_rep_240), v_p_2411});
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_lam4, 1, 5, (V[]){v_acc_242, v_rep_240, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str10, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str12, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str10), v_v_240));
    V v_t_2412 = heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str11), v_t_2411));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str12), v_t_2412), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str13));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2421 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str14), v_why_2421), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str15));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam3(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str8), v_t_248})});
    return (g_heff_2ebuild_2ecommands_2egitOk_24s15271929x2099161794(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam1, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2438 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str16), v_why_2438), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_str17));
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_str0), heff_dup(heff_rfield(v_d_243, 1)));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 0)), v_t_245);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_str1)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    HEFF_LAST return g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_d_243, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_get_n(v_d_243, 2, 3);
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2415);
    heff_drop(v_t_2416);
    v_t_2417 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = v_x_2415;
  }
  V f_ = v_p_242;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_lam1, 1, 2, (V[]){v_d_243, v_p_242})));
}