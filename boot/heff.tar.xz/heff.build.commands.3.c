// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Inherited 58190
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_library 398066429
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_outcome 1272833429
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_sources 357464573
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_update 1108295668
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo;
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo;
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s249844099x1984022322(V, V);
V g_list_2ekeepIf_24s249844099x1984022322_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s249844099x1984022322_clo;
V g_list_2emap_24f1533062604x661716706(V);
V g_list_2emap_24f1533062604x661716706_entry(V self, V *a);
extern Clo g_list_2emap_24f1533062604x661716706_clo;
V g_list_2emap_24f74587876x194913022(V, V, V);
V g_list_2emap_24f74587876x194913022_entry(V self, V *a);
extern Clo g_list_2emap_24f74587876x194913022_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V, V);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_name_242 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2ebrokenJob_str0), heff_take_field(v_j_240, 3), heff_rfield(v_j_240, 4)));
  V v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_244 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_242, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_243, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_dup(heff_rfield(v_j_240, 0)), heff_get_n(v_j_240, 2, 6), v_t_244, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c_lent(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0), 2)) {
    heff_drop(v_dir_241);
    HeffT3 v_t_244 = (g_std_2epath_2eparse_24cpr(v_st_240, v_x3_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      V v_x11_248 = v_field_245;
      heff_drop(v_x11_248);
      V v_x12_249 = v_field_246;
      heff_drop(v_x12_249);
      V v_xs_2410 = v_field_247;
      V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 2);
        return v_x_2412;
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
  } else {
    heff_drop(v_x3_242);
    HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(v_st_240, v_dir_241));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_field_2417 = v_t_2414.f[2];
      V v_x11_2418 = v_field_2415;
      heff_drop(v_x11_2418);
      V v_x12_2419 = v_field_2416;
      heff_drop(v_x12_2419);
      V v_xs_2420 = v_field_2417;
      V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 2);
        return v_x_2422;
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str5, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str8, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str9, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enameLike_str10, 4, "_app");
Clo g_heff_2ebuild_2ecommands_2enameLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enameLike_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2enameLike(V v_x_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24f74587876x194913022(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str2); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enameLike_str3), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  V v_x2_246 = (g_list_2ekeepIf_24s249844099x1984022322(MK_INT(0LL), v_t_245));
  V v_x_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_x_249 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_x_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str6), 2)) {
    heff_drop(v_x_249);
    v_x_2413 = ((V)&g_heff_2ebuild_2ecommands_2enameLike_str7);
  } else {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_249, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
        v_x_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enameLike_str8), v_x_249);
      } else {
        v_x_2413 = v_x_249;
      }
    } else {
      v_x_2413 = v_x_249;
    }
  }
  HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2413));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str9));
    } else {
      heff_drop(v_field_2416);
      if (heff_strEq_c(heff_dup(v_x_2413), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        return heff_strAppend(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2enameLike_str10));
      } else {
        return v_x_2413;
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enameLike(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(V v_rep_240, V v_badLoad_241, V v_cs_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0, 1, 4, (V[]){v_cs_242, v_z_243, heff_dup(v_badLoad_241), v_z_244})});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_badLoad_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2420);
  if ((heff_dup(v_badLoad_241) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_241);
    heff_drop(v_cs_242);
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_243, v_z_244));
  } else {
    heff_drop(v_badLoad_241);
    V v_t_2428 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_243, v_z_244));
    } else {
      heff_drop(v_z_243);
      heff_drop(v_t_2428);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_badLoad_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      V v_str_2412 = (g_heff_2ebuild_2edriver_2einterface(v_c_2411));
      V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1610559056x1820690235_lam1, 1, 4, (V[]){v_badLoad_241, v_z_243, v_z_244, v_cs_242})));
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badLoad_241);
      heff_drop(v_field_249);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, v_z_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s615738393x1686646143(v_t_2414, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1, 1, 6, (V[]){heff_dup(v_n_245), heff_dup(v_parts_241), v_dir_240, v_p_243, heff_dup(v_rest_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); heff_drop(v_rest_246); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany_24s1230506745x754542351(v_n_245, v_parts_241));
  V v_c_2426;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_n_245);
    heff_drop(v_st_2417);
    heff_drop(v_t_2418);
    v_c_2426 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam2_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2417, heff_dup(v_dir_240)));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2417, v_n_245));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_s_2424 = ({ V a_0 = v_st_2417; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2423); r_; });
    V v_t_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2424; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    v_c_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2425); r_; });
  }
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_lam3, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str1, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str2, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str6, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str7, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str8, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(V v_ex_240, V v_argv_241, V v_n_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2415;
  if ((heff_peek_word(v_n_242) == ((int64_t)0ULL))) {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0_clo);
  } else {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str0), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    v_t_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  }
  return heff_tail(v_t_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1, 1, 5, (V[]){v_hd_243, v_argv_241, v_ex_240, v_n_242, v_k_244})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2439);
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_k_2421;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam6, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_intShow(heff_box_word((heff_peek_word(v_n_242) + ((int64_t)1ULL))));
  V v_t_2424 = heff_get_n(v_x_2422, 0, 3);
  V v_t_2428;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Exited: {
    V v_n_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    if (heff_intEq_c(v_n_2425, MK_INT(0LL))) {
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str1);
    } else {
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str2);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str3);
    break;
  }
  case TAG_TimedOut: {
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str4);
    break;
  }
  case TAG_NotRun: {
    v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str5);
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str6), heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str7)));
  V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str8), heff_strAppend(v_t_2423, v_t_2429));
  V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str9)), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam5, 1, 2, (V[]){v_k_2421, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam4, 1, 3, (V[]){v_n_242, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2453);
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V f_ = v_k_2444;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam9, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7(V self, V *args) {
  V v_err_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_err_2442);
  V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_str10), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_hd_2443, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam8, 1, 2, (V[]){v_k_2444, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2457;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2417, v_argv_241, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2419 = (g_std_2eprocess_2ewithProcess_24s1345957496x637138289(heff_dup(v_ex_240), v_t_2418));
  V v_t_2456 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam3, 2, 2, (V[]){v_c_2419, heff_dup(v_n_242)}), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam7, 3, 1, (V[]){v_n_242})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2456, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam10, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_lam2, 1, 5, (V[]){v_argv_241, v_ex_240, v_n_242, v_hd_243, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 8), v_x_249});
  } else {
    heff_drop(v_x_2414);
    heff_drop_rec(v_s_244, 8);
    v_t_2415 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_dup(heff_rfield(v_s_244, 7));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_str0))) {
      V v_c_2413 = ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(a_0, a_1)); heff_drop(v_host_240); r_; });
      V f_ = v_c_2413;
      heff_room[0] = v_hd_247;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop_rec(v_s_244, 8);
      heff_drop(v_host_240);
      heff_drop(v_hd_247);
      V f_ = v_k_248;
      args[0] = v_x_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_s_244, 8);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    heff_drop(v_t_2410);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_247), heff_strLength_lent(v_path_246, 0));
      V v_t_2411;
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str0))) {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
        v_t_2411 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2410));
      } else {
        v_t_2411 = v_path_246;
      }
      V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2412); r_; });
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0, 2, 2, (V[]){v_c_2413, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2417})});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam1, 1, 2, (V[]){v_m_241, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V v_checkOnly_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_242); r_; });
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0, 2, 3, (V[]){v_c_243, v_f_241, heff_dup(v_checkOnly_240)});
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2415);
  V f_ = v_k_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2416 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2418, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2416; V a_3 = v_t_2419; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_str1));
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_247, NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam2, 1, 1, (V[]){v_k_245})));
  }
  case TAG_Just: {
    V v_src_2416 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_c_2417 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_241)));
    V f_ = v_c_2417;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2416, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_checkOnly_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_lam1, 1, 4, (V[]){v_f_241, v_hd_244, v_k_245, v_checkOnly_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(V v_rep_240, V v_prog_241, V v_chk_242, V v_x2_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_chk_242);
    V v_x_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_f_248 = heff_field(v_x2_243, 0);
    V v_rest_249 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_chk_242), heff_dup(v_f_248), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2, 2, 7, (V[]){v_t_2411, v_f_248, v_rep_240, v_prog_241, v_acc_244, v_chk_242, v_rest_249});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_cs_2420 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2412 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2428);
  V v_t_2437;
  if (heff_intLt_c(MK_INT(0LL), v_x_2417)) {
    V v_found_2430 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_2420));
    heff_drop(v_found_2430);
    v_t_2437 = v_acc_244;
  } else {
    V v_bad_2431 = (g_list_2eany_24s1740858080x874135214(v_cs_2420));
    HeffT2 v_t_2432 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2420));
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((heff_dup(v_bad_2431) == NTAG(TAG_True))) {
        heff_drop(v_bad_2431);
        heff_drop(v_field_2434);
        v_t_2437 = v_acc_244;
      } else {
        heff_drop(v_bad_2431);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          V v_c_2436 = v_field_2434;
          v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2436, v_acc_244});
        } else {
          heff_drop(v_field_2434);
          v_t_2437 = v_acc_244;
        }
      }
    }
  }
  V v_t_2438 = (g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(v_rep_240, v_prog_241, v_chk_242, v_rest_249, v_t_2437));
  V f_ = v_t_2438;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_cs_2420 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_chk_242 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  V v_k_2413 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2426}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2427, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam9, 1, 9, (V[]){v_x_2417, v_cs_2420, v_acc_244, v_rep_240, v_prog_241, v_chk_242, v_rest_249, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_chk_242 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_cs_2420 = heff_get_n(v_x_2419, 0, 2);
  V v_t_2421 = (g_list_2eany_24s1740858080x874135214(v_cs_2420));
  V v_c_2424;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_c_2424 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(heff_dup(v_rep_240), heff_dup(v_cs_2420)));
  } else {
    heff_drop(v_t_2421);
    v_c_2424 = ((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam7_clo);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam8, 1, 10, (V[]){v_x_2414, v_prog_241, v_hd_2412, v_x_2417, v_cs_2420, v_acc_244, v_rep_240, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_chk_242 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2418 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_2416));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam6, 1, 9, (V[]){v_rep_240, v_hd_2412, v_x_2414, v_prog_241, v_x_2417, v_acc_244, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_str0), heff_dup(heff_rfield(v_x_2416, 1)), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam5, 1, 9, (V[]){v_x_2416, v_hd_2412, v_rep_240, v_x_2414, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2415 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_f_248));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam4, 1, 8, (V[]){v_hd_2412, v_rep_240, v_x_2414, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_acc_244 = heff_env(self)[4];
  V v_chk_242 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_lam3, 1, 8, (V[]){v_f_248, v_hd_2412, v_rep_240, v_prog_241, v_acc_244, v_chk_242, v_rest_249, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str1, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str3, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str5, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str12, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str13, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str14, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str15, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str16, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str17, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str18, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str19, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str20, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str21, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str22, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str23, 17, "the commit is of ");
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V v_path_240, V v_v_241, V v_time_242, V v_hash_243, V v_dir_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str0), v_t_245), ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str1));
  V v_t_247 = heff_strAppend(heff_dup(v_hash_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str2), v_t_246));
  V v_t_248 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str3), v_t_247));
  V v_t_249 = heff_strAppend(heff_dup(v_path_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str4), v_t_248));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str5), v_t_249);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0, 2, 5, (V[]){v_path_240, v_dir_244, v_x_2410, v_hash_243, v_time_242});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_time_242 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2458 = heff_take_field(v_x_2455, 0);
  V v_t_2462;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Exited: {
    V v_n_2459 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 1);
    v_t_2462 = heff_bool(!heff_intEq_c_lent(v_n_2459, MK_INT(0LL), 2));
    heff_drop(v_n_2459);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2458, 0ULL, 1);
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_x_2474;
  if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
    heff_drop(v_x_2457);
    heff_drop(v_time_242);
    heff_drop(v_t_2462);
    V v_s_2463 = heff_get_n(v_x_2455, 2, 3);
    V v_t_2464 = (g_prelude_2eskipSpaces(v_s_2463, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2465 = (heff_unbox_word(heff_strLength_lent(v_s_2463, 0)) - ((int64_t)1ULL));
    V v_t_2466 = (g_prelude_2eskipSpaces(v_s_2463, heff_box_word(v_t_2465), MK_INT(-1LL)));
    V v_t_2467 = heff_strSlice(v_s_2463, v_t_2464, heff_intAdd(v_t_2466, MK_INT(1LL)));
    v_x_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2467)});
  } else {
    heff_drop_rec(v_x_2455, 3);
    heff_drop(v_t_2462);
    switch (heff_tag_of(v_x_2457)) {
    case TAG_Nothing: {
      heff_drop(v_time_242);
      v_x_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str21))});
      break;
    }
    case TAG_Just: {
      V v_it1_2468 = heff_field(v_x_2457, 0);
      V v_ru_24x_2457_24Just = heff_take_reuse_n(v_x_2457, 1ULL, 1);
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_MkPair: {
        V v_t_2469 = heff_field(v_it1_2468, 0);
        heff_take_n(v_it1_2468, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2469, v_time_242, 0)) {
          heff_drop(v_x_2410);
          heff_drop(v_time_242);
          heff_drop_cell(v_ru_24x_2457_24Just, 1);
          heff_drop(v_t_2469);
          v_x_2474 = NTAG(TAG_Nothing);
        } else {
          V v_t_2472 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str22), v_time_242));
          V v_t_2473 = heff_strAppend(v_x_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str23), v_t_2472));
          v_x_2474 = heff_tag_at_n(v_ru_24x_2457_24Just, TAG_Just, 1, (V[]){v_t_2473});
        }
        break;
      }
      default: heff_nomatch(v_it1_2468);
      }
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
  }
  V f_ = v_k_2412;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4(V self, V *args) {
  V v_x_2455 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2456 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(v_dir_244, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str20)));
  V f_ = v_c_2456;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam5, 1, 4, (V[]){v_x_2455, v_x_2410, v_time_242, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_time_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = heff_take_field(v_x_2429, 0);
  V v_t_2434;
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Exited: {
    V v_n_2431 = heff_field(v_t_2430, 0);
    heff_take_n(v_t_2430, 1ULL, 1);
    v_t_2434 = heff_bool(!heff_intEq_c_lent(v_n_2431, MK_INT(0LL), 2));
    heff_drop(v_n_2431);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2430, 0ULL, 1);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2430);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_dir_244);
    heff_drop(v_hash_243);
    heff_drop(v_hd_2411);
    heff_drop(v_time_242);
    heff_drop(v_t_2434);
    V v_s_2435 = heff_get_n(v_x_2429, 2, 3);
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2435, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_s_2435, 0)) - ((int64_t)1ULL));
    V v_t_2438 = (g_prelude_2eskipSpaces(v_s_2435, heff_box_word(v_t_2437), MK_INT(-1LL)));
    V v_t_2439 = heff_strSlice(v_s_2435, v_t_2436, heff_intAdd(v_t_2438, MK_INT(1LL)));
    V v_x_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2439)});
    V f_ = v_k_2412;
    args[0] = v_x_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop_rec(v_x_2429, 3);
    heff_drop(v_t_2434);
    V v_t_2441 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_243, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str13)), NTAG(TAG_Nil)});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str15), v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str17), v_t_2443})});
    V v_t_2445 = ({ V a_0 = v_t_2441; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2441); r_; });
    V v_t_2446 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str19), v_t_2444}), v_t_2445, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2448 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam3_clo)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam4, 1, 5, (V[]){v_dir_244, v_hd_2411, v_x_2410, v_time_242, v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_240 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_time_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_244), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str6), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str8), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str10), v_t_2416})});
  V v_t_2418 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str11);
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_str12), v_t_2417, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2422 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam1_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_lam2, 1, 6, (V[]){v_x_2410, v_k_2412, v_dir_244, v_hash_243, v_hd_2411, v_time_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_str0, 10, "heff build");
Clo g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(V v_prog_240, V v_st_241, V v_t_242, V v_p_243, V v_x_244, V v_next_245) {
top: ;
  V v_dir_246 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_a_247 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_t_248 = (g_std_2epath_2eparse(v_st_241, v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_241, v_x_244));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_out_2411 = ({ V a_0 = v_st_241; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_242, 5, 6), NTAG(TAG_Nil)});
  return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(MK_INT(1LL), v_prog_240, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_str0), v_st_241, v_t_2412, v_p_243, v_dir_246, v_out_2411, v_next_245));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(V v_lit_240, V v_lit_241, V v_lit_242, V v_rep_243, V v_f_244) {
top: ;
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0, 2, 6, (V[]){v_c_246, v_f_244, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_rep_243)});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_rep_243 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_src_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_src_2414 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_src_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_str1), v_src_2414, MK_INT(0LL), 5);
  V v_t_2417;
  if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
    heff_drop(v_j_2415);
    v_t_2417 = heff_strLength_lent(v_src_2414, 0);
  } else {
    v_t_2417 = v_j_2415;
  }
  V v_t_2418 = heff_strEq(heff_strSlice(v_src_2414, MK_INT(0LL), v_t_2417), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_rep_243; V a_1 = v_t_2412; V a_2 = v_f_244; V a_3 = v_t_2418; V a_4 = v_x_2411; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_243); heff_drop(v_t_2418); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_rep_243 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_244)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam2, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_x_249, v_rep_243, v_f_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_rep_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1679472525x1552472873_lam1, 1, 7, (V[]){v_f_244, v_hd_247, v_lit_240, v_lit_241, v_lit_242, v_rep_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24f1533062604x661716706(heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_str0), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(heff_get_n(v_c_244, 0, 14), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1725150722x1763968003_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}