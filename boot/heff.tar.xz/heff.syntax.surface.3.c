// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2efieldOrName(V, V);
V g_heff_2esyntax_2esurface_2efieldOrName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldOrName_clo;
V g_heff_2esyntax_2esurface_2efixityOut(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eknotField(V, V);
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotField_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatSegmentL(V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldOne_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eexpOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexpOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eexpOf(V v_ex_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str0))) {
    V v_t_241 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
    V v_t_242 = ({ V a_0 = v_t_241; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_241); r_; });
    return heff_intSub(MK_INT(0LL), v_t_242);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str1))) {
      V v_t_243 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
      return ({ V a_0 = v_t_243; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_243); r_; });
    } else {
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintOfText(v_ex_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eexpOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_rest_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 5);
        V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
        V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
        heff_drop(v_u_2429);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2428;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2430 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 4);
        V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2430, heff_hole()});
        V v_u_2435 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2434));
        heff_drop(v_u_2435);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2434;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFor: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENest: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETry: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWith: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisNameE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_end_243 = heff_dup(heff_rfield(v_x12_242, 1));
    V v_start_244 = heff_dup(heff_rfield(v_x12_242, 0));
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_x_247 = heff_field(v_x11_241, 0);
      V v_ret_24bool = heff_bool(heff_intEq_c(heff_intSub(heff_dup(v_end_243), heff_dup(v_start_244)), heff_strLength_lent(v_x_247, 0)));
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return v_ret_24bool;
    }
    case TAG_EInt: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisNameE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EString, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAnn: {
      V v_g_2422 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2422)));
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2422));
      V v_t_2426 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2424, 0, 2), heff_get_n(v_t_2425, 1, 2)});
      V v_t_2427 = (g_list_2emap_24s878634257x1677201747(v_t_2426));
      V v_sc_2428 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(heff_take_field(v_p_241, 1), v_t_2427));
      V v_st_2429 = ({ V rv_1 = v_sc_2428; V rr_ = heff_rec_reuse_nf(v_p_241, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_st_2429}});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EReturn: {
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENest: {
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELazy: {
      V v_ru_24e1_242_24ELazy = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ELazy, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETuple: {
      V v_ru_24e1_242_24ETuple = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETuple, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETry: {
      V v_ru_24e1_242_24ETry = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETry, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eplainBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplainBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eplainBinder(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_241)) {
    case TAG_EVar: {
      V v_ru_24d1_241_24EVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EImplicitVar: {
      V v_ru_24d1_241_24EImplicitVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      V v_ru_24d1_241_24ETag = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      V v_ru_24d1_241_24EInt = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      V v_ru_24d1_241_24EFloat = heff_take_reuse_na(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EString: {
      V v_ru_24d1_241_24EString = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBinary: {
      V v_ru_24d1_241_24EBinary = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ERune: {
      V v_ru_24d1_241_24ERune = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWord: {
      V v_ru_24d1_241_24EWord = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EApp: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EProject: {
      V v_ru_24d1_241_24EProject = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENamed: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EPi: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAnn: {
      V v_d11_2421 = heff_field(v_d1_241, 0);
      V v_t_2422 = heff_field(v_d1_241, 1);
      heff_take_n(v_d1_241, 3ULL, 2);
      switch (heff_tag_of(v_d11_2421)) {
      case TAG_At: {
        V v_d111_2423 = heff_field(v_d11_2421, 0);
        V v_xsp_2424 = heff_field(v_d11_2421, 1);
        heff_take_n(v_d11_2421, 3ULL, 2);
        switch (heff_tag_of(v_d111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_d111_2423, 0);
          heff_take_n(v_d111_2423, 1ULL, 1);
          heff_drop_tag(v_d_240, 2);
          return heff_tag_n(TAG_PiNamed, 3, (V[]){v_x_2425, v_xsp_2424, v_t_2422});
        }
        case TAG_EImplicitVar: {
          V v_ru_24d111_2423_24EImplicitVar = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETag: {
          V v_ru_24d111_2423_24ETag = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInt: {
          V v_ru_24d111_2423_24EInt = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFloat: {
          V v_ru_24d111_2423_24EFloat = heff_take_reuse_na(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EString: {
          V v_ru_24d111_2423_24EString = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBinary: {
          V v_ru_24d111_2423_24EBinary = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ERune: {
          V v_ru_24d111_2423_24ERune = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWord: {
          V v_ru_24d111_2423_24EWord = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EApp: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EProject: {
          V v_ru_24d111_2423_24EProject = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENamed: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EPi: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELam: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAnn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESpec: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESig: {
          V v_ru_24d111_2423_24ESig = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESum: {
          V v_ru_24d111_2423_24ESum = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EStruct: {
          V v_ru_24d111_2423_24EStruct = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EUpdate: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EMatch: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELetIn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EDo: {
          V v_ru_24d111_2423_24EDo = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELocal: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInvalid: {
          V v_ru_24d111_2423_24EInvalid = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAssign: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWhile: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFor: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EIfThen: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBreak: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EContinue: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EReturn: {
          V v_ru_24d111_2423_24EReturn = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENest: {
          V v_ru_24d111_2423_24ENest = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELazy: {
          V v_ru_24d111_2423_24ELazy = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETuple: {
          V v_ru_24d111_2423_24ETuple = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETry: {
          V v_ru_24d111_2423_24ETry = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWith: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        default: return heff_nomatch(v_d111_2423);
        }
      }
      default: return heff_nomatch(v_d11_2421);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESig: {
      V v_ru_24d1_241_24ESig = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESum: {
      V v_ru_24d1_241_24ESum = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EStruct: {
      V v_ru_24d1_241_24EStruct = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EUpdate: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELetIn: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EDo: {
      V v_ru_24d1_241_24EDo = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELocal: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInvalid: {
      V v_ru_24d1_241_24EInvalid = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAssign: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWhile: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFor: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EIfThen: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBreak: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EContinue: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EReturn: {
      V v_ru_24d1_241_24EReturn = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENest: {
      V v_ru_24d1_241_24ENest = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELazy: {
      V v_ru_24d1_241_24ELazy = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETuple: {
      V v_ru_24d1_241_24ETuple = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETry: {
      V v_ru_24d1_241_24ETry = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWith: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplainBinder(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_241}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str7, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2eatomTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eatomTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eatomTok(V v_t_240) {
top: ;
  V v_kind_241 = heff_take_field(v_t_240, 0);
  V v_text_242 = heff_take_field(v_t_240, 1);
  V v_start_243 = heff_take_field(v_t_240, 3);
  V v_end_244 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str0), 2)) {
    heff_drop(v_kind_241);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
  } else {
    if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str1), 2)) {
      heff_drop(v_kind_241);
      V v_t_245 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_text_242); r_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_245}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
    } else {
      if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str2), 2)) {
        heff_drop(v_kind_241);
        V v_s_246 = v_text_242;
        V v_x2_247 = ({ V b_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str3); V a_1 = v_s_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2eatomTok_str4), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_246); r_; });
        V v_t_2410;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nil: {
          v_t_2410 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_xs_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str6); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        double v_t_2411 = ({ V a_0 = v_t_2410; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_2410); r_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_2411)}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
      } else {
        if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str7), 2)) {
          heff_drop(v_kind_241);
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EString, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
        } else {
          if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str8), 2)) {
            heff_drop(v_kind_241);
            V v_t_2412 = heff_runeToInt(heff_strRuneAt(v_text_242, MK_INT(0LL)));
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ERune, 1, (V[]){v_t_2412}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
          } else {
            if (heff_strEq_c(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str9))) {
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            } else {
              V v_t_2413 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2ewordKw(a_0)); heff_drop(v_text_242); r_; });
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWord, 1, (V[]){v_t_2413}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eatomTok(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldOrName_str0, 3, "var");
V g_heff_2esyntax_2esurface_2efieldOrName_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldOrName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldOrName_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldOrName(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24Atom = heff_take_reuse_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efieldOrName_str0))) {
      heff_drop(v_r_240);
      heff_drop_cell(v_ru_24e_241_24Atom, 1);
      return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam0, 1, 1, (V[]){v_x_242});
    } else {
      V v_m_245 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, heff_tag_at_n(v_ru_24e_241_24Atom, TAG_Atom, 1, (V[]){v_x_242})));
      return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam1, 1, 1, (V[]){v_m_245});
    }
  }
  case TAG_EParen: {
    V v_m_2416 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam2, 1, 1, (V[]){v_m_2416});
  }
  case TAG_Named: {
    V v_m_2429 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam3, 1, 1, (V[]){v_m_2429});
  }
  case TAG_Tup: {
    V v_m_2441 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam4, 1, 1, (V[]){v_m_2441});
  }
  case TAG_Seg: {
    V v_m_2452 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam5, 1, 1, (V[]){v_m_2452});
  }
  case TAG_Braces: {
    V v_m_2464 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam6, 1, 1, (V[]){v_m_2464});
  }
  case TAG_Update: {
    V v_m_2478 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam7, 1, 1, (V[]){v_m_2478});
  }
  case TAG_EUSet: {
    V v_m_2489 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam8, 1, 1, (V[]){v_m_2489});
  }
  case TAG_InstB: {
    V v_m_24102 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam9, 1, 1, (V[]){v_m_24102});
  }
  case TAG_EFSet: {
    V v_m_24113 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam10, 1, 1, (V[]){v_m_24113});
  }
  case TAG_EFDefault: {
    V v_m_24124 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam11, 1, 1, (V[]){v_m_24124});
  }
  case TAG_Sum: {
    V v_m_24137 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam12, 1, 1, (V[]){v_m_24137});
  }
  case TAG_ECon: {
    V v_m_24147 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam13, 1, 1, (V[]){v_m_24147});
  }
  case TAG_EField: {
    V v_m_24157 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam14, 1, 1, (V[]){v_m_24157});
  }
  case TAG_ENeg: {
    V v_m_24167 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam15, 1, 1, (V[]){v_m_24167});
  }
  case TAG_ETilde: {
    V v_m_24177 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam16, 1, 1, (V[]){v_m_24177});
  }
  case TAG_App: {
    V v_m_24187 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam17, 1, 1, (V[]){v_m_24187});
  }
  case TAG_Op: {
    V v_m_24198 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam18, 1, 1, (V[]){v_m_24198});
  }
  case TAG_Ops: {
    V v_m_24208 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam19, 1, 1, (V[]){v_m_24208});
  }
  case TAG_OpRhs: {
    V v_m_24218 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam20, 1, 1, (V[]){v_m_24218});
  }
  case TAG_Ann: {
    V v_m_24229 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam21, 1, 1, (V[]){v_m_24229});
  }
  case TAG_BVar: {
    V v_m_24238 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam22, 1, 1, (V[]){v_m_24238});
  }
  case TAG_BImp: {
    V v_m_24249 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam23, 1, 1, (V[]){v_m_24249});
  }
  case TAG_BAnn: {
    V v_m_24262 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam24, 1, 1, (V[]){v_m_24262});
  }
  case TAG_BPat: {
    V v_m_24271 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam25, 1, 1, (V[]){v_m_24271});
  }
  case TAG_Lam: {
    V v_m_24283 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam26, 1, 1, (V[]){v_m_24283});
  }
  case TAG_Case: {
    V v_m_24295 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam27, 1, 1, (V[]){v_m_24295});
  }
  case TAG_EAlt: {
    V v_m_24306 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam28, 1, 1, (V[]){v_m_24306});
  }
  case TAG_If: {
    V v_m_24320 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam29, 1, 1, (V[]){v_m_24320});
  }
  case TAG_Do: {
    V v_m_24330 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam30, 1, 1, (V[]){v_m_24330});
  }
  case TAG_ESBind: {
    V v_m_24341 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam31, 1, 1, (V[]){v_m_24341});
  }
  case TAG_ELet: {
    V v_m_24355 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam32, 1, 1, (V[]){v_m_24355});
  }
  case TAG_ELetElse: {
    V v_m_24370 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam33, 1, 1, (V[]){v_m_24370});
  }
  case TAG_ELetMut: {
    V v_m_24384 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam34, 1, 1, (V[]){v_m_24384});
  }
  case TAG_EAssign: {
    V v_m_24395 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam35, 1, 1, (V[]){v_m_24395});
  }
  case TAG_EWhile: {
    V v_m_24407 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam36, 1, 1, (V[]){v_m_24407});
  }
  case TAG_EFor: {
    V v_m_24421 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam37, 1, 1, (V[]){v_m_24421});
  }
  case TAG_EJump: {
    V v_m_24430 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam38, 1, 1, (V[]){v_m_24430});
  }
  case TAG_EReturn: {
    V v_m_24440 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam39, 1, 1, (V[]){v_m_24440});
  }
  case TAG_ENest: {
    V v_m_24452 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam40, 1, 1, (V[]){v_m_24452});
  }
  case TAG_EArrow: {
    V v_m_24462 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam41, 1, 1, (V[]){v_m_24462});
  }
  case TAG_IfThen: {
    V v_m_24474 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam42, 1, 1, (V[]){v_m_24474});
  }
  case TAG_ETry: {
    V v_m_24486 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam43, 1, 1, (V[]){v_m_24486});
  }
  case TAG_ECatch: {
    V v_m_24498 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam44, 1, 1, (V[]){v_m_24498});
  }
  case TAG_EWith: {
    V v_m_24512 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam45, 1, 1, (V[]){v_m_24512});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldOrName(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x_242})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_st_243});
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2411})});
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_st_249});
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam2(V self, V *args) {
  V v_st_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_MkPair: {
    V v_x11_2419 = heff_field(v_x1_2418, 0);
    V v_st_2420 = heff_field(v_x1_2418, 1);
    V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_Left: {
      V v_e_2421 = heff_field(v_x11_2419, 0);
      heff_take_n(v_x11_2419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_x11_2419, 0);
      V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
      V v_t_2423 = heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2422})});
      return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_st_2420});
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      heff_take_n(v_x11_2432, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_t_2436 = heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2435})});
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam4(V self, V *args) {
  V v_st_2442 = args[0];
  V v_m_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2443 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_st_2442}));
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_MkPair: {
    V v_x11_2444 = heff_field(v_x1_2443, 0);
    V v_st_2445 = heff_field(v_x1_2443, 1);
    V v_ru_24x1_2443_24MkPair = heff_take_reuse_n(v_x1_2443, 3ULL, 2);
    switch (heff_tag_of(v_x11_2444)) {
    case TAG_Left: {
      V v_e_2446 = heff_field(v_x11_2444, 0);
      heff_take_n(v_x11_2444, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2446}), v_st_2445});
    }
    case TAG_Right: {
      V v_x_2447 = heff_field(v_x11_2444, 0);
      V v_ru_24x11_2444_24Right = heff_take_reuse_n(v_x11_2444, 1ULL, 1);
      V v_t_2448 = heff_tag_at_n(v_ru_24x11_2444_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2447})});
      return heff_tag_at_n(v_ru_24x1_2443_24MkPair, TAG_MkPair, 2, (V[]){v_t_2448, v_st_2445});
    }
    default: return heff_nomatch(v_x11_2444);
    }
  }
  default: return heff_nomatch(v_x1_2443);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam5(V self, V *args) {
  V v_st_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_st_2453}));
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_MkPair: {
    V v_x11_2455 = heff_field(v_x1_2454, 0);
    V v_st_2456 = heff_field(v_x1_2454, 1);
    V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
    switch (heff_tag_of(v_x11_2455)) {
    case TAG_Left: {
      V v_e_2457 = heff_field(v_x11_2455, 0);
      heff_take_n(v_x11_2455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
    }
    case TAG_Right: {
      V v_x_2458 = heff_field(v_x11_2455, 0);
      V v_ru_24x11_2455_24Right = heff_take_reuse_n(v_x11_2455, 1ULL, 1);
      V v_t_2459 = heff_tag_at_n(v_ru_24x11_2455_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2458})});
      return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){v_t_2459, v_st_2456});
    }
    default: return heff_nomatch(v_x11_2455);
    }
  }
  default: return heff_nomatch(v_x1_2454);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam6(V self, V *args) {
  V v_st_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_st_2465}));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_MkPair: {
    V v_x11_2467 = heff_field(v_x1_2466, 0);
    V v_st_2468 = heff_field(v_x1_2466, 1);
    V v_ru_24x1_2466_24MkPair = heff_take_reuse_n(v_x1_2466, 3ULL, 2);
    switch (heff_tag_of(v_x11_2467)) {
    case TAG_Left: {
      V v_e_2469 = heff_field(v_x11_2467, 0);
      heff_take_n(v_x11_2467, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2469}), v_st_2468});
    }
    case TAG_Right: {
      V v_x_2470 = heff_field(v_x11_2467, 0);
      V v_ru_24x11_2467_24Right = heff_take_reuse_n(v_x11_2467, 1ULL, 1);
      V v_t_2471 = heff_tag_at_n(v_ru_24x11_2467_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2470})});
      return heff_tag_at_n(v_ru_24x1_2466_24MkPair, TAG_MkPair, 2, (V[]){v_t_2471, v_st_2468});
    }
    default: return heff_nomatch(v_x11_2467);
    }
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam7(V self, V *args) {
  V v_st_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_st_2479}));
  switch (heff_tag_of(v_x1_2480)) {
  case TAG_MkPair: {
    V v_x11_2481 = heff_field(v_x1_2480, 0);
    V v_st_2482 = heff_field(v_x1_2480, 1);
    V v_ru_24x1_2480_24MkPair = heff_take_reuse_n(v_x1_2480, 3ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_Left: {
      V v_e_2483 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
    }
    case TAG_Right: {
      V v_x_2484 = heff_field(v_x11_2481, 0);
      V v_ru_24x11_2481_24Right = heff_take_reuse_n(v_x11_2481, 1ULL, 1);
      V v_t_2485 = heff_tag_at_n(v_ru_24x11_2481_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2484})});
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){v_t_2485, v_st_2482});
    }
    default: return heff_nomatch(v_x11_2481);
    }
  }
  default: return heff_nomatch(v_x1_2480);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam8(V self, V *args) {
  V v_st_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_st_2490}));
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_MkPair: {
    V v_x11_2492 = heff_field(v_x1_2491, 0);
    V v_st_2493 = heff_field(v_x1_2491, 1);
    V v_ru_24x1_2491_24MkPair = heff_take_reuse_n(v_x1_2491, 3ULL, 2);
    switch (heff_tag_of(v_x11_2492)) {
    case TAG_Left: {
      V v_e_2494 = heff_field(v_x11_2492, 0);
      heff_take_n(v_x11_2492, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2494}), v_st_2493});
    }
    case TAG_Right: {
      V v_x_2495 = heff_field(v_x11_2492, 0);
      V v_ru_24x11_2492_24Right = heff_take_reuse_n(v_x11_2492, 1ULL, 1);
      V v_t_2496 = heff_tag_at_n(v_ru_24x11_2492_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2495})});
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){v_t_2496, v_st_2493});
    }
    default: return heff_nomatch(v_x11_2492);
    }
  }
  default: return heff_nomatch(v_x1_2491);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam9(V self, V *args) {
  V v_st_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_st_24103}));
  switch (heff_tag_of(v_x1_24104)) {
  case TAG_MkPair: {
    V v_x11_24105 = heff_field(v_x1_24104, 0);
    V v_st_24106 = heff_field(v_x1_24104, 1);
    V v_ru_24x1_24104_24MkPair = heff_take_reuse_n(v_x1_24104, 3ULL, 2);
    switch (heff_tag_of(v_x11_24105)) {
    case TAG_Left: {
      V v_e_24107 = heff_field(v_x11_24105, 0);
      heff_take_n(v_x11_24105, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24107}), v_st_24106});
    }
    case TAG_Right: {
      V v_x_24108 = heff_field(v_x11_24105, 0);
      V v_ru_24x11_24105_24Right = heff_take_reuse_n(v_x11_24105, 1ULL, 1);
      V v_t_24109 = heff_tag_at_n(v_ru_24x11_24105_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24108})});
      return heff_tag_at_n(v_ru_24x1_24104_24MkPair, TAG_MkPair, 2, (V[]){v_t_24109, v_st_24106});
    }
    default: return heff_nomatch(v_x11_24105);
    }
  }
  default: return heff_nomatch(v_x1_24104);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam10(V self, V *args) {
  V v_st_24114 = args[0];
  V v_m_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24115 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_st_24114}));
  switch (heff_tag_of(v_x1_24115)) {
  case TAG_MkPair: {
    V v_x11_24116 = heff_field(v_x1_24115, 0);
    V v_st_24117 = heff_field(v_x1_24115, 1);
    V v_ru_24x1_24115_24MkPair = heff_take_reuse_n(v_x1_24115, 3ULL, 2);
    switch (heff_tag_of(v_x11_24116)) {
    case TAG_Left: {
      V v_e_24118 = heff_field(v_x11_24116, 0);
      heff_take_n(v_x11_24116, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24118}), v_st_24117});
    }
    case TAG_Right: {
      V v_x_24119 = heff_field(v_x11_24116, 0);
      V v_ru_24x11_24116_24Right = heff_take_reuse_n(v_x11_24116, 1ULL, 1);
      V v_t_24120 = heff_tag_at_n(v_ru_24x11_24116_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24119})});
      return heff_tag_at_n(v_ru_24x1_24115_24MkPair, TAG_MkPair, 2, (V[]){v_t_24120, v_st_24117});
    }
    default: return heff_nomatch(v_x11_24116);
    }
  }
  default: return heff_nomatch(v_x1_24115);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam11(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24131 = heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24130})});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){v_t_24131, v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam12(V self, V *args) {
  V v_st_24138 = args[0];
  V v_m_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24139 = heff_tr(heff_call(v_m_24137, 1, (V[]){v_st_24138}));
  switch (heff_tag_of(v_x1_24139)) {
  case TAG_MkPair: {
    V v_x11_24140 = heff_field(v_x1_24139, 0);
    V v_st_24141 = heff_field(v_x1_24139, 1);
    V v_ru_24x1_24139_24MkPair = heff_take_reuse_n(v_x1_24139, 3ULL, 2);
    switch (heff_tag_of(v_x11_24140)) {
    case TAG_Left: {
      V v_e_24142 = heff_field(v_x11_24140, 0);
      heff_take_n(v_x11_24140, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24139_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24142}), v_st_24141});
    }
    case TAG_Right: {
      V v_x_24143 = heff_field(v_x11_24140, 0);
      V v_ru_24x11_24140_24Right = heff_take_reuse_n(v_x11_24140, 1ULL, 1);
      V v_t_24144 = heff_tag_at_n(v_ru_24x11_24140_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24143})});
      return heff_tag_at_n(v_ru_24x1_24139_24MkPair, TAG_MkPair, 2, (V[]){v_t_24144, v_st_24141});
    }
    default: return heff_nomatch(v_x11_24140);
    }
  }
  default: return heff_nomatch(v_x1_24139);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam13(V self, V *args) {
  V v_st_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_st_24148}));
  switch (heff_tag_of(v_x1_24149)) {
  case TAG_MkPair: {
    V v_x11_24150 = heff_field(v_x1_24149, 0);
    V v_st_24151 = heff_field(v_x1_24149, 1);
    V v_ru_24x1_24149_24MkPair = heff_take_reuse_n(v_x1_24149, 3ULL, 2);
    switch (heff_tag_of(v_x11_24150)) {
    case TAG_Left: {
      V v_e_24152 = heff_field(v_x11_24150, 0);
      heff_take_n(v_x11_24150, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24149_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24152}), v_st_24151});
    }
    case TAG_Right: {
      V v_x_24153 = heff_field(v_x11_24150, 0);
      V v_ru_24x11_24150_24Right = heff_take_reuse_n(v_x11_24150, 1ULL, 1);
      V v_t_24154 = heff_tag_at_n(v_ru_24x11_24150_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24153})});
      return heff_tag_at_n(v_ru_24x1_24149_24MkPair, TAG_MkPair, 2, (V[]){v_t_24154, v_st_24151});
    }
    default: return heff_nomatch(v_x11_24150);
    }
  }
  default: return heff_nomatch(v_x1_24149);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam14(V self, V *args) {
  V v_st_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_st_24158}));
  switch (heff_tag_of(v_x1_24159)) {
  case TAG_MkPair: {
    V v_x11_24160 = heff_field(v_x1_24159, 0);
    V v_st_24161 = heff_field(v_x1_24159, 1);
    V v_ru_24x1_24159_24MkPair = heff_take_reuse_n(v_x1_24159, 3ULL, 2);
    switch (heff_tag_of(v_x11_24160)) {
    case TAG_Left: {
      V v_e_24162 = heff_field(v_x11_24160, 0);
      heff_take_n(v_x11_24160, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24162}), v_st_24161});
    }
    case TAG_Right: {
      V v_x_24163 = heff_field(v_x11_24160, 0);
      V v_ru_24x11_24160_24Right = heff_take_reuse_n(v_x11_24160, 1ULL, 1);
      V v_t_24164 = heff_tag_at_n(v_ru_24x11_24160_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24163})});
      return heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_MkPair, 2, (V[]){v_t_24164, v_st_24161});
    }
    default: return heff_nomatch(v_x11_24160);
    }
  }
  default: return heff_nomatch(v_x1_24159);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam15(V self, V *args) {
  V v_st_24168 = args[0];
  V v_m_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24169 = heff_tr(heff_call(v_m_24167, 1, (V[]){v_st_24168}));
  switch (heff_tag_of(v_x1_24169)) {
  case TAG_MkPair: {
    V v_x11_24170 = heff_field(v_x1_24169, 0);
    V v_st_24171 = heff_field(v_x1_24169, 1);
    V v_ru_24x1_24169_24MkPair = heff_take_reuse_n(v_x1_24169, 3ULL, 2);
    switch (heff_tag_of(v_x11_24170)) {
    case TAG_Left: {
      V v_e_24172 = heff_field(v_x11_24170, 0);
      heff_take_n(v_x11_24170, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24172}), v_st_24171});
    }
    case TAG_Right: {
      V v_x_24173 = heff_field(v_x11_24170, 0);
      V v_ru_24x11_24170_24Right = heff_take_reuse_n(v_x11_24170, 1ULL, 1);
      V v_t_24174 = heff_tag_at_n(v_ru_24x11_24170_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24173})});
      return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){v_t_24174, v_st_24171});
    }
    default: return heff_nomatch(v_x11_24170);
    }
  }
  default: return heff_nomatch(v_x1_24169);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam16(V self, V *args) {
  V v_st_24178 = args[0];
  V v_m_24177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24179 = heff_tr(heff_call(v_m_24177, 1, (V[]){v_st_24178}));
  switch (heff_tag_of(v_x1_24179)) {
  case TAG_MkPair: {
    V v_x11_24180 = heff_field(v_x1_24179, 0);
    V v_st_24181 = heff_field(v_x1_24179, 1);
    V v_ru_24x1_24179_24MkPair = heff_take_reuse_n(v_x1_24179, 3ULL, 2);
    switch (heff_tag_of(v_x11_24180)) {
    case TAG_Left: {
      V v_e_24182 = heff_field(v_x11_24180, 0);
      heff_take_n(v_x11_24180, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24179_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24182}), v_st_24181});
    }
    case TAG_Right: {
      V v_x_24183 = heff_field(v_x11_24180, 0);
      V v_ru_24x11_24180_24Right = heff_take_reuse_n(v_x11_24180, 1ULL, 1);
      V v_t_24184 = heff_tag_at_n(v_ru_24x11_24180_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24183})});
      return heff_tag_at_n(v_ru_24x1_24179_24MkPair, TAG_MkPair, 2, (V[]){v_t_24184, v_st_24181});
    }
    default: return heff_nomatch(v_x11_24180);
    }
  }
  default: return heff_nomatch(v_x1_24179);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam17(V self, V *args) {
  V v_st_24188 = args[0];
  V v_m_24187 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24189 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_st_24188}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      V v_ru_24x11_24190_24Right = heff_take_reuse_n(v_x11_24190, 1ULL, 1);
      V v_t_24194 = heff_tag_at_n(v_ru_24x11_24190_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24193})});
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){v_t_24194, v_st_24191});
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam18(V self, V *args) {
  V v_st_24199 = args[0];
  V v_m_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24200 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_st_24199}));
  switch (heff_tag_of(v_x1_24200)) {
  case TAG_MkPair: {
    V v_x11_24201 = heff_field(v_x1_24200, 0);
    V v_st_24202 = heff_field(v_x1_24200, 1);
    V v_ru_24x1_24200_24MkPair = heff_take_reuse_n(v_x1_24200, 3ULL, 2);
    switch (heff_tag_of(v_x11_24201)) {
    case TAG_Left: {
      V v_e_24203 = heff_field(v_x11_24201, 0);
      heff_take_n(v_x11_24201, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24203}), v_st_24202});
    }
    case TAG_Right: {
      V v_x_24204 = heff_field(v_x11_24201, 0);
      V v_ru_24x11_24201_24Right = heff_take_reuse_n(v_x11_24201, 1ULL, 1);
      V v_t_24205 = heff_tag_at_n(v_ru_24x11_24201_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24204})});
      return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){v_t_24205, v_st_24202});
    }
    default: return heff_nomatch(v_x11_24201);
    }
  }
  default: return heff_nomatch(v_x1_24200);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam19(V self, V *args) {
  V v_st_24209 = args[0];
  V v_m_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24210 = heff_tr(heff_call(v_m_24208, 1, (V[]){v_st_24209}));
  switch (heff_tag_of(v_x1_24210)) {
  case TAG_MkPair: {
    V v_x11_24211 = heff_field(v_x1_24210, 0);
    V v_st_24212 = heff_field(v_x1_24210, 1);
    V v_ru_24x1_24210_24MkPair = heff_take_reuse_n(v_x1_24210, 3ULL, 2);
    switch (heff_tag_of(v_x11_24211)) {
    case TAG_Left: {
      V v_e_24213 = heff_field(v_x11_24211, 0);
      heff_take_n(v_x11_24211, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24213}), v_st_24212});
    }
    case TAG_Right: {
      V v_x_24214 = heff_field(v_x11_24211, 0);
      V v_ru_24x11_24211_24Right = heff_take_reuse_n(v_x11_24211, 1ULL, 1);
      V v_t_24215 = heff_tag_at_n(v_ru_24x11_24211_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24214})});
      return heff_tag_at_n(v_ru_24x1_24210_24MkPair, TAG_MkPair, 2, (V[]){v_t_24215, v_st_24212});
    }
    default: return heff_nomatch(v_x11_24211);
    }
  }
  default: return heff_nomatch(v_x1_24210);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam20(V self, V *args) {
  V v_st_24219 = args[0];
  V v_m_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24220 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_st_24219}));
  switch (heff_tag_of(v_x1_24220)) {
  case TAG_MkPair: {
    V v_x11_24221 = heff_field(v_x1_24220, 0);
    V v_st_24222 = heff_field(v_x1_24220, 1);
    V v_ru_24x1_24220_24MkPair = heff_take_reuse_n(v_x1_24220, 3ULL, 2);
    switch (heff_tag_of(v_x11_24221)) {
    case TAG_Left: {
      V v_e_24223 = heff_field(v_x11_24221, 0);
      heff_take_n(v_x11_24221, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24220_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24223}), v_st_24222});
    }
    case TAG_Right: {
      V v_x_24224 = heff_field(v_x11_24221, 0);
      V v_ru_24x11_24221_24Right = heff_take_reuse_n(v_x11_24221, 1ULL, 1);
      V v_t_24225 = heff_tag_at_n(v_ru_24x11_24221_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224})});
      return heff_tag_at_n(v_ru_24x1_24220_24MkPair, TAG_MkPair, 2, (V[]){v_t_24225, v_st_24222});
    }
    default: return heff_nomatch(v_x11_24221);
    }
  }
  default: return heff_nomatch(v_x1_24220);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam21(V self, V *args) {
  V v_st_24230 = args[0];
  V v_m_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24231 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_st_24230}));
  switch (heff_tag_of(v_x1_24231)) {
  case TAG_MkPair: {
    V v_x11_24232 = heff_field(v_x1_24231, 0);
    V v_st_24233 = heff_field(v_x1_24231, 1);
    V v_ru_24x1_24231_24MkPair = heff_take_reuse_n(v_x1_24231, 3ULL, 2);
    switch (heff_tag_of(v_x11_24232)) {
    case TAG_Left: {
      V v_e_24234 = heff_field(v_x11_24232, 0);
      heff_take_n(v_x11_24232, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24234}), v_st_24233});
    }
    case TAG_Right: {
      V v_x_24235 = heff_field(v_x11_24232, 0);
      V v_ru_24x11_24232_24Right = heff_take_reuse_n(v_x11_24232, 1ULL, 1);
      V v_t_24236 = heff_tag_at_n(v_ru_24x11_24232_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235})});
      return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){v_t_24236, v_st_24233});
    }
    default: return heff_nomatch(v_x11_24232);
    }
  }
  default: return heff_nomatch(v_x1_24231);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam22(V self, V *args) {
  V v_st_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_st_24239}));
  switch (heff_tag_of(v_x1_24240)) {
  case TAG_MkPair: {
    V v_x11_24241 = heff_field(v_x1_24240, 0);
    V v_st_24242 = heff_field(v_x1_24240, 1);
    V v_ru_24x1_24240_24MkPair = heff_take_reuse_n(v_x1_24240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24241)) {
    case TAG_Left: {
      V v_e_24243 = heff_field(v_x11_24241, 0);
      heff_take_n(v_x11_24241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24243}), v_st_24242});
    }
    case TAG_Right: {
      V v_x_24244 = heff_field(v_x11_24241, 0);
      V v_ru_24x11_24241_24Right = heff_take_reuse_n(v_x11_24241, 1ULL, 1);
      V v_t_24245 = heff_tag_at_n(v_ru_24x11_24241_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24244})});
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){v_t_24245, v_st_24242});
    }
    default: return heff_nomatch(v_x11_24241);
    }
  }
  default: return heff_nomatch(v_x1_24240);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam23(V self, V *args) {
  V v_st_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_st_24250}));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_MkPair: {
    V v_x11_24252 = heff_field(v_x1_24251, 0);
    V v_st_24253 = heff_field(v_x1_24251, 1);
    V v_ru_24x1_24251_24MkPair = heff_take_reuse_n(v_x1_24251, 3ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_Left: {
      V v_e_24254 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24254}), v_st_24253});
    }
    case TAG_Right: {
      V v_x_24255 = heff_field(v_x11_24252, 0);
      V v_ru_24x11_24252_24Right = heff_take_reuse_n(v_x11_24252, 1ULL, 1);
      V v_t_24256 = heff_tag_at_n(v_ru_24x11_24252_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24255})});
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){v_t_24256, v_st_24253});
    }
    default: return heff_nomatch(v_x11_24252);
    }
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam24(V self, V *args) {
  V v_st_24263 = args[0];
  V v_m_24262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24264 = heff_tr(heff_call(v_m_24262, 1, (V[]){v_st_24263}));
  switch (heff_tag_of(v_x1_24264)) {
  case TAG_MkPair: {
    V v_x11_24265 = heff_field(v_x1_24264, 0);
    V v_st_24266 = heff_field(v_x1_24264, 1);
    V v_ru_24x1_24264_24MkPair = heff_take_reuse_n(v_x1_24264, 3ULL, 2);
    switch (heff_tag_of(v_x11_24265)) {
    case TAG_Left: {
      V v_e_24267 = heff_field(v_x11_24265, 0);
      heff_take_n(v_x11_24265, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24267}), v_st_24266});
    }
    case TAG_Right: {
      V v_x_24268 = heff_field(v_x11_24265, 0);
      V v_ru_24x11_24265_24Right = heff_take_reuse_n(v_x11_24265, 1ULL, 1);
      V v_t_24269 = heff_tag_at_n(v_ru_24x11_24265_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24268})});
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){v_t_24269, v_st_24266});
    }
    default: return heff_nomatch(v_x11_24265);
    }
  }
  default: return heff_nomatch(v_x1_24264);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam25(V self, V *args) {
  V v_st_24272 = args[0];
  V v_m_24271 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24273 = heff_tr(heff_call(v_m_24271, 1, (V[]){v_st_24272}));
  switch (heff_tag_of(v_x1_24273)) {
  case TAG_MkPair: {
    V v_x11_24274 = heff_field(v_x1_24273, 0);
    V v_st_24275 = heff_field(v_x1_24273, 1);
    V v_ru_24x1_24273_24MkPair = heff_take_reuse_n(v_x1_24273, 3ULL, 2);
    switch (heff_tag_of(v_x11_24274)) {
    case TAG_Left: {
      V v_e_24276 = heff_field(v_x11_24274, 0);
      heff_take_n(v_x11_24274, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24276}), v_st_24275});
    }
    case TAG_Right: {
      V v_x_24277 = heff_field(v_x11_24274, 0);
      V v_ru_24x11_24274_24Right = heff_take_reuse_n(v_x11_24274, 1ULL, 1);
      V v_t_24278 = heff_tag_at_n(v_ru_24x11_24274_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24277})});
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){v_t_24278, v_st_24275});
    }
    default: return heff_nomatch(v_x11_24274);
    }
  }
  default: return heff_nomatch(v_x1_24273);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam26(V self, V *args) {
  V v_st_24284 = args[0];
  V v_m_24283 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24285 = heff_tr(heff_call(v_m_24283, 1, (V[]){v_st_24284}));
  switch (heff_tag_of(v_x1_24285)) {
  case TAG_MkPair: {
    V v_x11_24286 = heff_field(v_x1_24285, 0);
    V v_st_24287 = heff_field(v_x1_24285, 1);
    V v_ru_24x1_24285_24MkPair = heff_take_reuse_n(v_x1_24285, 3ULL, 2);
    switch (heff_tag_of(v_x11_24286)) {
    case TAG_Left: {
      V v_e_24288 = heff_field(v_x11_24286, 0);
      heff_take_n(v_x11_24286, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24285_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24288}), v_st_24287});
    }
    case TAG_Right: {
      V v_x_24289 = heff_field(v_x11_24286, 0);
      V v_ru_24x11_24286_24Right = heff_take_reuse_n(v_x11_24286, 1ULL, 1);
      V v_t_24290 = heff_tag_at_n(v_ru_24x11_24286_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24289})});
      return heff_tag_at_n(v_ru_24x1_24285_24MkPair, TAG_MkPair, 2, (V[]){v_t_24290, v_st_24287});
    }
    default: return heff_nomatch(v_x11_24286);
    }
  }
  default: return heff_nomatch(v_x1_24285);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam27(V self, V *args) {
  V v_st_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_st_24296}));
  switch (heff_tag_of(v_x1_24297)) {
  case TAG_MkPair: {
    V v_x11_24298 = heff_field(v_x1_24297, 0);
    V v_st_24299 = heff_field(v_x1_24297, 1);
    V v_ru_24x1_24297_24MkPair = heff_take_reuse_n(v_x1_24297, 3ULL, 2);
    switch (heff_tag_of(v_x11_24298)) {
    case TAG_Left: {
      V v_e_24300 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24300}), v_st_24299});
    }
    case TAG_Right: {
      V v_x_24301 = heff_field(v_x11_24298, 0);
      V v_ru_24x11_24298_24Right = heff_take_reuse_n(v_x11_24298, 1ULL, 1);
      V v_t_24302 = heff_tag_at_n(v_ru_24x11_24298_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24301})});
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){v_t_24302, v_st_24299});
    }
    default: return heff_nomatch(v_x11_24298);
    }
  }
  default: return heff_nomatch(v_x1_24297);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam28(V self, V *args) {
  V v_st_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_st_24307}));
  switch (heff_tag_of(v_x1_24308)) {
  case TAG_MkPair: {
    V v_x11_24309 = heff_field(v_x1_24308, 0);
    V v_st_24310 = heff_field(v_x1_24308, 1);
    V v_ru_24x1_24308_24MkPair = heff_take_reuse_n(v_x1_24308, 3ULL, 2);
    switch (heff_tag_of(v_x11_24309)) {
    case TAG_Left: {
      V v_e_24311 = heff_field(v_x11_24309, 0);
      heff_take_n(v_x11_24309, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24311}), v_st_24310});
    }
    case TAG_Right: {
      V v_x_24312 = heff_field(v_x11_24309, 0);
      V v_ru_24x11_24309_24Right = heff_take_reuse_n(v_x11_24309, 1ULL, 1);
      V v_t_24313 = heff_tag_at_n(v_ru_24x11_24309_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24312})});
      return heff_tag_at_n(v_ru_24x1_24308_24MkPair, TAG_MkPair, 2, (V[]){v_t_24313, v_st_24310});
    }
    default: return heff_nomatch(v_x11_24309);
    }
  }
  default: return heff_nomatch(v_x1_24308);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam29(V self, V *args) {
  V v_st_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_st_24321}));
  switch (heff_tag_of(v_x1_24322)) {
  case TAG_MkPair: {
    V v_x11_24323 = heff_field(v_x1_24322, 0);
    V v_st_24324 = heff_field(v_x1_24322, 1);
    V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
    switch (heff_tag_of(v_x11_24323)) {
    case TAG_Left: {
      V v_e_24325 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
    }
    case TAG_Right: {
      V v_x_24326 = heff_field(v_x11_24323, 0);
      V v_ru_24x11_24323_24Right = heff_take_reuse_n(v_x11_24323, 1ULL, 1);
      V v_t_24327 = heff_tag_at_n(v_ru_24x11_24323_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326})});
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){v_t_24327, v_st_24324});
    }
    default: return heff_nomatch(v_x11_24323);
    }
  }
  default: return heff_nomatch(v_x1_24322);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam30(V self, V *args) {
  V v_st_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_st_24331}));
  switch (heff_tag_of(v_x1_24332)) {
  case TAG_MkPair: {
    V v_x11_24333 = heff_field(v_x1_24332, 0);
    V v_st_24334 = heff_field(v_x1_24332, 1);
    V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
    switch (heff_tag_of(v_x11_24333)) {
    case TAG_Left: {
      V v_e_24335 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
    }
    case TAG_Right: {
      V v_x_24336 = heff_field(v_x11_24333, 0);
      V v_ru_24x11_24333_24Right = heff_take_reuse_n(v_x11_24333, 1ULL, 1);
      V v_t_24337 = heff_tag_at_n(v_ru_24x11_24333_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24336})});
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){v_t_24337, v_st_24334});
    }
    default: return heff_nomatch(v_x11_24333);
    }
  }
  default: return heff_nomatch(v_x1_24332);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam31(V self, V *args) {
  V v_st_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_st_24342}));
  switch (heff_tag_of(v_x1_24343)) {
  case TAG_MkPair: {
    V v_x11_24344 = heff_field(v_x1_24343, 0);
    V v_st_24345 = heff_field(v_x1_24343, 1);
    V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
    switch (heff_tag_of(v_x11_24344)) {
    case TAG_Left: {
      V v_e_24346 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
    }
    case TAG_Right: {
      V v_x_24347 = heff_field(v_x11_24344, 0);
      V v_ru_24x11_24344_24Right = heff_take_reuse_n(v_x11_24344, 1ULL, 1);
      V v_t_24348 = heff_tag_at_n(v_ru_24x11_24344_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24347})});
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){v_t_24348, v_st_24345});
    }
    default: return heff_nomatch(v_x11_24344);
    }
  }
  default: return heff_nomatch(v_x1_24343);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam32(V self, V *args) {
  V v_st_24356 = args[0];
  V v_m_24355 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24357 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_st_24356}));
  switch (heff_tag_of(v_x1_24357)) {
  case TAG_MkPair: {
    V v_x11_24358 = heff_field(v_x1_24357, 0);
    V v_st_24359 = heff_field(v_x1_24357, 1);
    V v_ru_24x1_24357_24MkPair = heff_take_reuse_n(v_x1_24357, 3ULL, 2);
    switch (heff_tag_of(v_x11_24358)) {
    case TAG_Left: {
      V v_e_24360 = heff_field(v_x11_24358, 0);
      heff_take_n(v_x11_24358, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24360}), v_st_24359});
    }
    case TAG_Right: {
      V v_x_24361 = heff_field(v_x11_24358, 0);
      V v_ru_24x11_24358_24Right = heff_take_reuse_n(v_x11_24358, 1ULL, 1);
      V v_t_24362 = heff_tag_at_n(v_ru_24x11_24358_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24361})});
      return heff_tag_at_n(v_ru_24x1_24357_24MkPair, TAG_MkPair, 2, (V[]){v_t_24362, v_st_24359});
    }
    default: return heff_nomatch(v_x11_24358);
    }
  }
  default: return heff_nomatch(v_x1_24357);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam33(V self, V *args) {
  V v_st_24371 = args[0];
  V v_m_24370 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24372 = heff_tr(heff_call(v_m_24370, 1, (V[]){v_st_24371}));
  switch (heff_tag_of(v_x1_24372)) {
  case TAG_MkPair: {
    V v_x11_24373 = heff_field(v_x1_24372, 0);
    V v_st_24374 = heff_field(v_x1_24372, 1);
    V v_ru_24x1_24372_24MkPair = heff_take_reuse_n(v_x1_24372, 3ULL, 2);
    switch (heff_tag_of(v_x11_24373)) {
    case TAG_Left: {
      V v_e_24375 = heff_field(v_x11_24373, 0);
      heff_take_n(v_x11_24373, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24375}), v_st_24374});
    }
    case TAG_Right: {
      V v_x_24376 = heff_field(v_x11_24373, 0);
      V v_ru_24x11_24373_24Right = heff_take_reuse_n(v_x11_24373, 1ULL, 1);
      V v_t_24377 = heff_tag_at_n(v_ru_24x11_24373_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24376})});
      return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){v_t_24377, v_st_24374});
    }
    default: return heff_nomatch(v_x11_24373);
    }
  }
  default: return heff_nomatch(v_x1_24372);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam34(V self, V *args) {
  V v_st_24385 = args[0];
  V v_m_24384 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24386 = heff_tr(heff_call(v_m_24384, 1, (V[]){v_st_24385}));
  switch (heff_tag_of(v_x1_24386)) {
  case TAG_MkPair: {
    V v_x11_24387 = heff_field(v_x1_24386, 0);
    V v_st_24388 = heff_field(v_x1_24386, 1);
    V v_ru_24x1_24386_24MkPair = heff_take_reuse_n(v_x1_24386, 3ULL, 2);
    switch (heff_tag_of(v_x11_24387)) {
    case TAG_Left: {
      V v_e_24389 = heff_field(v_x11_24387, 0);
      heff_take_n(v_x11_24387, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24386_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24389}), v_st_24388});
    }
    case TAG_Right: {
      V v_x_24390 = heff_field(v_x11_24387, 0);
      V v_ru_24x11_24387_24Right = heff_take_reuse_n(v_x11_24387, 1ULL, 1);
      V v_t_24391 = heff_tag_at_n(v_ru_24x11_24387_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24390})});
      return heff_tag_at_n(v_ru_24x1_24386_24MkPair, TAG_MkPair, 2, (V[]){v_t_24391, v_st_24388});
    }
    default: return heff_nomatch(v_x11_24387);
    }
  }
  default: return heff_nomatch(v_x1_24386);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam35(V self, V *args) {
  V v_st_24396 = args[0];
  V v_m_24395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24397 = heff_tr(heff_call(v_m_24395, 1, (V[]){v_st_24396}));
  switch (heff_tag_of(v_x1_24397)) {
  case TAG_MkPair: {
    V v_x11_24398 = heff_field(v_x1_24397, 0);
    V v_st_24399 = heff_field(v_x1_24397, 1);
    V v_ru_24x1_24397_24MkPair = heff_take_reuse_n(v_x1_24397, 3ULL, 2);
    switch (heff_tag_of(v_x11_24398)) {
    case TAG_Left: {
      V v_e_24400 = heff_field(v_x11_24398, 0);
      heff_take_n(v_x11_24398, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24400}), v_st_24399});
    }
    case TAG_Right: {
      V v_x_24401 = heff_field(v_x11_24398, 0);
      V v_ru_24x11_24398_24Right = heff_take_reuse_n(v_x11_24398, 1ULL, 1);
      V v_t_24402 = heff_tag_at_n(v_ru_24x11_24398_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24401})});
      return heff_tag_at_n(v_ru_24x1_24397_24MkPair, TAG_MkPair, 2, (V[]){v_t_24402, v_st_24399});
    }
    default: return heff_nomatch(v_x11_24398);
    }
  }
  default: return heff_nomatch(v_x1_24397);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam36(V self, V *args) {
  V v_st_24408 = args[0];
  V v_m_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24409 = heff_tr(heff_call(v_m_24407, 1, (V[]){v_st_24408}));
  switch (heff_tag_of(v_x1_24409)) {
  case TAG_MkPair: {
    V v_x11_24410 = heff_field(v_x1_24409, 0);
    V v_st_24411 = heff_field(v_x1_24409, 1);
    V v_ru_24x1_24409_24MkPair = heff_take_reuse_n(v_x1_24409, 3ULL, 2);
    switch (heff_tag_of(v_x11_24410)) {
    case TAG_Left: {
      V v_e_24412 = heff_field(v_x11_24410, 0);
      heff_take_n(v_x11_24410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24412}), v_st_24411});
    }
    case TAG_Right: {
      V v_x_24413 = heff_field(v_x11_24410, 0);
      V v_ru_24x11_24410_24Right = heff_take_reuse_n(v_x11_24410, 1ULL, 1);
      V v_t_24414 = heff_tag_at_n(v_ru_24x11_24410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24413})});
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){v_t_24414, v_st_24411});
    }
    default: return heff_nomatch(v_x11_24410);
    }
  }
  default: return heff_nomatch(v_x1_24409);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam37(V self, V *args) {
  V v_st_24422 = args[0];
  V v_m_24421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24423 = heff_tr(heff_call(v_m_24421, 1, (V[]){v_st_24422}));
  switch (heff_tag_of(v_x1_24423)) {
  case TAG_MkPair: {
    V v_x11_24424 = heff_field(v_x1_24423, 0);
    V v_st_24425 = heff_field(v_x1_24423, 1);
    V v_ru_24x1_24423_24MkPair = heff_take_reuse_n(v_x1_24423, 3ULL, 2);
    switch (heff_tag_of(v_x11_24424)) {
    case TAG_Left: {
      V v_e_24426 = heff_field(v_x11_24424, 0);
      heff_take_n(v_x11_24424, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24426}), v_st_24425});
    }
    case TAG_Right: {
      V v_x_24427 = heff_field(v_x11_24424, 0);
      V v_ru_24x11_24424_24Right = heff_take_reuse_n(v_x11_24424, 1ULL, 1);
      V v_t_24428 = heff_tag_at_n(v_ru_24x11_24424_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24427})});
      return heff_tag_at_n(v_ru_24x1_24423_24MkPair, TAG_MkPair, 2, (V[]){v_t_24428, v_st_24425});
    }
    default: return heff_nomatch(v_x11_24424);
    }
  }
  default: return heff_nomatch(v_x1_24423);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam38(V self, V *args) {
  V v_st_24431 = args[0];
  V v_m_24430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24432 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_st_24431}));
  switch (heff_tag_of(v_x1_24432)) {
  case TAG_MkPair: {
    V v_x11_24433 = heff_field(v_x1_24432, 0);
    V v_st_24434 = heff_field(v_x1_24432, 1);
    V v_ru_24x1_24432_24MkPair = heff_take_reuse_n(v_x1_24432, 3ULL, 2);
    switch (heff_tag_of(v_x11_24433)) {
    case TAG_Left: {
      V v_e_24435 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24435}), v_st_24434});
    }
    case TAG_Right: {
      V v_x_24436 = heff_field(v_x11_24433, 0);
      V v_ru_24x11_24433_24Right = heff_take_reuse_n(v_x11_24433, 1ULL, 1);
      V v_t_24437 = heff_tag_at_n(v_ru_24x11_24433_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24436})});
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){v_t_24437, v_st_24434});
    }
    default: return heff_nomatch(v_x11_24433);
    }
  }
  default: return heff_nomatch(v_x1_24432);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam39(V self, V *args) {
  V v_st_24441 = args[0];
  V v_m_24440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24442 = heff_tr(heff_call(v_m_24440, 1, (V[]){v_st_24441}));
  switch (heff_tag_of(v_x1_24442)) {
  case TAG_MkPair: {
    V v_x11_24443 = heff_field(v_x1_24442, 0);
    V v_st_24444 = heff_field(v_x1_24442, 1);
    V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
    switch (heff_tag_of(v_x11_24443)) {
    case TAG_Left: {
      V v_e_24445 = heff_field(v_x11_24443, 0);
      heff_take_n(v_x11_24443, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24445}), v_st_24444});
    }
    case TAG_Right: {
      V v_x_24446 = heff_field(v_x11_24443, 0);
      V v_ru_24x11_24443_24Right = heff_take_reuse_n(v_x11_24443, 1ULL, 1);
      V v_t_24447 = heff_tag_at_n(v_ru_24x11_24443_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24446})});
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){v_t_24447, v_st_24444});
    }
    default: return heff_nomatch(v_x11_24443);
    }
  }
  default: return heff_nomatch(v_x1_24442);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam40(V self, V *args) {
  V v_st_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24454 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_st_24453}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      V v_ru_24x11_24455_24Right = heff_take_reuse_n(v_x11_24455, 1ULL, 1);
      V v_t_24459 = heff_tag_at_n(v_ru_24x11_24455_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24458})});
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){v_t_24459, v_st_24456});
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam41(V self, V *args) {
  V v_st_24463 = args[0];
  V v_m_24462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24464 = heff_tr(heff_call(v_m_24462, 1, (V[]){v_st_24463}));
  switch (heff_tag_of(v_x1_24464)) {
  case TAG_MkPair: {
    V v_x11_24465 = heff_field(v_x1_24464, 0);
    V v_st_24466 = heff_field(v_x1_24464, 1);
    V v_ru_24x1_24464_24MkPair = heff_take_reuse_n(v_x1_24464, 3ULL, 2);
    switch (heff_tag_of(v_x11_24465)) {
    case TAG_Left: {
      V v_e_24467 = heff_field(v_x11_24465, 0);
      heff_take_n(v_x11_24465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24467}), v_st_24466});
    }
    case TAG_Right: {
      V v_x_24468 = heff_field(v_x11_24465, 0);
      V v_ru_24x11_24465_24Right = heff_take_reuse_n(v_x11_24465, 1ULL, 1);
      V v_t_24469 = heff_tag_at_n(v_ru_24x11_24465_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24468})});
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){v_t_24469, v_st_24466});
    }
    default: return heff_nomatch(v_x11_24465);
    }
  }
  default: return heff_nomatch(v_x1_24464);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam42(V self, V *args) {
  V v_st_24475 = args[0];
  V v_m_24474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24476 = heff_tr(heff_call(v_m_24474, 1, (V[]){v_st_24475}));
  switch (heff_tag_of(v_x1_24476)) {
  case TAG_MkPair: {
    V v_x11_24477 = heff_field(v_x1_24476, 0);
    V v_st_24478 = heff_field(v_x1_24476, 1);
    V v_ru_24x1_24476_24MkPair = heff_take_reuse_n(v_x1_24476, 3ULL, 2);
    switch (heff_tag_of(v_x11_24477)) {
    case TAG_Left: {
      V v_e_24479 = heff_field(v_x11_24477, 0);
      heff_take_n(v_x11_24477, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24479}), v_st_24478});
    }
    case TAG_Right: {
      V v_x_24480 = heff_field(v_x11_24477, 0);
      V v_ru_24x11_24477_24Right = heff_take_reuse_n(v_x11_24477, 1ULL, 1);
      V v_t_24481 = heff_tag_at_n(v_ru_24x11_24477_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24480})});
      return heff_tag_at_n(v_ru_24x1_24476_24MkPair, TAG_MkPair, 2, (V[]){v_t_24481, v_st_24478});
    }
    default: return heff_nomatch(v_x11_24477);
    }
  }
  default: return heff_nomatch(v_x1_24476);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam43(V self, V *args) {
  V v_st_24487 = args[0];
  V v_m_24486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24488 = heff_tr(heff_call(v_m_24486, 1, (V[]){v_st_24487}));
  switch (heff_tag_of(v_x1_24488)) {
  case TAG_MkPair: {
    V v_x11_24489 = heff_field(v_x1_24488, 0);
    V v_st_24490 = heff_field(v_x1_24488, 1);
    V v_ru_24x1_24488_24MkPair = heff_take_reuse_n(v_x1_24488, 3ULL, 2);
    switch (heff_tag_of(v_x11_24489)) {
    case TAG_Left: {
      V v_e_24491 = heff_field(v_x11_24489, 0);
      heff_take_n(v_x11_24489, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24491}), v_st_24490});
    }
    case TAG_Right: {
      V v_x_24492 = heff_field(v_x11_24489, 0);
      V v_ru_24x11_24489_24Right = heff_take_reuse_n(v_x11_24489, 1ULL, 1);
      V v_t_24493 = heff_tag_at_n(v_ru_24x11_24489_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24492})});
      return heff_tag_at_n(v_ru_24x1_24488_24MkPair, TAG_MkPair, 2, (V[]){v_t_24493, v_st_24490});
    }
    default: return heff_nomatch(v_x11_24489);
    }
  }
  default: return heff_nomatch(v_x1_24488);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam44(V self, V *args) {
  V v_st_24499 = args[0];
  V v_m_24498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24500 = heff_tr(heff_call(v_m_24498, 1, (V[]){v_st_24499}));
  switch (heff_tag_of(v_x1_24500)) {
  case TAG_MkPair: {
    V v_x11_24501 = heff_field(v_x1_24500, 0);
    V v_st_24502 = heff_field(v_x1_24500, 1);
    V v_ru_24x1_24500_24MkPair = heff_take_reuse_n(v_x1_24500, 3ULL, 2);
    switch (heff_tag_of(v_x11_24501)) {
    case TAG_Left: {
      V v_e_24503 = heff_field(v_x11_24501, 0);
      heff_take_n(v_x11_24501, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24500_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24503}), v_st_24502});
    }
    case TAG_Right: {
      V v_x_24504 = heff_field(v_x11_24501, 0);
      V v_ru_24x11_24501_24Right = heff_take_reuse_n(v_x11_24501, 1ULL, 1);
      V v_t_24505 = heff_tag_at_n(v_ru_24x11_24501_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24504})});
      return heff_tag_at_n(v_ru_24x1_24500_24MkPair, TAG_MkPair, 2, (V[]){v_t_24505, v_st_24502});
    }
    default: return heff_nomatch(v_x11_24501);
    }
  }
  default: return heff_nomatch(v_x1_24500);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam45(V self, V *args) {
  V v_st_24513 = args[0];
  V v_m_24512 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24514 = heff_tr(heff_call(v_m_24512, 1, (V[]){v_st_24513}));
  switch (heff_tag_of(v_x1_24514)) {
  case TAG_MkPair: {
    V v_x11_24515 = heff_field(v_x1_24514, 0);
    V v_st_24516 = heff_field(v_x1_24514, 1);
    V v_ru_24x1_24514_24MkPair = heff_take_reuse_n(v_x1_24514, 3ULL, 2);
    switch (heff_tag_of(v_x11_24515)) {
    case TAG_Left: {
      V v_e_24517 = heff_field(v_x11_24515, 0);
      heff_take_n(v_x11_24515, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24517}), v_st_24516});
    }
    case TAG_Right: {
      V v_x_24518 = heff_field(v_x11_24515, 0);
      V v_ru_24x11_24515_24Right = heff_take_reuse_n(v_x11_24515, 1ULL, 1);
      V v_t_24519 = heff_tag_at_n(v_ru_24x11_24515_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24518})});
      return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){v_t_24519, v_st_24516});
    }
    default: return heff_nomatch(v_x11_24515);
    }
  }
  default: return heff_nomatch(v_x1_24514);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam45(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam46(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam47(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam48(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam49(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam50(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam51(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam52(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam53(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam54(V self, V *args);
Clo g_heff_2esyntax_2esurface_2estmtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2estmtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2estmtL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Seg: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam4, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Braces: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam5, 1, 1, (V[]){v_m_2477});
  }
  case TAG_Update: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_EUSet: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam7, 1, 1, (V[]){v_m_24108});
  }
  case TAG_InstB: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFSet: {
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam9, 1, 1, (V[]){v_m_24138});
  }
  case TAG_EFDefault: {
    V v_m_24152 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam10, 1, 1, (V[]){v_m_24152});
  }
  case TAG_Sum: {
    V v_m_24168 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam11, 1, 1, (V[]){v_m_24168});
  }
  case TAG_ECon: {
    V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam12, 1, 1, (V[]){v_m_24181});
  }
  case TAG_EField: {
    V v_m_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam13, 1, 1, (V[]){v_m_24194});
  }
  case TAG_ENeg: {
    V v_m_24207 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam14, 1, 1, (V[]){v_m_24207});
  }
  case TAG_ETilde: {
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam15, 1, 1, (V[]){v_m_24220});
  }
  case TAG_App: {
    V v_m_24233 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam16, 1, 1, (V[]){v_m_24233});
  }
  case TAG_Op: {
    V v_m_24247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam17, 1, 1, (V[]){v_m_24247});
  }
  case TAG_Ops: {
    V v_m_24260 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam18, 1, 1, (V[]){v_m_24260});
  }
  case TAG_OpRhs: {
    V v_m_24273 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam19, 1, 1, (V[]){v_m_24273});
  }
  case TAG_Ann: {
    V v_m_24287 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam20, 1, 1, (V[]){v_m_24287});
  }
  case TAG_BVar: {
    V v_m_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam21, 1, 1, (V[]){v_m_24299});
  }
  case TAG_BImp: {
    V v_m_24313 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam22, 1, 1, (V[]){v_m_24313});
  }
  case TAG_BAnn: {
    V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam23, 1, 1, (V[]){v_m_24329});
  }
  case TAG_BPat: {
    V v_m_24341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam24, 1, 1, (V[]){v_m_24341});
  }
  case TAG_Lam: {
    V v_m_24356 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam25, 1, 1, (V[]){v_m_24356});
  }
  case TAG_Case: {
    V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam26, 1, 1, (V[]){v_m_24371});
  }
  case TAG_EAlt: {
    V v_m_24385 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam27, 1, 1, (V[]){v_m_24385});
  }
  case TAG_If: {
    V v_m_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam28, 1, 1, (V[]){v_m_24402});
  }
  case TAG_Do: {
    V v_m_24415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam29, 1, 1, (V[]){v_m_24415});
  }
  case TAG_ESBind: {
    V v_x21_24426 = heff_field(v_x2_241, 0);
    V v_e_24428 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x21_24426)) {
    case TAG_PCon: {
      V v_m_24431 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam30, 1, 3, (V[]){v_m_24431, v_r_240, v_x21_24426});
    }
    case TAG_PAtom: {
      V v_x_24458 = heff_field(v_x21_24426, 0);
      heff_take_n(v_x21_24426, 1ULL, 1);
      V v_text_24459 = heff_take_field(v_x_24458, 1);
      V v_start_24460 = heff_take_field(v_x_24458, 3);
      V v_end_24461 = heff_get_n(v_x_24458, 4, 9);
      V v_m_24462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam31, 1, 4, (V[]){v_m_24462, v_text_24459, v_start_24460, v_end_24461});
    }
    case TAG_PParen: {
      V v_m_24480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam32, 1, 3, (V[]){v_m_24480, v_r_240, v_x21_24426});
    }
    case TAG_PList: {
      V v_m_24511 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam33, 1, 3, (V[]){v_m_24511, v_r_240, v_x21_24426});
    }
    case TAG_POp: {
      V v_m_24541 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam34, 1, 3, (V[]){v_m_24541, v_r_240, v_x21_24426});
    }
    case TAG_PRec: {
      V v_m_24572 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam35, 1, 3, (V[]){v_m_24572, v_r_240, v_x21_24426});
    }
    case TAG_PField: {
      V v_m_24602 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam36, 1, 3, (V[]){v_m_24602, v_r_240, v_x21_24426});
    }
    case TAG_PAs: {
      V v_m_24632 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam37, 1, 3, (V[]){v_m_24632, v_r_240, v_x21_24426});
    }
    case TAG_PSeg: {
      V v_m_24662 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam38, 1, 3, (V[]){v_m_24662, v_r_240, v_x21_24426});
    }
    default: return heff_nomatch(v_x21_24426);
    }
  }
  case TAG_ELet: {
    V v_x26_24694 = heff_dup(heff_field(v_x2_241, 5));
    switch (heff_tag_of(v_x26_24694)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_241)) {
      case TAG_ELet: {
        V v_kw_24695 = heff_field(v_x2_241, 0);
        V v_p_24696 = heff_field(v_x2_241, 1);
        V v_ann0_24697 = heff_field(v_x2_241, 2);
        V v_e_24699 = heff_field(v_x2_241, 4);
        heff_take_n(v_x2_241, 23ULL, 6);
        V v_m_24701 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_dup(v_p_24696), v_ann0_24697, heff_dup(v_e_24699)));
        return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam39, 1, 4, (V[]){v_m_24701, v_p_24696, v_e_24699, v_kw_24695});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x26_24694, 0ULL, 1);
      V v_m_24721 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam40, 1, 1, (V[]){v_m_24721});
    }
    default: return heff_nomatch(v_x26_24694);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24732 = heff_dup(heff_field(v_x2_241, 0));
    V v_p_24733 = heff_dup(heff_field(v_x2_241, 1));
    V v_ann0_24734 = heff_dup(heff_field(v_x2_241, 2));
    V v_e_24736 = heff_dup(heff_field(v_x2_241, 4));
    V v_ss_24738 = heff_dup(heff_field(v_x2_241, 6));
    V v_m_24739 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_24733), v_ann0_24734, v_e_24736));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam41, 1, 6, (V[]){v_m_24739, v_r_240, v_ss_24738, v_p_24733, v_x2_241, v_kw_24732});
  }
  case TAG_ELetMut: {
    V v_kw_24766 = heff_field(v_x2_241, 0);
    V v_x_24768 = heff_field(v_x2_241, 2);
    V v_ann0_24769 = heff_field(v_x2_241, 3);
    V v_e_24771 = heff_field(v_x2_241, 5);
    heff_take_n(v_x2_241, 45ULL, 6);
    V v_m_24772 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_tag_n(TAG_PAtom, 1, (V[]){heff_dup(v_x_24768)}), v_ann0_24769, heff_dup(v_e_24771)));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam43, 1, 4, (V[]){v_m_24772, v_x_24768, v_e_24771, v_kw_24766});
  }
  case TAG_EAssign: {
    V v_m_24793 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam44, 1, 1, (V[]){v_m_24793});
  }
  case TAG_EWhile: {
    V v_m_24808 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam45, 1, 1, (V[]){v_m_24808});
  }
  case TAG_EFor: {
    V v_m_24825 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam46, 1, 1, (V[]){v_m_24825});
  }
  case TAG_EJump: {
    V v_m_24837 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam47, 1, 1, (V[]){v_m_24837});
  }
  case TAG_EReturn: {
    V v_m_24850 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam48, 1, 1, (V[]){v_m_24850});
  }
  case TAG_ENest: {
    V v_m_24865 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam49, 1, 1, (V[]){v_m_24865});
  }
  case TAG_EArrow: {
    V v_m_24878 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam50, 1, 1, (V[]){v_m_24878});
  }
  case TAG_IfThen: {
    V v_m_24893 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam51, 1, 1, (V[]){v_m_24893});
  }
  case TAG_ETry: {
    V v_m_24908 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam52, 1, 1, (V[]){v_m_24908});
  }
  case TAG_ECatch: {
    V v_m_24923 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam53, 1, 1, (V[]){v_m_24923});
  }
  case TAG_EWith: {
    V v_m_24940 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam54, 1, 1, (V[]){v_m_24940});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2estmtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_StmtExpr, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_StmtExpr, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_StmtExpr, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_StmtExpr, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_x_2468)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_x_2468, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_x_2468);
      }
      V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_StmtExpr, 1, (V[]){v_x_2468}), v_t_2471});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2472}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      V v_ru_24x11_2480_24Right = heff_take_reuse_n(v_x11_2480, 1ULL, 1);
      V v_t_2486;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_x_2483, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2480_24Right, TAG_StmtExpr, 1, (V[]){v_x_2483}), v_t_2486});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2487}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_StmtExpr, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 1ULL, 1);
      V v_t_24117;
      switch (heff_tag_of(v_x_24114)) {
      case TAG_At: {
        V v_s_24116 = heff_dup(heff_field(v_x_24114, 1));
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_x_24114);
      }
      V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_StmtExpr, 1, (V[]){v_x_24114}), v_t_24117});
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24118}), v_st_24112});
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_StmtExpr, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24147;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_At: {
        V v_s_24146 = heff_dup(heff_field(v_x_24144, 1));
        v_t_24147 = v_s_24146;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_StmtExpr, 1, (V[]){v_x_24144}), v_t_24147});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args) {
  V v_st_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_st_24153}));
  switch (heff_tag_of(v_x1_24154)) {
  case TAG_MkPair: {
    V v_x11_24155 = heff_field(v_x1_24154, 0);
    V v_st_24156 = heff_field(v_x1_24154, 1);
    V v_ru_24x1_24154_24MkPair = heff_take_reuse_n(v_x1_24154, 3ULL, 2);
    switch (heff_tag_of(v_x11_24155)) {
    case TAG_Left: {
      V v_e_24157 = heff_field(v_x11_24155, 0);
      heff_take_n(v_x11_24155, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24157}), v_st_24156});
    }
    case TAG_Right: {
      V v_x_24158 = heff_field(v_x11_24155, 0);
      V v_ru_24x11_24155_24Right = heff_take_reuse_n(v_x11_24155, 1ULL, 1);
      V v_t_24161;
      switch (heff_tag_of(v_x_24158)) {
      case TAG_At: {
        V v_s_24160 = heff_dup(heff_field(v_x_24158, 1));
        v_t_24161 = v_s_24160;
        break;
      }
      default: heff_nomatch(v_x_24158);
      }
      V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24155_24Right, TAG_StmtExpr, 1, (V[]){v_x_24158}), v_t_24161});
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24162}), v_st_24156});
    }
    default: return heff_nomatch(v_x11_24155);
    }
  }
  default: return heff_nomatch(v_x1_24154);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args) {
  V v_st_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_st_24169}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
      V v_t_24177;
      switch (heff_tag_of(v_x_24174)) {
      case TAG_At: {
        V v_s_24176 = heff_dup(heff_field(v_x_24174, 1));
        v_t_24177 = v_s_24176;
        break;
      }
      default: heff_nomatch(v_x_24174);
      }
      V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_StmtExpr, 1, (V[]){v_x_24174}), v_t_24177});
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24178}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24190;
      switch (heff_tag_of(v_x_24187)) {
      case TAG_At: {
        V v_s_24189 = heff_dup(heff_field(v_x_24187, 1));
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_x_24187);
      }
      V v_t_24191 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_StmtExpr, 1, (V[]){v_x_24187}), v_t_24190});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24191}), v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args) {
  V v_st_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_st_24195}));
  switch (heff_tag_of(v_x1_24196)) {
  case TAG_MkPair: {
    V v_x11_24197 = heff_field(v_x1_24196, 0);
    V v_st_24198 = heff_field(v_x1_24196, 1);
    V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
    switch (heff_tag_of(v_x11_24197)) {
    case TAG_Left: {
      V v_e_24199 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
    }
    case TAG_Right: {
      V v_x_24200 = heff_field(v_x11_24197, 0);
      V v_ru_24x11_24197_24Right = heff_take_reuse_n(v_x11_24197, 1ULL, 1);
      V v_t_24203;
      switch (heff_tag_of(v_x_24200)) {
      case TAG_At: {
        V v_s_24202 = heff_dup(heff_field(v_x_24200, 1));
        v_t_24203 = v_s_24202;
        break;
      }
      default: heff_nomatch(v_x_24200);
      }
      V v_t_24204 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24197_24Right, TAG_StmtExpr, 1, (V[]){v_x_24200}), v_t_24203});
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24204}), v_st_24198});
    }
    default: return heff_nomatch(v_x11_24197);
    }
  }
  default: return heff_nomatch(v_x1_24196);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args) {
  V v_st_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24209 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_st_24208}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_MkPair: {
    V v_x11_24210 = heff_field(v_x1_24209, 0);
    V v_st_24211 = heff_field(v_x1_24209, 1);
    V v_ru_24x1_24209_24MkPair = heff_take_reuse_n(v_x1_24209, 3ULL, 2);
    switch (heff_tag_of(v_x11_24210)) {
    case TAG_Left: {
      V v_e_24212 = heff_field(v_x11_24210, 0);
      heff_take_n(v_x11_24210, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24212}), v_st_24211});
    }
    case TAG_Right: {
      V v_x_24213 = heff_field(v_x11_24210, 0);
      V v_ru_24x11_24210_24Right = heff_take_reuse_n(v_x11_24210, 1ULL, 1);
      V v_t_24216;
      switch (heff_tag_of(v_x_24213)) {
      case TAG_At: {
        V v_s_24215 = heff_dup(heff_field(v_x_24213, 1));
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_x_24213);
      }
      V v_t_24217 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24210_24Right, TAG_StmtExpr, 1, (V[]){v_x_24213}), v_t_24216});
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24217}), v_st_24211});
    }
    default: return heff_nomatch(v_x11_24210);
    }
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args) {
  V v_st_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_st_24221}));
  switch (heff_tag_of(v_x1_24222)) {
  case TAG_MkPair: {
    V v_x11_24223 = heff_field(v_x1_24222, 0);
    V v_st_24224 = heff_field(v_x1_24222, 1);
    V v_ru_24x1_24222_24MkPair = heff_take_reuse_n(v_x1_24222, 3ULL, 2);
    switch (heff_tag_of(v_x11_24223)) {
    case TAG_Left: {
      V v_e_24225 = heff_field(v_x11_24223, 0);
      heff_take_n(v_x11_24223, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24225}), v_st_24224});
    }
    case TAG_Right: {
      V v_x_24226 = heff_field(v_x11_24223, 0);
      V v_ru_24x11_24223_24Right = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
      V v_t_24229;
      switch (heff_tag_of(v_x_24226)) {
      case TAG_At: {
        V v_s_24228 = heff_dup(heff_field(v_x_24226, 1));
        v_t_24229 = v_s_24228;
        break;
      }
      default: heff_nomatch(v_x_24226);
      }
      V v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24223_24Right, TAG_StmtExpr, 1, (V[]){v_x_24226}), v_t_24229});
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24230}), v_st_24224});
    }
    default: return heff_nomatch(v_x11_24223);
    }
  }
  default: return heff_nomatch(v_x1_24222);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args) {
  V v_st_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_st_24234}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_MkPair: {
    V v_x11_24236 = heff_field(v_x1_24235, 0);
    V v_st_24237 = heff_field(v_x1_24235, 1);
    V v_ru_24x1_24235_24MkPair = heff_take_reuse_n(v_x1_24235, 3ULL, 2);
    switch (heff_tag_of(v_x11_24236)) {
    case TAG_Left: {
      V v_e_24238 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24238}), v_st_24237});
    }
    case TAG_Right: {
      V v_x_24239 = heff_field(v_x11_24236, 0);
      V v_ru_24x11_24236_24Right = heff_take_reuse_n(v_x11_24236, 1ULL, 1);
      V v_t_24242;
      switch (heff_tag_of(v_x_24239)) {
      case TAG_At: {
        V v_s_24241 = heff_dup(heff_field(v_x_24239, 1));
        v_t_24242 = v_s_24241;
        break;
      }
      default: heff_nomatch(v_x_24239);
      }
      V v_t_24243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24236_24Right, TAG_StmtExpr, 1, (V[]){v_x_24239}), v_t_24242});
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24243}), v_st_24237});
    }
    default: return heff_nomatch(v_x11_24236);
    }
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      V v_ru_24x11_24250_24Right = heff_take_reuse_n(v_x11_24250, 1ULL, 1);
      V v_t_24256;
      switch (heff_tag_of(v_x_24253)) {
      case TAG_At: {
        V v_s_24255 = heff_dup(heff_field(v_x_24253, 1));
        v_t_24256 = v_s_24255;
        break;
      }
      default: heff_nomatch(v_x_24253);
      }
      V v_t_24257 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24250_24Right, TAG_StmtExpr, 1, (V[]){v_x_24253}), v_t_24256});
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24257}), v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
      V v_t_24269;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24268 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24269 = v_s_24268;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_t_24270 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_StmtExpr, 1, (V[]){v_x_24266}), v_t_24269});
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24270}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args) {
  V v_st_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_st_24274}));
  switch (heff_tag_of(v_x1_24275)) {
  case TAG_MkPair: {
    V v_x11_24276 = heff_field(v_x1_24275, 0);
    V v_st_24277 = heff_field(v_x1_24275, 1);
    V v_ru_24x1_24275_24MkPair = heff_take_reuse_n(v_x1_24275, 3ULL, 2);
    switch (heff_tag_of(v_x11_24276)) {
    case TAG_Left: {
      V v_e_24278 = heff_field(v_x11_24276, 0);
      heff_take_n(v_x11_24276, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24278}), v_st_24277});
    }
    case TAG_Right: {
      V v_x_24279 = heff_field(v_x11_24276, 0);
      V v_ru_24x11_24276_24Right = heff_take_reuse_n(v_x11_24276, 1ULL, 1);
      V v_t_24282;
      switch (heff_tag_of(v_x_24279)) {
      case TAG_At: {
        V v_s_24281 = heff_dup(heff_field(v_x_24279, 1));
        v_t_24282 = v_s_24281;
        break;
      }
      default: heff_nomatch(v_x_24279);
      }
      V v_t_24283 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24276_24Right, TAG_StmtExpr, 1, (V[]){v_x_24279}), v_t_24282});
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24283}), v_st_24277});
    }
    default: return heff_nomatch(v_x11_24276);
    }
  }
  default: return heff_nomatch(v_x1_24275);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args) {
  V v_st_24288 = args[0];
  V v_m_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24289 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_st_24288}));
  switch (heff_tag_of(v_x1_24289)) {
  case TAG_MkPair: {
    V v_x11_24290 = heff_field(v_x1_24289, 0);
    V v_st_24291 = heff_field(v_x1_24289, 1);
    V v_ru_24x1_24289_24MkPair = heff_take_reuse_n(v_x1_24289, 3ULL, 2);
    switch (heff_tag_of(v_x11_24290)) {
    case TAG_Left: {
      V v_e_24292 = heff_field(v_x11_24290, 0);
      heff_take_n(v_x11_24290, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24292}), v_st_24291});
    }
    case TAG_Right: {
      V v_x_24293 = heff_field(v_x11_24290, 0);
      V v_ru_24x11_24290_24Right = heff_take_reuse_n(v_x11_24290, 1ULL, 1);
      V v_t_24296;
      switch (heff_tag_of(v_x_24293)) {
      case TAG_At: {
        V v_s_24295 = heff_dup(heff_field(v_x_24293, 1));
        v_t_24296 = v_s_24295;
        break;
      }
      default: heff_nomatch(v_x_24293);
      }
      V v_t_24297 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24290_24Right, TAG_StmtExpr, 1, (V[]){v_x_24293}), v_t_24296});
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24297}), v_st_24291});
    }
    default: return heff_nomatch(v_x11_24290);
    }
  }
  default: return heff_nomatch(v_x1_24289);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args) {
  V v_st_24300 = args[0];
  V v_m_24299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24301 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_st_24300}));
  switch (heff_tag_of(v_x1_24301)) {
  case TAG_MkPair: {
    V v_x11_24302 = heff_field(v_x1_24301, 0);
    V v_st_24303 = heff_field(v_x1_24301, 1);
    V v_ru_24x1_24301_24MkPair = heff_take_reuse_n(v_x1_24301, 3ULL, 2);
    switch (heff_tag_of(v_x11_24302)) {
    case TAG_Left: {
      V v_e_24304 = heff_field(v_x11_24302, 0);
      heff_take_n(v_x11_24302, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24304}), v_st_24303});
    }
    case TAG_Right: {
      V v_x_24305 = heff_field(v_x11_24302, 0);
      V v_ru_24x11_24302_24Right = heff_take_reuse_n(v_x11_24302, 1ULL, 1);
      V v_t_24308;
      switch (heff_tag_of(v_x_24305)) {
      case TAG_At: {
        V v_s_24307 = heff_dup(heff_field(v_x_24305, 1));
        v_t_24308 = v_s_24307;
        break;
      }
      default: heff_nomatch(v_x_24305);
      }
      V v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24302_24Right, TAG_StmtExpr, 1, (V[]){v_x_24305}), v_t_24308});
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24309}), v_st_24303});
    }
    default: return heff_nomatch(v_x11_24302);
    }
  }
  default: return heff_nomatch(v_x1_24301);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args) {
  V v_st_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_st_24314}));
  switch (heff_tag_of(v_x1_24315)) {
  case TAG_MkPair: {
    V v_x11_24316 = heff_field(v_x1_24315, 0);
    V v_st_24317 = heff_field(v_x1_24315, 1);
    V v_ru_24x1_24315_24MkPair = heff_take_reuse_n(v_x1_24315, 3ULL, 2);
    switch (heff_tag_of(v_x11_24316)) {
    case TAG_Left: {
      V v_e_24318 = heff_field(v_x11_24316, 0);
      heff_take_n(v_x11_24316, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24318}), v_st_24317});
    }
    case TAG_Right: {
      V v_x_24319 = heff_field(v_x11_24316, 0);
      V v_ru_24x11_24316_24Right = heff_take_reuse_n(v_x11_24316, 1ULL, 1);
      V v_t_24322;
      switch (heff_tag_of(v_x_24319)) {
      case TAG_At: {
        V v_s_24321 = heff_dup(heff_field(v_x_24319, 1));
        v_t_24322 = v_s_24321;
        break;
      }
      default: heff_nomatch(v_x_24319);
      }
      V v_t_24323 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24316_24Right, TAG_StmtExpr, 1, (V[]){v_x_24319}), v_t_24322});
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24323}), v_st_24317});
    }
    default: return heff_nomatch(v_x11_24316);
    }
  }
  default: return heff_nomatch(v_x1_24315);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Right = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      V v_t_24338;
      switch (heff_tag_of(v_x_24335)) {
      case TAG_At: {
        V v_s_24337 = heff_dup(heff_field(v_x_24335, 1));
        v_t_24338 = v_s_24337;
        break;
      }
      default: heff_nomatch(v_x_24335);
      }
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24332_24Right, TAG_StmtExpr, 1, (V[]){v_x_24335}), v_t_24338});
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24339}), v_st_24333});
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args) {
  V v_st_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_st_24342}));
  switch (heff_tag_of(v_x1_24343)) {
  case TAG_MkPair: {
    V v_x11_24344 = heff_field(v_x1_24343, 0);
    V v_st_24345 = heff_field(v_x1_24343, 1);
    V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
    switch (heff_tag_of(v_x11_24344)) {
    case TAG_Left: {
      V v_e_24346 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
    }
    case TAG_Right: {
      V v_x_24347 = heff_field(v_x11_24344, 0);
      V v_ru_24x11_24344_24Right = heff_take_reuse_n(v_x11_24344, 1ULL, 1);
      V v_t_24350;
      switch (heff_tag_of(v_x_24347)) {
      case TAG_At: {
        V v_s_24349 = heff_dup(heff_field(v_x_24347, 1));
        v_t_24350 = v_s_24349;
        break;
      }
      default: heff_nomatch(v_x_24347);
      }
      V v_t_24351 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24344_24Right, TAG_StmtExpr, 1, (V[]){v_x_24347}), v_t_24350});
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24351}), v_st_24345});
    }
    default: return heff_nomatch(v_x11_24344);
    }
  }
  default: return heff_nomatch(v_x1_24343);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args) {
  V v_st_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_st_24357}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_MkPair: {
    V v_x11_24359 = heff_field(v_x1_24358, 0);
    V v_st_24360 = heff_field(v_x1_24358, 1);
    V v_ru_24x1_24358_24MkPair = heff_take_reuse_n(v_x1_24358, 3ULL, 2);
    switch (heff_tag_of(v_x11_24359)) {
    case TAG_Left: {
      V v_e_24361 = heff_field(v_x11_24359, 0);
      heff_take_n(v_x11_24359, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24361}), v_st_24360});
    }
    case TAG_Right: {
      V v_x_24362 = heff_field(v_x11_24359, 0);
      V v_ru_24x11_24359_24Right = heff_take_reuse_n(v_x11_24359, 1ULL, 1);
      V v_t_24365;
      switch (heff_tag_of(v_x_24362)) {
      case TAG_At: {
        V v_s_24364 = heff_dup(heff_field(v_x_24362, 1));
        v_t_24365 = v_s_24364;
        break;
      }
      default: heff_nomatch(v_x_24362);
      }
      V v_t_24366 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24359_24Right, TAG_StmtExpr, 1, (V[]){v_x_24362}), v_t_24365});
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24366}), v_st_24360});
    }
    default: return heff_nomatch(v_x11_24359);
    }
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args) {
  V v_st_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24373 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_st_24372}));
  switch (heff_tag_of(v_x1_24373)) {
  case TAG_MkPair: {
    V v_x11_24374 = heff_field(v_x1_24373, 0);
    V v_st_24375 = heff_field(v_x1_24373, 1);
    V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
    switch (heff_tag_of(v_x11_24374)) {
    case TAG_Left: {
      V v_e_24376 = heff_field(v_x11_24374, 0);
      heff_take_n(v_x11_24374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
    }
    case TAG_Right: {
      V v_x_24377 = heff_field(v_x11_24374, 0);
      V v_ru_24x11_24374_24Right = heff_take_reuse_n(v_x11_24374, 1ULL, 1);
      V v_t_24380;
      switch (heff_tag_of(v_x_24377)) {
      case TAG_At: {
        V v_s_24379 = heff_dup(heff_field(v_x_24377, 1));
        v_t_24380 = v_s_24379;
        break;
      }
      default: heff_nomatch(v_x_24377);
      }
      V v_t_24381 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24374_24Right, TAG_StmtExpr, 1, (V[]){v_x_24377}), v_t_24380});
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24381}), v_st_24375});
    }
    default: return heff_nomatch(v_x11_24374);
    }
  }
  default: return heff_nomatch(v_x1_24373);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args) {
  V v_st_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24386}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_MkPair: {
    V v_x11_24388 = heff_field(v_x1_24387, 0);
    V v_st_24389 = heff_field(v_x1_24387, 1);
    V v_ru_24x1_24387_24MkPair = heff_take_reuse_n(v_x1_24387, 3ULL, 2);
    switch (heff_tag_of(v_x11_24388)) {
    case TAG_Left: {
      V v_e_24390 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24390}), v_st_24389});
    }
    case TAG_Right: {
      V v_x_24391 = heff_field(v_x11_24388, 0);
      V v_ru_24x11_24388_24Right = heff_take_reuse_n(v_x11_24388, 1ULL, 1);
      V v_t_24394;
      switch (heff_tag_of(v_x_24391)) {
      case TAG_At: {
        V v_s_24393 = heff_dup(heff_field(v_x_24391, 1));
        v_t_24394 = v_s_24393;
        break;
      }
      default: heff_nomatch(v_x_24391);
      }
      V v_t_24395 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24388_24Right, TAG_StmtExpr, 1, (V[]){v_x_24391}), v_t_24394});
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24395}), v_st_24389});
    }
    default: return heff_nomatch(v_x11_24388);
    }
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args) {
  V v_st_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_st_24403}));
  switch (heff_tag_of(v_x1_24404)) {
  case TAG_MkPair: {
    V v_x11_24405 = heff_field(v_x1_24404, 0);
    V v_st_24406 = heff_field(v_x1_24404, 1);
    V v_ru_24x1_24404_24MkPair = heff_take_reuse_n(v_x1_24404, 3ULL, 2);
    switch (heff_tag_of(v_x11_24405)) {
    case TAG_Left: {
      V v_e_24407 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24407}), v_st_24406});
    }
    case TAG_Right: {
      V v_x_24408 = heff_field(v_x11_24405, 0);
      V v_ru_24x11_24405_24Right = heff_take_reuse_n(v_x11_24405, 1ULL, 1);
      V v_t_24411;
      switch (heff_tag_of(v_x_24408)) {
      case TAG_At: {
        V v_s_24410 = heff_dup(heff_field(v_x_24408, 1));
        v_t_24411 = v_s_24410;
        break;
      }
      default: heff_nomatch(v_x_24408);
      }
      V v_t_24412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24405_24Right, TAG_StmtExpr, 1, (V[]){v_x_24408}), v_t_24411});
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24412}), v_st_24406});
    }
    default: return heff_nomatch(v_x11_24405);
    }
  }
  default: return heff_nomatch(v_x1_24404);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args) {
  V v_st_24416 = args[0];
  V v_m_24415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24417 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_st_24416}));
  switch (heff_tag_of(v_x1_24417)) {
  case TAG_MkPair: {
    V v_x11_24418 = heff_field(v_x1_24417, 0);
    V v_st_24419 = heff_field(v_x1_24417, 1);
    V v_ru_24x1_24417_24MkPair = heff_take_reuse_n(v_x1_24417, 3ULL, 2);
    switch (heff_tag_of(v_x11_24418)) {
    case TAG_Left: {
      V v_e_24420 = heff_field(v_x11_24418, 0);
      heff_take_n(v_x11_24418, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24420}), v_st_24419});
    }
    case TAG_Right: {
      V v_x_24421 = heff_field(v_x11_24418, 0);
      V v_ru_24x11_24418_24Right = heff_take_reuse_n(v_x11_24418, 1ULL, 1);
      V v_t_24424;
      switch (heff_tag_of(v_x_24421)) {
      case TAG_At: {
        V v_s_24423 = heff_dup(heff_field(v_x_24421, 1));
        v_t_24424 = v_s_24423;
        break;
      }
      default: heff_nomatch(v_x_24421);
      }
      V v_t_24425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24418_24Right, TAG_StmtExpr, 1, (V[]){v_x_24421}), v_t_24424});
      return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24425}), v_st_24419});
    }
    default: return heff_nomatch(v_x11_24418);
    }
  }
  default: return heff_nomatch(v_x1_24417);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args) {
  V v_st_24432 = args[0];
  V v_m_24431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24433 = heff_tr(heff_call(v_m_24431, 1, (V[]){v_st_24432}));
  switch (heff_tag_of(v_x1_24433)) {
  case TAG_MkPair: {
    V v_x11_24434 = heff_field(v_x1_24433, 0);
    V v_st_24435 = heff_field(v_x1_24433, 1);
    V v_ru_24x1_24433_24MkPair = heff_take_reuse_n(v_x1_24433, 3ULL, 2);
    switch (heff_tag_of(v_x11_24434)) {
    case TAG_Left: {
      V v_e_24436 = heff_field(v_x11_24434, 0);
      heff_take_n(v_x11_24434, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 2);
      return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24436}), v_st_24435});
    }
    case TAG_Right: {
      V v_x_24437 = heff_field(v_x11_24434, 0);
      V v_ru_24x11_24434_24Right = heff_take_reuse_n(v_x11_24434, 1ULL, 1);
      V v_m_24438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24439 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_st_24435}));
      switch (heff_tag_of(v_x1_24439)) {
      case TAG_MkPair: {
        V v_x11_24440 = heff_field(v_x1_24439, 0);
        V v_st_24441 = heff_field(v_x1_24439, 1);
        V v_ru_24x1_24439_24MkPair = heff_take_reuse_n(v_x1_24439, 3ULL, 2);
        switch (heff_tag_of(v_x11_24440)) {
        case TAG_Left: {
          V v_e_24442 = heff_field(v_x11_24440, 0);
          heff_take_n(v_x11_24440, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 2);
          heff_drop(v_x_24437);
          heff_drop_cell(v_ru_24x11_24434_24Right, 1);
          heff_drop_cell(v_ru_24x1_24439_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24442}), v_st_24441});
        }
        case TAG_Right: {
          V v_x_24443 = heff_field(v_x11_24440, 0);
          heff_take_n(v_x11_24440, 1ULL, 1);
          V v_sc_24444 = ({ V a_0 = heff_take_field(v_st_24441, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 2); r_; });
          V v_t_24447;
          switch (heff_tag_of(v_x_24437)) {
          case TAG_At: {
            V v_s_24446 = heff_dup(heff_field(v_x_24437, 1));
            v_t_24447 = v_s_24446;
            break;
          }
          default: heff_nomatch(v_x_24437);
          }
          V v_t_24448 = heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24434_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24437)}), v_t_24447});
          V v_t_24451;
          switch (heff_tag_of(v_x_24443)) {
          case TAG_At: {
            V v_s_24450 = heff_dup(heff_field(v_x_24443, 1));
            v_t_24451 = v_s_24450;
            break;
          }
          default: heff_nomatch(v_x_24443);
          }
          V v_t_24454;
          switch (heff_tag_of(v_x_24437)) {
          case TAG_At: {
            V v_s_24453 = heff_field(v_x_24437, 1);
            heff_take_n(v_x_24437, 2ULL, 2);
            v_t_24454 = v_s_24453;
            break;
          }
          default: heff_nomatch(v_x_24437);
          }
          V v_t_24455 = ({ V rv_1 = heff_get_n(v_t_24454, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24451, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24443, v_t_24448}), v_t_24455});
          V v_t_24457 = ({ V rv_1 = v_sc_24444; V rr_ = heff_rec_reuse_nf(v_st_24441, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24456}), v_t_24457});
        }
        default: return heff_nomatch(v_x11_24440);
        }
      }
      default: return heff_nomatch(v_x1_24439);
      }
    }
    default: return heff_nomatch(v_x11_24434);
    }
  }
  default: return heff_nomatch(v_x1_24433);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args) {
  V v_st_24463 = args[0];
  V v_m_24462 = heff_env(self)[0];
  V v_text_24459 = heff_env(self)[1];
  V v_start_24460 = heff_env(self)[2];
  V v_end_24461 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24464 = heff_tr(heff_call(v_m_24462, 1, (V[]){v_st_24463}));
  switch (heff_tag_of(v_x1_24464)) {
  case TAG_MkPair: {
    V v_x11_24465 = heff_field(v_x1_24464, 0);
    V v_st_24466 = heff_field(v_x1_24464, 1);
    V v_ru_24x1_24464_24MkPair = heff_take_reuse_n(v_x1_24464, 3ULL, 2);
    switch (heff_tag_of(v_x11_24465)) {
    case TAG_Left: {
      V v_e_24467 = heff_field(v_x11_24465, 0);
      heff_take_n(v_x11_24465, 1ULL, 1);
      heff_drop(v_text_24459);
      heff_drop(v_start_24460);
      heff_drop(v_end_24461);
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24467}), v_st_24466});
    }
    case TAG_Right: {
      V v_x_24468 = heff_field(v_x11_24465, 0);
      V v_ru_24x11_24465_24Right = heff_take_reuse_n(v_x11_24465, 1ULL, 1);
      V v_t_24469 = heff_tag_n(TAG_StmtBind, 3, (V[]){heff_dup(v_text_24459), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24460), v_end_24461}), heff_dup(v_x_24468)});
      V v_t_24472;
      switch (heff_tag_of(v_x_24468)) {
      case TAG_At: {
        V v_s_24471 = heff_field(v_x_24468, 1);
        heff_take_n(v_x_24468, 2ULL, 2);
        v_t_24472 = v_s_24471;
        break;
      }
      default: heff_nomatch(v_x_24468);
      }
      V v_t_24473 = ({ V rv_0 = v_start_24460; V rr_ = heff_rec_reuse_nf(v_t_24472, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24474 = heff_tag_at_n(v_ru_24x11_24465_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24469, v_t_24473})});
      V v_t_24475 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_24459, heff_take_field(v_st_24466, 1)});
      V v_t_24476 = ({ V rv_1 = v_t_24475; V rr_ = heff_rec_reuse_nf(v_st_24466, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){v_t_24474, v_t_24476});
    }
    default: return heff_nomatch(v_x11_24465);
    }
  }
  default: return heff_nomatch(v_x1_24464);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args) {
  V v_st_24481 = args[0];
  V v_m_24480 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24482 = heff_tr(heff_call(v_m_24480, 1, (V[]){v_st_24481}));
  switch (heff_tag_of(v_x1_24482)) {
  case TAG_MkPair: {
    V v_x11_24483 = heff_field(v_x1_24482, 0);
    V v_st_24484 = heff_field(v_x1_24482, 1);
    V v_ru_24x1_24482_24MkPair = heff_take_reuse_n(v_x1_24482, 3ULL, 2);
    switch (heff_tag_of(v_x11_24483)) {
    case TAG_Left: {
      V v_e_24485 = heff_field(v_x11_24483, 0);
      heff_take_n(v_x11_24483, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24485}), v_st_24484});
    }
    case TAG_Right: {
      V v_x_24486 = heff_field(v_x11_24483, 0);
      V v_ru_24x11_24483_24Right = heff_take_reuse_n(v_x11_24483, 1ULL, 1);
      V v_m_24487 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24488 = heff_tr(heff_call(v_m_24487, 1, (V[]){v_st_24484}));
      switch (heff_tag_of(v_x1_24488)) {
      case TAG_MkPair: {
        V v_x11_24489 = heff_field(v_x1_24488, 0);
        V v_st_24490 = heff_field(v_x1_24488, 1);
        V v_ru_24x1_24488_24MkPair = heff_take_reuse_n(v_x1_24488, 3ULL, 2);
        switch (heff_tag_of(v_x11_24489)) {
        case TAG_Left: {
          V v_e_24491 = heff_field(v_x11_24489, 0);
          heff_take_n(v_x11_24489, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24486);
          heff_drop_cell(v_ru_24x11_24483_24Right, 1);
          heff_drop_cell(v_ru_24x1_24488_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24491}), v_st_24490});
        }
        case TAG_Right: {
          V v_x_24492 = heff_field(v_x11_24489, 0);
          heff_take_n(v_x11_24489, 1ULL, 1);
          V v_sc_24493 = ({ V a_0 = heff_take_field(v_st_24490, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24496;
          switch (heff_tag_of(v_x_24486)) {
          case TAG_At: {
            V v_s_24495 = heff_dup(heff_field(v_x_24486, 1));
            v_t_24496 = v_s_24495;
            break;
          }
          default: heff_nomatch(v_x_24486);
          }
          V v_t_24497 = heff_tag_at_n(v_ru_24x1_24488_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24483_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24486)}), v_t_24496});
          V v_t_24500;
          switch (heff_tag_of(v_x_24492)) {
          case TAG_At: {
            V v_s_24499 = heff_dup(heff_field(v_x_24492, 1));
            v_t_24500 = v_s_24499;
            break;
          }
          default: heff_nomatch(v_x_24492);
          }
          V v_t_24503;
          switch (heff_tag_of(v_x_24486)) {
          case TAG_At: {
            V v_s_24502 = heff_field(v_x_24486, 1);
            heff_take_n(v_x_24486, 2ULL, 2);
            v_t_24503 = v_s_24502;
            break;
          }
          default: heff_nomatch(v_x_24486);
          }
          V v_t_24504 = ({ V rv_1 = heff_get_n(v_t_24503, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24500, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24505 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24492, v_t_24497}), v_t_24504});
          V v_t_24506 = ({ V rv_1 = v_sc_24493; V rr_ = heff_rec_reuse_nf(v_st_24490, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24505}), v_t_24506});
        }
        default: return heff_nomatch(v_x11_24489);
        }
      }
      default: return heff_nomatch(v_x1_24488);
      }
    }
    default: return heff_nomatch(v_x11_24483);
    }
  }
  default: return heff_nomatch(v_x1_24482);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args) {
  V v_st_24512 = args[0];
  V v_m_24511 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24513 = heff_tr(heff_call(v_m_24511, 1, (V[]){v_st_24512}));
  switch (heff_tag_of(v_x1_24513)) {
  case TAG_MkPair: {
    V v_x11_24514 = heff_field(v_x1_24513, 0);
    V v_st_24515 = heff_field(v_x1_24513, 1);
    V v_ru_24x1_24513_24MkPair = heff_take_reuse_n(v_x1_24513, 3ULL, 2);
    switch (heff_tag_of(v_x11_24514)) {
    case TAG_Left: {
      V v_e_24516 = heff_field(v_x11_24514, 0);
      heff_take_n(v_x11_24514, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 4);
      return heff_tag_at_n(v_ru_24x1_24513_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24516}), v_st_24515});
    }
    case TAG_Right: {
      V v_x_24517 = heff_field(v_x11_24514, 0);
      V v_ru_24x11_24514_24Right = heff_take_reuse_n(v_x11_24514, 1ULL, 1);
      V v_m_24518 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24519 = heff_tr(heff_call(v_m_24518, 1, (V[]){v_st_24515}));
      switch (heff_tag_of(v_x1_24519)) {
      case TAG_MkPair: {
        V v_x11_24520 = heff_field(v_x1_24519, 0);
        V v_st_24521 = heff_field(v_x1_24519, 1);
        V v_ru_24x1_24519_24MkPair = heff_take_reuse_n(v_x1_24519, 3ULL, 2);
        switch (heff_tag_of(v_x11_24520)) {
        case TAG_Left: {
          V v_e_24522 = heff_field(v_x11_24520, 0);
          heff_take_n(v_x11_24520, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 4);
          heff_drop(v_x_24517);
          heff_drop_cell(v_ru_24x11_24514_24Right, 1);
          heff_drop_cell(v_ru_24x1_24519_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24513_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24522}), v_st_24521});
        }
        case TAG_Right: {
          V v_x_24523 = heff_field(v_x11_24520, 0);
          heff_take_n(v_x11_24520, 1ULL, 1);
          V v_sc_24524 = ({ V a_0 = heff_take_field(v_st_24521, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 4); r_; });
          V v_t_24527;
          switch (heff_tag_of(v_x_24517)) {
          case TAG_At: {
            V v_s_24526 = heff_dup(heff_field(v_x_24517, 1));
            v_t_24527 = v_s_24526;
            break;
          }
          default: heff_nomatch(v_x_24517);
          }
          V v_t_24528 = heff_tag_at_n(v_ru_24x1_24519_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24514_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24517)}), v_t_24527});
          V v_t_24531;
          switch (heff_tag_of(v_x_24523)) {
          case TAG_At: {
            V v_s_24530 = heff_dup(heff_field(v_x_24523, 1));
            v_t_24531 = v_s_24530;
            break;
          }
          default: heff_nomatch(v_x_24523);
          }
          V v_t_24534;
          switch (heff_tag_of(v_x_24517)) {
          case TAG_At: {
            V v_s_24533 = heff_field(v_x_24517, 1);
            heff_take_n(v_x_24517, 2ULL, 2);
            v_t_24534 = v_s_24533;
            break;
          }
          default: heff_nomatch(v_x_24517);
          }
          V v_t_24535 = ({ V rv_1 = heff_get_n(v_t_24534, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24531, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24536 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24523, v_t_24528}), v_t_24535});
          V v_t_24537 = ({ V rv_1 = v_sc_24524; V rr_ = heff_rec_reuse_nf(v_st_24521, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24513_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24536}), v_t_24537});
        }
        default: return heff_nomatch(v_x11_24520);
        }
      }
      default: return heff_nomatch(v_x1_24519);
      }
    }
    default: return heff_nomatch(v_x11_24514);
    }
  }
  default: return heff_nomatch(v_x1_24513);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args) {
  V v_st_24542 = args[0];
  V v_m_24541 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24543 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_st_24542}));
  switch (heff_tag_of(v_x1_24543)) {
  case TAG_MkPair: {
    V v_x11_24544 = heff_field(v_x1_24543, 0);
    V v_st_24545 = heff_field(v_x1_24543, 1);
    V v_ru_24x1_24543_24MkPair = heff_take_reuse_n(v_x1_24543, 3ULL, 2);
    switch (heff_tag_of(v_x11_24544)) {
    case TAG_Left: {
      V v_e_24546 = heff_field(v_x11_24544, 0);
      heff_take_n(v_x11_24544, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24546}), v_st_24545});
    }
    case TAG_Right: {
      V v_x_24547 = heff_field(v_x11_24544, 0);
      V v_ru_24x11_24544_24Right = heff_take_reuse_n(v_x11_24544, 1ULL, 1);
      V v_m_24548 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24549 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_st_24545}));
      switch (heff_tag_of(v_x1_24549)) {
      case TAG_MkPair: {
        V v_x11_24550 = heff_field(v_x1_24549, 0);
        V v_st_24551 = heff_field(v_x1_24549, 1);
        V v_ru_24x1_24549_24MkPair = heff_take_reuse_n(v_x1_24549, 3ULL, 2);
        switch (heff_tag_of(v_x11_24550)) {
        case TAG_Left: {
          V v_e_24552 = heff_field(v_x11_24550, 0);
          heff_take_n(v_x11_24550, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24547);
          heff_drop_cell(v_ru_24x11_24544_24Right, 1);
          heff_drop_cell(v_ru_24x1_24549_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24552}), v_st_24551});
        }
        case TAG_Right: {
          V v_x_24553 = heff_field(v_x11_24550, 0);
          heff_take_n(v_x11_24550, 1ULL, 1);
          V v_sc_24554 = ({ V a_0 = heff_take_field(v_st_24551, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24557;
          switch (heff_tag_of(v_x_24547)) {
          case TAG_At: {
            V v_s_24556 = heff_dup(heff_field(v_x_24547, 1));
            v_t_24557 = v_s_24556;
            break;
          }
          default: heff_nomatch(v_x_24547);
          }
          V v_t_24558 = heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24544_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24547)}), v_t_24557});
          V v_t_24561;
          switch (heff_tag_of(v_x_24553)) {
          case TAG_At: {
            V v_s_24560 = heff_dup(heff_field(v_x_24553, 1));
            v_t_24561 = v_s_24560;
            break;
          }
          default: heff_nomatch(v_x_24553);
          }
          V v_t_24564;
          switch (heff_tag_of(v_x_24547)) {
          case TAG_At: {
            V v_s_24563 = heff_field(v_x_24547, 1);
            heff_take_n(v_x_24547, 2ULL, 2);
            v_t_24564 = v_s_24563;
            break;
          }
          default: heff_nomatch(v_x_24547);
          }
          V v_t_24565 = ({ V rv_1 = heff_get_n(v_t_24564, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24561, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24566 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24553, v_t_24558}), v_t_24565});
          V v_t_24567 = ({ V rv_1 = v_sc_24554; V rr_ = heff_rec_reuse_nf(v_st_24551, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24566}), v_t_24567});
        }
        default: return heff_nomatch(v_x11_24550);
        }
      }
      default: return heff_nomatch(v_x1_24549);
      }
    }
    default: return heff_nomatch(v_x11_24544);
    }
  }
  default: return heff_nomatch(v_x1_24543);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args) {
  V v_st_24573 = args[0];
  V v_m_24572 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24574 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_st_24573}));
  switch (heff_tag_of(v_x1_24574)) {
  case TAG_MkPair: {
    V v_x11_24575 = heff_field(v_x1_24574, 0);
    V v_st_24576 = heff_field(v_x1_24574, 1);
    V v_ru_24x1_24574_24MkPair = heff_take_reuse_n(v_x1_24574, 3ULL, 2);
    switch (heff_tag_of(v_x11_24575)) {
    case TAG_Left: {
      V v_e_24577 = heff_field(v_x11_24575, 0);
      heff_take_n(v_x11_24575, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 4);
      return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24577}), v_st_24576});
    }
    case TAG_Right: {
      V v_x_24578 = heff_field(v_x11_24575, 0);
      V v_ru_24x11_24575_24Right = heff_take_reuse_n(v_x11_24575, 1ULL, 1);
      V v_m_24579 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24580 = heff_tr(heff_call(v_m_24579, 1, (V[]){v_st_24576}));
      switch (heff_tag_of(v_x1_24580)) {
      case TAG_MkPair: {
        V v_x11_24581 = heff_field(v_x1_24580, 0);
        V v_st_24582 = heff_field(v_x1_24580, 1);
        V v_ru_24x1_24580_24MkPair = heff_take_reuse_n(v_x1_24580, 3ULL, 2);
        switch (heff_tag_of(v_x11_24581)) {
        case TAG_Left: {
          V v_e_24583 = heff_field(v_x11_24581, 0);
          heff_take_n(v_x11_24581, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 4);
          heff_drop(v_x_24578);
          heff_drop_cell(v_ru_24x11_24575_24Right, 1);
          heff_drop_cell(v_ru_24x1_24580_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24583}), v_st_24582});
        }
        case TAG_Right: {
          V v_x_24584 = heff_field(v_x11_24581, 0);
          heff_take_n(v_x11_24581, 1ULL, 1);
          V v_sc_24585 = ({ V a_0 = heff_take_field(v_st_24582, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 4); r_; });
          V v_t_24588;
          switch (heff_tag_of(v_x_24578)) {
          case TAG_At: {
            V v_s_24587 = heff_dup(heff_field(v_x_24578, 1));
            v_t_24588 = v_s_24587;
            break;
          }
          default: heff_nomatch(v_x_24578);
          }
          V v_t_24589 = heff_tag_at_n(v_ru_24x1_24580_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24575_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24578)}), v_t_24588});
          V v_t_24592;
          switch (heff_tag_of(v_x_24584)) {
          case TAG_At: {
            V v_s_24591 = heff_dup(heff_field(v_x_24584, 1));
            v_t_24592 = v_s_24591;
            break;
          }
          default: heff_nomatch(v_x_24584);
          }
          V v_t_24595;
          switch (heff_tag_of(v_x_24578)) {
          case TAG_At: {
            V v_s_24594 = heff_field(v_x_24578, 1);
            heff_take_n(v_x_24578, 2ULL, 2);
            v_t_24595 = v_s_24594;
            break;
          }
          default: heff_nomatch(v_x_24578);
          }
          V v_t_24596 = ({ V rv_1 = heff_get_n(v_t_24595, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24592, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24597 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24584, v_t_24589}), v_t_24596});
          V v_t_24598 = ({ V rv_1 = v_sc_24585; V rr_ = heff_rec_reuse_nf(v_st_24582, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24597}), v_t_24598});
        }
        default: return heff_nomatch(v_x11_24581);
        }
      }
      default: return heff_nomatch(v_x1_24580);
      }
    }
    default: return heff_nomatch(v_x11_24575);
    }
  }
  default: return heff_nomatch(v_x1_24574);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args) {
  V v_st_24603 = args[0];
  V v_m_24602 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24604 = heff_tr(heff_call(v_m_24602, 1, (V[]){v_st_24603}));
  switch (heff_tag_of(v_x1_24604)) {
  case TAG_MkPair: {
    V v_x11_24605 = heff_field(v_x1_24604, 0);
    V v_st_24606 = heff_field(v_x1_24604, 1);
    V v_ru_24x1_24604_24MkPair = heff_take_reuse_n(v_x1_24604, 3ULL, 2);
    switch (heff_tag_of(v_x11_24605)) {
    case TAG_Left: {
      V v_e_24607 = heff_field(v_x11_24605, 0);
      heff_take_n(v_x11_24605, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24607}), v_st_24606});
    }
    case TAG_Right: {
      V v_x_24608 = heff_field(v_x11_24605, 0);
      V v_ru_24x11_24605_24Right = heff_take_reuse_n(v_x11_24605, 1ULL, 1);
      V v_m_24609 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24610 = heff_tr(heff_call(v_m_24609, 1, (V[]){v_st_24606}));
      switch (heff_tag_of(v_x1_24610)) {
      case TAG_MkPair: {
        V v_x11_24611 = heff_field(v_x1_24610, 0);
        V v_st_24612 = heff_field(v_x1_24610, 1);
        V v_ru_24x1_24610_24MkPair = heff_take_reuse_n(v_x1_24610, 3ULL, 2);
        switch (heff_tag_of(v_x11_24611)) {
        case TAG_Left: {
          V v_e_24613 = heff_field(v_x11_24611, 0);
          heff_take_n(v_x11_24611, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24608);
          heff_drop_cell(v_ru_24x11_24605_24Right, 1);
          heff_drop_cell(v_ru_24x1_24610_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24613}), v_st_24612});
        }
        case TAG_Right: {
          V v_x_24614 = heff_field(v_x11_24611, 0);
          heff_take_n(v_x11_24611, 1ULL, 1);
          V v_sc_24615 = ({ V a_0 = heff_take_field(v_st_24612, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24618;
          switch (heff_tag_of(v_x_24608)) {
          case TAG_At: {
            V v_s_24617 = heff_dup(heff_field(v_x_24608, 1));
            v_t_24618 = v_s_24617;
            break;
          }
          default: heff_nomatch(v_x_24608);
          }
          V v_t_24619 = heff_tag_at_n(v_ru_24x1_24610_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24605_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24608)}), v_t_24618});
          V v_t_24622;
          switch (heff_tag_of(v_x_24614)) {
          case TAG_At: {
            V v_s_24621 = heff_dup(heff_field(v_x_24614, 1));
            v_t_24622 = v_s_24621;
            break;
          }
          default: heff_nomatch(v_x_24614);
          }
          V v_t_24625;
          switch (heff_tag_of(v_x_24608)) {
          case TAG_At: {
            V v_s_24624 = heff_field(v_x_24608, 1);
            heff_take_n(v_x_24608, 2ULL, 2);
            v_t_24625 = v_s_24624;
            break;
          }
          default: heff_nomatch(v_x_24608);
          }
          V v_t_24626 = ({ V rv_1 = heff_get_n(v_t_24625, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24622, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24627 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24614, v_t_24619}), v_t_24626});
          V v_t_24628 = ({ V rv_1 = v_sc_24615; V rr_ = heff_rec_reuse_nf(v_st_24612, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24627}), v_t_24628});
        }
        default: return heff_nomatch(v_x11_24611);
        }
      }
      default: return heff_nomatch(v_x1_24610);
      }
    }
    default: return heff_nomatch(v_x11_24605);
    }
  }
  default: return heff_nomatch(v_x1_24604);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args) {
  V v_st_24633 = args[0];
  V v_m_24632 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24634 = heff_tr(heff_call(v_m_24632, 1, (V[]){v_st_24633}));
  switch (heff_tag_of(v_x1_24634)) {
  case TAG_MkPair: {
    V v_x11_24635 = heff_field(v_x1_24634, 0);
    V v_st_24636 = heff_field(v_x1_24634, 1);
    V v_ru_24x1_24634_24MkPair = heff_take_reuse_n(v_x1_24634, 3ULL, 2);
    switch (heff_tag_of(v_x11_24635)) {
    case TAG_Left: {
      V v_e_24637 = heff_field(v_x11_24635, 0);
      heff_take_n(v_x11_24635, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24634_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24637}), v_st_24636});
    }
    case TAG_Right: {
      V v_x_24638 = heff_field(v_x11_24635, 0);
      V v_ru_24x11_24635_24Right = heff_take_reuse_n(v_x11_24635, 1ULL, 1);
      V v_m_24639 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24640 = heff_tr(heff_call(v_m_24639, 1, (V[]){v_st_24636}));
      switch (heff_tag_of(v_x1_24640)) {
      case TAG_MkPair: {
        V v_x11_24641 = heff_field(v_x1_24640, 0);
        V v_st_24642 = heff_field(v_x1_24640, 1);
        V v_ru_24x1_24640_24MkPair = heff_take_reuse_n(v_x1_24640, 3ULL, 2);
        switch (heff_tag_of(v_x11_24641)) {
        case TAG_Left: {
          V v_e_24643 = heff_field(v_x11_24641, 0);
          heff_take_n(v_x11_24641, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24638);
          heff_drop_cell(v_ru_24x11_24635_24Right, 1);
          heff_drop_cell(v_ru_24x1_24640_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24634_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24643}), v_st_24642});
        }
        case TAG_Right: {
          V v_x_24644 = heff_field(v_x11_24641, 0);
          heff_take_n(v_x11_24641, 1ULL, 1);
          V v_sc_24645 = ({ V a_0 = heff_take_field(v_st_24642, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24648;
          switch (heff_tag_of(v_x_24638)) {
          case TAG_At: {
            V v_s_24647 = heff_dup(heff_field(v_x_24638, 1));
            v_t_24648 = v_s_24647;
            break;
          }
          default: heff_nomatch(v_x_24638);
          }
          V v_t_24649 = heff_tag_at_n(v_ru_24x1_24640_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24635_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24638)}), v_t_24648});
          V v_t_24652;
          switch (heff_tag_of(v_x_24644)) {
          case TAG_At: {
            V v_s_24651 = heff_dup(heff_field(v_x_24644, 1));
            v_t_24652 = v_s_24651;
            break;
          }
          default: heff_nomatch(v_x_24644);
          }
          V v_t_24655;
          switch (heff_tag_of(v_x_24638)) {
          case TAG_At: {
            V v_s_24654 = heff_field(v_x_24638, 1);
            heff_take_n(v_x_24638, 2ULL, 2);
            v_t_24655 = v_s_24654;
            break;
          }
          default: heff_nomatch(v_x_24638);
          }
          V v_t_24656 = ({ V rv_1 = heff_get_n(v_t_24655, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24652, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24657 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24644, v_t_24649}), v_t_24656});
          V v_t_24658 = ({ V rv_1 = v_sc_24645; V rr_ = heff_rec_reuse_nf(v_st_24642, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24634_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24657}), v_t_24658});
        }
        default: return heff_nomatch(v_x11_24641);
        }
      }
      default: return heff_nomatch(v_x1_24640);
      }
    }
    default: return heff_nomatch(v_x11_24635);
    }
  }
  default: return heff_nomatch(v_x1_24634);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args) {
  V v_st_24663 = args[0];
  V v_m_24662 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24664 = heff_tr(heff_call(v_m_24662, 1, (V[]){v_st_24663}));
  switch (heff_tag_of(v_x1_24664)) {
  case TAG_MkPair: {
    V v_x11_24665 = heff_field(v_x1_24664, 0);
    V v_st_24666 = heff_field(v_x1_24664, 1);
    V v_ru_24x1_24664_24MkPair = heff_take_reuse_n(v_x1_24664, 3ULL, 2);
    switch (heff_tag_of(v_x11_24665)) {
    case TAG_Left: {
      V v_e_24667 = heff_field(v_x11_24665, 0);
      heff_take_n(v_x11_24665, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24664_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24667}), v_st_24666});
    }
    case TAG_Right: {
      V v_x_24668 = heff_field(v_x11_24665, 0);
      V v_ru_24x11_24665_24Right = heff_take_reuse_n(v_x11_24665, 1ULL, 1);
      V v_m_24669 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24670 = heff_tr(heff_call(v_m_24669, 1, (V[]){v_st_24666}));
      switch (heff_tag_of(v_x1_24670)) {
      case TAG_MkPair: {
        V v_x11_24671 = heff_field(v_x1_24670, 0);
        V v_st_24672 = heff_field(v_x1_24670, 1);
        V v_ru_24x1_24670_24MkPair = heff_take_reuse_n(v_x1_24670, 3ULL, 2);
        switch (heff_tag_of(v_x11_24671)) {
        case TAG_Left: {
          V v_e_24673 = heff_field(v_x11_24671, 0);
          heff_take_n(v_x11_24671, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24668);
          heff_drop_cell(v_ru_24x11_24665_24Right, 1);
          heff_drop_cell(v_ru_24x1_24670_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24664_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24673}), v_st_24672});
        }
        case TAG_Right: {
          V v_x_24674 = heff_field(v_x11_24671, 0);
          heff_take_n(v_x11_24671, 1ULL, 1);
          V v_sc_24675 = ({ V a_0 = heff_take_field(v_st_24672, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24678;
          switch (heff_tag_of(v_x_24668)) {
          case TAG_At: {
            V v_s_24677 = heff_dup(heff_field(v_x_24668, 1));
            v_t_24678 = v_s_24677;
            break;
          }
          default: heff_nomatch(v_x_24668);
          }
          V v_t_24679 = heff_tag_at_n(v_ru_24x1_24670_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24665_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24668)}), v_t_24678});
          V v_t_24682;
          switch (heff_tag_of(v_x_24674)) {
          case TAG_At: {
            V v_s_24681 = heff_dup(heff_field(v_x_24674, 1));
            v_t_24682 = v_s_24681;
            break;
          }
          default: heff_nomatch(v_x_24674);
          }
          V v_t_24685;
          switch (heff_tag_of(v_x_24668)) {
          case TAG_At: {
            V v_s_24684 = heff_field(v_x_24668, 1);
            heff_take_n(v_x_24668, 2ULL, 2);
            v_t_24685 = v_s_24684;
            break;
          }
          default: heff_nomatch(v_x_24668);
          }
          V v_t_24686 = ({ V rv_1 = heff_get_n(v_t_24685, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24682, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24687 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24674, v_t_24679}), v_t_24686});
          V v_t_24688 = ({ V rv_1 = v_sc_24675; V rr_ = heff_rec_reuse_nf(v_st_24672, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24664_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24687}), v_t_24688});
        }
        default: return heff_nomatch(v_x11_24671);
        }
      }
      default: return heff_nomatch(v_x1_24670);
      }
    }
    default: return heff_nomatch(v_x11_24665);
    }
  }
  default: return heff_nomatch(v_x1_24664);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args) {
  V v_st_24702 = args[0];
  V v_m_24701 = heff_env(self)[0];
  V v_p_24696 = heff_env(self)[1];
  V v_e_24699 = heff_env(self)[2];
  V v_kw_24695 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24703 = heff_tr(heff_call(v_m_24701, 1, (V[]){v_st_24702}));
  switch (heff_tag_of(v_x1_24703)) {
  case TAG_MkPair: {
    V v_x11_24704 = heff_field(v_x1_24703, 0);
    V v_st_24705 = heff_field(v_x1_24703, 1);
    V v_ru_24x1_24703_24MkPair = heff_take_reuse_n(v_x1_24703, 3ULL, 2);
    switch (heff_tag_of(v_x11_24704)) {
    case TAG_Left: {
      V v_e_24706 = heff_field(v_x11_24704, 0);
      heff_take_n(v_x11_24704, 1ULL, 1);
      heff_drop(v_p_24696);
      heff_drop(v_e_24699);
      heff_drop_rec(v_kw_24695, 9);
      return heff_tag_at_n(v_ru_24x1_24703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24706}), v_st_24705});
    }
    case TAG_Right: {
      V v_x_24707 = heff_field(v_x11_24704, 0);
      heff_take_n(v_x11_24704, 1ULL, 1);
      V v_sc_24708 = ({ V a_0 = heff_take_field(v_st_24705, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24696; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24696); r_; });
      V v_t_24711;
      switch (heff_tag_of(v_x_24707)) {
      case TAG_MkPair: {
        V v_x_24709 = heff_dup(heff_field(v_x_24707, 0));
        v_t_24711 = v_x_24709;
        break;
      }
      default: heff_nomatch(v_x_24707);
      }
      V v_t_24714;
      switch (heff_tag_of(v_x_24707)) {
      case TAG_MkPair: {
        V v_y_24713 = heff_field(v_x_24707, 1);
        heff_take_n(v_x_24707, 2ULL, 2);
        v_t_24714 = v_y_24713;
        break;
      }
      default: heff_nomatch(v_x_24707);
      }
      V v_t_24715 = (g_heff_2esyntax_2ecst_2elastE(v_e_24699));
      V v_e_24716 = heff_get_n(v_t_24715, 4, 9);
      V v_t_24717 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24695, 3, 9), v_e_24716});
      V v_x_24718 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_t_24711, v_t_24714}), v_t_24717});
      V v_t_24719 = ({ V rv_1 = v_sc_24708; V rr_ = heff_rec_reuse_nf(v_st_24705, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24718}), v_t_24719});
    }
    default: return heff_nomatch(v_x11_24704);
    }
  }
  default: return heff_nomatch(v_x1_24703);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args) {
  V v_st_24722 = args[0];
  V v_m_24721 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24723 = heff_tr(heff_call(v_m_24721, 1, (V[]){v_st_24722}));
  switch (heff_tag_of(v_x1_24723)) {
  case TAG_MkPair: {
    V v_x11_24724 = heff_field(v_x1_24723, 0);
    V v_st_24725 = heff_field(v_x1_24723, 1);
    V v_ru_24x1_24723_24MkPair = heff_take_reuse_n(v_x1_24723, 3ULL, 2);
    switch (heff_tag_of(v_x11_24724)) {
    case TAG_Left: {
      V v_e_24726 = heff_field(v_x11_24724, 0);
      heff_take_n(v_x11_24724, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24723_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24726}), v_st_24725});
    }
    case TAG_Right: {
      V v_x_24727 = heff_field(v_x11_24724, 0);
      V v_ru_24x11_24724_24Right = heff_take_reuse_n(v_x11_24724, 1ULL, 1);
      V v_t_24730;
      switch (heff_tag_of(v_x_24727)) {
      case TAG_At: {
        V v_s_24729 = heff_dup(heff_field(v_x_24727, 1));
        v_t_24730 = v_s_24729;
        break;
      }
      default: heff_nomatch(v_x_24727);
      }
      V v_t_24731 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24724_24Right, TAG_StmtExpr, 1, (V[]){v_x_24727}), v_t_24730});
      return heff_tag_at_n(v_ru_24x1_24723_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24731}), v_st_24725});
    }
    default: return heff_nomatch(v_x11_24724);
    }
  }
  default: return heff_nomatch(v_x1_24723);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args) {
  V v_m_24746 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24746));
}
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args) {
  V v_st_24740 = args[0];
  V v_m_24739 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_ss_24738 = heff_env(self)[2];
  V v_p_24733 = heff_env(self)[3];
  V v_x2_241 = heff_env(self)[4];
  V v_kw_24732 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_24741 = heff_tr(heff_call(v_m_24739, 1, (V[]){v_st_24740}));
  switch (heff_tag_of(v_x1_24741)) {
  case TAG_MkPair: {
    V v_x11_24742 = heff_field(v_x1_24741, 0);
    V v_st_24743 = heff_field(v_x1_24741, 1);
    V v_ru_24x1_24741_24MkPair = heff_take_reuse_n(v_x1_24741, 3ULL, 2);
    switch (heff_tag_of(v_x11_24742)) {
    case TAG_Left: {
      V v_e_24744 = heff_field(v_x11_24742, 0);
      heff_take_n(v_x11_24742, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_ss_24738);
      heff_drop(v_p_24733);
      heff_drop_tag(v_x2_241, 7);
      heff_drop_rec(v_kw_24732, 9);
      return heff_tag_at_n(v_ru_24x1_24741_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24744}), v_st_24743});
    }
    case TAG_Right: {
      V v_x_24745 = heff_field(v_x11_24742, 0);
      heff_take_n(v_x11_24742, 1ULL, 1);
      HeffT2 v_t_24747 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam42, 1, 1, (V[]){v_r_240}), v_ss_24738, v_st_24743));
      {
        V v_field_24748 = v_t_24747.f[0];
        V v_field_24749 = v_t_24747.f[1];
        V v_x11_24750 = v_field_24748;
        V v_st_24751 = v_field_24749;
        switch (heff_tag_of(v_x11_24750)) {
        case TAG_Left: {
          V v_e_24752 = heff_field(v_x11_24750, 0);
          heff_take_n(v_x11_24750, 1ULL, 1);
          heff_drop(v_p_24733);
          heff_drop_tag(v_x2_241, 7);
          heff_drop_rec(v_kw_24732, 9);
          heff_drop(v_x_24745);
          return heff_tag_at_n(v_ru_24x1_24741_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24752}), v_st_24751});
        }
        case TAG_Right: {
          V v_x_24753 = heff_field(v_x11_24750, 0);
          heff_take_n(v_x11_24750, 1ULL, 1);
          V v_sc_24754 = ({ V a_0 = heff_take_field(v_st_24751, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24733; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24733); r_; });
          V v_t_24757;
          switch (heff_tag_of(v_x_24745)) {
          case TAG_MkPair: {
            V v_x_24755 = heff_dup(heff_field(v_x_24745, 0));
            v_t_24757 = v_x_24755;
            break;
          }
          default: heff_nomatch(v_x_24745);
          }
          V v_t_24760;
          switch (heff_tag_of(v_x_24745)) {
          case TAG_MkPair: {
            V v_y_24759 = heff_field(v_x_24745, 1);
            heff_take_n(v_x_24745, 2ULL, 2);
            v_t_24760 = v_y_24759;
            break;
          }
          default: heff_nomatch(v_x_24745);
          }
          V v_t_24761 = (g_heff_2esyntax_2ecst_2elastE(v_x2_241));
          V v_e_24762 = heff_get_n(v_t_24761, 4, 9);
          V v_t_24763 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24732, 3, 9), v_e_24762});
          V v_x_24764 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_t_24757, v_t_24760, v_x_24753}), v_t_24763});
          V v_t_24765 = ({ V rv_1 = v_sc_24754; V rr_ = heff_rec_reuse_nf(v_st_24751, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24741_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24764}), v_t_24765});
        }
        default: return heff_nomatch(v_x11_24750);
        }
      }
    }
    default: return heff_nomatch(v_x11_24742);
    }
  }
  default: return heff_nomatch(v_x1_24741);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam43(V self, V *args) {
  V v_st_24773 = args[0];
  V v_m_24772 = heff_env(self)[0];
  V v_x_24768 = heff_env(self)[1];
  V v_e_24771 = heff_env(self)[2];
  V v_kw_24766 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24774 = heff_tr(heff_call(v_m_24772, 1, (V[]){v_st_24773}));
  switch (heff_tag_of(v_x1_24774)) {
  case TAG_MkPair: {
    V v_x11_24775 = heff_field(v_x1_24774, 0);
    V v_st_24776 = heff_field(v_x1_24774, 1);
    V v_ru_24x1_24774_24MkPair = heff_take_reuse_n(v_x1_24774, 3ULL, 2);
    switch (heff_tag_of(v_x11_24775)) {
    case TAG_Left: {
      V v_e_24777 = heff_field(v_x11_24775, 0);
      heff_take_n(v_x11_24775, 1ULL, 1);
      heff_drop_rec(v_x_24768, 9);
      heff_drop(v_e_24771);
      heff_drop_rec(v_kw_24766, 9);
      return heff_tag_at_n(v_ru_24x1_24774_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24777}), v_st_24776});
    }
    case TAG_Right: {
      V v_x_24778 = heff_field(v_x11_24775, 0);
      heff_take_n(v_x11_24775, 1ULL, 1);
      V v_t_24779 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24768, 3), heff_take_field(v_x_24768, 4)});
      V v_t_24782;
      switch (heff_tag_of(v_x_24778)) {
      case TAG_MkPair: {
        V v_y_24781 = heff_field(v_x_24778, 1);
        heff_take_n(v_x_24778, 2ULL, 2);
        v_t_24782 = v_y_24781;
        break;
      }
      default: heff_nomatch(v_x_24778);
      }
      V v_t_24783 = heff_tag_n(TAG_StmtLetMut, 3, (V[]){heff_dup(heff_rfield(v_x_24768, 1)), v_t_24779, v_t_24782});
      V v_t_24784 = (g_heff_2esyntax_2ecst_2elastE(v_e_24771));
      V v_e_24785 = heff_get_n(v_t_24784, 4, 9);
      V v_t_24786 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24766, 3, 9), v_e_24785});
      V v_x_24787 = heff_tag_n(TAG_At, 2, (V[]){v_t_24783, v_t_24786});
      V v_t_24788 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24768, 1, 9), heff_take_field(v_st_24776, 1)});
      V v_t_24789 = ({ V rv_1 = v_t_24788; V rr_ = heff_rec_reuse_nf(v_st_24776, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24774_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24787}), v_t_24789});
    }
    default: return heff_nomatch(v_x11_24775);
    }
  }
  default: return heff_nomatch(v_x1_24774);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam44(V self, V *args) {
  V v_st_24794 = args[0];
  V v_m_24793 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24795 = heff_tr(heff_call(v_m_24793, 1, (V[]){v_st_24794}));
  switch (heff_tag_of(v_x1_24795)) {
  case TAG_MkPair: {
    V v_x11_24796 = heff_field(v_x1_24795, 0);
    V v_st_24797 = heff_field(v_x1_24795, 1);
    V v_ru_24x1_24795_24MkPair = heff_take_reuse_n(v_x1_24795, 3ULL, 2);
    switch (heff_tag_of(v_x11_24796)) {
    case TAG_Left: {
      V v_e_24798 = heff_field(v_x11_24796, 0);
      heff_take_n(v_x11_24796, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24795_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24798}), v_st_24797});
    }
    case TAG_Right: {
      V v_x_24799 = heff_field(v_x11_24796, 0);
      V v_ru_24x11_24796_24Right = heff_take_reuse_n(v_x11_24796, 1ULL, 1);
      V v_t_24802;
      switch (heff_tag_of(v_x_24799)) {
      case TAG_At: {
        V v_s_24801 = heff_dup(heff_field(v_x_24799, 1));
        v_t_24802 = v_s_24801;
        break;
      }
      default: heff_nomatch(v_x_24799);
      }
      V v_t_24803 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24796_24Right, TAG_StmtExpr, 1, (V[]){v_x_24799}), v_t_24802});
      return heff_tag_at_n(v_ru_24x1_24795_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24803}), v_st_24797});
    }
    default: return heff_nomatch(v_x11_24796);
    }
  }
  default: return heff_nomatch(v_x1_24795);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam45(V self, V *args) {
  V v_st_24809 = args[0];
  V v_m_24808 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24810 = heff_tr(heff_call(v_m_24808, 1, (V[]){v_st_24809}));
  switch (heff_tag_of(v_x1_24810)) {
  case TAG_MkPair: {
    V v_x11_24811 = heff_field(v_x1_24810, 0);
    V v_st_24812 = heff_field(v_x1_24810, 1);
    V v_ru_24x1_24810_24MkPair = heff_take_reuse_n(v_x1_24810, 3ULL, 2);
    switch (heff_tag_of(v_x11_24811)) {
    case TAG_Left: {
      V v_e_24813 = heff_field(v_x11_24811, 0);
      heff_take_n(v_x11_24811, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24810_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24813}), v_st_24812});
    }
    case TAG_Right: {
      V v_x_24814 = heff_field(v_x11_24811, 0);
      V v_ru_24x11_24811_24Right = heff_take_reuse_n(v_x11_24811, 1ULL, 1);
      V v_t_24817;
      switch (heff_tag_of(v_x_24814)) {
      case TAG_At: {
        V v_s_24816 = heff_dup(heff_field(v_x_24814, 1));
        v_t_24817 = v_s_24816;
        break;
      }
      default: heff_nomatch(v_x_24814);
      }
      V v_t_24818 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24811_24Right, TAG_StmtExpr, 1, (V[]){v_x_24814}), v_t_24817});
      return heff_tag_at_n(v_ru_24x1_24810_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24818}), v_st_24812});
    }
    default: return heff_nomatch(v_x11_24811);
    }
  }
  default: return heff_nomatch(v_x1_24810);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam46(V self, V *args) {
  V v_st_24826 = args[0];
  V v_m_24825 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24827 = heff_tr(heff_call(v_m_24825, 1, (V[]){v_st_24826}));
  switch (heff_tag_of(v_x1_24827)) {
  case TAG_MkPair: {
    V v_x11_24828 = heff_field(v_x1_24827, 0);
    V v_st_24829 = heff_field(v_x1_24827, 1);
    V v_ru_24x1_24827_24MkPair = heff_take_reuse_n(v_x1_24827, 3ULL, 2);
    switch (heff_tag_of(v_x11_24828)) {
    case TAG_Left: {
      V v_e_24830 = heff_field(v_x11_24828, 0);
      heff_take_n(v_x11_24828, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24830}), v_st_24829});
    }
    case TAG_Right: {
      V v_x_24831 = heff_field(v_x11_24828, 0);
      V v_ru_24x11_24828_24Right = heff_take_reuse_n(v_x11_24828, 1ULL, 1);
      V v_t_24834;
      switch (heff_tag_of(v_x_24831)) {
      case TAG_At: {
        V v_s_24833 = heff_dup(heff_field(v_x_24831, 1));
        v_t_24834 = v_s_24833;
        break;
      }
      default: heff_nomatch(v_x_24831);
      }
      V v_t_24835 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24828_24Right, TAG_StmtExpr, 1, (V[]){v_x_24831}), v_t_24834});
      return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24835}), v_st_24829});
    }
    default: return heff_nomatch(v_x11_24828);
    }
  }
  default: return heff_nomatch(v_x1_24827);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam47(V self, V *args) {
  V v_st_24838 = args[0];
  V v_m_24837 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24839 = heff_tr(heff_call(v_m_24837, 1, (V[]){v_st_24838}));
  switch (heff_tag_of(v_x1_24839)) {
  case TAG_MkPair: {
    V v_x11_24840 = heff_field(v_x1_24839, 0);
    V v_st_24841 = heff_field(v_x1_24839, 1);
    V v_ru_24x1_24839_24MkPair = heff_take_reuse_n(v_x1_24839, 3ULL, 2);
    switch (heff_tag_of(v_x11_24840)) {
    case TAG_Left: {
      V v_e_24842 = heff_field(v_x11_24840, 0);
      heff_take_n(v_x11_24840, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24839_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24842}), v_st_24841});
    }
    case TAG_Right: {
      V v_x_24843 = heff_field(v_x11_24840, 0);
      V v_ru_24x11_24840_24Right = heff_take_reuse_n(v_x11_24840, 1ULL, 1);
      V v_t_24846;
      switch (heff_tag_of(v_x_24843)) {
      case TAG_At: {
        V v_s_24845 = heff_dup(heff_field(v_x_24843, 1));
        v_t_24846 = v_s_24845;
        break;
      }
      default: heff_nomatch(v_x_24843);
      }
      V v_t_24847 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24840_24Right, TAG_StmtExpr, 1, (V[]){v_x_24843}), v_t_24846});
      return heff_tag_at_n(v_ru_24x1_24839_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24847}), v_st_24841});
    }
    default: return heff_nomatch(v_x11_24840);
    }
  }
  default: return heff_nomatch(v_x1_24839);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam48(V self, V *args) {
  V v_st_24851 = args[0];
  V v_m_24850 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24852 = heff_tr(heff_call(v_m_24850, 1, (V[]){v_st_24851}));
  switch (heff_tag_of(v_x1_24852)) {
  case TAG_MkPair: {
    V v_x11_24853 = heff_field(v_x1_24852, 0);
    V v_st_24854 = heff_field(v_x1_24852, 1);
    V v_ru_24x1_24852_24MkPair = heff_take_reuse_n(v_x1_24852, 3ULL, 2);
    switch (heff_tag_of(v_x11_24853)) {
    case TAG_Left: {
      V v_e_24855 = heff_field(v_x11_24853, 0);
      heff_take_n(v_x11_24853, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24852_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24855}), v_st_24854});
    }
    case TAG_Right: {
      V v_x_24856 = heff_field(v_x11_24853, 0);
      V v_ru_24x11_24853_24Right = heff_take_reuse_n(v_x11_24853, 1ULL, 1);
      V v_t_24859;
      switch (heff_tag_of(v_x_24856)) {
      case TAG_At: {
        V v_s_24858 = heff_dup(heff_field(v_x_24856, 1));
        v_t_24859 = v_s_24858;
        break;
      }
      default: heff_nomatch(v_x_24856);
      }
      V v_t_24860 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24853_24Right, TAG_StmtExpr, 1, (V[]){v_x_24856}), v_t_24859});
      return heff_tag_at_n(v_ru_24x1_24852_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24860}), v_st_24854});
    }
    default: return heff_nomatch(v_x11_24853);
    }
  }
  default: return heff_nomatch(v_x1_24852);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam49(V self, V *args) {
  V v_st_24866 = args[0];
  V v_m_24865 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24867 = heff_tr(heff_call(v_m_24865, 1, (V[]){v_st_24866}));
  switch (heff_tag_of(v_x1_24867)) {
  case TAG_MkPair: {
    V v_x11_24868 = heff_field(v_x1_24867, 0);
    V v_st_24869 = heff_field(v_x1_24867, 1);
    V v_ru_24x1_24867_24MkPair = heff_take_reuse_n(v_x1_24867, 3ULL, 2);
    switch (heff_tag_of(v_x11_24868)) {
    case TAG_Left: {
      V v_e_24870 = heff_field(v_x11_24868, 0);
      heff_take_n(v_x11_24868, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24867_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24870}), v_st_24869});
    }
    case TAG_Right: {
      V v_x_24871 = heff_field(v_x11_24868, 0);
      V v_ru_24x11_24868_24Right = heff_take_reuse_n(v_x11_24868, 1ULL, 1);
      V v_t_24874;
      switch (heff_tag_of(v_x_24871)) {
      case TAG_At: {
        V v_s_24873 = heff_dup(heff_field(v_x_24871, 1));
        v_t_24874 = v_s_24873;
        break;
      }
      default: heff_nomatch(v_x_24871);
      }
      V v_t_24875 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24868_24Right, TAG_StmtExpr, 1, (V[]){v_x_24871}), v_t_24874});
      return heff_tag_at_n(v_ru_24x1_24867_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24875}), v_st_24869});
    }
    default: return heff_nomatch(v_x11_24868);
    }
  }
  default: return heff_nomatch(v_x1_24867);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam50(V self, V *args) {
  V v_st_24879 = args[0];
  V v_m_24878 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24880 = heff_tr(heff_call(v_m_24878, 1, (V[]){v_st_24879}));
  switch (heff_tag_of(v_x1_24880)) {
  case TAG_MkPair: {
    V v_x11_24881 = heff_field(v_x1_24880, 0);
    V v_st_24882 = heff_field(v_x1_24880, 1);
    V v_ru_24x1_24880_24MkPair = heff_take_reuse_n(v_x1_24880, 3ULL, 2);
    switch (heff_tag_of(v_x11_24881)) {
    case TAG_Left: {
      V v_e_24883 = heff_field(v_x11_24881, 0);
      heff_take_n(v_x11_24881, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24883}), v_st_24882});
    }
    case TAG_Right: {
      V v_x_24884 = heff_field(v_x11_24881, 0);
      V v_ru_24x11_24881_24Right = heff_take_reuse_n(v_x11_24881, 1ULL, 1);
      V v_t_24887;
      switch (heff_tag_of(v_x_24884)) {
      case TAG_At: {
        V v_s_24886 = heff_dup(heff_field(v_x_24884, 1));
        v_t_24887 = v_s_24886;
        break;
      }
      default: heff_nomatch(v_x_24884);
      }
      V v_t_24888 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24881_24Right, TAG_StmtExpr, 1, (V[]){v_x_24884}), v_t_24887});
      return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24888}), v_st_24882});
    }
    default: return heff_nomatch(v_x11_24881);
    }
  }
  default: return heff_nomatch(v_x1_24880);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam51(V self, V *args) {
  V v_st_24894 = args[0];
  V v_m_24893 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24895 = heff_tr(heff_call(v_m_24893, 1, (V[]){v_st_24894}));
  switch (heff_tag_of(v_x1_24895)) {
  case TAG_MkPair: {
    V v_x11_24896 = heff_field(v_x1_24895, 0);
    V v_st_24897 = heff_field(v_x1_24895, 1);
    V v_ru_24x1_24895_24MkPair = heff_take_reuse_n(v_x1_24895, 3ULL, 2);
    switch (heff_tag_of(v_x11_24896)) {
    case TAG_Left: {
      V v_e_24898 = heff_field(v_x11_24896, 0);
      heff_take_n(v_x11_24896, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24895_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24898}), v_st_24897});
    }
    case TAG_Right: {
      V v_x_24899 = heff_field(v_x11_24896, 0);
      V v_ru_24x11_24896_24Right = heff_take_reuse_n(v_x11_24896, 1ULL, 1);
      V v_t_24902;
      switch (heff_tag_of(v_x_24899)) {
      case TAG_At: {
        V v_s_24901 = heff_dup(heff_field(v_x_24899, 1));
        v_t_24902 = v_s_24901;
        break;
      }
      default: heff_nomatch(v_x_24899);
      }
      V v_t_24903 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24896_24Right, TAG_StmtExpr, 1, (V[]){v_x_24899}), v_t_24902});
      return heff_tag_at_n(v_ru_24x1_24895_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24903}), v_st_24897});
    }
    default: return heff_nomatch(v_x11_24896);
    }
  }
  default: return heff_nomatch(v_x1_24895);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam52(V self, V *args) {
  V v_st_24909 = args[0];
  V v_m_24908 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24910 = heff_tr(heff_call(v_m_24908, 1, (V[]){v_st_24909}));
  switch (heff_tag_of(v_x1_24910)) {
  case TAG_MkPair: {
    V v_x11_24911 = heff_field(v_x1_24910, 0);
    V v_st_24912 = heff_field(v_x1_24910, 1);
    V v_ru_24x1_24910_24MkPair = heff_take_reuse_n(v_x1_24910, 3ULL, 2);
    switch (heff_tag_of(v_x11_24911)) {
    case TAG_Left: {
      V v_e_24913 = heff_field(v_x11_24911, 0);
      heff_take_n(v_x11_24911, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24910_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24913}), v_st_24912});
    }
    case TAG_Right: {
      V v_x_24914 = heff_field(v_x11_24911, 0);
      V v_ru_24x11_24911_24Right = heff_take_reuse_n(v_x11_24911, 1ULL, 1);
      V v_t_24917;
      switch (heff_tag_of(v_x_24914)) {
      case TAG_At: {
        V v_s_24916 = heff_dup(heff_field(v_x_24914, 1));
        v_t_24917 = v_s_24916;
        break;
      }
      default: heff_nomatch(v_x_24914);
      }
      V v_t_24918 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24911_24Right, TAG_StmtExpr, 1, (V[]){v_x_24914}), v_t_24917});
      return heff_tag_at_n(v_ru_24x1_24910_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24918}), v_st_24912});
    }
    default: return heff_nomatch(v_x11_24911);
    }
  }
  default: return heff_nomatch(v_x1_24910);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam53(V self, V *args) {
  V v_st_24924 = args[0];
  V v_m_24923 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24925 = heff_tr(heff_call(v_m_24923, 1, (V[]){v_st_24924}));
  switch (heff_tag_of(v_x1_24925)) {
  case TAG_MkPair: {
    V v_x11_24926 = heff_field(v_x1_24925, 0);
    V v_st_24927 = heff_field(v_x1_24925, 1);
    V v_ru_24x1_24925_24MkPair = heff_take_reuse_n(v_x1_24925, 3ULL, 2);
    switch (heff_tag_of(v_x11_24926)) {
    case TAG_Left: {
      V v_e_24928 = heff_field(v_x11_24926, 0);
      heff_take_n(v_x11_24926, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24925_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24928}), v_st_24927});
    }
    case TAG_Right: {
      V v_x_24929 = heff_field(v_x11_24926, 0);
      V v_ru_24x11_24926_24Right = heff_take_reuse_n(v_x11_24926, 1ULL, 1);
      V v_t_24932;
      switch (heff_tag_of(v_x_24929)) {
      case TAG_At: {
        V v_s_24931 = heff_dup(heff_field(v_x_24929, 1));
        v_t_24932 = v_s_24931;
        break;
      }
      default: heff_nomatch(v_x_24929);
      }
      V v_t_24933 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24926_24Right, TAG_StmtExpr, 1, (V[]){v_x_24929}), v_t_24932});
      return heff_tag_at_n(v_ru_24x1_24925_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24933}), v_st_24927});
    }
    default: return heff_nomatch(v_x11_24926);
    }
  }
  default: return heff_nomatch(v_x1_24925);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam54(V self, V *args) {
  V v_st_24941 = args[0];
  V v_m_24940 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24942 = heff_tr(heff_call(v_m_24940, 1, (V[]){v_st_24941}));
  switch (heff_tag_of(v_x1_24942)) {
  case TAG_MkPair: {
    V v_x11_24943 = heff_field(v_x1_24942, 0);
    V v_st_24944 = heff_field(v_x1_24942, 1);
    V v_ru_24x1_24942_24MkPair = heff_take_reuse_n(v_x1_24942, 3ULL, 2);
    switch (heff_tag_of(v_x11_24943)) {
    case TAG_Left: {
      V v_e_24945 = heff_field(v_x11_24943, 0);
      heff_take_n(v_x11_24943, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24942_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24945}), v_st_24944});
    }
    case TAG_Right: {
      V v_x_24946 = heff_field(v_x11_24943, 0);
      V v_ru_24x11_24943_24Right = heff_take_reuse_n(v_x11_24943, 1ULL, 1);
      V v_t_24949;
      switch (heff_tag_of(v_x_24946)) {
      case TAG_At: {
        V v_s_24948 = heff_dup(heff_field(v_x_24946, 1));
        v_t_24949 = v_s_24948;
        break;
      }
      default: heff_nomatch(v_x_24946);
      }
      V v_t_24950 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24943_24Right, TAG_StmtExpr, 1, (V[]){v_x_24946}), v_t_24949});
      return heff_tag_at_n(v_ru_24x1_24942_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24950}), v_st_24944});
    }
    default: return heff_nomatch(v_x11_24943);
    }
  }
  default: return heff_nomatch(v_x1_24942);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str81, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str82, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str83, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str84, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str85, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str87, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecatchL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatchL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatchL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop(v_r_240);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_244 = heff_take_field(v_t_243, 3);
    V v_end_245 = heff_get_n(v_t_243, 4, 9);
    V v_t_246 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_247 = heff_strAppend(heff_get_n(v_t_246, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str0));
    V v_msg_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str1), v_t_247);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam0, 1, 3, (V[]){v_msg_248, v_start_244, v_end_245});
  }
  case TAG_EParen: {
    heff_drop(v_r_240);
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2415 = heff_take_field(v_t_2414, 3);
    V v_end_2416 = heff_get_n(v_t_2414, 4, 9);
    V v_t_2417 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2418 = heff_strAppend(heff_get_n(v_t_2417, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str2));
    V v_msg_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str3), v_t_2418);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam1, 1, 3, (V[]){v_msg_2419, v_start_2415, v_end_2416});
  }
  case TAG_Named: {
    heff_drop(v_r_240);
    V v_t_2427 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2428 = heff_take_field(v_t_2427, 3);
    V v_end_2429 = heff_get_n(v_t_2427, 4, 9);
    V v_t_2430 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2431 = heff_strAppend(heff_get_n(v_t_2430, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str4));
    V v_msg_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str5), v_t_2431);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam2, 1, 3, (V[]){v_msg_2432, v_start_2428, v_end_2429});
  }
  case TAG_Tup: {
    heff_drop(v_r_240);
    V v_t_2439 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2440 = heff_take_field(v_t_2439, 3);
    V v_end_2441 = heff_get_n(v_t_2439, 4, 9);
    V v_t_2442 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2443 = heff_strAppend(heff_get_n(v_t_2442, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str6));
    V v_msg_2444 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str7), v_t_2443);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam3, 1, 3, (V[]){v_msg_2444, v_start_2440, v_end_2441});
  }
  case TAG_Seg: {
    heff_drop(v_r_240);
    V v_t_2450 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2451 = heff_take_field(v_t_2450, 3);
    V v_end_2452 = heff_get_n(v_t_2450, 4, 9);
    V v_t_2453 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2454 = heff_strAppend(heff_get_n(v_t_2453, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str8));
    V v_msg_2455 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str9), v_t_2454);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam4, 1, 3, (V[]){v_msg_2455, v_start_2451, v_end_2452});
  }
  case TAG_Braces: {
    heff_drop(v_r_240);
    V v_t_2462 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2463 = heff_take_field(v_t_2462, 3);
    V v_end_2464 = heff_get_n(v_t_2462, 4, 9);
    V v_t_2465 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2466 = heff_strAppend(heff_get_n(v_t_2465, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str10));
    V v_msg_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str11), v_t_2466);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam5, 1, 3, (V[]){v_msg_2467, v_start_2463, v_end_2464});
  }
  case TAG_Update: {
    heff_drop(v_r_240);
    V v_t_2476 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2477 = heff_take_field(v_t_2476, 3);
    V v_end_2478 = heff_get_n(v_t_2476, 4, 9);
    V v_t_2479 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2480 = heff_strAppend(heff_get_n(v_t_2479, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str12));
    V v_msg_2481 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str13), v_t_2480);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam6, 1, 3, (V[]){v_msg_2481, v_start_2477, v_end_2478});
  }
  case TAG_EUSet: {
    heff_drop(v_r_240);
    V v_t_2487 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2488 = heff_take_field(v_t_2487, 3);
    V v_end_2489 = heff_get_n(v_t_2487, 4, 9);
    V v_t_2490 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2491 = heff_strAppend(heff_get_n(v_t_2490, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str14));
    V v_msg_2492 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str15), v_t_2491);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam7, 1, 3, (V[]){v_msg_2492, v_start_2488, v_end_2489});
  }
  case TAG_InstB: {
    heff_drop(v_r_240);
    V v_t_24100 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24101 = heff_take_field(v_t_24100, 3);
    V v_end_24102 = heff_get_n(v_t_24100, 4, 9);
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str16));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str17), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam8, 1, 3, (V[]){v_msg_24105, v_start_24101, v_end_24102});
  }
  case TAG_EFSet: {
    heff_drop(v_r_240);
    V v_t_24111 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24112 = heff_take_field(v_t_24111, 3);
    V v_end_24113 = heff_get_n(v_t_24111, 4, 9);
    V v_t_24114 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24115 = heff_strAppend(heff_get_n(v_t_24114, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str18));
    V v_msg_24116 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str19), v_t_24115);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam9, 1, 3, (V[]){v_msg_24116, v_start_24112, v_end_24113});
  }
  case TAG_EFDefault: {
    heff_drop(v_r_240);
    V v_t_24122 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24123 = heff_take_field(v_t_24122, 3);
    V v_end_24124 = heff_get_n(v_t_24122, 4, 9);
    V v_t_24125 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str20));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str21), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam10, 1, 3, (V[]){v_msg_24127, v_start_24123, v_end_24124});
  }
  case TAG_Sum: {
    heff_drop(v_r_240);
    V v_t_24135 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24136 = heff_take_field(v_t_24135, 3);
    V v_end_24137 = heff_get_n(v_t_24135, 4, 9);
    V v_t_24138 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24139 = heff_strAppend(heff_get_n(v_t_24138, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str22));
    V v_msg_24140 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str23), v_t_24139);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam11, 1, 3, (V[]){v_msg_24140, v_start_24136, v_end_24137});
  }
  case TAG_ECon: {
    heff_drop(v_r_240);
    V v_t_24145 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24146 = heff_take_field(v_t_24145, 3);
    V v_end_24147 = heff_get_n(v_t_24145, 4, 9);
    V v_t_24148 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24149 = heff_strAppend(heff_get_n(v_t_24148, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str24));
    V v_msg_24150 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str25), v_t_24149);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam12, 1, 3, (V[]){v_msg_24150, v_start_24146, v_end_24147});
  }
  case TAG_EField: {
    heff_drop(v_r_240);
    V v_t_24155 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24156 = heff_take_field(v_t_24155, 3);
    V v_end_24157 = heff_get_n(v_t_24155, 4, 9);
    V v_t_24158 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24159 = heff_strAppend(heff_get_n(v_t_24158, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str26));
    V v_msg_24160 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str27), v_t_24159);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam13, 1, 3, (V[]){v_msg_24160, v_start_24156, v_end_24157});
  }
  case TAG_ENeg: {
    heff_drop(v_r_240);
    V v_t_24165 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24166 = heff_take_field(v_t_24165, 3);
    V v_end_24167 = heff_get_n(v_t_24165, 4, 9);
    V v_t_24168 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24169 = heff_strAppend(heff_get_n(v_t_24168, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str28));
    V v_msg_24170 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str29), v_t_24169);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam14, 1, 3, (V[]){v_msg_24170, v_start_24166, v_end_24167});
  }
  case TAG_ETilde: {
    heff_drop(v_r_240);
    V v_t_24175 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24176 = heff_take_field(v_t_24175, 3);
    V v_end_24177 = heff_get_n(v_t_24175, 4, 9);
    V v_t_24178 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24179 = heff_strAppend(heff_get_n(v_t_24178, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str30));
    V v_msg_24180 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str31), v_t_24179);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam15, 1, 3, (V[]){v_msg_24180, v_start_24176, v_end_24177});
  }
  case TAG_App: {
    heff_drop(v_r_240);
    V v_t_24185 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24186 = heff_take_field(v_t_24185, 3);
    V v_end_24187 = heff_get_n(v_t_24185, 4, 9);
    V v_t_24188 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24189 = heff_strAppend(heff_get_n(v_t_24188, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str32));
    V v_msg_24190 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str33), v_t_24189);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam16, 1, 3, (V[]){v_msg_24190, v_start_24186, v_end_24187});
  }
  case TAG_Op: {
    heff_drop(v_r_240);
    V v_t_24196 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24197 = heff_take_field(v_t_24196, 3);
    V v_end_24198 = heff_get_n(v_t_24196, 4, 9);
    V v_t_24199 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str34));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str35), v_t_24200);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam17, 1, 3, (V[]){v_msg_24201, v_start_24197, v_end_24198});
  }
  case TAG_Ops: {
    heff_drop(v_r_240);
    V v_t_24206 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24207 = heff_take_field(v_t_24206, 3);
    V v_end_24208 = heff_get_n(v_t_24206, 4, 9);
    V v_t_24209 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24210 = heff_strAppend(heff_get_n(v_t_24209, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str36));
    V v_msg_24211 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str37), v_t_24210);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam18, 1, 3, (V[]){v_msg_24211, v_start_24207, v_end_24208});
  }
  case TAG_OpRhs: {
    heff_drop(v_r_240);
    V v_t_24216 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24217 = heff_take_field(v_t_24216, 3);
    V v_end_24218 = heff_get_n(v_t_24216, 4, 9);
    V v_t_24219 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24220 = heff_strAppend(heff_get_n(v_t_24219, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str38));
    V v_msg_24221 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str39), v_t_24220);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam19, 1, 3, (V[]){v_msg_24221, v_start_24217, v_end_24218});
  }
  case TAG_Ann: {
    heff_drop(v_r_240);
    V v_t_24227 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24228 = heff_take_field(v_t_24227, 3);
    V v_end_24229 = heff_get_n(v_t_24227, 4, 9);
    V v_t_24230 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24231 = heff_strAppend(heff_get_n(v_t_24230, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str40));
    V v_msg_24232 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str41), v_t_24231);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam20, 1, 3, (V[]){v_msg_24232, v_start_24228, v_end_24229});
  }
  case TAG_BVar: {
    heff_drop(v_r_240);
    V v_t_24236 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24237 = heff_take_field(v_t_24236, 3);
    V v_end_24238 = heff_get_n(v_t_24236, 4, 9);
    V v_t_24239 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24240 = heff_strAppend(heff_get_n(v_t_24239, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str42));
    V v_msg_24241 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str43), v_t_24240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam21, 1, 3, (V[]){v_msg_24241, v_start_24237, v_end_24238});
  }
  case TAG_BImp: {
    heff_drop(v_r_240);
    V v_t_24247 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24248 = heff_take_field(v_t_24247, 3);
    V v_end_24249 = heff_get_n(v_t_24247, 4, 9);
    V v_t_24250 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24251 = heff_strAppend(heff_get_n(v_t_24250, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str44));
    V v_msg_24252 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str45), v_t_24251);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam22, 1, 3, (V[]){v_msg_24252, v_start_24248, v_end_24249});
  }
  case TAG_BAnn: {
    heff_drop(v_r_240);
    V v_t_24260 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24261 = heff_take_field(v_t_24260, 3);
    V v_end_24262 = heff_get_n(v_t_24260, 4, 9);
    V v_t_24263 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24264 = heff_strAppend(heff_get_n(v_t_24263, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str46));
    V v_msg_24265 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str47), v_t_24264);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam23, 1, 3, (V[]){v_msg_24265, v_start_24261, v_end_24262});
  }
  case TAG_BPat: {
    heff_drop(v_r_240);
    V v_t_24269 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24270 = heff_take_field(v_t_24269, 3);
    V v_end_24271 = heff_get_n(v_t_24269, 4, 9);
    V v_t_24272 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24273 = heff_strAppend(heff_get_n(v_t_24272, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str48));
    V v_msg_24274 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str49), v_t_24273);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam24, 1, 3, (V[]){v_msg_24274, v_start_24270, v_end_24271});
  }
  case TAG_Lam: {
    heff_drop(v_r_240);
    V v_t_24281 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24282 = heff_take_field(v_t_24281, 3);
    V v_end_24283 = heff_get_n(v_t_24281, 4, 9);
    V v_t_24284 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24285 = heff_strAppend(heff_get_n(v_t_24284, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str50));
    V v_msg_24286 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str51), v_t_24285);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam25, 1, 3, (V[]){v_msg_24286, v_start_24282, v_end_24283});
  }
  case TAG_Case: {
    heff_drop(v_r_240);
    V v_t_24293 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24294 = heff_take_field(v_t_24293, 3);
    V v_end_24295 = heff_get_n(v_t_24293, 4, 9);
    V v_t_24296 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24297 = heff_strAppend(heff_get_n(v_t_24296, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str52));
    V v_msg_24298 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str53), v_t_24297);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam26, 1, 3, (V[]){v_msg_24298, v_start_24294, v_end_24295});
  }
  case TAG_EAlt: {
    heff_drop(v_r_240);
    V v_t_24304 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24305 = heff_take_field(v_t_24304, 3);
    V v_end_24306 = heff_get_n(v_t_24304, 4, 9);
    V v_t_24307 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24308 = heff_strAppend(heff_get_n(v_t_24307, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str54));
    V v_msg_24309 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str55), v_t_24308);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam27, 1, 3, (V[]){v_msg_24309, v_start_24305, v_end_24306});
  }
  case TAG_If: {
    heff_drop(v_r_240);
    V v_t_24318 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24319 = heff_take_field(v_t_24318, 3);
    V v_end_24320 = heff_get_n(v_t_24318, 4, 9);
    V v_t_24321 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24322 = heff_strAppend(heff_get_n(v_t_24321, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str56));
    V v_msg_24323 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str57), v_t_24322);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam28, 1, 3, (V[]){v_msg_24323, v_start_24319, v_end_24320});
  }
  case TAG_Do: {
    heff_drop(v_r_240);
    V v_t_24328 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24329 = heff_take_field(v_t_24328, 3);
    V v_end_24330 = heff_get_n(v_t_24328, 4, 9);
    V v_t_24331 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24332 = heff_strAppend(heff_get_n(v_t_24331, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str58));
    V v_msg_24333 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str59), v_t_24332);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam29, 1, 3, (V[]){v_msg_24333, v_start_24329, v_end_24330});
  }
  case TAG_ESBind: {
    heff_drop(v_r_240);
    V v_t_24339 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24340 = heff_take_field(v_t_24339, 3);
    V v_end_24341 = heff_get_n(v_t_24339, 4, 9);
    V v_t_24342 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24343 = heff_strAppend(heff_get_n(v_t_24342, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str60));
    V v_msg_24344 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str61), v_t_24343);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam30, 1, 3, (V[]){v_msg_24344, v_start_24340, v_end_24341});
  }
  case TAG_ELet: {
    heff_drop(v_r_240);
    V v_t_24353 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24354 = heff_take_field(v_t_24353, 3);
    V v_end_24355 = heff_get_n(v_t_24353, 4, 9);
    V v_t_24356 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24357 = heff_strAppend(heff_get_n(v_t_24356, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str62));
    V v_msg_24358 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str63), v_t_24357);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam31, 1, 3, (V[]){v_msg_24358, v_start_24354, v_end_24355});
  }
  case TAG_ELetElse: {
    heff_drop(v_r_240);
    V v_t_24368 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24369 = heff_take_field(v_t_24368, 3);
    V v_end_24370 = heff_get_n(v_t_24368, 4, 9);
    V v_t_24371 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 7); r_; });
    V v_t_24372 = heff_strAppend(heff_get_n(v_t_24371, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str64));
    V v_msg_24373 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str65), v_t_24372);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam32, 1, 3, (V[]){v_msg_24373, v_start_24369, v_end_24370});
  }
  case TAG_ELetMut: {
    heff_drop(v_r_240);
    V v_t_24382 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24383 = heff_take_field(v_t_24382, 3);
    V v_end_24384 = heff_get_n(v_t_24382, 4, 9);
    V v_t_24385 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24386 = heff_strAppend(heff_get_n(v_t_24385, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str66));
    V v_msg_24387 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str67), v_t_24386);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam33, 1, 3, (V[]){v_msg_24387, v_start_24383, v_end_24384});
  }
  case TAG_EAssign: {
    heff_drop(v_r_240);
    V v_t_24393 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24394 = heff_take_field(v_t_24393, 3);
    V v_end_24395 = heff_get_n(v_t_24393, 4, 9);
    V v_t_24396 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24397 = heff_strAppend(heff_get_n(v_t_24396, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str68));
    V v_msg_24398 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str69), v_t_24397);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam34, 1, 3, (V[]){v_msg_24398, v_start_24394, v_end_24395});
  }
  case TAG_EWhile: {
    heff_drop(v_r_240);
    V v_t_24405 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24406 = heff_take_field(v_t_24405, 3);
    V v_end_24407 = heff_get_n(v_t_24405, 4, 9);
    V v_t_24408 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24409 = heff_strAppend(heff_get_n(v_t_24408, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str70));
    V v_msg_24410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str71), v_t_24409);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam35, 1, 3, (V[]){v_msg_24410, v_start_24406, v_end_24407});
  }
  case TAG_EFor: {
    heff_drop(v_r_240);
    V v_t_24419 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24420 = heff_take_field(v_t_24419, 3);
    V v_end_24421 = heff_get_n(v_t_24419, 4, 9);
    V v_t_24422 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24423 = heff_strAppend(heff_get_n(v_t_24422, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str72));
    V v_msg_24424 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str73), v_t_24423);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam36, 1, 3, (V[]){v_msg_24424, v_start_24420, v_end_24421});
  }
  case TAG_EJump: {
    heff_drop(v_r_240);
    V v_t_24428 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24429 = heff_take_field(v_t_24428, 3);
    V v_end_24430 = heff_get_n(v_t_24428, 4, 9);
    V v_t_24431 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24432 = heff_strAppend(heff_get_n(v_t_24431, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str74));
    V v_msg_24433 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str75), v_t_24432);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam37, 1, 3, (V[]){v_msg_24433, v_start_24429, v_end_24430});
  }
  case TAG_EReturn: {
    heff_drop(v_r_240);
    V v_t_24438 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24439 = heff_take_field(v_t_24438, 3);
    V v_end_24440 = heff_get_n(v_t_24438, 4, 9);
    V v_t_24441 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24442 = heff_strAppend(heff_get_n(v_t_24441, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str76));
    V v_msg_24443 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str77), v_t_24442);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam38, 1, 3, (V[]){v_msg_24443, v_start_24439, v_end_24440});
  }
  case TAG_ENest: {
    heff_drop(v_r_240);
    V v_t_24450 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24451 = heff_take_field(v_t_24450, 3);
    V v_end_24452 = heff_get_n(v_t_24450, 4, 9);
    V v_t_24453 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24454 = heff_strAppend(heff_get_n(v_t_24453, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str78));
    V v_msg_24455 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str79), v_t_24454);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam39, 1, 3, (V[]){v_msg_24455, v_start_24451, v_end_24452});
  }
  case TAG_EArrow: {
    heff_drop(v_r_240);
    V v_t_24460 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24461 = heff_take_field(v_t_24460, 3);
    V v_end_24462 = heff_get_n(v_t_24460, 4, 9);
    V v_t_24463 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24464 = heff_strAppend(heff_get_n(v_t_24463, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str80));
    V v_msg_24465 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str81), v_t_24464);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam40, 1, 3, (V[]){v_msg_24465, v_start_24461, v_end_24462});
  }
  case TAG_IfThen: {
    heff_drop(v_r_240);
    V v_t_24472 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24473 = heff_take_field(v_t_24472, 3);
    V v_end_24474 = heff_get_n(v_t_24472, 4, 9);
    V v_t_24475 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24476 = heff_strAppend(heff_get_n(v_t_24475, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str82));
    V v_msg_24477 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str83), v_t_24476);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam41, 1, 3, (V[]){v_msg_24477, v_start_24473, v_end_24474});
  }
  case TAG_ETry: {
    heff_drop(v_r_240);
    V v_t_24484 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24485 = heff_take_field(v_t_24484, 3);
    V v_end_24486 = heff_get_n(v_t_24484, 4, 9);
    V v_t_24487 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24488 = heff_strAppend(heff_get_n(v_t_24487, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str84));
    V v_msg_24489 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str85), v_t_24488);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam42, 1, 3, (V[]){v_msg_24489, v_start_24485, v_end_24486});
  }
  case TAG_ECatch: {
    V v_b_24493 = heff_field(v_e_241, 1);
    V v_body_24495 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 4);
    V v_m_24496 = (g_heff_2esyntax_2esurface_2elamBinderL(heff_dup(v_r_240), v_b_24493));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam43, 1, 3, (V[]){v_m_24496, v_r_240, v_body_24495});
  }
  case TAG_EWith: {
    heff_drop(v_r_240);
    V v_t_24530 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_24531 = heff_take_field(v_t_24530, 3);
    V v_end_24532 = heff_get_n(v_t_24530, 4, 9);
    V v_t_24533 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24534 = heff_strAppend(heff_get_n(v_t_24533, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str86));
    V v_msg_24535 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str87), v_t_24534);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam45, 1, 3, (V[]){v_msg_24535, v_start_24531, v_end_24532});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatchL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_msg_248 = heff_env(self)[0];
  V v_start_244 = heff_env(self)[1];
  V v_end_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_248, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2410}), v_st_249});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args) {
  V v_st_2420 = args[0];
  V v_msg_2419 = heff_env(self)[0];
  V v_start_2415 = heff_env(self)[1];
  V v_end_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2419, heff_rec_n(2, shape_start__end, (V[]){v_start_2415, v_end_2416}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2420});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args) {
  V v_st_2433 = args[0];
  V v_msg_2432 = heff_env(self)[0];
  V v_start_2428 = heff_env(self)[1];
  V v_end_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2432, heff_rec_n(2, shape_start__end, (V[]){v_start_2428, v_end_2429}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2434}), v_st_2433});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args) {
  V v_st_2445 = args[0];
  V v_msg_2444 = heff_env(self)[0];
  V v_start_2440 = heff_env(self)[1];
  V v_end_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2444, heff_rec_n(2, shape_start__end, (V[]){v_start_2440, v_end_2441}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2446}), v_st_2445});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args) {
  V v_st_2456 = args[0];
  V v_msg_2455 = heff_env(self)[0];
  V v_start_2451 = heff_env(self)[1];
  V v_end_2452 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2455, heff_rec_n(2, shape_start__end, (V[]){v_start_2451, v_end_2452}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2457}), v_st_2456});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args) {
  V v_st_2468 = args[0];
  V v_msg_2467 = heff_env(self)[0];
  V v_start_2463 = heff_env(self)[1];
  V v_end_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2467, heff_rec_n(2, shape_start__end, (V[]){v_start_2463, v_end_2464}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2469}), v_st_2468});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args) {
  V v_st_2482 = args[0];
  V v_msg_2481 = heff_env(self)[0];
  V v_start_2477 = heff_env(self)[1];
  V v_end_2478 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2481, heff_rec_n(2, shape_start__end, (V[]){v_start_2477, v_end_2478}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2483}), v_st_2482});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args) {
  V v_st_2493 = args[0];
  V v_msg_2492 = heff_env(self)[0];
  V v_start_2488 = heff_env(self)[1];
  V v_end_2489 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2492, heff_rec_n(2, shape_start__end, (V[]){v_start_2488, v_end_2489}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2494}), v_st_2493});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args) {
  V v_st_24106 = args[0];
  V v_msg_24105 = heff_env(self)[0];
  V v_start_24101 = heff_env(self)[1];
  V v_end_24102 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, heff_rec_n(2, shape_start__end, (V[]){v_start_24101, v_end_24102}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24107}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args) {
  V v_st_24117 = args[0];
  V v_msg_24116 = heff_env(self)[0];
  V v_start_24112 = heff_env(self)[1];
  V v_end_24113 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24116, heff_rec_n(2, shape_start__end, (V[]){v_start_24112, v_end_24113}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24117});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args) {
  V v_st_24128 = args[0];
  V v_msg_24127 = heff_env(self)[0];
  V v_start_24123 = heff_env(self)[1];
  V v_end_24124 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, heff_rec_n(2, shape_start__end, (V[]){v_start_24123, v_end_24124}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24129}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args) {
  V v_st_24141 = args[0];
  V v_msg_24140 = heff_env(self)[0];
  V v_start_24136 = heff_env(self)[1];
  V v_end_24137 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24142 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24140, heff_rec_n(2, shape_start__end, (V[]){v_start_24136, v_end_24137}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24142}), v_st_24141});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args) {
  V v_st_24151 = args[0];
  V v_msg_24150 = heff_env(self)[0];
  V v_start_24146 = heff_env(self)[1];
  V v_end_24147 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24152 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24150, heff_rec_n(2, shape_start__end, (V[]){v_start_24146, v_end_24147}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24152}), v_st_24151});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args) {
  V v_st_24161 = args[0];
  V v_msg_24160 = heff_env(self)[0];
  V v_start_24156 = heff_env(self)[1];
  V v_end_24157 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24162 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24160, heff_rec_n(2, shape_start__end, (V[]){v_start_24156, v_end_24157}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24162}), v_st_24161});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args) {
  V v_st_24171 = args[0];
  V v_msg_24170 = heff_env(self)[0];
  V v_start_24166 = heff_env(self)[1];
  V v_end_24167 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24172 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24170, heff_rec_n(2, shape_start__end, (V[]){v_start_24166, v_end_24167}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24172}), v_st_24171});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args) {
  V v_st_24181 = args[0];
  V v_msg_24180 = heff_env(self)[0];
  V v_start_24176 = heff_env(self)[1];
  V v_end_24177 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24182 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24180, heff_rec_n(2, shape_start__end, (V[]){v_start_24176, v_end_24177}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24182}), v_st_24181});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args) {
  V v_st_24191 = args[0];
  V v_msg_24190 = heff_env(self)[0];
  V v_start_24186 = heff_env(self)[1];
  V v_end_24187 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24192 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24190, heff_rec_n(2, shape_start__end, (V[]){v_start_24186, v_end_24187}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24192}), v_st_24191});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args) {
  V v_st_24202 = args[0];
  V v_msg_24201 = heff_env(self)[0];
  V v_start_24197 = heff_env(self)[1];
  V v_end_24198 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24203 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, heff_rec_n(2, shape_start__end, (V[]){v_start_24197, v_end_24198}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24203}), v_st_24202});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args) {
  V v_st_24212 = args[0];
  V v_msg_24211 = heff_env(self)[0];
  V v_start_24207 = heff_env(self)[1];
  V v_end_24208 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24213 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24211, heff_rec_n(2, shape_start__end, (V[]){v_start_24207, v_end_24208}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24213}), v_st_24212});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args) {
  V v_st_24222 = args[0];
  V v_msg_24221 = heff_env(self)[0];
  V v_start_24217 = heff_env(self)[1];
  V v_end_24218 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24223 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24221, heff_rec_n(2, shape_start__end, (V[]){v_start_24217, v_end_24218}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24223}), v_st_24222});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args) {
  V v_st_24233 = args[0];
  V v_msg_24232 = heff_env(self)[0];
  V v_start_24228 = heff_env(self)[1];
  V v_end_24229 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24234 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24232, heff_rec_n(2, shape_start__end, (V[]){v_start_24228, v_end_24229}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24234}), v_st_24233});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args) {
  V v_st_24242 = args[0];
  V v_msg_24241 = heff_env(self)[0];
  V v_start_24237 = heff_env(self)[1];
  V v_end_24238 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24243 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24241, heff_rec_n(2, shape_start__end, (V[]){v_start_24237, v_end_24238}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24243}), v_st_24242});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args) {
  V v_st_24253 = args[0];
  V v_msg_24252 = heff_env(self)[0];
  V v_start_24248 = heff_env(self)[1];
  V v_end_24249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24254 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24252, heff_rec_n(2, shape_start__end, (V[]){v_start_24248, v_end_24249}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24254}), v_st_24253});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args) {
  V v_st_24266 = args[0];
  V v_msg_24265 = heff_env(self)[0];
  V v_start_24261 = heff_env(self)[1];
  V v_end_24262 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24267 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24265, heff_rec_n(2, shape_start__end, (V[]){v_start_24261, v_end_24262}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24267}), v_st_24266});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args) {
  V v_st_24275 = args[0];
  V v_msg_24274 = heff_env(self)[0];
  V v_start_24270 = heff_env(self)[1];
  V v_end_24271 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24276 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24274, heff_rec_n(2, shape_start__end, (V[]){v_start_24270, v_end_24271}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24276}), v_st_24275});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args) {
  V v_st_24287 = args[0];
  V v_msg_24286 = heff_env(self)[0];
  V v_start_24282 = heff_env(self)[1];
  V v_end_24283 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24288 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24286, heff_rec_n(2, shape_start__end, (V[]){v_start_24282, v_end_24283}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24288}), v_st_24287});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args) {
  V v_st_24299 = args[0];
  V v_msg_24298 = heff_env(self)[0];
  V v_start_24294 = heff_env(self)[1];
  V v_end_24295 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24300 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24298, heff_rec_n(2, shape_start__end, (V[]){v_start_24294, v_end_24295}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24300}), v_st_24299});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args) {
  V v_st_24310 = args[0];
  V v_msg_24309 = heff_env(self)[0];
  V v_start_24305 = heff_env(self)[1];
  V v_end_24306 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24311 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24309, heff_rec_n(2, shape_start__end, (V[]){v_start_24305, v_end_24306}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24311}), v_st_24310});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args) {
  V v_st_24324 = args[0];
  V v_msg_24323 = heff_env(self)[0];
  V v_start_24319 = heff_env(self)[1];
  V v_end_24320 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24325 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24323, heff_rec_n(2, shape_start__end, (V[]){v_start_24319, v_end_24320}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24325}), v_st_24324});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args) {
  V v_st_24334 = args[0];
  V v_msg_24333 = heff_env(self)[0];
  V v_start_24329 = heff_env(self)[1];
  V v_end_24330 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24335 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24333, heff_rec_n(2, shape_start__end, (V[]){v_start_24329, v_end_24330}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24335}), v_st_24334});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args) {
  V v_st_24345 = args[0];
  V v_msg_24344 = heff_env(self)[0];
  V v_start_24340 = heff_env(self)[1];
  V v_end_24341 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24346 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24344, heff_rec_n(2, shape_start__end, (V[]){v_start_24340, v_end_24341}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24346}), v_st_24345});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args) {
  V v_st_24359 = args[0];
  V v_msg_24358 = heff_env(self)[0];
  V v_start_24354 = heff_env(self)[1];
  V v_end_24355 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24360 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24358, heff_rec_n(2, shape_start__end, (V[]){v_start_24354, v_end_24355}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24360}), v_st_24359});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args) {
  V v_st_24374 = args[0];
  V v_msg_24373 = heff_env(self)[0];
  V v_start_24369 = heff_env(self)[1];
  V v_end_24370 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24375 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24373, heff_rec_n(2, shape_start__end, (V[]){v_start_24369, v_end_24370}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24375}), v_st_24374});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args) {
  V v_st_24388 = args[0];
  V v_msg_24387 = heff_env(self)[0];
  V v_start_24383 = heff_env(self)[1];
  V v_end_24384 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24389 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24387, heff_rec_n(2, shape_start__end, (V[]){v_start_24383, v_end_24384}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24389}), v_st_24388});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args) {
  V v_st_24399 = args[0];
  V v_msg_24398 = heff_env(self)[0];
  V v_start_24394 = heff_env(self)[1];
  V v_end_24395 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24400 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24398, heff_rec_n(2, shape_start__end, (V[]){v_start_24394, v_end_24395}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24400}), v_st_24399});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args) {
  V v_st_24411 = args[0];
  V v_msg_24410 = heff_env(self)[0];
  V v_start_24406 = heff_env(self)[1];
  V v_end_24407 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24410, heff_rec_n(2, shape_start__end, (V[]){v_start_24406, v_end_24407}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24412}), v_st_24411});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args) {
  V v_st_24425 = args[0];
  V v_msg_24424 = heff_env(self)[0];
  V v_start_24420 = heff_env(self)[1];
  V v_end_24421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24424, heff_rec_n(2, shape_start__end, (V[]){v_start_24420, v_end_24421}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24426}), v_st_24425});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args) {
  V v_st_24434 = args[0];
  V v_msg_24433 = heff_env(self)[0];
  V v_start_24429 = heff_env(self)[1];
  V v_end_24430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24433, heff_rec_n(2, shape_start__end, (V[]){v_start_24429, v_end_24430}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24435}), v_st_24434});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args) {
  V v_st_24444 = args[0];
  V v_msg_24443 = heff_env(self)[0];
  V v_start_24439 = heff_env(self)[1];
  V v_end_24440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24443, heff_rec_n(2, shape_start__end, (V[]){v_start_24439, v_end_24440}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24445}), v_st_24444});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args) {
  V v_st_24456 = args[0];
  V v_msg_24455 = heff_env(self)[0];
  V v_start_24451 = heff_env(self)[1];
  V v_end_24452 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24455, heff_rec_n(2, shape_start__end, (V[]){v_start_24451, v_end_24452}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24457}), v_st_24456});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args) {
  V v_st_24466 = args[0];
  V v_msg_24465 = heff_env(self)[0];
  V v_start_24461 = heff_env(self)[1];
  V v_end_24462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24465, heff_rec_n(2, shape_start__end, (V[]){v_start_24461, v_end_24462}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24467}), v_st_24466});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args) {
  V v_st_24478 = args[0];
  V v_msg_24477 = heff_env(self)[0];
  V v_start_24473 = heff_env(self)[1];
  V v_end_24474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24477, heff_rec_n(2, shape_start__end, (V[]){v_start_24473, v_end_24474}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24479}), v_st_24478});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args) {
  V v_st_24490 = args[0];
  V v_msg_24489 = heff_env(self)[0];
  V v_start_24485 = heff_env(self)[1];
  V v_end_24486 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24489, heff_rec_n(2, shape_start__end, (V[]){v_start_24485, v_end_24486}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24491}), v_st_24490});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam44(V self, V *args) {
  V v_m_24514 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24514));
}
V g_heff_2esyntax_2esurface_2ecatchL_lam43(V self, V *args) {
  V v_st_24497 = args[0];
  V v_m_24496 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_body_24495 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24498 = heff_tr(heff_call(v_m_24496, 1, (V[]){v_st_24497}));
  switch (heff_tag_of(v_x1_24498)) {
  case TAG_MkPair: {
    V v_x11_24499 = heff_field(v_x1_24498, 0);
    V v_st_24500 = heff_field(v_x1_24498, 1);
    V v_ru_24x1_24498_24MkPair = heff_take_reuse_n(v_x1_24498, 3ULL, 2);
    switch (heff_tag_of(v_x11_24499)) {
    case TAG_Left: {
      V v_e_24501 = heff_field(v_x11_24499, 0);
      heff_take_n(v_x11_24499, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_body_24495);
      return heff_tag_at_n(v_ru_24x1_24498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24501}), v_st_24500});
    }
    case TAG_Right: {
      V v_x_24502 = heff_field(v_x11_24499, 0);
      V v_ru_24x11_24499_24Right = heff_take_reuse_n(v_x11_24499, 1ULL, 1);
      V v_binder_24503 = heff_take_field(v_x_24502, 0);
      V v_pat_24504 = heff_get_n(v_x_24502, 2, 3);
      V v_t_24513;
      switch (heff_tag_of(v_binder_24503)) {
      case TAG_LamName: {
        V v_x_24505 = heff_dup(heff_field(v_binder_24503, 0));
        switch (heff_tag_of(v_pat_24504)) {
        case TAG_Nothing: {
          v_t_24513 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24505, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Just: {
          V v_p_24507 = heff_field(v_pat_24504, 0);
          heff_take_n(v_pat_24504, 1ULL, 1);
          heff_drop(v_x_24505);
          v_t_24513 = (g_heff_2esyntax_2epresyntax_2epatNames(v_p_24507));
          break;
        }
        default: heff_nomatch(v_pat_24504);
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_24508 = heff_dup(heff_field(v_binder_24503, 0));
        heff_drop(v_pat_24504);
        v_t_24513 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24508, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_24510 = heff_dup(heff_field(v_binder_24503, 0));
        heff_drop(v_pat_24504);
        v_t_24513 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24510, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_binder_24503);
      }
      V v_t_24515 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam44, 1, 1, (V[]){v_r_240}), v_body_24495}));
      HeffT2 v_t_24516 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24513, v_t_24515, v_st_24500));
      {
        V v_field_24517 = v_t_24516.f[0];
        V v_field_24518 = v_t_24516.f[1];
        V v_x11_24519 = v_field_24517;
        V v_st_24520 = v_field_24518;
        switch (heff_tag_of(v_x11_24519)) {
        case TAG_Left: {
          V v_e_24521 = heff_field(v_x11_24519, 0);
          heff_take_n(v_x11_24519, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_24499_24Right, 1);
          heff_drop(v_binder_24503);
          return heff_tag_at_n(v_ru_24x1_24498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24521}), v_st_24520});
        }
        case TAG_Right: {
          V v_x_24522 = heff_field(v_x11_24519, 0);
          heff_take_n(v_x11_24519, 1ULL, 1);
          V v_t_24523 = heff_tag_at_n(v_ru_24x11_24499_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_binder_24503, v_x_24522})});
          return heff_tag_at_n(v_ru_24x1_24498_24MkPair, TAG_MkPair, 2, (V[]){v_t_24523, v_st_24520});
        }
        default: return heff_nomatch(v_x11_24519);
        }
      }
    }
    default: return heff_nomatch(v_x11_24499);
    }
  }
  default: return heff_nomatch(v_x1_24498);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_lam45(V self, V *args) {
  V v_st_24536 = args[0];
  V v_msg_24535 = heff_env(self)[0];
  V v_start_24531 = heff_env(self)[1];
  V v_end_24532 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24537 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24535, heff_rec_n(2, shape_start__end, (V[]){v_start_24531, v_end_24532}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24537}), v_st_24536});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_240, v_sp_241, v_e_242, v_v_243, v_s_244, v_st_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3, 17, " does not fit in ");
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5, 1, 0};
Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V v_inPat_240, V v_sp_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_StrValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo);
  }
  case TAG_IntValue: {
    V v_v_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    if (((heff_dup(v_inPat_240) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_v_246, 1) && ({ V v_t_2421 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_2421, 0); heff_drop(v_t_2421); c_; })) : ({ V v_t_247 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_243) - ((int64_t)1ULL))))); int c_ = ({ V v_t_2422 = heff_intSub(MK_INT(0LL), heff_dup(v_t_247)); int c_ = (heff_intLe_c_lent(v_t_2422, v_v_246, 0) && ({ V v_t_2423 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_2423, 0); heff_drop(v_t_2423); c_; })); heff_drop(v_t_2422); c_; }); heff_drop(v_t_247); c_; }))) {
      heff_drop(v_sp_241);
      heff_drop(v_n_243);
      heff_drop(v_v_246);
      return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo);
    } else {
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2, 1, 4, (V[]){heff_dup(v_inPat_240), v_n_243, v_v_246, v_sp_241});
    }
  }
  case TAG_FloatValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo);
  }
  case TAG_RuneValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo);
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_t_249 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_st_248});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_inPat_240 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  V v_v_246 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  if (!(heff_dup(v_inPat_240) == NTAG(TAG_True))) {
    heff_drop(v_inPat_240);
    v_t_2411 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0);
  } else {
    heff_drop(v_inPat_240);
    v_t_2411 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_n_243), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2), v_t_2411));
  V v_t_2413 = heff_strAppend(heff_intShow(v_v_246), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3), v_t_2412));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2413, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_2410});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args) {
  V v_st_2415 = args[0];
  V v_t_2416 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_st_2415});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2418 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_st_2417});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args) {
  V v_st_2419 = args[0];
  V v_t_2420 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_st_2419});
}
Clo g_heff_2esyntax_2esurface_2etakesRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakesRest_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakesRest(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_PatVar: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatTag: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatOp: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatInt: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatFloat: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRune: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRecord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatWord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatAs: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      default: return heff_nomatch(v_x111_246);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etakesRest(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatSegmentsL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_rest_245)) {
    case TAG_Nil: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_245);
    }
    V v_m_249 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_t_248; V a_2 = v_p_244; V r_ = heff_tr(g_heff_2esyntax_2esurface_2epatSegmentL(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentsL_lam1, 1, 3, (V[]){v_m_249, v_r_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatSegmentsL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_st_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_rest_245);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_m_2416 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_rest_245));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2413}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_x_2421 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2421})});
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryFieldOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryFieldOne_entry, 4, 0};

V g_heff_2esyntax_2esurface_2etheoryFieldOne(V v_r_240, V v_ty_241, V v_d_242, V v_x_243) {
top: ;
  V v_text_244 = heff_take_field(v_x_243, 1);
  V v_start_245 = heff_take_field(v_x_243, 3);
  V v_end_246 = heff_get_n(v_x_243, 4, 9);
  V v_m_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_241}));
  return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0, 1, 6, (V[]){v_m_247, v_r_240, v_d_242, v_text_244, v_start_245, v_end_246});
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryFieldOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_start_245 = heff_env(self)[4];
  V v_end_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_242);
      heff_drop(v_text_244);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_m_2414 = (g_heff_2esyntax_2esurface_2edefaultL(v_r_240, v_d_242));
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop(v_text_244);
          heff_drop(v_start_245);
          heff_drop(v_end_246);
          heff_drop(v_x_2413);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          heff_drop_cell(v_ru_24x1_2415_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          V v_t_2420 = heff_tag_n(TAG_DeclareField, 4, (V[]){heff_dup(v_text_244), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_245), v_end_246}), heff_dup(v_x_2413), heff_dup(v_x_2419)});
          V v_t_2422;
          switch (heff_tag_of(v_x_2419)) {
          case TAG_Nothing: {
            v_t_2422 = v_x_2413;
            break;
          }
          case TAG_Just: {
            V v_x_2421 = heff_field(v_x_2419, 0);
            heff_take_n(v_x_2419, 1ULL, 1);
            heff_drop(v_x_2413);
            v_t_2422 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_x_2419);
          }
          V v_t_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_At: {
            V v_s_2424 = heff_field(v_t_2422, 1);
            heff_take_n(v_t_2422, 2ULL, 2);
            v_t_2425 = v_s_2424;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2426 = ({ V rv_0 = v_start_245; V rr_ = heff_rec_reuse_nf(v_t_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2427 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2426})});
          V v_t_2428 = heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_Cons, 2, (V[]){v_text_244, heff_dup(heff_rfield(v_st_2417, 1))});
          V v_t_2429 = ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_st_2417, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_t_2429});
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str0, 4, "#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str1, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str2, 4, "#arg");
Clo g_heff_2esyntax_2esurface_2eknotField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eknotField_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eknotField(V v_k_240, V v_d_241) {
top: ;
  V v_name_242 = heff_take_field(v_d_241, 0);
  V v_span_243 = heff_get_n(v_d_241, 1, 5);
  V v_t_244 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(heff_dup(v_name_242), ((V)&g_heff_2esyntax_2esurface_2eknotField_str0)), heff_dup(v_span_243)});
  V v_t_245 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_242), ((V)&g_heff_2esyntax_2esurface_2eknotField_str1))});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_240}), heff_dup(v_span_243)});
  V v_t_247 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_242), ((V)&g_heff_2esyntax_2esurface_2eknotField_str2))});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_span_243)}), NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_span_243)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})));
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_244, v_t_249}), heff_dup(v_span_243)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_name_242, heff_dup(v_span_243), v_t_2410}), v_span_243});
}
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eknotField(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efixityOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixityOut(V v_imported_240, V v_decls_241, V v_groups_242, V v_edges_243) {
top: ;
  V v_groups_244 = heff_take_field(v_imported_240, 0);
  V v_above_245 = heff_get_n(v_imported_240, 1, 2);
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(v_groups_244), heff_dup(v_groups_242)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByG(v_t_246));
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(v_above_245), NTAG(TAG_Nil)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByE(v_t_248));
  V v_t_2410 = heff_rec_n(2, shape_groups__above, (V[]){v_t_247, v_t_249});
  V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_244, heff_dup(v_groups_242)));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2411));
  V v_t_2413 = (g_heff_2esyntax_2efixity_2eappendF(v_above_245, heff_dup(v_edges_243)));
  V v_t_2414 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2413));
  V v_t_2415 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2412, v_t_2414});
  V v_t_2416 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_t_2410, v_t_2415, v_decls_241));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_242, v_edges_243}), v_t_2416});
}
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixityOut(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), heff_dup(v_ds_241), heff_dup(v_st_243)));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x11_247 = v_field_245;
    V v_st_248 = v_field_246;
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ds_241);
      heff_drop(v_rhs_242);
      heff_drop_rec(v_st_243, 9);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_st_2411 = ({ V rv_3 = heff_get_n(v_st_243, 3, 9); V rr_ = heff_rec_reuse_nf(v_st_248, 503ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_items_2413 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2412, NTAG(TAG_Nil)));
      V v_t_2414 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2418 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0, 2, 1, (V[]){heff_dup(v_st_2411)}); V a_1 = v_t_2414; V a_2 = v_items_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2413); r_; });
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2418, 3, 4)));
      V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_items_2421 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2420, NTAG(TAG_Nil)));
      V v_t_2422 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2423 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2421));
      V v_t_2424 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2421));
      V v_t_2425 = ({ V a_0 = v_t_2422; V a_1 = v_t_2423; V a_2 = v_t_2424; V a_3 = v_items_2421; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); heff_drop(v_t_2423); heff_drop(v_t_2424); r_; });
      V v_t_2426 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2425));
      V v_t_2427 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2419, v_t_2426));
      switch (heff_tag_of(v_t_2427)) {
      case TAG_Nil: {
        V v_items_2428 = ({ V a_0 = v_x_2410; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2410); r_; });
        V v_items_2429 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2428, NTAG(TAG_Nil)));
        V v_t_2430 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_items_2429; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
        V v_x1_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
        V v_b_2436;
        switch (heff_tag_of(v_x1_2432)) {
        case TAG_Nil: {
          v_b_2436 = heff_get_n(v_kw_240, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2433 = heff_field(v_x1_2432, 0);
          heff_take_n(v_x1_2432, 1ULL, 2);
          heff_drop_rec(v_kw_240, 9);
          V v_t_2435 = (g_heff_2esyntax_2ecst_2elastD(v_x_2433));
          v_b_2436 = heff_get_n(v_t_2435, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2432);
        }
        V v_t_2439;
        switch (heff_tag_of(v_rhs_242)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_rhs_242, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_242);
        }
        V v_t_2440 = ({ V rv_1 = v_b_2436; V rr_ = heff_rec_reuse_nf(v_t_2439, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_242, v_t_2431}), v_t_2440});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2441}), v_st_2411});
      }
      case TAG_Cons: {
        V v_d_2442 = heff_field(v_t_2427, 0);
        V v_ru_24t_2427_24Cons = heff_take_reuse_n(v_t_2427, 1ULL, 2);
        heff_drop_rec(v_kw_240, 9);
        heff_drop(v_ds_241);
        heff_drop(v_rhs_242);
        heff_drop(v_x_2410);
        heff_drop_cell(v_ru_24x11_247_24Right, 1);
        return heff_tag_at_n(v_ru_24t_2427_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2442}), v_st_2411});
      }
      default: return heff_nomatch(v_t_2427);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args) {
  V v_d_2415 = args[0];
  V v_it_2416 = args[1];
  V v_st_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2415, 2)), v_it_2416));
  return ({ V a_0 = heff_get_n(v_st_2411, 7, 9); V a_1 = v_d_2415; V a_2 = v_t_2417; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0), v_t_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1)})});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_249;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a[0], a[1], a[2]);
}