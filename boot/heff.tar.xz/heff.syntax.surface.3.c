// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclPrimitive 46335
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2efixityOut(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisAnnE(V);
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisAnnE_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eopRhsOf(V);
V g_heff_2esyntax_2esurface_2eopRhsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopRhsOf_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_clo;
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_map_2eempty_get(void);
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eexpOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexpOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eexpOf(V v_ex_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_ex_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength(v_ex_240));
    V v_t_243 = (g_heff_2esyntax_2esurface_2eintOfText(v_t_242));
    return heff_intSub(MK_INT(0LL), v_t_243);
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_ex_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str1))) {
      V v_t_245 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength(v_ex_240));
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintOfText(v_t_245);
    } else {
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintOfText(v_ex_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexpOf(a[0]);
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_rest_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 5);
        V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
        V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
        heff_drop(v_u_2429);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2428;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2430 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 4);
        V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2430, heff_hole()});
        V v_u_2435 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2434));
        heff_drop(v_u_2435);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2434;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisNameE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_x11_241, 0);
      V v_t_246 = heff_intSub(heff_dup(heff_rfield(v_x12_242, 1)), heff_dup(heff_rfield(v_x12_242, 0)));
      return heff_intEq(v_t_246, heff_strLength(heff_dup(v_x_245)));
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisNameE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eplainBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplainBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eplainBinder(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_241)) {
    case TAG_EVar: {
      V v_ru_24d1_241_24EVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EImplicitVar: {
      V v_ru_24d1_241_24EImplicitVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      V v_ru_24d1_241_24ETag = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      V v_ru_24d1_241_24EInt = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      V v_ru_24d1_241_24EFloat = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EString: {
      V v_ru_24d1_241_24EString = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBytes: {
      V v_ru_24d1_241_24EBytes = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EBytes, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ERune: {
      V v_ru_24d1_241_24ERune = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWord: {
      V v_ru_24d1_241_24EWord = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EApp: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EProject: {
      V v_ru_24d1_241_24EProject = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENamed: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EPi: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAnn: {
      V v_d11_2421 = heff_field(v_d1_241, 0);
      V v_t_2422 = heff_field(v_d1_241, 1);
      heff_take_n(v_d1_241, 3ULL, 2);
      switch (heff_tag_of(v_d11_2421)) {
      case TAG_At: {
        V v_d111_2423 = heff_field(v_d11_2421, 0);
        V v_xsp_2424 = heff_field(v_d11_2421, 1);
        heff_take_n(v_d11_2421, 3ULL, 2);
        switch (heff_tag_of(v_d111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_d111_2423, 0);
          heff_take_n(v_d111_2423, 1ULL, 1);
          heff_drop_tag(v_d_240, 2);
          return heff_tag_n(TAG_PiNamed, 3, (V[]){v_x_2425, v_xsp_2424, v_t_2422});
        }
        case TAG_EImplicitVar: {
          V v_ru_24d111_2423_24EImplicitVar = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETag: {
          V v_ru_24d111_2423_24ETag = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInt: {
          V v_ru_24d111_2423_24EInt = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFloat: {
          V v_ru_24d111_2423_24EFloat = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EString: {
          V v_ru_24d111_2423_24EString = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBytes: {
          V v_ru_24d111_2423_24EBytes = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EBytes, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ERune: {
          V v_ru_24d111_2423_24ERune = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWord: {
          V v_ru_24d111_2423_24EWord = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EApp: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EProject: {
          V v_ru_24d111_2423_24EProject = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENamed: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EPi: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELam: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAnn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESpec: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESig: {
          V v_ru_24d111_2423_24ESig = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESum: {
          V v_ru_24d111_2423_24ESum = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EStruct: {
          V v_ru_24d111_2423_24EStruct = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EUpdate: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EMatch: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELetIn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EDo: {
          V v_ru_24d111_2423_24EDo = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELocal: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInvalid: {
          V v_ru_24d111_2423_24EInvalid = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        default: return heff_nomatch(v_d111_2423);
        }
      }
      default: return heff_nomatch(v_d11_2421);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESig: {
      V v_ru_24d1_241_24ESig = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESum: {
      V v_ru_24d1_241_24ESum = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EStruct: {
      V v_ru_24d1_241_24EStruct = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EUpdate: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELetIn: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EDo: {
      V v_ru_24d1_241_24EDo = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELocal: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInvalid: {
      V v_ru_24d1_241_24EInvalid = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplainBinder(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eopRhsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eopRhsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eopRhsOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    V v_t_242 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_e_240});
  }
  case TAG_EParen: {
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_e_240});
  }
  case TAG_Named: {
    V v_t_2412 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_e_240});
  }
  case TAG_Tup: {
    V v_t_2417 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_e_240});
  }
  case TAG_Braces: {
    V v_t_2422 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_e_240});
  }
  case TAG_Update: {
    V v_t_2429 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_e_240});
  }
  case TAG_EUSet: {
    V v_t_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_e_240});
  }
  case TAG_InstB: {
    V v_t_2439 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_e_240});
  }
  case TAG_EFSet: {
    V v_t_2443 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_e_240});
  }
  case TAG_EFDefault: {
    V v_t_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, v_e_240});
  }
  case TAG_Sum: {
    V v_t_2453 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_e_240});
  }
  case TAG_ECon: {
    V v_t_2456 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_e_240});
  }
  case TAG_EField: {
    V v_t_2459 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_e_240});
  }
  case TAG_ENeg: {
    V v_t_2462 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_e_240});
  }
  case TAG_App: {
    V v_t_2465 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_e_240});
  }
  case TAG_Op: {
    V v_t_2469 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_e_240});
  }
  case TAG_Ops: {
    V v_t_2472 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2472, v_e_240});
  }
  case TAG_OpRhs: {
    V v_op_2473 = heff_field(v_e_240, 0);
    V v_e2_2474 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24OpRhs = heff_take_reuse_n(v_e_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24OpRhs, TAG_MkPair, 2, (V[]){v_op_2473, v_e2_2474});
  }
  case TAG_Ann: {
    V v_t_2478 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_e_240});
  }
  case TAG_BVar: {
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_e_240});
  }
  case TAG_BImp: {
    V v_t_2484 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, v_e_240});
  }
  case TAG_BAnn: {
    V v_t_2490 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2490, v_e_240});
  }
  case TAG_Lam: {
    V v_t_2495 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2495, v_e_240});
  }
  case TAG_Case: {
    V v_t_24100 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24100, v_e_240});
  }
  case TAG_EAlt: {
    V v_t_24104 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24104, v_e_240});
  }
  case TAG_If: {
    V v_t_24111 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24111, v_e_240});
  }
  case TAG_Do: {
    V v_t_24114 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24114, v_e_240});
  }
  case TAG_ESBind: {
    V v_t_24118 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24118, v_e_240});
  }
  case TAG_ELet: {
    V v_t_24125 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24125, v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2eopRhsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eopRhsOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedOne_str0, 2, ":=");
Clo g_heff_2esyntax_2esurface_2ebracedOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracedOne_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ebracedOne(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EParen: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Named: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Tup: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Braces: {
    V v_x12_2415 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2415)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_f_2418 = heff_field(v_x12_2415, 0);
      V v_x122_2419 = heff_field(v_x12_2415, 1);
      switch (heff_tag_of(v_x122_2419)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_f_2418)) {
        case TAG_Atom: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_EParen: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Named: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Tup: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Braces: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Update: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_EUSet: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_InstB: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_EFSet: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EFDefault: {
          V v_eq_2455 = heff_field(v_f_2418, 1);
          if (heff_strEq_c(heff_dup(heff_rfield(v_eq_2455, 1)), ((V)&g_heff_2esyntax_2esurface_2ebracedOne_str0))) {
            return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
          } else {
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Sum: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_ECon: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_EField: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_ENeg: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_App: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Op: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Ops: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_OpRhs: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Ann: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_BVar: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_BImp: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_BAnn: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Lam: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Case: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_EAlt: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_If: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_Do: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_ESBind: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        case TAG_ELet: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2418)});
        }
        default: return heff_nomatch(v_f_2418);
        }
      }
      case TAG_Cons: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x122_2419);
      }
    }
    default: return heff_nomatch(v_x12_2415);
    }
  }
  case TAG_Update: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EUSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_InstB: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Sum: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ECon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EField: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ENeg: {
    return NTAG(TAG_Nothing);
  }
  case TAG_App: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Op: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ops: {
    return NTAG(TAG_Nothing);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ann: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BVar: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BImp: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BAnn: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Lam: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Case: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EAlt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_If: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Do: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ESBind: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ebracedOne(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str6, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str7, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2eatomTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eatomTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eatomTok(V v_t_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str0))) {
    V v_t_242 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str1))) {
      V v_t_245 = (g_heff_2esyntax_2esurface_2eintOfText(heff_take_field(v_t_240, 1)));
      V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_245}), v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str2))) {
        V v_x2_248 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2esurface_2eatomTok_str3), heff_take_field(v_t_240, 1), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2411;
        switch (heff_tag_of(v_x2_248)) {
        case TAG_Nil: {
          v_t_2411 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x2_248, 0);
          V v_xs_2410 = heff_field(v_x2_248, 1);
          heff_take_n(v_x2_248, 3ULL, 2);
          v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
          break;
        }
        default: heff_nomatch(v_x2_248);
        }
        double v_t_2412 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_2411));
        V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EFloat, 1, (V[]){heff_box_f64(v_t_2412)}), v_t_2413});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str6))) {
          V v_t_2415 = heff_tag_n(TAG_EString, 1, (V[]){heff_take_field(v_t_240, 1)});
          V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str7))) {
            V v_t_2418 = heff_tag_n(TAG_EBytes, 1, (V[]){heff_take_field(v_t_240, 1)});
            V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419});
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str8))) {
              V v_t_2421 = heff_strRuneAt(heff_take_field(v_t_240, 1), MK_INT(0LL));
              V v_t_2422 = heff_tag_n(TAG_ERune, 1, (V[]){heff_runeToInt(v_t_2421)});
              V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423});
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str9))) {
                V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
                V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2426});
              } else {
                V v_t_2427 = (g_heff_2esyntax_2esurface_2ewordKw(heff_take_field(v_t_240, 1)));
                V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWord, 1, (V[]){v_t_2427}), v_t_2428});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eatomTok(a[0]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2estmtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2estmtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2estmtL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Braces: {
    V v_m_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam4, 1, 1, (V[]){v_m_2463});
  }
  case TAG_Update: {
    V v_m_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam5, 1, 1, (V[]){v_m_2480});
  }
  case TAG_EUSet: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_InstB: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam7, 1, 1, (V[]){v_m_24110});
  }
  case TAG_EFSet: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFDefault: {
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam9, 1, 1, (V[]){v_m_24138});
  }
  case TAG_Sum: {
    V v_m_24154 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam10, 1, 1, (V[]){v_m_24154});
  }
  case TAG_ECon: {
    V v_m_24167 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam11, 1, 1, (V[]){v_m_24167});
  }
  case TAG_EField: {
    V v_m_24180 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam12, 1, 1, (V[]){v_m_24180});
  }
  case TAG_ENeg: {
    V v_m_24193 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam13, 1, 1, (V[]){v_m_24193});
  }
  case TAG_App: {
    V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam14, 1, 1, (V[]){v_m_24206});
  }
  case TAG_Op: {
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam15, 1, 1, (V[]){v_m_24220});
  }
  case TAG_Ops: {
    V v_m_24233 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam16, 1, 1, (V[]){v_m_24233});
  }
  case TAG_OpRhs: {
    V v_m_24246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam17, 1, 1, (V[]){v_m_24246});
  }
  case TAG_Ann: {
    V v_m_24260 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam18, 1, 1, (V[]){v_m_24260});
  }
  case TAG_BVar: {
    V v_m_24272 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam19, 1, 1, (V[]){v_m_24272});
  }
  case TAG_BImp: {
    V v_m_24286 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam20, 1, 1, (V[]){v_m_24286});
  }
  case TAG_BAnn: {
    V v_m_24302 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam21, 1, 1, (V[]){v_m_24302});
  }
  case TAG_Lam: {
    V v_m_24317 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam22, 1, 1, (V[]){v_m_24317});
  }
  case TAG_Case: {
    V v_m_24332 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam23, 1, 1, (V[]){v_m_24332});
  }
  case TAG_EAlt: {
    V v_m_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam24, 1, 1, (V[]){v_m_24346});
  }
  case TAG_If: {
    V v_m_24363 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam25, 1, 1, (V[]){v_m_24363});
  }
  case TAG_Do: {
    V v_m_24376 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam26, 1, 1, (V[]){v_m_24376});
  }
  case TAG_ESBind: {
    V v_x_24387 = heff_field(v_e_241, 0);
    V v_e3_24389 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 5ULL, 3);
    V v_m_24390 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e3_24389}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam27, 1, 2, (V[]){v_m_24390, v_x_24387});
  }
  case TAG_ELet: {
    V v_kw_24406 = heff_dup(heff_field(v_e_241, 0));
    V v_p_24407 = heff_dup(heff_field(v_e_241, 1));
    V v_ann0_24408 = heff_dup(heff_field(v_e_241, 2));
    V v_e5_24410 = heff_dup(heff_field(v_e_241, 4));
    V v_e6_24411 = heff_dup(heff_field(v_e_241, 5));
    switch (heff_tag_of(v_e6_24411)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_241, 6);
      V v_m_24412 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_dup(v_p_24407), v_ann0_24408, heff_dup(v_e5_24410)));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam28, 1, 4, (V[]){v_m_24412, v_p_24407, v_e5_24410, v_kw_24406});
    }
    case TAG_Just: {
      heff_take_n(v_e6_24411, 0ULL, 1);
      heff_drop_rec(v_kw_24406, 9);
      heff_drop(v_p_24407);
      heff_drop(v_ann0_24408);
      heff_drop(v_e5_24410);
      V v_m_24438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam29, 1, 1, (V[]){v_m_24438});
    }
    default: return heff_nomatch(v_e6_24411);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2estmtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_x_2413 = heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_x_2427 = heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){v_x_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_x_2443 = heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_Right, 1, (V[]){v_x_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_x_2458 = heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Right, 1, (V[]){v_x_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args) {
  V v_st_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_st_2464}));
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_MkPair: {
    V v_x11_2466 = heff_field(v_x1_2465, 0);
    V v_st_2467 = heff_field(v_x1_2465, 1);
    V v_ru_24x1_2465_24MkPair = heff_take_reuse_n(v_x1_2465, 3ULL, 2);
    switch (heff_tag_of(v_x11_2466)) {
    case TAG_Left: {
      V v_e_2468 = heff_field(v_x11_2466, 0);
      heff_take_n(v_x11_2466, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2468}), v_st_2467});
    }
    case TAG_Right: {
      V v_x_2469 = heff_field(v_x11_2466, 0);
      V v_ru_24x11_2466_24Right = heff_take_reuse_n(v_x11_2466, 1ULL, 1);
      V v_t_2472;
      switch (heff_tag_of(v_x_2469)) {
      case TAG_At: {
        V v_s_2471 = heff_dup(heff_field(v_x_2469, 1));
        v_t_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_x_2469);
      }
      V v_x_2473 = heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2469}), v_t_2472});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2466_24Right, TAG_Right, 1, (V[]){v_x_2473}), v_st_2467});
    }
    default: return heff_nomatch(v_x11_2466);
    }
  }
  default: return heff_nomatch(v_x1_2465);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args) {
  V v_st_2481 = args[0];
  V v_m_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2482 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_st_2481}));
  switch (heff_tag_of(v_x1_2482)) {
  case TAG_MkPair: {
    V v_x11_2483 = heff_field(v_x1_2482, 0);
    V v_st_2484 = heff_field(v_x1_2482, 1);
    V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
    switch (heff_tag_of(v_x11_2483)) {
    case TAG_Left: {
      V v_e_2485 = heff_field(v_x11_2483, 0);
      heff_take_n(v_x11_2483, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
    }
    case TAG_Right: {
      V v_x_2486 = heff_field(v_x11_2483, 0);
      V v_ru_24x11_2483_24Right = heff_take_reuse_n(v_x11_2483, 1ULL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_x_2486)) {
      case TAG_At: {
        V v_s_2488 = heff_dup(heff_field(v_x_2486, 1));
        v_t_2489 = v_s_2488;
        break;
      }
      default: heff_nomatch(v_x_2486);
      }
      V v_x_2490 = heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2486}), v_t_2489});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2483_24Right, TAG_Right, 1, (V[]){v_x_2490}), v_st_2484});
    }
    default: return heff_nomatch(v_x11_2483);
    }
  }
  default: return heff_nomatch(v_x1_2482);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_x_24104 = heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_Right, 1, (V[]){v_x_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args) {
  V v_st_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_st_24111}));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      V v_ru_24x11_24113_24Right = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
      V v_t_24119;
      switch (heff_tag_of(v_x_24116)) {
      case TAG_At: {
        V v_s_24118 = heff_dup(heff_field(v_x_24116, 1));
        v_t_24119 = v_s_24118;
        break;
      }
      default: heff_nomatch(v_x_24116);
      }
      V v_x_24120 = heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24116}), v_t_24119});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24113_24Right, TAG_Right, 1, (V[]){v_x_24120}), v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_x_24134 = heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_Right, 1, (V[]){v_x_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24147;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_At: {
        V v_s_24146 = heff_dup(heff_field(v_x_24144, 1));
        v_t_24147 = v_s_24146;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_x_24148 = heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24144}), v_t_24147});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_Right, 1, (V[]){v_x_24148}), v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args) {
  V v_st_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_st_24155}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_MkPair: {
    V v_x11_24157 = heff_field(v_x1_24156, 0);
    V v_st_24158 = heff_field(v_x1_24156, 1);
    V v_ru_24x1_24156_24MkPair = heff_take_reuse_n(v_x1_24156, 3ULL, 2);
    switch (heff_tag_of(v_x11_24157)) {
    case TAG_Left: {
      V v_e_24159 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24159}), v_st_24158});
    }
    case TAG_Right: {
      V v_x_24160 = heff_field(v_x11_24157, 0);
      V v_ru_24x11_24157_24Right = heff_take_reuse_n(v_x11_24157, 1ULL, 1);
      V v_t_24163;
      switch (heff_tag_of(v_x_24160)) {
      case TAG_At: {
        V v_s_24162 = heff_dup(heff_field(v_x_24160, 1));
        v_t_24163 = v_s_24162;
        break;
      }
      default: heff_nomatch(v_x_24160);
      }
      V v_x_24164 = heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24160}), v_t_24163});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24157_24Right, TAG_Right, 1, (V[]){v_x_24164}), v_st_24158});
    }
    default: return heff_nomatch(v_x11_24157);
    }
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args) {
  V v_st_24168 = args[0];
  V v_m_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24169 = heff_tr(heff_call(v_m_24167, 1, (V[]){v_st_24168}));
  switch (heff_tag_of(v_x1_24169)) {
  case TAG_MkPair: {
    V v_x11_24170 = heff_field(v_x1_24169, 0);
    V v_st_24171 = heff_field(v_x1_24169, 1);
    V v_ru_24x1_24169_24MkPair = heff_take_reuse_n(v_x1_24169, 3ULL, 2);
    switch (heff_tag_of(v_x11_24170)) {
    case TAG_Left: {
      V v_e_24172 = heff_field(v_x11_24170, 0);
      heff_take_n(v_x11_24170, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24172}), v_st_24171});
    }
    case TAG_Right: {
      V v_x_24173 = heff_field(v_x11_24170, 0);
      V v_ru_24x11_24170_24Right = heff_take_reuse_n(v_x11_24170, 1ULL, 1);
      V v_t_24176;
      switch (heff_tag_of(v_x_24173)) {
      case TAG_At: {
        V v_s_24175 = heff_dup(heff_field(v_x_24173, 1));
        v_t_24176 = v_s_24175;
        break;
      }
      default: heff_nomatch(v_x_24173);
      }
      V v_x_24177 = heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24173}), v_t_24176});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24170_24Right, TAG_Right, 1, (V[]){v_x_24177}), v_st_24171});
    }
    default: return heff_nomatch(v_x11_24170);
    }
  }
  default: return heff_nomatch(v_x1_24169);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args) {
  V v_st_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_st_24181}));
  switch (heff_tag_of(v_x1_24182)) {
  case TAG_MkPair: {
    V v_x11_24183 = heff_field(v_x1_24182, 0);
    V v_st_24184 = heff_field(v_x1_24182, 1);
    V v_ru_24x1_24182_24MkPair = heff_take_reuse_n(v_x1_24182, 3ULL, 2);
    switch (heff_tag_of(v_x11_24183)) {
    case TAG_Left: {
      V v_e_24185 = heff_field(v_x11_24183, 0);
      heff_take_n(v_x11_24183, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24185}), v_st_24184});
    }
    case TAG_Right: {
      V v_x_24186 = heff_field(v_x11_24183, 0);
      V v_ru_24x11_24183_24Right = heff_take_reuse_n(v_x11_24183, 1ULL, 1);
      V v_t_24189;
      switch (heff_tag_of(v_x_24186)) {
      case TAG_At: {
        V v_s_24188 = heff_dup(heff_field(v_x_24186, 1));
        v_t_24189 = v_s_24188;
        break;
      }
      default: heff_nomatch(v_x_24186);
      }
      V v_x_24190 = heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24186}), v_t_24189});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24183_24Right, TAG_Right, 1, (V[]){v_x_24190}), v_st_24184});
    }
    default: return heff_nomatch(v_x11_24183);
    }
  }
  default: return heff_nomatch(v_x1_24182);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args) {
  V v_st_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_st_24194}));
  switch (heff_tag_of(v_x1_24195)) {
  case TAG_MkPair: {
    V v_x11_24196 = heff_field(v_x1_24195, 0);
    V v_st_24197 = heff_field(v_x1_24195, 1);
    V v_ru_24x1_24195_24MkPair = heff_take_reuse_n(v_x1_24195, 3ULL, 2);
    switch (heff_tag_of(v_x11_24196)) {
    case TAG_Left: {
      V v_e_24198 = heff_field(v_x11_24196, 0);
      heff_take_n(v_x11_24196, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24198}), v_st_24197});
    }
    case TAG_Right: {
      V v_x_24199 = heff_field(v_x11_24196, 0);
      V v_ru_24x11_24196_24Right = heff_take_reuse_n(v_x11_24196, 1ULL, 1);
      V v_t_24202;
      switch (heff_tag_of(v_x_24199)) {
      case TAG_At: {
        V v_s_24201 = heff_dup(heff_field(v_x_24199, 1));
        v_t_24202 = v_s_24201;
        break;
      }
      default: heff_nomatch(v_x_24199);
      }
      V v_x_24203 = heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24199}), v_t_24202});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24196_24Right, TAG_Right, 1, (V[]){v_x_24203}), v_st_24197});
    }
    default: return heff_nomatch(v_x11_24196);
    }
  }
  default: return heff_nomatch(v_x1_24195);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args) {
  V v_st_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_st_24207}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      V v_ru_24x11_24209_24Right = heff_take_reuse_n(v_x11_24209, 1ULL, 1);
      V v_t_24215;
      switch (heff_tag_of(v_x_24212)) {
      case TAG_At: {
        V v_s_24214 = heff_dup(heff_field(v_x_24212, 1));
        v_t_24215 = v_s_24214;
        break;
      }
      default: heff_nomatch(v_x_24212);
      }
      V v_x_24216 = heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24212}), v_t_24215});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24209_24Right, TAG_Right, 1, (V[]){v_x_24216}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args) {
  V v_st_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_st_24221}));
  switch (heff_tag_of(v_x1_24222)) {
  case TAG_MkPair: {
    V v_x11_24223 = heff_field(v_x1_24222, 0);
    V v_st_24224 = heff_field(v_x1_24222, 1);
    V v_ru_24x1_24222_24MkPair = heff_take_reuse_n(v_x1_24222, 3ULL, 2);
    switch (heff_tag_of(v_x11_24223)) {
    case TAG_Left: {
      V v_e_24225 = heff_field(v_x11_24223, 0);
      heff_take_n(v_x11_24223, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24225}), v_st_24224});
    }
    case TAG_Right: {
      V v_x_24226 = heff_field(v_x11_24223, 0);
      V v_ru_24x11_24223_24Right = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
      V v_t_24229;
      switch (heff_tag_of(v_x_24226)) {
      case TAG_At: {
        V v_s_24228 = heff_dup(heff_field(v_x_24226, 1));
        v_t_24229 = v_s_24228;
        break;
      }
      default: heff_nomatch(v_x_24226);
      }
      V v_x_24230 = heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24226}), v_t_24229});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24223_24Right, TAG_Right, 1, (V[]){v_x_24230}), v_st_24224});
    }
    default: return heff_nomatch(v_x11_24223);
    }
  }
  default: return heff_nomatch(v_x1_24222);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args) {
  V v_st_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_st_24234}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_MkPair: {
    V v_x11_24236 = heff_field(v_x1_24235, 0);
    V v_st_24237 = heff_field(v_x1_24235, 1);
    V v_ru_24x1_24235_24MkPair = heff_take_reuse_n(v_x1_24235, 3ULL, 2);
    switch (heff_tag_of(v_x11_24236)) {
    case TAG_Left: {
      V v_e_24238 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24238}), v_st_24237});
    }
    case TAG_Right: {
      V v_x_24239 = heff_field(v_x11_24236, 0);
      V v_ru_24x11_24236_24Right = heff_take_reuse_n(v_x11_24236, 1ULL, 1);
      V v_t_24242;
      switch (heff_tag_of(v_x_24239)) {
      case TAG_At: {
        V v_s_24241 = heff_dup(heff_field(v_x_24239, 1));
        v_t_24242 = v_s_24241;
        break;
      }
      default: heff_nomatch(v_x_24239);
      }
      V v_x_24243 = heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24239}), v_t_24242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24236_24Right, TAG_Right, 1, (V[]){v_x_24243}), v_st_24237});
    }
    default: return heff_nomatch(v_x11_24236);
    }
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args) {
  V v_st_24247 = args[0];
  V v_m_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24248 = heff_tr(heff_call(v_m_24246, 1, (V[]){v_st_24247}));
  switch (heff_tag_of(v_x1_24248)) {
  case TAG_MkPair: {
    V v_x11_24249 = heff_field(v_x1_24248, 0);
    V v_st_24250 = heff_field(v_x1_24248, 1);
    V v_ru_24x1_24248_24MkPair = heff_take_reuse_n(v_x1_24248, 3ULL, 2);
    switch (heff_tag_of(v_x11_24249)) {
    case TAG_Left: {
      V v_e_24251 = heff_field(v_x11_24249, 0);
      heff_take_n(v_x11_24249, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24251}), v_st_24250});
    }
    case TAG_Right: {
      V v_x_24252 = heff_field(v_x11_24249, 0);
      V v_ru_24x11_24249_24Right = heff_take_reuse_n(v_x11_24249, 1ULL, 1);
      V v_t_24255;
      switch (heff_tag_of(v_x_24252)) {
      case TAG_At: {
        V v_s_24254 = heff_dup(heff_field(v_x_24252, 1));
        v_t_24255 = v_s_24254;
        break;
      }
      default: heff_nomatch(v_x_24252);
      }
      V v_x_24256 = heff_tag_at_n(v_ru_24x1_24248_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24252}), v_t_24255});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24249_24Right, TAG_Right, 1, (V[]){v_x_24256}), v_st_24250});
    }
    default: return heff_nomatch(v_x11_24249);
    }
  }
  default: return heff_nomatch(v_x1_24248);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
      V v_t_24269;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24268 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24269 = v_s_24268;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_x_24270 = heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24266}), v_t_24269});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Right, 1, (V[]){v_x_24270}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      V v_ru_24x11_24275_24Right = heff_take_reuse_n(v_x11_24275, 1ULL, 1);
      V v_t_24281;
      switch (heff_tag_of(v_x_24278)) {
      case TAG_At: {
        V v_s_24280 = heff_dup(heff_field(v_x_24278, 1));
        v_t_24281 = v_s_24280;
        break;
      }
      default: heff_nomatch(v_x_24278);
      }
      V v_x_24282 = heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24278}), v_t_24281});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24275_24Right, TAG_Right, 1, (V[]){v_x_24282}), v_st_24276});
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args) {
  V v_st_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_st_24287}));
  switch (heff_tag_of(v_x1_24288)) {
  case TAG_MkPair: {
    V v_x11_24289 = heff_field(v_x1_24288, 0);
    V v_st_24290 = heff_field(v_x1_24288, 1);
    V v_ru_24x1_24288_24MkPair = heff_take_reuse_n(v_x1_24288, 3ULL, 2);
    switch (heff_tag_of(v_x11_24289)) {
    case TAG_Left: {
      V v_e_24291 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
    }
    case TAG_Right: {
      V v_x_24292 = heff_field(v_x11_24289, 0);
      V v_ru_24x11_24289_24Right = heff_take_reuse_n(v_x11_24289, 1ULL, 1);
      V v_t_24295;
      switch (heff_tag_of(v_x_24292)) {
      case TAG_At: {
        V v_s_24294 = heff_dup(heff_field(v_x_24292, 1));
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_x_24292);
      }
      V v_x_24296 = heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24292}), v_t_24295});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24289_24Right, TAG_Right, 1, (V[]){v_x_24296}), v_st_24290});
    }
    default: return heff_nomatch(v_x11_24289);
    }
  }
  default: return heff_nomatch(v_x1_24288);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args) {
  V v_st_24303 = args[0];
  V v_m_24302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24304 = heff_tr(heff_call(v_m_24302, 1, (V[]){v_st_24303}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_MkPair: {
    V v_x11_24305 = heff_field(v_x1_24304, 0);
    V v_st_24306 = heff_field(v_x1_24304, 1);
    V v_ru_24x1_24304_24MkPair = heff_take_reuse_n(v_x1_24304, 3ULL, 2);
    switch (heff_tag_of(v_x11_24305)) {
    case TAG_Left: {
      V v_e_24307 = heff_field(v_x11_24305, 0);
      heff_take_n(v_x11_24305, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24304_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24307}), v_st_24306});
    }
    case TAG_Right: {
      V v_x_24308 = heff_field(v_x11_24305, 0);
      V v_ru_24x11_24305_24Right = heff_take_reuse_n(v_x11_24305, 1ULL, 1);
      V v_t_24311;
      switch (heff_tag_of(v_x_24308)) {
      case TAG_At: {
        V v_s_24310 = heff_dup(heff_field(v_x_24308, 1));
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_x_24308);
      }
      V v_x_24312 = heff_tag_at_n(v_ru_24x1_24304_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24308}), v_t_24311});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24305_24Right, TAG_Right, 1, (V[]){v_x_24312}), v_st_24306});
    }
    default: return heff_nomatch(v_x11_24305);
    }
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args) {
  V v_st_24318 = args[0];
  V v_m_24317 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24319 = heff_tr(heff_call(v_m_24317, 1, (V[]){v_st_24318}));
  switch (heff_tag_of(v_x1_24319)) {
  case TAG_MkPair: {
    V v_x11_24320 = heff_field(v_x1_24319, 0);
    V v_st_24321 = heff_field(v_x1_24319, 1);
    V v_ru_24x1_24319_24MkPair = heff_take_reuse_n(v_x1_24319, 3ULL, 2);
    switch (heff_tag_of(v_x11_24320)) {
    case TAG_Left: {
      V v_e_24322 = heff_field(v_x11_24320, 0);
      heff_take_n(v_x11_24320, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24319_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24322}), v_st_24321});
    }
    case TAG_Right: {
      V v_x_24323 = heff_field(v_x11_24320, 0);
      V v_ru_24x11_24320_24Right = heff_take_reuse_n(v_x11_24320, 1ULL, 1);
      V v_t_24326;
      switch (heff_tag_of(v_x_24323)) {
      case TAG_At: {
        V v_s_24325 = heff_dup(heff_field(v_x_24323, 1));
        v_t_24326 = v_s_24325;
        break;
      }
      default: heff_nomatch(v_x_24323);
      }
      V v_x_24327 = heff_tag_at_n(v_ru_24x1_24319_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24323}), v_t_24326});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24320_24Right, TAG_Right, 1, (V[]){v_x_24327}), v_st_24321});
    }
    default: return heff_nomatch(v_x11_24320);
    }
  }
  default: return heff_nomatch(v_x1_24319);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args) {
  V v_st_24333 = args[0];
  V v_m_24332 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24334 = heff_tr(heff_call(v_m_24332, 1, (V[]){v_st_24333}));
  switch (heff_tag_of(v_x1_24334)) {
  case TAG_MkPair: {
    V v_x11_24335 = heff_field(v_x1_24334, 0);
    V v_st_24336 = heff_field(v_x1_24334, 1);
    V v_ru_24x1_24334_24MkPair = heff_take_reuse_n(v_x1_24334, 3ULL, 2);
    switch (heff_tag_of(v_x11_24335)) {
    case TAG_Left: {
      V v_e_24337 = heff_field(v_x11_24335, 0);
      heff_take_n(v_x11_24335, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24334_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24337}), v_st_24336});
    }
    case TAG_Right: {
      V v_x_24338 = heff_field(v_x11_24335, 0);
      V v_ru_24x11_24335_24Right = heff_take_reuse_n(v_x11_24335, 1ULL, 1);
      V v_t_24341;
      switch (heff_tag_of(v_x_24338)) {
      case TAG_At: {
        V v_s_24340 = heff_dup(heff_field(v_x_24338, 1));
        v_t_24341 = v_s_24340;
        break;
      }
      default: heff_nomatch(v_x_24338);
      }
      V v_x_24342 = heff_tag_at_n(v_ru_24x1_24334_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24338}), v_t_24341});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24335_24Right, TAG_Right, 1, (V[]){v_x_24342}), v_st_24336});
    }
    default: return heff_nomatch(v_x11_24335);
    }
  }
  default: return heff_nomatch(v_x1_24334);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args) {
  V v_st_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_st_24347}));
  switch (heff_tag_of(v_x1_24348)) {
  case TAG_MkPair: {
    V v_x11_24349 = heff_field(v_x1_24348, 0);
    V v_st_24350 = heff_field(v_x1_24348, 1);
    V v_ru_24x1_24348_24MkPair = heff_take_reuse_n(v_x1_24348, 3ULL, 2);
    switch (heff_tag_of(v_x11_24349)) {
    case TAG_Left: {
      V v_e_24351 = heff_field(v_x11_24349, 0);
      heff_take_n(v_x11_24349, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24351}), v_st_24350});
    }
    case TAG_Right: {
      V v_x_24352 = heff_field(v_x11_24349, 0);
      V v_ru_24x11_24349_24Right = heff_take_reuse_n(v_x11_24349, 1ULL, 1);
      V v_t_24355;
      switch (heff_tag_of(v_x_24352)) {
      case TAG_At: {
        V v_s_24354 = heff_dup(heff_field(v_x_24352, 1));
        v_t_24355 = v_s_24354;
        break;
      }
      default: heff_nomatch(v_x_24352);
      }
      V v_x_24356 = heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24352}), v_t_24355});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24349_24Right, TAG_Right, 1, (V[]){v_x_24356}), v_st_24350});
    }
    default: return heff_nomatch(v_x11_24349);
    }
  }
  default: return heff_nomatch(v_x1_24348);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args) {
  V v_st_24364 = args[0];
  V v_m_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24365 = heff_tr(heff_call(v_m_24363, 1, (V[]){v_st_24364}));
  switch (heff_tag_of(v_x1_24365)) {
  case TAG_MkPair: {
    V v_x11_24366 = heff_field(v_x1_24365, 0);
    V v_st_24367 = heff_field(v_x1_24365, 1);
    V v_ru_24x1_24365_24MkPair = heff_take_reuse_n(v_x1_24365, 3ULL, 2);
    switch (heff_tag_of(v_x11_24366)) {
    case TAG_Left: {
      V v_e_24368 = heff_field(v_x11_24366, 0);
      heff_take_n(v_x11_24366, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24365_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24368}), v_st_24367});
    }
    case TAG_Right: {
      V v_x_24369 = heff_field(v_x11_24366, 0);
      V v_ru_24x11_24366_24Right = heff_take_reuse_n(v_x11_24366, 1ULL, 1);
      V v_t_24372;
      switch (heff_tag_of(v_x_24369)) {
      case TAG_At: {
        V v_s_24371 = heff_dup(heff_field(v_x_24369, 1));
        v_t_24372 = v_s_24371;
        break;
      }
      default: heff_nomatch(v_x_24369);
      }
      V v_x_24373 = heff_tag_at_n(v_ru_24x1_24365_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24369}), v_t_24372});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24366_24Right, TAG_Right, 1, (V[]){v_x_24373}), v_st_24367});
    }
    default: return heff_nomatch(v_x11_24366);
    }
  }
  default: return heff_nomatch(v_x1_24365);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args) {
  V v_st_24377 = args[0];
  V v_m_24376 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24378 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_st_24377}));
  switch (heff_tag_of(v_x1_24378)) {
  case TAG_MkPair: {
    V v_x11_24379 = heff_field(v_x1_24378, 0);
    V v_st_24380 = heff_field(v_x1_24378, 1);
    V v_ru_24x1_24378_24MkPair = heff_take_reuse_n(v_x1_24378, 3ULL, 2);
    switch (heff_tag_of(v_x11_24379)) {
    case TAG_Left: {
      V v_e_24381 = heff_field(v_x11_24379, 0);
      heff_take_n(v_x11_24379, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24378_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24381}), v_st_24380});
    }
    case TAG_Right: {
      V v_x_24382 = heff_field(v_x11_24379, 0);
      V v_ru_24x11_24379_24Right = heff_take_reuse_n(v_x11_24379, 1ULL, 1);
      V v_t_24385;
      switch (heff_tag_of(v_x_24382)) {
      case TAG_At: {
        V v_s_24384 = heff_dup(heff_field(v_x_24382, 1));
        v_t_24385 = v_s_24384;
        break;
      }
      default: heff_nomatch(v_x_24382);
      }
      V v_x_24386 = heff_tag_at_n(v_ru_24x1_24378_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24382}), v_t_24385});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24379_24Right, TAG_Right, 1, (V[]){v_x_24386}), v_st_24380});
    }
    default: return heff_nomatch(v_x11_24379);
    }
  }
  default: return heff_nomatch(v_x1_24378);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args) {
  V v_st_24391 = args[0];
  V v_m_24390 = heff_env(self)[0];
  V v_x_24387 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24392 = heff_tr(heff_call(v_m_24390, 1, (V[]){v_st_24391}));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      heff_drop_rec(v_x_24387, 9);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      V v_ru_24x11_24393_24Right = heff_take_reuse_n(v_x11_24393, 1ULL, 1);
      V v_t_24397 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24387, 3)), heff_take_field(v_x_24387, 4)});
      V v_t_24398 = heff_tag_n(TAG_StmtBind, 3, (V[]){heff_dup(heff_rfield(v_x_24387, 1)), v_t_24397, heff_dup(v_x_24396)});
      V v_b_24401;
      switch (heff_tag_of(v_x_24396)) {
      case TAG_At: {
        V v_s_24400 = heff_field(v_x_24396, 1);
        heff_take_n(v_x_24396, 2ULL, 2);
        v_b_24401 = v_s_24400;
        break;
      }
      default: heff_nomatch(v_x_24396);
      }
      V v_t_24402 = ({ V rv_0 = heff_take_field(v_x_24387, 3); V rr_ = heff_rec_reuse_nf(v_b_24401, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_24403 = heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_At, 2, (V[]){v_t_24398, v_t_24402});
      V v_t_24404 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24387, 1, 9), heff_take_field(v_st_24394, 1)});
      V v_t_24405 = ({ V rv_1 = v_t_24404; V rr_ = heff_rec_reuse_nf(v_st_24394, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24393_24Right, TAG_Right, 1, (V[]){v_x_24403}), v_t_24405});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args) {
  V v_st_24413 = args[0];
  V v_m_24412 = heff_env(self)[0];
  V v_p_24407 = heff_env(self)[1];
  V v_e5_24410 = heff_env(self)[2];
  V v_kw_24406 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24414 = heff_tr(heff_call(v_m_24412, 1, (V[]){v_st_24413}));
  switch (heff_tag_of(v_x1_24414)) {
  case TAG_MkPair: {
    V v_x11_24415 = heff_field(v_x1_24414, 0);
    V v_st_24416 = heff_field(v_x1_24414, 1);
    V v_ru_24x1_24414_24MkPair = heff_take_reuse_n(v_x1_24414, 3ULL, 2);
    switch (heff_tag_of(v_x11_24415)) {
    case TAG_Left: {
      V v_e_24417 = heff_field(v_x11_24415, 0);
      heff_take_n(v_x11_24415, 1ULL, 1);
      heff_drop(v_p_24407);
      heff_drop(v_e5_24410);
      heff_drop_rec(v_kw_24406, 9);
      return heff_tag_at_n(v_ru_24x1_24414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24417}), v_st_24416});
    }
    case TAG_Right: {
      V v_x_24418 = heff_field(v_x11_24415, 0);
      V v_ru_24x11_24415_24Right = heff_take_reuse_n(v_x11_24415, 1ULL, 1);
      V v_t_24419 = heff_tag_at_n(v_ru_24x11_24415_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_sc_24420 = ({ V a_0 = heff_take_field(v_st_24416, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24407; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24407); r_; });
      V v_t_24421 = ({ V rv_1 = v_sc_24420; V rr_ = heff_rec_reuse_nf(v_st_24416, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x1_24422 = heff_tag_at_n(v_ru_24x1_24414_24MkPair, TAG_MkPair, 2, (V[]){v_t_24419, v_t_24421});
      switch (heff_tag_of(v_x1_24422)) {
      case TAG_MkPair: {
        V v_x11_24423 = heff_field(v_x1_24422, 0);
        V v_st_24424 = heff_field(v_x1_24422, 1);
        V v_ru_24x1_24422_24MkPair = heff_take_reuse_n(v_x1_24422, 3ULL, 2);
        switch (heff_tag_of(v_x11_24423)) {
        case TAG_Left: {
          V v_e_24425 = heff_field(v_x11_24423, 0);
          heff_take_n(v_x11_24423, 1ULL, 1);
          heff_drop(v_e5_24410);
          heff_drop_rec(v_kw_24406, 9);
          heff_drop(v_x_24418);
          return heff_tag_at_n(v_ru_24x1_24422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24425}), v_st_24424});
        }
        case TAG_Right: {
          V v_ru_24x11_24423_24Right = heff_take_reuse_n(v_x11_24423, 0ULL, 1);
          V v_t_24429;
          switch (heff_tag_of(v_x_24418)) {
          case TAG_MkPair: {
            V v_x_24427 = heff_dup(heff_field(v_x_24418, 0));
            v_t_24429 = v_x_24427;
            break;
          }
          default: heff_nomatch(v_x_24418);
          }
          V v_t_24432;
          switch (heff_tag_of(v_x_24418)) {
          case TAG_MkPair: {
            V v_y_24431 = heff_field(v_x_24418, 1);
            heff_take_n(v_x_24418, 2ULL, 2);
            v_t_24432 = v_y_24431;
            break;
          }
          default: heff_nomatch(v_x_24418);
          }
          V v_t_24433 = (g_heff_2esyntax_2ecst_2elastE(v_e5_24410));
          V v_e_24434 = heff_get_n(v_t_24433, 4, 9);
          V v_t_24435 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24406, 3, 9), v_e_24434});
          V v_x_24436 = heff_tag_at_n(v_ru_24x1_24422_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_t_24429, v_t_24432}), v_t_24435});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24423_24Right, TAG_Right, 1, (V[]){v_x_24436}), v_st_24424});
        }
        default: return heff_nomatch(v_x11_24423);
        }
      }
      default: return heff_nomatch(v_x1_24422);
      }
    }
    default: return heff_nomatch(v_x11_24415);
    }
  }
  default: return heff_nomatch(v_x1_24414);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args) {
  V v_st_24439 = args[0];
  V v_m_24438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24440 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_st_24439}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_MkPair: {
    V v_x11_24441 = heff_field(v_x1_24440, 0);
    V v_st_24442 = heff_field(v_x1_24440, 1);
    V v_ru_24x1_24440_24MkPair = heff_take_reuse_n(v_x1_24440, 3ULL, 2);
    switch (heff_tag_of(v_x11_24441)) {
    case TAG_Left: {
      V v_e_24443 = heff_field(v_x11_24441, 0);
      heff_take_n(v_x11_24441, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24443}), v_st_24442});
    }
    case TAG_Right: {
      V v_x_24444 = heff_field(v_x11_24441, 0);
      V v_ru_24x11_24441_24Right = heff_take_reuse_n(v_x11_24441, 1ULL, 1);
      V v_t_24447;
      switch (heff_tag_of(v_x_24444)) {
      case TAG_At: {
        V v_s_24446 = heff_dup(heff_field(v_x_24444, 1));
        v_t_24447 = v_s_24446;
        break;
      }
      default: heff_nomatch(v_x_24444);
      }
      V v_x_24448 = heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24444}), v_t_24447});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24441_24Right, TAG_Right, 1, (V[]){v_x_24448}), v_st_24442});
    }
    default: return heff_nomatch(v_x11_24441);
    }
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
Clo g_heff_2esyntax_2esurface_2eprimitiveL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprimitiveL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eprimitiveL(V v_r_240, V v_kw_241, V v_x_242, V v_ty_243, V v_z_244) {
top: ;
  V v_m_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_ty_243)}));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_x_242, 9);
      heff_drop(v_ty_243);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_take_field(v_x_242, 4)});
      V v_t_2412 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){heff_get_n(v_x_242, 1, 9), v_t_2411, v_x_2410});
      V v_t_2413 = (g_heff_2esyntax_2ecst_2elastE(v_ty_243));
      V v_e_2414 = heff_get_n(v_t_2413, 4, 9);
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2414});
      V v_t_2416 = heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_At, 2, (V[]){v_t_2412, v_t_2415})});
      V v_x_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2417}), v_st_248});
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eprimitiveL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprimitiveL(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2esurface_2efixityOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixityOut(V v_imported_240, V v_decls_241, V v_groups_242, V v_edges_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 0)), heff_dup(v_groups_242)));
  V v_t_245 = (g_heff_2esyntax_2efixity_2enubByG(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 1)), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByE(v_t_246));
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_imported_240, 0), heff_dup(v_groups_242)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(v_t_248));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_imported_240, 1, 2), heff_dup(v_edges_243)));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2410));
  V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_clo), 2, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_t_245, v_t_247}), heff_rec_n(2, shape_groups__above, (V[]){v_t_249, v_t_2411})}));
  V v_t_2413 = (g_heff_2esyntax_2esurface_2econcatMapS(v_t_2412, v_decls_241));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_242, v_edges_243}), v_t_2413});
}
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixityOut(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243) {
top: ;
  V v_x1_244 = (g_heff_2esyntax_2esurface_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), heff_dup(v_ds_241), heff_dup(v_st_243)));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ds_241);
      heff_drop(v_rhs_242);
      heff_drop_rec(v_st_243, 8);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_st_249 = ({ V rv_3 = heff_get_n(v_st_243, 3, 8); V rr_ = heff_rec_reuse_nf(v_st_246, 247ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2410 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_248));
      V v_t_2411 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2415 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0, 2, 1, (V[]){heff_dup(v_st_249)}); V a_1 = v_t_2411; V a_2 = v_items_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2410); r_; });
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2415, 3, 4)));
      V v_items_2417 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_248));
      V v_t_2418 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2419 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2417));
      V v_t_2420 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2417));
      V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_clo), 3, (V[]){v_t_2418, v_t_2419, v_t_2420}));
      V v_t_2422 = (g_list_2emap(v_t_2421, v_items_2417));
      V v_t_2423 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2422));
      V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2416, v_t_2423));
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nil: {
        V v_items_2425 = ({ V a_0 = v_x_248; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_248); r_; });
        V v_t_2426 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_items_2425; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
        V v_t_2430;
        switch (heff_tag_of(v_rhs_242)) {
        case TAG_At: {
          V v_s_2429 = heff_dup(heff_field(v_rhs_242, 1));
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_rhs_242);
        }
        V v_a_2431 = heff_get_n(v_t_2430, 0, 2);
        V v_x1_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
        V v_b_2436;
        switch (heff_tag_of(v_x1_2432)) {
        case TAG_Nil: {
          v_b_2436 = heff_get_n(v_kw_240, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2433 = heff_field(v_x1_2432, 0);
          heff_take_n(v_x1_2432, 1ULL, 2);
          heff_drop_rec(v_kw_240, 9);
          V v_t_2435 = (g_heff_2esyntax_2ecst_2elastD(v_x_2433));
          v_b_2436 = heff_get_n(v_t_2435, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2432);
        }
        V v_x_2437 = heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_242, v_t_2427}), heff_rec_n(2, shape_start__end, (V[]){v_a_2431, v_b_2436})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){v_x_2437}), v_st_249});
      }
      case TAG_Cons: {
        V v_d_2438 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 2);
        heff_drop_rec(v_kw_240, 9);
        heff_drop(v_ds_241);
        heff_drop(v_rhs_242);
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24x11_245_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2438}), v_st_249});
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_it_2413 = args[1];
  V v_st_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2412, 2)), v_it_2413));
  return ({ V a_0 = heff_get_n(v_st_249, 7, 8); V a_1 = v_d_2412; V a_2 = v_t_2414; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_str0, 24, "a field is `name : Type`");
Clo g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550(V v_e_240, V v_st_241) {
top: ;
  V v_x1_242 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_st_244 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24MkPair = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_245}), v_st_244});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_t_247 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_246));
      V v_x1_248 = (g_heff_2esyntax_2esurface_2easBinderOn(v_t_247, v_st_244));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x11_249 = heff_field(v_x1_248, 0);
        V v_st_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        switch (heff_tag_of(v_x11_249)) {
        case TAG_Left: {
          V v_e_2411 = heff_field(v_x11_249, 0);
          heff_take_n(v_x11_249, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
        }
        case TAG_Right: {
          V v_x_2412 = heff_field(v_x11_249, 0);
          heff_take_n(v_x11_249, 1ULL, 1);
          V v_t_2413 = (g_heff_2esyntax_2esurface_2eisAnnE(v_x_2412));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2412}), v_st_2410});
          } else {
            heff_drop(v_t_2413);
            V v_span_2416;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_At: {
              V v_s_2415 = heff_field(v_x_2412, 1);
              heff_take_n(v_x_2412, 2ULL, 2);
              v_span_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_str0), v_span_2416, NTAG(TAG_Nothing)});
            return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2410});
          }
        }
        default: return heff_nomatch(v_x11_249);
        }
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(v_x_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(a[0]);
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_heff_2esyntax_2esurface_2etraverseS_24s1191676551x1739619601(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0), v_t_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1)})});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_249;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a[0], a[1], a[2]);
}