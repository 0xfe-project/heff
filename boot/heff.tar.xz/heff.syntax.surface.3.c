// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclTest 38719
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBinding 25795
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAtom 50987
#define TAG_PSeg 50182
#define TAG_PatString 45794
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_groups 709681407
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edecimalOfDigits(V);
V g_heff_2esyntax_2esurface_2edecimalOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edecimalOfDigits_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo;
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
HeffT3 g_heff_2esyntax_2esurface_2epickSig_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl(V, V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2esetBinders(V, V);
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetBinders_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2esigBinders(V, V, V);
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigBinders_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24rec0_get(void);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1389405036x1664963487(V, V, V);
V g_list_2efoldl_24s1389405036x1664963487_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1389405036x1664963487_clo;
V g_list_2ekeepIf_24s2053104128x1598844325(V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2041933216x1458595349(V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2eordmap_2eempty_get(void);
Clo g_heff_2esyntax_2esurface_2edotAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edotAt_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edotAt(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edotAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EPi: {
      V v_x111_2421 = heff_field(v_x11_242, 0);
      V v_rest_2422 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2421, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2422;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2426 = heff_field(v_x111_2421, 0);
        heff_take_n(v_x111_2421, 1ULL, 5);
        V v_cell_2431 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2426, heff_hole()});
        V v_u_2432 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2431);
        V t_0 = v_rest_2422;
        V t_1 = v_u_2432;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2433 = heff_field(v_x111_2421, 0);
        heff_take_n(v_x111_2421, 1ULL, 4);
        V v_cell_2437 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2433, heff_hole()});
        V v_u_2438 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2437);
        V t_0 = v_rest_2422;
        V t_1 = v_u_2438;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2421, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2422;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_2421);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFor: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENest: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETry: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWith: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWithBound: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epiImplicits_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2eisNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisNameE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_end_243 = heff_dup(heff_rfield(v_x12_242, 1));
    V v_start_244 = heff_dup(heff_rfield(v_x12_242, 0));
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ENotationVar: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_x_2410 = heff_field(v_x11_241, 0);
      V v_ret_24bool = heff_bool(heff_intEq_c(heff_intSub_lent(v_end_243, v_start_244, 0), heff_strLength_lent(v_x_2410, 0)));
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return v_ret_24bool;
    }
    case TAG_EInt: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    case TAG_EWithBound: {
      heff_drop(v_end_243);
      heff_drop(v_start_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisNameE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2eplainBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplainBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eplainBinder(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_241)) {
    case TAG_EVar: {
      V v_ru_24d1_241_24EVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EImplicitVar: {
      V v_ru_24d1_241_24EImplicitVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      V v_ru_24d1_241_24ETag = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      V v_ru_24d1_241_24EInt = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      V v_ru_24d1_241_24EFloat = heff_take_reuse_nf(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EString: {
      V v_ru_24d1_241_24EString = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBinary: {
      V v_ru_24d1_241_24EBinary = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ERune: {
      V v_ru_24d1_241_24ERune = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWord: {
      V v_ru_24d1_241_24EWord = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EApp: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EProject: {
      V v_ru_24d1_241_24EProject = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENamed: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EPi: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAnn: {
      V v_d11_2424 = heff_field(v_d1_241, 0);
      V v_t_2425 = heff_field(v_d1_241, 1);
      heff_take_n(v_d1_241, 3ULL, 2);
      switch (heff_tag_of(v_d11_2424)) {
      case TAG_At: {
        V v_d111_2426 = heff_field(v_d11_2424, 0);
        V v_xsp_2427 = heff_field(v_d11_2424, 1);
        heff_take_n(v_d11_2424, 3ULL, 2);
        switch (heff_tag_of(v_d111_2426)) {
        case TAG_EVar: {
          V v_x_2428 = heff_field(v_d111_2426, 0);
          heff_take_n(v_d111_2426, 1ULL, 1);
          heff_drop_tag(v_d_240, 2);
          return heff_tag_n(TAG_PiNamed, 3, (V[]){v_x_2428, v_xsp_2427, v_t_2425});
        }
        case TAG_EImplicitVar: {
          V v_ru_24d111_2426_24EImplicitVar = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENotationVar: {
          heff_take_n(v_d111_2426, 0ULL, 3);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETag: {
          V v_ru_24d111_2426_24ETag = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInt: {
          V v_ru_24d111_2426_24EInt = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFloat: {
          V v_ru_24d111_2426_24EFloat = heff_take_reuse_nf(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EString: {
          V v_ru_24d111_2426_24EString = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBinary: {
          V v_ru_24d111_2426_24EBinary = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ERune: {
          V v_ru_24d111_2426_24ERune = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWord: {
          V v_ru_24d111_2426_24EWord = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EApp: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EProject: {
          V v_ru_24d111_2426_24EProject = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENamed: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EPi: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELam: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAnn: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESpec: {
          heff_take_n(v_d111_2426, 0ULL, 4);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESig: {
          V v_ru_24d111_2426_24ESig = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESum: {
          V v_ru_24d111_2426_24ESum = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EStruct: {
          V v_ru_24d111_2426_24EStruct = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EUpdate: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EMatch: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELetIn: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EDo: {
          V v_ru_24d111_2426_24EDo = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELocal: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInvalid: {
          V v_ru_24d111_2426_24EInvalid = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAssign: {
          heff_take_n(v_d111_2426, 0ULL, 3);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWhile: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFor: {
          heff_take_n(v_d111_2426, 0ULL, 3);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EIfThen: {
          heff_take_n(v_d111_2426, 0ULL, 2);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBreak: {
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EContinue: {
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EReturn: {
          V v_ru_24d111_2426_24EReturn = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENest: {
          V v_ru_24d111_2426_24ENest = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELazy: {
          V v_ru_24d111_2426_24ELazy = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETuple: {
          V v_ru_24d111_2426_24ETuple = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETry: {
          V v_ru_24d111_2426_24ETry = heff_take_reuse_n(v_d111_2426, 0ULL, 1);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_at_n(v_ru_24d111_2426_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWith: {
          heff_take_n(v_d111_2426, 0ULL, 4);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWithBound: {
          heff_take_n(v_d111_2426, 0ULL, 3);
          heff_drop(v_t_2425);
          heff_drop(v_xsp_2427);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        default: return heff_nomatch(v_d111_2426);
        }
      }
      default: return heff_nomatch(v_d11_2424);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESig: {
      V v_ru_24d1_241_24ESig = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESum: {
      V v_ru_24d1_241_24ESum = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EStruct: {
      V v_ru_24d1_241_24EStruct = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EUpdate: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELetIn: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EDo: {
      V v_ru_24d1_241_24EDo = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELocal: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInvalid: {
      V v_ru_24d1_241_24EInvalid = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAssign: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWhile: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFor: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EIfThen: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBreak: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EContinue: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EReturn: {
      V v_ru_24d1_241_24EReturn = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENest: {
      V v_ru_24d1_241_24ENest = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELazy: {
      V v_ru_24d1_241_24ELazy = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETuple: {
      V v_ru_24d1_241_24ETuple = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETry: {
      V v_ru_24d1_241_24ETry = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWith: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWithBound: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplainBinder(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epickSig_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epickSig_24cpr_str1, 0, "");

HeffT3 g_heff_2esyntax_2esurface_2epickSig_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_it_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_dup(heff_field(v_it_242, 1));
      v_t_2414 = v_f_245;
      break;
    }
    case TAG_Eqn: {
      V v_f_249 = heff_dup(heff_field(v_it_242, 0));
      v_t_2414 = v_f_249;
      break;
    }
    case TAG_Whole: {
      v_t_2414 = ((V)&g_heff_2esyntax_2esurface_2epickSig_24cpr_str0);
      break;
    }
    case TAG_Doc: {
      v_t_2414 = ((V)&g_heff_2esyntax_2esurface_2epickSig_24cpr_str1);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if (heff_strEq_c_lent(v_t_2414, v_f_240, 1)) {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_it_242, v_rest_243}});
    } else {
      HeffT3 v_t_2415 = (g_heff_2esyntax_2esurface_2epickSig_24cpr(v_f_240, v_rest_243));
      {
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_s_2419 = v_field_2417;
          V v_more_2420 = v_field_2418;
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_s_2419, heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_242, v_more_2420})}});
        } else {
          heff_drop(v_it_242);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_field_2417);
          heff_drop(v_field_2418);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_t_241)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Update: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWithBound: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinding: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str7, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2eatomTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eatomTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eatomTok(V v_t_240) {
top: ;
  V v_kind_241 = heff_take_field(v_t_240, 0);
  V v_text_242 = heff_take_field(v_t_240, 1);
  V v_start_243 = heff_take_field(v_t_240, 3);
  V v_end_244 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str0), 2)) {
    heff_drop(v_kind_241);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
  } else {
    if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str1), 2)) {
      heff_drop(v_kind_241);
      V v_t_245 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_text_242); r_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_245}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
    } else {
      if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str2), 2)) {
        heff_drop(v_kind_241);
        V v_s_246 = v_text_242;
        V v_x2_247 = ({ V a_0 = v_s_246; V b_1 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2eatomTok_str4), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_246); heff_drop(b_1); r_; });
        V v_t_2410;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nil: {
          v_t_2410 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_xs_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str6); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2esyntax_2esurface_2edecimalOfDigits(a_0)); heff_drop(v_t_2410); r_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EFloat, 1, (V[]){v_t_2411}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
      } else {
        if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str7), 2)) {
          heff_drop(v_kind_241);
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EString, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
        } else {
          if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str8), 2)) {
            heff_drop(v_kind_241);
            V v_t_2412 = heff_runeToInt(heff_strRuneAt(v_text_242, MK_INT(0LL)));
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ERune, 1, (V[]){v_t_2412}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
          } else {
            if (heff_strEq_c(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2eatomTok_str9))) {
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            } else {
              V v_t_2413 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2ewordKw(a_0)); heff_drop(v_text_242); r_; });
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWord, 1, (V[]){v_t_2413}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eatomTok(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V v_lit_240, V v_lit_241, V v_m_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(v_lit_240, v_lit_241, v_m_242, v_st_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econL(V v_r_240, V v_c_241, V v_args_242) {
top: ;
  V v_text_243 = heff_take_field(v_c_241, 1);
  V v_start_244 = heff_take_field(v_c_241, 3);
  V v_end_245 = heff_get_n(v_c_241, 4, 9);
  V v_m_246 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_args_242));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_lam0, 1, 4, (V[]){v_m_246, v_text_243, v_start_244, v_end_245});
}
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_start_244 = heff_env(self)[2];
  V v_end_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_text_243);
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_text_243}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
      V v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_x_2412));
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_x_2414}), v_st_2410});
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(v_z_240, v_xs_243));
    V v_b_245 = heff_dup(v_x_242);
    V v_binder_246 = heff_take_field(v_b_245, 0);
    V v_pat_247 = heff_get_n(v_b_245, 2, 3);
    V v_e_248 = heff_dup(v_a_244);
    V v_t_249 = v_binder_246;
    V v_t_2432;
    switch (heff_tag_of(v_t_249)) {
    case TAG_LamName: {
      V v_x_2410 = heff_field(v_t_249, 0);
      V v_xsp_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24LamName = heff_take_reuse_n(v_t_249, 3ULL, 2);
      V v_t_2412 = v_pat_247;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_x_2410);
        heff_drop_rec(v_xsp_2411, 2);
        heff_drop_cell(v_ru_24t_249_24LamName, 2);
        v_t_2432 = v_e_248;
        break;
      }
      case TAG_Just: {
        V v_p_2413 = heff_field(v_t_2412, 0);
        V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_p_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_p_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_p_2413);
        }
        V v_t_2419;
        switch (heff_tag_of(v_e_248)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_e_248, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_e_248);
        }
        V v_t_2422;
        switch (heff_tag_of(v_e_248)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_e_248, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_e_248);
        }
        V v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_2412_24Just, TAG_EVar, 1, (V[]){v_x_2410}), heff_dup(v_xsp_2411)});
        V v_t_2424 = ({ V rv_1 = heff_get_n(v_t_2419, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2425 = heff_tag_at_n(v_ru_24t_249_24LamName, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2413, v_e_248}), v_t_2424});
        V v_t_2426 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2411, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_t_2423, v_t_2425}), v_t_2426});
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    case TAG_LamImplicit: {
      heff_take_n(v_t_249, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_pat_247);
      v_t_2432 = v_e_248;
      break;
    }
    case TAG_LamAnn: {
      heff_take_n(v_t_249, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_pat_247);
      v_t_2432 = v_e_248;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2435;
    switch (heff_tag_of(v_a_244)) {
    case TAG_At: {
      V v_a_2434 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 2ULL, 2);
      v_t_2435 = v_a_2434;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2436 = heff_tag_n(TAG_ELam, 2, (V[]){heff_take_field(v_x_242, 0), v_t_2432});
    V v_t_2437 = heff_get_n(heff_get_n(v_x_242, 1, 3), 0, 2);
    V v_t_2438 = ({ V rv_0 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_t_2435, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_t_2438});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args);
Clo g_heff_2esyntax_2esurface_2estmtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2estmtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2estmtL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ESBind: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_e_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_PAtom: {
      V v_x_245 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_text_246 = heff_take_field(v_x_245, 1);
      V v_start_247 = heff_take_field(v_x_245, 3);
      V v_end_248 = heff_get_n(v_x_245, 4, 9);
      V v_m_249 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_244}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam0, 1, 4, (V[]){v_m_249, v_text_246, v_start_247, v_end_248});
    }
    default: {
      V v_m_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_244}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam1, 1, 3, (V[]){v_m_2424, v_r_240, v_x21_242});
    }
    }
  }
  case TAG_ELet: {
    V v_x26_2456 = heff_dup(heff_field(v_x2_241, 5));
    switch (heff_tag_of(v_x26_2456)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_241)) {
      case TAG_ELet: {
        V v_kw_2457 = heff_field(v_x2_241, 0);
        V v_p_2458 = heff_field(v_x2_241, 1);
        V v_ann0_2459 = heff_field(v_x2_241, 2);
        V v_e_2461 = heff_field(v_x2_241, 4);
        heff_take_n(v_x2_241, 23ULL, 6);
        V v_m_2463 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_dup(v_p_2458), v_ann0_2459, heff_dup(v_e_2461)));
        return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam2, 1, 4, (V[]){v_m_2463, v_p_2458, v_e_2461, v_kw_2457});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x26_2456, 0ULL, 1);
      V v_m_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam3, 1, 1, (V[]){v_m_2483});
    }
    default: return heff_nomatch(v_x26_2456);
    }
  }
  case TAG_ELetElse: {
    V v_kw_2494 = heff_dup(heff_field(v_x2_241, 0));
    V v_p_2495 = heff_dup(heff_field(v_x2_241, 1));
    V v_ann0_2496 = heff_dup(heff_field(v_x2_241, 2));
    V v_e_2498 = heff_dup(heff_field(v_x2_241, 4));
    V v_ss_24100 = heff_dup(heff_field(v_x2_241, 6));
    V v_m_24101 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_2495), v_ann0_2496, v_e_2498));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam4, 1, 6, (V[]){v_m_24101, v_r_240, v_ss_24100, v_p_2495, v_x2_241, v_kw_2494});
  }
  case TAG_ELetMut: {
    V v_kw_24132 = heff_field(v_x2_241, 0);
    V v_x_24134 = heff_field(v_x2_241, 2);
    V v_ann0_24135 = heff_field(v_x2_241, 3);
    V v_e_24137 = heff_field(v_x2_241, 5);
    heff_take_n(v_x2_241, 45ULL, 6);
    V v_m_24138 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_tag_n(TAG_PAtom, 1, (V[]){heff_dup(v_x_24134)}), v_ann0_24135, heff_dup(v_e_24137)));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam8, 1, 4, (V[]){v_m_24138, v_x_24134, v_e_24137, v_kw_24132});
  }
  default: {
    V v_m_24156 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam9, 1, 1, (V[]){v_m_24156});
  }
  }
}
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2estmtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args) {
  V v_st_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_text_246 = heff_env(self)[1];
  V v_start_247 = heff_env(self)[2];
  V v_end_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_st_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      return heff_tag_re_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_text_246), heff_dup(heff_rfield(v_st_2413, 1))});
      V v_st_2417 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2416, v_st_2413));
      V v_t_2420;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2415, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      V v_t_2421 = heff_tag_n(TAG_StmtBind, 3, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), v_end_248}), v_x_2415});
      V v_t_2422 = ({ V rv_0 = v_start_247; V rr_ = heff_rec_reuse_nf(v_t_2420, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2423 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2422})});
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_st_2417});
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args) {
  V v_st_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2425}));
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkPair: {
    V v_x11_2427 = heff_field(v_x1_2426, 0);
    V v_st_2428 = heff_field(v_x1_2426, 1);
    V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_Left: {
      V v_e_2429 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Left = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_x21_242);
      return heff_tag_re_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2427_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2429}), v_st_2428});
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Right = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      V v_m_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_242)}));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_st_2428}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Left = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          heff_drop(v_x21_242);
          heff_drop(v_x_2430);
          heff_drop_cell(v_ru_24x11_2427_24Right, 1);
          heff_drop_cell(v_ru_24x1_2432_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2433_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = ({ V a_0 = heff_dup(heff_rfield(v_st_2434, 1)); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_242; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x21_242); r_; });
          V v_st_2438 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2437, v_st_2434));
          V v_t_2441;
          switch (heff_tag_of(v_x_2430)) {
          case TAG_At: {
            V v_s_2440 = heff_dup(heff_field(v_x_2430, 1));
            v_t_2441 = v_s_2440;
            break;
          }
          default: heff_nomatch(v_x_2430);
          }
          V v_t_2444;
          switch (heff_tag_of(v_x_2436)) {
          case TAG_At: {
            V v_s_2443 = heff_dup(heff_field(v_x_2436, 1));
            v_t_2444 = v_s_2443;
            break;
          }
          default: heff_nomatch(v_x_2436);
          }
          V v_t_2447;
          switch (heff_tag_of(v_x_2430)) {
          case TAG_At: {
            V v_s_2446 = heff_dup(heff_field(v_x_2430, 1));
            v_t_2447 = v_s_2446;
            break;
          }
          default: heff_nomatch(v_x_2430);
          }
          V v_t_2448 = heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_ENest, 1, (V[]){v_x_2430}), v_t_2441});
          V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2447, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2444, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_2436, v_t_2448}), v_t_2449});
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2427_24Right, TAG_Right, 1, (V[]){v_t_2450}), v_st_2438});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args) {
  V v_st_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_p_2458 = heff_env(self)[1];
  V v_e_2461 = heff_env(self)[2];
  V v_kw_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_st_2464}));
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_MkPair: {
    V v_x11_2466 = heff_field(v_x1_2465, 0);
    V v_st_2467 = heff_field(v_x1_2465, 1);
    V v_ru_24x1_2465_24MkPair = heff_take_reuse_n(v_x1_2465, 3ULL, 2);
    switch (heff_tag_of(v_x11_2466)) {
    case TAG_Left: {
      V v_e_2468 = heff_field(v_x11_2466, 0);
      V v_ru_24x11_2466_24Left = heff_take_reuse_n(v_x11_2466, 1ULL, 1);
      heff_drop(v_p_2458);
      heff_drop(v_e_2461);
      heff_drop_rec(v_kw_2457, 9);
      return heff_tag_re_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2466_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2468}), v_st_2467});
    }
    case TAG_Right: {
      V v_x_2469 = heff_field(v_x11_2466, 0);
      V v_ru_24x11_2466_24Right = heff_take_reuse_n(v_x11_2466, 1ULL, 1);
      V v_t_2470 = ({ V a_0 = heff_dup(heff_rfield(v_st_2467, 1)); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_2458; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_2458); r_; });
      V v_st_2471 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2470, v_st_2467));
      V v_t_2474;
      switch (heff_tag_of(v_x_2469)) {
      case TAG_MkPair: {
        V v_x_2472 = heff_dup(heff_field(v_x_2469, 0));
        v_t_2474 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_x_2469);
      }
      V v_t_2477;
      switch (heff_tag_of(v_x_2469)) {
      case TAG_MkPair: {
        V v_y_2476 = heff_field(v_x_2469, 1);
        heff_take_n(v_x_2469, 2ULL, 2);
        v_t_2477 = v_y_2476;
        break;
      }
      default: heff_nomatch(v_x_2469);
      }
      V v_t_2478 = (g_heff_2esyntax_2ecst_2elastE(v_e_2461));
      V v_e_2479 = heff_get_n(v_t_2478, 4, 9);
      V v_t_2480 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2457, 3, 9), v_e_2479});
      V v_x_2481 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_t_2474, v_t_2477}), v_t_2480});
      return heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2466_24Right, TAG_Right, 1, (V[]){v_x_2481}), v_st_2471});
    }
    default: return heff_nomatch(v_x11_2466);
    }
  }
  default: return heff_nomatch(v_x1_2465);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args) {
  V v_st_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_st_2484}));
  switch (heff_tag_of(v_x1_2485)) {
  case TAG_MkPair: {
    V v_x11_2486 = heff_field(v_x1_2485, 0);
    V v_st_2487 = heff_field(v_x1_2485, 1);
    V v_ru_24x1_2485_24MkPair = heff_take_reuse_n(v_x1_2485, 3ULL, 2);
    switch (heff_tag_of(v_x11_2486)) {
    case TAG_Left: {
      V v_e_2488 = heff_field(v_x11_2486, 0);
      V v_ru_24x11_2486_24Left = heff_take_reuse_n(v_x11_2486, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2485_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2486_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2488}), v_st_2487});
    }
    case TAG_Right: {
      V v_x_2489 = heff_field(v_x11_2486, 0);
      V v_ru_24x11_2486_24Right = heff_take_reuse_n(v_x11_2486, 1ULL, 1);
      V v_t_2492;
      switch (heff_tag_of(v_x_2489)) {
      case TAG_At: {
        V v_s_2491 = heff_dup(heff_field(v_x_2489, 1));
        v_t_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_x_2489);
      }
      V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_2489}), v_t_2492});
      return heff_tag_re_n(v_ru_24x1_2485_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2486_24Right, TAG_Right, 1, (V[]){v_t_2493}), v_st_2487});
    }
    default: return heff_nomatch(v_x11_2486);
    }
  }
  default: return heff_nomatch(v_x1_2485);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args) {
  V v_m_24110 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24110));
}
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args) {
  V v_st_24108 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_ss_24100 = heff_env(self)[1];
  V v_t_24109 = heff_dup(heff_rfield(v_st_24108, 1));
  heff_clo_take(self, 2);
  V v_t_24111 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam6, 1, 1, (V[]){v_r_240}), v_ss_24100));
  V v_x1_24112 = heff_tr(heff_call(v_t_24111, 1, (V[]){v_st_24108}));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      V v_ru_24x11_24113_24Left = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
      heff_drop(v_t_24109);
      return heff_tag_re_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24113_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      V v_ru_24x11_24113_24Right = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
      V v_st_24117 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24109, v_st_24114));
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24113_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24116}), v_st_24117});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args) {
  V v_ss_27_24118 = args[0];
  V v_st_24119 = args[1];
  V v_p_2495 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  V v_x2_241 = heff_env(self)[2];
  V v_kw_2494 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24120 = ({ V a_0 = heff_dup(heff_rfield(v_st_24119, 1)); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_2495; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_2495); r_; });
  V v_st_24121 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24120, v_st_24119));
  V v_t_24124;
  switch (heff_tag_of(v_x_24107)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_dup(heff_field(v_x_24107, 0));
    v_t_24124 = v_x_24122;
    break;
  }
  default: heff_nomatch(v_x_24107);
  }
  V v_t_24127;
  switch (heff_tag_of(v_x_24107)) {
  case TAG_MkPair: {
    V v_y_24126 = heff_field(v_x_24107, 1);
    heff_take_n(v_x_24107, 2ULL, 2);
    v_t_24127 = v_y_24126;
    break;
  }
  default: heff_nomatch(v_x_24107);
  }
  V v_t_24128 = (g_heff_2esyntax_2ecst_2elastE(v_x2_241));
  V v_e_24129 = heff_get_n(v_t_24128, 4, 9);
  V v_t_24130 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2494, 3, 9), v_e_24129});
  V v_x_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_t_24124, v_t_24127, v_ss_27_24118}), v_t_24130});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24131}), v_st_24121});
}
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args) {
  V v_st_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_ss_24100 = heff_env(self)[2];
  V v_p_2495 = heff_env(self)[3];
  V v_x2_241 = heff_env(self)[4];
  V v_kw_2494 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_24103 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_st_24102}));
  switch (heff_tag_of(v_x1_24103)) {
  case TAG_MkPair: {
    V v_x11_24104 = heff_field(v_x1_24103, 0);
    V v_st_24105 = heff_field(v_x1_24103, 1);
    V v_ru_24x1_24103_24MkPair = heff_take_reuse_n(v_x1_24103, 3ULL, 2);
    switch (heff_tag_of(v_x11_24104)) {
    case TAG_Left: {
      V v_e_24106 = heff_field(v_x11_24104, 0);
      V v_ru_24x11_24104_24Left = heff_take_reuse_n(v_x11_24104, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_ss_24100);
      heff_drop(v_p_2495);
      heff_drop_tag(v_x2_241, 7);
      heff_drop_rec(v_kw_2494, 9);
      return heff_tag_re_n(v_ru_24x1_24103_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24104_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24106}), v_st_24105});
    }
    case TAG_Right: {
      V v_x_24107 = heff_field(v_x11_24104, 0);
      heff_take_n(v_x11_24104, 1ULL, 1);
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24103_24MkPair, heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam5, 1, 2, (V[]){v_r_240, v_ss_24100}), heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam7, 2, 4, (V[]){v_p_2495, v_x_24107, v_x2_241, v_kw_2494}), v_st_24105));
    }
    default: return heff_nomatch(v_x11_24104);
    }
  }
  default: return heff_nomatch(v_x1_24103);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  V v_x_24134 = heff_env(self)[1];
  V v_e_24137 = heff_env(self)[2];
  V v_kw_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Left = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      heff_drop_rec(v_x_24134, 9);
      heff_drop(v_e_24137);
      heff_drop_rec(v_kw_24132, 9);
      return heff_tag_re_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24141_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_24134, 1)), heff_dup(heff_rfield(v_st_24142, 1))});
      V v_st_24146 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24145, v_st_24142));
      V v_t_24149;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_MkPair: {
        V v_y_24148 = heff_field(v_x_24144, 1);
        heff_take_n(v_x_24144, 2ULL, 2);
        v_t_24149 = v_y_24148;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_t_24150 = (g_heff_2esyntax_2ecst_2elastE(v_e_24137));
      V v_e_24151 = heff_get_n(v_t_24150, 4, 9);
      V v_t_24152 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24134, 3), heff_take_field(v_x_24134, 4)});
      V v_t_24153 = heff_tag_n(TAG_StmtLetMut, 3, (V[]){heff_get_n(v_x_24134, 1, 9), v_t_24152, v_t_24149});
      V v_t_24154 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24132, 3, 9), v_e_24151});
      V v_x_24155 = heff_tag_n(TAG_At, 2, (V[]){v_t_24153, v_t_24154});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_Right, 1, (V[]){v_x_24155}), v_st_24146});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args) {
  V v_st_24157 = args[0];
  V v_m_24156 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24158 = heff_tr(heff_call(v_m_24156, 1, (V[]){v_st_24157}));
  switch (heff_tag_of(v_x1_24158)) {
  case TAG_MkPair: {
    V v_x11_24159 = heff_field(v_x1_24158, 0);
    V v_st_24160 = heff_field(v_x1_24158, 1);
    V v_ru_24x1_24158_24MkPair = heff_take_reuse_n(v_x1_24158, 3ULL, 2);
    switch (heff_tag_of(v_x11_24159)) {
    case TAG_Left: {
      V v_e_24161 = heff_field(v_x11_24159, 0);
      V v_ru_24x11_24159_24Left = heff_take_reuse_n(v_x11_24159, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_24158_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24159_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24161}), v_st_24160});
    }
    case TAG_Right: {
      V v_x_24162 = heff_field(v_x11_24159, 0);
      V v_ru_24x11_24159_24Right = heff_take_reuse_n(v_x11_24159, 1ULL, 1);
      V v_t_24165;
      switch (heff_tag_of(v_x_24162)) {
      case TAG_At: {
        V v_s_24164 = heff_dup(heff_field(v_x_24162, 1));
        v_t_24165 = v_s_24164;
        break;
      }
      default: heff_nomatch(v_x_24162);
      }
      V v_t_24166 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_x_24162}), v_t_24165});
      return heff_tag_re_n(v_ru_24x1_24158_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24159_24Right, TAG_Right, 1, (V[]){v_t_24166}), v_st_24160});
    }
    default: return heff_nomatch(v_x11_24159);
    }
  }
  default: return heff_nomatch(v_x1_24158);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str0, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str1, 1, "`");
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecatchL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatchL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatchL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ECatch: {
    V v_b_243 = heff_field(v_e_241, 1);
    V v_body_245 = heff_field(v_e_241, 3);
    V v_m_246 = (g_heff_2esyntax_2esurface_2elamBinderL(heff_dup(v_r_240), heff_dup(v_b_243)));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam0, 1, 3, (V[]){v_m_246, v_r_240, heff_dup(v_body_245)});
  }
  default: {
    heff_drop(v_r_240);
    V v_t_2444 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2445 = heff_take_field(v_t_2444, 3);
    V v_end_2446 = heff_get_n(v_t_2444, 4, 9);
    V v_t_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str0), heff_get_n(v_t_2447, 1, 9));
    V v_msg_2449 = heff_strAppend(v_t_2448, ((V)&g_heff_2esyntax_2esurface_2ecatchL_str1));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam3, 1, 3, (V[]){v_msg_2449, v_start_2445, v_end_2446});
  }
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2ecatchL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args) {
  V v_m_2428 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_2428));
}
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args) {
  V v_st_2426 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_245 = heff_env(self)[1];
  V v_t_2427 = heff_dup(heff_rfield(v_st_2426, 1));
  heff_clo_take(self, 2);
  V v_t_2429 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam2, 1, 1, (V[]){v_r_240}), v_body_245));
  V v_x1_2430 = heff_tr(heff_call(v_t_2429, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_MkPair: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_st_2432 = heff_field(v_x1_2430, 1);
    V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_Left: {
      V v_e_2433 = heff_field(v_x11_2431, 0);
      V v_ru_24x11_2431_24Left = heff_take_reuse_n(v_x11_2431, 1ULL, 1);
      heff_drop(v_t_2427);
      return heff_tag_re_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2431_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2433}), v_st_2432});
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_x11_2431, 0);
      V v_ru_24x11_2431_24Right = heff_take_reuse_n(v_x11_2431, 1ULL, 1);
      V v_st_2435 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2427, v_st_2432));
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2431_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2434}), v_st_2435});
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_body_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_body_245);
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_binder_2413 = heff_take_field(v_x_2412, 0);
      V v_pat_2414 = heff_get_n(v_x_2412, 2, 3);
      V v_t_2415 = heff_dup(v_binder_2413);
      V v_t_2425;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_LamName: {
        V v_x_2416 = heff_field(v_t_2415, 0);
        V v_ru_24t_2415_24LamName = heff_take_reuse_n(v_t_2415, 1ULL, 2);
        V v_t_2418 = v_pat_2414;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag_at_n(v_ru_24t_2415_24LamName, TAG_Cons, 2, (V[]){v_x_2416, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Just: {
          V v_p_2419 = heff_field(v_t_2418, 0);
          heff_take_n(v_t_2418, 1ULL, 1);
          heff_drop(v_x_2416);
          heff_drop_cell(v_ru_24t_2415_24LamName, 2);
          v_t_2425 = (g_heff_2esyntax_2epresyntax_2epatNames(v_p_2419));
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_2420 = heff_field(v_t_2415, 0);
        V v_ru_24t_2415_24LamImplicit = heff_take_reuse_n(v_t_2415, 1ULL, 2);
        heff_drop(v_pat_2414);
        v_t_2425 = heff_tag_at_n(v_ru_24t_2415_24LamImplicit, TAG_Cons, 2, (V[]){v_x_2420, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2422 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 3);
        heff_drop(v_pat_2414);
        v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      HeffT2 v_t_2436 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2425, heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam1, 1, 2, (V[]){v_r_240, v_body_245}), v_st_2410));
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_x11_2439 = v_field_2437;
        V v_st_2440 = v_field_2438;
        switch (heff_tag_of(v_x11_2439)) {
        case TAG_Left: {
          V v_e_2441 = heff_field(v_x11_2439, 0);
          V v_ru_24x11_2439_24Left = heff_take_reuse_n(v_x11_2439, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop(v_binder_2413);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2439_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2441}), v_st_2440});
        }
        case TAG_Right: {
          V v_x_2442 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          V v_t_2443 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_binder_2413, v_x_2442})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2443, v_st_2440});
        }
        default: return heff_nomatch(v_x11_2439);
        }
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args) {
  V v_st_2450 = args[0];
  V v_msg_2449 = heff_env(self)[0];
  V v_start_2445 = heff_env(self)[1];
  V v_end_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, heff_rec_n(2, shape_start__end, (V[]){v_start_2445, v_end_2446}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2451}), v_st_2450});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_240, v_sp_241, v_e_242, v_v_243, v_s_244, v_st_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentOf(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2esyntax_2esurface_2etakesRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakesRest_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakesRest(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      default: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etakesRest(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatSegmentsL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_r_246 = heff_dup(v_r_240);
    V v_last_249;
    switch (heff_tag_of(v_rest_245)) {
    case TAG_Nil: {
      v_last_249 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_last_249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_245);
    }
    V v_x3_2410 = v_p_244;
    V v_m_2433;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_PSeg: {
      V v_p_2411 = heff_field(v_x3_2410, 0);
      V v_cc_2412 = heff_field(v_x3_2410, 1);
      V v_spec_2413 = heff_field(v_x3_2410, 2);
      heff_take_n(v_x3_2410, 7ULL, 3);
      V v_t_2414 = (g_heff_2esyntax_2esurface_2especGroups(heff_dup(v_spec_2413), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_cc_2412, 3)), heff_dup(heff_rfield(v_cc_2412, 4))});
      V v_m_2416 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_t_2415, heff_dup(g_heff_2esyntax_2esurface_2eemptySpec_get()), v_t_2414));
      v_m_2433 = heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentsL_lam1, 1, 6, (V[]){v_m_2416, v_p_2411, v_spec_2413, v_cc_2412, v_r_246, v_last_249});
      break;
    }
    default: {
      V v_a_2429 = (g_heff_2esyntax_2ecst_2efirstP(v_x3_2410));
      V v_t_2430 = (g_heff_2esyntax_2ecst_2elastP(heff_dup(v_x3_2410)));
      V v_e_2431 = heff_get_n(v_t_2430, 4, 9);
      V v_t_2432 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2429, 3, 9), v_e_2431});
      v_m_2433 = ({ V a_0 = v_r_246; V a_1 = v_last_249; V a_2 = v_t_2432; V a_3 = v_x3_2410; V r_ = heff_tr(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(a_0, a_1, a_2, a_3)); heff_drop(v_last_249); r_; });
      break;
    }
    }
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentsL_lam2, 1, 3, (V[]){v_m_2433, v_r_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatSegmentsL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_p_2411 = heff_env(self)[1];
  V v_spec_2413 = heff_env(self)[2];
  V v_cc_2412 = heff_env(self)[3];
  V v_r_246 = heff_env(self)[4];
  V v_last_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_MkPair: {
    V v_x11_2419 = heff_field(v_x1_2418, 0);
    V v_st_2420 = heff_field(v_x1_2418, 1);
    V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_Left: {
      V v_e_2421 = heff_field(v_x11_2419, 0);
      V v_ru_24x11_2419_24Left = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
      heff_drop(v_p_2411);
      heff_drop(v_spec_2413);
      heff_drop_rec(v_cc_2412, 9);
      heff_drop(v_r_246);
      heff_drop(v_last_249);
      return heff_tag_re_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2421}), v_st_2420});
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_x11_2419, 0);
      heff_take_n(v_x11_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
      V v_a_2423 = (g_heff_2esyntax_2ecst_2efirstP(v_p_2411));
      V v_x1_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_spec_2413));
      V v_t_2427;
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_Nil: {
        v_t_2427 = v_cc_2412;
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x1_2424, 0);
        heff_take_n(v_x1_2424, 1ULL, 2);
        heff_drop_rec(v_cc_2412, 9);
        v_t_2427 = v_x_2425;
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
      V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2423, 3, 9), heff_get_n(v_t_2427, 4, 9)});
      return ({ V a_0 = v_r_246; V a_1 = v_last_249; V a_2 = v_t_2428; V a_3 = v_p_2411; V a_4 = v_x_2422; V a_5 = v_st_2420; V r_ = (g_heff_2esyntax_2esurface_2epatSegmentWith(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_last_249); r_; });
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Left = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_rest_245);
      return heff_tag_re_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2436_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2440 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_rest_245));
      V v_x1_2441 = heff_tr(heff_call(v_t_2440, 1, (V[]){v_st_2437}));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_MkPair: {
        V v_x11_2442 = heff_field(v_x1_2441, 0);
        V v_st_2443 = heff_field(v_x1_2441, 1);
        V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
        switch (heff_tag_of(v_x11_2442)) {
        case TAG_Left: {
          V v_e_2444 = heff_field(v_x11_2442, 0);
          V v_ru_24x11_2442_24Left = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
          heff_drop(v_x_2439);
          heff_drop_cell(v_ru_24x11_2436_24Right, 1);
          heff_drop_cell(v_ru_24x1_2441_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2442_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2444}), v_st_2443});
        }
        case TAG_Right: {
          V v_x_2445 = heff_field(v_x11_2442, 0);
          heff_take_n(v_x11_2442, 1ULL, 1);
          V v_t_2446 = heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_Cons, 2, (V[]){v_x_2439, v_x_2445})});
          return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){v_t_2446, v_st_2443});
        }
        default: return heff_nomatch(v_x11_2442);
        }
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_24cpr(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_z_244}});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(heff_dup(v_fix_240), v_lenient_241, v_st_242, heff_dup(v_r_245)));
    V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_MkPair: {
      V v_x11_249 = heff_field(v_x1_248, 0);
      V v_st_2410 = heff_field(v_x1_248, 1);
      heff_take_n(v_x1_248, 3ULL, 2);
      switch (heff_tag_of(v_x11_249)) {
      case TAG_Left: {
        V v_e_2411 = heff_field(v_x11_249, 0);
        V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
        heff_drop(v_fix_240);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410}});
      }
      case TAG_Right: {
        V v_x_2412 = heff_field(v_x11_249, 0);
        heff_take_n(v_x11_249, 1ULL, 1);
        V t_0 = v_fix_240;
        V t_1 = v_lenient_241;
        V t_2 = v_x_2412;
        V t_3 = v_rest_246;
        V t_4 = v_st_2410;
        v_fix_240 = t_0;
        v_lenient_241 = t_1;
        v_st_242 = t_2;
        v_x5_243 = t_3;
        v_z_244 = t_4;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erestOfDecl_str0, 3, "eof");
Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erestOfDecl_entry, 3, 0};

V g_heff_2esyntax_2esurface_2erestOfDecl(V v_ts_240, V v_box_24j_241, V v_acc_242) {
  int64_t v_j_241 = heff_unbox_word(v_box_24j_241);
top: ;
  if (((((int64_t)0ULL) <= v_j_241) && (v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_243 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_j_241), 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2erestOfDecl_str0)) || ((heff_dup(heff_rfield(v_t_243, 6)) == NTAG(TAG_True)) && heff_intEq_c(heff_dup(heff_rfield(v_t_243, 5)), MK_INT(0LL))))) {
      heff_drop_rec(v_t_243, 7);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    } else {
      V t_0 = v_ts_240;
      int64_t t_1 = (v_j_241 + ((int64_t)1ULL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_acc_242});
      v_ts_240 = t_0;
      v_j_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  } else {
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
}
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2erestOfDecl(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakeSyms(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_str0))) {
      V v_cell_243 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_u_241, heff_hole()});
      V v_u_244 = (g_heff_2esyntax_2esurface_2etakeSyms_24dps(v_rest_242, v_cell_243));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_u_241, 7);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms(a[0]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_243, 3));
  V v_t_245 = heff_dup(heff_rfield(v_st_243, 1));
  V v_t_246 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), heff_dup(v_ds_241)));
  V v_x1_247 = heff_tr(heff_call(v_t_246, 1, (V[]){v_st_243}));
  V v_x11_2413;
  V v_st_2414;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    heff_take_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_t_245);
      v_x11_2413 = heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410});
      v_st_2414 = v_st_249;
      break;
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_st_2412 = (g_heff_2esyntax_2esurface_2esetScope(v_t_245, v_st_249));
      v_x11_2413 = heff_tag_re_n(v_ru_24x11_248_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2411});
      v_st_2414 = v_st_2412;
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_x11_2413)) {
  case TAG_Left: {
    V v_e_2415 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    heff_drop_rec(v_kw_240, 9);
    heff_drop(v_ds_241);
    heff_drop(v_rhs_242);
    heff_drop(v_t_244);
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2415}), v_st_2414});
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    V v_st_2417 = (g_heff_2esyntax_2esurface_2esetBinders(v_t_244, v_st_2414));
    V v_t_2418 = heff_dup(heff_rfield(v_st_2417, 7));
    V v_items_2419 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2420 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2419, NTAG(TAG_Nil)));
    V v_d_2424 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0, 2, 1, (V[]){v_t_2418}); V a_1 = heff_dup(g_heff_2esyntax_2esurface_2ewhereL_24rec0_get()); V a_2 = v_items_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2420); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2424, 3, 4)));
    V v_items_2426 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2427 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2426, NTAG(TAG_Nil)));
    V v_t_2428 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2427));
    V v_t_2429 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2427));
    V v_t_2430 = (g_list_2emap_24s2130193383x1335133353(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2428, v_t_2429, v_items_2427));
    V v_t_2431 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2430));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2431));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      V v_items_2433 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2416); r_; });
      V v_items_2434 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2433, NTAG(TAG_Nil)));
      V v_t_2435 = (g_heff_2esyntax_2esurface_2eassembleGo(heff_dup(g_std_2eordmap_2eempty_get()), v_items_2434, NTAG(TAG_Nil)));
      V v_x1_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
      V v_b_2440;
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_Nil: {
        v_b_2440 = heff_get_n(v_kw_240, 4, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2437 = heff_field(v_x1_2436, 0);
        heff_take_n(v_x1_2436, 1ULL, 2);
        heff_drop_rec(v_kw_240, 9);
        V v_t_2439 = (g_heff_2esyntax_2ecst_2elastD(v_x_2437));
        v_b_2440 = heff_get_n(v_t_2439, 4, 9);
        break;
      }
      default: heff_nomatch(v_x1_2436);
      }
      V v_t_2443;
      switch (heff_tag_of(v_rhs_242)) {
      case TAG_At: {
        V v_s_2442 = heff_dup(heff_field(v_rhs_242, 1));
        v_t_2443 = v_s_2442;
        break;
      }
      default: heff_nomatch(v_rhs_242);
      }
      V v_t_2444 = ({ V rv_1 = v_b_2440; V rr_ = heff_rec_reuse_nf(v_t_2443, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_242, v_t_2435}), v_t_2444});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2445}), v_st_2417});
    }
    case TAG_Cons: {
      V v_d_2446 = heff_field(v_t_2432, 0);
      V v_ru_24t_2432_24Cons = heff_take_reuse_n(v_t_2432, 1ULL, 2);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ds_241);
      heff_drop(v_rhs_242);
      heff_drop(v_x_2416);
      heff_drop_cell(v_ru_24x11_2413_24Right, 1);
      return heff_tag_at_n(v_ru_24t_2432_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2446}), v_st_2417});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x11_2413);
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args) {
  V v_d_2421 = args[0];
  V v_it_2422 = args[1];
  V v_t_2418 = heff_env(self)[0];
  V v_t_2423 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2421, 2)), v_it_2422));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2418; V a_1 = v_d_2421; V a_2 = v_t_2423; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V v_d_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    V v_ru_24d_240_24DImport = heff_take_reuse_n(v_d_240, 0ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24d_240_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_z_241}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_240, 0ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_246, v_z_241}});
  }
  case TAG_DSig: {
    V v_names_247 = heff_field(v_d_240, 0);
    V v_ty_2410 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 9ULL, 4);
    V v_declared_2411 = NTAG(TAG_AsDefinition);
    V v_start_2416;
    switch (heff_tag_of(v_names_247)) {
    case TAG_Nil: {
      v_start_2416 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_dup(heff_field(v_names_247, 0));
      switch (heff_tag_of(v_x_2412)) {
      case TAG_Nil: {
        v_start_2416 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_t_2414 = heff_field(v_x_2412, 0);
        heff_take_n(v_x_2412, 1ULL, 2);
        v_start_2416 = heff_get_n(v_t_2414, 3, 9);
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      break;
    }
    default: heff_nomatch(v_names_247);
    }
    V v_names_2417 = v_names_247;
    V v_ty_2418 = v_ty_2410;
    V v_t_2419 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_2417)));
    HeffT2 v_t_2420 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2419));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop(v_start_2416);
        heff_drop(v_names_2417);
        heff_drop(v_ty_2418);
        V v_d_2423 = v_field_2422;
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2423}), v_z_241}});
      } else {
        heff_drop(v_field_2422);
        V v_x1_2424 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_2418), v_z_241));
        switch (heff_tag_of(v_x1_2424)) {
        case TAG_MkPair: {
          V v_x11_2425 = heff_field(v_x1_2424, 0);
          V v_st_2426 = heff_field(v_x1_2424, 1);
          heff_take_n(v_x1_2424, 3ULL, 2);
          switch (heff_tag_of(v_x11_2425)) {
          case TAG_Left: {
            V v_e_2427 = heff_field(v_x11_2425, 0);
            V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
            heff_drop(v_start_2416);
            heff_drop(v_names_2417);
            heff_drop(v_ty_2418);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2425_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2427}), v_st_2426}});
          }
          case TAG_Right: {
            V v_x_2428 = heff_field(v_x11_2425, 0);
            V v_ru_24x11_2425_24Right = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
            V v_t_2429 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_2417)));
            V v_st_2430 = ({ V a_0 = heff_dup(v_x_2428); V a_1 = v_st_2426; V a_2 = v_t_2429; V r_ = (g_list_2efoldl_24s1389405036x1664963487(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
            V v_t_2431 = (g_heff_2esyntax_2ecst_2elastE(v_ty_2418));
            V v_b_2432 = heff_get_n(v_t_2431, 4, 9);
            V v_x_2433 = (g_list_2emap_24f2041933216x1458595349(v_declared_2411, v_x_2428, v_start_2416, v_b_2432, v_names_2417));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2425_24Right, TAG_Right, 1, (V[]){v_x_2433}), v_st_2430}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2425)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2424)}});
        }
      }
    }
  }
  case TAG_DInstance: {
    V v_kw_2434 = heff_field(v_d_240, 0);
    V v_names_2435 = heff_field(v_d_240, 1);
    V v_ty_2437 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    V v_lit_2438 = v_names_2435;
    V v_declared_2439 = NTAG(TAG_AsInstance);
    V v_start_2440 = heff_get_n(v_kw_2434, 3, 9);
    V v_ty_2441 = v_ty_2437;
    V v_t_2442 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_lit_2438));
    heff_drop(v_t_2442);
    V v_x1_2443 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_2441), v_z_241));
    switch (heff_tag_of(v_x1_2443)) {
    case TAG_MkPair: {
      V v_x11_2444 = heff_field(v_x1_2443, 0);
      V v_st_2445 = heff_field(v_x1_2443, 1);
      V v_ru_24x1_2443_24MkPair = heff_take_reuse_n(v_x1_2443, 3ULL, 2);
      switch (heff_tag_of(v_x11_2444)) {
      case TAG_Left: {
        V v_e_2446 = heff_field(v_x11_2444, 0);
        V v_ru_24x11_2444_24Left = heff_take_reuse_n(v_x11_2444, 1ULL, 1);
        heff_drop(v_lit_2438);
        heff_drop(v_start_2440);
        heff_drop(v_ty_2441);
        heff_drop_cell(v_ru_24x1_2443_24MkPair, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2444_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2446}), v_st_2445}});
      }
      case TAG_Right: {
        V v_x_2447 = heff_field(v_x11_2444, 0);
        V v_ru_24x11_2444_24Right = heff_take_reuse_n(v_x11_2444, 1ULL, 1);
        V v_t_2448 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_lit_2438));
        V v_z_2449 = (g_heff_2esyntax_2esurface_2esigBinders(heff_dup(v_x_2447), v_st_2445, v_t_2448));
        V v_t_2450 = (g_heff_2esyntax_2ecst_2elastE(v_ty_2441));
        V v_b_2451 = heff_get_n(v_t_2450, 4, 9);
        HeffT2 v_t_2452 = ({ V a_0 = v_lit_2438; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(a_0)); heff_drop(v_lit_2438); r_; });
        {
          V v_field_2453 = v_t_2452.f[0];
          V v_field_2454 = v_t_2452.f[1];
          V v_t_2455 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_2439, v_field_2453, v_field_2454, v_x_2447, heff_rec_n(2, shape_start__end, (V[]){v_start_2440, v_b_2451})});
          V v_t_2456 = heff_tag_at_n(v_ru_24x1_2443_24MkPair, TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2444_24Right, TAG_Right, 1, (V[]){v_t_2456}), v_z_2449}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2444)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2443)}});
    }
  }
  case TAG_DEqn: {
    V v_names_2457 = heff_field(v_d_240, 0);
    V v_pats_2458 = heff_field(v_d_240, 1);
    V v_rhs_2460 = heff_field(v_d_240, 3);
    V v_w_2461 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 27ULL, 5);
    return ({ V a_0 = v_names_2457; V a_1 = v_pats_2458; V a_2 = v_rhs_2460; V a_3 = v_w_2461; V a_4 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2457); heff_drop(v_w_2461); r_; });
  }
  case TAG_DData: {
    V v_kw_2462 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2463 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2464 = heff_dup(heff_field(v_d_240, 2));
    V v_universe_2465 = heff_dup(heff_field(v_d_240, 3));
    V v_alts_2466 = heff_dup(heff_field(v_d_240, 4));
    return ({ V a_0 = v_d_240; V a_1 = v_kw_2462; V a_2 = v_name_2463; V a_3 = v_params_2464; V a_4 = v_universe_2465; V a_5 = v_alts_2466; V a_6 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_universe_2465); heff_drop(v_alts_2466); r_; });
  }
  case TAG_DType: {
    V v_kw_2467 = heff_field(v_d_240, 0);
    V v_name_2468 = heff_field(v_d_240, 1);
    V v_params_2469 = heff_field(v_d_240, 2);
    V v_body_2471 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(v_kw_2467, v_name_2468, v_params_2469, v_body_2471, v_z_241));
  }
  case TAG_DTheory: {
    V v_kw_2472 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2473 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2474 = heff_dup(heff_field(v_d_240, 2));
    V v_fields_2476 = heff_dup(heff_field(v_d_240, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(v_d_240, v_kw_2472, v_name_2473, v_params_2474, v_fields_2476, v_z_241));
  }
  case TAG_DMutual: {
    V v_kw_2477 = heff_field(v_d_240, 0);
    V v_ds_2478 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 3ULL, 2);
    return (g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(v_kw_2477, v_ds_2478, v_z_241));
  }
  case TAG_DPrimitive: {
    V v_kw_2479 = heff_field(v_d_240, 0);
    V v_x_2480 = heff_field(v_d_240, 1);
    V v_ty_2482 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(v_kw_2479, v_x_2480, v_ty_2482, v_z_241));
  }
  case TAG_DTest: {
    V v_kw_2483 = heff_field(v_d_240, 0);
    V v_x_2484 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DTest = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_text_2485 = heff_take_field(v_x_2484, 1);
    V v_start_2486 = heff_take_field(v_x_2484, 3);
    V v_end_2487 = heff_get_n(v_x_2484, 4, 9);
    V v_t_2488 = heff_tag_at_n(v_ru_24d_240_24DTest, TAG_DeclTest, 2, (V[]){v_text_2485, heff_rec_n(2, shape_start__end, (V[]){v_start_2486, heff_dup(v_end_2487)})});
    V v_t_2489 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2483, 3, 9), v_end_2487});
    V v_t_2490 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2488, v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, NTAG(TAG_Nil)});
    V v_f_2492 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2491});
    return ((HeffT2){{v_f_2492, v_z_241}});
  }
  case TAG_DWatch: {
    V v_w_2493 = heff_field(v_d_240, 0);
    V v_e_2494 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DWatch = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_start_2495 = heff_take_field(v_w_2493, 3);
    V v_kind_2496 = heff_get_n(v_w_2493, 0, 9);
    V v_x1_2497 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_2494), v_z_241));
    switch (heff_tag_of(v_x1_2497)) {
    case TAG_MkPair: {
      V v_x11_2498 = heff_field(v_x1_2497, 0);
      V v_st_2499 = heff_field(v_x1_2497, 1);
      V v_ru_24x1_2497_24MkPair = heff_take_reuse_n(v_x1_2497, 3ULL, 2);
      switch (heff_tag_of(v_x11_2498)) {
      case TAG_Left: {
        V v_e_24100 = heff_field(v_x11_2498, 0);
        V v_ru_24x11_2498_24Left = heff_take_reuse_n(v_x11_2498, 1ULL, 1);
        heff_drop(v_e_2494);
        heff_drop_cell(v_ru_24d_240_24DWatch, 2);
        heff_drop(v_start_2495);
        heff_drop(v_kind_2496);
        heff_drop_cell(v_ru_24x1_2497_24MkPair, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2498_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24100}), v_st_2499}});
      }
      case TAG_Right: {
        V v_x_24101 = heff_field(v_x11_2498, 0);
        V v_ru_24x11_2498_24Right = heff_take_reuse_n(v_x11_2498, 1ULL, 1);
        V v_t_24102 = (g_heff_2esyntax_2ecst_2elastE(v_e_2494));
        V v_e_24103 = heff_get_n(v_t_24102, 4, 9);
        V v_d_24104 = heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_24101}), heff_rec_n(2, shape_start__end, (V[]){v_start_2495, v_e_24103})});
        V v_t_24105;
        if (heff_strEq_c(v_kind_2496, ((V)&g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0))) {
          v_t_24105 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_24104});
        } else {
          v_t_24105 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_24104});
        }
        V v_x_24106 = heff_tag_at_n(v_ru_24x1_2497_24MkPair, TAG_Cons, 2, (V[]){v_t_24105, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2498_24Right, TAG_Right, 1, (V[]){v_x_24106}), v_st_2499}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2498)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2497)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_240)}});
  }
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr(V v_place_240, V v_decls_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s2053104128x1598844325(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_241)));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr_lam0, 1, 1, (V[]){v_place_240}), v_t_242));
  V v_groups_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_247 = heff_rec_n(2, shape_groups__above, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_edges_248 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_t_247, v_decls_241));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_2410 = heff_rec_n(2, shape_groups__above, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByG(heff_dup(v_groups_245)));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(heff_dup(v_edges_248)));
  V v_t_2413 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2411, v_t_2412});
  V v_t_2414 = ({ V a_0 = v_t_2410; V a_1 = v_t_2413; V a_2 = v_decls_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a_0, a_1, a_2)); heff_drop(v_decls_241); r_; });
  return ((HeffT2){{heff_rec_n(2, shape_groups__above, (V[]){v_groups_245, v_edges_248}), v_t_2414}});
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_243));
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0), v_t_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1)})});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2410 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_249);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2410;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ebind_24tok2(V v_tok_240, V v_m_241, V v_f_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(v_m_241, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop(v_f_242);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_245_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return heff_tail(v_f_242, 2, (V[]){v_x_248, v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind_24tok2(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry, 7, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V v_tok_240, V v_inPat_241, V v_sp_242, V v_e_243, V v_v_244, V v_s_245, V v_st_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_241, v_sp_242, v_e_243, v_v_244, v_s_245, v_st_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_248, v_field_249});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentOf_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}