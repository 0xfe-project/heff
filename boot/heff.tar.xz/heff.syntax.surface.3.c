// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAtom 50987
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2efixityOut(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eknotField(V, V);
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotField_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatSegmentL(V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eexpOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexpOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eexpOf(V v_ex_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
    V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_242); r_; });
    return heff_intSub(MK_INT(0LL), v_t_243);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str1))) {
      V v_t_245 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
      return ({ V a_0 = v_t_245; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_245); r_; });
    } else {
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintOfText(v_ex_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eexpOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_rest_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 5);
        V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
        V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
        heff_drop(v_u_2429);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2428;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2430 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 4);
        V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2430, heff_hole()});
        V v_u_2435 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2434));
        heff_drop(v_u_2435);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2434;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFor: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENest: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EIfLet: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETry: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWith: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisNameE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_x11_241, 0);
      V v_t_246 = heff_intSub(heff_dup(heff_rfield(v_x12_242, 1)), heff_dup(heff_rfield(v_x12_242, 0)));
      return heff_intEq(v_t_246, heff_strLength_lent(v_x_245, 0));
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_EIfLet: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisNameE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EString, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAnn: {
      V v_g_2422 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2422)));
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2422));
      V v_t_2426 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2424, 0, 2), heff_get_n(v_t_2425, 1, 2)});
      V v_t_2427 = (g_list_2emap_24s878634257x1677201747(v_t_2426));
      V v_sc_2428 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(heff_take_field(v_p_241, 1), v_t_2427));
      V v_f_2429 = ({ V rv_1 = v_sc_2428; V rr_ = heff_rec_reuse_nf(v_p_241, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_f_2429}});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EReturn: {
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENest: {
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EIfLet: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETry: {
      V v_ru_24e1_242_24ETry = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETry, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eplainBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplainBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eplainBinder(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_241)) {
    case TAG_EVar: {
      V v_ru_24d1_241_24EVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EImplicitVar: {
      V v_ru_24d1_241_24EImplicitVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      V v_ru_24d1_241_24ETag = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      V v_ru_24d1_241_24EInt = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      V v_ru_24d1_241_24EFloat = heff_take_reuse_na(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EString: {
      V v_ru_24d1_241_24EString = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBinary: {
      V v_ru_24d1_241_24EBinary = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ERune: {
      V v_ru_24d1_241_24ERune = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWord: {
      V v_ru_24d1_241_24EWord = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EApp: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EProject: {
      V v_ru_24d1_241_24EProject = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENamed: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EPi: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAnn: {
      V v_d11_2421 = heff_field(v_d1_241, 0);
      V v_t_2422 = heff_field(v_d1_241, 1);
      heff_take_n(v_d1_241, 3ULL, 2);
      switch (heff_tag_of(v_d11_2421)) {
      case TAG_At: {
        V v_d111_2423 = heff_field(v_d11_2421, 0);
        V v_xsp_2424 = heff_field(v_d11_2421, 1);
        heff_take_n(v_d11_2421, 3ULL, 2);
        switch (heff_tag_of(v_d111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_d111_2423, 0);
          heff_take_n(v_d111_2423, 1ULL, 1);
          heff_drop_tag(v_d_240, 2);
          return heff_tag_n(TAG_PiNamed, 3, (V[]){v_x_2425, v_xsp_2424, v_t_2422});
        }
        case TAG_EImplicitVar: {
          V v_ru_24d111_2423_24EImplicitVar = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETag: {
          V v_ru_24d111_2423_24ETag = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInt: {
          V v_ru_24d111_2423_24EInt = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFloat: {
          V v_ru_24d111_2423_24EFloat = heff_take_reuse_na(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EString: {
          V v_ru_24d111_2423_24EString = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBinary: {
          V v_ru_24d111_2423_24EBinary = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ERune: {
          V v_ru_24d111_2423_24ERune = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWord: {
          V v_ru_24d111_2423_24EWord = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EApp: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EProject: {
          V v_ru_24d111_2423_24EProject = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENamed: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EPi: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELam: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAnn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESpec: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESig: {
          V v_ru_24d111_2423_24ESig = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESum: {
          V v_ru_24d111_2423_24ESum = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EStruct: {
          V v_ru_24d111_2423_24EStruct = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EUpdate: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EMatch: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELetIn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EDo: {
          V v_ru_24d111_2423_24EDo = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELocal: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInvalid: {
          V v_ru_24d111_2423_24EInvalid = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAssign: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWhile: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFor: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EIfThen: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBreak: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EContinue: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EReturn: {
          V v_ru_24d111_2423_24EReturn = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENest: {
          V v_ru_24d111_2423_24ENest = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EIfLet: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETry: {
          V v_ru_24d111_2423_24ETry = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWith: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        default: return heff_nomatch(v_d111_2423);
        }
      }
      default: return heff_nomatch(v_d11_2421);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESig: {
      V v_ru_24d1_241_24ESig = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESum: {
      V v_ru_24d1_241_24ESum = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EStruct: {
      V v_ru_24d1_241_24EStruct = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EUpdate: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELetIn: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EDo: {
      V v_ru_24d1_241_24EDo = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELocal: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInvalid: {
      V v_ru_24d1_241_24EInvalid = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAssign: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWhile: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFor: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EIfThen: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBreak: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EContinue: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EReturn: {
      V v_ru_24d1_241_24EReturn = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENest: {
      V v_ru_24d1_241_24ENest = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EIfLet: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETry: {
      V v_ru_24d1_241_24ETry = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWith: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplainBinder(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_241}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetCond: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str7, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2eatomTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eatomTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eatomTok(V v_t_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str0))) {
    V v_t_242 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str1))) {
      V v_t_245 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_t_240, 1)));
      V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_245}), v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str2))) {
        V v_s_248 = heff_take_field(v_t_240, 1);
        V v_x2_249 = ({ V b_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str3); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2eatomTok_str4), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
        V v_t_2412;
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nil: {
          v_t_2412 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x2_249, 0);
          V v_xs_2411 = heff_field(v_x2_249, 1);
          heff_take_n(v_x2_249, 3ULL, 2);
          v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str6); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
          break;
        }
        default: heff_nomatch(v_x2_249);
        }
        double v_t_2413 = ({ V a_0 = v_t_2412; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_2412); r_; });
        V v_t_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)}), v_t_2414});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str7))) {
          V v_t_2416 = heff_tag_n(TAG_EString, 1, (V[]){heff_take_field(v_t_240, 1)});
          V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_t_2417});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str8))) {
            V v_t_2419 = heff_strRuneAt(heff_take_field(v_t_240, 1), MK_INT(0LL));
            V v_t_2420 = heff_tag_n(TAG_ERune, 1, (V[]){heff_runeToInt(v_t_2419)});
            V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2421});
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str9))) {
              V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
              V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424});
            } else {
              V v_t_2425 = (g_heff_2esyntax_2esurface_2ewordKw(heff_rfield(v_t_240, 1)));
              V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWord, 1, (V[]){v_t_2425}), v_t_2426});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eatomTok(a[0]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args);
Clo g_heff_2esyntax_2esurface_2estmtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2estmtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2estmtL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Seg: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam4, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Braces: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam5, 1, 1, (V[]){v_m_2477});
  }
  case TAG_Update: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_EUSet: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam7, 1, 1, (V[]){v_m_24108});
  }
  case TAG_InstB: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFSet: {
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam9, 1, 1, (V[]){v_m_24138});
  }
  case TAG_EFDefault: {
    V v_m_24152 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam10, 1, 1, (V[]){v_m_24152});
  }
  case TAG_Sum: {
    V v_m_24168 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam11, 1, 1, (V[]){v_m_24168});
  }
  case TAG_ECon: {
    V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam12, 1, 1, (V[]){v_m_24181});
  }
  case TAG_EField: {
    V v_m_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam13, 1, 1, (V[]){v_m_24194});
  }
  case TAG_ENeg: {
    V v_m_24207 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam14, 1, 1, (V[]){v_m_24207});
  }
  case TAG_App: {
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam15, 1, 1, (V[]){v_m_24220});
  }
  case TAG_Op: {
    V v_m_24234 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam16, 1, 1, (V[]){v_m_24234});
  }
  case TAG_Ops: {
    V v_m_24247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam17, 1, 1, (V[]){v_m_24247});
  }
  case TAG_OpRhs: {
    V v_m_24260 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam18, 1, 1, (V[]){v_m_24260});
  }
  case TAG_Ann: {
    V v_m_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam19, 1, 1, (V[]){v_m_24274});
  }
  case TAG_BVar: {
    V v_m_24286 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam20, 1, 1, (V[]){v_m_24286});
  }
  case TAG_BImp: {
    V v_m_24300 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam21, 1, 1, (V[]){v_m_24300});
  }
  case TAG_BAnn: {
    V v_m_24316 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam22, 1, 1, (V[]){v_m_24316});
  }
  case TAG_Lam: {
    V v_m_24331 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam23, 1, 1, (V[]){v_m_24331});
  }
  case TAG_Case: {
    V v_m_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam24, 1, 1, (V[]){v_m_24346});
  }
  case TAG_EAlt: {
    V v_m_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam25, 1, 1, (V[]){v_m_24360});
  }
  case TAG_If: {
    V v_m_24377 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam26, 1, 1, (V[]){v_m_24377});
  }
  case TAG_Do: {
    V v_m_24390 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam27, 1, 1, (V[]){v_m_24390});
  }
  case TAG_ESBind: {
    V v_x_24401 = heff_field(v_x2_241, 0);
    V v_e_24403 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_24404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24403}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam28, 1, 2, (V[]){v_m_24404, v_x_24401});
  }
  case TAG_ELet: {
    V v_kw_24420 = heff_dup(heff_field(v_x2_241, 0));
    V v_p_24421 = heff_dup(heff_field(v_x2_241, 1));
    V v_ann0_24422 = heff_dup(heff_field(v_x2_241, 2));
    V v_e_24424 = heff_dup(heff_field(v_x2_241, 4));
    V v_x26_24425 = heff_dup(heff_field(v_x2_241, 5));
    switch (heff_tag_of(v_x26_24425)) {
    case TAG_Nothing: {
      heff_drop_tag(v_x2_241, 6);
      V v_m_24426 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_dup(v_p_24421), v_ann0_24422, heff_dup(v_e_24424)));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam29, 1, 4, (V[]){v_m_24426, v_p_24421, v_e_24424, v_kw_24420});
    }
    case TAG_Just: {
      heff_take_n(v_x26_24425, 0ULL, 1);
      heff_drop_rec(v_kw_24420, 9);
      heff_drop(v_p_24421);
      heff_drop(v_ann0_24422);
      heff_drop(v_e_24424);
      V v_m_24446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam30, 1, 1, (V[]){v_m_24446});
    }
    default: return heff_nomatch(v_x26_24425);
    }
  }
  case TAG_ELetMut: {
    V v_kw_24457 = heff_field(v_x2_241, 0);
    V v_x_24459 = heff_field(v_x2_241, 2);
    V v_ann0_24460 = heff_field(v_x2_241, 3);
    V v_e_24462 = heff_field(v_x2_241, 5);
    heff_take_n(v_x2_241, 45ULL, 6);
    V v_m_24463 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_tag_n(TAG_PAtom, 1, (V[]){heff_dup(v_x_24459)}), v_ann0_24460, heff_dup(v_e_24462)));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam31, 1, 4, (V[]){v_m_24463, v_x_24459, v_e_24462, v_kw_24457});
  }
  case TAG_EAssign: {
    V v_m_24484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam32, 1, 1, (V[]){v_m_24484});
  }
  case TAG_EWhile: {
    V v_m_24499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam33, 1, 1, (V[]){v_m_24499});
  }
  case TAG_EFor: {
    V v_m_24516 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam34, 1, 1, (V[]){v_m_24516});
  }
  case TAG_EJump: {
    V v_m_24528 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam35, 1, 1, (V[]){v_m_24528});
  }
  case TAG_EReturn: {
    V v_m_24541 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam36, 1, 1, (V[]){v_m_24541});
  }
  case TAG_ENest: {
    V v_m_24556 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam37, 1, 1, (V[]){v_m_24556});
  }
  case TAG_IfThen: {
    V v_m_24571 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam38, 1, 1, (V[]){v_m_24571});
  }
  case TAG_ELetCond: {
    V v_m_24586 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam39, 1, 1, (V[]){v_m_24586});
  }
  case TAG_ETry: {
    V v_m_24601 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam40, 1, 1, (V[]){v_m_24601});
  }
  case TAG_ECatch: {
    V v_m_24616 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam41, 1, 1, (V[]){v_m_24616});
  }
  case TAG_EWith: {
    V v_m_24633 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam42, 1, 1, (V[]){v_m_24633});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2estmtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_StmtExpr, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_StmtExpr, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_StmtExpr, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_StmtExpr, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_x_2468)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_x_2468, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_x_2468);
      }
      V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_StmtExpr, 1, (V[]){v_x_2468}), v_t_2471});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2472}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      V v_ru_24x11_2480_24Right = heff_take_reuse_n(v_x11_2480, 1ULL, 1);
      V v_t_2486;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_x_2483, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2480_24Right, TAG_StmtExpr, 1, (V[]){v_x_2483}), v_t_2486});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2487}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_StmtExpr, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 1ULL, 1);
      V v_t_24117;
      switch (heff_tag_of(v_x_24114)) {
      case TAG_At: {
        V v_s_24116 = heff_dup(heff_field(v_x_24114, 1));
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_x_24114);
      }
      V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_StmtExpr, 1, (V[]){v_x_24114}), v_t_24117});
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24118}), v_st_24112});
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_StmtExpr, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24147;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_At: {
        V v_s_24146 = heff_dup(heff_field(v_x_24144, 1));
        v_t_24147 = v_s_24146;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_StmtExpr, 1, (V[]){v_x_24144}), v_t_24147});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args) {
  V v_st_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_st_24153}));
  switch (heff_tag_of(v_x1_24154)) {
  case TAG_MkPair: {
    V v_x11_24155 = heff_field(v_x1_24154, 0);
    V v_st_24156 = heff_field(v_x1_24154, 1);
    V v_ru_24x1_24154_24MkPair = heff_take_reuse_n(v_x1_24154, 3ULL, 2);
    switch (heff_tag_of(v_x11_24155)) {
    case TAG_Left: {
      V v_e_24157 = heff_field(v_x11_24155, 0);
      heff_take_n(v_x11_24155, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24157}), v_st_24156});
    }
    case TAG_Right: {
      V v_x_24158 = heff_field(v_x11_24155, 0);
      V v_ru_24x11_24155_24Right = heff_take_reuse_n(v_x11_24155, 1ULL, 1);
      V v_t_24161;
      switch (heff_tag_of(v_x_24158)) {
      case TAG_At: {
        V v_s_24160 = heff_dup(heff_field(v_x_24158, 1));
        v_t_24161 = v_s_24160;
        break;
      }
      default: heff_nomatch(v_x_24158);
      }
      V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24155_24Right, TAG_StmtExpr, 1, (V[]){v_x_24158}), v_t_24161});
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24162}), v_st_24156});
    }
    default: return heff_nomatch(v_x11_24155);
    }
  }
  default: return heff_nomatch(v_x1_24154);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args) {
  V v_st_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_st_24169}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
      V v_t_24177;
      switch (heff_tag_of(v_x_24174)) {
      case TAG_At: {
        V v_s_24176 = heff_dup(heff_field(v_x_24174, 1));
        v_t_24177 = v_s_24176;
        break;
      }
      default: heff_nomatch(v_x_24174);
      }
      V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_StmtExpr, 1, (V[]){v_x_24174}), v_t_24177});
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24178}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24190;
      switch (heff_tag_of(v_x_24187)) {
      case TAG_At: {
        V v_s_24189 = heff_dup(heff_field(v_x_24187, 1));
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_x_24187);
      }
      V v_t_24191 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_StmtExpr, 1, (V[]){v_x_24187}), v_t_24190});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24191}), v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args) {
  V v_st_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_st_24195}));
  switch (heff_tag_of(v_x1_24196)) {
  case TAG_MkPair: {
    V v_x11_24197 = heff_field(v_x1_24196, 0);
    V v_st_24198 = heff_field(v_x1_24196, 1);
    V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
    switch (heff_tag_of(v_x11_24197)) {
    case TAG_Left: {
      V v_e_24199 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
    }
    case TAG_Right: {
      V v_x_24200 = heff_field(v_x11_24197, 0);
      V v_ru_24x11_24197_24Right = heff_take_reuse_n(v_x11_24197, 1ULL, 1);
      V v_t_24203;
      switch (heff_tag_of(v_x_24200)) {
      case TAG_At: {
        V v_s_24202 = heff_dup(heff_field(v_x_24200, 1));
        v_t_24203 = v_s_24202;
        break;
      }
      default: heff_nomatch(v_x_24200);
      }
      V v_t_24204 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24197_24Right, TAG_StmtExpr, 1, (V[]){v_x_24200}), v_t_24203});
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24204}), v_st_24198});
    }
    default: return heff_nomatch(v_x11_24197);
    }
  }
  default: return heff_nomatch(v_x1_24196);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args) {
  V v_st_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24209 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_st_24208}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_MkPair: {
    V v_x11_24210 = heff_field(v_x1_24209, 0);
    V v_st_24211 = heff_field(v_x1_24209, 1);
    V v_ru_24x1_24209_24MkPair = heff_take_reuse_n(v_x1_24209, 3ULL, 2);
    switch (heff_tag_of(v_x11_24210)) {
    case TAG_Left: {
      V v_e_24212 = heff_field(v_x11_24210, 0);
      heff_take_n(v_x11_24210, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24212}), v_st_24211});
    }
    case TAG_Right: {
      V v_x_24213 = heff_field(v_x11_24210, 0);
      V v_ru_24x11_24210_24Right = heff_take_reuse_n(v_x11_24210, 1ULL, 1);
      V v_t_24216;
      switch (heff_tag_of(v_x_24213)) {
      case TAG_At: {
        V v_s_24215 = heff_dup(heff_field(v_x_24213, 1));
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_x_24213);
      }
      V v_t_24217 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24210_24Right, TAG_StmtExpr, 1, (V[]){v_x_24213}), v_t_24216});
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24217}), v_st_24211});
    }
    default: return heff_nomatch(v_x11_24210);
    }
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args) {
  V v_st_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_st_24221}));
  switch (heff_tag_of(v_x1_24222)) {
  case TAG_MkPair: {
    V v_x11_24223 = heff_field(v_x1_24222, 0);
    V v_st_24224 = heff_field(v_x1_24222, 1);
    V v_ru_24x1_24222_24MkPair = heff_take_reuse_n(v_x1_24222, 3ULL, 2);
    switch (heff_tag_of(v_x11_24223)) {
    case TAG_Left: {
      V v_e_24225 = heff_field(v_x11_24223, 0);
      heff_take_n(v_x11_24223, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24225}), v_st_24224});
    }
    case TAG_Right: {
      V v_x_24226 = heff_field(v_x11_24223, 0);
      V v_ru_24x11_24223_24Right = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
      V v_t_24229;
      switch (heff_tag_of(v_x_24226)) {
      case TAG_At: {
        V v_s_24228 = heff_dup(heff_field(v_x_24226, 1));
        v_t_24229 = v_s_24228;
        break;
      }
      default: heff_nomatch(v_x_24226);
      }
      V v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24223_24Right, TAG_StmtExpr, 1, (V[]){v_x_24226}), v_t_24229});
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24230}), v_st_24224});
    }
    default: return heff_nomatch(v_x11_24223);
    }
  }
  default: return heff_nomatch(v_x1_24222);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args) {
  V v_st_24235 = args[0];
  V v_m_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24236 = heff_tr(heff_call(v_m_24234, 1, (V[]){v_st_24235}));
  switch (heff_tag_of(v_x1_24236)) {
  case TAG_MkPair: {
    V v_x11_24237 = heff_field(v_x1_24236, 0);
    V v_st_24238 = heff_field(v_x1_24236, 1);
    V v_ru_24x1_24236_24MkPair = heff_take_reuse_n(v_x1_24236, 3ULL, 2);
    switch (heff_tag_of(v_x11_24237)) {
    case TAG_Left: {
      V v_e_24239 = heff_field(v_x11_24237, 0);
      heff_take_n(v_x11_24237, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24236_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24239}), v_st_24238});
    }
    case TAG_Right: {
      V v_x_24240 = heff_field(v_x11_24237, 0);
      V v_ru_24x11_24237_24Right = heff_take_reuse_n(v_x11_24237, 1ULL, 1);
      V v_t_24243;
      switch (heff_tag_of(v_x_24240)) {
      case TAG_At: {
        V v_s_24242 = heff_dup(heff_field(v_x_24240, 1));
        v_t_24243 = v_s_24242;
        break;
      }
      default: heff_nomatch(v_x_24240);
      }
      V v_t_24244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24237_24Right, TAG_StmtExpr, 1, (V[]){v_x_24240}), v_t_24243});
      return heff_tag_at_n(v_ru_24x1_24236_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24244}), v_st_24238});
    }
    default: return heff_nomatch(v_x11_24237);
    }
  }
  default: return heff_nomatch(v_x1_24236);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      V v_ru_24x11_24250_24Right = heff_take_reuse_n(v_x11_24250, 1ULL, 1);
      V v_t_24256;
      switch (heff_tag_of(v_x_24253)) {
      case TAG_At: {
        V v_s_24255 = heff_dup(heff_field(v_x_24253, 1));
        v_t_24256 = v_s_24255;
        break;
      }
      default: heff_nomatch(v_x_24253);
      }
      V v_t_24257 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24250_24Right, TAG_StmtExpr, 1, (V[]){v_x_24253}), v_t_24256});
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24257}), v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
      V v_t_24269;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24268 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24269 = v_s_24268;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_t_24270 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_StmtExpr, 1, (V[]){v_x_24266}), v_t_24269});
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24270}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args) {
  V v_st_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24276 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_st_24275}));
  switch (heff_tag_of(v_x1_24276)) {
  case TAG_MkPair: {
    V v_x11_24277 = heff_field(v_x1_24276, 0);
    V v_st_24278 = heff_field(v_x1_24276, 1);
    V v_ru_24x1_24276_24MkPair = heff_take_reuse_n(v_x1_24276, 3ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_Left: {
      V v_e_24279 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24279}), v_st_24278});
    }
    case TAG_Right: {
      V v_x_24280 = heff_field(v_x11_24277, 0);
      V v_ru_24x11_24277_24Right = heff_take_reuse_n(v_x11_24277, 1ULL, 1);
      V v_t_24283;
      switch (heff_tag_of(v_x_24280)) {
      case TAG_At: {
        V v_s_24282 = heff_dup(heff_field(v_x_24280, 1));
        v_t_24283 = v_s_24282;
        break;
      }
      default: heff_nomatch(v_x_24280);
      }
      V v_t_24284 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24277_24Right, TAG_StmtExpr, 1, (V[]){v_x_24280}), v_t_24283});
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24284}), v_st_24278});
    }
    default: return heff_nomatch(v_x11_24277);
    }
  }
  default: return heff_nomatch(v_x1_24276);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args) {
  V v_st_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_st_24287}));
  switch (heff_tag_of(v_x1_24288)) {
  case TAG_MkPair: {
    V v_x11_24289 = heff_field(v_x1_24288, 0);
    V v_st_24290 = heff_field(v_x1_24288, 1);
    V v_ru_24x1_24288_24MkPair = heff_take_reuse_n(v_x1_24288, 3ULL, 2);
    switch (heff_tag_of(v_x11_24289)) {
    case TAG_Left: {
      V v_e_24291 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
    }
    case TAG_Right: {
      V v_x_24292 = heff_field(v_x11_24289, 0);
      V v_ru_24x11_24289_24Right = heff_take_reuse_n(v_x11_24289, 1ULL, 1);
      V v_t_24295;
      switch (heff_tag_of(v_x_24292)) {
      case TAG_At: {
        V v_s_24294 = heff_dup(heff_field(v_x_24292, 1));
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_x_24292);
      }
      V v_t_24296 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24289_24Right, TAG_StmtExpr, 1, (V[]){v_x_24292}), v_t_24295});
      return heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24296}), v_st_24290});
    }
    default: return heff_nomatch(v_x11_24289);
    }
  }
  default: return heff_nomatch(v_x1_24288);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args) {
  V v_st_24301 = args[0];
  V v_m_24300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24302 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_st_24301}));
  switch (heff_tag_of(v_x1_24302)) {
  case TAG_MkPair: {
    V v_x11_24303 = heff_field(v_x1_24302, 0);
    V v_st_24304 = heff_field(v_x1_24302, 1);
    V v_ru_24x1_24302_24MkPair = heff_take_reuse_n(v_x1_24302, 3ULL, 2);
    switch (heff_tag_of(v_x11_24303)) {
    case TAG_Left: {
      V v_e_24305 = heff_field(v_x11_24303, 0);
      heff_take_n(v_x11_24303, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24305}), v_st_24304});
    }
    case TAG_Right: {
      V v_x_24306 = heff_field(v_x11_24303, 0);
      V v_ru_24x11_24303_24Right = heff_take_reuse_n(v_x11_24303, 1ULL, 1);
      V v_t_24309;
      switch (heff_tag_of(v_x_24306)) {
      case TAG_At: {
        V v_s_24308 = heff_dup(heff_field(v_x_24306, 1));
        v_t_24309 = v_s_24308;
        break;
      }
      default: heff_nomatch(v_x_24306);
      }
      V v_t_24310 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24303_24Right, TAG_StmtExpr, 1, (V[]){v_x_24306}), v_t_24309});
      return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24310}), v_st_24304});
    }
    default: return heff_nomatch(v_x11_24303);
    }
  }
  default: return heff_nomatch(v_x1_24302);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args) {
  V v_st_24317 = args[0];
  V v_m_24316 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24318 = heff_tr(heff_call(v_m_24316, 1, (V[]){v_st_24317}));
  switch (heff_tag_of(v_x1_24318)) {
  case TAG_MkPair: {
    V v_x11_24319 = heff_field(v_x1_24318, 0);
    V v_st_24320 = heff_field(v_x1_24318, 1);
    V v_ru_24x1_24318_24MkPair = heff_take_reuse_n(v_x1_24318, 3ULL, 2);
    switch (heff_tag_of(v_x11_24319)) {
    case TAG_Left: {
      V v_e_24321 = heff_field(v_x11_24319, 0);
      heff_take_n(v_x11_24319, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24321}), v_st_24320});
    }
    case TAG_Right: {
      V v_x_24322 = heff_field(v_x11_24319, 0);
      V v_ru_24x11_24319_24Right = heff_take_reuse_n(v_x11_24319, 1ULL, 1);
      V v_t_24325;
      switch (heff_tag_of(v_x_24322)) {
      case TAG_At: {
        V v_s_24324 = heff_dup(heff_field(v_x_24322, 1));
        v_t_24325 = v_s_24324;
        break;
      }
      default: heff_nomatch(v_x_24322);
      }
      V v_t_24326 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24319_24Right, TAG_StmtExpr, 1, (V[]){v_x_24322}), v_t_24325});
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24326}), v_st_24320});
    }
    default: return heff_nomatch(v_x11_24319);
    }
  }
  default: return heff_nomatch(v_x1_24318);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args) {
  V v_st_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24333 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_st_24332}));
  switch (heff_tag_of(v_x1_24333)) {
  case TAG_MkPair: {
    V v_x11_24334 = heff_field(v_x1_24333, 0);
    V v_st_24335 = heff_field(v_x1_24333, 1);
    V v_ru_24x1_24333_24MkPair = heff_take_reuse_n(v_x1_24333, 3ULL, 2);
    switch (heff_tag_of(v_x11_24334)) {
    case TAG_Left: {
      V v_e_24336 = heff_field(v_x11_24334, 0);
      heff_take_n(v_x11_24334, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24333_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24336}), v_st_24335});
    }
    case TAG_Right: {
      V v_x_24337 = heff_field(v_x11_24334, 0);
      V v_ru_24x11_24334_24Right = heff_take_reuse_n(v_x11_24334, 1ULL, 1);
      V v_t_24340;
      switch (heff_tag_of(v_x_24337)) {
      case TAG_At: {
        V v_s_24339 = heff_dup(heff_field(v_x_24337, 1));
        v_t_24340 = v_s_24339;
        break;
      }
      default: heff_nomatch(v_x_24337);
      }
      V v_t_24341 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24334_24Right, TAG_StmtExpr, 1, (V[]){v_x_24337}), v_t_24340});
      return heff_tag_at_n(v_ru_24x1_24333_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24341}), v_st_24335});
    }
    default: return heff_nomatch(v_x11_24334);
    }
  }
  default: return heff_nomatch(v_x1_24333);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args) {
  V v_st_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_st_24347}));
  switch (heff_tag_of(v_x1_24348)) {
  case TAG_MkPair: {
    V v_x11_24349 = heff_field(v_x1_24348, 0);
    V v_st_24350 = heff_field(v_x1_24348, 1);
    V v_ru_24x1_24348_24MkPair = heff_take_reuse_n(v_x1_24348, 3ULL, 2);
    switch (heff_tag_of(v_x11_24349)) {
    case TAG_Left: {
      V v_e_24351 = heff_field(v_x11_24349, 0);
      heff_take_n(v_x11_24349, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24351}), v_st_24350});
    }
    case TAG_Right: {
      V v_x_24352 = heff_field(v_x11_24349, 0);
      V v_ru_24x11_24349_24Right = heff_take_reuse_n(v_x11_24349, 1ULL, 1);
      V v_t_24355;
      switch (heff_tag_of(v_x_24352)) {
      case TAG_At: {
        V v_s_24354 = heff_dup(heff_field(v_x_24352, 1));
        v_t_24355 = v_s_24354;
        break;
      }
      default: heff_nomatch(v_x_24352);
      }
      V v_t_24356 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24349_24Right, TAG_StmtExpr, 1, (V[]){v_x_24352}), v_t_24355});
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24356}), v_st_24350});
    }
    default: return heff_nomatch(v_x11_24349);
    }
  }
  default: return heff_nomatch(v_x1_24348);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args) {
  V v_st_24361 = args[0];
  V v_m_24360 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24362 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_st_24361}));
  switch (heff_tag_of(v_x1_24362)) {
  case TAG_MkPair: {
    V v_x11_24363 = heff_field(v_x1_24362, 0);
    V v_st_24364 = heff_field(v_x1_24362, 1);
    V v_ru_24x1_24362_24MkPair = heff_take_reuse_n(v_x1_24362, 3ULL, 2);
    switch (heff_tag_of(v_x11_24363)) {
    case TAG_Left: {
      V v_e_24365 = heff_field(v_x11_24363, 0);
      heff_take_n(v_x11_24363, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24365}), v_st_24364});
    }
    case TAG_Right: {
      V v_x_24366 = heff_field(v_x11_24363, 0);
      V v_ru_24x11_24363_24Right = heff_take_reuse_n(v_x11_24363, 1ULL, 1);
      V v_t_24369;
      switch (heff_tag_of(v_x_24366)) {
      case TAG_At: {
        V v_s_24368 = heff_dup(heff_field(v_x_24366, 1));
        v_t_24369 = v_s_24368;
        break;
      }
      default: heff_nomatch(v_x_24366);
      }
      V v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24363_24Right, TAG_StmtExpr, 1, (V[]){v_x_24366}), v_t_24369});
      return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24370}), v_st_24364});
    }
    default: return heff_nomatch(v_x11_24363);
    }
  }
  default: return heff_nomatch(v_x1_24362);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args) {
  V v_st_24378 = args[0];
  V v_m_24377 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24379 = heff_tr(heff_call(v_m_24377, 1, (V[]){v_st_24378}));
  switch (heff_tag_of(v_x1_24379)) {
  case TAG_MkPair: {
    V v_x11_24380 = heff_field(v_x1_24379, 0);
    V v_st_24381 = heff_field(v_x1_24379, 1);
    V v_ru_24x1_24379_24MkPair = heff_take_reuse_n(v_x1_24379, 3ULL, 2);
    switch (heff_tag_of(v_x11_24380)) {
    case TAG_Left: {
      V v_e_24382 = heff_field(v_x11_24380, 0);
      heff_take_n(v_x11_24380, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24382}), v_st_24381});
    }
    case TAG_Right: {
      V v_x_24383 = heff_field(v_x11_24380, 0);
      V v_ru_24x11_24380_24Right = heff_take_reuse_n(v_x11_24380, 1ULL, 1);
      V v_t_24386;
      switch (heff_tag_of(v_x_24383)) {
      case TAG_At: {
        V v_s_24385 = heff_dup(heff_field(v_x_24383, 1));
        v_t_24386 = v_s_24385;
        break;
      }
      default: heff_nomatch(v_x_24383);
      }
      V v_t_24387 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24380_24Right, TAG_StmtExpr, 1, (V[]){v_x_24383}), v_t_24386});
      return heff_tag_at_n(v_ru_24x1_24379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24387}), v_st_24381});
    }
    default: return heff_nomatch(v_x11_24380);
    }
  }
  default: return heff_nomatch(v_x1_24379);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args) {
  V v_st_24391 = args[0];
  V v_m_24390 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(heff_call(v_m_24390, 1, (V[]){v_st_24391}));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      V v_ru_24x11_24393_24Right = heff_take_reuse_n(v_x11_24393, 1ULL, 1);
      V v_t_24399;
      switch (heff_tag_of(v_x_24396)) {
      case TAG_At: {
        V v_s_24398 = heff_dup(heff_field(v_x_24396, 1));
        v_t_24399 = v_s_24398;
        break;
      }
      default: heff_nomatch(v_x_24396);
      }
      V v_t_24400 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24393_24Right, TAG_StmtExpr, 1, (V[]){v_x_24396}), v_t_24399});
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24400}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args) {
  V v_st_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  V v_x_24401 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_st_24405}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      heff_drop_rec(v_x_24401, 9);
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      V v_ru_24x11_24407_24Right = heff_take_reuse_n(v_x11_24407, 1ULL, 1);
      V v_t_24411 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24401, 3)), heff_take_field(v_x_24401, 4)});
      V v_t_24412 = heff_tag_n(TAG_StmtBind, 3, (V[]){heff_dup(heff_rfield(v_x_24401, 1)), v_t_24411, heff_dup(v_x_24410)});
      V v_t_24415;
      switch (heff_tag_of(v_x_24410)) {
      case TAG_At: {
        V v_s_24414 = heff_field(v_x_24410, 1);
        heff_take_n(v_x_24410, 2ULL, 2);
        v_t_24415 = v_s_24414;
        break;
      }
      default: heff_nomatch(v_x_24410);
      }
      V v_t_24416 = ({ V rv_0 = heff_take_field(v_x_24401, 3); V rr_ = heff_rec_reuse_nf(v_t_24415, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24417 = heff_tag_at_n(v_ru_24x11_24407_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24412, v_t_24416})});
      V v_t_24418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24401, 1, 9), heff_take_field(v_st_24408, 1)});
      V v_t_24419 = ({ V rv_1 = v_t_24418; V rr_ = heff_rec_reuse_nf(v_st_24408, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){v_t_24417, v_t_24419});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args) {
  V v_st_24427 = args[0];
  V v_m_24426 = heff_env(self)[0];
  V v_p_24421 = heff_env(self)[1];
  V v_e_24424 = heff_env(self)[2];
  V v_kw_24420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24428 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_st_24427}));
  switch (heff_tag_of(v_x1_24428)) {
  case TAG_MkPair: {
    V v_x11_24429 = heff_field(v_x1_24428, 0);
    V v_st_24430 = heff_field(v_x1_24428, 1);
    V v_ru_24x1_24428_24MkPair = heff_take_reuse_n(v_x1_24428, 3ULL, 2);
    switch (heff_tag_of(v_x11_24429)) {
    case TAG_Left: {
      V v_e_24431 = heff_field(v_x11_24429, 0);
      heff_take_n(v_x11_24429, 1ULL, 1);
      heff_drop(v_p_24421);
      heff_drop(v_e_24424);
      heff_drop_rec(v_kw_24420, 9);
      return heff_tag_at_n(v_ru_24x1_24428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24431}), v_st_24430});
    }
    case TAG_Right: {
      V v_x_24432 = heff_field(v_x11_24429, 0);
      heff_take_n(v_x11_24429, 1ULL, 1);
      V v_sc_24433 = ({ V a_0 = heff_take_field(v_st_24430, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24421; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24421); r_; });
      V v_t_24436;
      switch (heff_tag_of(v_x_24432)) {
      case TAG_MkPair: {
        V v_x_24434 = heff_dup(heff_field(v_x_24432, 0));
        v_t_24436 = v_x_24434;
        break;
      }
      default: heff_nomatch(v_x_24432);
      }
      V v_t_24439;
      switch (heff_tag_of(v_x_24432)) {
      case TAG_MkPair: {
        V v_y_24438 = heff_field(v_x_24432, 1);
        heff_take_n(v_x_24432, 2ULL, 2);
        v_t_24439 = v_y_24438;
        break;
      }
      default: heff_nomatch(v_x_24432);
      }
      V v_t_24440 = (g_heff_2esyntax_2ecst_2elastE(v_e_24424));
      V v_e_24441 = heff_get_n(v_t_24440, 4, 9);
      V v_t_24442 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24420, 3, 9), v_e_24441});
      V v_x_24443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_t_24436, v_t_24439}), v_t_24442});
      V v_t_24444 = ({ V rv_1 = v_sc_24433; V rr_ = heff_rec_reuse_nf(v_st_24430, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24443}), v_t_24444});
    }
    default: return heff_nomatch(v_x11_24429);
    }
  }
  default: return heff_nomatch(v_x1_24428);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args) {
  V v_st_24447 = args[0];
  V v_m_24446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24448 = heff_tr(heff_call(v_m_24446, 1, (V[]){v_st_24447}));
  switch (heff_tag_of(v_x1_24448)) {
  case TAG_MkPair: {
    V v_x11_24449 = heff_field(v_x1_24448, 0);
    V v_st_24450 = heff_field(v_x1_24448, 1);
    V v_ru_24x1_24448_24MkPair = heff_take_reuse_n(v_x1_24448, 3ULL, 2);
    switch (heff_tag_of(v_x11_24449)) {
    case TAG_Left: {
      V v_e_24451 = heff_field(v_x11_24449, 0);
      heff_take_n(v_x11_24449, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24451}), v_st_24450});
    }
    case TAG_Right: {
      V v_x_24452 = heff_field(v_x11_24449, 0);
      V v_ru_24x11_24449_24Right = heff_take_reuse_n(v_x11_24449, 1ULL, 1);
      V v_t_24455;
      switch (heff_tag_of(v_x_24452)) {
      case TAG_At: {
        V v_s_24454 = heff_dup(heff_field(v_x_24452, 1));
        v_t_24455 = v_s_24454;
        break;
      }
      default: heff_nomatch(v_x_24452);
      }
      V v_t_24456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24449_24Right, TAG_StmtExpr, 1, (V[]){v_x_24452}), v_t_24455});
      return heff_tag_at_n(v_ru_24x1_24448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24456}), v_st_24450});
    }
    default: return heff_nomatch(v_x11_24449);
    }
  }
  default: return heff_nomatch(v_x1_24448);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args) {
  V v_st_24464 = args[0];
  V v_m_24463 = heff_env(self)[0];
  V v_x_24459 = heff_env(self)[1];
  V v_e_24462 = heff_env(self)[2];
  V v_kw_24457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24465 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_st_24464}));
  switch (heff_tag_of(v_x1_24465)) {
  case TAG_MkPair: {
    V v_x11_24466 = heff_field(v_x1_24465, 0);
    V v_st_24467 = heff_field(v_x1_24465, 1);
    V v_ru_24x1_24465_24MkPair = heff_take_reuse_n(v_x1_24465, 3ULL, 2);
    switch (heff_tag_of(v_x11_24466)) {
    case TAG_Left: {
      V v_e_24468 = heff_field(v_x11_24466, 0);
      heff_take_n(v_x11_24466, 1ULL, 1);
      heff_drop_rec(v_x_24459, 9);
      heff_drop(v_e_24462);
      heff_drop_rec(v_kw_24457, 9);
      return heff_tag_at_n(v_ru_24x1_24465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24468}), v_st_24467});
    }
    case TAG_Right: {
      V v_x_24469 = heff_field(v_x11_24466, 0);
      heff_take_n(v_x11_24466, 1ULL, 1);
      V v_t_24470 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24459, 3), heff_take_field(v_x_24459, 4)});
      V v_t_24473;
      switch (heff_tag_of(v_x_24469)) {
      case TAG_MkPair: {
        V v_y_24472 = heff_field(v_x_24469, 1);
        heff_take_n(v_x_24469, 2ULL, 2);
        v_t_24473 = v_y_24472;
        break;
      }
      default: heff_nomatch(v_x_24469);
      }
      V v_t_24474 = heff_tag_n(TAG_StmtLetMut, 3, (V[]){heff_dup(heff_rfield(v_x_24459, 1)), v_t_24470, v_t_24473});
      V v_t_24475 = (g_heff_2esyntax_2ecst_2elastE(v_e_24462));
      V v_e_24476 = heff_get_n(v_t_24475, 4, 9);
      V v_t_24477 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24457, 3, 9), v_e_24476});
      V v_x_24478 = heff_tag_n(TAG_At, 2, (V[]){v_t_24474, v_t_24477});
      V v_t_24479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24459, 1, 9), heff_take_field(v_st_24467, 1)});
      V v_t_24480 = ({ V rv_1 = v_t_24479; V rr_ = heff_rec_reuse_nf(v_st_24467, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24478}), v_t_24480});
    }
    default: return heff_nomatch(v_x11_24466);
    }
  }
  default: return heff_nomatch(v_x1_24465);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args) {
  V v_st_24485 = args[0];
  V v_m_24484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24486 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_st_24485}));
  switch (heff_tag_of(v_x1_24486)) {
  case TAG_MkPair: {
    V v_x11_24487 = heff_field(v_x1_24486, 0);
    V v_st_24488 = heff_field(v_x1_24486, 1);
    V v_ru_24x1_24486_24MkPair = heff_take_reuse_n(v_x1_24486, 3ULL, 2);
    switch (heff_tag_of(v_x11_24487)) {
    case TAG_Left: {
      V v_e_24489 = heff_field(v_x11_24487, 0);
      heff_take_n(v_x11_24487, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24489}), v_st_24488});
    }
    case TAG_Right: {
      V v_x_24490 = heff_field(v_x11_24487, 0);
      V v_ru_24x11_24487_24Right = heff_take_reuse_n(v_x11_24487, 1ULL, 1);
      V v_t_24493;
      switch (heff_tag_of(v_x_24490)) {
      case TAG_At: {
        V v_s_24492 = heff_dup(heff_field(v_x_24490, 1));
        v_t_24493 = v_s_24492;
        break;
      }
      default: heff_nomatch(v_x_24490);
      }
      V v_t_24494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24487_24Right, TAG_StmtExpr, 1, (V[]){v_x_24490}), v_t_24493});
      return heff_tag_at_n(v_ru_24x1_24486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24494}), v_st_24488});
    }
    default: return heff_nomatch(v_x11_24487);
    }
  }
  default: return heff_nomatch(v_x1_24486);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args) {
  V v_st_24500 = args[0];
  V v_m_24499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24501 = heff_tr(heff_call(v_m_24499, 1, (V[]){v_st_24500}));
  switch (heff_tag_of(v_x1_24501)) {
  case TAG_MkPair: {
    V v_x11_24502 = heff_field(v_x1_24501, 0);
    V v_st_24503 = heff_field(v_x1_24501, 1);
    V v_ru_24x1_24501_24MkPair = heff_take_reuse_n(v_x1_24501, 3ULL, 2);
    switch (heff_tag_of(v_x11_24502)) {
    case TAG_Left: {
      V v_e_24504 = heff_field(v_x11_24502, 0);
      heff_take_n(v_x11_24502, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24504}), v_st_24503});
    }
    case TAG_Right: {
      V v_x_24505 = heff_field(v_x11_24502, 0);
      V v_ru_24x11_24502_24Right = heff_take_reuse_n(v_x11_24502, 1ULL, 1);
      V v_t_24508;
      switch (heff_tag_of(v_x_24505)) {
      case TAG_At: {
        V v_s_24507 = heff_dup(heff_field(v_x_24505, 1));
        v_t_24508 = v_s_24507;
        break;
      }
      default: heff_nomatch(v_x_24505);
      }
      V v_t_24509 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24502_24Right, TAG_StmtExpr, 1, (V[]){v_x_24505}), v_t_24508});
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24509}), v_st_24503});
    }
    default: return heff_nomatch(v_x11_24502);
    }
  }
  default: return heff_nomatch(v_x1_24501);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args) {
  V v_st_24517 = args[0];
  V v_m_24516 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24518 = heff_tr(heff_call(v_m_24516, 1, (V[]){v_st_24517}));
  switch (heff_tag_of(v_x1_24518)) {
  case TAG_MkPair: {
    V v_x11_24519 = heff_field(v_x1_24518, 0);
    V v_st_24520 = heff_field(v_x1_24518, 1);
    V v_ru_24x1_24518_24MkPair = heff_take_reuse_n(v_x1_24518, 3ULL, 2);
    switch (heff_tag_of(v_x11_24519)) {
    case TAG_Left: {
      V v_e_24521 = heff_field(v_x11_24519, 0);
      heff_take_n(v_x11_24519, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24518_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24521}), v_st_24520});
    }
    case TAG_Right: {
      V v_x_24522 = heff_field(v_x11_24519, 0);
      V v_ru_24x11_24519_24Right = heff_take_reuse_n(v_x11_24519, 1ULL, 1);
      V v_t_24525;
      switch (heff_tag_of(v_x_24522)) {
      case TAG_At: {
        V v_s_24524 = heff_dup(heff_field(v_x_24522, 1));
        v_t_24525 = v_s_24524;
        break;
      }
      default: heff_nomatch(v_x_24522);
      }
      V v_t_24526 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24519_24Right, TAG_StmtExpr, 1, (V[]){v_x_24522}), v_t_24525});
      return heff_tag_at_n(v_ru_24x1_24518_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24526}), v_st_24520});
    }
    default: return heff_nomatch(v_x11_24519);
    }
  }
  default: return heff_nomatch(v_x1_24518);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args) {
  V v_st_24529 = args[0];
  V v_m_24528 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24530 = heff_tr(heff_call(v_m_24528, 1, (V[]){v_st_24529}));
  switch (heff_tag_of(v_x1_24530)) {
  case TAG_MkPair: {
    V v_x11_24531 = heff_field(v_x1_24530, 0);
    V v_st_24532 = heff_field(v_x1_24530, 1);
    V v_ru_24x1_24530_24MkPair = heff_take_reuse_n(v_x1_24530, 3ULL, 2);
    switch (heff_tag_of(v_x11_24531)) {
    case TAG_Left: {
      V v_e_24533 = heff_field(v_x11_24531, 0);
      heff_take_n(v_x11_24531, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24533}), v_st_24532});
    }
    case TAG_Right: {
      V v_x_24534 = heff_field(v_x11_24531, 0);
      V v_ru_24x11_24531_24Right = heff_take_reuse_n(v_x11_24531, 1ULL, 1);
      V v_t_24537;
      switch (heff_tag_of(v_x_24534)) {
      case TAG_At: {
        V v_s_24536 = heff_dup(heff_field(v_x_24534, 1));
        v_t_24537 = v_s_24536;
        break;
      }
      default: heff_nomatch(v_x_24534);
      }
      V v_t_24538 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24531_24Right, TAG_StmtExpr, 1, (V[]){v_x_24534}), v_t_24537});
      return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24538}), v_st_24532});
    }
    default: return heff_nomatch(v_x11_24531);
    }
  }
  default: return heff_nomatch(v_x1_24530);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args) {
  V v_st_24542 = args[0];
  V v_m_24541 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24543 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_st_24542}));
  switch (heff_tag_of(v_x1_24543)) {
  case TAG_MkPair: {
    V v_x11_24544 = heff_field(v_x1_24543, 0);
    V v_st_24545 = heff_field(v_x1_24543, 1);
    V v_ru_24x1_24543_24MkPair = heff_take_reuse_n(v_x1_24543, 3ULL, 2);
    switch (heff_tag_of(v_x11_24544)) {
    case TAG_Left: {
      V v_e_24546 = heff_field(v_x11_24544, 0);
      heff_take_n(v_x11_24544, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24546}), v_st_24545});
    }
    case TAG_Right: {
      V v_x_24547 = heff_field(v_x11_24544, 0);
      V v_ru_24x11_24544_24Right = heff_take_reuse_n(v_x11_24544, 1ULL, 1);
      V v_t_24550;
      switch (heff_tag_of(v_x_24547)) {
      case TAG_At: {
        V v_s_24549 = heff_dup(heff_field(v_x_24547, 1));
        v_t_24550 = v_s_24549;
        break;
      }
      default: heff_nomatch(v_x_24547);
      }
      V v_t_24551 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24544_24Right, TAG_StmtExpr, 1, (V[]){v_x_24547}), v_t_24550});
      return heff_tag_at_n(v_ru_24x1_24543_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24551}), v_st_24545});
    }
    default: return heff_nomatch(v_x11_24544);
    }
  }
  default: return heff_nomatch(v_x1_24543);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args) {
  V v_st_24557 = args[0];
  V v_m_24556 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24558 = heff_tr(heff_call(v_m_24556, 1, (V[]){v_st_24557}));
  switch (heff_tag_of(v_x1_24558)) {
  case TAG_MkPair: {
    V v_x11_24559 = heff_field(v_x1_24558, 0);
    V v_st_24560 = heff_field(v_x1_24558, 1);
    V v_ru_24x1_24558_24MkPair = heff_take_reuse_n(v_x1_24558, 3ULL, 2);
    switch (heff_tag_of(v_x11_24559)) {
    case TAG_Left: {
      V v_e_24561 = heff_field(v_x11_24559, 0);
      heff_take_n(v_x11_24559, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24558_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24561}), v_st_24560});
    }
    case TAG_Right: {
      V v_x_24562 = heff_field(v_x11_24559, 0);
      V v_ru_24x11_24559_24Right = heff_take_reuse_n(v_x11_24559, 1ULL, 1);
      V v_t_24565;
      switch (heff_tag_of(v_x_24562)) {
      case TAG_At: {
        V v_s_24564 = heff_dup(heff_field(v_x_24562, 1));
        v_t_24565 = v_s_24564;
        break;
      }
      default: heff_nomatch(v_x_24562);
      }
      V v_t_24566 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24559_24Right, TAG_StmtExpr, 1, (V[]){v_x_24562}), v_t_24565});
      return heff_tag_at_n(v_ru_24x1_24558_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24566}), v_st_24560});
    }
    default: return heff_nomatch(v_x11_24559);
    }
  }
  default: return heff_nomatch(v_x1_24558);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args) {
  V v_st_24572 = args[0];
  V v_m_24571 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24573 = heff_tr(heff_call(v_m_24571, 1, (V[]){v_st_24572}));
  switch (heff_tag_of(v_x1_24573)) {
  case TAG_MkPair: {
    V v_x11_24574 = heff_field(v_x1_24573, 0);
    V v_st_24575 = heff_field(v_x1_24573, 1);
    V v_ru_24x1_24573_24MkPair = heff_take_reuse_n(v_x1_24573, 3ULL, 2);
    switch (heff_tag_of(v_x11_24574)) {
    case TAG_Left: {
      V v_e_24576 = heff_field(v_x11_24574, 0);
      heff_take_n(v_x11_24574, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24576}), v_st_24575});
    }
    case TAG_Right: {
      V v_x_24577 = heff_field(v_x11_24574, 0);
      V v_ru_24x11_24574_24Right = heff_take_reuse_n(v_x11_24574, 1ULL, 1);
      V v_t_24580;
      switch (heff_tag_of(v_x_24577)) {
      case TAG_At: {
        V v_s_24579 = heff_dup(heff_field(v_x_24577, 1));
        v_t_24580 = v_s_24579;
        break;
      }
      default: heff_nomatch(v_x_24577);
      }
      V v_t_24581 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24574_24Right, TAG_StmtExpr, 1, (V[]){v_x_24577}), v_t_24580});
      return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24581}), v_st_24575});
    }
    default: return heff_nomatch(v_x11_24574);
    }
  }
  default: return heff_nomatch(v_x1_24573);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args) {
  V v_st_24587 = args[0];
  V v_m_24586 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24588 = heff_tr(heff_call(v_m_24586, 1, (V[]){v_st_24587}));
  switch (heff_tag_of(v_x1_24588)) {
  case TAG_MkPair: {
    V v_x11_24589 = heff_field(v_x1_24588, 0);
    V v_st_24590 = heff_field(v_x1_24588, 1);
    V v_ru_24x1_24588_24MkPair = heff_take_reuse_n(v_x1_24588, 3ULL, 2);
    switch (heff_tag_of(v_x11_24589)) {
    case TAG_Left: {
      V v_e_24591 = heff_field(v_x11_24589, 0);
      heff_take_n(v_x11_24589, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24588_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24591}), v_st_24590});
    }
    case TAG_Right: {
      V v_x_24592 = heff_field(v_x11_24589, 0);
      V v_ru_24x11_24589_24Right = heff_take_reuse_n(v_x11_24589, 1ULL, 1);
      V v_t_24595;
      switch (heff_tag_of(v_x_24592)) {
      case TAG_At: {
        V v_s_24594 = heff_dup(heff_field(v_x_24592, 1));
        v_t_24595 = v_s_24594;
        break;
      }
      default: heff_nomatch(v_x_24592);
      }
      V v_t_24596 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24589_24Right, TAG_StmtExpr, 1, (V[]){v_x_24592}), v_t_24595});
      return heff_tag_at_n(v_ru_24x1_24588_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24596}), v_st_24590});
    }
    default: return heff_nomatch(v_x11_24589);
    }
  }
  default: return heff_nomatch(v_x1_24588);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args) {
  V v_st_24602 = args[0];
  V v_m_24601 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24603 = heff_tr(heff_call(v_m_24601, 1, (V[]){v_st_24602}));
  switch (heff_tag_of(v_x1_24603)) {
  case TAG_MkPair: {
    V v_x11_24604 = heff_field(v_x1_24603, 0);
    V v_st_24605 = heff_field(v_x1_24603, 1);
    V v_ru_24x1_24603_24MkPair = heff_take_reuse_n(v_x1_24603, 3ULL, 2);
    switch (heff_tag_of(v_x11_24604)) {
    case TAG_Left: {
      V v_e_24606 = heff_field(v_x11_24604, 0);
      heff_take_n(v_x11_24604, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24603_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24606}), v_st_24605});
    }
    case TAG_Right: {
      V v_x_24607 = heff_field(v_x11_24604, 0);
      V v_ru_24x11_24604_24Right = heff_take_reuse_n(v_x11_24604, 1ULL, 1);
      V v_t_24610;
      switch (heff_tag_of(v_x_24607)) {
      case TAG_At: {
        V v_s_24609 = heff_dup(heff_field(v_x_24607, 1));
        v_t_24610 = v_s_24609;
        break;
      }
      default: heff_nomatch(v_x_24607);
      }
      V v_t_24611 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24604_24Right, TAG_StmtExpr, 1, (V[]){v_x_24607}), v_t_24610});
      return heff_tag_at_n(v_ru_24x1_24603_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24611}), v_st_24605});
    }
    default: return heff_nomatch(v_x11_24604);
    }
  }
  default: return heff_nomatch(v_x1_24603);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args) {
  V v_st_24617 = args[0];
  V v_m_24616 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24618 = heff_tr(heff_call(v_m_24616, 1, (V[]){v_st_24617}));
  switch (heff_tag_of(v_x1_24618)) {
  case TAG_MkPair: {
    V v_x11_24619 = heff_field(v_x1_24618, 0);
    V v_st_24620 = heff_field(v_x1_24618, 1);
    V v_ru_24x1_24618_24MkPair = heff_take_reuse_n(v_x1_24618, 3ULL, 2);
    switch (heff_tag_of(v_x11_24619)) {
    case TAG_Left: {
      V v_e_24621 = heff_field(v_x11_24619, 0);
      heff_take_n(v_x11_24619, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24621}), v_st_24620});
    }
    case TAG_Right: {
      V v_x_24622 = heff_field(v_x11_24619, 0);
      V v_ru_24x11_24619_24Right = heff_take_reuse_n(v_x11_24619, 1ULL, 1);
      V v_t_24625;
      switch (heff_tag_of(v_x_24622)) {
      case TAG_At: {
        V v_s_24624 = heff_dup(heff_field(v_x_24622, 1));
        v_t_24625 = v_s_24624;
        break;
      }
      default: heff_nomatch(v_x_24622);
      }
      V v_t_24626 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24619_24Right, TAG_StmtExpr, 1, (V[]){v_x_24622}), v_t_24625});
      return heff_tag_at_n(v_ru_24x1_24618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24626}), v_st_24620});
    }
    default: return heff_nomatch(v_x11_24619);
    }
  }
  default: return heff_nomatch(v_x1_24618);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args) {
  V v_st_24634 = args[0];
  V v_m_24633 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24635 = heff_tr(heff_call(v_m_24633, 1, (V[]){v_st_24634}));
  switch (heff_tag_of(v_x1_24635)) {
  case TAG_MkPair: {
    V v_x11_24636 = heff_field(v_x1_24635, 0);
    V v_st_24637 = heff_field(v_x1_24635, 1);
    V v_ru_24x1_24635_24MkPair = heff_take_reuse_n(v_x1_24635, 3ULL, 2);
    switch (heff_tag_of(v_x11_24636)) {
    case TAG_Left: {
      V v_e_24638 = heff_field(v_x11_24636, 0);
      heff_take_n(v_x11_24636, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24638}), v_st_24637});
    }
    case TAG_Right: {
      V v_x_24639 = heff_field(v_x11_24636, 0);
      V v_ru_24x11_24636_24Right = heff_take_reuse_n(v_x11_24636, 1ULL, 1);
      V v_t_24642;
      switch (heff_tag_of(v_x_24639)) {
      case TAG_At: {
        V v_s_24641 = heff_dup(heff_field(v_x_24639, 1));
        v_t_24642 = v_s_24641;
        break;
      }
      default: heff_nomatch(v_x_24639);
      }
      V v_t_24643 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24636_24Right, TAG_StmtExpr, 1, (V[]){v_x_24639}), v_t_24642});
      return heff_tag_at_n(v_ru_24x1_24635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24643}), v_st_24637});
    }
    default: return heff_nomatch(v_x11_24636);
    }
  }
  default: return heff_nomatch(v_x1_24635);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str81, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecatchL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatchL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatchL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop(v_r_240);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop(v_r_240);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop(v_r_240);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop(v_r_240);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Seg: {
    heff_drop(v_r_240);
    V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2447 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str8));
    V v_msg_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str9), v_t_2448);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam4, 1, 2, (V[]){v_t_2446, v_msg_2449});
  }
  case TAG_Braces: {
    heff_drop(v_r_240);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2458 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2459 = heff_strAppend(heff_get_n(v_t_2458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str10));
    V v_msg_2460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str11), v_t_2459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam5, 1, 2, (V[]){v_t_2457, v_msg_2460});
  }
  case TAG_Update: {
    heff_drop(v_r_240);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_EUSet: {
    heff_drop(v_r_240);
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2481 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str14));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str15), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam7, 1, 2, (V[]){v_t_2480, v_msg_2483});
  }
  case TAG_InstB: {
    heff_drop(v_r_240);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFSet: {
    heff_drop(v_r_240);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_EFDefault: {
    heff_drop(v_r_240);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24113 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24114 = heff_strAppend(heff_get_n(v_t_24113, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str20));
    V v_msg_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str21), v_t_24114);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam10, 1, 2, (V[]){v_t_24112, v_msg_24115});
  }
  case TAG_Sum: {
    heff_drop(v_r_240);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24125 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str22));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str23), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam11, 1, 2, (V[]){v_t_24124, v_msg_24127});
  }
  case TAG_ECon: {
    heff_drop(v_r_240);
    V v_t_24133 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24134 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str24));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str25), v_t_24135);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam12, 1, 2, (V[]){v_t_24133, v_msg_24136});
  }
  case TAG_EField: {
    heff_drop(v_r_240);
    V v_t_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24143 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24144 = heff_strAppend(heff_get_n(v_t_24143, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str26));
    V v_msg_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str27), v_t_24144);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam13, 1, 2, (V[]){v_t_24142, v_msg_24145});
  }
  case TAG_ENeg: {
    heff_drop(v_r_240);
    V v_t_24151 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24152 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24153 = heff_strAppend(heff_get_n(v_t_24152, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str28));
    V v_msg_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str29), v_t_24153);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam14, 1, 2, (V[]){v_t_24151, v_msg_24154});
  }
  case TAG_App: {
    heff_drop(v_r_240);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Op: {
    heff_drop(v_r_240);
    V v_t_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24171 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24172 = heff_strAppend(heff_get_n(v_t_24171, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str32));
    V v_msg_24173 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str33), v_t_24172);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam16, 1, 2, (V[]){v_t_24170, v_msg_24173});
  }
  case TAG_Ops: {
    heff_drop(v_r_240);
    V v_t_24179 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24180 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str34));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str35), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam17, 1, 2, (V[]){v_t_24179, v_msg_24182});
  }
  case TAG_OpRhs: {
    heff_drop(v_r_240);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_Ann: {
    heff_drop(v_r_240);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24199 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str38));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str39), v_t_24200);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam19, 1, 2, (V[]){v_t_24198, v_msg_24201});
  }
  case TAG_BVar: {
    heff_drop(v_r_240);
    V v_t_24206 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24207 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24208 = heff_strAppend(heff_get_n(v_t_24207, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str40));
    V v_msg_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str41), v_t_24208);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam20, 1, 2, (V[]){v_t_24206, v_msg_24209});
  }
  case TAG_BImp: {
    heff_drop(v_r_240);
    V v_t_24216 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24217 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24218 = heff_strAppend(heff_get_n(v_t_24217, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str42));
    V v_msg_24219 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str43), v_t_24218);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam21, 1, 2, (V[]){v_t_24216, v_msg_24219});
  }
  case TAG_BAnn: {
    heff_drop(v_r_240);
    V v_t_24228 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24229 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24230 = heff_strAppend(heff_get_n(v_t_24229, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str44));
    V v_msg_24231 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str45), v_t_24230);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam22, 1, 2, (V[]){v_t_24228, v_msg_24231});
  }
  case TAG_Lam: {
    heff_drop(v_r_240);
    V v_t_24239 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24240 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24241 = heff_strAppend(heff_get_n(v_t_24240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str46));
    V v_msg_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str47), v_t_24241);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam23, 1, 2, (V[]){v_t_24239, v_msg_24242});
  }
  case TAG_Case: {
    heff_drop(v_r_240);
    V v_t_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24251 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24252 = heff_strAppend(heff_get_n(v_t_24251, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str48));
    V v_msg_24253 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str49), v_t_24252);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam24, 1, 2, (V[]){v_t_24250, v_msg_24253});
  }
  case TAG_EAlt: {
    heff_drop(v_r_240);
    V v_t_24260 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24261 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24262 = heff_strAppend(heff_get_n(v_t_24261, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str50));
    V v_msg_24263 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str51), v_t_24262);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam25, 1, 2, (V[]){v_t_24260, v_msg_24263});
  }
  case TAG_If: {
    heff_drop(v_r_240);
    V v_t_24273 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24274 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24275 = heff_strAppend(heff_get_n(v_t_24274, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str52));
    V v_msg_24276 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str53), v_t_24275);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam26, 1, 2, (V[]){v_t_24273, v_msg_24276});
  }
  case TAG_Do: {
    heff_drop(v_r_240);
    V v_t_24282 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24283 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24284 = heff_strAppend(heff_get_n(v_t_24283, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str54));
    V v_msg_24285 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str55), v_t_24284);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam27, 1, 2, (V[]){v_t_24282, v_msg_24285});
  }
  case TAG_ESBind: {
    heff_drop(v_r_240);
    V v_t_24292 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24293 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24294 = heff_strAppend(heff_get_n(v_t_24293, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str56));
    V v_msg_24295 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str57), v_t_24294);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam28, 1, 2, (V[]){v_t_24292, v_msg_24295});
  }
  case TAG_ELet: {
    heff_drop(v_r_240);
    V v_t_24305 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24306 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24307 = heff_strAppend(heff_get_n(v_t_24306, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str58));
    V v_msg_24308 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str59), v_t_24307);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam29, 1, 2, (V[]){v_t_24305, v_msg_24308});
  }
  case TAG_ELetMut: {
    heff_drop(v_r_240);
    V v_t_24318 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24319 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24320 = heff_strAppend(heff_get_n(v_t_24319, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str60));
    V v_msg_24321 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str61), v_t_24320);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam30, 1, 2, (V[]){v_t_24318, v_msg_24321});
  }
  case TAG_EAssign: {
    heff_drop(v_r_240);
    V v_t_24328 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24329 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24330 = heff_strAppend(heff_get_n(v_t_24329, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str62));
    V v_msg_24331 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str63), v_t_24330);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam31, 1, 2, (V[]){v_t_24328, v_msg_24331});
  }
  case TAG_EWhile: {
    heff_drop(v_r_240);
    V v_t_24339 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24340 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24341 = heff_strAppend(heff_get_n(v_t_24340, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str64));
    V v_msg_24342 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str65), v_t_24341);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam32, 1, 2, (V[]){v_t_24339, v_msg_24342});
  }
  case TAG_EFor: {
    heff_drop(v_r_240);
    V v_t_24352 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24353 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24354 = heff_strAppend(heff_get_n(v_t_24353, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str66));
    V v_msg_24355 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str67), v_t_24354);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam33, 1, 2, (V[]){v_t_24352, v_msg_24355});
  }
  case TAG_EJump: {
    heff_drop(v_r_240);
    V v_t_24360 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24361 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24362 = heff_strAppend(heff_get_n(v_t_24361, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str68));
    V v_msg_24363 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str69), v_t_24362);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam34, 1, 2, (V[]){v_t_24360, v_msg_24363});
  }
  case TAG_EReturn: {
    heff_drop(v_r_240);
    V v_t_24369 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24370 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24371 = heff_strAppend(heff_get_n(v_t_24370, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str70));
    V v_msg_24372 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str71), v_t_24371);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam35, 1, 2, (V[]){v_t_24369, v_msg_24372});
  }
  case TAG_ENest: {
    heff_drop(v_r_240);
    V v_t_24380 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24381 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24382 = heff_strAppend(heff_get_n(v_t_24381, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str72));
    V v_msg_24383 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str73), v_t_24382);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam36, 1, 2, (V[]){v_t_24380, v_msg_24383});
  }
  case TAG_IfThen: {
    heff_drop(v_r_240);
    V v_t_24391 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24392 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24393 = heff_strAppend(heff_get_n(v_t_24392, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str74));
    V v_msg_24394 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str75), v_t_24393);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam37, 1, 2, (V[]){v_t_24391, v_msg_24394});
  }
  case TAG_ELetCond: {
    heff_drop(v_r_240);
    V v_t_24402 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24403 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24404 = heff_strAppend(heff_get_n(v_t_24403, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str76));
    V v_msg_24405 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str77), v_t_24404);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam38, 1, 2, (V[]){v_t_24402, v_msg_24405});
  }
  case TAG_ETry: {
    heff_drop(v_r_240);
    V v_t_24413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24415 = heff_strAppend(heff_get_n(v_t_24414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str78));
    V v_msg_24416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str79), v_t_24415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam39, 1, 2, (V[]){v_t_24413, v_msg_24416});
  }
  case TAG_ECatch: {
    V v_b_24421 = heff_field(v_e_241, 1);
    V v_body_24423 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 4);
    V v_m_24424 = (g_heff_2esyntax_2esurface_2elamBinderL(heff_dup(v_r_240), v_b_24421));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam40, 1, 3, (V[]){v_m_24424, v_r_240, v_body_24423});
  }
  case TAG_EWith: {
    heff_drop(v_r_240);
    V v_t_24456 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24457 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24458 = heff_strAppend(heff_get_n(v_t_24457, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str80));
    V v_msg_24459 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str81), v_t_24458);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam42, 1, 2, (V[]){v_t_24456, v_msg_24459});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatchL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args) {
  V v_st_2450 = args[0];
  V v_t_2446 = heff_env(self)[0];
  V v_msg_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2446, 3), heff_get_n(v_t_2446, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, v_t_2451, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2452}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args) {
  V v_st_2461 = args[0];
  V v_t_2457 = heff_env(self)[0];
  V v_msg_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2457, 3), heff_get_n(v_t_2457, 4, 9)});
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2460, v_t_2462, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2461});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args) {
  V v_st_2484 = args[0];
  V v_t_2480 = heff_env(self)[0];
  V v_msg_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2480, 3), heff_get_n(v_t_2480, 4, 9)});
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, v_t_2485, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args) {
  V v_st_24116 = args[0];
  V v_t_24112 = heff_env(self)[0];
  V v_msg_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24112, 3), heff_get_n(v_t_24112, 4, 9)});
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24115, v_t_24117, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24116});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args) {
  V v_st_24128 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_msg_24127 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24124, 3), heff_get_n(v_t_24124, 4, 9)});
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, v_t_24129, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args) {
  V v_st_24137 = args[0];
  V v_t_24133 = heff_env(self)[0];
  V v_msg_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24133, 3), heff_get_n(v_t_24133, 4, 9)});
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, v_t_24138, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args) {
  V v_st_24146 = args[0];
  V v_t_24142 = heff_env(self)[0];
  V v_msg_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24142, 3), heff_get_n(v_t_24142, 4, 9)});
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24145, v_t_24147, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24148}), v_st_24146});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args) {
  V v_st_24155 = args[0];
  V v_t_24151 = heff_env(self)[0];
  V v_msg_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24151, 3), heff_get_n(v_t_24151, 4, 9)});
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24154, v_t_24156, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24155});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args) {
  V v_st_24174 = args[0];
  V v_t_24170 = heff_env(self)[0];
  V v_msg_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24170, 3), heff_get_n(v_t_24170, 4, 9)});
  V v_t_24176 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24173, v_t_24175, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24176}), v_st_24174});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args) {
  V v_st_24183 = args[0];
  V v_t_24179 = heff_env(self)[0];
  V v_msg_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24179, 3), heff_get_n(v_t_24179, 4, 9)});
  V v_t_24185 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, v_t_24184, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24185}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args) {
  V v_st_24202 = args[0];
  V v_t_24198 = heff_env(self)[0];
  V v_msg_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24203 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24198, 3), heff_get_n(v_t_24198, 4, 9)});
  V v_t_24204 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, v_t_24203, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24204}), v_st_24202});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args) {
  V v_st_24210 = args[0];
  V v_t_24206 = heff_env(self)[0];
  V v_msg_24209 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24206, 3), heff_get_n(v_t_24206, 4, 9)});
  V v_t_24212 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24209, v_t_24211, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24212}), v_st_24210});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args) {
  V v_st_24220 = args[0];
  V v_t_24216 = heff_env(self)[0];
  V v_msg_24219 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24221 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24216, 3), heff_get_n(v_t_24216, 4, 9)});
  V v_t_24222 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24219, v_t_24221, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24222}), v_st_24220});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args) {
  V v_st_24232 = args[0];
  V v_t_24228 = heff_env(self)[0];
  V v_msg_24231 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24228, 3), heff_get_n(v_t_24228, 4, 9)});
  V v_t_24234 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24231, v_t_24233, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24234}), v_st_24232});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args) {
  V v_st_24243 = args[0];
  V v_t_24239 = heff_env(self)[0];
  V v_msg_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
  V v_t_24245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24242, v_t_24244, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24245}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args) {
  V v_st_24254 = args[0];
  V v_t_24250 = heff_env(self)[0];
  V v_msg_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24255 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24250, 3), heff_get_n(v_t_24250, 4, 9)});
  V v_t_24256 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24253, v_t_24255, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24256}), v_st_24254});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args) {
  V v_st_24264 = args[0];
  V v_t_24260 = heff_env(self)[0];
  V v_msg_24263 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24265 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24260, 3), heff_get_n(v_t_24260, 4, 9)});
  V v_t_24266 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24263, v_t_24265, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24266}), v_st_24264});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args) {
  V v_st_24277 = args[0];
  V v_t_24273 = heff_env(self)[0];
  V v_msg_24276 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24278 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24273, 3), heff_get_n(v_t_24273, 4, 9)});
  V v_t_24279 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24276, v_t_24278, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24279}), v_st_24277});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args) {
  V v_st_24286 = args[0];
  V v_t_24282 = heff_env(self)[0];
  V v_msg_24285 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24287 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24282, 3), heff_get_n(v_t_24282, 4, 9)});
  V v_t_24288 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24285, v_t_24287, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24288}), v_st_24286});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args) {
  V v_st_24296 = args[0];
  V v_t_24292 = heff_env(self)[0];
  V v_msg_24295 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24297 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24292, 3), heff_get_n(v_t_24292, 4, 9)});
  V v_t_24298 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24295, v_t_24297, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24298}), v_st_24296});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args) {
  V v_st_24309 = args[0];
  V v_t_24305 = heff_env(self)[0];
  V v_msg_24308 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24310 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24305, 3), heff_get_n(v_t_24305, 4, 9)});
  V v_t_24311 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24308, v_t_24310, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24311}), v_st_24309});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args) {
  V v_st_24322 = args[0];
  V v_t_24318 = heff_env(self)[0];
  V v_msg_24321 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24323 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24318, 3), heff_get_n(v_t_24318, 4, 9)});
  V v_t_24324 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24321, v_t_24323, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24324}), v_st_24322});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args) {
  V v_st_24332 = args[0];
  V v_t_24328 = heff_env(self)[0];
  V v_msg_24331 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24333 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24328, 3), heff_get_n(v_t_24328, 4, 9)});
  V v_t_24334 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24331, v_t_24333, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24334}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args) {
  V v_st_24343 = args[0];
  V v_t_24339 = heff_env(self)[0];
  V v_msg_24342 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24344 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24339, 3), heff_get_n(v_t_24339, 4, 9)});
  V v_t_24345 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24342, v_t_24344, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24345}), v_st_24343});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args) {
  V v_st_24356 = args[0];
  V v_t_24352 = heff_env(self)[0];
  V v_msg_24355 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24357 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24352, 3), heff_get_n(v_t_24352, 4, 9)});
  V v_t_24358 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24355, v_t_24357, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24358}), v_st_24356});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args) {
  V v_st_24364 = args[0];
  V v_t_24360 = heff_env(self)[0];
  V v_msg_24363 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24365 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24360, 3), heff_get_n(v_t_24360, 4, 9)});
  V v_t_24366 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24363, v_t_24365, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24366}), v_st_24364});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args) {
  V v_st_24373 = args[0];
  V v_t_24369 = heff_env(self)[0];
  V v_msg_24372 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24374 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24369, 3), heff_get_n(v_t_24369, 4, 9)});
  V v_t_24375 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24372, v_t_24374, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24375}), v_st_24373});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args) {
  V v_st_24384 = args[0];
  V v_t_24380 = heff_env(self)[0];
  V v_msg_24383 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24385 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24380, 3), heff_get_n(v_t_24380, 4, 9)});
  V v_t_24386 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24383, v_t_24385, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24386}), v_st_24384});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args) {
  V v_st_24395 = args[0];
  V v_t_24391 = heff_env(self)[0];
  V v_msg_24394 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24396 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24391, 3), heff_get_n(v_t_24391, 4, 9)});
  V v_t_24397 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24394, v_t_24396, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24397}), v_st_24395});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args) {
  V v_st_24406 = args[0];
  V v_t_24402 = heff_env(self)[0];
  V v_msg_24405 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24407 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24402, 3), heff_get_n(v_t_24402, 4, 9)});
  V v_t_24408 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24405, v_t_24407, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24408}), v_st_24406});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args) {
  V v_st_24417 = args[0];
  V v_t_24413 = heff_env(self)[0];
  V v_msg_24416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24413, 3), heff_get_n(v_t_24413, 4, 9)});
  V v_t_24419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24416, v_t_24418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24419}), v_st_24417});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args) {
  V v_m_24440 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24440));
}
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args) {
  V v_st_24425 = args[0];
  V v_m_24424 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_body_24423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24426 = heff_tr(heff_call(v_m_24424, 1, (V[]){v_st_24425}));
  switch (heff_tag_of(v_x1_24426)) {
  case TAG_MkPair: {
    V v_x11_24427 = heff_field(v_x1_24426, 0);
    V v_st_24428 = heff_field(v_x1_24426, 1);
    V v_ru_24x1_24426_24MkPair = heff_take_reuse_n(v_x1_24426, 3ULL, 2);
    switch (heff_tag_of(v_x11_24427)) {
    case TAG_Left: {
      V v_e_24429 = heff_field(v_x11_24427, 0);
      heff_take_n(v_x11_24427, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_body_24423);
      return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24429}), v_st_24428});
    }
    case TAG_Right: {
      V v_x_24430 = heff_field(v_x11_24427, 0);
      heff_take_n(v_x11_24427, 1ULL, 1);
      V v_t_24431 = heff_dup(heff_rfield(v_x_24430, 0));
      V v_t_24439;
      switch (heff_tag_of(v_t_24431)) {
      case TAG_LamName: {
        V v_x_24432 = heff_field(v_t_24431, 0);
        V v_ru_24t_24431_24LamName = heff_take_reuse_n(v_t_24431, 1ULL, 2);
        v_t_24439 = heff_tag_at_n(v_ru_24t_24431_24LamName, TAG_Cons, 2, (V[]){v_x_24432, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamImplicit: {
        V v_x_24434 = heff_field(v_t_24431, 0);
        V v_ru_24t_24431_24LamImplicit = heff_take_reuse_n(v_t_24431, 1ULL, 2);
        v_t_24439 = heff_tag_at_n(v_ru_24t_24431_24LamImplicit, TAG_Cons, 2, (V[]){v_x_24434, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_24436 = heff_field(v_t_24431, 0);
        heff_take_n(v_t_24431, 1ULL, 3);
        v_t_24439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24436, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_24431);
      }
      V v_t_24441 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam41, 1, 1, (V[]){v_r_240}), v_body_24423}));
      HeffT2 v_t_24442 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24439, v_t_24441, v_st_24428));
      {
        V v_field_24443 = v_t_24442.f[0];
        V v_field_24444 = v_t_24442.f[1];
        V v_x11_24445 = v_field_24443;
        V v_st_24446 = v_field_24444;
        switch (heff_tag_of(v_x11_24445)) {
        case TAG_Left: {
          V v_e_24447 = heff_field(v_x11_24445, 0);
          heff_take_n(v_x11_24445, 1ULL, 1);
          heff_drop_rec(v_x_24430, 2);
          return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24447}), v_st_24446});
        }
        case TAG_Right: {
          V v_x_24448 = heff_field(v_x11_24445, 0);
          heff_take_n(v_x11_24445, 1ULL, 1);
          V v_t_24449 = heff_tag_n(TAG_MkCatchArm, 2, (V[]){heff_get_n(v_x_24430, 0, 2), v_x_24448});
          return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24449}), v_st_24446});
        }
        default: return heff_nomatch(v_x11_24445);
        }
      }
    }
    default: return heff_nomatch(v_x11_24427);
    }
  }
  default: return heff_nomatch(v_x1_24426);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args) {
  V v_st_24460 = args[0];
  V v_t_24456 = heff_env(self)[0];
  V v_msg_24459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24461 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24456, 3), heff_get_n(v_t_24456, 4, 9)});
  V v_t_24462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24459, v_t_24461, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24462}), v_st_24460});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_240, v_sp_241, v_e_242, v_v_243, v_s_244, v_st_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3, 17, " does not fit in ");
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5, 1, 0};
Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V v_inPat_240, V v_sp_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_StrValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo);
  }
  case TAG_IntValue: {
    V v_v_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_2412 = heff_bool(((heff_dup(v_inPat_240) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_v_246, 1) && ({ V v_t_248 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_248, 0); heff_drop(v_t_248); c_; })) : ({ V v_t_249 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_243) - ((int64_t)1ULL))))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_249)), heff_dup(v_v_246)) && ({ V v_t_2411 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_2411, 0); heff_drop(v_t_2411); c_; })); heff_drop(v_t_249); c_; })));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_sp_241);
      heff_drop(v_n_243);
      heff_drop(v_v_246);
      heff_drop(v_t_2412);
      return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo);
    } else {
      heff_drop(v_t_2412);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2, 1, 4, (V[]){heff_dup(v_inPat_240), v_n_243, v_v_246, v_sp_241});
    }
  }
  case TAG_FloatValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo);
  }
  case TAG_RuneValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo);
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_t_2414 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_st_2413});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args) {
  V v_st_2415 = args[0];
  V v_inPat_240 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  V v_v_246 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  if ((heff_dup(v_inPat_240) == NTAG(TAG_True))) {
    heff_drop(v_inPat_240);
    v_t_2416 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0);
  } else {
    heff_drop(v_inPat_240);
    v_t_2416 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1);
  }
  V v_t_2417 = heff_strAppend(heff_intShow(v_n_243), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2), v_t_2416));
  V v_t_2418 = heff_strAppend(heff_intShow(v_v_246), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3), v_t_2417));
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2418, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2415});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args) {
  V v_st_2420 = args[0];
  V v_t_2421 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_st_2420});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args) {
  V v_st_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2422});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args) {
  V v_st_2424 = args[0];
  V v_t_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_st_2424});
}
Clo g_heff_2esyntax_2esurface_2etakesRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakesRest_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakesRest(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_PatVar: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatTag: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatOp: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatInt: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatFloat: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRune: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRecord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatWord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatAs: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      default: return heff_nomatch(v_x111_246);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etakesRest(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatSegmentsL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_rest_245)) {
    case TAG_Nil: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_245);
    }
    V v_m_249 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_t_248; V a_2 = v_p_244; V r_ = heff_tr(g_heff_2esyntax_2esurface_2epatSegmentL(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentsL_lam1, 1, 3, (V[]){v_m_249, v_r_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatSegmentsL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_st_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_rest_245);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_m_2416 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_rest_245));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2413}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_x_2421 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2421})});
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str0, 4, "#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str1, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str2, 4, "#arg");
Clo g_heff_2esyntax_2esurface_2eknotField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eknotField_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eknotField(V v_k_240, V v_d_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str0));
  V v_t_243 = heff_tag_n(TAG_LamName, 2, (V[]){v_t_242, heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str1));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_244}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_240}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str2));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_243, v_t_2410}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_2412 = heff_tag_n(TAG_SetField, 3, (V[]){heff_take_field(v_d_241, 0), heff_dup(heff_rfield(v_d_241, 1)), v_t_2411});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_get_n(v_d_241, 1, 5)});
}
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eknotField(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efixityOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixityOut(V v_imported_240, V v_decls_241, V v_groups_242, V v_edges_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 0)), heff_dup(v_groups_242)));
  V v_t_245 = (g_heff_2esyntax_2efixity_2enubByG(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 1)), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByE(v_t_246));
  V v_t_248 = heff_rec_n(2, shape_groups__above, (V[]){v_t_245, v_t_247});
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_imported_240, 0), heff_dup(v_groups_242)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByG(v_t_249));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_imported_240, 1, 2), heff_dup(v_edges_243)));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2411));
  V v_t_2413 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2410, v_t_2412});
  V v_t_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_t_248, v_t_2413, v_decls_241));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_242, v_edges_243}), v_t_2414});
}
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixityOut(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), heff_dup(v_ds_241), heff_dup(v_st_243)));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x11_247 = v_field_245;
    V v_st_248 = v_field_246;
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ds_241);
      heff_drop(v_rhs_242);
      heff_drop_rec(v_st_243, 9);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = ({ V rv_3 = heff_get_n(v_st_243, 3, 9); V rr_ = heff_rec_reuse_nf(v_st_248, 503ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_t_2413 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2417 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0, 2, 1, (V[]){heff_dup(v_t_2411)}); V a_1 = v_t_2413; V a_2 = v_items_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2412); r_; });
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2417, 3, 4)));
      V v_items_2419 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_t_2420 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2421 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2419));
      V v_t_2422 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2419));
      V v_t_2423 = ({ V a_0 = v_t_2420; V a_1 = v_t_2421; V a_2 = v_t_2422; V a_3 = v_items_2419; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); heff_drop(v_t_2421); heff_drop(v_t_2422); r_; });
      V v_t_2424 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2423));
      V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2418, v_t_2424));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nil: {
        V v_items_2426 = ({ V a_0 = v_x_2410; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2410); r_; });
        V v_t_2427 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_items_2426; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
        V v_x1_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
        V v_b_2433;
        switch (heff_tag_of(v_x1_2429)) {
        case TAG_Nil: {
          v_b_2433 = heff_get_n(v_kw_240, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2430 = heff_field(v_x1_2429, 0);
          heff_take_n(v_x1_2429, 1ULL, 2);
          heff_drop_rec(v_kw_240, 9);
          V v_t_2432 = (g_heff_2esyntax_2ecst_2elastD(v_x_2430));
          v_b_2433 = heff_get_n(v_t_2432, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2429);
        }
        V v_t_2436;
        switch (heff_tag_of(v_rhs_242)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_rhs_242, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_rhs_242);
        }
        V v_t_2437 = ({ V rv_1 = v_b_2433; V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_242, v_t_2428}), v_t_2437});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2438}), v_t_2411});
      }
      case TAG_Cons: {
        V v_d_2439 = heff_field(v_t_2425, 0);
        V v_ru_24t_2425_24Cons = heff_take_reuse_n(v_t_2425, 1ULL, 2);
        heff_drop_rec(v_kw_240, 9);
        heff_drop(v_ds_241);
        heff_drop(v_rhs_242);
        heff_drop(v_x_2410);
        heff_drop_cell(v_ru_24x11_247_24Right, 1);
        return heff_tag_at_n(v_ru_24t_2425_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2439}), v_t_2411});
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args) {
  V v_d_2414 = args[0];
  V v_it_2415 = args[1];
  V v_t_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2414, 2)), v_it_2415));
  return ({ V a_0 = heff_get_n(v_t_2411, 7, 9); V a_1 = v_d_2414; V a_2 = v_t_2416; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0), v_t_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1)})});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_249;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a[0], a[1], a[2]);
}