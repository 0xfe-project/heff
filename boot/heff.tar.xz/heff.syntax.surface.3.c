// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2efieldOrName(V, V);
V g_heff_2esyntax_2esurface_2efieldOrName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldOrName_clo;
V g_heff_2esyntax_2esurface_2efixityOut(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eknotField(V, V);
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotField_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatSegmentL(V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentL_clo;
V g_heff_2esyntax_2esurface_2epatSegmentsL(V, V);
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldOne_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexpOf_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eexpOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexpOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eexpOf(V v_ex_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
    V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_242); r_; });
    return heff_intSub(MK_INT(0LL), v_t_243);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_ex_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eexpOf_str1))) {
      V v_t_245 = heff_strSlice(heff_dup(v_ex_240), MK_INT(1LL), heff_strLength_lent(v_ex_240, 0));
      return ({ V a_0 = v_t_245; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_245); r_; });
    } else {
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintOfText(v_ex_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eexpOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_rest_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 5);
        V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
        V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
        heff_drop(v_u_2429);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2428;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2430 = heff_field(v_x111_2418, 0);
        heff_take_n(v_x111_2418, 1ULL, 4);
        V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2430, heff_hole()});
        V v_u_2435 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2434));
        heff_drop(v_u_2435);
        V t_0 = v_rest_2419;
        V t_1 = v_cell_2434;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2419;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EFor: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ENest: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_ETry: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_EWith: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisNameE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_x11_241, 0);
      V v_t_246 = heff_intSub(heff_dup(heff_rfield(v_x12_242, 1)), heff_dup(heff_rfield(v_x12_242, 0)));
      return heff_intEq(v_t_246, heff_strLength_lent(v_x_245, 0));
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisNameE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EString, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAnn: {
      V v_g_2422 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 1ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_2422)));
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_2422));
      V v_t_2426 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_Cons, 2, (V[]){heff_get_n(v_t_2424, 0, 2), heff_get_n(v_t_2425, 1, 2)});
      V v_t_2427 = (g_list_2emap_24s878634257x1677201747(v_t_2426));
      V v_sc_2428 = (g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637(heff_take_field(v_p_241, 1), v_t_2427));
      V v_f_2429 = ({ V rv_1 = v_sc_2428; V rr_ = heff_rec_reuse_nf(v_p_241, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_f_2429}});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_242, 0ULL, 2);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EReturn: {
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ENest: {
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ELazy: {
      V v_ru_24e1_242_24ELazy = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ELazy, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETuple: {
      V v_ru_24e1_242_24ETuple = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETuple, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_ETry: {
      V v_ru_24e1_242_24ETry = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24e1_242_24ETry, TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      return ((HeffT2){{heff_tag_n(TAG_Right, 1, (V[]){v_e_240}), v_p_241}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eplainBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplainBinder_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eplainBinder(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_241)) {
    case TAG_EVar: {
      V v_ru_24d1_241_24EVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EImplicitVar: {
      V v_ru_24d1_241_24EImplicitVar = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      V v_ru_24d1_241_24ETag = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      V v_ru_24d1_241_24EInt = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      V v_ru_24d1_241_24EFloat = heff_take_reuse_na(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EString: {
      V v_ru_24d1_241_24EString = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBinary: {
      V v_ru_24d1_241_24EBinary = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ERune: {
      V v_ru_24d1_241_24ERune = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWord: {
      V v_ru_24d1_241_24EWord = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EApp: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EProject: {
      V v_ru_24d1_241_24EProject = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENamed: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EPi: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAnn: {
      V v_d11_2421 = heff_field(v_d1_241, 0);
      V v_t_2422 = heff_field(v_d1_241, 1);
      heff_take_n(v_d1_241, 3ULL, 2);
      switch (heff_tag_of(v_d11_2421)) {
      case TAG_At: {
        V v_d111_2423 = heff_field(v_d11_2421, 0);
        V v_xsp_2424 = heff_field(v_d11_2421, 1);
        heff_take_n(v_d11_2421, 3ULL, 2);
        switch (heff_tag_of(v_d111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_d111_2423, 0);
          heff_take_n(v_d111_2423, 1ULL, 1);
          heff_drop_tag(v_d_240, 2);
          return heff_tag_n(TAG_PiNamed, 3, (V[]){v_x_2425, v_xsp_2424, v_t_2422});
        }
        case TAG_EImplicitVar: {
          V v_ru_24d111_2423_24EImplicitVar = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETag: {
          V v_ru_24d111_2423_24ETag = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETag, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInt: {
          V v_ru_24d111_2423_24EInt = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInt, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFloat: {
          V v_ru_24d111_2423_24EFloat = heff_take_reuse_na(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EFloat, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EString: {
          V v_ru_24d111_2423_24EString = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EString, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBinary: {
          V v_ru_24d111_2423_24EBinary = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EBinary, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ERune: {
          V v_ru_24d111_2423_24ERune = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ERune, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWord: {
          V v_ru_24d111_2423_24EWord = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EWord, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EApp: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EProject: {
          V v_ru_24d111_2423_24EProject = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EProject, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENamed: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EPi: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELam: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAnn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESpec: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESig: {
          V v_ru_24d111_2423_24ESig = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ESum: {
          V v_ru_24d111_2423_24ESum = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EStruct: {
          V v_ru_24d111_2423_24EStruct = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EUpdate: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EMatch: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELetIn: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EDo: {
          V v_ru_24d111_2423_24EDo = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELocal: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EInvalid: {
          V v_ru_24d111_2423_24EInvalid = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EAssign: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWhile: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EFor: {
          heff_take_n(v_d111_2423, 0ULL, 3);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EIfThen: {
          heff_take_n(v_d111_2423, 0ULL, 2);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EBreak: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EContinue: {
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EReturn: {
          V v_ru_24d111_2423_24EReturn = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ENest: {
          V v_ru_24d111_2423_24ENest = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ELazy: {
          V v_ru_24d111_2423_24ELazy = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETuple: {
          V v_ru_24d111_2423_24ETuple = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_ETry: {
          V v_ru_24d111_2423_24ETry = heff_take_reuse_n(v_d111_2423, 0ULL, 1);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_at_n(v_ru_24d111_2423_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
        }
        case TAG_EWith: {
          heff_take_n(v_d111_2423, 0ULL, 4);
          heff_drop(v_t_2422);
          heff_drop(v_xsp_2424);
          return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
        }
        default: return heff_nomatch(v_d111_2423);
        }
      }
      default: return heff_nomatch(v_d11_2421);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESig: {
      V v_ru_24d1_241_24ESig = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESig, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ESum: {
      V v_ru_24d1_241_24ESum = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ESum, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EStruct: {
      V v_ru_24d1_241_24EStruct = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EStruct, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EUpdate: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELetIn: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EDo: {
      V v_ru_24d1_241_24EDo = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EDo, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELocal: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EInvalid: {
      V v_ru_24d1_241_24EInvalid = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EInvalid, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EAssign: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWhile: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EFor: {
      heff_take_n(v_d1_241, 0ULL, 3);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EIfThen: {
      heff_take_n(v_d1_241, 0ULL, 2);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EBreak: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EContinue: {
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EReturn: {
      V v_ru_24d1_241_24EReturn = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24EReturn, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ENest: {
      V v_ru_24d1_241_24ENest = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ENest, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ELazy: {
      V v_ru_24d1_241_24ELazy = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ELazy, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETuple: {
      V v_ru_24d1_241_24ETuple = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETuple, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_ETry: {
      V v_ru_24d1_241_24ETry = heff_take_reuse_n(v_d1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24d1_241_24ETry, TAG_PiAnon, 1, (V[]){v_d_240});
    }
    case TAG_EWith: {
      heff_take_n(v_d1_241, 0ULL, 4);
      return heff_tag_n(TAG_PiAnon, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplainBinder(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_241}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str7, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2eatomTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2eatomTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eatomTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eatomTok(V v_t_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str0))) {
    V v_t_242 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str1))) {
      V v_t_245 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_t_240, 1)));
      V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_245}), v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str2))) {
        V v_s_248 = heff_take_field(v_t_240, 1);
        V v_x2_249 = ({ V b_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str3); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2eatomTok_str4), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
        V v_t_2412;
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nil: {
          v_t_2412 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x2_249, 0);
          V v_xs_2411 = heff_field(v_x2_249, 1);
          heff_take_n(v_x2_249, 3ULL, 2);
          v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2eatomTok_str6); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
          break;
        }
        default: heff_nomatch(v_x2_249);
        }
        double v_t_2413 = ({ V a_0 = v_t_2412; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_2412); r_; });
        V v_t_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)}), v_t_2414});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str7))) {
          V v_t_2416 = heff_tag_n(TAG_EString, 1, (V[]){heff_take_field(v_t_240, 1)});
          V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_t_2417});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str8))) {
            V v_t_2419 = heff_strRuneAt(heff_take_field(v_t_240, 1), MK_INT(0LL));
            V v_t_2420 = heff_tag_n(TAG_ERune, 1, (V[]){heff_runeToInt(v_t_2419)});
            V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2421});
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2eatomTok_str9))) {
              V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
              V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424});
            } else {
              V v_t_2425 = (g_heff_2esyntax_2esurface_2ewordKw(heff_rfield(v_t_240, 1)));
              V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWord, 1, (V[]){v_t_2425}), v_t_2426});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eatomTok(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldOrName_str0, 3, "var");
V g_heff_2esyntax_2esurface_2efieldOrName_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldOrName_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldOrName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldOrName_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldOrName(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24Atom = heff_take_reuse_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efieldOrName_str0))) {
      heff_drop(v_r_240);
      heff_drop_cell(v_ru_24e_241_24Atom, 1);
      return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam0, 1, 1, (V[]){v_x_242});
    } else {
      V v_m_246 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, heff_tag_at_n(v_ru_24e_241_24Atom, TAG_Atom, 1, (V[]){v_x_242})));
      return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam1, 1, 1, (V[]){v_m_246});
    }
  }
  case TAG_EParen: {
    V v_m_2417 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam2, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2430 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam3, 1, 1, (V[]){v_m_2430});
  }
  case TAG_Tup: {
    V v_m_2442 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam4, 1, 1, (V[]){v_m_2442});
  }
  case TAG_Seg: {
    V v_m_2453 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam5, 1, 1, (V[]){v_m_2453});
  }
  case TAG_Braces: {
    V v_m_2465 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam6, 1, 1, (V[]){v_m_2465});
  }
  case TAG_Update: {
    V v_m_2479 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam7, 1, 1, (V[]){v_m_2479});
  }
  case TAG_EUSet: {
    V v_m_2490 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam8, 1, 1, (V[]){v_m_2490});
  }
  case TAG_InstB: {
    V v_m_24103 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam9, 1, 1, (V[]){v_m_24103});
  }
  case TAG_EFSet: {
    V v_m_24114 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam10, 1, 1, (V[]){v_m_24114});
  }
  case TAG_EFDefault: {
    V v_m_24125 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam11, 1, 1, (V[]){v_m_24125});
  }
  case TAG_Sum: {
    V v_m_24138 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam12, 1, 1, (V[]){v_m_24138});
  }
  case TAG_ECon: {
    V v_m_24148 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam13, 1, 1, (V[]){v_m_24148});
  }
  case TAG_EField: {
    V v_m_24158 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam14, 1, 1, (V[]){v_m_24158});
  }
  case TAG_ENeg: {
    V v_m_24168 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam15, 1, 1, (V[]){v_m_24168});
  }
  case TAG_ETilde: {
    V v_m_24178 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam16, 1, 1, (V[]){v_m_24178});
  }
  case TAG_App: {
    V v_m_24188 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam17, 1, 1, (V[]){v_m_24188});
  }
  case TAG_Op: {
    V v_m_24199 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam18, 1, 1, (V[]){v_m_24199});
  }
  case TAG_Ops: {
    V v_m_24209 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam19, 1, 1, (V[]){v_m_24209});
  }
  case TAG_OpRhs: {
    V v_m_24219 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam20, 1, 1, (V[]){v_m_24219});
  }
  case TAG_Ann: {
    V v_m_24230 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam21, 1, 1, (V[]){v_m_24230});
  }
  case TAG_BVar: {
    V v_m_24239 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam22, 1, 1, (V[]){v_m_24239});
  }
  case TAG_BImp: {
    V v_m_24250 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam23, 1, 1, (V[]){v_m_24250});
  }
  case TAG_BAnn: {
    V v_m_24263 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam24, 1, 1, (V[]){v_m_24263});
  }
  case TAG_BPat: {
    V v_m_24272 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam25, 1, 1, (V[]){v_m_24272});
  }
  case TAG_Lam: {
    V v_m_24284 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam26, 1, 1, (V[]){v_m_24284});
  }
  case TAG_Case: {
    V v_m_24296 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam27, 1, 1, (V[]){v_m_24296});
  }
  case TAG_EAlt: {
    V v_m_24307 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam28, 1, 1, (V[]){v_m_24307});
  }
  case TAG_If: {
    V v_m_24321 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam29, 1, 1, (V[]){v_m_24321});
  }
  case TAG_Do: {
    V v_m_24331 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam30, 1, 1, (V[]){v_m_24331});
  }
  case TAG_ESBind: {
    V v_m_24342 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam31, 1, 1, (V[]){v_m_24342});
  }
  case TAG_ELet: {
    V v_m_24356 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam32, 1, 1, (V[]){v_m_24356});
  }
  case TAG_ELetElse: {
    V v_m_24371 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam33, 1, 1, (V[]){v_m_24371});
  }
  case TAG_ELetMut: {
    V v_m_24385 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam34, 1, 1, (V[]){v_m_24385});
  }
  case TAG_EAssign: {
    V v_m_24396 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam35, 1, 1, (V[]){v_m_24396});
  }
  case TAG_EWhile: {
    V v_m_24408 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam36, 1, 1, (V[]){v_m_24408});
  }
  case TAG_EFor: {
    V v_m_24422 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam37, 1, 1, (V[]){v_m_24422});
  }
  case TAG_EJump: {
    V v_m_24431 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam38, 1, 1, (V[]){v_m_24431});
  }
  case TAG_EReturn: {
    V v_m_24441 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam39, 1, 1, (V[]){v_m_24441});
  }
  case TAG_ENest: {
    V v_m_24453 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam40, 1, 1, (V[]){v_m_24453});
  }
  case TAG_EArrow: {
    V v_m_24463 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam41, 1, 1, (V[]){v_m_24463});
  }
  case TAG_IfThen: {
    V v_m_24475 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam42, 1, 1, (V[]){v_m_24475});
  }
  case TAG_ETry: {
    V v_m_24487 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam43, 1, 1, (V[]){v_m_24487});
  }
  case TAG_ECatch: {
    V v_m_24499 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam44, 1, 1, (V[]){v_m_24499});
  }
  case TAG_EWith: {
    V v_m_24513 = (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldOrName_lam45, 1, 1, (V[]){v_m_24513});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldOrName(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x_242})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2412})});
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st_2410});
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2424 = heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2423})});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam3(V self, V *args) {
  V v_st_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_st_2431}));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_MkPair: {
    V v_x11_2433 = heff_field(v_x1_2432, 0);
    V v_st_2434 = heff_field(v_x1_2432, 1);
    V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
    switch (heff_tag_of(v_x11_2433)) {
    case TAG_Left: {
      V v_e_2435 = heff_field(v_x11_2433, 0);
      heff_take_n(v_x11_2433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
    }
    case TAG_Right: {
      V v_x_2436 = heff_field(v_x11_2433, 0);
      V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
      V v_t_2437 = heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2436})});
      return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_st_2434});
    }
    default: return heff_nomatch(v_x11_2433);
    }
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam4(V self, V *args) {
  V v_st_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_st_2443}));
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_MkPair: {
    V v_x11_2445 = heff_field(v_x1_2444, 0);
    V v_st_2446 = heff_field(v_x1_2444, 1);
    V v_ru_24x1_2444_24MkPair = heff_take_reuse_n(v_x1_2444, 3ULL, 2);
    switch (heff_tag_of(v_x11_2445)) {
    case TAG_Left: {
      V v_e_2447 = heff_field(v_x11_2445, 0);
      heff_take_n(v_x11_2445, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2444_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2447}), v_st_2446});
    }
    case TAG_Right: {
      V v_x_2448 = heff_field(v_x11_2445, 0);
      V v_ru_24x11_2445_24Right = heff_take_reuse_n(v_x11_2445, 1ULL, 1);
      V v_t_2449 = heff_tag_at_n(v_ru_24x11_2445_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2448})});
      return heff_tag_at_n(v_ru_24x1_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2449, v_st_2446});
    }
    default: return heff_nomatch(v_x11_2445);
    }
  }
  default: return heff_nomatch(v_x1_2444);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam5(V self, V *args) {
  V v_st_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_st_2454}));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_MkPair: {
    V v_x11_2456 = heff_field(v_x1_2455, 0);
    V v_st_2457 = heff_field(v_x1_2455, 1);
    V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
    switch (heff_tag_of(v_x11_2456)) {
    case TAG_Left: {
      V v_e_2458 = heff_field(v_x11_2456, 0);
      heff_take_n(v_x11_2456, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2458}), v_st_2457});
    }
    case TAG_Right: {
      V v_x_2459 = heff_field(v_x11_2456, 0);
      V v_ru_24x11_2456_24Right = heff_take_reuse_n(v_x11_2456, 1ULL, 1);
      V v_t_2460 = heff_tag_at_n(v_ru_24x11_2456_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2459})});
      return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){v_t_2460, v_st_2457});
    }
    default: return heff_nomatch(v_x11_2456);
    }
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam6(V self, V *args) {
  V v_st_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_st_2466}));
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_MkPair: {
    V v_x11_2468 = heff_field(v_x1_2467, 0);
    V v_st_2469 = heff_field(v_x1_2467, 1);
    V v_ru_24x1_2467_24MkPair = heff_take_reuse_n(v_x1_2467, 3ULL, 2);
    switch (heff_tag_of(v_x11_2468)) {
    case TAG_Left: {
      V v_e_2470 = heff_field(v_x11_2468, 0);
      heff_take_n(v_x11_2468, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2470}), v_st_2469});
    }
    case TAG_Right: {
      V v_x_2471 = heff_field(v_x11_2468, 0);
      V v_ru_24x11_2468_24Right = heff_take_reuse_n(v_x11_2468, 1ULL, 1);
      V v_t_2472 = heff_tag_at_n(v_ru_24x11_2468_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2471})});
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){v_t_2472, v_st_2469});
    }
    default: return heff_nomatch(v_x11_2468);
    }
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam7(V self, V *args) {
  V v_st_2480 = args[0];
  V v_m_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2481 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_st_2480}));
  switch (heff_tag_of(v_x1_2481)) {
  case TAG_MkPair: {
    V v_x11_2482 = heff_field(v_x1_2481, 0);
    V v_st_2483 = heff_field(v_x1_2481, 1);
    V v_ru_24x1_2481_24MkPair = heff_take_reuse_n(v_x1_2481, 3ULL, 2);
    switch (heff_tag_of(v_x11_2482)) {
    case TAG_Left: {
      V v_e_2484 = heff_field(v_x11_2482, 0);
      heff_take_n(v_x11_2482, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2484}), v_st_2483});
    }
    case TAG_Right: {
      V v_x_2485 = heff_field(v_x11_2482, 0);
      V v_ru_24x11_2482_24Right = heff_take_reuse_n(v_x11_2482, 1ULL, 1);
      V v_t_2486 = heff_tag_at_n(v_ru_24x11_2482_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2485})});
      return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){v_t_2486, v_st_2483});
    }
    default: return heff_nomatch(v_x11_2482);
    }
  }
  default: return heff_nomatch(v_x1_2481);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam8(V self, V *args) {
  V v_st_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_st_2491}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      V v_ru_24x11_2493_24Right = heff_take_reuse_n(v_x11_2493, 1ULL, 1);
      V v_t_2497 = heff_tag_at_n(v_ru_24x11_2493_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2496})});
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){v_t_2497, v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam9(V self, V *args) {
  V v_st_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_st_24104}));
  switch (heff_tag_of(v_x1_24105)) {
  case TAG_MkPair: {
    V v_x11_24106 = heff_field(v_x1_24105, 0);
    V v_st_24107 = heff_field(v_x1_24105, 1);
    V v_ru_24x1_24105_24MkPair = heff_take_reuse_n(v_x1_24105, 3ULL, 2);
    switch (heff_tag_of(v_x11_24106)) {
    case TAG_Left: {
      V v_e_24108 = heff_field(v_x11_24106, 0);
      heff_take_n(v_x11_24106, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24108}), v_st_24107});
    }
    case TAG_Right: {
      V v_x_24109 = heff_field(v_x11_24106, 0);
      V v_ru_24x11_24106_24Right = heff_take_reuse_n(v_x11_24106, 1ULL, 1);
      V v_t_24110 = heff_tag_at_n(v_ru_24x11_24106_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24109})});
      return heff_tag_at_n(v_ru_24x1_24105_24MkPair, TAG_MkPair, 2, (V[]){v_t_24110, v_st_24107});
    }
    default: return heff_nomatch(v_x11_24106);
    }
  }
  default: return heff_nomatch(v_x1_24105);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam10(V self, V *args) {
  V v_st_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_st_24115}));
  switch (heff_tag_of(v_x1_24116)) {
  case TAG_MkPair: {
    V v_x11_24117 = heff_field(v_x1_24116, 0);
    V v_st_24118 = heff_field(v_x1_24116, 1);
    V v_ru_24x1_24116_24MkPair = heff_take_reuse_n(v_x1_24116, 3ULL, 2);
    switch (heff_tag_of(v_x11_24117)) {
    case TAG_Left: {
      V v_e_24119 = heff_field(v_x11_24117, 0);
      heff_take_n(v_x11_24117, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24119}), v_st_24118});
    }
    case TAG_Right: {
      V v_x_24120 = heff_field(v_x11_24117, 0);
      V v_ru_24x11_24117_24Right = heff_take_reuse_n(v_x11_24117, 1ULL, 1);
      V v_t_24121 = heff_tag_at_n(v_ru_24x11_24117_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24120})});
      return heff_tag_at_n(v_ru_24x1_24116_24MkPair, TAG_MkPair, 2, (V[]){v_t_24121, v_st_24118});
    }
    default: return heff_nomatch(v_x11_24117);
    }
  }
  default: return heff_nomatch(v_x1_24116);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam11(V self, V *args) {
  V v_st_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_st_24126}));
  switch (heff_tag_of(v_x1_24127)) {
  case TAG_MkPair: {
    V v_x11_24128 = heff_field(v_x1_24127, 0);
    V v_st_24129 = heff_field(v_x1_24127, 1);
    V v_ru_24x1_24127_24MkPair = heff_take_reuse_n(v_x1_24127, 3ULL, 2);
    switch (heff_tag_of(v_x11_24128)) {
    case TAG_Left: {
      V v_e_24130 = heff_field(v_x11_24128, 0);
      heff_take_n(v_x11_24128, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24130}), v_st_24129});
    }
    case TAG_Right: {
      V v_x_24131 = heff_field(v_x11_24128, 0);
      V v_ru_24x11_24128_24Right = heff_take_reuse_n(v_x11_24128, 1ULL, 1);
      V v_t_24132 = heff_tag_at_n(v_ru_24x11_24128_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24131})});
      return heff_tag_at_n(v_ru_24x1_24127_24MkPair, TAG_MkPair, 2, (V[]){v_t_24132, v_st_24129});
    }
    default: return heff_nomatch(v_x11_24128);
    }
  }
  default: return heff_nomatch(v_x1_24127);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam12(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24145 = heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144})});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){v_t_24145, v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam13(V self, V *args) {
  V v_st_24149 = args[0];
  V v_m_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24150 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_st_24149}));
  switch (heff_tag_of(v_x1_24150)) {
  case TAG_MkPair: {
    V v_x11_24151 = heff_field(v_x1_24150, 0);
    V v_st_24152 = heff_field(v_x1_24150, 1);
    V v_ru_24x1_24150_24MkPair = heff_take_reuse_n(v_x1_24150, 3ULL, 2);
    switch (heff_tag_of(v_x11_24151)) {
    case TAG_Left: {
      V v_e_24153 = heff_field(v_x11_24151, 0);
      heff_take_n(v_x11_24151, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24150_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24153}), v_st_24152});
    }
    case TAG_Right: {
      V v_x_24154 = heff_field(v_x11_24151, 0);
      V v_ru_24x11_24151_24Right = heff_take_reuse_n(v_x11_24151, 1ULL, 1);
      V v_t_24155 = heff_tag_at_n(v_ru_24x11_24151_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24154})});
      return heff_tag_at_n(v_ru_24x1_24150_24MkPair, TAG_MkPair, 2, (V[]){v_t_24155, v_st_24152});
    }
    default: return heff_nomatch(v_x11_24151);
    }
  }
  default: return heff_nomatch(v_x1_24150);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam14(V self, V *args) {
  V v_st_24159 = args[0];
  V v_m_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24160 = heff_tr(heff_call(v_m_24158, 1, (V[]){v_st_24159}));
  switch (heff_tag_of(v_x1_24160)) {
  case TAG_MkPair: {
    V v_x11_24161 = heff_field(v_x1_24160, 0);
    V v_st_24162 = heff_field(v_x1_24160, 1);
    V v_ru_24x1_24160_24MkPair = heff_take_reuse_n(v_x1_24160, 3ULL, 2);
    switch (heff_tag_of(v_x11_24161)) {
    case TAG_Left: {
      V v_e_24163 = heff_field(v_x11_24161, 0);
      heff_take_n(v_x11_24161, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24163}), v_st_24162});
    }
    case TAG_Right: {
      V v_x_24164 = heff_field(v_x11_24161, 0);
      V v_ru_24x11_24161_24Right = heff_take_reuse_n(v_x11_24161, 1ULL, 1);
      V v_t_24165 = heff_tag_at_n(v_ru_24x11_24161_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24164})});
      return heff_tag_at_n(v_ru_24x1_24160_24MkPair, TAG_MkPair, 2, (V[]){v_t_24165, v_st_24162});
    }
    default: return heff_nomatch(v_x11_24161);
    }
  }
  default: return heff_nomatch(v_x1_24160);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam15(V self, V *args) {
  V v_st_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_st_24169}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
      V v_t_24175 = heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24174})});
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){v_t_24175, v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam16(V self, V *args) {
  V v_st_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_st_24179}));
  switch (heff_tag_of(v_x1_24180)) {
  case TAG_MkPair: {
    V v_x11_24181 = heff_field(v_x1_24180, 0);
    V v_st_24182 = heff_field(v_x1_24180, 1);
    V v_ru_24x1_24180_24MkPair = heff_take_reuse_n(v_x1_24180, 3ULL, 2);
    switch (heff_tag_of(v_x11_24181)) {
    case TAG_Left: {
      V v_e_24183 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
    }
    case TAG_Right: {
      V v_x_24184 = heff_field(v_x11_24181, 0);
      V v_ru_24x11_24181_24Right = heff_take_reuse_n(v_x11_24181, 1ULL, 1);
      V v_t_24185 = heff_tag_at_n(v_ru_24x11_24181_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24184})});
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){v_t_24185, v_st_24182});
    }
    default: return heff_nomatch(v_x11_24181);
    }
  }
  default: return heff_nomatch(v_x1_24180);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam17(V self, V *args) {
  V v_st_24189 = args[0];
  V v_m_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24190 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_st_24189}));
  switch (heff_tag_of(v_x1_24190)) {
  case TAG_MkPair: {
    V v_x11_24191 = heff_field(v_x1_24190, 0);
    V v_st_24192 = heff_field(v_x1_24190, 1);
    V v_ru_24x1_24190_24MkPair = heff_take_reuse_n(v_x1_24190, 3ULL, 2);
    switch (heff_tag_of(v_x11_24191)) {
    case TAG_Left: {
      V v_e_24193 = heff_field(v_x11_24191, 0);
      heff_take_n(v_x11_24191, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24190_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24193}), v_st_24192});
    }
    case TAG_Right: {
      V v_x_24194 = heff_field(v_x11_24191, 0);
      V v_ru_24x11_24191_24Right = heff_take_reuse_n(v_x11_24191, 1ULL, 1);
      V v_t_24195 = heff_tag_at_n(v_ru_24x11_24191_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24194})});
      return heff_tag_at_n(v_ru_24x1_24190_24MkPair, TAG_MkPair, 2, (V[]){v_t_24195, v_st_24192});
    }
    default: return heff_nomatch(v_x11_24191);
    }
  }
  default: return heff_nomatch(v_x1_24190);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam18(V self, V *args) {
  V v_st_24200 = args[0];
  V v_m_24199 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24201 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_st_24200}));
  switch (heff_tag_of(v_x1_24201)) {
  case TAG_MkPair: {
    V v_x11_24202 = heff_field(v_x1_24201, 0);
    V v_st_24203 = heff_field(v_x1_24201, 1);
    V v_ru_24x1_24201_24MkPair = heff_take_reuse_n(v_x1_24201, 3ULL, 2);
    switch (heff_tag_of(v_x11_24202)) {
    case TAG_Left: {
      V v_e_24204 = heff_field(v_x11_24202, 0);
      heff_take_n(v_x11_24202, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24204}), v_st_24203});
    }
    case TAG_Right: {
      V v_x_24205 = heff_field(v_x11_24202, 0);
      V v_ru_24x11_24202_24Right = heff_take_reuse_n(v_x11_24202, 1ULL, 1);
      V v_t_24206 = heff_tag_at_n(v_ru_24x11_24202_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24205})});
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){v_t_24206, v_st_24203});
    }
    default: return heff_nomatch(v_x11_24202);
    }
  }
  default: return heff_nomatch(v_x1_24201);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam19(V self, V *args) {
  V v_st_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_st_24210}));
  switch (heff_tag_of(v_x1_24211)) {
  case TAG_MkPair: {
    V v_x11_24212 = heff_field(v_x1_24211, 0);
    V v_st_24213 = heff_field(v_x1_24211, 1);
    V v_ru_24x1_24211_24MkPair = heff_take_reuse_n(v_x1_24211, 3ULL, 2);
    switch (heff_tag_of(v_x11_24212)) {
    case TAG_Left: {
      V v_e_24214 = heff_field(v_x11_24212, 0);
      heff_take_n(v_x11_24212, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24214}), v_st_24213});
    }
    case TAG_Right: {
      V v_x_24215 = heff_field(v_x11_24212, 0);
      V v_ru_24x11_24212_24Right = heff_take_reuse_n(v_x11_24212, 1ULL, 1);
      V v_t_24216 = heff_tag_at_n(v_ru_24x11_24212_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24215})});
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){v_t_24216, v_st_24213});
    }
    default: return heff_nomatch(v_x11_24212);
    }
  }
  default: return heff_nomatch(v_x1_24211);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam20(V self, V *args) {
  V v_st_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24221 = heff_tr(heff_call(v_m_24219, 1, (V[]){v_st_24220}));
  switch (heff_tag_of(v_x1_24221)) {
  case TAG_MkPair: {
    V v_x11_24222 = heff_field(v_x1_24221, 0);
    V v_st_24223 = heff_field(v_x1_24221, 1);
    V v_ru_24x1_24221_24MkPair = heff_take_reuse_n(v_x1_24221, 3ULL, 2);
    switch (heff_tag_of(v_x11_24222)) {
    case TAG_Left: {
      V v_e_24224 = heff_field(v_x11_24222, 0);
      heff_take_n(v_x11_24222, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24221_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24224}), v_st_24223});
    }
    case TAG_Right: {
      V v_x_24225 = heff_field(v_x11_24222, 0);
      V v_ru_24x11_24222_24Right = heff_take_reuse_n(v_x11_24222, 1ULL, 1);
      V v_t_24226 = heff_tag_at_n(v_ru_24x11_24222_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24225})});
      return heff_tag_at_n(v_ru_24x1_24221_24MkPair, TAG_MkPair, 2, (V[]){v_t_24226, v_st_24223});
    }
    default: return heff_nomatch(v_x11_24222);
    }
  }
  default: return heff_nomatch(v_x1_24221);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam21(V self, V *args) {
  V v_st_24231 = args[0];
  V v_m_24230 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24232 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_st_24231}));
  switch (heff_tag_of(v_x1_24232)) {
  case TAG_MkPair: {
    V v_x11_24233 = heff_field(v_x1_24232, 0);
    V v_st_24234 = heff_field(v_x1_24232, 1);
    V v_ru_24x1_24232_24MkPair = heff_take_reuse_n(v_x1_24232, 3ULL, 2);
    switch (heff_tag_of(v_x11_24233)) {
    case TAG_Left: {
      V v_e_24235 = heff_field(v_x11_24233, 0);
      heff_take_n(v_x11_24233, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24235}), v_st_24234});
    }
    case TAG_Right: {
      V v_x_24236 = heff_field(v_x11_24233, 0);
      V v_ru_24x11_24233_24Right = heff_take_reuse_n(v_x11_24233, 1ULL, 1);
      V v_t_24237 = heff_tag_at_n(v_ru_24x11_24233_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24236})});
      return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){v_t_24237, v_st_24234});
    }
    default: return heff_nomatch(v_x11_24233);
    }
  }
  default: return heff_nomatch(v_x1_24232);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam22(V self, V *args) {
  V v_st_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_st_24240}));
  switch (heff_tag_of(v_x1_24241)) {
  case TAG_MkPair: {
    V v_x11_24242 = heff_field(v_x1_24241, 0);
    V v_st_24243 = heff_field(v_x1_24241, 1);
    V v_ru_24x1_24241_24MkPair = heff_take_reuse_n(v_x1_24241, 3ULL, 2);
    switch (heff_tag_of(v_x11_24242)) {
    case TAG_Left: {
      V v_e_24244 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24244}), v_st_24243});
    }
    case TAG_Right: {
      V v_x_24245 = heff_field(v_x11_24242, 0);
      V v_ru_24x11_24242_24Right = heff_take_reuse_n(v_x11_24242, 1ULL, 1);
      V v_t_24246 = heff_tag_at_n(v_ru_24x11_24242_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24245})});
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){v_t_24246, v_st_24243});
    }
    default: return heff_nomatch(v_x11_24242);
    }
  }
  default: return heff_nomatch(v_x1_24241);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam23(V self, V *args) {
  V v_st_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_st_24251}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_MkPair: {
    V v_x11_24253 = heff_field(v_x1_24252, 0);
    V v_st_24254 = heff_field(v_x1_24252, 1);
    V v_ru_24x1_24252_24MkPair = heff_take_reuse_n(v_x1_24252, 3ULL, 2);
    switch (heff_tag_of(v_x11_24253)) {
    case TAG_Left: {
      V v_e_24255 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24255}), v_st_24254});
    }
    case TAG_Right: {
      V v_x_24256 = heff_field(v_x11_24253, 0);
      V v_ru_24x11_24253_24Right = heff_take_reuse_n(v_x11_24253, 1ULL, 1);
      V v_t_24257 = heff_tag_at_n(v_ru_24x11_24253_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24256})});
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){v_t_24257, v_st_24254});
    }
    default: return heff_nomatch(v_x11_24253);
    }
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam24(V self, V *args) {
  V v_st_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_st_24264}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_MkPair: {
    V v_x11_24266 = heff_field(v_x1_24265, 0);
    V v_st_24267 = heff_field(v_x1_24265, 1);
    V v_ru_24x1_24265_24MkPair = heff_take_reuse_n(v_x1_24265, 3ULL, 2);
    switch (heff_tag_of(v_x11_24266)) {
    case TAG_Left: {
      V v_e_24268 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24268}), v_st_24267});
    }
    case TAG_Right: {
      V v_x_24269 = heff_field(v_x11_24266, 0);
      V v_ru_24x11_24266_24Right = heff_take_reuse_n(v_x11_24266, 1ULL, 1);
      V v_t_24270 = heff_tag_at_n(v_ru_24x11_24266_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24269})});
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){v_t_24270, v_st_24267});
    }
    default: return heff_nomatch(v_x11_24266);
    }
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam25(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      V v_ru_24x11_24275_24Right = heff_take_reuse_n(v_x11_24275, 1ULL, 1);
      V v_t_24279 = heff_tag_at_n(v_ru_24x11_24275_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24278})});
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){v_t_24279, v_st_24276});
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam26(V self, V *args) {
  V v_st_24285 = args[0];
  V v_m_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24286 = heff_tr(heff_call(v_m_24284, 1, (V[]){v_st_24285}));
  switch (heff_tag_of(v_x1_24286)) {
  case TAG_MkPair: {
    V v_x11_24287 = heff_field(v_x1_24286, 0);
    V v_st_24288 = heff_field(v_x1_24286, 1);
    V v_ru_24x1_24286_24MkPair = heff_take_reuse_n(v_x1_24286, 3ULL, 2);
    switch (heff_tag_of(v_x11_24287)) {
    case TAG_Left: {
      V v_e_24289 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24289}), v_st_24288});
    }
    case TAG_Right: {
      V v_x_24290 = heff_field(v_x11_24287, 0);
      V v_ru_24x11_24287_24Right = heff_take_reuse_n(v_x11_24287, 1ULL, 1);
      V v_t_24291 = heff_tag_at_n(v_ru_24x11_24287_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24290})});
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){v_t_24291, v_st_24288});
    }
    default: return heff_nomatch(v_x11_24287);
    }
  }
  default: return heff_nomatch(v_x1_24286);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam27(V self, V *args) {
  V v_st_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24298 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_st_24297}));
  switch (heff_tag_of(v_x1_24298)) {
  case TAG_MkPair: {
    V v_x11_24299 = heff_field(v_x1_24298, 0);
    V v_st_24300 = heff_field(v_x1_24298, 1);
    V v_ru_24x1_24298_24MkPair = heff_take_reuse_n(v_x1_24298, 3ULL, 2);
    switch (heff_tag_of(v_x11_24299)) {
    case TAG_Left: {
      V v_e_24301 = heff_field(v_x11_24299, 0);
      heff_take_n(v_x11_24299, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24298_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24301}), v_st_24300});
    }
    case TAG_Right: {
      V v_x_24302 = heff_field(v_x11_24299, 0);
      V v_ru_24x11_24299_24Right = heff_take_reuse_n(v_x11_24299, 1ULL, 1);
      V v_t_24303 = heff_tag_at_n(v_ru_24x11_24299_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24302})});
      return heff_tag_at_n(v_ru_24x1_24298_24MkPair, TAG_MkPair, 2, (V[]){v_t_24303, v_st_24300});
    }
    default: return heff_nomatch(v_x11_24299);
    }
  }
  default: return heff_nomatch(v_x1_24298);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam28(V self, V *args) {
  V v_st_24308 = args[0];
  V v_m_24307 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24309 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_st_24308}));
  switch (heff_tag_of(v_x1_24309)) {
  case TAG_MkPair: {
    V v_x11_24310 = heff_field(v_x1_24309, 0);
    V v_st_24311 = heff_field(v_x1_24309, 1);
    V v_ru_24x1_24309_24MkPair = heff_take_reuse_n(v_x1_24309, 3ULL, 2);
    switch (heff_tag_of(v_x11_24310)) {
    case TAG_Left: {
      V v_e_24312 = heff_field(v_x11_24310, 0);
      heff_take_n(v_x11_24310, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24312}), v_st_24311});
    }
    case TAG_Right: {
      V v_x_24313 = heff_field(v_x11_24310, 0);
      V v_ru_24x11_24310_24Right = heff_take_reuse_n(v_x11_24310, 1ULL, 1);
      V v_t_24314 = heff_tag_at_n(v_ru_24x11_24310_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24313})});
      return heff_tag_at_n(v_ru_24x1_24309_24MkPair, TAG_MkPair, 2, (V[]){v_t_24314, v_st_24311});
    }
    default: return heff_nomatch(v_x11_24310);
    }
  }
  default: return heff_nomatch(v_x1_24309);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam29(V self, V *args) {
  V v_st_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24323 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_st_24322}));
  switch (heff_tag_of(v_x1_24323)) {
  case TAG_MkPair: {
    V v_x11_24324 = heff_field(v_x1_24323, 0);
    V v_st_24325 = heff_field(v_x1_24323, 1);
    V v_ru_24x1_24323_24MkPair = heff_take_reuse_n(v_x1_24323, 3ULL, 2);
    switch (heff_tag_of(v_x11_24324)) {
    case TAG_Left: {
      V v_e_24326 = heff_field(v_x11_24324, 0);
      heff_take_n(v_x11_24324, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24326}), v_st_24325});
    }
    case TAG_Right: {
      V v_x_24327 = heff_field(v_x11_24324, 0);
      V v_ru_24x11_24324_24Right = heff_take_reuse_n(v_x11_24324, 1ULL, 1);
      V v_t_24328 = heff_tag_at_n(v_ru_24x11_24324_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24327})});
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){v_t_24328, v_st_24325});
    }
    default: return heff_nomatch(v_x11_24324);
    }
  }
  default: return heff_nomatch(v_x1_24323);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam30(V self, V *args) {
  V v_st_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24333 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_st_24332}));
  switch (heff_tag_of(v_x1_24333)) {
  case TAG_MkPair: {
    V v_x11_24334 = heff_field(v_x1_24333, 0);
    V v_st_24335 = heff_field(v_x1_24333, 1);
    V v_ru_24x1_24333_24MkPair = heff_take_reuse_n(v_x1_24333, 3ULL, 2);
    switch (heff_tag_of(v_x11_24334)) {
    case TAG_Left: {
      V v_e_24336 = heff_field(v_x11_24334, 0);
      heff_take_n(v_x11_24334, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24333_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24336}), v_st_24335});
    }
    case TAG_Right: {
      V v_x_24337 = heff_field(v_x11_24334, 0);
      V v_ru_24x11_24334_24Right = heff_take_reuse_n(v_x11_24334, 1ULL, 1);
      V v_t_24338 = heff_tag_at_n(v_ru_24x11_24334_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24337})});
      return heff_tag_at_n(v_ru_24x1_24333_24MkPair, TAG_MkPair, 2, (V[]){v_t_24338, v_st_24335});
    }
    default: return heff_nomatch(v_x11_24334);
    }
  }
  default: return heff_nomatch(v_x1_24333);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam31(V self, V *args) {
  V v_st_24343 = args[0];
  V v_m_24342 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24344 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_st_24343}));
  switch (heff_tag_of(v_x1_24344)) {
  case TAG_MkPair: {
    V v_x11_24345 = heff_field(v_x1_24344, 0);
    V v_st_24346 = heff_field(v_x1_24344, 1);
    V v_ru_24x1_24344_24MkPair = heff_take_reuse_n(v_x1_24344, 3ULL, 2);
    switch (heff_tag_of(v_x11_24345)) {
    case TAG_Left: {
      V v_e_24347 = heff_field(v_x11_24345, 0);
      heff_take_n(v_x11_24345, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24344_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24347}), v_st_24346});
    }
    case TAG_Right: {
      V v_x_24348 = heff_field(v_x11_24345, 0);
      V v_ru_24x11_24345_24Right = heff_take_reuse_n(v_x11_24345, 1ULL, 1);
      V v_t_24349 = heff_tag_at_n(v_ru_24x11_24345_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24348})});
      return heff_tag_at_n(v_ru_24x1_24344_24MkPair, TAG_MkPair, 2, (V[]){v_t_24349, v_st_24346});
    }
    default: return heff_nomatch(v_x11_24345);
    }
  }
  default: return heff_nomatch(v_x1_24344);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam32(V self, V *args) {
  V v_st_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_st_24357}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_MkPair: {
    V v_x11_24359 = heff_field(v_x1_24358, 0);
    V v_st_24360 = heff_field(v_x1_24358, 1);
    V v_ru_24x1_24358_24MkPair = heff_take_reuse_n(v_x1_24358, 3ULL, 2);
    switch (heff_tag_of(v_x11_24359)) {
    case TAG_Left: {
      V v_e_24361 = heff_field(v_x11_24359, 0);
      heff_take_n(v_x11_24359, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24361}), v_st_24360});
    }
    case TAG_Right: {
      V v_x_24362 = heff_field(v_x11_24359, 0);
      V v_ru_24x11_24359_24Right = heff_take_reuse_n(v_x11_24359, 1ULL, 1);
      V v_t_24363 = heff_tag_at_n(v_ru_24x11_24359_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24362})});
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){v_t_24363, v_st_24360});
    }
    default: return heff_nomatch(v_x11_24359);
    }
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam33(V self, V *args) {
  V v_st_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24373 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_st_24372}));
  switch (heff_tag_of(v_x1_24373)) {
  case TAG_MkPair: {
    V v_x11_24374 = heff_field(v_x1_24373, 0);
    V v_st_24375 = heff_field(v_x1_24373, 1);
    V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
    switch (heff_tag_of(v_x11_24374)) {
    case TAG_Left: {
      V v_e_24376 = heff_field(v_x11_24374, 0);
      heff_take_n(v_x11_24374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
    }
    case TAG_Right: {
      V v_x_24377 = heff_field(v_x11_24374, 0);
      V v_ru_24x11_24374_24Right = heff_take_reuse_n(v_x11_24374, 1ULL, 1);
      V v_t_24378 = heff_tag_at_n(v_ru_24x11_24374_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24377})});
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){v_t_24378, v_st_24375});
    }
    default: return heff_nomatch(v_x11_24374);
    }
  }
  default: return heff_nomatch(v_x1_24373);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam34(V self, V *args) {
  V v_st_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24386}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_MkPair: {
    V v_x11_24388 = heff_field(v_x1_24387, 0);
    V v_st_24389 = heff_field(v_x1_24387, 1);
    V v_ru_24x1_24387_24MkPair = heff_take_reuse_n(v_x1_24387, 3ULL, 2);
    switch (heff_tag_of(v_x11_24388)) {
    case TAG_Left: {
      V v_e_24390 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24390}), v_st_24389});
    }
    case TAG_Right: {
      V v_x_24391 = heff_field(v_x11_24388, 0);
      V v_ru_24x11_24388_24Right = heff_take_reuse_n(v_x11_24388, 1ULL, 1);
      V v_t_24392 = heff_tag_at_n(v_ru_24x11_24388_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24391})});
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){v_t_24392, v_st_24389});
    }
    default: return heff_nomatch(v_x11_24388);
    }
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam35(V self, V *args) {
  V v_st_24397 = args[0];
  V v_m_24396 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24398 = heff_tr(heff_call(v_m_24396, 1, (V[]){v_st_24397}));
  switch (heff_tag_of(v_x1_24398)) {
  case TAG_MkPair: {
    V v_x11_24399 = heff_field(v_x1_24398, 0);
    V v_st_24400 = heff_field(v_x1_24398, 1);
    V v_ru_24x1_24398_24MkPair = heff_take_reuse_n(v_x1_24398, 3ULL, 2);
    switch (heff_tag_of(v_x11_24399)) {
    case TAG_Left: {
      V v_e_24401 = heff_field(v_x11_24399, 0);
      heff_take_n(v_x11_24399, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24398_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24401}), v_st_24400});
    }
    case TAG_Right: {
      V v_x_24402 = heff_field(v_x11_24399, 0);
      V v_ru_24x11_24399_24Right = heff_take_reuse_n(v_x11_24399, 1ULL, 1);
      V v_t_24403 = heff_tag_at_n(v_ru_24x11_24399_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24402})});
      return heff_tag_at_n(v_ru_24x1_24398_24MkPair, TAG_MkPair, 2, (V[]){v_t_24403, v_st_24400});
    }
    default: return heff_nomatch(v_x11_24399);
    }
  }
  default: return heff_nomatch(v_x1_24398);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam36(V self, V *args) {
  V v_st_24409 = args[0];
  V v_m_24408 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24410 = heff_tr(heff_call(v_m_24408, 1, (V[]){v_st_24409}));
  switch (heff_tag_of(v_x1_24410)) {
  case TAG_MkPair: {
    V v_x11_24411 = heff_field(v_x1_24410, 0);
    V v_st_24412 = heff_field(v_x1_24410, 1);
    V v_ru_24x1_24410_24MkPair = heff_take_reuse_n(v_x1_24410, 3ULL, 2);
    switch (heff_tag_of(v_x11_24411)) {
    case TAG_Left: {
      V v_e_24413 = heff_field(v_x11_24411, 0);
      heff_take_n(v_x11_24411, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24413}), v_st_24412});
    }
    case TAG_Right: {
      V v_x_24414 = heff_field(v_x11_24411, 0);
      V v_ru_24x11_24411_24Right = heff_take_reuse_n(v_x11_24411, 1ULL, 1);
      V v_t_24415 = heff_tag_at_n(v_ru_24x11_24411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24414})});
      return heff_tag_at_n(v_ru_24x1_24410_24MkPair, TAG_MkPair, 2, (V[]){v_t_24415, v_st_24412});
    }
    default: return heff_nomatch(v_x11_24411);
    }
  }
  default: return heff_nomatch(v_x1_24410);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam37(V self, V *args) {
  V v_st_24423 = args[0];
  V v_m_24422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24424 = heff_tr(heff_call(v_m_24422, 1, (V[]){v_st_24423}));
  switch (heff_tag_of(v_x1_24424)) {
  case TAG_MkPair: {
    V v_x11_24425 = heff_field(v_x1_24424, 0);
    V v_st_24426 = heff_field(v_x1_24424, 1);
    V v_ru_24x1_24424_24MkPair = heff_take_reuse_n(v_x1_24424, 3ULL, 2);
    switch (heff_tag_of(v_x11_24425)) {
    case TAG_Left: {
      V v_e_24427 = heff_field(v_x11_24425, 0);
      heff_take_n(v_x11_24425, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24427}), v_st_24426});
    }
    case TAG_Right: {
      V v_x_24428 = heff_field(v_x11_24425, 0);
      V v_ru_24x11_24425_24Right = heff_take_reuse_n(v_x11_24425, 1ULL, 1);
      V v_t_24429 = heff_tag_at_n(v_ru_24x11_24425_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24428})});
      return heff_tag_at_n(v_ru_24x1_24424_24MkPair, TAG_MkPair, 2, (V[]){v_t_24429, v_st_24426});
    }
    default: return heff_nomatch(v_x11_24425);
    }
  }
  default: return heff_nomatch(v_x1_24424);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam38(V self, V *args) {
  V v_st_24432 = args[0];
  V v_m_24431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24433 = heff_tr(heff_call(v_m_24431, 1, (V[]){v_st_24432}));
  switch (heff_tag_of(v_x1_24433)) {
  case TAG_MkPair: {
    V v_x11_24434 = heff_field(v_x1_24433, 0);
    V v_st_24435 = heff_field(v_x1_24433, 1);
    V v_ru_24x1_24433_24MkPair = heff_take_reuse_n(v_x1_24433, 3ULL, 2);
    switch (heff_tag_of(v_x11_24434)) {
    case TAG_Left: {
      V v_e_24436 = heff_field(v_x11_24434, 0);
      heff_take_n(v_x11_24434, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24436}), v_st_24435});
    }
    case TAG_Right: {
      V v_x_24437 = heff_field(v_x11_24434, 0);
      V v_ru_24x11_24434_24Right = heff_take_reuse_n(v_x11_24434, 1ULL, 1);
      V v_t_24438 = heff_tag_at_n(v_ru_24x11_24434_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437})});
      return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){v_t_24438, v_st_24435});
    }
    default: return heff_nomatch(v_x11_24434);
    }
  }
  default: return heff_nomatch(v_x1_24433);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam39(V self, V *args) {
  V v_st_24442 = args[0];
  V v_m_24441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24443 = heff_tr(heff_call(v_m_24441, 1, (V[]){v_st_24442}));
  switch (heff_tag_of(v_x1_24443)) {
  case TAG_MkPair: {
    V v_x11_24444 = heff_field(v_x1_24443, 0);
    V v_st_24445 = heff_field(v_x1_24443, 1);
    V v_ru_24x1_24443_24MkPair = heff_take_reuse_n(v_x1_24443, 3ULL, 2);
    switch (heff_tag_of(v_x11_24444)) {
    case TAG_Left: {
      V v_e_24446 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24446}), v_st_24445});
    }
    case TAG_Right: {
      V v_x_24447 = heff_field(v_x11_24444, 0);
      V v_ru_24x11_24444_24Right = heff_take_reuse_n(v_x11_24444, 1ULL, 1);
      V v_t_24448 = heff_tag_at_n(v_ru_24x11_24444_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24447})});
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){v_t_24448, v_st_24445});
    }
    default: return heff_nomatch(v_x11_24444);
    }
  }
  default: return heff_nomatch(v_x1_24443);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam40(V self, V *args) {
  V v_st_24454 = args[0];
  V v_m_24453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24455 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_st_24454}));
  switch (heff_tag_of(v_x1_24455)) {
  case TAG_MkPair: {
    V v_x11_24456 = heff_field(v_x1_24455, 0);
    V v_st_24457 = heff_field(v_x1_24455, 1);
    V v_ru_24x1_24455_24MkPair = heff_take_reuse_n(v_x1_24455, 3ULL, 2);
    switch (heff_tag_of(v_x11_24456)) {
    case TAG_Left: {
      V v_e_24458 = heff_field(v_x11_24456, 0);
      heff_take_n(v_x11_24456, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24458}), v_st_24457});
    }
    case TAG_Right: {
      V v_x_24459 = heff_field(v_x11_24456, 0);
      V v_ru_24x11_24456_24Right = heff_take_reuse_n(v_x11_24456, 1ULL, 1);
      V v_t_24460 = heff_tag_at_n(v_ru_24x11_24456_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24459})});
      return heff_tag_at_n(v_ru_24x1_24455_24MkPair, TAG_MkPair, 2, (V[]){v_t_24460, v_st_24457});
    }
    default: return heff_nomatch(v_x11_24456);
    }
  }
  default: return heff_nomatch(v_x1_24455);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam41(V self, V *args) {
  V v_st_24464 = args[0];
  V v_m_24463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24465 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_st_24464}));
  switch (heff_tag_of(v_x1_24465)) {
  case TAG_MkPair: {
    V v_x11_24466 = heff_field(v_x1_24465, 0);
    V v_st_24467 = heff_field(v_x1_24465, 1);
    V v_ru_24x1_24465_24MkPair = heff_take_reuse_n(v_x1_24465, 3ULL, 2);
    switch (heff_tag_of(v_x11_24466)) {
    case TAG_Left: {
      V v_e_24468 = heff_field(v_x11_24466, 0);
      heff_take_n(v_x11_24466, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24468}), v_st_24467});
    }
    case TAG_Right: {
      V v_x_24469 = heff_field(v_x11_24466, 0);
      V v_ru_24x11_24466_24Right = heff_take_reuse_n(v_x11_24466, 1ULL, 1);
      V v_t_24470 = heff_tag_at_n(v_ru_24x11_24466_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24469})});
      return heff_tag_at_n(v_ru_24x1_24465_24MkPair, TAG_MkPair, 2, (V[]){v_t_24470, v_st_24467});
    }
    default: return heff_nomatch(v_x11_24466);
    }
  }
  default: return heff_nomatch(v_x1_24465);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam42(V self, V *args) {
  V v_st_24476 = args[0];
  V v_m_24475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24477 = heff_tr(heff_call(v_m_24475, 1, (V[]){v_st_24476}));
  switch (heff_tag_of(v_x1_24477)) {
  case TAG_MkPair: {
    V v_x11_24478 = heff_field(v_x1_24477, 0);
    V v_st_24479 = heff_field(v_x1_24477, 1);
    V v_ru_24x1_24477_24MkPair = heff_take_reuse_n(v_x1_24477, 3ULL, 2);
    switch (heff_tag_of(v_x11_24478)) {
    case TAG_Left: {
      V v_e_24480 = heff_field(v_x11_24478, 0);
      heff_take_n(v_x11_24478, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24480}), v_st_24479});
    }
    case TAG_Right: {
      V v_x_24481 = heff_field(v_x11_24478, 0);
      V v_ru_24x11_24478_24Right = heff_take_reuse_n(v_x11_24478, 1ULL, 1);
      V v_t_24482 = heff_tag_at_n(v_ru_24x11_24478_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24481})});
      return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){v_t_24482, v_st_24479});
    }
    default: return heff_nomatch(v_x11_24478);
    }
  }
  default: return heff_nomatch(v_x1_24477);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam43(V self, V *args) {
  V v_st_24488 = args[0];
  V v_m_24487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24489 = heff_tr(heff_call(v_m_24487, 1, (V[]){v_st_24488}));
  switch (heff_tag_of(v_x1_24489)) {
  case TAG_MkPair: {
    V v_x11_24490 = heff_field(v_x1_24489, 0);
    V v_st_24491 = heff_field(v_x1_24489, 1);
    V v_ru_24x1_24489_24MkPair = heff_take_reuse_n(v_x1_24489, 3ULL, 2);
    switch (heff_tag_of(v_x11_24490)) {
    case TAG_Left: {
      V v_e_24492 = heff_field(v_x11_24490, 0);
      heff_take_n(v_x11_24490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24492}), v_st_24491});
    }
    case TAG_Right: {
      V v_x_24493 = heff_field(v_x11_24490, 0);
      V v_ru_24x11_24490_24Right = heff_take_reuse_n(v_x11_24490, 1ULL, 1);
      V v_t_24494 = heff_tag_at_n(v_ru_24x11_24490_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24493})});
      return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){v_t_24494, v_st_24491});
    }
    default: return heff_nomatch(v_x11_24490);
    }
  }
  default: return heff_nomatch(v_x1_24489);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam44(V self, V *args) {
  V v_st_24500 = args[0];
  V v_m_24499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24501 = heff_tr(heff_call(v_m_24499, 1, (V[]){v_st_24500}));
  switch (heff_tag_of(v_x1_24501)) {
  case TAG_MkPair: {
    V v_x11_24502 = heff_field(v_x1_24501, 0);
    V v_st_24503 = heff_field(v_x1_24501, 1);
    V v_ru_24x1_24501_24MkPair = heff_take_reuse_n(v_x1_24501, 3ULL, 2);
    switch (heff_tag_of(v_x11_24502)) {
    case TAG_Left: {
      V v_e_24504 = heff_field(v_x11_24502, 0);
      heff_take_n(v_x11_24502, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24504}), v_st_24503});
    }
    case TAG_Right: {
      V v_x_24505 = heff_field(v_x11_24502, 0);
      V v_ru_24x11_24502_24Right = heff_take_reuse_n(v_x11_24502, 1ULL, 1);
      V v_t_24506 = heff_tag_at_n(v_ru_24x11_24502_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24505})});
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){v_t_24506, v_st_24503});
    }
    default: return heff_nomatch(v_x11_24502);
    }
  }
  default: return heff_nomatch(v_x1_24501);
  }
}
V g_heff_2esyntax_2esurface_2efieldOrName_lam45(V self, V *args) {
  V v_st_24514 = args[0];
  V v_m_24513 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24515 = heff_tr(heff_call(v_m_24513, 1, (V[]){v_st_24514}));
  switch (heff_tag_of(v_x1_24515)) {
  case TAG_MkPair: {
    V v_x11_24516 = heff_field(v_x1_24515, 0);
    V v_st_24517 = heff_field(v_x1_24515, 1);
    V v_ru_24x1_24515_24MkPair = heff_take_reuse_n(v_x1_24515, 3ULL, 2);
    switch (heff_tag_of(v_x11_24516)) {
    case TAG_Left: {
      V v_e_24518 = heff_field(v_x11_24516, 0);
      heff_take_n(v_x11_24516, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24515_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24518}), v_st_24517});
    }
    case TAG_Right: {
      V v_x_24519 = heff_field(v_x11_24516, 0);
      V v_ru_24x11_24516_24Right = heff_take_reuse_n(v_x11_24516, 1ULL, 1);
      V v_t_24520 = heff_tag_at_n(v_ru_24x11_24516_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24519})});
      return heff_tag_at_n(v_ru_24x1_24515_24MkPair, TAG_MkPair, 2, (V[]){v_t_24520, v_st_24517});
    }
    default: return heff_nomatch(v_x11_24516);
    }
  }
  default: return heff_nomatch(v_x1_24515);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam45(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam46(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam47(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam48(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam49(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam50(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam51(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam52(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam53(V self, V *args);
V g_heff_2esyntax_2esurface_2estmtL_lam54(V self, V *args);
Clo g_heff_2esyntax_2esurface_2estmtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2estmtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2estmtL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Seg: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam4, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Braces: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam5, 1, 1, (V[]){v_m_2477});
  }
  case TAG_Update: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_EUSet: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam7, 1, 1, (V[]){v_m_24108});
  }
  case TAG_InstB: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFSet: {
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam9, 1, 1, (V[]){v_m_24138});
  }
  case TAG_EFDefault: {
    V v_m_24152 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam10, 1, 1, (V[]){v_m_24152});
  }
  case TAG_Sum: {
    V v_m_24168 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam11, 1, 1, (V[]){v_m_24168});
  }
  case TAG_ECon: {
    V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam12, 1, 1, (V[]){v_m_24181});
  }
  case TAG_EField: {
    V v_m_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam13, 1, 1, (V[]){v_m_24194});
  }
  case TAG_ENeg: {
    V v_m_24207 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam14, 1, 1, (V[]){v_m_24207});
  }
  case TAG_ETilde: {
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam15, 1, 1, (V[]){v_m_24220});
  }
  case TAG_App: {
    V v_m_24233 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam16, 1, 1, (V[]){v_m_24233});
  }
  case TAG_Op: {
    V v_m_24247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam17, 1, 1, (V[]){v_m_24247});
  }
  case TAG_Ops: {
    V v_m_24260 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam18, 1, 1, (V[]){v_m_24260});
  }
  case TAG_OpRhs: {
    V v_m_24273 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam19, 1, 1, (V[]){v_m_24273});
  }
  case TAG_Ann: {
    V v_m_24287 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam20, 1, 1, (V[]){v_m_24287});
  }
  case TAG_BVar: {
    V v_m_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam21, 1, 1, (V[]){v_m_24299});
  }
  case TAG_BImp: {
    V v_m_24313 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam22, 1, 1, (V[]){v_m_24313});
  }
  case TAG_BAnn: {
    V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam23, 1, 1, (V[]){v_m_24329});
  }
  case TAG_BPat: {
    V v_m_24341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam24, 1, 1, (V[]){v_m_24341});
  }
  case TAG_Lam: {
    V v_m_24356 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam25, 1, 1, (V[]){v_m_24356});
  }
  case TAG_Case: {
    V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam26, 1, 1, (V[]){v_m_24371});
  }
  case TAG_EAlt: {
    V v_m_24385 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam27, 1, 1, (V[]){v_m_24385});
  }
  case TAG_If: {
    V v_m_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam28, 1, 1, (V[]){v_m_24402});
  }
  case TAG_Do: {
    V v_m_24415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam29, 1, 1, (V[]){v_m_24415});
  }
  case TAG_ESBind: {
    V v_x21_24426 = heff_field(v_x2_241, 0);
    V v_e_24428 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x21_24426)) {
    case TAG_PCon: {
      V v_m_24431 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam30, 1, 3, (V[]){v_m_24431, v_r_240, v_x21_24426});
    }
    case TAG_PAtom: {
      V v_x_24458 = heff_field(v_x21_24426, 0);
      heff_take_n(v_x21_24426, 1ULL, 1);
      V v_m_24459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam31, 1, 2, (V[]){v_m_24459, v_x_24458});
    }
    case TAG_PParen: {
      V v_m_24478 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam32, 1, 3, (V[]){v_m_24478, v_r_240, v_x21_24426});
    }
    case TAG_PList: {
      V v_m_24509 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam33, 1, 3, (V[]){v_m_24509, v_r_240, v_x21_24426});
    }
    case TAG_POp: {
      V v_m_24539 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam34, 1, 3, (V[]){v_m_24539, v_r_240, v_x21_24426});
    }
    case TAG_PRec: {
      V v_m_24570 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam35, 1, 3, (V[]){v_m_24570, v_r_240, v_x21_24426});
    }
    case TAG_PField: {
      V v_m_24600 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam36, 1, 3, (V[]){v_m_24600, v_r_240, v_x21_24426});
    }
    case TAG_PAs: {
      V v_m_24630 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam37, 1, 3, (V[]){v_m_24630, v_r_240, v_x21_24426});
    }
    case TAG_PSeg: {
      V v_m_24660 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24428}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam38, 1, 3, (V[]){v_m_24660, v_r_240, v_x21_24426});
    }
    default: return heff_nomatch(v_x21_24426);
    }
  }
  case TAG_ELet: {
    V v_kw_24687 = heff_dup(heff_field(v_x2_241, 0));
    V v_p_24688 = heff_dup(heff_field(v_x2_241, 1));
    V v_ann0_24689 = heff_dup(heff_field(v_x2_241, 2));
    V v_e_24691 = heff_dup(heff_field(v_x2_241, 4));
    V v_x26_24692 = heff_dup(heff_field(v_x2_241, 5));
    switch (heff_tag_of(v_x26_24692)) {
    case TAG_Nothing: {
      heff_drop_tag(v_x2_241, 6);
      V v_m_24693 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_dup(v_p_24688), v_ann0_24689, heff_dup(v_e_24691)));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam39, 1, 4, (V[]){v_m_24693, v_p_24688, v_e_24691, v_kw_24687});
    }
    case TAG_Just: {
      heff_take_n(v_x26_24692, 0ULL, 1);
      heff_drop_rec(v_kw_24687, 9);
      heff_drop(v_p_24688);
      heff_drop(v_ann0_24689);
      heff_drop(v_e_24691);
      V v_m_24713 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam40, 1, 1, (V[]){v_m_24713});
    }
    default: return heff_nomatch(v_x26_24692);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24724 = heff_dup(heff_field(v_x2_241, 0));
    V v_p_24725 = heff_dup(heff_field(v_x2_241, 1));
    V v_ann0_24726 = heff_dup(heff_field(v_x2_241, 2));
    V v_e_24728 = heff_dup(heff_field(v_x2_241, 4));
    V v_ss_24730 = heff_dup(heff_field(v_x2_241, 6));
    V v_m_24731 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_24725), v_ann0_24726, v_e_24728));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam41, 1, 6, (V[]){v_m_24731, v_r_240, v_ss_24730, v_p_24725, v_x2_241, v_kw_24724});
  }
  case TAG_ELetMut: {
    V v_kw_24758 = heff_field(v_x2_241, 0);
    V v_x_24760 = heff_field(v_x2_241, 2);
    V v_ann0_24761 = heff_field(v_x2_241, 3);
    V v_e_24763 = heff_field(v_x2_241, 5);
    heff_take_n(v_x2_241, 45ULL, 6);
    V v_m_24764 = (g_heff_2esyntax_2esurface_2eletHeadL(v_r_240, heff_tag_n(TAG_PAtom, 1, (V[]){heff_dup(v_x_24760)}), v_ann0_24761, heff_dup(v_e_24763)));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam43, 1, 4, (V[]){v_m_24764, v_x_24760, v_e_24763, v_kw_24758});
  }
  case TAG_EAssign: {
    V v_m_24785 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam44, 1, 1, (V[]){v_m_24785});
  }
  case TAG_EWhile: {
    V v_m_24800 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam45, 1, 1, (V[]){v_m_24800});
  }
  case TAG_EFor: {
    V v_m_24817 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam46, 1, 1, (V[]){v_m_24817});
  }
  case TAG_EJump: {
    V v_m_24829 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam47, 1, 1, (V[]){v_m_24829});
  }
  case TAG_EReturn: {
    V v_m_24842 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam48, 1, 1, (V[]){v_m_24842});
  }
  case TAG_ENest: {
    V v_m_24857 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam49, 1, 1, (V[]){v_m_24857});
  }
  case TAG_EArrow: {
    V v_m_24870 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam50, 1, 1, (V[]){v_m_24870});
  }
  case TAG_IfThen: {
    V v_m_24885 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam51, 1, 1, (V[]){v_m_24885});
  }
  case TAG_ETry: {
    V v_m_24900 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam52, 1, 1, (V[]){v_m_24900});
  }
  case TAG_ECatch: {
    V v_m_24915 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam53, 1, 1, (V[]){v_m_24915});
  }
  case TAG_EWith: {
    V v_m_24932 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam54, 1, 1, (V[]){v_m_24932});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2estmtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2estmtL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_StmtExpr, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_StmtExpr, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_StmtExpr, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_StmtExpr, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_x_2468)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_x_2468, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_x_2468);
      }
      V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_StmtExpr, 1, (V[]){v_x_2468}), v_t_2471});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2472}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam5(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      V v_ru_24x11_2480_24Right = heff_take_reuse_n(v_x11_2480, 1ULL, 1);
      V v_t_2486;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_x_2483, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2480_24Right, TAG_StmtExpr, 1, (V[]){v_x_2483}), v_t_2486});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2487}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_StmtExpr, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam7(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 1ULL, 1);
      V v_t_24117;
      switch (heff_tag_of(v_x_24114)) {
      case TAG_At: {
        V v_s_24116 = heff_dup(heff_field(v_x_24114, 1));
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_x_24114);
      }
      V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_StmtExpr, 1, (V[]){v_x_24114}), v_t_24117});
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24118}), v_st_24112});
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_StmtExpr, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam9(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24147;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_At: {
        V v_s_24146 = heff_dup(heff_field(v_x_24144, 1));
        v_t_24147 = v_s_24146;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_StmtExpr, 1, (V[]){v_x_24144}), v_t_24147});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam10(V self, V *args) {
  V v_st_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_st_24153}));
  switch (heff_tag_of(v_x1_24154)) {
  case TAG_MkPair: {
    V v_x11_24155 = heff_field(v_x1_24154, 0);
    V v_st_24156 = heff_field(v_x1_24154, 1);
    V v_ru_24x1_24154_24MkPair = heff_take_reuse_n(v_x1_24154, 3ULL, 2);
    switch (heff_tag_of(v_x11_24155)) {
    case TAG_Left: {
      V v_e_24157 = heff_field(v_x11_24155, 0);
      heff_take_n(v_x11_24155, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24157}), v_st_24156});
    }
    case TAG_Right: {
      V v_x_24158 = heff_field(v_x11_24155, 0);
      V v_ru_24x11_24155_24Right = heff_take_reuse_n(v_x11_24155, 1ULL, 1);
      V v_t_24161;
      switch (heff_tag_of(v_x_24158)) {
      case TAG_At: {
        V v_s_24160 = heff_dup(heff_field(v_x_24158, 1));
        v_t_24161 = v_s_24160;
        break;
      }
      default: heff_nomatch(v_x_24158);
      }
      V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24155_24Right, TAG_StmtExpr, 1, (V[]){v_x_24158}), v_t_24161});
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24162}), v_st_24156});
    }
    default: return heff_nomatch(v_x11_24155);
    }
  }
  default: return heff_nomatch(v_x1_24154);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam11(V self, V *args) {
  V v_st_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_st_24169}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
      V v_t_24177;
      switch (heff_tag_of(v_x_24174)) {
      case TAG_At: {
        V v_s_24176 = heff_dup(heff_field(v_x_24174, 1));
        v_t_24177 = v_s_24176;
        break;
      }
      default: heff_nomatch(v_x_24174);
      }
      V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_StmtExpr, 1, (V[]){v_x_24174}), v_t_24177});
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24178}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam12(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24190;
      switch (heff_tag_of(v_x_24187)) {
      case TAG_At: {
        V v_s_24189 = heff_dup(heff_field(v_x_24187, 1));
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_x_24187);
      }
      V v_t_24191 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_StmtExpr, 1, (V[]){v_x_24187}), v_t_24190});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24191}), v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam13(V self, V *args) {
  V v_st_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_st_24195}));
  switch (heff_tag_of(v_x1_24196)) {
  case TAG_MkPair: {
    V v_x11_24197 = heff_field(v_x1_24196, 0);
    V v_st_24198 = heff_field(v_x1_24196, 1);
    V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
    switch (heff_tag_of(v_x11_24197)) {
    case TAG_Left: {
      V v_e_24199 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
    }
    case TAG_Right: {
      V v_x_24200 = heff_field(v_x11_24197, 0);
      V v_ru_24x11_24197_24Right = heff_take_reuse_n(v_x11_24197, 1ULL, 1);
      V v_t_24203;
      switch (heff_tag_of(v_x_24200)) {
      case TAG_At: {
        V v_s_24202 = heff_dup(heff_field(v_x_24200, 1));
        v_t_24203 = v_s_24202;
        break;
      }
      default: heff_nomatch(v_x_24200);
      }
      V v_t_24204 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24197_24Right, TAG_StmtExpr, 1, (V[]){v_x_24200}), v_t_24203});
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24204}), v_st_24198});
    }
    default: return heff_nomatch(v_x11_24197);
    }
  }
  default: return heff_nomatch(v_x1_24196);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam14(V self, V *args) {
  V v_st_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24209 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_st_24208}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_MkPair: {
    V v_x11_24210 = heff_field(v_x1_24209, 0);
    V v_st_24211 = heff_field(v_x1_24209, 1);
    V v_ru_24x1_24209_24MkPair = heff_take_reuse_n(v_x1_24209, 3ULL, 2);
    switch (heff_tag_of(v_x11_24210)) {
    case TAG_Left: {
      V v_e_24212 = heff_field(v_x11_24210, 0);
      heff_take_n(v_x11_24210, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24212}), v_st_24211});
    }
    case TAG_Right: {
      V v_x_24213 = heff_field(v_x11_24210, 0);
      V v_ru_24x11_24210_24Right = heff_take_reuse_n(v_x11_24210, 1ULL, 1);
      V v_t_24216;
      switch (heff_tag_of(v_x_24213)) {
      case TAG_At: {
        V v_s_24215 = heff_dup(heff_field(v_x_24213, 1));
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_x_24213);
      }
      V v_t_24217 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24210_24Right, TAG_StmtExpr, 1, (V[]){v_x_24213}), v_t_24216});
      return heff_tag_at_n(v_ru_24x1_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24217}), v_st_24211});
    }
    default: return heff_nomatch(v_x11_24210);
    }
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam15(V self, V *args) {
  V v_st_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_st_24221}));
  switch (heff_tag_of(v_x1_24222)) {
  case TAG_MkPair: {
    V v_x11_24223 = heff_field(v_x1_24222, 0);
    V v_st_24224 = heff_field(v_x1_24222, 1);
    V v_ru_24x1_24222_24MkPair = heff_take_reuse_n(v_x1_24222, 3ULL, 2);
    switch (heff_tag_of(v_x11_24223)) {
    case TAG_Left: {
      V v_e_24225 = heff_field(v_x11_24223, 0);
      heff_take_n(v_x11_24223, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24225}), v_st_24224});
    }
    case TAG_Right: {
      V v_x_24226 = heff_field(v_x11_24223, 0);
      V v_ru_24x11_24223_24Right = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
      V v_t_24229;
      switch (heff_tag_of(v_x_24226)) {
      case TAG_At: {
        V v_s_24228 = heff_dup(heff_field(v_x_24226, 1));
        v_t_24229 = v_s_24228;
        break;
      }
      default: heff_nomatch(v_x_24226);
      }
      V v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24223_24Right, TAG_StmtExpr, 1, (V[]){v_x_24226}), v_t_24229});
      return heff_tag_at_n(v_ru_24x1_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24230}), v_st_24224});
    }
    default: return heff_nomatch(v_x11_24223);
    }
  }
  default: return heff_nomatch(v_x1_24222);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam16(V self, V *args) {
  V v_st_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_st_24234}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_MkPair: {
    V v_x11_24236 = heff_field(v_x1_24235, 0);
    V v_st_24237 = heff_field(v_x1_24235, 1);
    V v_ru_24x1_24235_24MkPair = heff_take_reuse_n(v_x1_24235, 3ULL, 2);
    switch (heff_tag_of(v_x11_24236)) {
    case TAG_Left: {
      V v_e_24238 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24238}), v_st_24237});
    }
    case TAG_Right: {
      V v_x_24239 = heff_field(v_x11_24236, 0);
      V v_ru_24x11_24236_24Right = heff_take_reuse_n(v_x11_24236, 1ULL, 1);
      V v_t_24242;
      switch (heff_tag_of(v_x_24239)) {
      case TAG_At: {
        V v_s_24241 = heff_dup(heff_field(v_x_24239, 1));
        v_t_24242 = v_s_24241;
        break;
      }
      default: heff_nomatch(v_x_24239);
      }
      V v_t_24243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24236_24Right, TAG_StmtExpr, 1, (V[]){v_x_24239}), v_t_24242});
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24243}), v_st_24237});
    }
    default: return heff_nomatch(v_x11_24236);
    }
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam17(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      V v_ru_24x11_24250_24Right = heff_take_reuse_n(v_x11_24250, 1ULL, 1);
      V v_t_24256;
      switch (heff_tag_of(v_x_24253)) {
      case TAG_At: {
        V v_s_24255 = heff_dup(heff_field(v_x_24253, 1));
        v_t_24256 = v_s_24255;
        break;
      }
      default: heff_nomatch(v_x_24253);
      }
      V v_t_24257 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24250_24Right, TAG_StmtExpr, 1, (V[]){v_x_24253}), v_t_24256});
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24257}), v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam18(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
      V v_t_24269;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24268 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24269 = v_s_24268;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_t_24270 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_StmtExpr, 1, (V[]){v_x_24266}), v_t_24269});
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24270}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam19(V self, V *args) {
  V v_st_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_st_24274}));
  switch (heff_tag_of(v_x1_24275)) {
  case TAG_MkPair: {
    V v_x11_24276 = heff_field(v_x1_24275, 0);
    V v_st_24277 = heff_field(v_x1_24275, 1);
    V v_ru_24x1_24275_24MkPair = heff_take_reuse_n(v_x1_24275, 3ULL, 2);
    switch (heff_tag_of(v_x11_24276)) {
    case TAG_Left: {
      V v_e_24278 = heff_field(v_x11_24276, 0);
      heff_take_n(v_x11_24276, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24278}), v_st_24277});
    }
    case TAG_Right: {
      V v_x_24279 = heff_field(v_x11_24276, 0);
      V v_ru_24x11_24276_24Right = heff_take_reuse_n(v_x11_24276, 1ULL, 1);
      V v_t_24282;
      switch (heff_tag_of(v_x_24279)) {
      case TAG_At: {
        V v_s_24281 = heff_dup(heff_field(v_x_24279, 1));
        v_t_24282 = v_s_24281;
        break;
      }
      default: heff_nomatch(v_x_24279);
      }
      V v_t_24283 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24276_24Right, TAG_StmtExpr, 1, (V[]){v_x_24279}), v_t_24282});
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24283}), v_st_24277});
    }
    default: return heff_nomatch(v_x11_24276);
    }
  }
  default: return heff_nomatch(v_x1_24275);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam20(V self, V *args) {
  V v_st_24288 = args[0];
  V v_m_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24289 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_st_24288}));
  switch (heff_tag_of(v_x1_24289)) {
  case TAG_MkPair: {
    V v_x11_24290 = heff_field(v_x1_24289, 0);
    V v_st_24291 = heff_field(v_x1_24289, 1);
    V v_ru_24x1_24289_24MkPair = heff_take_reuse_n(v_x1_24289, 3ULL, 2);
    switch (heff_tag_of(v_x11_24290)) {
    case TAG_Left: {
      V v_e_24292 = heff_field(v_x11_24290, 0);
      heff_take_n(v_x11_24290, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24292}), v_st_24291});
    }
    case TAG_Right: {
      V v_x_24293 = heff_field(v_x11_24290, 0);
      V v_ru_24x11_24290_24Right = heff_take_reuse_n(v_x11_24290, 1ULL, 1);
      V v_t_24296;
      switch (heff_tag_of(v_x_24293)) {
      case TAG_At: {
        V v_s_24295 = heff_dup(heff_field(v_x_24293, 1));
        v_t_24296 = v_s_24295;
        break;
      }
      default: heff_nomatch(v_x_24293);
      }
      V v_t_24297 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24290_24Right, TAG_StmtExpr, 1, (V[]){v_x_24293}), v_t_24296});
      return heff_tag_at_n(v_ru_24x1_24289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24297}), v_st_24291});
    }
    default: return heff_nomatch(v_x11_24290);
    }
  }
  default: return heff_nomatch(v_x1_24289);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam21(V self, V *args) {
  V v_st_24300 = args[0];
  V v_m_24299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24301 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_st_24300}));
  switch (heff_tag_of(v_x1_24301)) {
  case TAG_MkPair: {
    V v_x11_24302 = heff_field(v_x1_24301, 0);
    V v_st_24303 = heff_field(v_x1_24301, 1);
    V v_ru_24x1_24301_24MkPair = heff_take_reuse_n(v_x1_24301, 3ULL, 2);
    switch (heff_tag_of(v_x11_24302)) {
    case TAG_Left: {
      V v_e_24304 = heff_field(v_x11_24302, 0);
      heff_take_n(v_x11_24302, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24304}), v_st_24303});
    }
    case TAG_Right: {
      V v_x_24305 = heff_field(v_x11_24302, 0);
      V v_ru_24x11_24302_24Right = heff_take_reuse_n(v_x11_24302, 1ULL, 1);
      V v_t_24308;
      switch (heff_tag_of(v_x_24305)) {
      case TAG_At: {
        V v_s_24307 = heff_dup(heff_field(v_x_24305, 1));
        v_t_24308 = v_s_24307;
        break;
      }
      default: heff_nomatch(v_x_24305);
      }
      V v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24302_24Right, TAG_StmtExpr, 1, (V[]){v_x_24305}), v_t_24308});
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24309}), v_st_24303});
    }
    default: return heff_nomatch(v_x11_24302);
    }
  }
  default: return heff_nomatch(v_x1_24301);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam22(V self, V *args) {
  V v_st_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_st_24314}));
  switch (heff_tag_of(v_x1_24315)) {
  case TAG_MkPair: {
    V v_x11_24316 = heff_field(v_x1_24315, 0);
    V v_st_24317 = heff_field(v_x1_24315, 1);
    V v_ru_24x1_24315_24MkPair = heff_take_reuse_n(v_x1_24315, 3ULL, 2);
    switch (heff_tag_of(v_x11_24316)) {
    case TAG_Left: {
      V v_e_24318 = heff_field(v_x11_24316, 0);
      heff_take_n(v_x11_24316, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24318}), v_st_24317});
    }
    case TAG_Right: {
      V v_x_24319 = heff_field(v_x11_24316, 0);
      V v_ru_24x11_24316_24Right = heff_take_reuse_n(v_x11_24316, 1ULL, 1);
      V v_t_24322;
      switch (heff_tag_of(v_x_24319)) {
      case TAG_At: {
        V v_s_24321 = heff_dup(heff_field(v_x_24319, 1));
        v_t_24322 = v_s_24321;
        break;
      }
      default: heff_nomatch(v_x_24319);
      }
      V v_t_24323 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24316_24Right, TAG_StmtExpr, 1, (V[]){v_x_24319}), v_t_24322});
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24323}), v_st_24317});
    }
    default: return heff_nomatch(v_x11_24316);
    }
  }
  default: return heff_nomatch(v_x1_24315);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam23(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Right = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      V v_t_24338;
      switch (heff_tag_of(v_x_24335)) {
      case TAG_At: {
        V v_s_24337 = heff_dup(heff_field(v_x_24335, 1));
        v_t_24338 = v_s_24337;
        break;
      }
      default: heff_nomatch(v_x_24335);
      }
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24332_24Right, TAG_StmtExpr, 1, (V[]){v_x_24335}), v_t_24338});
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24339}), v_st_24333});
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam24(V self, V *args) {
  V v_st_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_st_24342}));
  switch (heff_tag_of(v_x1_24343)) {
  case TAG_MkPair: {
    V v_x11_24344 = heff_field(v_x1_24343, 0);
    V v_st_24345 = heff_field(v_x1_24343, 1);
    V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
    switch (heff_tag_of(v_x11_24344)) {
    case TAG_Left: {
      V v_e_24346 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
    }
    case TAG_Right: {
      V v_x_24347 = heff_field(v_x11_24344, 0);
      V v_ru_24x11_24344_24Right = heff_take_reuse_n(v_x11_24344, 1ULL, 1);
      V v_t_24350;
      switch (heff_tag_of(v_x_24347)) {
      case TAG_At: {
        V v_s_24349 = heff_dup(heff_field(v_x_24347, 1));
        v_t_24350 = v_s_24349;
        break;
      }
      default: heff_nomatch(v_x_24347);
      }
      V v_t_24351 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24344_24Right, TAG_StmtExpr, 1, (V[]){v_x_24347}), v_t_24350});
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24351}), v_st_24345});
    }
    default: return heff_nomatch(v_x11_24344);
    }
  }
  default: return heff_nomatch(v_x1_24343);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam25(V self, V *args) {
  V v_st_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_st_24357}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_MkPair: {
    V v_x11_24359 = heff_field(v_x1_24358, 0);
    V v_st_24360 = heff_field(v_x1_24358, 1);
    V v_ru_24x1_24358_24MkPair = heff_take_reuse_n(v_x1_24358, 3ULL, 2);
    switch (heff_tag_of(v_x11_24359)) {
    case TAG_Left: {
      V v_e_24361 = heff_field(v_x11_24359, 0);
      heff_take_n(v_x11_24359, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24361}), v_st_24360});
    }
    case TAG_Right: {
      V v_x_24362 = heff_field(v_x11_24359, 0);
      V v_ru_24x11_24359_24Right = heff_take_reuse_n(v_x11_24359, 1ULL, 1);
      V v_t_24365;
      switch (heff_tag_of(v_x_24362)) {
      case TAG_At: {
        V v_s_24364 = heff_dup(heff_field(v_x_24362, 1));
        v_t_24365 = v_s_24364;
        break;
      }
      default: heff_nomatch(v_x_24362);
      }
      V v_t_24366 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24359_24Right, TAG_StmtExpr, 1, (V[]){v_x_24362}), v_t_24365});
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24366}), v_st_24360});
    }
    default: return heff_nomatch(v_x11_24359);
    }
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam26(V self, V *args) {
  V v_st_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24373 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_st_24372}));
  switch (heff_tag_of(v_x1_24373)) {
  case TAG_MkPair: {
    V v_x11_24374 = heff_field(v_x1_24373, 0);
    V v_st_24375 = heff_field(v_x1_24373, 1);
    V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
    switch (heff_tag_of(v_x11_24374)) {
    case TAG_Left: {
      V v_e_24376 = heff_field(v_x11_24374, 0);
      heff_take_n(v_x11_24374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
    }
    case TAG_Right: {
      V v_x_24377 = heff_field(v_x11_24374, 0);
      V v_ru_24x11_24374_24Right = heff_take_reuse_n(v_x11_24374, 1ULL, 1);
      V v_t_24380;
      switch (heff_tag_of(v_x_24377)) {
      case TAG_At: {
        V v_s_24379 = heff_dup(heff_field(v_x_24377, 1));
        v_t_24380 = v_s_24379;
        break;
      }
      default: heff_nomatch(v_x_24377);
      }
      V v_t_24381 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24374_24Right, TAG_StmtExpr, 1, (V[]){v_x_24377}), v_t_24380});
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24381}), v_st_24375});
    }
    default: return heff_nomatch(v_x11_24374);
    }
  }
  default: return heff_nomatch(v_x1_24373);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam27(V self, V *args) {
  V v_st_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24386}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_MkPair: {
    V v_x11_24388 = heff_field(v_x1_24387, 0);
    V v_st_24389 = heff_field(v_x1_24387, 1);
    V v_ru_24x1_24387_24MkPair = heff_take_reuse_n(v_x1_24387, 3ULL, 2);
    switch (heff_tag_of(v_x11_24388)) {
    case TAG_Left: {
      V v_e_24390 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24390}), v_st_24389});
    }
    case TAG_Right: {
      V v_x_24391 = heff_field(v_x11_24388, 0);
      V v_ru_24x11_24388_24Right = heff_take_reuse_n(v_x11_24388, 1ULL, 1);
      V v_t_24394;
      switch (heff_tag_of(v_x_24391)) {
      case TAG_At: {
        V v_s_24393 = heff_dup(heff_field(v_x_24391, 1));
        v_t_24394 = v_s_24393;
        break;
      }
      default: heff_nomatch(v_x_24391);
      }
      V v_t_24395 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24388_24Right, TAG_StmtExpr, 1, (V[]){v_x_24391}), v_t_24394});
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24395}), v_st_24389});
    }
    default: return heff_nomatch(v_x11_24388);
    }
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam28(V self, V *args) {
  V v_st_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_st_24403}));
  switch (heff_tag_of(v_x1_24404)) {
  case TAG_MkPair: {
    V v_x11_24405 = heff_field(v_x1_24404, 0);
    V v_st_24406 = heff_field(v_x1_24404, 1);
    V v_ru_24x1_24404_24MkPair = heff_take_reuse_n(v_x1_24404, 3ULL, 2);
    switch (heff_tag_of(v_x11_24405)) {
    case TAG_Left: {
      V v_e_24407 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24407}), v_st_24406});
    }
    case TAG_Right: {
      V v_x_24408 = heff_field(v_x11_24405, 0);
      V v_ru_24x11_24405_24Right = heff_take_reuse_n(v_x11_24405, 1ULL, 1);
      V v_t_24411;
      switch (heff_tag_of(v_x_24408)) {
      case TAG_At: {
        V v_s_24410 = heff_dup(heff_field(v_x_24408, 1));
        v_t_24411 = v_s_24410;
        break;
      }
      default: heff_nomatch(v_x_24408);
      }
      V v_t_24412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24405_24Right, TAG_StmtExpr, 1, (V[]){v_x_24408}), v_t_24411});
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24412}), v_st_24406});
    }
    default: return heff_nomatch(v_x11_24405);
    }
  }
  default: return heff_nomatch(v_x1_24404);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam29(V self, V *args) {
  V v_st_24416 = args[0];
  V v_m_24415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24417 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_st_24416}));
  switch (heff_tag_of(v_x1_24417)) {
  case TAG_MkPair: {
    V v_x11_24418 = heff_field(v_x1_24417, 0);
    V v_st_24419 = heff_field(v_x1_24417, 1);
    V v_ru_24x1_24417_24MkPair = heff_take_reuse_n(v_x1_24417, 3ULL, 2);
    switch (heff_tag_of(v_x11_24418)) {
    case TAG_Left: {
      V v_e_24420 = heff_field(v_x11_24418, 0);
      heff_take_n(v_x11_24418, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24420}), v_st_24419});
    }
    case TAG_Right: {
      V v_x_24421 = heff_field(v_x11_24418, 0);
      V v_ru_24x11_24418_24Right = heff_take_reuse_n(v_x11_24418, 1ULL, 1);
      V v_t_24424;
      switch (heff_tag_of(v_x_24421)) {
      case TAG_At: {
        V v_s_24423 = heff_dup(heff_field(v_x_24421, 1));
        v_t_24424 = v_s_24423;
        break;
      }
      default: heff_nomatch(v_x_24421);
      }
      V v_t_24425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24418_24Right, TAG_StmtExpr, 1, (V[]){v_x_24421}), v_t_24424});
      return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24425}), v_st_24419});
    }
    default: return heff_nomatch(v_x11_24418);
    }
  }
  default: return heff_nomatch(v_x1_24417);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam30(V self, V *args) {
  V v_st_24432 = args[0];
  V v_m_24431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24433 = heff_tr(heff_call(v_m_24431, 1, (V[]){v_st_24432}));
  switch (heff_tag_of(v_x1_24433)) {
  case TAG_MkPair: {
    V v_x11_24434 = heff_field(v_x1_24433, 0);
    V v_st_24435 = heff_field(v_x1_24433, 1);
    V v_ru_24x1_24433_24MkPair = heff_take_reuse_n(v_x1_24433, 3ULL, 2);
    switch (heff_tag_of(v_x11_24434)) {
    case TAG_Left: {
      V v_e_24436 = heff_field(v_x11_24434, 0);
      heff_take_n(v_x11_24434, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 2);
      return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24436}), v_st_24435});
    }
    case TAG_Right: {
      V v_x_24437 = heff_field(v_x11_24434, 0);
      V v_ru_24x11_24434_24Right = heff_take_reuse_n(v_x11_24434, 1ULL, 1);
      V v_m_24438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24439 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_st_24435}));
      switch (heff_tag_of(v_x1_24439)) {
      case TAG_MkPair: {
        V v_x11_24440 = heff_field(v_x1_24439, 0);
        V v_st_24441 = heff_field(v_x1_24439, 1);
        V v_ru_24x1_24439_24MkPair = heff_take_reuse_n(v_x1_24439, 3ULL, 2);
        switch (heff_tag_of(v_x11_24440)) {
        case TAG_Left: {
          V v_e_24442 = heff_field(v_x11_24440, 0);
          heff_take_n(v_x11_24440, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 2);
          heff_drop(v_x_24437);
          heff_drop_cell(v_ru_24x11_24434_24Right, 1);
          heff_drop_cell(v_ru_24x1_24439_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24442}), v_st_24441});
        }
        case TAG_Right: {
          V v_x_24443 = heff_field(v_x11_24440, 0);
          heff_take_n(v_x11_24440, 1ULL, 1);
          V v_sc_24444 = ({ V a_0 = heff_take_field(v_st_24441, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 2); r_; });
          V v_t_24447;
          switch (heff_tag_of(v_x_24437)) {
          case TAG_At: {
            V v_s_24446 = heff_dup(heff_field(v_x_24437, 1));
            v_t_24447 = v_s_24446;
            break;
          }
          default: heff_nomatch(v_x_24437);
          }
          V v_t_24448 = heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24434_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24437)}), v_t_24447});
          V v_t_24451;
          switch (heff_tag_of(v_x_24443)) {
          case TAG_At: {
            V v_s_24450 = heff_dup(heff_field(v_x_24443, 1));
            v_t_24451 = v_s_24450;
            break;
          }
          default: heff_nomatch(v_x_24443);
          }
          V v_t_24454;
          switch (heff_tag_of(v_x_24437)) {
          case TAG_At: {
            V v_s_24453 = heff_field(v_x_24437, 1);
            heff_take_n(v_x_24437, 2ULL, 2);
            v_t_24454 = v_s_24453;
            break;
          }
          default: heff_nomatch(v_x_24437);
          }
          V v_t_24455 = ({ V rv_1 = heff_get_n(v_t_24454, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24451, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24443, v_t_24448}), v_t_24455});
          V v_t_24457 = ({ V rv_1 = v_sc_24444; V rr_ = heff_rec_reuse_nf(v_st_24441, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24456}), v_t_24457});
        }
        default: return heff_nomatch(v_x11_24440);
        }
      }
      default: return heff_nomatch(v_x1_24439);
      }
    }
    default: return heff_nomatch(v_x11_24434);
    }
  }
  default: return heff_nomatch(v_x1_24433);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam31(V self, V *args) {
  V v_st_24460 = args[0];
  V v_m_24459 = heff_env(self)[0];
  V v_x_24458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24461 = heff_tr(heff_call(v_m_24459, 1, (V[]){v_st_24460}));
  switch (heff_tag_of(v_x1_24461)) {
  case TAG_MkPair: {
    V v_x11_24462 = heff_field(v_x1_24461, 0);
    V v_st_24463 = heff_field(v_x1_24461, 1);
    V v_ru_24x1_24461_24MkPair = heff_take_reuse_n(v_x1_24461, 3ULL, 2);
    switch (heff_tag_of(v_x11_24462)) {
    case TAG_Left: {
      V v_e_24464 = heff_field(v_x11_24462, 0);
      heff_take_n(v_x11_24462, 1ULL, 1);
      heff_drop_rec(v_x_24458, 9);
      return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24464}), v_st_24463});
    }
    case TAG_Right: {
      V v_x_24465 = heff_field(v_x11_24462, 0);
      V v_ru_24x11_24462_24Right = heff_take_reuse_n(v_x11_24462, 1ULL, 1);
      V v_t_24466 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24458, 3)), heff_take_field(v_x_24458, 4)});
      V v_t_24467 = heff_tag_n(TAG_StmtBind, 3, (V[]){heff_dup(heff_rfield(v_x_24458, 1)), v_t_24466, heff_dup(v_x_24465)});
      V v_t_24470;
      switch (heff_tag_of(v_x_24465)) {
      case TAG_At: {
        V v_s_24469 = heff_field(v_x_24465, 1);
        heff_take_n(v_x_24465, 2ULL, 2);
        v_t_24470 = v_s_24469;
        break;
      }
      default: heff_nomatch(v_x_24465);
      }
      V v_t_24471 = ({ V rv_0 = heff_take_field(v_x_24458, 3); V rr_ = heff_rec_reuse_nf(v_t_24470, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24472 = heff_tag_at_n(v_ru_24x11_24462_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24467, v_t_24471})});
      V v_t_24473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24458, 1, 9), heff_take_field(v_st_24463, 1)});
      V v_t_24474 = ({ V rv_1 = v_t_24473; V rr_ = heff_rec_reuse_nf(v_st_24463, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){v_t_24472, v_t_24474});
    }
    default: return heff_nomatch(v_x11_24462);
    }
  }
  default: return heff_nomatch(v_x1_24461);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam32(V self, V *args) {
  V v_st_24479 = args[0];
  V v_m_24478 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24480 = heff_tr(heff_call(v_m_24478, 1, (V[]){v_st_24479}));
  switch (heff_tag_of(v_x1_24480)) {
  case TAG_MkPair: {
    V v_x11_24481 = heff_field(v_x1_24480, 0);
    V v_st_24482 = heff_field(v_x1_24480, 1);
    V v_ru_24x1_24480_24MkPair = heff_take_reuse_n(v_x1_24480, 3ULL, 2);
    switch (heff_tag_of(v_x11_24481)) {
    case TAG_Left: {
      V v_e_24483 = heff_field(v_x11_24481, 0);
      heff_take_n(v_x11_24481, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24483}), v_st_24482});
    }
    case TAG_Right: {
      V v_x_24484 = heff_field(v_x11_24481, 0);
      V v_ru_24x11_24481_24Right = heff_take_reuse_n(v_x11_24481, 1ULL, 1);
      V v_m_24485 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24486 = heff_tr(heff_call(v_m_24485, 1, (V[]){v_st_24482}));
      switch (heff_tag_of(v_x1_24486)) {
      case TAG_MkPair: {
        V v_x11_24487 = heff_field(v_x1_24486, 0);
        V v_st_24488 = heff_field(v_x1_24486, 1);
        V v_ru_24x1_24486_24MkPair = heff_take_reuse_n(v_x1_24486, 3ULL, 2);
        switch (heff_tag_of(v_x11_24487)) {
        case TAG_Left: {
          V v_e_24489 = heff_field(v_x11_24487, 0);
          heff_take_n(v_x11_24487, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24484);
          heff_drop_cell(v_ru_24x11_24481_24Right, 1);
          heff_drop_cell(v_ru_24x1_24486_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24489}), v_st_24488});
        }
        case TAG_Right: {
          V v_x_24490 = heff_field(v_x11_24487, 0);
          heff_take_n(v_x11_24487, 1ULL, 1);
          V v_sc_24491 = ({ V a_0 = heff_take_field(v_st_24488, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24494;
          switch (heff_tag_of(v_x_24484)) {
          case TAG_At: {
            V v_s_24493 = heff_dup(heff_field(v_x_24484, 1));
            v_t_24494 = v_s_24493;
            break;
          }
          default: heff_nomatch(v_x_24484);
          }
          V v_t_24495 = heff_tag_at_n(v_ru_24x1_24486_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24481_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24484)}), v_t_24494});
          V v_t_24498;
          switch (heff_tag_of(v_x_24490)) {
          case TAG_At: {
            V v_s_24497 = heff_dup(heff_field(v_x_24490, 1));
            v_t_24498 = v_s_24497;
            break;
          }
          default: heff_nomatch(v_x_24490);
          }
          V v_t_24501;
          switch (heff_tag_of(v_x_24484)) {
          case TAG_At: {
            V v_s_24500 = heff_field(v_x_24484, 1);
            heff_take_n(v_x_24484, 2ULL, 2);
            v_t_24501 = v_s_24500;
            break;
          }
          default: heff_nomatch(v_x_24484);
          }
          V v_t_24502 = ({ V rv_1 = heff_get_n(v_t_24501, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24498, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24503 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24490, v_t_24495}), v_t_24502});
          V v_t_24504 = ({ V rv_1 = v_sc_24491; V rr_ = heff_rec_reuse_nf(v_st_24488, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24503}), v_t_24504});
        }
        default: return heff_nomatch(v_x11_24487);
        }
      }
      default: return heff_nomatch(v_x1_24486);
      }
    }
    default: return heff_nomatch(v_x11_24481);
    }
  }
  default: return heff_nomatch(v_x1_24480);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam33(V self, V *args) {
  V v_st_24510 = args[0];
  V v_m_24509 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24511 = heff_tr(heff_call(v_m_24509, 1, (V[]){v_st_24510}));
  switch (heff_tag_of(v_x1_24511)) {
  case TAG_MkPair: {
    V v_x11_24512 = heff_field(v_x1_24511, 0);
    V v_st_24513 = heff_field(v_x1_24511, 1);
    V v_ru_24x1_24511_24MkPair = heff_take_reuse_n(v_x1_24511, 3ULL, 2);
    switch (heff_tag_of(v_x11_24512)) {
    case TAG_Left: {
      V v_e_24514 = heff_field(v_x11_24512, 0);
      heff_take_n(v_x11_24512, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 4);
      return heff_tag_at_n(v_ru_24x1_24511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24514}), v_st_24513});
    }
    case TAG_Right: {
      V v_x_24515 = heff_field(v_x11_24512, 0);
      V v_ru_24x11_24512_24Right = heff_take_reuse_n(v_x11_24512, 1ULL, 1);
      V v_m_24516 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24517 = heff_tr(heff_call(v_m_24516, 1, (V[]){v_st_24513}));
      switch (heff_tag_of(v_x1_24517)) {
      case TAG_MkPair: {
        V v_x11_24518 = heff_field(v_x1_24517, 0);
        V v_st_24519 = heff_field(v_x1_24517, 1);
        V v_ru_24x1_24517_24MkPair = heff_take_reuse_n(v_x1_24517, 3ULL, 2);
        switch (heff_tag_of(v_x11_24518)) {
        case TAG_Left: {
          V v_e_24520 = heff_field(v_x11_24518, 0);
          heff_take_n(v_x11_24518, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 4);
          heff_drop(v_x_24515);
          heff_drop_cell(v_ru_24x11_24512_24Right, 1);
          heff_drop_cell(v_ru_24x1_24517_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24520}), v_st_24519});
        }
        case TAG_Right: {
          V v_x_24521 = heff_field(v_x11_24518, 0);
          heff_take_n(v_x11_24518, 1ULL, 1);
          V v_sc_24522 = ({ V a_0 = heff_take_field(v_st_24519, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 4); r_; });
          V v_t_24525;
          switch (heff_tag_of(v_x_24515)) {
          case TAG_At: {
            V v_s_24524 = heff_dup(heff_field(v_x_24515, 1));
            v_t_24525 = v_s_24524;
            break;
          }
          default: heff_nomatch(v_x_24515);
          }
          V v_t_24526 = heff_tag_at_n(v_ru_24x1_24517_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24512_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24515)}), v_t_24525});
          V v_t_24529;
          switch (heff_tag_of(v_x_24521)) {
          case TAG_At: {
            V v_s_24528 = heff_dup(heff_field(v_x_24521, 1));
            v_t_24529 = v_s_24528;
            break;
          }
          default: heff_nomatch(v_x_24521);
          }
          V v_t_24532;
          switch (heff_tag_of(v_x_24515)) {
          case TAG_At: {
            V v_s_24531 = heff_field(v_x_24515, 1);
            heff_take_n(v_x_24515, 2ULL, 2);
            v_t_24532 = v_s_24531;
            break;
          }
          default: heff_nomatch(v_x_24515);
          }
          V v_t_24533 = ({ V rv_1 = heff_get_n(v_t_24532, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24529, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24534 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24521, v_t_24526}), v_t_24533});
          V v_t_24535 = ({ V rv_1 = v_sc_24522; V rr_ = heff_rec_reuse_nf(v_st_24519, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24534}), v_t_24535});
        }
        default: return heff_nomatch(v_x11_24518);
        }
      }
      default: return heff_nomatch(v_x1_24517);
      }
    }
    default: return heff_nomatch(v_x11_24512);
    }
  }
  default: return heff_nomatch(v_x1_24511);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam34(V self, V *args) {
  V v_st_24540 = args[0];
  V v_m_24539 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24541 = heff_tr(heff_call(v_m_24539, 1, (V[]){v_st_24540}));
  switch (heff_tag_of(v_x1_24541)) {
  case TAG_MkPair: {
    V v_x11_24542 = heff_field(v_x1_24541, 0);
    V v_st_24543 = heff_field(v_x1_24541, 1);
    V v_ru_24x1_24541_24MkPair = heff_take_reuse_n(v_x1_24541, 3ULL, 2);
    switch (heff_tag_of(v_x11_24542)) {
    case TAG_Left: {
      V v_e_24544 = heff_field(v_x11_24542, 0);
      heff_take_n(v_x11_24542, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24544}), v_st_24543});
    }
    case TAG_Right: {
      V v_x_24545 = heff_field(v_x11_24542, 0);
      V v_ru_24x11_24542_24Right = heff_take_reuse_n(v_x11_24542, 1ULL, 1);
      V v_m_24546 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24547 = heff_tr(heff_call(v_m_24546, 1, (V[]){v_st_24543}));
      switch (heff_tag_of(v_x1_24547)) {
      case TAG_MkPair: {
        V v_x11_24548 = heff_field(v_x1_24547, 0);
        V v_st_24549 = heff_field(v_x1_24547, 1);
        V v_ru_24x1_24547_24MkPair = heff_take_reuse_n(v_x1_24547, 3ULL, 2);
        switch (heff_tag_of(v_x11_24548)) {
        case TAG_Left: {
          V v_e_24550 = heff_field(v_x11_24548, 0);
          heff_take_n(v_x11_24548, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24545);
          heff_drop_cell(v_ru_24x11_24542_24Right, 1);
          heff_drop_cell(v_ru_24x1_24547_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24550}), v_st_24549});
        }
        case TAG_Right: {
          V v_x_24551 = heff_field(v_x11_24548, 0);
          heff_take_n(v_x11_24548, 1ULL, 1);
          V v_sc_24552 = ({ V a_0 = heff_take_field(v_st_24549, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24555;
          switch (heff_tag_of(v_x_24545)) {
          case TAG_At: {
            V v_s_24554 = heff_dup(heff_field(v_x_24545, 1));
            v_t_24555 = v_s_24554;
            break;
          }
          default: heff_nomatch(v_x_24545);
          }
          V v_t_24556 = heff_tag_at_n(v_ru_24x1_24547_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24542_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24545)}), v_t_24555});
          V v_t_24559;
          switch (heff_tag_of(v_x_24551)) {
          case TAG_At: {
            V v_s_24558 = heff_dup(heff_field(v_x_24551, 1));
            v_t_24559 = v_s_24558;
            break;
          }
          default: heff_nomatch(v_x_24551);
          }
          V v_t_24562;
          switch (heff_tag_of(v_x_24545)) {
          case TAG_At: {
            V v_s_24561 = heff_field(v_x_24545, 1);
            heff_take_n(v_x_24545, 2ULL, 2);
            v_t_24562 = v_s_24561;
            break;
          }
          default: heff_nomatch(v_x_24545);
          }
          V v_t_24563 = ({ V rv_1 = heff_get_n(v_t_24562, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24564 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24551, v_t_24556}), v_t_24563});
          V v_t_24565 = ({ V rv_1 = v_sc_24552; V rr_ = heff_rec_reuse_nf(v_st_24549, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24564}), v_t_24565});
        }
        default: return heff_nomatch(v_x11_24548);
        }
      }
      default: return heff_nomatch(v_x1_24547);
      }
    }
    default: return heff_nomatch(v_x11_24542);
    }
  }
  default: return heff_nomatch(v_x1_24541);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam35(V self, V *args) {
  V v_st_24571 = args[0];
  V v_m_24570 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24572 = heff_tr(heff_call(v_m_24570, 1, (V[]){v_st_24571}));
  switch (heff_tag_of(v_x1_24572)) {
  case TAG_MkPair: {
    V v_x11_24573 = heff_field(v_x1_24572, 0);
    V v_st_24574 = heff_field(v_x1_24572, 1);
    V v_ru_24x1_24572_24MkPair = heff_take_reuse_n(v_x1_24572, 3ULL, 2);
    switch (heff_tag_of(v_x11_24573)) {
    case TAG_Left: {
      V v_e_24575 = heff_field(v_x11_24573, 0);
      heff_take_n(v_x11_24573, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 4);
      return heff_tag_at_n(v_ru_24x1_24572_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24575}), v_st_24574});
    }
    case TAG_Right: {
      V v_x_24576 = heff_field(v_x11_24573, 0);
      V v_ru_24x11_24573_24Right = heff_take_reuse_n(v_x11_24573, 1ULL, 1);
      V v_m_24577 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24578 = heff_tr(heff_call(v_m_24577, 1, (V[]){v_st_24574}));
      switch (heff_tag_of(v_x1_24578)) {
      case TAG_MkPair: {
        V v_x11_24579 = heff_field(v_x1_24578, 0);
        V v_st_24580 = heff_field(v_x1_24578, 1);
        V v_ru_24x1_24578_24MkPair = heff_take_reuse_n(v_x1_24578, 3ULL, 2);
        switch (heff_tag_of(v_x11_24579)) {
        case TAG_Left: {
          V v_e_24581 = heff_field(v_x11_24579, 0);
          heff_take_n(v_x11_24579, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 4);
          heff_drop(v_x_24576);
          heff_drop_cell(v_ru_24x11_24573_24Right, 1);
          heff_drop_cell(v_ru_24x1_24578_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24572_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24581}), v_st_24580});
        }
        case TAG_Right: {
          V v_x_24582 = heff_field(v_x11_24579, 0);
          heff_take_n(v_x11_24579, 1ULL, 1);
          V v_sc_24583 = ({ V a_0 = heff_take_field(v_st_24580, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 4); r_; });
          V v_t_24586;
          switch (heff_tag_of(v_x_24576)) {
          case TAG_At: {
            V v_s_24585 = heff_dup(heff_field(v_x_24576, 1));
            v_t_24586 = v_s_24585;
            break;
          }
          default: heff_nomatch(v_x_24576);
          }
          V v_t_24587 = heff_tag_at_n(v_ru_24x1_24578_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24573_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24576)}), v_t_24586});
          V v_t_24590;
          switch (heff_tag_of(v_x_24582)) {
          case TAG_At: {
            V v_s_24589 = heff_dup(heff_field(v_x_24582, 1));
            v_t_24590 = v_s_24589;
            break;
          }
          default: heff_nomatch(v_x_24582);
          }
          V v_t_24593;
          switch (heff_tag_of(v_x_24576)) {
          case TAG_At: {
            V v_s_24592 = heff_field(v_x_24576, 1);
            heff_take_n(v_x_24576, 2ULL, 2);
            v_t_24593 = v_s_24592;
            break;
          }
          default: heff_nomatch(v_x_24576);
          }
          V v_t_24594 = ({ V rv_1 = heff_get_n(v_t_24593, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24590, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24595 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24582, v_t_24587}), v_t_24594});
          V v_t_24596 = ({ V rv_1 = v_sc_24583; V rr_ = heff_rec_reuse_nf(v_st_24580, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24572_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24595}), v_t_24596});
        }
        default: return heff_nomatch(v_x11_24579);
        }
      }
      default: return heff_nomatch(v_x1_24578);
      }
    }
    default: return heff_nomatch(v_x11_24573);
    }
  }
  default: return heff_nomatch(v_x1_24572);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam36(V self, V *args) {
  V v_st_24601 = args[0];
  V v_m_24600 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24602 = heff_tr(heff_call(v_m_24600, 1, (V[]){v_st_24601}));
  switch (heff_tag_of(v_x1_24602)) {
  case TAG_MkPair: {
    V v_x11_24603 = heff_field(v_x1_24602, 0);
    V v_st_24604 = heff_field(v_x1_24602, 1);
    V v_ru_24x1_24602_24MkPair = heff_take_reuse_n(v_x1_24602, 3ULL, 2);
    switch (heff_tag_of(v_x11_24603)) {
    case TAG_Left: {
      V v_e_24605 = heff_field(v_x11_24603, 0);
      heff_take_n(v_x11_24603, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24605}), v_st_24604});
    }
    case TAG_Right: {
      V v_x_24606 = heff_field(v_x11_24603, 0);
      V v_ru_24x11_24603_24Right = heff_take_reuse_n(v_x11_24603, 1ULL, 1);
      V v_m_24607 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24608 = heff_tr(heff_call(v_m_24607, 1, (V[]){v_st_24604}));
      switch (heff_tag_of(v_x1_24608)) {
      case TAG_MkPair: {
        V v_x11_24609 = heff_field(v_x1_24608, 0);
        V v_st_24610 = heff_field(v_x1_24608, 1);
        V v_ru_24x1_24608_24MkPair = heff_take_reuse_n(v_x1_24608, 3ULL, 2);
        switch (heff_tag_of(v_x11_24609)) {
        case TAG_Left: {
          V v_e_24611 = heff_field(v_x11_24609, 0);
          heff_take_n(v_x11_24609, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24606);
          heff_drop_cell(v_ru_24x11_24603_24Right, 1);
          heff_drop_cell(v_ru_24x1_24608_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24611}), v_st_24610});
        }
        case TAG_Right: {
          V v_x_24612 = heff_field(v_x11_24609, 0);
          heff_take_n(v_x11_24609, 1ULL, 1);
          V v_sc_24613 = ({ V a_0 = heff_take_field(v_st_24610, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24616;
          switch (heff_tag_of(v_x_24606)) {
          case TAG_At: {
            V v_s_24615 = heff_dup(heff_field(v_x_24606, 1));
            v_t_24616 = v_s_24615;
            break;
          }
          default: heff_nomatch(v_x_24606);
          }
          V v_t_24617 = heff_tag_at_n(v_ru_24x1_24608_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24603_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24606)}), v_t_24616});
          V v_t_24620;
          switch (heff_tag_of(v_x_24612)) {
          case TAG_At: {
            V v_s_24619 = heff_dup(heff_field(v_x_24612, 1));
            v_t_24620 = v_s_24619;
            break;
          }
          default: heff_nomatch(v_x_24612);
          }
          V v_t_24623;
          switch (heff_tag_of(v_x_24606)) {
          case TAG_At: {
            V v_s_24622 = heff_field(v_x_24606, 1);
            heff_take_n(v_x_24606, 2ULL, 2);
            v_t_24623 = v_s_24622;
            break;
          }
          default: heff_nomatch(v_x_24606);
          }
          V v_t_24624 = ({ V rv_1 = heff_get_n(v_t_24623, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24620, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24625 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24612, v_t_24617}), v_t_24624});
          V v_t_24626 = ({ V rv_1 = v_sc_24613; V rr_ = heff_rec_reuse_nf(v_st_24610, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24625}), v_t_24626});
        }
        default: return heff_nomatch(v_x11_24609);
        }
      }
      default: return heff_nomatch(v_x1_24608);
      }
    }
    default: return heff_nomatch(v_x11_24603);
    }
  }
  default: return heff_nomatch(v_x1_24602);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam37(V self, V *args) {
  V v_st_24631 = args[0];
  V v_m_24630 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24632 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_st_24631}));
  switch (heff_tag_of(v_x1_24632)) {
  case TAG_MkPair: {
    V v_x11_24633 = heff_field(v_x1_24632, 0);
    V v_st_24634 = heff_field(v_x1_24632, 1);
    V v_ru_24x1_24632_24MkPair = heff_take_reuse_n(v_x1_24632, 3ULL, 2);
    switch (heff_tag_of(v_x11_24633)) {
    case TAG_Left: {
      V v_e_24635 = heff_field(v_x11_24633, 0);
      heff_take_n(v_x11_24633, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24635}), v_st_24634});
    }
    case TAG_Right: {
      V v_x_24636 = heff_field(v_x11_24633, 0);
      V v_ru_24x11_24633_24Right = heff_take_reuse_n(v_x11_24633, 1ULL, 1);
      V v_m_24637 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24638 = heff_tr(heff_call(v_m_24637, 1, (V[]){v_st_24634}));
      switch (heff_tag_of(v_x1_24638)) {
      case TAG_MkPair: {
        V v_x11_24639 = heff_field(v_x1_24638, 0);
        V v_st_24640 = heff_field(v_x1_24638, 1);
        V v_ru_24x1_24638_24MkPair = heff_take_reuse_n(v_x1_24638, 3ULL, 2);
        switch (heff_tag_of(v_x11_24639)) {
        case TAG_Left: {
          V v_e_24641 = heff_field(v_x11_24639, 0);
          heff_take_n(v_x11_24639, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24636);
          heff_drop_cell(v_ru_24x11_24633_24Right, 1);
          heff_drop_cell(v_ru_24x1_24638_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24641}), v_st_24640});
        }
        case TAG_Right: {
          V v_x_24642 = heff_field(v_x11_24639, 0);
          heff_take_n(v_x11_24639, 1ULL, 1);
          V v_sc_24643 = ({ V a_0 = heff_take_field(v_st_24640, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24646;
          switch (heff_tag_of(v_x_24636)) {
          case TAG_At: {
            V v_s_24645 = heff_dup(heff_field(v_x_24636, 1));
            v_t_24646 = v_s_24645;
            break;
          }
          default: heff_nomatch(v_x_24636);
          }
          V v_t_24647 = heff_tag_at_n(v_ru_24x1_24638_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24633_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24636)}), v_t_24646});
          V v_t_24650;
          switch (heff_tag_of(v_x_24642)) {
          case TAG_At: {
            V v_s_24649 = heff_dup(heff_field(v_x_24642, 1));
            v_t_24650 = v_s_24649;
            break;
          }
          default: heff_nomatch(v_x_24642);
          }
          V v_t_24653;
          switch (heff_tag_of(v_x_24636)) {
          case TAG_At: {
            V v_s_24652 = heff_field(v_x_24636, 1);
            heff_take_n(v_x_24636, 2ULL, 2);
            v_t_24653 = v_s_24652;
            break;
          }
          default: heff_nomatch(v_x_24636);
          }
          V v_t_24654 = ({ V rv_1 = heff_get_n(v_t_24653, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24650, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24655 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24642, v_t_24647}), v_t_24654});
          V v_t_24656 = ({ V rv_1 = v_sc_24643; V rr_ = heff_rec_reuse_nf(v_st_24640, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24655}), v_t_24656});
        }
        default: return heff_nomatch(v_x11_24639);
        }
      }
      default: return heff_nomatch(v_x1_24638);
      }
    }
    default: return heff_nomatch(v_x11_24633);
    }
  }
  default: return heff_nomatch(v_x1_24632);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam38(V self, V *args) {
  V v_st_24661 = args[0];
  V v_m_24660 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x21_24426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24662 = heff_tr(heff_call(v_m_24660, 1, (V[]){v_st_24661}));
  switch (heff_tag_of(v_x1_24662)) {
  case TAG_MkPair: {
    V v_x11_24663 = heff_field(v_x1_24662, 0);
    V v_st_24664 = heff_field(v_x1_24662, 1);
    V v_ru_24x1_24662_24MkPair = heff_take_reuse_n(v_x1_24662, 3ULL, 2);
    switch (heff_tag_of(v_x11_24663)) {
    case TAG_Left: {
      V v_e_24665 = heff_field(v_x11_24663, 0);
      heff_take_n(v_x11_24663, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop_tag(v_x21_24426, 3);
      return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24665}), v_st_24664});
    }
    case TAG_Right: {
      V v_x_24666 = heff_field(v_x11_24663, 0);
      V v_ru_24x11_24663_24Right = heff_take_reuse_n(v_x11_24663, 1ULL, 1);
      V v_m_24667 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){heff_dup(v_x21_24426)}));
      V v_x1_24668 = heff_tr(heff_call(v_m_24667, 1, (V[]){v_st_24664}));
      switch (heff_tag_of(v_x1_24668)) {
      case TAG_MkPair: {
        V v_x11_24669 = heff_field(v_x1_24668, 0);
        V v_st_24670 = heff_field(v_x1_24668, 1);
        V v_ru_24x1_24668_24MkPair = heff_take_reuse_n(v_x1_24668, 3ULL, 2);
        switch (heff_tag_of(v_x11_24669)) {
        case TAG_Left: {
          V v_e_24671 = heff_field(v_x11_24669, 0);
          heff_take_n(v_x11_24669, 1ULL, 1);
          heff_drop_tag(v_x21_24426, 3);
          heff_drop(v_x_24666);
          heff_drop_cell(v_ru_24x11_24663_24Right, 1);
          heff_drop_cell(v_ru_24x1_24668_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24671}), v_st_24670});
        }
        case TAG_Right: {
          V v_x_24672 = heff_field(v_x11_24669, 0);
          heff_take_n(v_x11_24669, 1ULL, 1);
          V v_sc_24673 = ({ V a_0 = heff_take_field(v_st_24670, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_x21_24426; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_x21_24426, 3); r_; });
          V v_t_24676;
          switch (heff_tag_of(v_x_24666)) {
          case TAG_At: {
            V v_s_24675 = heff_dup(heff_field(v_x_24666, 1));
            v_t_24676 = v_s_24675;
            break;
          }
          default: heff_nomatch(v_x_24666);
          }
          V v_t_24677 = heff_tag_at_n(v_ru_24x1_24668_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24663_24Right, TAG_ENest, 1, (V[]){heff_dup(v_x_24666)}), v_t_24676});
          V v_t_24680;
          switch (heff_tag_of(v_x_24672)) {
          case TAG_At: {
            V v_s_24679 = heff_dup(heff_field(v_x_24672, 1));
            v_t_24680 = v_s_24679;
            break;
          }
          default: heff_nomatch(v_x_24672);
          }
          V v_t_24683;
          switch (heff_tag_of(v_x_24666)) {
          case TAG_At: {
            V v_s_24682 = heff_field(v_x_24666, 1);
            heff_take_n(v_x_24666, 2ULL, 2);
            v_t_24683 = v_s_24682;
            break;
          }
          default: heff_nomatch(v_x_24666);
          }
          V v_t_24684 = ({ V rv_1 = heff_get_n(v_t_24683, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24680, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24685 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24672, v_t_24677}), v_t_24684});
          V v_t_24686 = ({ V rv_1 = v_sc_24673; V rr_ = heff_rec_reuse_nf(v_st_24670, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24685}), v_t_24686});
        }
        default: return heff_nomatch(v_x11_24669);
        }
      }
      default: return heff_nomatch(v_x1_24668);
      }
    }
    default: return heff_nomatch(v_x11_24663);
    }
  }
  default: return heff_nomatch(v_x1_24662);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam39(V self, V *args) {
  V v_st_24694 = args[0];
  V v_m_24693 = heff_env(self)[0];
  V v_p_24688 = heff_env(self)[1];
  V v_e_24691 = heff_env(self)[2];
  V v_kw_24687 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24695 = heff_tr(heff_call(v_m_24693, 1, (V[]){v_st_24694}));
  switch (heff_tag_of(v_x1_24695)) {
  case TAG_MkPair: {
    V v_x11_24696 = heff_field(v_x1_24695, 0);
    V v_st_24697 = heff_field(v_x1_24695, 1);
    V v_ru_24x1_24695_24MkPair = heff_take_reuse_n(v_x1_24695, 3ULL, 2);
    switch (heff_tag_of(v_x11_24696)) {
    case TAG_Left: {
      V v_e_24698 = heff_field(v_x11_24696, 0);
      heff_take_n(v_x11_24696, 1ULL, 1);
      heff_drop(v_p_24688);
      heff_drop(v_e_24691);
      heff_drop_rec(v_kw_24687, 9);
      return heff_tag_at_n(v_ru_24x1_24695_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24698}), v_st_24697});
    }
    case TAG_Right: {
      V v_x_24699 = heff_field(v_x11_24696, 0);
      heff_take_n(v_x11_24696, 1ULL, 1);
      V v_sc_24700 = ({ V a_0 = heff_take_field(v_st_24697, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24688; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24688); r_; });
      V v_t_24703;
      switch (heff_tag_of(v_x_24699)) {
      case TAG_MkPair: {
        V v_x_24701 = heff_dup(heff_field(v_x_24699, 0));
        v_t_24703 = v_x_24701;
        break;
      }
      default: heff_nomatch(v_x_24699);
      }
      V v_t_24706;
      switch (heff_tag_of(v_x_24699)) {
      case TAG_MkPair: {
        V v_y_24705 = heff_field(v_x_24699, 1);
        heff_take_n(v_x_24699, 2ULL, 2);
        v_t_24706 = v_y_24705;
        break;
      }
      default: heff_nomatch(v_x_24699);
      }
      V v_t_24707 = (g_heff_2esyntax_2ecst_2elastE(v_e_24691));
      V v_e_24708 = heff_get_n(v_t_24707, 4, 9);
      V v_t_24709 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24687, 3, 9), v_e_24708});
      V v_x_24710 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_t_24703, v_t_24706}), v_t_24709});
      V v_t_24711 = ({ V rv_1 = v_sc_24700; V rr_ = heff_rec_reuse_nf(v_st_24697, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24695_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24710}), v_t_24711});
    }
    default: return heff_nomatch(v_x11_24696);
    }
  }
  default: return heff_nomatch(v_x1_24695);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam40(V self, V *args) {
  V v_st_24714 = args[0];
  V v_m_24713 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24715 = heff_tr(heff_call(v_m_24713, 1, (V[]){v_st_24714}));
  switch (heff_tag_of(v_x1_24715)) {
  case TAG_MkPair: {
    V v_x11_24716 = heff_field(v_x1_24715, 0);
    V v_st_24717 = heff_field(v_x1_24715, 1);
    V v_ru_24x1_24715_24MkPair = heff_take_reuse_n(v_x1_24715, 3ULL, 2);
    switch (heff_tag_of(v_x11_24716)) {
    case TAG_Left: {
      V v_e_24718 = heff_field(v_x11_24716, 0);
      heff_take_n(v_x11_24716, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24715_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24718}), v_st_24717});
    }
    case TAG_Right: {
      V v_x_24719 = heff_field(v_x11_24716, 0);
      V v_ru_24x11_24716_24Right = heff_take_reuse_n(v_x11_24716, 1ULL, 1);
      V v_t_24722;
      switch (heff_tag_of(v_x_24719)) {
      case TAG_At: {
        V v_s_24721 = heff_dup(heff_field(v_x_24719, 1));
        v_t_24722 = v_s_24721;
        break;
      }
      default: heff_nomatch(v_x_24719);
      }
      V v_t_24723 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24716_24Right, TAG_StmtExpr, 1, (V[]){v_x_24719}), v_t_24722});
      return heff_tag_at_n(v_ru_24x1_24715_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24723}), v_st_24717});
    }
    default: return heff_nomatch(v_x11_24716);
    }
  }
  default: return heff_nomatch(v_x1_24715);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam42(V self, V *args) {
  V v_m_24738 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24738));
}
V g_heff_2esyntax_2esurface_2estmtL_lam41(V self, V *args) {
  V v_st_24732 = args[0];
  V v_m_24731 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_ss_24730 = heff_env(self)[2];
  V v_p_24725 = heff_env(self)[3];
  V v_x2_241 = heff_env(self)[4];
  V v_kw_24724 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_24733 = heff_tr(heff_call(v_m_24731, 1, (V[]){v_st_24732}));
  switch (heff_tag_of(v_x1_24733)) {
  case TAG_MkPair: {
    V v_x11_24734 = heff_field(v_x1_24733, 0);
    V v_st_24735 = heff_field(v_x1_24733, 1);
    V v_ru_24x1_24733_24MkPair = heff_take_reuse_n(v_x1_24733, 3ULL, 2);
    switch (heff_tag_of(v_x11_24734)) {
    case TAG_Left: {
      V v_e_24736 = heff_field(v_x11_24734, 0);
      heff_take_n(v_x11_24734, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_ss_24730);
      heff_drop(v_p_24725);
      heff_drop_tag(v_x2_241, 7);
      heff_drop_rec(v_kw_24724, 9);
      return heff_tag_at_n(v_ru_24x1_24733_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24736}), v_st_24735});
    }
    case TAG_Right: {
      V v_x_24737 = heff_field(v_x11_24734, 0);
      heff_take_n(v_x11_24734, 1ULL, 1);
      HeffT2 v_t_24739 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2estmtL_lam42, 1, 1, (V[]){v_r_240}), v_ss_24730, v_st_24735));
      {
        V v_field_24740 = v_t_24739.f[0];
        V v_field_24741 = v_t_24739.f[1];
        V v_x11_24742 = v_field_24740;
        V v_st_24743 = v_field_24741;
        switch (heff_tag_of(v_x11_24742)) {
        case TAG_Left: {
          V v_e_24744 = heff_field(v_x11_24742, 0);
          heff_take_n(v_x11_24742, 1ULL, 1);
          heff_drop(v_p_24725);
          heff_drop_tag(v_x2_241, 7);
          heff_drop_rec(v_kw_24724, 9);
          heff_drop(v_x_24737);
          return heff_tag_at_n(v_ru_24x1_24733_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24744}), v_st_24743});
        }
        case TAG_Right: {
          V v_x_24745 = heff_field(v_x11_24742, 0);
          heff_take_n(v_x11_24742, 1ULL, 1);
          V v_sc_24746 = ({ V a_0 = heff_take_field(v_st_24743, 1); V b_1 = NTAG(TAG_Nil); V a_2 = v_p_24725; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_p_24725); r_; });
          V v_t_24749;
          switch (heff_tag_of(v_x_24737)) {
          case TAG_MkPair: {
            V v_x_24747 = heff_dup(heff_field(v_x_24737, 0));
            v_t_24749 = v_x_24747;
            break;
          }
          default: heff_nomatch(v_x_24737);
          }
          V v_t_24752;
          switch (heff_tag_of(v_x_24737)) {
          case TAG_MkPair: {
            V v_y_24751 = heff_field(v_x_24737, 1);
            heff_take_n(v_x_24737, 2ULL, 2);
            v_t_24752 = v_y_24751;
            break;
          }
          default: heff_nomatch(v_x_24737);
          }
          V v_t_24753 = (g_heff_2esyntax_2ecst_2elastE(v_x2_241));
          V v_e_24754 = heff_get_n(v_t_24753, 4, 9);
          V v_t_24755 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24724, 3, 9), v_e_24754});
          V v_x_24756 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_t_24749, v_t_24752, v_x_24745}), v_t_24755});
          V v_t_24757 = ({ V rv_1 = v_sc_24746; V rr_ = heff_rec_reuse_nf(v_st_24743, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_24733_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24756}), v_t_24757});
        }
        default: return heff_nomatch(v_x11_24742);
        }
      }
    }
    default: return heff_nomatch(v_x11_24734);
    }
  }
  default: return heff_nomatch(v_x1_24733);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam43(V self, V *args) {
  V v_st_24765 = args[0];
  V v_m_24764 = heff_env(self)[0];
  V v_x_24760 = heff_env(self)[1];
  V v_e_24763 = heff_env(self)[2];
  V v_kw_24758 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24766 = heff_tr(heff_call(v_m_24764, 1, (V[]){v_st_24765}));
  switch (heff_tag_of(v_x1_24766)) {
  case TAG_MkPair: {
    V v_x11_24767 = heff_field(v_x1_24766, 0);
    V v_st_24768 = heff_field(v_x1_24766, 1);
    V v_ru_24x1_24766_24MkPair = heff_take_reuse_n(v_x1_24766, 3ULL, 2);
    switch (heff_tag_of(v_x11_24767)) {
    case TAG_Left: {
      V v_e_24769 = heff_field(v_x11_24767, 0);
      heff_take_n(v_x11_24767, 1ULL, 1);
      heff_drop_rec(v_x_24760, 9);
      heff_drop(v_e_24763);
      heff_drop_rec(v_kw_24758, 9);
      return heff_tag_at_n(v_ru_24x1_24766_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24769}), v_st_24768});
    }
    case TAG_Right: {
      V v_x_24770 = heff_field(v_x11_24767, 0);
      heff_take_n(v_x11_24767, 1ULL, 1);
      V v_t_24771 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24760, 3), heff_take_field(v_x_24760, 4)});
      V v_t_24774;
      switch (heff_tag_of(v_x_24770)) {
      case TAG_MkPair: {
        V v_y_24773 = heff_field(v_x_24770, 1);
        heff_take_n(v_x_24770, 2ULL, 2);
        v_t_24774 = v_y_24773;
        break;
      }
      default: heff_nomatch(v_x_24770);
      }
      V v_t_24775 = heff_tag_n(TAG_StmtLetMut, 3, (V[]){heff_dup(heff_rfield(v_x_24760, 1)), v_t_24771, v_t_24774});
      V v_t_24776 = (g_heff_2esyntax_2ecst_2elastE(v_e_24763));
      V v_e_24777 = heff_get_n(v_t_24776, 4, 9);
      V v_t_24778 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24758, 3, 9), v_e_24777});
      V v_x_24779 = heff_tag_n(TAG_At, 2, (V[]){v_t_24775, v_t_24778});
      V v_t_24780 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_24760, 1, 9), heff_take_field(v_st_24768, 1)});
      V v_t_24781 = ({ V rv_1 = v_t_24780; V rr_ = heff_rec_reuse_nf(v_st_24768, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_24766_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24779}), v_t_24781});
    }
    default: return heff_nomatch(v_x11_24767);
    }
  }
  default: return heff_nomatch(v_x1_24766);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam44(V self, V *args) {
  V v_st_24786 = args[0];
  V v_m_24785 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24787 = heff_tr(heff_call(v_m_24785, 1, (V[]){v_st_24786}));
  switch (heff_tag_of(v_x1_24787)) {
  case TAG_MkPair: {
    V v_x11_24788 = heff_field(v_x1_24787, 0);
    V v_st_24789 = heff_field(v_x1_24787, 1);
    V v_ru_24x1_24787_24MkPair = heff_take_reuse_n(v_x1_24787, 3ULL, 2);
    switch (heff_tag_of(v_x11_24788)) {
    case TAG_Left: {
      V v_e_24790 = heff_field(v_x11_24788, 0);
      heff_take_n(v_x11_24788, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24787_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24790}), v_st_24789});
    }
    case TAG_Right: {
      V v_x_24791 = heff_field(v_x11_24788, 0);
      V v_ru_24x11_24788_24Right = heff_take_reuse_n(v_x11_24788, 1ULL, 1);
      V v_t_24794;
      switch (heff_tag_of(v_x_24791)) {
      case TAG_At: {
        V v_s_24793 = heff_dup(heff_field(v_x_24791, 1));
        v_t_24794 = v_s_24793;
        break;
      }
      default: heff_nomatch(v_x_24791);
      }
      V v_t_24795 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24788_24Right, TAG_StmtExpr, 1, (V[]){v_x_24791}), v_t_24794});
      return heff_tag_at_n(v_ru_24x1_24787_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24795}), v_st_24789});
    }
    default: return heff_nomatch(v_x11_24788);
    }
  }
  default: return heff_nomatch(v_x1_24787);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam45(V self, V *args) {
  V v_st_24801 = args[0];
  V v_m_24800 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24802 = heff_tr(heff_call(v_m_24800, 1, (V[]){v_st_24801}));
  switch (heff_tag_of(v_x1_24802)) {
  case TAG_MkPair: {
    V v_x11_24803 = heff_field(v_x1_24802, 0);
    V v_st_24804 = heff_field(v_x1_24802, 1);
    V v_ru_24x1_24802_24MkPair = heff_take_reuse_n(v_x1_24802, 3ULL, 2);
    switch (heff_tag_of(v_x11_24803)) {
    case TAG_Left: {
      V v_e_24805 = heff_field(v_x11_24803, 0);
      heff_take_n(v_x11_24803, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24805}), v_st_24804});
    }
    case TAG_Right: {
      V v_x_24806 = heff_field(v_x11_24803, 0);
      V v_ru_24x11_24803_24Right = heff_take_reuse_n(v_x11_24803, 1ULL, 1);
      V v_t_24809;
      switch (heff_tag_of(v_x_24806)) {
      case TAG_At: {
        V v_s_24808 = heff_dup(heff_field(v_x_24806, 1));
        v_t_24809 = v_s_24808;
        break;
      }
      default: heff_nomatch(v_x_24806);
      }
      V v_t_24810 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24803_24Right, TAG_StmtExpr, 1, (V[]){v_x_24806}), v_t_24809});
      return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24810}), v_st_24804});
    }
    default: return heff_nomatch(v_x11_24803);
    }
  }
  default: return heff_nomatch(v_x1_24802);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam46(V self, V *args) {
  V v_st_24818 = args[0];
  V v_m_24817 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24819 = heff_tr(heff_call(v_m_24817, 1, (V[]){v_st_24818}));
  switch (heff_tag_of(v_x1_24819)) {
  case TAG_MkPair: {
    V v_x11_24820 = heff_field(v_x1_24819, 0);
    V v_st_24821 = heff_field(v_x1_24819, 1);
    V v_ru_24x1_24819_24MkPair = heff_take_reuse_n(v_x1_24819, 3ULL, 2);
    switch (heff_tag_of(v_x11_24820)) {
    case TAG_Left: {
      V v_e_24822 = heff_field(v_x11_24820, 0);
      heff_take_n(v_x11_24820, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24819_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24822}), v_st_24821});
    }
    case TAG_Right: {
      V v_x_24823 = heff_field(v_x11_24820, 0);
      V v_ru_24x11_24820_24Right = heff_take_reuse_n(v_x11_24820, 1ULL, 1);
      V v_t_24826;
      switch (heff_tag_of(v_x_24823)) {
      case TAG_At: {
        V v_s_24825 = heff_dup(heff_field(v_x_24823, 1));
        v_t_24826 = v_s_24825;
        break;
      }
      default: heff_nomatch(v_x_24823);
      }
      V v_t_24827 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24820_24Right, TAG_StmtExpr, 1, (V[]){v_x_24823}), v_t_24826});
      return heff_tag_at_n(v_ru_24x1_24819_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24827}), v_st_24821});
    }
    default: return heff_nomatch(v_x11_24820);
    }
  }
  default: return heff_nomatch(v_x1_24819);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam47(V self, V *args) {
  V v_st_24830 = args[0];
  V v_m_24829 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24831 = heff_tr(heff_call(v_m_24829, 1, (V[]){v_st_24830}));
  switch (heff_tag_of(v_x1_24831)) {
  case TAG_MkPair: {
    V v_x11_24832 = heff_field(v_x1_24831, 0);
    V v_st_24833 = heff_field(v_x1_24831, 1);
    V v_ru_24x1_24831_24MkPair = heff_take_reuse_n(v_x1_24831, 3ULL, 2);
    switch (heff_tag_of(v_x11_24832)) {
    case TAG_Left: {
      V v_e_24834 = heff_field(v_x11_24832, 0);
      heff_take_n(v_x11_24832, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24831_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24834}), v_st_24833});
    }
    case TAG_Right: {
      V v_x_24835 = heff_field(v_x11_24832, 0);
      V v_ru_24x11_24832_24Right = heff_take_reuse_n(v_x11_24832, 1ULL, 1);
      V v_t_24838;
      switch (heff_tag_of(v_x_24835)) {
      case TAG_At: {
        V v_s_24837 = heff_dup(heff_field(v_x_24835, 1));
        v_t_24838 = v_s_24837;
        break;
      }
      default: heff_nomatch(v_x_24835);
      }
      V v_t_24839 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24832_24Right, TAG_StmtExpr, 1, (V[]){v_x_24835}), v_t_24838});
      return heff_tag_at_n(v_ru_24x1_24831_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24839}), v_st_24833});
    }
    default: return heff_nomatch(v_x11_24832);
    }
  }
  default: return heff_nomatch(v_x1_24831);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam48(V self, V *args) {
  V v_st_24843 = args[0];
  V v_m_24842 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24844 = heff_tr(heff_call(v_m_24842, 1, (V[]){v_st_24843}));
  switch (heff_tag_of(v_x1_24844)) {
  case TAG_MkPair: {
    V v_x11_24845 = heff_field(v_x1_24844, 0);
    V v_st_24846 = heff_field(v_x1_24844, 1);
    V v_ru_24x1_24844_24MkPair = heff_take_reuse_n(v_x1_24844, 3ULL, 2);
    switch (heff_tag_of(v_x11_24845)) {
    case TAG_Left: {
      V v_e_24847 = heff_field(v_x11_24845, 0);
      heff_take_n(v_x11_24845, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24844_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24847}), v_st_24846});
    }
    case TAG_Right: {
      V v_x_24848 = heff_field(v_x11_24845, 0);
      V v_ru_24x11_24845_24Right = heff_take_reuse_n(v_x11_24845, 1ULL, 1);
      V v_t_24851;
      switch (heff_tag_of(v_x_24848)) {
      case TAG_At: {
        V v_s_24850 = heff_dup(heff_field(v_x_24848, 1));
        v_t_24851 = v_s_24850;
        break;
      }
      default: heff_nomatch(v_x_24848);
      }
      V v_t_24852 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24845_24Right, TAG_StmtExpr, 1, (V[]){v_x_24848}), v_t_24851});
      return heff_tag_at_n(v_ru_24x1_24844_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24852}), v_st_24846});
    }
    default: return heff_nomatch(v_x11_24845);
    }
  }
  default: return heff_nomatch(v_x1_24844);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam49(V self, V *args) {
  V v_st_24858 = args[0];
  V v_m_24857 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24859 = heff_tr(heff_call(v_m_24857, 1, (V[]){v_st_24858}));
  switch (heff_tag_of(v_x1_24859)) {
  case TAG_MkPair: {
    V v_x11_24860 = heff_field(v_x1_24859, 0);
    V v_st_24861 = heff_field(v_x1_24859, 1);
    V v_ru_24x1_24859_24MkPair = heff_take_reuse_n(v_x1_24859, 3ULL, 2);
    switch (heff_tag_of(v_x11_24860)) {
    case TAG_Left: {
      V v_e_24862 = heff_field(v_x11_24860, 0);
      heff_take_n(v_x11_24860, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24859_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24862}), v_st_24861});
    }
    case TAG_Right: {
      V v_x_24863 = heff_field(v_x11_24860, 0);
      V v_ru_24x11_24860_24Right = heff_take_reuse_n(v_x11_24860, 1ULL, 1);
      V v_t_24866;
      switch (heff_tag_of(v_x_24863)) {
      case TAG_At: {
        V v_s_24865 = heff_dup(heff_field(v_x_24863, 1));
        v_t_24866 = v_s_24865;
        break;
      }
      default: heff_nomatch(v_x_24863);
      }
      V v_t_24867 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24860_24Right, TAG_StmtExpr, 1, (V[]){v_x_24863}), v_t_24866});
      return heff_tag_at_n(v_ru_24x1_24859_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24867}), v_st_24861});
    }
    default: return heff_nomatch(v_x11_24860);
    }
  }
  default: return heff_nomatch(v_x1_24859);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam50(V self, V *args) {
  V v_st_24871 = args[0];
  V v_m_24870 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24872 = heff_tr(heff_call(v_m_24870, 1, (V[]){v_st_24871}));
  switch (heff_tag_of(v_x1_24872)) {
  case TAG_MkPair: {
    V v_x11_24873 = heff_field(v_x1_24872, 0);
    V v_st_24874 = heff_field(v_x1_24872, 1);
    V v_ru_24x1_24872_24MkPair = heff_take_reuse_n(v_x1_24872, 3ULL, 2);
    switch (heff_tag_of(v_x11_24873)) {
    case TAG_Left: {
      V v_e_24875 = heff_field(v_x11_24873, 0);
      heff_take_n(v_x11_24873, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24872_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24875}), v_st_24874});
    }
    case TAG_Right: {
      V v_x_24876 = heff_field(v_x11_24873, 0);
      V v_ru_24x11_24873_24Right = heff_take_reuse_n(v_x11_24873, 1ULL, 1);
      V v_t_24879;
      switch (heff_tag_of(v_x_24876)) {
      case TAG_At: {
        V v_s_24878 = heff_dup(heff_field(v_x_24876, 1));
        v_t_24879 = v_s_24878;
        break;
      }
      default: heff_nomatch(v_x_24876);
      }
      V v_t_24880 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24873_24Right, TAG_StmtExpr, 1, (V[]){v_x_24876}), v_t_24879});
      return heff_tag_at_n(v_ru_24x1_24872_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24880}), v_st_24874});
    }
    default: return heff_nomatch(v_x11_24873);
    }
  }
  default: return heff_nomatch(v_x1_24872);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam51(V self, V *args) {
  V v_st_24886 = args[0];
  V v_m_24885 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24887 = heff_tr(heff_call(v_m_24885, 1, (V[]){v_st_24886}));
  switch (heff_tag_of(v_x1_24887)) {
  case TAG_MkPair: {
    V v_x11_24888 = heff_field(v_x1_24887, 0);
    V v_st_24889 = heff_field(v_x1_24887, 1);
    V v_ru_24x1_24887_24MkPair = heff_take_reuse_n(v_x1_24887, 3ULL, 2);
    switch (heff_tag_of(v_x11_24888)) {
    case TAG_Left: {
      V v_e_24890 = heff_field(v_x11_24888, 0);
      heff_take_n(v_x11_24888, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24887_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24890}), v_st_24889});
    }
    case TAG_Right: {
      V v_x_24891 = heff_field(v_x11_24888, 0);
      V v_ru_24x11_24888_24Right = heff_take_reuse_n(v_x11_24888, 1ULL, 1);
      V v_t_24894;
      switch (heff_tag_of(v_x_24891)) {
      case TAG_At: {
        V v_s_24893 = heff_dup(heff_field(v_x_24891, 1));
        v_t_24894 = v_s_24893;
        break;
      }
      default: heff_nomatch(v_x_24891);
      }
      V v_t_24895 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24888_24Right, TAG_StmtExpr, 1, (V[]){v_x_24891}), v_t_24894});
      return heff_tag_at_n(v_ru_24x1_24887_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24895}), v_st_24889});
    }
    default: return heff_nomatch(v_x11_24888);
    }
  }
  default: return heff_nomatch(v_x1_24887);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam52(V self, V *args) {
  V v_st_24901 = args[0];
  V v_m_24900 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24902 = heff_tr(heff_call(v_m_24900, 1, (V[]){v_st_24901}));
  switch (heff_tag_of(v_x1_24902)) {
  case TAG_MkPair: {
    V v_x11_24903 = heff_field(v_x1_24902, 0);
    V v_st_24904 = heff_field(v_x1_24902, 1);
    V v_ru_24x1_24902_24MkPair = heff_take_reuse_n(v_x1_24902, 3ULL, 2);
    switch (heff_tag_of(v_x11_24903)) {
    case TAG_Left: {
      V v_e_24905 = heff_field(v_x11_24903, 0);
      heff_take_n(v_x11_24903, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24902_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24905}), v_st_24904});
    }
    case TAG_Right: {
      V v_x_24906 = heff_field(v_x11_24903, 0);
      V v_ru_24x11_24903_24Right = heff_take_reuse_n(v_x11_24903, 1ULL, 1);
      V v_t_24909;
      switch (heff_tag_of(v_x_24906)) {
      case TAG_At: {
        V v_s_24908 = heff_dup(heff_field(v_x_24906, 1));
        v_t_24909 = v_s_24908;
        break;
      }
      default: heff_nomatch(v_x_24906);
      }
      V v_t_24910 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24903_24Right, TAG_StmtExpr, 1, (V[]){v_x_24906}), v_t_24909});
      return heff_tag_at_n(v_ru_24x1_24902_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24910}), v_st_24904});
    }
    default: return heff_nomatch(v_x11_24903);
    }
  }
  default: return heff_nomatch(v_x1_24902);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam53(V self, V *args) {
  V v_st_24916 = args[0];
  V v_m_24915 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24917 = heff_tr(heff_call(v_m_24915, 1, (V[]){v_st_24916}));
  switch (heff_tag_of(v_x1_24917)) {
  case TAG_MkPair: {
    V v_x11_24918 = heff_field(v_x1_24917, 0);
    V v_st_24919 = heff_field(v_x1_24917, 1);
    V v_ru_24x1_24917_24MkPair = heff_take_reuse_n(v_x1_24917, 3ULL, 2);
    switch (heff_tag_of(v_x11_24918)) {
    case TAG_Left: {
      V v_e_24920 = heff_field(v_x11_24918, 0);
      heff_take_n(v_x11_24918, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24920}), v_st_24919});
    }
    case TAG_Right: {
      V v_x_24921 = heff_field(v_x11_24918, 0);
      V v_ru_24x11_24918_24Right = heff_take_reuse_n(v_x11_24918, 1ULL, 1);
      V v_t_24924;
      switch (heff_tag_of(v_x_24921)) {
      case TAG_At: {
        V v_s_24923 = heff_dup(heff_field(v_x_24921, 1));
        v_t_24924 = v_s_24923;
        break;
      }
      default: heff_nomatch(v_x_24921);
      }
      V v_t_24925 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24918_24Right, TAG_StmtExpr, 1, (V[]){v_x_24921}), v_t_24924});
      return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24925}), v_st_24919});
    }
    default: return heff_nomatch(v_x11_24918);
    }
  }
  default: return heff_nomatch(v_x1_24917);
  }
}
V g_heff_2esyntax_2esurface_2estmtL_lam54(V self, V *args) {
  V v_st_24933 = args[0];
  V v_m_24932 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24934 = heff_tr(heff_call(v_m_24932, 1, (V[]){v_st_24933}));
  switch (heff_tag_of(v_x1_24934)) {
  case TAG_MkPair: {
    V v_x11_24935 = heff_field(v_x1_24934, 0);
    V v_st_24936 = heff_field(v_x1_24934, 1);
    V v_ru_24x1_24934_24MkPair = heff_take_reuse_n(v_x1_24934, 3ULL, 2);
    switch (heff_tag_of(v_x11_24935)) {
    case TAG_Left: {
      V v_e_24937 = heff_field(v_x11_24935, 0);
      heff_take_n(v_x11_24935, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24934_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24937}), v_st_24936});
    }
    case TAG_Right: {
      V v_x_24938 = heff_field(v_x11_24935, 0);
      V v_ru_24x11_24935_24Right = heff_take_reuse_n(v_x11_24935, 1ULL, 1);
      V v_t_24941;
      switch (heff_tag_of(v_x_24938)) {
      case TAG_At: {
        V v_s_24940 = heff_dup(heff_field(v_x_24938, 1));
        v_t_24941 = v_s_24940;
        break;
      }
      default: heff_nomatch(v_x_24938);
      }
      V v_t_24942 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24935_24Right, TAG_StmtExpr, 1, (V[]){v_x_24938}), v_t_24941});
      return heff_tag_at_n(v_ru_24x1_24934_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24942}), v_st_24936});
    }
    default: return heff_nomatch(v_x11_24935);
    }
  }
  default: return heff_nomatch(v_x1_24934);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str81, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str82, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str83, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str84, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str85, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecatchL_str87, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2ecatchL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecatchL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatchL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecatchL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop(v_r_240);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop(v_r_240);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop(v_r_240);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop(v_r_240);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Seg: {
    heff_drop(v_r_240);
    V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2447 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str8));
    V v_msg_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str9), v_t_2448);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam4, 1, 2, (V[]){v_t_2446, v_msg_2449});
  }
  case TAG_Braces: {
    heff_drop(v_r_240);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2458 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2459 = heff_strAppend(heff_get_n(v_t_2458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str10));
    V v_msg_2460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str11), v_t_2459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam5, 1, 2, (V[]){v_t_2457, v_msg_2460});
  }
  case TAG_Update: {
    heff_drop(v_r_240);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_EUSet: {
    heff_drop(v_r_240);
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2481 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str14));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str15), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam7, 1, 2, (V[]){v_t_2480, v_msg_2483});
  }
  case TAG_InstB: {
    heff_drop(v_r_240);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFSet: {
    heff_drop(v_r_240);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_EFDefault: {
    heff_drop(v_r_240);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24113 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24114 = heff_strAppend(heff_get_n(v_t_24113, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str20));
    V v_msg_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str21), v_t_24114);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam10, 1, 2, (V[]){v_t_24112, v_msg_24115});
  }
  case TAG_Sum: {
    heff_drop(v_r_240);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24125 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str22));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str23), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam11, 1, 2, (V[]){v_t_24124, v_msg_24127});
  }
  case TAG_ECon: {
    heff_drop(v_r_240);
    V v_t_24133 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24134 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str24));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str25), v_t_24135);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam12, 1, 2, (V[]){v_t_24133, v_msg_24136});
  }
  case TAG_EField: {
    heff_drop(v_r_240);
    V v_t_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24143 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24144 = heff_strAppend(heff_get_n(v_t_24143, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str26));
    V v_msg_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str27), v_t_24144);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam13, 1, 2, (V[]){v_t_24142, v_msg_24145});
  }
  case TAG_ENeg: {
    heff_drop(v_r_240);
    V v_t_24151 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24152 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24153 = heff_strAppend(heff_get_n(v_t_24152, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str28));
    V v_msg_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str29), v_t_24153);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam14, 1, 2, (V[]){v_t_24151, v_msg_24154});
  }
  case TAG_ETilde: {
    heff_drop(v_r_240);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_App: {
    heff_drop(v_r_240);
    V v_t_24169 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24170 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24171 = heff_strAppend(heff_get_n(v_t_24170, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str32));
    V v_msg_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str33), v_t_24171);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam16, 1, 2, (V[]){v_t_24169, v_msg_24172});
  }
  case TAG_Op: {
    heff_drop(v_r_240);
    V v_t_24179 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24180 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str34));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str35), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam17, 1, 2, (V[]){v_t_24179, v_msg_24182});
  }
  case TAG_Ops: {
    heff_drop(v_r_240);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_OpRhs: {
    heff_drop(v_r_240);
    V v_t_24197 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24198 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24199 = heff_strAppend(heff_get_n(v_t_24198, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str38));
    V v_msg_24200 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str39), v_t_24199);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam19, 1, 2, (V[]){v_t_24197, v_msg_24200});
  }
  case TAG_Ann: {
    heff_drop(v_r_240);
    V v_t_24207 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24208 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24209 = heff_strAppend(heff_get_n(v_t_24208, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str40));
    V v_msg_24210 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str41), v_t_24209);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam20, 1, 2, (V[]){v_t_24207, v_msg_24210});
  }
  case TAG_BVar: {
    heff_drop(v_r_240);
    V v_t_24215 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24216 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24217 = heff_strAppend(heff_get_n(v_t_24216, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str42));
    V v_msg_24218 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str43), v_t_24217);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam21, 1, 2, (V[]){v_t_24215, v_msg_24218});
  }
  case TAG_BImp: {
    heff_drop(v_r_240);
    V v_t_24225 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24226 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24227 = heff_strAppend(heff_get_n(v_t_24226, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str44));
    V v_msg_24228 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str45), v_t_24227);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam22, 1, 2, (V[]){v_t_24225, v_msg_24228});
  }
  case TAG_BAnn: {
    heff_drop(v_r_240);
    V v_t_24237 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24238 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24239 = heff_strAppend(heff_get_n(v_t_24238, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str46));
    V v_msg_24240 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str47), v_t_24239);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam23, 1, 2, (V[]){v_t_24237, v_msg_24240});
  }
  case TAG_BPat: {
    heff_drop(v_r_240);
    V v_t_24245 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24246 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24247 = heff_strAppend(heff_get_n(v_t_24246, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str48));
    V v_msg_24248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str49), v_t_24247);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam24, 1, 2, (V[]){v_t_24245, v_msg_24248});
  }
  case TAG_Lam: {
    heff_drop(v_r_240);
    V v_t_24256 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24257 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24258 = heff_strAppend(heff_get_n(v_t_24257, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str50));
    V v_msg_24259 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str51), v_t_24258);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam25, 1, 2, (V[]){v_t_24256, v_msg_24259});
  }
  case TAG_Case: {
    heff_drop(v_r_240);
    V v_t_24267 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24268 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24269 = heff_strAppend(heff_get_n(v_t_24268, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str52));
    V v_msg_24270 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str53), v_t_24269);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam26, 1, 2, (V[]){v_t_24267, v_msg_24270});
  }
  case TAG_EAlt: {
    heff_drop(v_r_240);
    V v_t_24277 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24278 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24279 = heff_strAppend(heff_get_n(v_t_24278, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str54));
    V v_msg_24280 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str55), v_t_24279);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam27, 1, 2, (V[]){v_t_24277, v_msg_24280});
  }
  case TAG_If: {
    heff_drop(v_r_240);
    V v_t_24290 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24291 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24292 = heff_strAppend(heff_get_n(v_t_24291, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str56));
    V v_msg_24293 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str57), v_t_24292);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam28, 1, 2, (V[]){v_t_24290, v_msg_24293});
  }
  case TAG_Do: {
    heff_drop(v_r_240);
    V v_t_24299 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24300 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24301 = heff_strAppend(heff_get_n(v_t_24300, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str58));
    V v_msg_24302 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str59), v_t_24301);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam29, 1, 2, (V[]){v_t_24299, v_msg_24302});
  }
  case TAG_ESBind: {
    heff_drop(v_r_240);
    V v_t_24309 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24310 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24311 = heff_strAppend(heff_get_n(v_t_24310, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str60));
    V v_msg_24312 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str61), v_t_24311);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam30, 1, 2, (V[]){v_t_24309, v_msg_24312});
  }
  case TAG_ELet: {
    heff_drop(v_r_240);
    V v_t_24322 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24323 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24324 = heff_strAppend(heff_get_n(v_t_24323, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str62));
    V v_msg_24325 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str63), v_t_24324);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam31, 1, 2, (V[]){v_t_24322, v_msg_24325});
  }
  case TAG_ELetElse: {
    heff_drop(v_r_240);
    V v_t_24336 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24337 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 7); r_; });
    V v_t_24338 = heff_strAppend(heff_get_n(v_t_24337, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str64));
    V v_msg_24339 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str65), v_t_24338);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam32, 1, 2, (V[]){v_t_24336, v_msg_24339});
  }
  case TAG_ELetMut: {
    heff_drop(v_r_240);
    V v_t_24349 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24350 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24351 = heff_strAppend(heff_get_n(v_t_24350, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str66));
    V v_msg_24352 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str67), v_t_24351);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam33, 1, 2, (V[]){v_t_24349, v_msg_24352});
  }
  case TAG_EAssign: {
    heff_drop(v_r_240);
    V v_t_24359 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24360 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24361 = heff_strAppend(heff_get_n(v_t_24360, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str68));
    V v_msg_24362 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str69), v_t_24361);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam34, 1, 2, (V[]){v_t_24359, v_msg_24362});
  }
  case TAG_EWhile: {
    heff_drop(v_r_240);
    V v_t_24370 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24371 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24372 = heff_strAppend(heff_get_n(v_t_24371, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str70));
    V v_msg_24373 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str71), v_t_24372);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam35, 1, 2, (V[]){v_t_24370, v_msg_24373});
  }
  case TAG_EFor: {
    heff_drop(v_r_240);
    V v_t_24383 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24384 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24385 = heff_strAppend(heff_get_n(v_t_24384, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str72));
    V v_msg_24386 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str73), v_t_24385);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam36, 1, 2, (V[]){v_t_24383, v_msg_24386});
  }
  case TAG_EJump: {
    heff_drop(v_r_240);
    V v_t_24391 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24392 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24393 = heff_strAppend(heff_get_n(v_t_24392, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str74));
    V v_msg_24394 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str75), v_t_24393);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam37, 1, 2, (V[]){v_t_24391, v_msg_24394});
  }
  case TAG_EReturn: {
    heff_drop(v_r_240);
    V v_t_24400 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24401 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24402 = heff_strAppend(heff_get_n(v_t_24401, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str76));
    V v_msg_24403 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str77), v_t_24402);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam38, 1, 2, (V[]){v_t_24400, v_msg_24403});
  }
  case TAG_ENest: {
    heff_drop(v_r_240);
    V v_t_24411 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24412 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24413 = heff_strAppend(heff_get_n(v_t_24412, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str78));
    V v_msg_24414 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str79), v_t_24413);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam39, 1, 2, (V[]){v_t_24411, v_msg_24414});
  }
  case TAG_EArrow: {
    heff_drop(v_r_240);
    V v_t_24420 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24421 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24422 = heff_strAppend(heff_get_n(v_t_24421, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str80));
    V v_msg_24423 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str81), v_t_24422);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam40, 1, 2, (V[]){v_t_24420, v_msg_24423});
  }
  case TAG_IfThen: {
    heff_drop(v_r_240);
    V v_t_24431 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24432 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24433 = heff_strAppend(heff_get_n(v_t_24432, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str82));
    V v_msg_24434 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str83), v_t_24433);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam41, 1, 2, (V[]){v_t_24431, v_msg_24434});
  }
  case TAG_ETry: {
    heff_drop(v_r_240);
    V v_t_24442 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24443 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24444 = heff_strAppend(heff_get_n(v_t_24443, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str84));
    V v_msg_24445 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str85), v_t_24444);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam42, 1, 2, (V[]){v_t_24442, v_msg_24445});
  }
  case TAG_ECatch: {
    V v_b_24450 = heff_field(v_e_241, 1);
    V v_body_24452 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 4);
    V v_m_24453 = (g_heff_2esyntax_2esurface_2elamBinderL(heff_dup(v_r_240), v_b_24450));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam43, 1, 3, (V[]){v_m_24453, v_r_240, v_body_24452});
  }
  case TAG_EWith: {
    heff_drop(v_r_240);
    V v_t_24487 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24488 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24489 = heff_strAppend(heff_get_n(v_t_24488, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ecatchL_str86));
    V v_msg_24490 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecatchL_str87), v_t_24489);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam45, 1, 2, (V[]){v_t_24487, v_msg_24490});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatchL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecatchL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam4(V self, V *args) {
  V v_st_2450 = args[0];
  V v_t_2446 = heff_env(self)[0];
  V v_msg_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2446, 3), heff_get_n(v_t_2446, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, v_t_2451, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2452}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam5(V self, V *args) {
  V v_st_2461 = args[0];
  V v_t_2457 = heff_env(self)[0];
  V v_msg_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2457, 3), heff_get_n(v_t_2457, 4, 9)});
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2460, v_t_2462, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2461});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam7(V self, V *args) {
  V v_st_2484 = args[0];
  V v_t_2480 = heff_env(self)[0];
  V v_msg_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2480, 3), heff_get_n(v_t_2480, 4, 9)});
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, v_t_2485, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam10(V self, V *args) {
  V v_st_24116 = args[0];
  V v_t_24112 = heff_env(self)[0];
  V v_msg_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24112, 3), heff_get_n(v_t_24112, 4, 9)});
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24115, v_t_24117, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24116});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam11(V self, V *args) {
  V v_st_24128 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_msg_24127 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24124, 3), heff_get_n(v_t_24124, 4, 9)});
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, v_t_24129, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam12(V self, V *args) {
  V v_st_24137 = args[0];
  V v_t_24133 = heff_env(self)[0];
  V v_msg_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24133, 3), heff_get_n(v_t_24133, 4, 9)});
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, v_t_24138, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam13(V self, V *args) {
  V v_st_24146 = args[0];
  V v_t_24142 = heff_env(self)[0];
  V v_msg_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24142, 3), heff_get_n(v_t_24142, 4, 9)});
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24145, v_t_24147, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24148}), v_st_24146});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam14(V self, V *args) {
  V v_st_24155 = args[0];
  V v_t_24151 = heff_env(self)[0];
  V v_msg_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24151, 3), heff_get_n(v_t_24151, 4, 9)});
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24154, v_t_24156, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24155});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam16(V self, V *args) {
  V v_st_24173 = args[0];
  V v_t_24169 = heff_env(self)[0];
  V v_msg_24172 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24174 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24169, 3), heff_get_n(v_t_24169, 4, 9)});
  V v_t_24175 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24172, v_t_24174, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24175}), v_st_24173});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam17(V self, V *args) {
  V v_st_24183 = args[0];
  V v_t_24179 = heff_env(self)[0];
  V v_msg_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24179, 3), heff_get_n(v_t_24179, 4, 9)});
  V v_t_24185 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, v_t_24184, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24185}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam19(V self, V *args) {
  V v_st_24201 = args[0];
  V v_t_24197 = heff_env(self)[0];
  V v_msg_24200 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24202 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24197, 3), heff_get_n(v_t_24197, 4, 9)});
  V v_t_24203 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24200, v_t_24202, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24203}), v_st_24201});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam20(V self, V *args) {
  V v_st_24211 = args[0];
  V v_t_24207 = heff_env(self)[0];
  V v_msg_24210 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24212 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24207, 3), heff_get_n(v_t_24207, 4, 9)});
  V v_t_24213 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24210, v_t_24212, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24213}), v_st_24211});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam21(V self, V *args) {
  V v_st_24219 = args[0];
  V v_t_24215 = heff_env(self)[0];
  V v_msg_24218 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24220 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24215, 3), heff_get_n(v_t_24215, 4, 9)});
  V v_t_24221 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24218, v_t_24220, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24221}), v_st_24219});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam22(V self, V *args) {
  V v_st_24229 = args[0];
  V v_t_24225 = heff_env(self)[0];
  V v_msg_24228 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24230 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24225, 3), heff_get_n(v_t_24225, 4, 9)});
  V v_t_24231 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24228, v_t_24230, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24231}), v_st_24229});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam23(V self, V *args) {
  V v_st_24241 = args[0];
  V v_t_24237 = heff_env(self)[0];
  V v_msg_24240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24242 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24237, 3), heff_get_n(v_t_24237, 4, 9)});
  V v_t_24243 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24240, v_t_24242, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24243}), v_st_24241});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam24(V self, V *args) {
  V v_st_24249 = args[0];
  V v_t_24245 = heff_env(self)[0];
  V v_msg_24248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24250 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24245, 3), heff_get_n(v_t_24245, 4, 9)});
  V v_t_24251 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24248, v_t_24250, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24251}), v_st_24249});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam25(V self, V *args) {
  V v_st_24260 = args[0];
  V v_t_24256 = heff_env(self)[0];
  V v_msg_24259 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24261 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24256, 3), heff_get_n(v_t_24256, 4, 9)});
  V v_t_24262 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24259, v_t_24261, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24262}), v_st_24260});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam26(V self, V *args) {
  V v_st_24271 = args[0];
  V v_t_24267 = heff_env(self)[0];
  V v_msg_24270 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24272 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24267, 3), heff_get_n(v_t_24267, 4, 9)});
  V v_t_24273 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24270, v_t_24272, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24273}), v_st_24271});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam27(V self, V *args) {
  V v_st_24281 = args[0];
  V v_t_24277 = heff_env(self)[0];
  V v_msg_24280 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24282 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24277, 3), heff_get_n(v_t_24277, 4, 9)});
  V v_t_24283 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24280, v_t_24282, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24283}), v_st_24281});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam28(V self, V *args) {
  V v_st_24294 = args[0];
  V v_t_24290 = heff_env(self)[0];
  V v_msg_24293 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24295 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24290, 3), heff_get_n(v_t_24290, 4, 9)});
  V v_t_24296 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24293, v_t_24295, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24296}), v_st_24294});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam29(V self, V *args) {
  V v_st_24303 = args[0];
  V v_t_24299 = heff_env(self)[0];
  V v_msg_24302 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24304 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24299, 3), heff_get_n(v_t_24299, 4, 9)});
  V v_t_24305 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24302, v_t_24304, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24305}), v_st_24303});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam30(V self, V *args) {
  V v_st_24313 = args[0];
  V v_t_24309 = heff_env(self)[0];
  V v_msg_24312 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24314 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24309, 3), heff_get_n(v_t_24309, 4, 9)});
  V v_t_24315 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24312, v_t_24314, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24315}), v_st_24313});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam31(V self, V *args) {
  V v_st_24326 = args[0];
  V v_t_24322 = heff_env(self)[0];
  V v_msg_24325 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24327 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24322, 3), heff_get_n(v_t_24322, 4, 9)});
  V v_t_24328 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24325, v_t_24327, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24328}), v_st_24326});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam32(V self, V *args) {
  V v_st_24340 = args[0];
  V v_t_24336 = heff_env(self)[0];
  V v_msg_24339 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24341 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24336, 3), heff_get_n(v_t_24336, 4, 9)});
  V v_t_24342 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24339, v_t_24341, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24342}), v_st_24340});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam33(V self, V *args) {
  V v_st_24353 = args[0];
  V v_t_24349 = heff_env(self)[0];
  V v_msg_24352 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24354 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24349, 3), heff_get_n(v_t_24349, 4, 9)});
  V v_t_24355 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24352, v_t_24354, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24355}), v_st_24353});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam34(V self, V *args) {
  V v_st_24363 = args[0];
  V v_t_24359 = heff_env(self)[0];
  V v_msg_24362 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24364 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24359, 3), heff_get_n(v_t_24359, 4, 9)});
  V v_t_24365 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24362, v_t_24364, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24365}), v_st_24363});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam35(V self, V *args) {
  V v_st_24374 = args[0];
  V v_t_24370 = heff_env(self)[0];
  V v_msg_24373 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24375 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24370, 3), heff_get_n(v_t_24370, 4, 9)});
  V v_t_24376 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24373, v_t_24375, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24376}), v_st_24374});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam36(V self, V *args) {
  V v_st_24387 = args[0];
  V v_t_24383 = heff_env(self)[0];
  V v_msg_24386 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24388 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24383, 3), heff_get_n(v_t_24383, 4, 9)});
  V v_t_24389 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24386, v_t_24388, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24389}), v_st_24387});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam37(V self, V *args) {
  V v_st_24395 = args[0];
  V v_t_24391 = heff_env(self)[0];
  V v_msg_24394 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24396 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24391, 3), heff_get_n(v_t_24391, 4, 9)});
  V v_t_24397 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24394, v_t_24396, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24397}), v_st_24395});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam38(V self, V *args) {
  V v_st_24404 = args[0];
  V v_t_24400 = heff_env(self)[0];
  V v_msg_24403 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24405 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24400, 3), heff_get_n(v_t_24400, 4, 9)});
  V v_t_24406 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24403, v_t_24405, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24406}), v_st_24404});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam39(V self, V *args) {
  V v_st_24415 = args[0];
  V v_t_24411 = heff_env(self)[0];
  V v_msg_24414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24411, 3), heff_get_n(v_t_24411, 4, 9)});
  V v_t_24417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24414, v_t_24416, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24417}), v_st_24415});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam40(V self, V *args) {
  V v_st_24424 = args[0];
  V v_t_24420 = heff_env(self)[0];
  V v_msg_24423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24425 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24420, 3), heff_get_n(v_t_24420, 4, 9)});
  V v_t_24426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24423, v_t_24425, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24426}), v_st_24424});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam41(V self, V *args) {
  V v_st_24435 = args[0];
  V v_t_24431 = heff_env(self)[0];
  V v_msg_24434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24431, 3), heff_get_n(v_t_24431, 4, 9)});
  V v_t_24437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24434, v_t_24436, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24437}), v_st_24435});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam42(V self, V *args) {
  V v_st_24446 = args[0];
  V v_t_24442 = heff_env(self)[0];
  V v_msg_24445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24447 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24442, 3), heff_get_n(v_t_24442, 4, 9)});
  V v_t_24448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24445, v_t_24447, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24448}), v_st_24446});
}
V g_heff_2esyntax_2esurface_2ecatchL_lam44(V self, V *args) {
  V v_m_24471 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24471));
}
V g_heff_2esyntax_2esurface_2ecatchL_lam43(V self, V *args) {
  V v_st_24454 = args[0];
  V v_m_24453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_body_24452 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24455 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_st_24454}));
  switch (heff_tag_of(v_x1_24455)) {
  case TAG_MkPair: {
    V v_x11_24456 = heff_field(v_x1_24455, 0);
    V v_st_24457 = heff_field(v_x1_24455, 1);
    V v_ru_24x1_24455_24MkPair = heff_take_reuse_n(v_x1_24455, 3ULL, 2);
    switch (heff_tag_of(v_x11_24456)) {
    case TAG_Left: {
      V v_e_24458 = heff_field(v_x11_24456, 0);
      heff_take_n(v_x11_24456, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_body_24452);
      return heff_tag_at_n(v_ru_24x1_24455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24458}), v_st_24457});
    }
    case TAG_Right: {
      V v_x_24459 = heff_field(v_x11_24456, 0);
      heff_take_n(v_x11_24456, 1ULL, 1);
      V v_t_24460 = heff_dup(heff_rfield(v_x_24459, 0));
      V v_t_24470;
      switch (heff_tag_of(v_t_24460)) {
      case TAG_LamName: {
        V v_x_24461 = heff_field(v_t_24460, 0);
        V v_ru_24t_24460_24LamName = heff_take_reuse_n(v_t_24460, 1ULL, 2);
        V v_t_24463 = heff_dup(heff_rfield(v_x_24459, 2));
        switch (heff_tag_of(v_t_24463)) {
        case TAG_Nothing: {
          v_t_24470 = heff_tag_at_n(v_ru_24t_24460_24LamName, TAG_Cons, 2, (V[]){v_x_24461, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Just: {
          V v_p_24464 = heff_field(v_t_24463, 0);
          heff_take_n(v_t_24463, 1ULL, 1);
          heff_drop(v_x_24461);
          heff_drop_cell(v_ru_24t_24460_24LamName, 2);
          v_t_24470 = (g_heff_2esyntax_2epresyntax_2epatNames(v_p_24464));
          break;
        }
        default: heff_nomatch(v_t_24463);
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_24465 = heff_field(v_t_24460, 0);
        V v_ru_24t_24460_24LamImplicit = heff_take_reuse_n(v_t_24460, 1ULL, 2);
        v_t_24470 = heff_tag_at_n(v_ru_24t_24460_24LamImplicit, TAG_Cons, 2, (V[]){v_x_24465, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_24467 = heff_field(v_t_24460, 0);
        heff_take_n(v_t_24460, 1ULL, 3);
        v_t_24470 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24467, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_24460);
      }
      V v_t_24472 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2ecatchL_lam44, 1, 1, (V[]){v_r_240}), v_body_24452}));
      HeffT2 v_t_24473 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24470, v_t_24472, v_st_24457));
      {
        V v_field_24474 = v_t_24473.f[0];
        V v_field_24475 = v_t_24473.f[1];
        V v_x11_24476 = v_field_24474;
        V v_st_24477 = v_field_24475;
        switch (heff_tag_of(v_x11_24476)) {
        case TAG_Left: {
          V v_e_24478 = heff_field(v_x11_24476, 0);
          heff_take_n(v_x11_24476, 1ULL, 1);
          heff_drop_rec(v_x_24459, 3);
          return heff_tag_at_n(v_ru_24x1_24455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24478}), v_st_24477});
        }
        case TAG_Right: {
          V v_x_24479 = heff_field(v_x11_24476, 0);
          heff_take_n(v_x11_24476, 1ULL, 1);
          V v_t_24480 = heff_tag_n(TAG_MkCatchArm, 2, (V[]){heff_get_n(v_x_24459, 0, 3), v_x_24479});
          return heff_tag_at_n(v_ru_24x1_24455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24480}), v_st_24477});
        }
        default: return heff_nomatch(v_x11_24476);
        }
      }
    }
    default: return heff_nomatch(v_x11_24456);
    }
  }
  default: return heff_nomatch(v_x1_24455);
  }
}
V g_heff_2esyntax_2esurface_2ecatchL_lam45(V self, V *args) {
  V v_st_24491 = args[0];
  V v_t_24487 = heff_env(self)[0];
  V v_msg_24490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24492 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24487, 3), heff_get_n(v_t_24487, 4, 9)});
  V v_t_24493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24490, v_t_24492, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24493}), v_st_24491});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_240, v_sp_241, v_e_242, v_v_243, v_s_244, v_st_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3, 17, " does not fit in ");
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5, 1, 0};
Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V v_inPat_240, V v_sp_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_StrValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0_clo);
  }
  case TAG_IntValue: {
    V v_v_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_2412 = heff_bool(((heff_dup(v_inPat_240) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_v_246, 1) && ({ V v_t_248 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_248, 0); heff_drop(v_t_248); c_; })) : ({ V v_t_249 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_243) - ((int64_t)1ULL))))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_249)), heff_dup(v_v_246)) && ({ V v_t_2411 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_243))); int c_ = heff_intLt_c_lent(v_v_246, v_t_2411, 0); heff_drop(v_t_2411); c_; })); heff_drop(v_t_249); c_; })));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_sp_241);
      heff_drop(v_n_243);
      heff_drop(v_v_246);
      heff_drop(v_t_2412);
      return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1_clo);
    } else {
      heff_drop(v_t_2412);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2, 1, 4, (V[]){heff_dup(v_inPat_240), v_n_243, v_v_246, v_sp_241});
    }
  }
  case TAG_FloatValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3_clo);
  }
  case TAG_RuneValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4_clo);
  }
  case TAG_OtherValue: {
    heff_drop(v_sp_241);
    heff_drop(v_n_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_t_2414 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_st_2413});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam2(V self, V *args) {
  V v_st_2415 = args[0];
  V v_inPat_240 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  V v_v_246 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  if ((heff_dup(v_inPat_240) == NTAG(TAG_True))) {
    heff_drop(v_inPat_240);
    v_t_2416 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str0);
  } else {
    heff_drop(v_inPat_240);
    v_t_2416 = ((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str1);
  }
  V v_t_2417 = heff_strAppend(heff_intShow(v_n_243), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str2), v_t_2416));
  V v_t_2418 = heff_strAppend(heff_intShow(v_v_246), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_str3), v_t_2417));
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2418, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2415});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam3(V self, V *args) {
  V v_st_2420 = args[0];
  V v_t_2421 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_st_2420});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam4(V self, V *args) {
  V v_st_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2422});
}
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_lam5(V self, V *args) {
  V v_st_2424 = args[0];
  V v_t_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_st_2424});
}
Clo g_heff_2esyntax_2esurface_2etakesRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakesRest_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakesRest(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_PatVar: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatTag: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatOp: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatInt: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatFloat: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRune: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatRecord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatWord: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_PatAs: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentBits: {
          switch (heff_tag_of(v_x13_243)) {
          case TAG_SizeDefault: {
            return NTAG(TAG_True);
          }
          case TAG_SizeNumber: {
            return NTAG(TAG_False);
          }
          case TAG_SizeName: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x13_243);
          }
        }
        case TAG_SegmentFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SegmentUtf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      default: return heff_nomatch(v_x111_246);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etakesRest(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentsL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentsL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatSegmentsL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2esyntax_2esurface_2epatSegmentsL_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_rest_245)) {
    case TAG_Nil: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_245);
    }
    V v_m_249 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_t_248; V a_2 = v_p_244; V r_ = heff_tr(g_heff_2esyntax_2esurface_2epatSegmentL(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    return heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentsL_lam1, 1, 3, (V[]){v_m_249, v_r_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatSegmentsL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2epatSegmentsL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_st_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_rest_245);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_m_2416 = (g_heff_2esyntax_2esurface_2epatSegmentsL(v_r_240, v_rest_245));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2413}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_x_2421 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2421})});
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryFieldOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryFieldOne_entry, 4, 0};

V g_heff_2esyntax_2esurface_2etheoryFieldOne(V v_r_240, V v_ty_241, V v_d_242, V v_x_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_241}));
  return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0, 1, 4, (V[]){v_m_244, v_r_240, v_d_242, v_x_243});
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryFieldOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2etheoryFieldOne_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_242);
      heff_drop_rec(v_x_243, 9);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_m_2411 = (g_heff_2esyntax_2esurface_2edefaultL(v_r_240, v_d_242));
      V v_x1_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_MkPair: {
        V v_x11_2413 = heff_field(v_x1_2412, 0);
        V v_st_2414 = heff_field(v_x1_2412, 1);
        V v_ru_24x1_2412_24MkPair = heff_take_reuse_n(v_x1_2412, 3ULL, 2);
        switch (heff_tag_of(v_x11_2413)) {
        case TAG_Left: {
          V v_e_2415 = heff_field(v_x11_2413, 0);
          heff_take_n(v_x11_2413, 1ULL, 1);
          heff_drop_rec(v_x_243, 9);
          heff_drop(v_x_2410);
          heff_drop_cell(v_ru_24x11_247_24Right, 1);
          heff_drop_cell(v_ru_24x1_2412_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2415}), v_st_2414});
        }
        case TAG_Right: {
          V v_x_2416 = heff_field(v_x11_2413, 0);
          heff_take_n(v_x11_2413, 1ULL, 1);
          V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_243, 3)), heff_take_field(v_x_243, 4)});
          V v_t_2418 = heff_tag_n(TAG_DeclareField, 4, (V[]){heff_dup(heff_rfield(v_x_243, 1)), v_t_2417, heff_dup(v_x_2410), heff_dup(v_x_2416)});
          V v_t_2420;
          switch (heff_tag_of(v_x_2416)) {
          case TAG_Nothing: {
            v_t_2420 = v_x_2410;
            break;
          }
          case TAG_Just: {
            V v_x_2419 = heff_field(v_x_2416, 0);
            heff_take_n(v_x_2416, 1ULL, 1);
            heff_drop(v_x_2410);
            v_t_2420 = v_x_2419;
            break;
          }
          default: heff_nomatch(v_x_2416);
          }
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_field(v_t_2420, 1);
            heff_take_n(v_t_2420, 2ULL, 2);
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2424 = ({ V rv_0 = heff_take_field(v_x_243, 3); V rr_ = heff_rec_reuse_nf(v_t_2423, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2424})});
          V v_t_2426 = heff_tag_at_n(v_ru_24x1_2412_24MkPair, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 9), heff_dup(heff_rfield(v_st_2414, 1))});
          V v_t_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_2414, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_t_2427});
        }
        default: return heff_nomatch(v_x11_2413);
        }
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str0, 4, "#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str1, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eknotField_str2, 4, "#arg");
Clo g_heff_2esyntax_2esurface_2eknotField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eknotField_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eknotField(V v_k_240, V v_d_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str0));
  V v_t_243 = heff_tag_n(TAG_LamName, 2, (V[]){v_t_242, heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str1));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_244}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_240}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eknotField_str2));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_243, v_t_2410}), heff_dup(heff_rfield(v_d_241, 1))});
  V v_t_2412 = heff_tag_n(TAG_SetField, 3, (V[]){heff_take_field(v_d_241, 0), heff_dup(heff_rfield(v_d_241, 1)), v_t_2411});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_get_n(v_d_241, 1, 5)});
}
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eknotField(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efixityOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixityOut(V v_imported_240, V v_decls_241, V v_groups_242, V v_edges_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 0)), heff_dup(v_groups_242)));
  V v_t_245 = (g_heff_2esyntax_2efixity_2enubByG(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(heff_rfield(v_imported_240, 1)), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByE(v_t_246));
  V v_t_248 = heff_rec_n(2, shape_groups__above, (V[]){v_t_245, v_t_247});
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_imported_240, 0), heff_dup(v_groups_242)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByG(v_t_249));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_imported_240, 1, 2), heff_dup(v_edges_243)));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2411));
  V v_t_2413 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2410, v_t_2412});
  V v_t_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_t_248, v_t_2413, v_decls_241));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_242, v_edges_243}), v_t_2414});
}
V g_heff_2esyntax_2esurface_2efixityOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixityOut(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V v_kw_240, V v_ds_241, V v_rhs_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), heff_dup(v_ds_241), heff_dup(v_st_243)));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x11_247 = v_field_245;
    V v_st_248 = v_field_246;
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_ds_241);
      heff_drop(v_rhs_242);
      heff_drop_rec(v_st_243, 9);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = ({ V rv_3 = heff_get_n(v_st_243, 3, 9); V rr_ = heff_rec_reuse_nf(v_st_248, 503ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2412 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_items_2413 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2412, NTAG(TAG_Nil)));
      V v_t_2414 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2418 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0, 2, 1, (V[]){heff_dup(v_t_2411)}); V a_1 = v_t_2414; V a_2 = v_items_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2413); r_; });
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2418, 3, 4)));
      V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2410));
      V v_items_2421 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2420, NTAG(TAG_Nil)));
      V v_t_2422 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2423 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2421));
      V v_t_2424 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2421));
      V v_t_2425 = ({ V a_0 = v_t_2422; V a_1 = v_t_2423; V a_2 = v_t_2424; V a_3 = v_items_2421; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); heff_drop(v_t_2423); heff_drop(v_t_2424); r_; });
      V v_t_2426 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2425));
      V v_t_2427 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2419, v_t_2426));
      switch (heff_tag_of(v_t_2427)) {
      case TAG_Nil: {
        V v_items_2428 = ({ V a_0 = v_x_2410; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2410); r_; });
        V v_items_2429 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2428, NTAG(TAG_Nil)));
        V v_t_2430 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_items_2429; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
        V v_x1_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
        V v_b_2436;
        switch (heff_tag_of(v_x1_2432)) {
        case TAG_Nil: {
          v_b_2436 = heff_get_n(v_kw_240, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2433 = heff_field(v_x1_2432, 0);
          heff_take_n(v_x1_2432, 1ULL, 2);
          heff_drop_rec(v_kw_240, 9);
          V v_t_2435 = (g_heff_2esyntax_2ecst_2elastD(v_x_2433));
          v_b_2436 = heff_get_n(v_t_2435, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2432);
        }
        V v_t_2439;
        switch (heff_tag_of(v_rhs_242)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_rhs_242, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_242);
        }
        V v_t_2440 = ({ V rv_1 = v_b_2436; V rr_ = heff_rec_reuse_nf(v_t_2439, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_242, v_t_2431}), v_t_2440});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2441}), v_t_2411});
      }
      case TAG_Cons: {
        V v_d_2442 = heff_field(v_t_2427, 0);
        V v_ru_24t_2427_24Cons = heff_take_reuse_n(v_t_2427, 1ULL, 2);
        heff_drop_rec(v_kw_240, 9);
        heff_drop(v_ds_241);
        heff_drop(v_rhs_242);
        heff_drop(v_x_2410);
        heff_drop_cell(v_ru_24x11_247_24Right, 1);
        return heff_tag_at_n(v_ru_24t_2427_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2442}), v_t_2411});
      }
      default: return heff_nomatch(v_t_2427);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_lam0(V self, V *args) {
  V v_d_2415 = args[0];
  V v_it_2416 = args[1];
  V v_t_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2415, 2)), v_it_2416));
  return ({ V a_0 = heff_get_n(v_t_2411, 7, 9); V a_1 = v_d_2415; V a_2 = v_t_2417; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str0), v_t_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_str1)})});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_249;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a[0], a[1], a[2]);
}