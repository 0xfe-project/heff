// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Dirs 41877
#define TAG_Exit 20279
#define TAG_Files 59123
#define TAG_GetEnv 43934
#define TAG_Interactive 42932
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Right 62770
#define TAG_Some 35658
#define TAG_Start 63542
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_alone 294267509
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bench 294981194
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_checked 974171621
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_cwd 308458
#define LBL_dev 308879
#define LBL_doc 309170
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_dumpC 297304297
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_explain 1070179126
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_filter 672649891
#define LBL_fmap 9641981
#define LBL_fmt 311047
#define LBL_form 9644427
#define LBL_fuel 9649789
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_globals 352931696
#define LBL_heff 9694020
#define LBL_hmap 9701563
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_lib 316671
#define LBL_listing 413833414
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_malg 9839318
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_mod 317820
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_project 2070030684
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_ran 322201
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_shutdown 575795380
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_tool 10061407
#define LBL_top 324559
#define LBL_typeAt 1088337976
#define LBL_typing 1088343202
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_view 10114924
#define LBL_watch 314261737
static uint32_t shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc[] = {LBL_check, LBL_run, LBL_tests, LBL_bench, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt, LBL_doc};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_file__outPath__name__backend__fuel[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend, LBL_fuel};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval__dumpC[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval, LBL_dumpC};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_prog__entries__filter__typing__menu__form__alone__listing[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form, LBL_alone, LBL_listing};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_start__step__view[] = {LBL_start, LBL_step, LBL_view};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(V, V, V, V);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_clo;
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2ebuildCommands_24rec1_get(void);
V g_app_2eheff_2emain_2ebuildCommands_24rec3_get(void);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_clo;
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585(V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s101399745x11401585_clo;
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329(V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplored_24s891876813x19684329_clo;
V g_app_2eheff_2emain_2efuelSays_get(void);
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_clo;
V g_app_2eheff_2emain_2esaid_get(void);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992(V);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_clo;
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_get(void);
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s204600452x2025369236(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s204600452x2025369236_entry(V self, V *a);
extern Clo g_co_2eop_24s204600452x2025369236_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386(V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_clo;
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762(V, V);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_clo;
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2etestCmd_24s1137615276x247764950(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestCmd_24s1137615276x247764950_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestCmd_24s1137615276x247764950_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506(V, V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_clo;
V g_heff_2ebuild_2etesting_2etestsWatched_24s2073613053x2087193982(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2073613053x2087193982_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2073613053x2087193982_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1271133029x1548514599(V, V);
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1271133029x1548514599_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(V, V, V, V);
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_entry(V self, V *a);
extern Clo g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400(V, V, V);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_entry(V self, V *a);
extern Clo g_std_2eterminal_2einteractWith_24s1999309355x1375671400_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
HEFF_LIT(g_app_2eheff_2emain_2ehf_str0, 3, ".hf");
HEFF_TAG_LIT(g_app_2eheff_2emain_2ehf_lit1, TAG_Files, 1, ((V)&g_app_2eheff_2emain_2ehf_str0));

static V g_app_2eheff_2emain_2ehf_val;
static HEFF_ONCE g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return ((V)&g_app_2eheff_2emain_2ehf_lit1);
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ehf_st)) return g_app_2eheff_2emain_2ehf_val;
  return heff_global(&g_app_2eheff_2emain_2ehf_val, &g_app_2eheff_2emain_2ehf_st, g_app_2eheff_2emain_2ehf_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec1_str0, 4, "fuel");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec1_str1, 1, "f");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec1_str2, 0, "");

static V g_app_2eheff_2emain_2ebuildCommands_24rec1_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuildCommands_24rec1_st;
static V g_app_2eheff_2emain_2ebuildCommands_24rec1_init(void) {
  return heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24rec1_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_24rec1_str1), ((V)&g_app_2eheff_2emain_2ebuildCommands_24rec1_str2), heff_dup(g_app_2eheff_2emain_2efuelSays_get()), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
}
V g_app_2eheff_2emain_2ebuildCommands_24rec1_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuildCommands_24rec1_st)) return g_app_2eheff_2emain_2ebuildCommands_24rec1_val;
  return heff_global(&g_app_2eheff_2emain_2ebuildCommands_24rec1_val, &g_app_2eheff_2emain_2ebuildCommands_24rec1_st, g_app_2eheff_2emain_2ebuildCommands_24rec1_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec3_str0, 4, "FILE");

static V g_app_2eheff_2emain_2ebuildCommands_24rec3_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuildCommands_24rec3_st;
static V g_app_2eheff_2emain_2ebuildCommands_24rec3_init(void) {
  return heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24rec3_str0), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
}
V g_app_2eheff_2emain_2ebuildCommands_24rec3_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuildCommands_24rec3_st)) return g_app_2eheff_2emain_2ebuildCommands_24rec3_val;
  return heff_global(&g_app_2eheff_2emain_2ebuildCommands_24rec3_val, &g_app_2eheff_2emain_2ebuildCommands_24rec3_st, g_app_2eheff_2emain_2ebuildCommands_24rec3_init);
}
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str0, 4, "init");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str1, 39, "a new project in DIR (here, without it)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str2, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str3, 3, "get");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str4, 190, "fetch what the project requires, writing heff.sum; with PATH, require it (at VERSION or the commit REV names, PATH@REV, else its newest: its newest tag, or its default branch's commit) first");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str5, 14, "PATH[@VERSION]");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str6, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str7, 193, "the whole project: every module of src/ checked, then every program, app/NAME/main.hf, compiled as app/NAME/build.hf says, to .heff/bin/ (C by zig at -O1: built quickly, not to run its fastest)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str8, 7, "install");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str9, 264, "the project at DIR (here, without it) built as `heff build` builds it, but to run its fastest (C by zig at -O2), its programs into the heff home's bin/ (HEFF_HOME/bin, else ~/.heff/bin), and what they ship (their build.hf's `ships`) into the heff home, beside bin/");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str10, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str11, 7, "publish");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str12, 56, "check the project, then tag it vVERSION and push the tag");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str14, 7, "VERSION");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str15, 3, "dev");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str16, 138, "the project built as `heff build` builds it, its C programs (the APPs, else all) run, then built and run again at each change of its files");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str17, 3, "APP");
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_init_241 = heff_take_field(v_c_240, 0);
  V v_get_242 = heff_take_field(v_c_240, 1);
  V v_build_243 = heff_rget_v(v_c_240, 2);
  V v_install_244 = heff_take_field(v_c_240, 3);
  V v_publish_245 = heff_take_field(v_c_240, 4);
  V v_dev_246 = heff_get_n(v_c_240, 5, 6);
  V v_t_2419 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){v_init_241})});
  V v_t_2432 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){v_get_242})});
  V v_t_2434 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){v_build_243})});
  V v_t_2447 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){v_install_244})});
  V v_t_2460 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){v_publish_245})});
  V v_t_2468 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str15), ((V)&g_app_2eheff_2emain_2eprojectCommands_str16), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam9, 1, 1, (V[]){v_dev_246})});
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2470})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2471});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_2411 = args[0];
  switch (heff_tag_of(v_ws_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_ws_2411, 0);
    heff_take_n(v_ws_2411, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  }
  default: return heff_nomatch(v_ws_2411);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_init_241 = heff_env(self)[0];
  V v_give_248 = heff_take_field(v_s_247, 0);
  V v_pos_249 = heff_take_field(v_s_247, 3);
  V v_ap_2410 = heff_get_n(v_s_247, 1, 4);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_give_248), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_2415 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2416 = heff_tr(heff_call(v_pos_249, 1, (V[]){v_t_2415}));
  V v_x_2417 = heff_tr(heff_call(heff_dup(v_ap_2410), 2, (V[]){v_t_2414, v_t_2416}));
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(v_give_248, 1, (V[]){v_init_241}));
  V f_ = v_ap_2410;
  heff_room[0] = v_t_2418;
  heff_room[1] = v_x_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_get_242 = heff_env(self)[0];
  V v_give_2421 = heff_take_field(v_s_2420, 0);
  V v_pos_2422 = heff_take_field(v_s_2420, 3);
  V v_ap_2423 = heff_get_n(v_s_2420, 1, 4);
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_give_2421), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2429 = heff_tr(heff_call(v_pos_2422, 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(v_ap_2423), 2, (V[]){v_t_2427, v_t_2429}));
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tr(heff_call(v_give_2421, 1, (V[]){v_get_242}));
  V f_ = v_ap_2423;
  heff_room[0] = v_t_2431;
  heff_room[1] = v_x_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_build_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2433, 0, 4);
  args[0] = v_build_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2439 = args[0];
  switch (heff_tag_of(v_ws_2439)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_ws_2439, 0);
    heff_take_n(v_ws_2439, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2440});
  }
  default: return heff_nomatch(v_ws_2439);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_install_244 = heff_env(self)[0];
  V v_give_2436 = heff_take_field(v_s_2435, 0);
  V v_pos_2437 = heff_take_field(v_s_2435, 3);
  V v_ap_2438 = heff_get_n(v_s_2435, 1, 4);
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_give_2436), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2443 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2444 = heff_tr(heff_call(v_pos_2437, 1, (V[]){v_t_2443}));
  V v_x_2445 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2442, v_t_2444}));
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_give_2436, 1, (V[]){v_install_244}));
  V f_ = v_ap_2438;
  heff_room[0] = v_t_2446;
  heff_room[1] = v_x_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2452 = args[0];
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take_n(v_x2_2452, 1ULL, 2);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2448 = args[0];
  V v_publish_245 = heff_env(self)[0];
  V v_give_2449 = heff_take_field(v_s_2448, 0);
  V v_pos_2450 = heff_take_field(v_s_2448, 3);
  V v_ap_2451 = heff_get_n(v_s_2448, 1, 4);
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_give_2449), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2456 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_call(v_pos_2450, 1, (V[]){v_t_2456}));
  V v_x_2458 = heff_tr(heff_call(heff_dup(v_ap_2451), 2, (V[]){v_t_2455, v_t_2457}));
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tr(heff_call(v_give_2449, 1, (V[]){v_publish_245}));
  V f_ = v_ap_2451;
  heff_room[0] = v_t_2459;
  heff_room[1] = v_x_2458;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args) {
  V v_s_2461 = args[0];
  V v_dev_246 = heff_env(self)[0];
  V v_pos_2462 = heff_take_field(v_s_2461, 3);
  V v_give_2463 = heff_take_field(v_s_2461, 0);
  V v_ap_2464 = heff_get_n(v_s_2461, 1, 4);
  V v_t_2465 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str17), NTAG(TAG_Many), NTAG(TAG_None)});
  V v_x_2466 = heff_tr(heff_call(v_pos_2462, 1, (V[]){v_t_2465}));
  heff_clo_take(self, 1);
  V v_t_2467 = heff_tr(heff_call(v_give_2463, 1, (V[]){v_dev_246}));
  V f_ = v_ap_2464;
  heff_room[0] = v_t_2467;
  heff_room[1] = v_x_2466;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str1, 7, "testing");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str2, 4, "heff");
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam3(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam0, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam11, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam12(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam14(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam15(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam10(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam8(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam19(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam18(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam17(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam16, 6, 0};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam26(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam25(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam24(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam23(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam22(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam21(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam20, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam27(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam27_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam27, 5, 0};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam30(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam29(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam28(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam28_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam28, 2, 0};
Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_entry, 4, 0};

V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243) {
top: ;
  return heff_rec_n(10, shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc, (V[]){((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_clo), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam7, 7, 4, (V[]){v_clock_240, v_ex_242, v_cu_243, v_rx_241}), ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam16_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam20_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam27_clo), ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_clo), ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_clo), ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam28_clo), ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_clo)});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_t_2416 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2413, 1));
  heff_clo_take(self, 3);
  heff_drop(v_x_2413);
  return ({ V a_0 = v_t_2416; V a_1 = heff_get_n(v_x_2415, 0, 2); V a_2 = v_hd_246; V a_3 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_2412));
  V f_ = v_t_2414;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam6, 1, 3, (V[]){v_x_2413, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_t_2411 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2410, heff_dup(heff_rfield(v_x_249, 4))));
  heff_clo_take(self, 3);
  V v_x_2412 = (g_list_2efoldl_24s571074576x1179600767(v_x_249, v_t_2411));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str0), heff_dup(heff_rfield(v_x_2412, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam5, 1, 3, (V[]){v_x_2412, v_hd_246, v_k_247})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_246), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam4, 1, 3, (V[]){v_x_249, v_hd_246, v_k_247})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_248, v_file_244, heff_dup(v_hd_246), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam3, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_file_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam2, 1, 3, (V[]){v_file_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam0(V self, V *args) {
  V v_file_244 = args[0];
  V v_c_245 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam1, 2, 2, (V[]){v_c_245, v_file_244});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam11(V self, V *args) {
  V v_t_2437 = args[0];
  return v_t_2437;
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam13(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_2441 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_tr(heff_call(v_g_2441, 1, (V[]){v_x_2443}));
  V f_ = heff_get_n(v_hd_2440, 0, 3);
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam12(V self, V *args) {
  V v_g_2441 = args[0];
  V v_m_2442 = args[1];
  V v_hd_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
  args[0] = v_m_2442;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam13, 1, 2, (V[]){v_g_2441, v_hd_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam14(V self, V *args) {
  V v_c_2445 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2445;
  heff_room[0] = heff_dup(v_hd_2440);
  heff_room[1] = heff_get_n(v_hd_2440, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam15(V self, V *args) {
  V v_a_2448 = args[0];
  V v_lit_2430 = heff_env(self)[0];
  V v_lit_2431 = heff_env(self)[1];
  V v_lit_2432 = heff_env(self)[2];
  V v_lit_2433 = heff_env(self)[3];
  V v_lit_2434 = heff_env(self)[4];
  V v_lit_2435 = heff_env(self)[5];
  V v_lit_2436 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2etesting_2etestCmd_24s1137615276x247764950(v_lit_2430, v_lit_2431, v_lit_2432, v_a_2448, v_lit_2433, v_lit_2434, heff_dup(g_heff_2ebuild_2etesting_2enoRes_get()), NTAG(TAG_Nil), v_lit_2435, v_lit_2436));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_cu_243 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_hd_2425 = heff_env(self)[4];
  V v_k_2426 = heff_env(self)[5];
  V v_total_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2428));
  heff_clo_take(self, 6);
  V v_lit_2430 = v_rx_241;
  V v_lit_2431 = v_ex_242;
  V v_lit_2432 = v_cu_243;
  V v_lit_2433 = v_x_2427;
  V v_lit_2434 = v_x_2428;
  V v_lit_2435 = heff_dup(v_hd_2425);
  V v_lit_2436 = v_k_2426;
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str1), v_total_2429, ((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam11_clo)})});
  V v_p_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_hd_2440 = v_hd_2425;
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam12, 2, 1, (V[]){heff_dup(v_hd_2440)})}), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam14, 1, 1, (V[]){heff_dup(v_hd_2440)}), v_p_2439}));
  V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2446}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  heff_room[0] = v_t_2447;
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam15, 1, 7, (V[]){v_lit_2430, v_lit_2431, v_lit_2432, v_lit_2433, v_lit_2434, v_lit_2435, v_lit_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_given_2423 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_cu_243 = heff_env(self)[4];
  V v_k_2426 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506(v_given_2423, heff_dup(v_hd_2425), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam10, 1, 6, (V[]){v_rx_241, v_ex_242, v_cu_243, v_x_2427, v_hd_2425, v_k_2426})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam8(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_given_2423 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_cu_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam9, 1, 6, (V[]){v_given_2423, v_hd_2425, v_rx_241, v_ex_242, v_cu_243, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam7(V self, V *args) {
  V v_seed_2417 = args[0];
  V v_pattern_2418 = args[1];
  V v_jobs_2419 = args[2];
  V v_update_2420 = args[3];
  V v_watch_2421 = args[4];
  V v_fuel_2422 = args[5];
  V v_given_2423 = args[6];
  V v_clock_240 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_cu_243 = heff_env(self)[2];
  V v_rx_241 = heff_env(self)[3];
  if ((heff_dup(v_watch_2421) == NTAG(TAG_True))) {
    heff_drop(v_watch_2421);
    heff_clo_take(self, 4);
    heff_drop(v_rx_241);
    return ({ V a_0 = v_clock_240; V a_1 = v_ex_242; V a_2 = v_cu_243; V a_3 = v_seed_2417; V a_4 = v_pattern_2418; V a_5 = v_jobs_2419; V a_6 = v_update_2420; V a_7 = v_fuel_2422; V a_8 = v_given_2423; V r_ = (g_heff_2ebuild_2etesting_2etestsWatched_24s2073613053x2087193982(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_seed_2417); heff_drop(v_pattern_2418); heff_drop(v_jobs_2419); heff_drop(v_update_2420); r_; });
  } else {
    heff_drop(v_watch_2421);
    heff_clo_take(self, 4);
    heff_drop(v_clock_240);
    V v_c_2424 = ({ V a_0 = v_seed_2417; V a_1 = v_pattern_2418; V a_2 = v_jobs_2419; V a_3 = v_update_2420; V a_4 = v_fuel_2422; V r_ = (g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_seed_2417); heff_drop(v_pattern_2418); heff_drop(v_jobs_2419); r_; });
    return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam8, 2, 5, (V[]){v_c_2424, v_given_2423, v_rx_241, v_ex_242, v_cu_243});
  }
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam19(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2458 = heff_env(self)[0];
  V v_hd_2456 = heff_env(self)[1];
  V v_k_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_2458; V a_1 = v_x_2459; V a_2 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_3 = v_hd_2456; V a_4 = v_k_2457; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2459); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam18(V self, V *args) {
  V v_x_2458 = args[0];
  V v_given_2454 = heff_env(self)[0];
  V v_hd_2456 = heff_env(self)[1];
  V v_k_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099(v_given_2454, heff_dup(v_hd_2456), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam19, 1, 3, (V[]){v_x_2458, v_hd_2456, v_k_2457})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam17(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_given_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam18, 1, 3, (V[]){v_given_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam16(V self, V *args) {
  V v_pattern_2449 = args[0];
  V v_time_2450 = args[1];
  V v_count_2451 = args[2];
  V v_json_2452 = args[3];
  V v_fuel_2453 = args[4];
  V v_given_2454 = args[5];
  V v_c_2455 = ({ V a_0 = v_pattern_2449; V a_1 = v_time_2450; V a_2 = v_count_2451; V a_3 = v_json_2452; V a_4 = v_fuel_2453; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_pattern_2449); r_; });
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam17, 2, 2, (V[]){v_c_2455, v_given_2454});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam26(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x_2469 = heff_env(self)[0];
  V v_file_2460 = heff_env(self)[1];
  V v_hd_2462 = heff_env(self)[2];
  V v_k_2463 = heff_env(self)[3];
  V v_t_2472 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2469, 1));
  heff_clo_take(self, 4);
  heff_drop(v_x_2469);
  return ({ V a_0 = v_file_2460; V a_1 = v_t_2472; V a_2 = heff_get_n(v_x_2471, 0, 2); V a_3 = v_hd_2462; V a_4 = v_k_2463; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2472); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam25(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2468 = heff_env(self)[0];
  V v_hd_2462 = heff_env(self)[1];
  V v_file_2460 = heff_env(self)[2];
  V v_k_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_2468));
  V f_ = v_t_2470;
  heff_room[0] = heff_dup(v_hd_2462);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam26, 1, 4, (V[]){v_x_2469, v_file_2460, v_hd_2462, v_k_2463});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam24(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_hd_2462 = heff_env(self)[1];
  V v_file_2460 = heff_env(self)[2];
  V v_k_2463 = heff_env(self)[3];
  V v_t_2467 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2466, heff_dup(heff_rfield(v_x_2465, 4))));
  heff_clo_take(self, 4);
  V v_x_2468 = (g_list_2efoldl_24s571074576x1179600767(v_x_2465, v_t_2467));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_str2), heff_dup(heff_rfield(v_x_2468, 1)), MK_INT(0LL), heff_dup(v_hd_2462), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam25, 1, 4, (V[]){v_x_2468, v_hd_2462, v_file_2460, v_k_2463})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam23(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  V v_file_2460 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_2462), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam24, 1, 4, (V[]){v_x_2465, v_hd_2462, v_file_2460, v_k_2463})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam22(V self, V *args) {
  V v_x_2464 = args[0];
  V v_file_2460 = heff_env(self)[0];
  V v_hd_2462 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2464, heff_dup(v_file_2460), heff_dup(v_hd_2462), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam23, 1, 3, (V[]){v_hd_2462, v_file_2460, v_k_2463})));
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam21(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_file_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = heff_dup(v_hd_2462);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam22, 1, 3, (V[]){v_file_2460, v_hd_2462, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam20(V self, V *args) {
  V v_file_2460 = args[0];
  V v_c_2461 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam21, 2, 2, (V[]){v_c_2461, v_file_2460});
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam27(V self, V *args) {
  V v_file_2473 = args[0];
  V v_outPath_2474 = args[1];
  V v_name_2475 = args[2];
  V v_backend_2476 = args[3];
  V v_fuel_2477 = args[4];
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_clo);
  args[0] = heff_rec_n(5, shape_file__outPath__name__backend__fuel, (V[]){v_file_2473, v_outPath_2474, v_name_2475, v_backend_2476, v_fuel_2477});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam30(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_2481 = heff_env(self)[0];
  V v_k_2482 = heff_env(self)[1];
  if (heff_intLt_c(MK_INT(0LL), v_x_2483)) {
    V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
    heff_clo_take(self, 2);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), v_hd_2481, v_k_2482));
  } else {
    heff_clo_take(self, 2);
    heff_drop(v_hd_2481);
    V f_ = v_k_2482;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam29(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_c_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2480;
  args[0] = heff_dup(v_hd_2481);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam30, 1, 2, (V[]){v_hd_2481, v_k_2482});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam28(V self, V *args) {
  V v_check_2478 = args[0];
  V v_files_2479 = args[1];
  V v_c_2480 = (g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(v_check_2478, v_files_2479, MK_INT(0LL)));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_lam29, 2, 1, (V[]){v_c_2480});
}
HEFF_LIT(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_str1, 1, "#");
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam3, 1, 0};
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam5(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam4(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam6(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam7(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam2(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam0, 1, 0};
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam11(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam10(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam9(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam8, 1, 0};
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam20(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam21(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam22(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam19(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam18(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam17(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam16(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam15(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam14(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam13(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam12, 1, 0};
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam27(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam26(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam25(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam24(V self, V *args);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam23(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam23_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam23, 2, 0};

static V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_val;
static HEFF_ONCE g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_st;
static V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_init(void) {
  return heff_rec_n(5, shape_lsp__version__dumpCore__dumpEval__dumpC, (V[]){((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam0_clo), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_clo), ((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam8_clo), ((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam12_clo), ((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam23_clo)});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_st)) return g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_val;
  return heff_global(&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_val, &g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_st, g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_init);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam3(V self, V *args) {
  V v_a_249 = args[0];
  return v_a_249;
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_2415, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam4(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2415, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam5, 1, 2, (V[]){v_g_2416, v_hd_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam6(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_get_n(v_hd_2415, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam7(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_246 = heff_env(self)[0];
  V v_lit_247 = heff_env(self)[1];
  V v_lit_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = ({ V rv_0 = v_a_2423; V rr_ = heff_rec_reuse_nf(v_lit_246, 30ULL, 5, shape_lib__mod__cwd__style__heff, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2425 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_2424});
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(v_t_2425, v_lit_247, v_lit_248));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_t_245 = heff_dup(heff_rfield(v_x_244, 0));
  V v_lit_246 = v_x_244;
  V v_lit_247 = heff_dup(v_hd_242);
  heff_clo_take(self, 2);
  V v_lit_248 = v_k_243;
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_AbsPath, 2, (V[]){v_t_245, ((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_p_2414 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2413});
  V v_hd_2415 = v_hd_242;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam4, 2, 1, (V[]){heff_dup(v_hd_2415)})}), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam6, 1, 1, (V[]){heff_dup(v_hd_2415)}), v_p_2414}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_2415, 2), 1, (V[]){v_t_2421}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam7, 1, 3, (V[]){v_lit_246, v_lit_247, v_lit_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam1(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam0(V self, V *args) {
  V v_flags_240 = args[0];
  heff_drop(v_flags_240);
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam1, 2, 1, (V[]){v_c_241});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam11(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  if (heff_intEq_c(v_x_2432, MK_INT(0LL))) {
    heff_clo_take(self, 2);
    heff_drop(v_hd_2428);
    V f_ = v_k_2429;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    heff_clo_take(self, 2);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_2428, v_k_2429));
  }
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam10(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_k_2429 = heff_env(self)[1];
  V v_t_2431 = (g_list_2efoldl_24s1271133029x1548514599(NTAG(TAG_Nil), v_x_2430));
  heff_clo_take(self, 2);
  return ({ V a_0 = v_t_2431; V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_hd_2428); V a_3 = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam11, 1, 2, (V[]){v_k_2429, v_hd_2428}); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(a_0, a_1, a_2, a_3)); heff_drop(v_t_2431); r_; });
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam9(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam10, 1, 2, (V[]){v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam8(V self, V *args) {
  V v_paths_2426 = args[0];
  V v_c_2427 = (g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(NTAG(TAG_Nil), v_paths_2426));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam9, 2, 1, (V[]){v_c_2427});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam20(V self, V *args) {
  V v_acc_2466 = args[0];
  V v_k_2467 = args[1];
  V v_entries_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2468 = ({ V a_0 = v_entries_2464; V a_1 = v_k_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2464); r_; });
  {
    V v_field_2470 = v_t_2468.f[1];
    int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
    if ((v_tag_2469 == ((int64_t)0ULL))) {
      V v_e_2471 = v_field_2470;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2467, v_e_2471}), v_acc_2466});
    } else {
      heff_drop(v_k_2467);
      heff_drop(v_field_2470);
      return v_acc_2466;
    }
  }
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam21(V self, V *args) {
  V v_k_2473 = args[0];
  V v_own_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = (g_list_2emap_24s152505078x225062837(v_own_2462));
  return ({ V a_0 = v_k_2473; V a_1 = v_t_2474; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_2473); heff_drop(v_t_2474); r_; });
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam22(V self, V *args) {
  V v_x_2478 = args[0];
  V v_badL_2451 = heff_env(self)[0];
  V v_cs_2452 = heff_env(self)[1];
  V v_hd_2453 = heff_env(self)[2];
  V v_k_2454 = heff_env(self)[3];
  if (((heff_dup(v_badL_2451) == NTAG(TAG_True)) || ({ V v_c_24101 = (g_list_2eany_24s1740858080x874135214(v_cs_2452)); int c_ = ((heff_dup(v_c_24101) == NTAG(TAG_True)) || (heff_dup(v_x_2478) == NTAG(TAG_True))); heff_drop(v_c_24101); c_; }))) {
    heff_drop(v_x_2478);
    heff_clo_take(self, 4);
    heff_drop(v_badL_2451);
    heff_drop(v_cs_2452);
    V v_t_2479 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), v_hd_2453, v_k_2454));
  } else {
    heff_drop(v_x_2478);
    heff_clo_take(self, 4);
    heff_drop(v_badL_2451);
    heff_drop(v_cs_2452);
    heff_drop(v_hd_2453);
    V f_ = v_k_2454;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam19(V self, V *args) {
  V v_x_2455 = args[0];
  V v_cs_2452 = heff_env(self)[0];
  V v_hd_2453 = heff_env(self)[1];
  V v_badL_2451 = heff_env(self)[2];
  V v_k_2454 = heff_env(self)[3];
  heff_drop(v_x_2455);
  HeffT2 v_t_2456 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2452));
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      V v_c_2459 = v_field_2458;
      V v_c_2460 = v_c_2459;
      V v_top_2461 = heff_take_field(v_c_2460, 5);
      V v_own_2462 = heff_get_n(v_c_2460, 7, 14);
      V v_gs_2463 = heff_dup(heff_rfield(v_top_2461, 0));
      V v_entries_2464 = heff_take_field(v_gs_2463, 1);
      V v_order_2465 = heff_get_n(v_gs_2463, 0, 8);
      V v_t_2472 = ({ V a_0 = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam20, 2, 1, (V[]){v_entries_2464}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2465; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_2465); r_; });
      V v_t_2475 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo(heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam21, 1, 1, (V[]){heff_dup(v_own_2462)}), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2472, NTAG(TAG_Nil)));
      V v_t_2476 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_2462; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
      V v_t_2477 = ({ V a_0 = heff_get_n(v_top_2461, 0, 10); V a_1 = v_t_2475; V a_2 = v_t_2476; V r_ = (g_heff_2ebuild_2edriver_2eevalPick(a_0, a_1, a_2)); heff_drop(v_t_2475); r_; });
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(v_t_2477, heff_dup(v_hd_2453), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam22, 1, 4, (V[]){v_badL_2451, v_cs_2452, v_hd_2453, v_k_2454})));
    } else {
      heff_clo_take(self, 4);
      heff_drop(v_cs_2452);
      heff_drop(v_badL_2451);
      heff_drop(v_field_2458);
      V v_t_2485 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2490}), v_hd_2453, v_k_2454));
    }
  }
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam18(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  V v_badL_2451 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2448, 1));
  heff_clo_take(self, 3);
  heff_drop(v_x_2448);
  V v_cs_2452 = heff_get_n(v_x_2450, 0, 2);
  V v_hd_2453 = v_hd_2441;
  V v_k_2454 = v_k_2442;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2452), heff_dup(v_hd_2453), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam19, 1, 4, (V[]){v_cs_2452, v_hd_2453, v_badL_2451, v_k_2454})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam17(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_2447 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_2447));
  V f_ = v_t_2449;
  heff_room[0] = heff_dup(v_hd_2441);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam18, 1, 3, (V[]){v_x_2448, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  V v_t_2446 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2445, heff_dup(heff_rfield(v_x_2444, 4))));
  heff_clo_take(self, 3);
  V v_x_2447 = (g_list_2efoldl_24s571074576x1179600767(v_x_2444, v_t_2446));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_str0), heff_dup(heff_rfield(v_x_2447, 1)), MK_INT(0LL), heff_dup(v_hd_2441), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam17, 1, 3, (V[]){v_x_2447, v_hd_2441, v_k_2442})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2441 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_2441), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam16, 1, 3, (V[]){v_x_2444, v_hd_2441, v_k_2442})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam14(V self, V *args) {
  V v_x_2443 = args[0];
  V v_file_2439 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2443, v_file_2439, heff_dup(v_hd_2441), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam15, 1, 2, (V[]){v_hd_2441, v_k_2442})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam13(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_file_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam14, 1, 3, (V[]){v_file_2439, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam12(V self, V *args) {
  V v_file_2439 = args[0];
  V v_c_2440 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam13, 2, 2, (V[]){v_c_2440, v_file_2439});
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam27(V self, V *args) {
  V v_x_2498 = args[0];
  V v_x_2497 = heff_env(self)[0];
  V v_outPath_2492 = heff_env(self)[1];
  V v_file_2491 = heff_env(self)[2];
  V v_hd_2494 = heff_env(self)[3];
  V v_k_2495 = heff_env(self)[4];
  V v_t_2499 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2498, heff_dup(heff_rfield(v_x_2497, 4))));
  heff_clo_take(self, 5);
  V v_x_24100 = (g_list_2efoldl_24s571074576x1179600767(v_x_2497, v_t_2499));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996(MK_INT(1LL), NTAG(TAG_False), v_x_24100, NTAG(TAG_Nothing), v_outPath_2492, v_file_2491, v_hd_2494, v_k_2495));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam26(V self, V *args) {
  V v_x_2497 = args[0];
  V v_hd_2494 = heff_env(self)[0];
  V v_outPath_2492 = heff_env(self)[1];
  V v_file_2491 = heff_env(self)[2];
  V v_k_2495 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_2494), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam27, 1, 5, (V[]){v_x_2497, v_outPath_2492, v_file_2491, v_hd_2494, v_k_2495})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam25(V self, V *args) {
  V v_x_2496 = args[0];
  V v_file_2491 = heff_env(self)[0];
  V v_hd_2494 = heff_env(self)[1];
  V v_outPath_2492 = heff_env(self)[2];
  V v_k_2495 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2496, heff_dup(v_file_2491), heff_dup(v_hd_2494), heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam26, 1, 4, (V[]){v_hd_2494, v_outPath_2492, v_file_2491, v_k_2495})));
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam24(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k_2495 = args[1];
  V v_c_2493 = heff_env(self)[0];
  V v_file_2491 = heff_env(self)[1];
  V v_outPath_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2493;
  args[0] = heff_dup(v_hd_2494);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam25, 1, 4, (V[]){v_file_2491, v_hd_2494, v_outPath_2492, v_k_2495});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam23(V self, V *args) {
  V v_file_2491 = args[0];
  V v_outPath_2492 = args[1];
  V v_c_2493 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_lam24, 2, 3, (V[]){v_c_2493, v_file_2491, v_outPath_2492});
}
Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s236854004x1777896992_entry, 1, 0};

V g_app_2eheff_2emain_2etool_24s236854004x1777896992(V v_ex_240) {
top: ;
  return heff_dup(g_app_2eheff_2emain_2etool_24s236854004x1777896992_24rec0_get());
}
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_app_2eheff_2emain_2etool_24s236854004x1777896992(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str1, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str2, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str3, 2, "$ ");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str4, 1, "\012");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str5, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str6, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str7, 46, "heff: cannot write the command line chosen to ");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str8, 1, "\012");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str9, 46, "heff: cannot write the command line chosen to ");
HEFF_LIT(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str10, 1, "\012");
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam1(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam0(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam2(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam3(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam4, 1, 0};
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam6(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam7(V self, V *args);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam5(V self, V *args);
Clo g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_entry, 8, 0};

V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_ws_244, V v_file_245, V v_z_246, V v_z_247) {
top: ;
  if (heff_strEq_c_lent(v_file_245, ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str0), 2)) {
    heff_drop(v_file_245);
    V v_t_248 = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str1), ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str2), v_ws_244));
    V v_str_249 = heff_strAppend(((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str3), v_t_248);
    V v_lit_2410 = v_clock_240;
    V v_lit_2411 = v_rx_241;
    V v_lit_2412 = v_ex_242;
    V v_lit_2413 = v_cu_243;
    V v_lit_2414 = v_ws_244;
    V v_lit_2415 = heff_dup(v_z_246);
    V v_lit_2416 = v_z_247;
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_249, ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str4)), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_p_2423 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2422});
    V v_hd_2424 = v_z_246;
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam0, 2, 1, (V[]){heff_dup(v_hd_2424)})}), heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam2, 1, 1, (V[]){heff_dup(v_hd_2424)}), v_p_2423}));
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get_n(v_hd_2424, 1, 3), 2, (V[]){v_t_2431, heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam3, 1, 7, (V[]){v_lit_2410, v_lit_2411, v_lit_2412, v_lit_2413, v_lit_2414, v_lit_2415, v_lit_2416})});
  } else {
    heff_drop(v_clock_240);
    heff_drop(v_rx_241);
    heff_drop(v_ex_242);
    heff_drop(v_cu_243);
    V v_path_2434 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_file_245)));
    V v_text_2435 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str5); V a_1 = ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str6); V a_2 = v_ws_244; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(a_0, a_1, a_2)); heff_drop(v_ws_244); r_; });
    V v_t_2436 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2434; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2434); r_; });
    V v_a_2438 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2436, v_text_2435, ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam4_clo)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2443, heff_dup(v_z_246), heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam5, 1, 3, (V[]){v_file_245, v_z_246, v_z_247})));
  }
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tr(heff_call(v_g_2425, 1, (V[]){v_x_2427}));
  V f_ = heff_get_n(v_hd_2424, 0, 3);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam0(V self, V *args) {
  V v_g_2425 = args[0];
  V v_m_2426 = args[1];
  V v_hd_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2424, 1));
  args[0] = v_m_2426;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam1, 1, 2, (V[]){v_g_2425, v_hd_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam2(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_get_n(v_hd_2424, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam3(V self, V *args) {
  V v_a_2432 = args[0];
  V v_lit_2410 = heff_env(self)[0];
  V v_lit_2411 = heff_env(self)[1];
  V v_lit_2412 = heff_env(self)[2];
  V v_lit_2413 = heff_env(self)[3];
  V v_lit_2414 = heff_env(self)[4];
  V v_lit_2415 = heff_env(self)[5];
  V v_lit_2416 = heff_env(self)[6];
  heff_drop(v_a_2432);
  heff_clo_take(self, 7);
  V v_t_2433 = ({ V a_0 = v_lit_2410; V a_1 = v_lit_2411; V a_2 = v_lit_2412; V a_3 = v_lit_2413; V a_4 = v_lit_2414; V r_ = heff_tr(g_app_2eheff_2emain_2edispatch_24s101399745x11401585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_2414); r_; });
  V f_ = v_t_2433;
  heff_room[0] = v_lit_2415;
  heff_room[1] = v_lit_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam4(V self, V *args) {
  V v_r_2437 = args[0];
  return v_r_2437;
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_drop(v_x_2453);
  V v_t_2454 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_z_246, v_z_247));
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam7(V self, V *args) {
  V v_x_2469 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_drop(v_x_2469);
  V v_t_2470 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_z_246, v_z_247));
}
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_file_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_ru_24x_2444_24Left = heff_take_reuse_n(v_x_2444, 0ULL, 1);
    heff_clo_take(self, 3);
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str7), v_file_245), ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str8));
    V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2444_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_z_246), heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam6, 1, 2, (V[]){v_z_246, v_z_247})));
  }
  case TAG_Right: {
    V v_y_2460 = heff_field(v_x_2444, 0);
    V v_ru_24x_2444_24Right = heff_take_reuse_n(v_x_2444, 1ULL, 1);
    switch (heff_tag_of(v_y_2460)) {
    case TAG_Left: {
      V v_ru_24y_2460_24Left = heff_take_reuse_n(v_y_2460, 0ULL, 1);
      heff_clo_take(self, 3);
      V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str9), v_file_245), ((V)&g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_str10));
      V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2462, NTAG(TAG_MkUnit)});
      V v_t_2464 = heff_tag_at_n(v_ru_24x_2444_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2460_24Left, TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), heff_dup(v_z_246), heff_clo_n(g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_lam7, 1, 2, (V[]){v_z_246, v_z_247})));
    }
    case TAG_Right: {
      heff_take_n(v_y_2460, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_file_245);
      heff_drop(v_z_246);
      heff_drop_cell(v_ru_24x_2444_24Right, 1);
      V f_ = v_z_247;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2460);
    }
  }
  default: return heff_nomatch(v_x_2444);
  }
}
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str2, 7, "_CHOSEN");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str3, 0, "");
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eexplored_24s891876813x19684329_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s891876813x19684329_lam0, 1, 0};
Clo g_app_2eheff_2emain_2eexplored_24s891876813x19684329_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s891876813x19684329_entry, 7, 0};

V g_app_2eheff_2emain_2eexplored_24s891876813x19684329(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_chosen_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_chosen_244)) {
  case TAG_Nothing: {
    heff_drop(v_clock_240);
    heff_drop(v_rx_241);
    heff_drop(v_ex_242);
    heff_drop(v_cu_243);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_chosen1_247 = heff_field(v_chosen_244, 0);
    V v_ru_24chosen_244_24Just = heff_take_reuse_n(v_chosen_244, 1ULL, 1);
    switch (heff_tag_of(v_chosen1_247)) {
    case TAG_Nothing: {
      heff_drop(v_clock_240);
      heff_drop(v_rx_241);
      heff_drop(v_ex_242);
      heff_drop(v_cu_243);
      heff_drop(v_z_245);
      heff_drop_cell(v_ru_24chosen_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_Just: {
      V v_ws_248 = heff_field(v_chosen1_247, 0);
      V v_ru_24chosen1_247_24Just = heff_take_reuse_n(v_chosen1_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = MK_INT(32LL); V b_1 = ((V)&g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str0); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str1); V r_ = (g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      V v_name_2410 = heff_strAppend(v_t_249, ((V)&g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str2));
      V v_t_2412 = heff_tag_at_n(v_ru_24chosen_244_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){v_name_2410, ((V)&g_app_2eheff_2emain_2eexplored_24s891876813x19684329_lam0_clo)})});
      V v_t_2413 = heff_tag_at_n(v_ru_24chosen1_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      return (g_co_2eop_24s204600452x2025369236(v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_ws_248, ((V)&g_app_2eheff_2emain_2eexplored_24s891876813x19684329_str3), heff_dup(v_z_245), v_z_246, v_t_2417, v_z_245));
    }
    default: return heff_nomatch(v_chosen1_247);
    }
  }
  default: return heff_nomatch(v_chosen_244);
  }
}
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eexplored_24s891876813x19684329(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str2, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str3, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str4, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str5, 7, "_CHOSEN");
HEFF_LIT(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str6, 0, "");
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam0, 1, 0};
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam3, 1, 0};
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_entry, 8, 0};

V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_argv_244, V v_x2_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tr(g_app_2eheff_2emain_2edispatch_24s101399745x11401585(v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_argv_244));
    return heff_tail(v_t_248, 2, (V[]){v_z_246, v_z_247});
  }
  case TAG_Just: {
    V v_fm_249 = heff_field(v_x2_245, 0);
    V v_ru_24x2_245_24Just = heff_take_reuse_n(v_x2_245, 1ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24x2_245_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Interactive, 1, (V[]){((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam0_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_z_246), heff_clo_n(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam1, 1, 8, (V[]){v_fm_249, v_z_246, v_clock_240, v_rx_241, v_ex_242, v_cu_243, heff_dup(v_argv_244), v_z_247})));
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_app_2eheff_2emain_2eprompted_24s1557523500x207701710(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam0(V self, V *args) {
  V v_b_2410 = args[0];
  return v_b_2410;
}
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam3(V self, V *args) {
  V v_v_2430 = args[0];
  return v_v_2430;
}
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_cu_243 = heff_env(self)[3];
  V v_argv_244 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_left_2425 = ({ V a_0 = heff_dup(v_clock_240); V a_1 = heff_dup(v_rx_241); V a_2 = heff_dup(v_ex_242); V a_3 = heff_dup(v_cu_243); V a_4 = v_argv_244; V r_ = heff_tr(g_app_2eheff_2emain_2edispatch_24s101399745x11401585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_argv_244); r_; });
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_clock_240);
    heff_drop(v_rx_241);
    heff_drop(v_ex_242);
    heff_drop(v_cu_243);
    V f_ = v_left_2425;
    heff_room[0] = v_z_246;
    heff_room[1] = v_z_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_chosen1_2426 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Just = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    switch (heff_tag_of(v_chosen1_2426)) {
    case TAG_Nothing: {
      heff_drop(v_clock_240);
      heff_drop(v_rx_241);
      heff_drop(v_ex_242);
      heff_drop(v_cu_243);
      heff_drop_cell(v_ru_24x_2424_24Just, 1);
      V f_ = v_left_2425;
      heff_room[0] = v_z_246;
      heff_room[1] = v_z_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_ws_2427 = heff_field(v_chosen1_2426, 0);
      V v_ru_24chosen1_2426_24Just = heff_take_reuse_n(v_chosen1_2426, 1ULL, 1);
      heff_drop(v_left_2425);
      V v_t_2428 = ({ V a_0 = MK_INT(32LL); V b_1 = ((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str3); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str4); V r_ = (g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      V v_name_2429 = heff_strAppend(v_t_2428, ((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str5));
      V v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){v_name_2429, ((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam3_clo)})});
      V v_t_2432 = heff_tag_at_n(v_ru_24chosen1_2426_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s204600452x2025369236(v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_ws_2427, ((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str6), heff_dup(v_z_246), v_z_247, v_t_2436, v_z_246));
    }
    default: return heff_nomatch(v_chosen1_2426);
    }
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_fm_249 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_clock_240 = heff_env(self)[2];
  V v_rx_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_cu_243 = heff_env(self)[5];
  V v_argv_244 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    V v_t_2415 = (g_app_2eheff_2emain_2ebuildCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 0))));
    V v_t_2416 = (g_app_2eheff_2emain_2eprojectCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 1))));
    V v_t_2417 = (g_app_2eheff_2emain_2etoolCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 2))));
    V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2417));
    V v_t_2419 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_2415, v_t_2418));
    V v_es_2420 = (g_list_2emap_24s1531382666x123921537(v_t_2419));
    V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2422 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str1)), v_t_2421});
    heff_clo_take(self, 8);
    V v_t_2423 = heff_rec_n(8, shape_prog__entries__filter__typing__menu__form__alone__listing, (V[]){((V)&g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_str2), v_es_2420, v_t_2422, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), heff_tag_n(TAG_Just, 1, (V[]){v_fm_249}), NTAG(TAG_True), NTAG(TAG_Nothing)});
    return (g_std_2eterminal_2einteractWith_24s1999309355x1375671400(heff_rec_n(3, shape_start__step__view, (V[]){v_t_2423, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)}), heff_dup(v_z_246), heff_clo_n(g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_lam2, 1, 7, (V[]){v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_argv_244, v_z_246, v_z_247})));
  } else {
    heff_drop(v_x_2414);
    heff_clo_take(self, 8);
    heff_drop(v_fm_249);
    V v_t_2437 = ({ V a_0 = v_clock_240; V a_1 = v_rx_241; V a_2 = v_ex_242; V a_3 = v_cu_243; V a_4 = v_argv_244; V r_ = heff_tr(g_app_2eheff_2emain_2edispatch_24s101399745x11401585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_argv_244); r_; });
    V f_ = v_t_2437;
    heff_room[0] = v_z_246;
    heff_room[1] = v_z_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}