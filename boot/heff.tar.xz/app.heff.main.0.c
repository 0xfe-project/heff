// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Dirs 41877
#define TAG_Exit 20279
#define TAG_Files 59123
#define TAG_Finish 61316
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_address 1231649329
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_build 295453320
#define LBL_complete 145693389
#define LBL_dev 308879
#define LBL_doc 309170
#define LBL_entries 787768015
#define LBL_filter 672649891
#define LBL_flag 9641011
#define LBL_form 9644427
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_long 9823043
#define LBL_menu 9843238
#define LBL_message 1186782793
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_publish 2143976274
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_text 10052084
#define LBL_typing 1088343202
#define LBL_values 1123329101
#define LBL_view 10114924
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_start__step__view[] = {LBL_start, LBL_step, LBL_view};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(V);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_clo;
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738(V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s56716935x916488738_clo;
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815(V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_clo;
V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045(V, V, V, V);
V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711(V);
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eproject_24s816933939x1507085711_clo;
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889(V);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etool_24s1521631011x1066814889_clo;
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279(V, V, V, V);
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2eterminal_2eloop_24s856685530x267249326(V, V, V, V, V);
V g_std_2eterminal_2eloop_24s856685530x267249326_entry(V self, V *a);
extern Clo g_std_2eterminal_2eloop_24s856685530x267249326_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
HEFF_LIT(g_app_2eheff_2emain_2ehf_str0, 3, ".hf");

static V g_app_2eheff_2emain_2ehf_val;
static HEFF_ONCE g_app_2eheff_2emain_2ehf_st;
static V g_app_2eheff_2emain_2ehf_init(void) {
  return heff_tag_n(TAG_Files, 1, (V[]){((V)&g_app_2eheff_2emain_2ehf_str0)});
}
V g_app_2eheff_2emain_2ehf_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ehf_st)) return g_app_2eheff_2emain_2ehf_val;
  return heff_global(&g_app_2eheff_2emain_2ehf_val, &g_app_2eheff_2emain_2ehf_st, g_app_2eheff_2emain_2ehf_init);
}
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str0, 4, "init");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str1, 39, "a new project in DIR (here, without it)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str2, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str3, 3, "get");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str4, 190, "fetch what the project requires, writing heff.sum; with PATH, require it (at VERSION or the commit REV names, PATH@REV, else its newest: its newest tag, or its default branch's commit) first");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str5, 14, "PATH[@VERSION]");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str6, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str7, 193, "the whole project: every module of src/ checked, then every program, app/NAME/main.hf, compiled as app/NAME/build.hf says, to .heff/bin/ (C by zig at -O1: built quickly, not to run its fastest)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str8, 7, "install");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str9, 264, "the project at DIR (here, without it) built as `heff build` builds it, but to run its fastest (C by zig at -O2), its programs into the heff home's bin/ (HEFF_HOME/bin, else ~/.heff/bin), and what they ship (their build.hf's `ships`) into the heff home, beside bin/");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str10, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str11, 7, "publish");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str12, 56, "check the project, then tag it vVERSION and push the tag");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str14, 7, "VERSION");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str15, 3, "dev");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str16, 159, "the project built as `heff build` builds it, its C programs (the APPs, else all) run and its pages served, then built and run again at each change of its files");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str17, 3, "APP");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str18, 4, "port");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str19, 1, "p");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str20, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str21, 57, "where the pages are served: http://127.0.0.1:PORT/ (8000)");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str22, 5, "proxy");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str23, 1, "x");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str24, 3, "URL");
HEFF_LIT(g_app_2eheff_2emain_2eprojectCommands_str25, 94, "where the pages' server sends what is not a page's: the C program's, http://127.0.0.1:8080 say");
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2eprojectCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args);
Clo g_app_2eheff_2emain_2eprojectCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprojectCommands_entry, 1, 0};

V g_app_2eheff_2emain_2eprojectCommands(V v_c_240) {
top: ;
  V v_init_241 = heff_take_field(v_c_240, 0);
  V v_get_242 = heff_take_field(v_c_240, 1);
  V v_build_243 = heff_rget_v(v_c_240, 2);
  V v_install_244 = heff_take_field(v_c_240, 3);
  V v_publish_245 = heff_take_field(v_c_240, 4);
  V v_dev_246 = heff_get_n(v_c_240, 5, 6);
  V v_t_2419 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str0), ((V)&g_app_2eheff_2emain_2eprojectCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam0, 1, 1, (V[]){v_init_241})});
  V v_t_2432 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str3), ((V)&g_app_2eheff_2emain_2eprojectCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam2, 1, 1, (V[]){v_get_242})});
  V v_t_2434 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str6), ((V)&g_app_2eheff_2emain_2eprojectCommands_str7), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam4, 1, 1, (V[]){v_build_243})});
  V v_t_2447 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str8), ((V)&g_app_2eheff_2emain_2eprojectCommands_str9), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam5, 1, 1, (V[]){v_install_244})});
  V v_t_2460 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str11), ((V)&g_app_2eheff_2emain_2eprojectCommands_str12), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam7, 1, 1, (V[]){v_publish_245})});
  V v_t_2479 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str15), ((V)&g_app_2eheff_2emain_2eprojectCommands_str16), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2eprojectCommands_lam9, 1, 1, (V[]){v_dev_246})});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2481})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2482});
}
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprojectCommands(a[0]);
}
V g_app_2eheff_2emain_2eprojectCommands_lam1(V self, V *args) {
  V v_ws_2411 = args[0];
  switch (heff_tag_of(v_ws_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_ws_2411, 0);
    heff_take_n(v_ws_2411, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  }
  default: return heff_nomatch(v_ws_2411);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_init_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_248 = heff_take_field(v_s_247, 1);
  V v_give_249 = heff_take_field(v_s_247, 0);
  V v_pos_2410 = heff_get_n(v_s_247, 3, 4);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_give_249), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam1_clo)}));
  V v_t_2415 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str2), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2416 = heff_tr(heff_call(v_pos_2410, 1, (V[]){v_t_2415}));
  V v_x_2417 = heff_tr(heff_call(heff_dup(v_ap_248), 2, (V[]){v_t_2414, v_t_2416}));
  V v_t_2418 = heff_tr(heff_call(v_give_249, 1, (V[]){v_init_241}));
  V f_ = v_ap_248;
  heff_room[0] = v_t_2418;
  heff_room[1] = v_x_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam3(V self, V *args) {
  V v_ws_2424 = args[0];
  switch (heff_tag_of(v_ws_2424)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_ws_2424, 0);
    heff_take_n(v_ws_2424, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_ws_2424);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_get_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2421 = heff_take_field(v_s_2420, 1);
  V v_give_2422 = heff_take_field(v_s_2420, 0);
  V v_pos_2423 = heff_get_n(v_s_2420, 3, 4);
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_give_2422), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam3_clo)}));
  V v_t_2428 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str5), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2429 = heff_tr(heff_call(v_pos_2423, 1, (V[]){v_t_2428}));
  V v_x_2430 = heff_tr(heff_call(heff_dup(v_ap_2421), 2, (V[]){v_t_2427, v_t_2429}));
  V v_t_2431 = heff_tr(heff_call(v_give_2422, 1, (V[]){v_get_242}));
  V f_ = v_ap_2421;
  heff_room[0] = v_t_2431;
  heff_room[1] = v_x_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_build_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2433, 0, 4);
  args[0] = v_build_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eprojectCommands_lam6(V self, V *args) {
  V v_ws_2439 = args[0];
  switch (heff_tag_of(v_ws_2439)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_ws_2439, 0);
    heff_take_n(v_ws_2439, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2440});
  }
  default: return heff_nomatch(v_ws_2439);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_install_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2436 = heff_take_field(v_s_2435, 1);
  V v_give_2437 = heff_take_field(v_s_2435, 0);
  V v_pos_2438 = heff_get_n(v_s_2435, 3, 4);
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_give_2437), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam6_clo)}));
  V v_t_2443 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str10), NTAG(TAG_Optional), NTAG(TAG_Dirs)});
  V v_t_2444 = heff_tr(heff_call(v_pos_2438, 1, (V[]){v_t_2443}));
  V v_x_2445 = heff_tr(heff_call(heff_dup(v_ap_2436), 2, (V[]){v_t_2442, v_t_2444}));
  V v_t_2446 = heff_tr(heff_call(v_give_2437, 1, (V[]){v_install_244}));
  V f_ = v_ap_2436;
  heff_room[0] = v_t_2446;
  heff_room[1] = v_x_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam8(V self, V *args) {
  V v_x2_2452 = args[0];
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2eprojectCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    heff_take_n(v_x2_2452, 1ULL, 2);
    return v_x_2453;
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_app_2eheff_2emain_2eprojectCommands_lam7(V self, V *args) {
  V v_s_2448 = args[0];
  V v_publish_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2449 = heff_take_field(v_s_2448, 1);
  V v_give_2450 = heff_take_field(v_s_2448, 0);
  V v_pos_2451 = heff_get_n(v_s_2448, 3, 4);
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_give_2450), 1, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_lam8_clo)}));
  V v_t_2456 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_call(v_pos_2451, 1, (V[]){v_t_2456}));
  V v_x_2458 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_call(v_give_2450, 1, (V[]){v_publish_245}));
  V f_ = v_ap_2449;
  heff_room[0] = v_t_2459;
  heff_room[1] = v_x_2458;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eprojectCommands_lam9(V self, V *args) {
  V v_s_2461 = args[0];
  V v_dev_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_2462 = heff_take_field(v_s_2461, 3);
  V v_ap_2463 = heff_take_field(v_s_2461, 1);
  V v_give_2464 = heff_take_field(v_s_2461, 0);
  V v_flag_2465 = heff_get_n(v_s_2461, 2, 4);
  V v_t_2466 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str17), NTAG(TAG_Many), NTAG(TAG_None)});
  V v_x_2467 = heff_tr(heff_call(v_pos_2462, 1, (V[]){v_t_2466}));
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_give_2464), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2469 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str18), ((V)&g_app_2eheff_2emain_2eprojectCommands_str19), ((V)&g_app_2eheff_2emain_2eprojectCommands_str20), ((V)&g_app_2eheff_2emain_2eprojectCommands_str21), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2470 = heff_tr(heff_call(heff_dup(v_flag_2465), 1, (V[]){v_t_2469}));
  V v_y_2471 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2468, v_t_2470}));
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_give_2464), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2473 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2eprojectCommands_str22), ((V)&g_app_2eheff_2emain_2eprojectCommands_str23), ((V)&g_app_2eheff_2emain_2eprojectCommands_str24), ((V)&g_app_2eheff_2emain_2eprojectCommands_str25), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2474 = heff_tr(heff_call(v_flag_2465, 1, (V[]){v_t_2473}));
  V v_z_2475 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2472, v_t_2474}));
  V v_t_2476 = heff_tr(heff_call(v_give_2464, 1, (V[]){v_dev_246}));
  V v_t_2477 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2476, v_x_2467}));
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_ap_2463), 2, (V[]){v_t_2477, v_y_2471}));
  V f_ = v_ap_2463;
  heff_room[0] = v_t_2478;
  heff_room[1] = v_z_2475;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str0, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str1, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str2, 2, "$ ");
HEFF_LIT(g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str3, 1, "\012");
V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_entry, 4, 0};

V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045(V v_e_240, V v_chosen_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_chosen_241)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_chosen1_244 = heff_field(v_chosen_241, 0);
    V v_ru_24chosen_241_24Just = heff_take_reuse_n(v_chosen_241, 1ULL, 1);
    switch (heff_tag_of(v_chosen1_244)) {
    case TAG_Nothing: {
      heff_drop(v_e_240);
      heff_drop(v_z_242);
      heff_drop_cell(v_ru_24chosen_241_24Just, 1);
      return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_Just: {
      V v_ws_245 = heff_field(v_chosen1_244, 0);
      V v_ru_24chosen1_244_24Just = heff_take_reuse_n(v_chosen1_244, 1ULL, 1);
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(((V)&g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str0), ((V)&g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str1), v_ws_245));
      V v_str_247 = heff_strAppend(((V)&g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str2), v_t_246);
      V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_247, ((V)&g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_str3)), NTAG(TAG_MkUnit)});
      V v_t_249 = heff_tag_at_n(v_ru_24chosen_241_24Just, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24chosen1_244_24Just, TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_z_242), heff_clo_n(g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_lam0, 1, 4, (V[]){v_e_240, v_ws_245, v_z_242, v_z_243}));
    }
    default: return heff_nomatch(v_chosen1_244);
    }
  }
  default: return heff_nomatch(v_chosen_241);
  }
}
V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ws_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  return (g_app_2eheff_2emain_2edispatch_24s56716935x916488738(v_e_240, v_ws_245, v_z_242, v_z_243));
}
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str2, 4, "heff");
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam0(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam1, 1, 0};
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam4(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam3(V self, V *args);
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam2(V self, V *args);
Clo g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_entry, 6, 0};

V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815(V v_e_240, V v_x1_241, V v_z_242, V v_z_243, V v_z_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x1_241) == NTAG(TAG_True))) {
    V v_t_246 = (g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(heff_dup(v_e_240)));
    V v_t_247 = (g_app_2eheff_2emain_2eproject_24s816933939x1507085711(heff_dup(v_e_240)));
    V v_t_248 = (g_app_2eheff_2emain_2etool_24s1521631011x1066814889(heff_dup(v_e_240)));
    V v_t_249 = (g_app_2eheff_2emain_2ebuildCommands(v_t_246));
    V v_t_2410 = (g_app_2eheff_2emain_2eprojectCommands(v_t_247));
    V v_t_2411 = (g_app_2eheff_2emain_2etoolCommands(v_t_248));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    V v_t_2413 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_249, v_t_2412));
    V v_es_2414 = (g_list_2emap_24s1531382666x123921537(v_t_2413));
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2416 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str1)), v_t_2415});
    V v_t_2417 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_str2), v_es_2414, v_t_2416, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), NTAG(TAG_Nothing)});
    V v_t_2418 = heff_rec_n(3, shape_start__step__view, (V[]){v_t_2417, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)});
    V v_e_2419 = heff_dup(v_e_240);
    V v_app_2420 = v_t_2418;
    V v_hd_2421 = heff_dup(v_z_242);
    V v_k_2423 = heff_clo_n(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam0, 1, 3, (V[]){v_e_240, v_z_242, v_z_243});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 1, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam1_clo)})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    V v_t_2437 = heff_tr(g_co_2eop_24s310169282x2049378029(heff_dup(v_e_2419), heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2421), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam2, 1, 4, (V[]){v_e_2419, v_app_2420, v_hd_2421, v_k_2423})));
    return heff_tail(v_t_2437, 2, (V[]){v_z_244, v_z_245});
  } else {
    V v_t_2438 = heff_tr(g_app_2eheff_2emain_2edispatch_24s56716935x916488738(v_e_240, NTAG(TAG_Nil), v_z_242, v_z_243));
    return heff_tail(v_t_2438, 2, (V[]){v_z_244, v_z_245});
  }
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_app_2eheff_2emain_2eexplore_24s1488403284x165539815(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_app_2eheff_2emain_2eexplored_24s1901980155x1076319045(v_e_240, v_x_2422, v_z_242, v_z_243));
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam1(V self, V *args) {
  V v_b_2424 = args[0];
  return v_b_2424;
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_2423;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_2419 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_tag_n(TAG_Finish, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_2419, v_t_2435, v_hd_2421, heff_clo_n(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam4, 1, 2, (V[]){v_k_2423, v_x_2430})));
}
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_2419 = heff_env(self)[0];
  V v_app_2420 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2429) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    return (g_std_2eterminal_2eloop_24s856685530x267249326(heff_dup(v_e_2419), heff_dup(v_app_2420), heff_get_n(v_app_2420, 0, 3), heff_dup(v_hd_2421), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_lam3, 1, 3, (V[]){v_e_2419, v_hd_2421, v_k_2423})));
  } else {
    heff_drop(v_x_2429);
    heff_drop(v_e_2419);
    heff_drop_rec(v_app_2420, 3);
    heff_drop(v_hd_2421);
    V f_ = v_k_2423;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str0, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str1, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str2, 6, "heff: ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str3, 1, "\012");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str4, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str5, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str6, 6, "heff: ");
HEFF_LIT(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str7, 1, "\012");
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam0(V self, V *args);
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_entry, 4, 0};

V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279(V v_e_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Left: {
    V v_err_244 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Left = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    V v_path_245 = heff_take_field(v_err_244, 3);
    V v_name_246 = heff_take_field(v_err_244, 1);
    V v_message_247 = heff_get_n(v_err_244, 2, 4);
    V v_t_248 = heff_strAppend(heff_strAppend(v_path_245, ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str0)), v_name_246);
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str1)), v_message_247);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str2), v_t_249), ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str3));
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_at_n(v_ru_24x1_241_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_p_242), heff_clo_n(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam0, 1, 3, (V[]){v_e_240, v_p_242, v_p_243}));
  }
  case TAG_Right: {
    V v_x11_2424 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Right = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_err_2425 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      V v_address_2426 = heff_take_field(v_err_2425, 3);
      V v_name_2427 = heff_take_field(v_err_2425, 1);
      V v_message_2428 = heff_get_n(v_err_2425, 2, 4);
      V v_t_2429 = heff_strAppend(heff_strAppend(v_address_2426, ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str4)), v_name_2427);
      V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str5)), v_message_2428);
      V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str6), v_t_2430), ((V)&g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_str7));
      V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_at_n(v_ru_24x1_241_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Left, TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_p_242), heff_clo_n(g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam1, 1, 3, (V[]){v_e_240, v_p_242, v_p_243}));
    }
    case TAG_Right: {
      heff_take_n(v_x11_2424, 0ULL, 1);
      heff_drop(v_e_240);
      heff_drop(v_p_242);
      heff_drop_cell(v_ru_24x1_241_24Right, 1);
      return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eunheard_24s1646521510x754669279(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242, v_p_243));
}
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_lam1(V self, V *args) {
  V v_x_2438 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_p_242, v_p_243));
}