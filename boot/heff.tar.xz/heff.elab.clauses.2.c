// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291 3888
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648 39892
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156 11512
#define TAG_Enter_24heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297 1281
#define TAG_ExplicitParam 63083
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_terms 311608737
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo;
V g_heff_2eelab_2eclauses_2earmSub(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSub_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ebinBindGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo;
V g_heff_2eelab_2eclauses_2ebinTest(V);
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTest_clo;
V g_heff_2eelab_2eclauses_2ebinTestGo(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolNames(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
HeffT2 g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2edesugarCols_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropAt_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efits(V, V, V, V);
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efits_clo;
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_clo;
HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_clo;
V g_heff_2eelab_2eclauses_2eletFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eletFields_clo;
HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitExpr(V);
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitExpr_clo;
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
HeffT2 g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V, V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo;
HeffT2 g_heff_2eelab_2eclauses_2enoLitHere_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelAs_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_clo;
HeffT2 g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameField(V, V);
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameField_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2esegBind(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegBind_clo;
V g_heff_2eelab_2eclauses_2esegRead(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegRead_clo;
V g_heff_2eelab_2eclauses_2esizeOk(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esizeOk_clo;
V g_heff_2eelab_2eclauses_2esoleBin(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_clo;
V g_heff_2eelab_2eclauses_2etagArmStep(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagArmStep_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
HeffT2 g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2eutfWidth(V, V, V, V);
V g_heff_2eelab_2eclauses_2eutfWidth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eutfWidth_clo;
HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2eelab_2eclauses_2ezipC(V, V);
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1437740164x269163243(V, V);
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1437740164x269163243_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s901304517x253262467(V, V, V);
V g_list_2efoldl_24s901304517x253262467_entry(V self, V *a);
extern Clo g_list_2efoldl_24s901304517x253262467_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V, V);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2eelab_2eclauses_2esoleBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esoleBin_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esoleBin(V v_s_240, V v_v_241, V v_ty_242, V v_size_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_At: {
    V v_v1_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24At = heff_take_reuse_n(v_v_241, 1ULL, 2);
    switch (heff_tag_of(v_v1_245)) {
    case TAG_PatVar: {
      V v_x_247 = heff_field(v_v1_245, 0);
      V v_ru_24v1_245_24PatVar = heff_take_reuse_n(v_v1_245, 1ULL, 1);
      switch (heff_tag_of(v_ty_242)) {
      case TAG_SegmentInteger: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_248 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_248, v_sp_244});
      }
      case TAG_SegmentBinary: {
        switch (heff_tag_of(v_size_243)) {
        case TAG_SizeDefault: {
          heff_drop(v_s_240);
          heff_drop(v_sp_244);
          heff_drop_cell(v_ru_24v_241_24At, 2);
          return heff_tag_at_n(v_ru_24v1_245_24PatVar, TAG_PVar, 1, (V[]){v_x_247});
        }
        case TAG_SizeNumber: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2410, v_sp_244});
        }
        case TAG_SizeName: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2414 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2414, v_sp_244});
        }
        default: return heff_nomatch(v_size_243);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2415 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2415, v_sp_244});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2416 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2416, v_sp_244});
      }
      case TAG_SegmentUtf: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2418 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2418, v_sp_244});
      }
      default: return heff_nomatch(v_ty_242);
      }
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2422 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2422, v_sp_244});
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2426 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2426, v_sp_244});
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2428, v_sp_244});
    }
    case TAG_PatFloat: {
      heff_take_na(v_v1_245, 0ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2430, v_sp_244});
    }
    case TAG_PatString: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2432, v_sp_244});
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2434 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2434, v_sp_244});
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2436 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2436, v_sp_244});
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2438 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2438, v_sp_244});
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2440 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2440, v_sp_244});
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2444 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2444, v_sp_244});
    }
    default: return heff_nomatch(v_v1_245);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2esoleBin(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2eappendC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eclauses_2eappendC_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
    }
    case TAG_Right: {
      heff_take_n(v_x1_244, 0ULL, 1);
      V t_0 = v_xs_243;
      V t_1 = v_f_241;
      v_x1_240 = t_0;
      v_f_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_entry, 3, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2emapWithIndexC(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry, 4, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2ezipC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ezipC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eclauses_2ezipC_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eallC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eallC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eallC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2edropAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2elitExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitExpr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2elitExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatTag: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatOp: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatInt: {
      V v_x_2410 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatInt = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x_2410}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatInt, TAG_CInf, 1, (V[]){v_t_2411}), v_sp_242});
    }
    case TAG_PatFloat: {
      double v_x_2412 = heff_tflat_f64(v_x11_241, 0);
      V v_ru_24x11_241_24PatFloat = heff_take_reuse_na(v_x11_241, 0ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatFloat, TAG_CInf, 1, (V[]){v_t_2413}), v_sp_242});
    }
    case TAG_PatString: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatString = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatString, TAG_CInf, 1, (V[]){v_t_2415}), v_sp_242});
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatRune: {
      V v_x_2417 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatRune = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_x_2417}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatRune, TAG_CInf, 1, (V[]){v_t_2418}), v_sp_242});
    }
    case TAG_PatRecord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatAs: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2elitExpr(a[0]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2epatVars(v_t_245));
    V v_t_247 = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatVars_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    return heff_setField(v_d_241, MK_INT(1LL), v_t_243);
  }
  case TAG_PTag: {
    V v_ps_245 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    V v_t_247 = ({ V a_0 = v_ps_245; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_245); r_; });
    return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_PRec: {
    V v_fps_249 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_fps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_249); r_; });
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
  }
  case TAG_PAs: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    V v_p_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_p_2413;
    V t_1 = v_cell_2414;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_PBin: {
    V v_segs_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2418 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2416)));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2418));
    V v_t_2420 = (g_list_2emap_24s939813003x1383013550(v_segs_2416));
    V v_t_2421 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2420));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2419, v_t_2421));
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2422);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatIdents(V v_p_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_247; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_247); r_; });
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_242, 0);
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_t_2411 = ({ V a_0 = v_ps_2410; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2410); r_; });
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_248, v_t_2411});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatBinary: {
      V v_segs_2415 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(v_segs_2415, v_acc_241);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2417, v_acc_241);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatAs: {
      V v_x_2419 = heff_field(v_p1_242, 0);
      V v_q_2421 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2422 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2419, heff_hole()});
      V v_u_2423 = (g_heff_2eelab_2eclauses_2epatIdents_24dps(v_q_2421, v_acc_241, heff_dup(v_cell_2422)));
      heff_drop(v_u_2423);
      return v_cell_2422;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_TPi: {
      V v_b_245 = heff_field(v_n1_243, 0);
      V v_cod_246 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_cod_246, v_acc_242}));
      return ({ V a_0 = v_r_240; V a_1 = v_b_245; V a_2 = v_t_247; V r_ = (g_heff_2eelab_2eclauses_2epiIdents(a_0, a_1, a_2)); heff_drop(v_b_245); r_; });
    }
    case TAG_TSig: {
      V v_fs_248 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_248; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_248); r_; });
    }
    case TAG_TSum: {
      V v_vs_2421 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_vs_2421; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_vs_2421); r_; });
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TArray: {
      V v_a_2430 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_a_2430, v_acc_242});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInf: {
      V v_i_2432 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2432, v_acc_242});
    }
    case TAG_TChk: {
      V v_c_2433 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2433, v_acc_242});
    }
    case TAG_TNominal: {
      V v_t_2434 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2434, v_acc_242});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsTypF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args) {
  V v_x2_249 = args[0];
  V v_acc_2410 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_249)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24At = heff_take_reuse_n(v_x2_249, 1ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_DeclareField: {
      V v_x_2413 = heff_field(v_x21_2411, 0);
      V v_t_2415 = heff_field(v_x21_2411, 2);
      V v_d_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 13ULL, 4);
      V v_t_2418;
      switch (heff_tag_of(v_d_2416)) {
      case TAG_Nothing: {
        v_t_2418 = v_acc_2410;
        break;
      }
      case TAG_Just: {
        V v_c_2417 = heff_field(v_d_2416, 0);
        heff_take_n(v_d_2416, 1ULL, 1);
        v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_c_2417, v_acc_2410}));
        break;
      }
      default: heff_nomatch(v_d_2416);
      }
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2415, v_t_2418}));
      return heff_tag_at_n(v_ru_24x2_249_24At, TAG_Cons, 2, (V[]){v_x_2413, v_t_2419});
    }
    case TAG_BadFieldDecl: {
      V v_e_2420 = heff_field(v_x21_2411, 0);
      heff_take_n(v_x21_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_249_24At, 2);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2420;
      args[1] = v_acc_2410;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args) {
  V v_x2_2422 = args[0];
  V v_acc_2423 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_At: {
    V v_x21_2424 = heff_field(v_x2_2422, 0);
    heff_take_n(v_x2_2422, 1ULL, 2);
    switch (heff_tag_of(v_x21_2424)) {
    case TAG_TagVariant: {
      V v_args_2428 = heff_field(v_x21_2424, 2);
      heff_take_n(v_x21_2424, 4ULL, 3);
      return ({ V a_0 = heff_get_n(v_r_240, 2, 4); V a_1 = v_args_2428; V a_2 = v_acc_2423; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2428); r_; });
    }
    case TAG_BadVariant: {
      V v_e_2429 = heff_field(v_x21_2424, 0);
      heff_take_n(v_x21_2424, 1ULL, 1);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2429;
      args[1] = v_acc_2423;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2424);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsDeclF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsDeclF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x21_243, 0);
      V v_ty_248 = heff_field(v_x21_243, 3);
      V v_eqs_249 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 25ULL, 5);
      V v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_eqs_249; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_eqs_249); r_; });
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_ty_248, v_t_2420}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_f_245, v_t_2421});
    }
    case TAG_DeclDefine: {
      V v_x_2422 = heff_field(v_x21_243, 0);
      V v_ps_2424 = heff_field(v_x21_243, 2);
      V v_u_2425 = heff_field(v_x21_243, 3);
      V v_body_2426 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 29ULL, 5);
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2426, v_acc_242}));
      V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_u_2425, v_t_2427}));
      V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2424; V a_2 = v_t_2428; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2424); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2422, v_t_2441});
    }
    case TAG_DeclTheory: {
      V v_x_2442 = heff_field(v_x21_243, 0);
      V v_ps_2444 = heff_field(v_x21_243, 2);
      V v_body_2445 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2445, v_acc_242}));
      V v_t_2459 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2444; V a_2 = v_t_2446; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2444); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2442, v_t_2459});
    }
    case TAG_DeclPrimitive: {
      V v_x_2460 = heff_field(v_x21_243, 0);
      V v_t_2462 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2462, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2460, v_t_2463});
    }
    case TAG_DeclTest: {
      V v_x_2464 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 2);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2464, v_acc_242});
    }
    case TAG_DeclWatch: {
      V v_e_2466 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2466, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsDeclF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_a_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2412 = heff_field(v_m_2410, 0);
    V v_ru_24m_2410_24At = heff_take_reuse_n(v_m_2410, 1ULL, 2);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_ps_2416 = heff_field(v_x21_2412, 2);
      V v_rhs_2417 = heff_field(v_x21_2412, 3);
      heff_take_n(v_x21_2412, 13ULL, 4);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_rhs_2417, v_a_2411}));
      V v_t_2419 = ({ V a_0 = v_ps_2416; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a_0, a_1)); heff_drop(v_ps_2416); r_; });
      return heff_tag_at_n(v_ru_24m_2410_24At, TAG_Cons, 2, (V[]){v_f_2414, v_t_2419});
    }
    default: return heff_nomatch(v_x21_2412);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args) {
  V v_m_2429 = args[0];
  V v_a_2430 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2429)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_m_2429, 0);
    V v_ru_24m_2429_24At = heff_take_reuse_n(v_m_2429, 1ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_ExplicitParam: {
      V v_x_2433 = heff_field(v_x21_2431, 0);
      V v_t_2435 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 5ULL, 3);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2435, v_a_2430}));
      return heff_tag_at_n(v_ru_24m_2429_24At, TAG_Cons, 2, (V[]){v_x_2433, v_t_2436});
    }
    case TAG_ImplicitParam: {
      V v_x_2437 = heff_field(v_x21_2431, 0);
      V v_t_2439 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 5ULL, 3);
      V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2439, v_a_2430}));
      return heff_tag_at_n(v_ru_24m_2429_24At, TAG_Cons, 2, (V[]){v_x_2437, v_t_2440});
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_m_2429);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args) {
  V v_m_2447 = args[0];
  V v_a_2448 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2447)) {
  case TAG_At: {
    V v_x21_2449 = heff_field(v_m_2447, 0);
    V v_ru_24m_2447_24At = heff_take_reuse_n(v_m_2447, 1ULL, 2);
    switch (heff_tag_of(v_x21_2449)) {
    case TAG_ExplicitParam: {
      V v_x_2451 = heff_field(v_x21_2449, 0);
      V v_t_2453 = heff_field(v_x21_2449, 2);
      heff_take_n(v_x21_2449, 5ULL, 3);
      V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2453, v_a_2448}));
      return heff_tag_at_n(v_ru_24m_2447_24At, TAG_Cons, 2, (V[]){v_x_2451, v_t_2454});
    }
    case TAG_ImplicitParam: {
      V v_x_2455 = heff_field(v_x21_2449, 0);
      V v_t_2457 = heff_field(v_x21_2449, 2);
      heff_take_n(v_x21_2449, 5ULL, 3);
      V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2457, v_a_2448}));
      return heff_tag_at_n(v_ru_24m_2447_24At, TAG_Cons, 2, (V[]){v_x_2455, v_t_2458});
    }
    default: return heff_nomatch(v_x21_2449);
    }
  }
  default: return heff_nomatch(v_m_2447);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str15, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str16, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str17, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str18, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str19, 0, "");
Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry, 9, 0};

V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(V v_tag_240, V v_x2_241, V v_acc_242, V v_n_243, V v_acc_244, V v_n_245, V v_acc_246, V v_x2_247, V v_acc_248) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297: ;
    heff_drop(v_n_243);
    heff_drop(v_acc_244);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_PiNamed: {
      V v_x_249 = heff_field(v_x2_241, 0);
      V v_t_2411 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 5ULL, 3);
      heff_drop(v_n_245);
      heff_drop(v_acc_246);
      heff_drop(v_x2_247);
      heff_drop(v_acc_248);
      V v_t_2412 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2411, v_acc_242));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_t_2412});
    }
    case TAG_PiImplicit: {
      V v_x_2413 = heff_field(v_x2_241, 0);
      V v_t_2416 = heff_field(v_x2_241, 3);
      V v_d_2417 = heff_field(v_x2_241, 4);
      heff_take_n(v_x2_241, 25ULL, 5);
      heff_drop(v_n_245);
      heff_drop(v_acc_246);
      heff_drop(v_x2_247);
      heff_drop(v_acc_248);
      V v_acc_2419;
      switch (heff_tag_of(v_d_2417)) {
      case TAG_Nothing: {
        v_acc_2419 = v_acc_242;
        break;
      }
      case TAG_Just: {
        V v_c_2418 = heff_field(v_d_2417, 0);
        heff_take_n(v_d_2417, 1ULL, 1);
        v_acc_2419 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_c_2418, v_acc_242));
        break;
      }
      default: heff_nomatch(v_d_2417);
      }
      V v_t_2420 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2416, v_acc_2419));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_t_2420});
    }
    case TAG_PiInstance: {
      V v_x_2421 = heff_field(v_x2_241, 0);
      V v_t_2424 = heff_field(v_x2_241, 3);
      heff_take_n(v_x2_241, 9ULL, 4);
      heff_drop(v_n_245);
      heff_drop(v_acc_246);
      heff_drop(v_x2_247);
      heff_drop(v_acc_248);
      V v_t_2425 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2424, v_acc_242));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2421, v_t_2425});
    }
    case TAG_PiAnon: {
      V v_d_2426 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
      V t_1 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str1);
      V t_3 = v_d_2426;
      V t_4 = v_acc_242;
      V t_5 = v_n_245;
      V t_6 = v_acc_246;
      V t_7 = v_x2_247;
      V t_8 = v_acc_248;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_n_243 = t_3;
      v_acc_244 = t_4;
      v_n_245 = t_5;
      v_acc_246 = t_6;
      v_x2_247 = t_7;
      v_acc_248 = t_8;
      goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156: ;
    switch (heff_tag_of(v_n_243)) {
    case TAG_At: {
      V v_n1_2427 = heff_field(v_n_243, 0);
      heff_take_n(v_n_243, 1ULL, 2);
      switch (heff_tag_of(v_n1_2427)) {
      case TAG_TPi: {
        V v_b_2429 = heff_field(v_n1_2427, 0);
        V v_cod_2430 = heff_field(v_n1_2427, 1);
        heff_take_n(v_n1_2427, 3ULL, 2);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        V v_t_2431 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_cod_2430, v_acc_244));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297);
        V t_1 = v_b_2429;
        V t_2 = v_t_2431;
        V t_3 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str2);
        V t_4 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str3);
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297;
      }
      case TAG_TSig: {
        V v_fs_2432 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return (g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(v_fs_2432, v_acc_244));
      }
      case TAG_TSum: {
        V v_vs_2433 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return ({ V a_0 = v_vs_2433; V a_1 = v_acc_244; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(a_0, a_1)); heff_drop(v_vs_2433); r_; });
      }
      case TAG_TType: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TInt: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TFloat: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TString: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TRune: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TArray: {
        V v_a_2434 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_a_2434;
        V t_4 = v_acc_244;
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      case TAG_TFixed: {
        heff_take_n(v_n1_2427, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return v_acc_244;
      }
      case TAG_TInf: {
        V v_i_2436 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str4);
        V t_4 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str5);
        V t_5 = v_i_2436;
        V t_6 = v_acc_244;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_TChk: {
        V v_c_2437 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str6);
        V t_4 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str7);
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_c_2437;
        V t_8 = v_acc_244;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_TNominal: {
        V v_t_2438 = heff_field(v_n1_2427, 0);
        heff_take_n(v_n1_2427, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2438;
        V t_4 = v_acc_244;
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      default: return heff_nomatch(v_n1_2427);
      }
    }
    default: return heff_nomatch(v_n_243);
    }
  }
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2439 = heff_field(v_n_245, 0);
      V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 1ULL, 2);
      switch (heff_tag_of(v_n1_2439)) {
      case TAG_IVar: {
        V v_x_2441 = heff_field(v_n1_2439, 0);
        heff_take_n(v_n1_2439, 1ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        return heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_x_2441, v_acc_246});
      }
      case TAG_IInt: {
        heff_take_n(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IFloat: {
        heff_take_na(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IString: {
        heff_take_n(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IBytes: {
        heff_take_n(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IPrim: {
        heff_take_n(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IRune: {
        heff_take_n(v_n1_2439, 0ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_IApp: {
        V v_h_2448 = heff_field(v_n1_2439, 0);
        V v_args_2449 = heff_field(v_n1_2439, 1);
        heff_take_n(v_n1_2439, 3ULL, 2);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V v_acc_2450 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(v_args_2449, v_acc_246));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_h_2448;
        V t_6 = v_acc_2450;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IAnn: {
        V v_c_2451 = heff_field(v_n1_2439, 0);
        V v_t_2452 = heff_field(v_n1_2439, 1);
        heff_take_n(v_n1_2439, 3ULL, 2);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V v_acc_2453 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2452, v_acc_246));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str8);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str9);
        V t_7 = v_c_2451;
        V t_8 = v_acc_2453;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_ISpec: {
        V v_a_2454 = heff_field(v_n1_2439, 0);
        V v_v_2457 = heff_field(v_n1_2439, 3);
        heff_take_n(v_n1_2439, 9ULL, 4);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V v_acc_2458 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_v_2457, v_acc_246));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_a_2454;
        V t_6 = v_acc_2458;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IUpdate: {
        V v_a_2459 = heff_field(v_n1_2439, 0);
        V v_fs_2460 = heff_field(v_n1_2439, 1);
        heff_take_n(v_n1_2439, 3ULL, 2);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V v_acc_2461 = ({ V a_0 = v_fs_2460; V a_1 = v_acc_246; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a_0, a_1)); heff_drop(v_fs_2460); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_a_2459;
        V t_6 = v_acc_2461;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IAnnLam: {
        V v_x_2462 = heff_field(v_n1_2439, 0);
        V v_t_2464 = heff_field(v_n1_2439, 2);
        V v_b_2465 = heff_field(v_n1_2439, 3);
        heff_take_n(v_n1_2439, 13ULL, 4);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        V v_acc_2466 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_b_2465, v_acc_246));
        V v_t_2467 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2464, v_acc_2466));
        return heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_x_2462, v_t_2467});
      }
      case TAG_IInvalid: {
        heff_take_n(v_n1_2439, 0ULL, 3);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        return v_acc_246;
      }
      case TAG_INominal: {
        V v_i_2471 = heff_field(v_n1_2439, 0);
        heff_take_n(v_n1_2439, 1ULL, 1);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_i_2471;
        V t_6 = v_acc_246;
        V t_7 = v_x2_247;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_ILitEq: {
        V v_x_2472 = heff_field(v_n1_2439, 0);
        V v_eq_2474 = heff_field(v_n1_2439, 2);
        V v_lit_2475 = heff_field(v_n1_2439, 3);
        heff_take_n(v_n1_2439, 13ULL, 4);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        V v_t_2476 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_lit_2475, v_acc_246));
        return heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_x_2472, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2474, v_t_2476})});
      }
      case TAG_ILazy: {
        V v_c_2477 = heff_field(v_n1_2439, 0);
        heff_take_n(v_n1_2439, 1ULL, 1);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str10);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str11);
        V t_7 = v_c_2477;
        V t_8 = v_acc_246;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_ITuple: {
        V v_cs_2478 = heff_field(v_n1_2439, 0);
        heff_take_n(v_n1_2439, 1ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_247);
        heff_drop(v_acc_248);
        heff_drop_cell(v_ru_24n_245_24At, 2);
        V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2478));
        return ({ V a_0 = v_acc_246; V a_1 = v_t_2479; V r_ = (g_list_2efoldl_24s1437740164x269163243(a_0, a_1)); heff_drop(v_t_2479); r_; });
      }
      default: return heff_nomatch(v_n1_2439);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291: ;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_At: {
      V v_x21_2480 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24At = heff_take_reuse_n(v_x2_247, 1ULL, 2);
      switch (heff_tag_of(v_x21_2480)) {
      case TAG_CInf: {
        V v_i_2482 = heff_field(v_x21_2480, 0);
        heff_take_n(v_x21_2480, 1ULL, 1);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_i_2482;
        V t_6 = v_acc_248;
        V t_7 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str12);
        V t_8 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str13);
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CType: {
        V v_t_2483 = heff_field(v_x21_2480, 0);
        heff_take_n(v_x21_2480, 1ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2483;
        V t_4 = v_acc_248;
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str14);
        V t_8 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str15);
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      case TAG_CLam: {
        V v_x_2484 = heff_field(v_x21_2480, 0);
        V v_b_2486 = heff_field(v_x21_2480, 2);
        heff_take_n(v_x21_2480, 5ULL, 3);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        V v_cell_2487 = heff_tag_at_n(v_ru_24x2_247_24At, TAG_Cons, 2, (V[]){v_x_2484, heff_hole()});
        V v_u_2488 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_2486, v_acc_248, heff_dup(v_cell_2487)));
        heff_drop(v_u_2488);
        return v_cell_2487;
      }
      case TAG_CImplicitLam: {
        V v_x_2489 = heff_field(v_x21_2480, 0);
        V v_b_2491 = heff_field(v_x21_2480, 2);
        heff_take_n(v_x21_2480, 5ULL, 3);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        V v_cell_2492 = heff_tag_at_n(v_ru_24x2_247_24At, TAG_Cons, 2, (V[]){v_x_2489, heff_hole()});
        V v_u_2493 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_2491, v_acc_248, heff_dup(v_cell_2492)));
        heff_drop(v_u_2493);
        return v_cell_2492;
      }
      case TAG_CAnnLam: {
        V v_x_2494 = heff_field(v_x21_2480, 0);
        V v_t_2496 = heff_field(v_x21_2480, 2);
        V v_b_2497 = heff_field(v_x21_2480, 3);
        heff_take_n(v_x21_2480, 13ULL, 4);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        V v_acc_2498 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2497, v_acc_248));
        V v_t_2499 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2496, v_acc_2498));
        return heff_tag_at_n(v_ru_24x2_247_24At, TAG_Cons, 2, (V[]){v_x_2494, v_t_2499});
      }
      case TAG_CTag: {
        V v_args_24102 = heff_field(v_x21_2480, 2);
        heff_take_n(v_x21_2480, 4ULL, 3);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        return ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_24102; V a_2 = v_acc_248; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_24102); r_; });
      }
      case TAG_CStruct: {
        V v_fs_24103 = heff_field(v_x21_2480, 0);
        heff_take_n(v_x21_2480, 1ULL, 1);
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        return (g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_24103, v_acc_248));
      }
      case TAG_CMatch: {
        V v_s_24104 = heff_field(v_x21_2480, 0);
        V v_alts_24105 = heff_field(v_x21_2480, 1);
        heff_take_n(v_x21_2480, 3ULL, 2);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V v_acc_24106 = ({ V a_0 = v_alts_24105; V a_1 = v_acc_248; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_24105); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_s_24104;
        V t_6 = v_acc_24106;
        V t_7 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str16);
        V t_8 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str17);
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CLetIn: {
        V v_rhs_24107 = heff_field(v_x21_2480, 0);
        V v_a_24108 = heff_field(v_x21_2480, 1);
        heff_take_n(v_x21_2480, 3ULL, 2);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V v_acc_24114;
        switch (heff_tag_of(v_a_24108)) {
        case TAG_At: {
          V v_x21_24109 = heff_field(v_a_24108, 0);
          heff_take_n(v_a_24108, 1ULL, 2);
          switch (heff_tag_of(v_x21_24109)) {
          case TAG_MkAlt: {
            V v_p_24111 = heff_field(v_x21_24109, 0);
            V v_b_24112 = heff_field(v_x21_24109, 1);
            heff_take_n(v_x21_24109, 3ULL, 2);
            V v_t_24113 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_24112, v_acc_248));
            v_acc_24114 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_24111, v_t_24113));
            break;
          }
          default: heff_nomatch(v_x21_24109);
          }
          break;
        }
        default: heff_nomatch(v_a_24108);
        }
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_rhs_24107;
        V t_6 = v_acc_24114;
        V t_7 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str18);
        V t_8 = ((V)&g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_str19);
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CLocal: {
        V v_body_24115 = heff_field(v_x21_2480, 0);
        V v_ds_24116 = heff_field(v_x21_2480, 1);
        heff_take_n(v_x21_2480, 3ULL, 2);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V v_acc_24117 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_24116; V a_2 = v_acc_248; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_24116); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_body_24115;
        V t_8 = v_acc_24117;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_CAbandon: {
        heff_drop(v_x2_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_n_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        return v_acc_248;
      }
      case TAG_CNominal: {
        V v_c_24118 = heff_field(v_x21_2480, 0);
        heff_take_n(v_x21_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_247_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_x2_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_n_245;
        V t_6 = v_acc_246;
        V t_7 = v_c_24118;
        V t_8 = v_acc_248;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_n_245 = t_5;
        v_acc_246 = t_6;
        v_x2_247 = t_7;
        v_acc_248 = t_8;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      default: return heff_nomatch(v_x21_2480);
      }
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_a_246)));
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 3);
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_248, v_acc_241));
        v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_249});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2410 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2411;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkSegment: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_245)));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411 = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2erenameAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameAlt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameAlt(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_xs_246 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_p_244)));
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_take_field(v_r_240, 0)}));
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_b_245}), v_sp_243});
      } else {
        heff_drop(v_t_248);
        V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_245}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_249}), v_sp_243});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameAlt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameField(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_ysp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_248 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_246}));
      V v_t_2411;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 5);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_c_249 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_y_244, v_ysp_245, v_t_248, v_t_2411}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2412}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_t_2413}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameField(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(V v_lit_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_2414;
    switch (heff_tag_of(v_m_243)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_m_243, 0);
      heff_take_n(v_m_243, 1ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 3);
        v_t_2414 = heff_strEq_lent(v_lit_240, v_a_248, 2);
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 3);
        v_t_2414 = heff_strEq_lent(v_lit_240, v_a_2411, 2);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_m_243);
    }
    V v_t_2415;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_f_241);
      heff_drop(v_t_2414);
      v_t_2415 = v_rest_244;
    } else {
      heff_drop(v_t_2414);
      v_t_2415 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(v_lit_240, v_f_241, v_rest_244));
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameTypF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameTypF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24TPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2erenamePi(heff_dup(v_r_240), heff_dup(v_b_244)));
      V v_x_247 = heff_take_field(v_r_240, 0);
      V v_t_2424;
      switch (heff_tag_of(v_b_244)) {
      case TAG_PiNamed: {
        V v_y_248 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 3);
        if (heff_strEq_c(v_x_247, v_y_248)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiImplicit: {
        V v_y_2412 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 5);
        if (heff_strEq_c(v_x_247, v_y_2412)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiInstance: {
        V v_y_2418 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 4);
        if (heff_strEq_c(v_x_247, v_y_2418)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_244, 0ULL, 1);
        heff_drop(v_x_247);
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TPi, TAG_TPi, 2, (V[]){v_t_246, v_t_2424}), v_sp_243});
    }
    case TAG_TSig: {
      V v_fs_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSig = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameField_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2427 = (g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(v_r_240, v_t_2426, v_fs_2425));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSig, TAG_TSig, 1, (V[]){v_t_2427}), v_sp_243});
    }
    case TAG_TSum: {
      V v_vs_2428 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSum = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameTypF_lam0, 1, 1, (V[]){v_r_240}), v_vs_2428));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSum, TAG_TSum, 1, (V[]){v_t_2438}), v_sp_243});
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TArray: {
      V v_a_2439 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TArray = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_a_2439}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TArray, TAG_TArray, 1, (V[]){v_t_2440}), v_sp_243});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInf: {
      V v_i_2442 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2442}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TInf, TAG_TInf, 1, (V[]){v_t_2443}), v_sp_243});
    }
    case TAG_TChk: {
      V v_c_2444 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TChk = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2444}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TChk, TAG_TChk, 1, (V[]){v_t_2445}), v_sp_243});
    }
    case TAG_TNominal: {
      V v_t_2446 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2446}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TNominal, TAG_TNominal, 1, (V[]){v_t_2447}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameTypF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args) {
  V v_x2_2429 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_At: {
    V v_x21_2430 = heff_field(v_x2_2429, 0);
    V v_sp_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24At = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_TagVariant: {
      V v_t_2432 = heff_field(v_x21_2430, 0);
      V v_tsp_2433 = heff_field(v_x21_2430, 1);
      V v_args_2434 = heff_field(v_x21_2430, 2);
      heff_take_n(v_x21_2430, 7ULL, 3);
      V v_t_2435 = (g_list_2emap(heff_get_n(v_r_240, 4, 5), v_args_2434));
      return heff_tag_at_n(v_ru_24x2_2429_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_2432, v_tsp_2433, v_t_2435}), v_sp_2431});
    }
    case TAG_BadVariant: {
      V v_e_2436 = heff_field(v_x21_2430, 0);
      heff_take_n(v_x21_2430, 1ULL, 1);
      V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2436}));
      return heff_tag_at_n(v_ru_24x2_2429_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_t_2437}), v_sp_2431});
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eanyIn_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2eanyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eanyIn(V v_c_240, V v_n_241, V v_a_242) {
top: ;
  V v_ys_243 = (g_list_2emap_24f1539731936x1117725130(((V)&g_heff_2eelab_2eclauses_2eanyIn_str0), MK_INT(0LL), v_n_241));
  V v_xs_244 = heff_take_field(v_a_242, 0);
  V v_t_245 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_244)));
  V v_t_246 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_244));
  V v_t_247 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_243, v_t_246));
  V v_pats_248 = (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_247));
  return ({ V rv_0 = v_pats_248; V rr_ = heff_rec_reuse_nf(v_a_242, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eanyIn(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagArmStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagArmStep_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagArmStep(V v_c_240, V v_col_241, V v_t_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagArmStep_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_t_242)}), heff_dup(heff_rfield(v_col_241, 2))));
    V v_t_247 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(v_t_242), NTAG(TAG_False), heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, v_t_246})});
    V v_t_248 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_col_241, 0), heff_dup(heff_rfield(v_t_242, 0)), v_t_247));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_take_field(v_col_241, 1)});
    return ({ V rv_0 = v_t_248; V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_col_241, 4ULL, 3, shape_arms__order__anys, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_arm_2410 = heff_field(v_x5_244, 0);
    heff_drop(v_c_240);
    V v_t_2411 = heff_dup(heff_rfield(v_arm_2410, 1));
    V v_t_2414 = heff_bool(((heff_dup(v_t_2411) == NTAG(TAG_True)) || ({ V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_arm_2410, 0)), 1, 4); int c_ = !heff_intEq_c(heff_dup(heff_rfield(v_t_242, 1)), heff_dup(v_t_2412)); heff_drop(v_t_2412); c_; })));
    heff_drop(v_t_2411);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_dup(heff_rfield(v_arm_2410, 2))});
    V v_t_2416 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(heff_rfield(v_arm_2410, 0)), v_t_2414, v_t_2415});
    V v_t_2417 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_col_241, 0), heff_get_n(v_t_242, 0, 4), v_t_2416));
    return ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_col_241, 6ULL, 3, shape_arms__order__anys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagArmStep(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, heff_get_n(v_t_242, 1, 4), v_a_245));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColGo_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2etagColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColGo_entry, 4, 0};

V g_heff_2eelab_2eclauses_2etagColGo(V v_c_240, V v_v_241, V v_col_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    return v_col_242;
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(heff_rfield(v_r_244, 0)), heff_dup(v_c_240)));
    V v_t_2411;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_248;
        v_t_2411 = v_p_2410;
      } else {
        heff_drop(v_field_248);
        v_t_2411 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2etagColGo_str0)});
      }
    }
    V v_t_2412 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_v_241); V a_2 = v_col_242; V a_3 = heff_dup(v_r_244); V a_4 = v_t_2411; V r_ = (g_heff_2eelab_2eclauses_2etagColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
    V t_0 = v_c_240;
    V t_1 = v_v_241;
    V t_2 = v_t_2412;
    V t_3 = v_rest_245;
    v_c_240 = t_0;
    v_v_241 = t_1;
    v_col_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2etagColGo(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str0, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str1, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str2, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str3, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str4, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str5, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2esizeOk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esizeOk_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esizeOk(V v_k_240, V v_ty_241, V v_size_242, V v_w_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_249 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_249)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_sp_249});
      V v_t_2412 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_w_243), heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413});
      V v_sp_2415 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str0)}), heff_dup(v_sp_2415)});
      V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2415), v_args_2414));
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2417}), v_sp_2415});
      V v_t_2419 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 6))));
      V v_sp_2420 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(64LL)}), heff_dup(v_sp_2420)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), v_sp_2420});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_args_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2423});
      V v_sp_2425 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str1)}), heff_dup(v_sp_2425)});
      V v_t_2427 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2425), v_args_2424));
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2426, v_t_2427}), v_sp_2425});
      V v_t_2429 = (g_heff_2eelab_2eclauses_2eandC(v_t_2428, v_rest_244, heff_dup(heff_rfield(v_k_240, 6))));
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2418, v_t_2429, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2434 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2434)});
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2435}), v_sp_2434});
      V v_t_2437 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      V v_args_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2438});
      V v_sp_2440 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str2)}), heff_dup(v_sp_2440)});
      V v_t_2442 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2440), v_args_2439));
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, v_t_2442}), v_sp_2440});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2443, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2448 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2448)});
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2449}), v_sp_2448});
      V v_t_2451 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_args_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2452});
      V v_sp_2454 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str3)}), heff_dup(v_sp_2454)});
      V v_t_2456 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2454), v_args_2453));
      V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2455, v_t_2456}), v_sp_2454});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2457, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2462 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2462)});
      V v_t_2464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2463}), v_sp_2462});
      V v_t_2465 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
      V v_args_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_t_2466});
      V v_sp_2468 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str4)}), heff_dup(v_sp_2468)});
      V v_t_2470 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2468), v_args_2467));
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2469, v_t_2470}), v_sp_2468});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2471, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  case TAG_SegmentUtf: {
    V v_ru_24ty_241_24SegmentUtf = heff_take_reuse_n(v_ty_241, 0ULL, 1);
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      heff_drop_cell(v_ru_24ty_241_24SegmentUtf, 1);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_w_243);
      heff_drop_cell(v_ru_24ty_241_24SegmentUtf, 1);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2477 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_241_24SegmentUtf, TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2477)});
      V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2478}), v_sp_2477});
      V v_t_2480 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
      V v_args_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_2481});
      V v_sp_2483 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str5)}), heff_dup(v_sp_2483)});
      V v_t_2485 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2483), v_args_2482));
      V v_t_2486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2485}), v_sp_2483});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2486, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2esizeOk(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efits_str0, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efits_entry, 4, 0};

V g_heff_2eelab_2eclauses_2efits(V v_k_240, V v_off_241, V v_w_242, V v_rest_243) {
top: ;
  V v_t_244 = heff_intAdd(heff_take_field(v_off_241, 0), heff_take_field(v_w_242, 0));
  V v_t_245 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_241, 1, 2), heff_get_n(v_w_242, 1, 2)));
  V v_t_246 = (g_heff_2eelab_2eclauses_2eoffC(heff_rec_n(2, shape_bits__terms, (V[]){v_t_244, v_t_245}), heff_dup(heff_rfield(v_k_240, 6))));
  V v_sp_247 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_248 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 2)});
  V v_t_249 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_247)})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_247}), NTAG(TAG_Nil)});
  V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2410});
  V v_sp_2412 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efits_str0)}), heff_dup(v_sp_2412)});
  V v_t_2414 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2412), v_args_2411));
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_2412});
  return (g_heff_2eelab_2eclauses_2eandC(v_t_2415, v_rest_243, heff_get_n(v_k_240, 6, 7)));
}
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efits(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str0, 9, "bitsIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str1, 10, "bytesIntAt");
Clo g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(V v_lit_240, V v_k_241, V v_off_242, V v_flags_243) {
top: ;
  V v_sp_244 = heff_dup(heff_rfield(v_k_241, 6));
  V v_t_245 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_241, 0)});
  V v_t_246 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_sp_244)})});
  V v_t_247 = (g_heff_2eelab_2eclauses_2eoffC(v_off_242, heff_dup(heff_rfield(v_k_241, 6))));
  V v_t_248 = heff_rec_n(2, shape_bits__terms, (V[]){v_lit_240, NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2eelab_2eclauses_2eoffC(v_t_248, heff_dup(heff_rfield(v_k_241, 6))));
  V v_sp_2410 = heff_dup(heff_rfield(v_k_241, 6));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_flags_243}), heff_dup(v_sp_2410)});
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_sp_2410});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2413})});
  V v_args_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_244}), v_t_2414});
  V v_sp_2416 = heff_take_field(v_k_241, 6);
  V v_t_2417 = heff_get_n(v_k_241, 1, 7);
  V v_t_2418;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2418 = ((V)&g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str0);
  } else {
    heff_drop(v_t_2417);
    v_t_2418 = ((V)&g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str1);
  }
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2418}), heff_dup(v_sp_2416)});
  V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2416), v_args_2415));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_2416});
}
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ebinTest_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ebinTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTest_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebinTest(V v_k_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2eelab_2eclauses_2ebinTest_lam0, 4, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinTest(a[0]);
}
V g_heff_2eelab_2eclauses_2ebinTest_lam0(V self, V *args) {
  V v_env_241 = args[0];
  V v_i_242 = args[1];
  V v_off_243 = args[2];
  V v_segs_244 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2eelab_2eclauses_2ebinTest(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_245; V a_1 = v_k_240; V a_2 = v_env_241; V a_3 = v_i_242; V a_4 = v_off_243; V a_5 = v_segs_244; V r_ = (g_heff_2eelab_2eclauses_2ebinTestGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_segs_244); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str3, 0, "");

HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V v_s_240, V v_ty_241, V v_size_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_244 = heff_field(v_v_243, 0);
        heff_take_n(v_v_243, 1ULL, 2);
        switch (heff_tag_of(v_v1_244)) {
        case TAG_PatVar: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          heff_take_n(v_v1_244, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          heff_take_n(v_v1_244, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          V v_n_2413 = heff_field(v_v1_244, 0);
          heff_take_n(v_v1_244, 1ULL, 1);
          V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_t_2416 = heff_intAdd(heff_intMod(v_n_2413, v_t_2414), v_t_2415);
          V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_b_2418 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_2416, v_t_2417), ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str0)));
          V v_t_2419 = heff_intMod(heff_get_n(v_s_240, 3, 5), MK_INT(2LL));
          V v_f_2421;
          if ((heff_unbox_word(v_t_2419) == ((int64_t)1ULL))) {
            v_f_2421 = ({ V a_0 = v_b_2418; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2418); r_; });
          } else {
            v_f_2421 = v_b_2418;
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_PatFloat: {
          heff_take_na(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatBinary: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          heff_take_n(v_v1_244, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          heff_take_n(v_v1_244, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_244)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeNumber: {
      V v_m_2431 = heff_field(v_size_242, 0);
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_2432 = heff_field(v_v_243, 0);
        heff_take_n(v_v_243, 1ULL, 2);
        switch (heff_tag_of(v_v1_2432)) {
        case TAG_PatVar: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          heff_take_n(v_v1_2432, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          heff_take_n(v_v1_2432, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          V v_n_2441 = heff_field(v_v1_2432, 0);
          heff_take_n(v_v1_2432, 1ULL, 1);
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2431)));
          V v_t_2443 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2431)));
          V v_t_2444 = heff_intAdd(heff_intMod(v_n_2441, v_t_2442), v_t_2443);
          V v_t_2445 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2431)));
          V v_b_2446 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(heff_dup(v_m_2431), MK_INT(8LL)), heff_intMod(v_t_2444, v_t_2445), ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str2)));
          V v_t_2447 = heff_intMod(heff_get_n(v_s_240, 3, 5), MK_INT(2LL));
          V v_f_2449;
          if ((heff_unbox_word(v_t_2447) == ((int64_t)1ULL))) {
            v_f_2449 = ({ V a_0 = v_b_2446; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2446); r_; });
          } else {
            v_f_2449 = v_b_2446;
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2449}});
        }
        case TAG_PatFloat: {
          heff_take_na(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatBinary: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          heff_take_n(v_v1_2432, 0ULL, 1);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          heff_take_n(v_v1_2432, 0ULL, 3);
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_2432)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeName: {
      heff_drop_rec(v_s_240, 5);
      heff_drop(v_v_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_size_242)}});
    }
  }
  case TAG_SegmentBinary: {
    heff_drop_rec(v_s_240, 5);
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_2462 = heff_field(v_v_243, 0);
        heff_take_n(v_v_243, 1ULL, 2);
        switch (heff_tag_of(v_v1_2462)) {
        case TAG_PatVar: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          heff_take_n(v_v1_2462, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          heff_take_n(v_v1_2462, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatFloat: {
          heff_take_na(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          V v_str_2473 = heff_field(v_v1_2462, 0);
          heff_take_n(v_v1_2462, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_str_2473}});
        }
        case TAG_PatBinary: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          heff_take_n(v_v1_2462, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          heff_take_n(v_v1_2462, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_2462)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeNumber: {
      heff_drop(v_v_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeName: {
      heff_drop(v_v_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_size_242)}});
    }
  }
  case TAG_SegmentBits: {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_v_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SegmentFloat: {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_v_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SegmentUtf: {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_v_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_ty_241)}});
  }
}
Clo g_heff_2eelab_2eclauses_2esegBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegBind_entry, 11, 0};

V g_heff_2eelab_2eclauses_2esegBind(V v_b_240, V v_k_241, V v_env_242, V v_i_243, V v_x5_244, V v_off_245, V v_s_246, V v_rest_247, V v_body_248, V v_w_249, V v_x11_2410) {
top: ;
  switch (heff_tag_of(v_x11_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_241, 7);
    heff_drop_rec(v_s_246, 5);
    V v_t_2411 = heff_intAdd(heff_take_field(v_off_245, 0), heff_take_field(v_w_249, 0));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_245, 1, 2), heff_get_n(v_w_249, 1, 2)));
    return heff_tail(heff_get_n(v_b_240, 0, 1), 6, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_x5_244, heff_rec_n(2, shape_bits__terms, (V[]){v_t_2411, v_t_2412}), v_rest_247, v_body_248});
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x11_2410, 0);
    V v_ru_24x11_2410_24Just = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_b_240, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop(v_env_242);
      heff_drop(v_i_243);
      heff_drop_rec(v_off_245, 2);
      heff_drop_rec(v_s_246, 5);
      heff_drop(v_rest_247);
      heff_drop_rec(v_w_249, 2);
      heff_drop(v_x_2413);
      heff_drop_cell(v_ru_24x11_2410_24Just, 1);
      return v_body_248;
    }
    case TAG_Cons: {
      V v_y_2414 = heff_field(v_x5_244, 0);
      V v_ys_2415 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_rhs_2416 = (g_heff_2eelab_2eclauses_2esegRead(heff_dup(v_k_241), heff_dup(v_off_245), heff_dup(v_w_249), heff_dup(v_s_246), heff_dup(heff_rfield(v_s_246, 1)), heff_get_n(v_s_246, 2, 5)));
      V v_t_2417 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, heff_dup(v_y_2414)}), v_env_242});
      V v_t_2418 = heff_intAdd(heff_take_field(v_off_245, 0), heff_take_field(v_w_249, 0));
      V v_t_2419 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_245, 1, 2), heff_get_n(v_w_249, 1, 2)));
      V v_body_2420 = heff_tr(heff_call(heff_get_n(v_b_240, 0, 1), 6, (V[]){v_t_2417, heff_intAdd(v_i_243, MK_INT(1LL)), v_ys_2415, heff_rec_n(2, shape_bits__terms, (V[]){v_t_2418, v_t_2419}), v_rest_247, v_body_248}));
      V v_sp_2421 = heff_get_n(v_k_241, 6, 7);
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Just, TAG_PatVar, 1, (V[]){v_y_2414}), heff_dup(v_sp_2421)});
      V v_t_2425;
      switch (heff_tag_of(v_body_2420)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_body_2420, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_body_2420);
      }
      V v_t_2426 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2421, 0)); V rr_ = heff_rec_reuse_nf(v_t_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2422, v_body_2420}), v_t_2426});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2416, v_t_2427}), v_sp_2421});
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x11_2410);
  }
}
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegBind(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str0, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str1, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str3, 1, "_");
Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinBindGo_entry, 8, 0};

V g_heff_2eelab_2eclauses_2ebinBindGo(V v_b_240, V v_k_241, V v_env_242, V v_i_243, V v_ys_244, V v_off_245, V v_x7_246, V v_body_247) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop_rec(v_k_241, 7);
    heff_drop(v_env_242);
    heff_drop(v_i_243);
    heff_drop(v_ys_244);
    heff_drop(v_off_245);
    return v_body_247;
  }
  case TAG_Cons: {
    V v_s_248 = heff_field(v_x7_246, 0);
    V v_rest_249 = heff_field(v_x7_246, 1);
    V v_ru_24x7_246_24Cons = heff_take_reuse_n(v_x7_246, 3ULL, 2);
    V v_t_2410 = heff_dup(heff_rfield(v_s_248, 1));
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_SegmentInteger: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentBinary: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentBits: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentFloat: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentUtf: {
      V v_x11_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2414 = heff_bool((heff_intEq_c_lent(v_x11_2411, MK_INT(8LL), 2) || heff_intEq_c_lent(v_x11_2411, MK_INT(16LL), 2)));
      heff_drop(v_x11_2411);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str0), v_t_2415));
      V v_x_2417 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2416));
      V v_rhs_2418 = (g_heff_2eelab_2eclauses_2eutfWidth(heff_dup(v_k_241), heff_dup(v_off_245), heff_dup(v_s_248), heff_dup(heff_rfield(v_s_248, 1))));
      V v_t_2419 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str1), v_t_2419));
      V v_x_2421 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2420));
      V v_sp_2422 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2421}), heff_dup(v_sp_2422)});
      V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2423}), v_sp_2422});
      V v_t_2425 = heff_tag_at_n(v_ru_24x7_246_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      V v_t_2426 = heff_dup(heff_rfield(v_s_248, 0));
      V v_t_2447;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_At: {
        V v_x11_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 2);
        switch (heff_tag_of(v_x11_2427)) {
        case TAG_PatVar: {
          V v_x_2429 = heff_field(v_x11_2427, 0);
          V v_ru_24x11_2427_24PatVar = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
          if (heff_strEq_c_lent(v_x_2429, ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str2), 2)) {
            heff_drop(v_x_2429);
            heff_drop_cell(v_ru_24x11_2427_24PatVar, 1);
            v_t_2447 = NTAG(TAG_Nothing);
          } else {
            v_t_2447 = heff_tag_at_n(v_ru_24x11_2427_24PatVar, TAG_Just, 1, (V[]){v_x_2429});
          }
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2427, 0ULL, 3);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2427, 0ULL, 3);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatInt: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2427, 0ULL, 1);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2427, 0ULL, 3);
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x11_2427);
        }
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_body_2448 = heff_tr(g_heff_2eelab_2eclauses_2esegBind(v_b_240, heff_dup(v_k_241), v_env_242, v_i_243, v_ys_244, v_off_245, v_s_248, v_rest_249, v_body_247, heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2425}), v_t_2447));
      V v_sp_2449 = heff_get_n(v_k_241, 6, 7);
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2417}), heff_dup(v_sp_2449)});
      V v_t_2453;
      switch (heff_tag_of(v_body_2448)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_body_2448, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_body_2448);
      }
      V v_t_2454 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2449, 0)); V rr_ = heff_rec_reuse_nf(v_t_2453, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2450, v_body_2448}), v_t_2454});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2418, v_t_2455}), v_sp_2449});
    } else {
      heff_drop_cell(v_ru_24x7_246_24Cons, 2);
      heff_drop(v_t_2414);
      V v_t_2456 = (g_heff_2eelab_2eclauses_2ewidthBy(v_env_242, heff_dup(heff_rfield(v_s_248, 4)), heff_dup(heff_rfield(v_s_248, 1)), heff_rfield(v_s_248, 2), heff_rfield(v_s_248, 0)));
      V v_t_2457 = heff_dup(heff_rfield(v_s_248, 0));
      V v_t_2478;
      switch (heff_tag_of(v_t_2457)) {
      case TAG_At: {
        V v_x11_2458 = heff_field(v_t_2457, 0);
        heff_take_n(v_t_2457, 1ULL, 2);
        switch (heff_tag_of(v_x11_2458)) {
        case TAG_PatVar: {
          V v_x_2460 = heff_field(v_x11_2458, 0);
          V v_ru_24x11_2458_24PatVar = heff_take_reuse_n(v_x11_2458, 1ULL, 1);
          if (heff_strEq_c_lent(v_x_2460, ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str3), 2)) {
            heff_drop(v_x_2460);
            heff_drop_cell(v_ru_24x11_2458_24PatVar, 1);
            v_t_2478 = NTAG(TAG_Nothing);
          } else {
            v_t_2478 = heff_tag_at_n(v_ru_24x11_2458_24PatVar, TAG_Just, 1, (V[]){v_x_2460});
          }
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2458, 0ULL, 3);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2458, 0ULL, 3);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatInt: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2458, 0ULL, 3);
          v_t_2478 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x11_2458);
        }
        break;
      }
      default: heff_nomatch(v_t_2457);
      }
      return (g_heff_2eelab_2eclauses_2esegBind(v_b_240, v_k_241, v_env_242, v_i_243, v_ys_244, v_off_245, v_s_248, v_rest_249, v_body_247, v_t_2456, v_t_2478));
    }
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinBindGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epeelAs_24cpr_str0, 1, "_");

HeffT2 g_heff_2eelab_2eclauses_2epeelAs_24cpr(V v_v_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PVar: {
    heff_drop(v_v_240);
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_PTag: {
    heff_drop(v_v_240);
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_PLit: {
    heff_drop(v_v_240);
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_PRec: {
    heff_drop(v_v_240);
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_PAs: {
    V v_x_2410 = heff_field(v_x2_241, 0);
    V v_p_2411 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2415;
    if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2eelab_2eclauses_2epeelAs_24cpr_str0), 2)) {
      heff_drop(v_x_2410);
      v_t_2415 = v_e_242;
    } else {
      if (heff_strEq_c_lent(v_x_2410, v_v_240, 0)) {
        heff_drop(v_x_2410);
        v_t_2415 = v_e_242;
      } else {
        V v_t_2414 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2410, heff_dup(v_v_240)));
        v_t_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 3, 5), 1, (V[]){v_e_242}));
      }
    }
    V t_0 = v_v_240;
    V t_1 = v_p_2411;
    V t_2 = v_t_2415;
    v_v_240 = t_0;
    v_x2_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PBin: {
    heff_drop(v_v_240);
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V v_x1_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_v_243);
      heff_drop(v_vs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{v_x2_241, v_e_242}});
    }
    case TAG_Cons: {
      V v_p_245 = heff_field(v_x2_241, 0);
      V v_ps_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2epeelAs_24cpr(v_v_243, v_p_245, v_e_242));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_p_27_2410 = v_field_248;
        V v_e_27_2411 = v_field_249;
        HeffT2 v_t_2412 = (g_heff_2eelab_2eclauses_2epeelCols_24cpr(v_vs_244, v_ps_246, v_e_27_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_27_2410, v_field_2413}), v_field_2414}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str2, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2, 1, 0};
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246) {
top: ;
  switch (heff_tag_of(v_rest_246)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop_rec(v_sp_242, 2);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_vars_249 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_rows_2441 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0, 1, 2, (V[]){v_c_245, v_vars_243}), v_rest_246));
    V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3, 1, 1, (V[]){heff_dup(v_vars_249)}), v_rows_2441));
    HeffT2 v_t_2444 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, heff_dup(v_sp_242), v_vars_249, v_t_2443));
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        heff_drop_rec(v_sp_242, 2);
        V v_e_2448 = v_field_2446;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2448}});
      } else {
        V v_x_2449 = v_field_2446;
        V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str2)}), heff_dup(v_sp_242)});
        V v_t_2453;
        switch (heff_tag_of(v_x_2449)) {
        case TAG_At: {
          V v_s_2452 = heff_dup(heff_field(v_x_2449, 1));
          v_t_2453 = v_s_2452;
          break;
        }
        default: heff_nomatch(v_x_2449);
        }
        V v_t_2454 = ({ V rv_1 = heff_get_n(v_t_2453, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_242, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2450, v_x_2449}), v_t_2454});
        V v_f_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2456}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_rest_246)}});
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1(V self, V *args) {
  V v_e_2423 = args[0];
  V v_p_2422 = heff_env(self)[0];
  V v_v_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_PVar: {
    V v_x_2424 = heff_field(v_p_2422, 0);
    heff_take_n(v_p_2422, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_2424, ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str1), 2)) {
      heff_drop(v_v_2417);
      heff_drop(v_x_2424);
      return v_e_2423;
    } else {
      if (heff_strEq_c_lent(v_x_2424, v_v_2417, 0)) {
        heff_drop(v_v_2417);
        heff_drop(v_x_2424);
        return v_e_2423;
      } else {
        V v_t_2427 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2424, v_v_2417));
        V f_ = heff_get_n(v_t_2427, 3, 5);
        args[0] = v_e_2423;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2422, 0ULL, 3);
    heff_drop(v_v_2417);
    return v_e_2423;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2422, 0ULL, 1);
    heff_drop(v_v_2417);
    return v_e_2423;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2417);
    return v_e_2423;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2417);
    return v_e_2423;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2417);
    return v_e_2423;
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2(V self, V *args) {
  V v_e_2438 = args[0];
  return v_e_2438;
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0(V self, V *args) {
  V v_row_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_vars_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_pats_2411 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(heff_rfield(v_row_2410, 0))));
  HeffT2 v_t_2412 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
  V v_v_2417;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_v_2416 = v_field_2414;
      v_v_2417 = v_v_2416;
    } else {
      heff_drop(v_field_2414);
      v_v_2417 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str0);
    }
  }
  HeffT2 v_t_2418 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_take_field(v_row_2410, 0), v_c_245));
  V v_t_2439;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_p_2422 = v_field_2420;
      v_t_2439 = heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1, 1, 2, (V[]){v_p_2422, v_v_2417});
    } else {
      heff_drop(v_v_2417);
      heff_drop(v_field_2420);
      v_t_2439 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2_clo);
    }
  }
  V v_rhs_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){heff_get_n(v_row_2410, 1, 2)}));
  return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2411, v_rhs_2440});
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3(V self, V *args) {
  V v_row_2442 = args[0];
  V v_vars_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_249, heff_dup(heff_rfield(v_row_2442, 0)), heff_get_n(v_row_2442, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str1, 1, "_");
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_col_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2enoRecMix_24cpr(heff_dup(v_rows_244), heff_dup(v_c_245)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop_rec(v_col_246, 3);
      V v_e_2411 = v_field_249;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2411}});
    } else {
      V v_x_2412 = v_field_249;
      heff_drop(v_x_2412);
      HeffT2 v_t_2413 = (g_heff_2eelab_2eclauses_2enoLitHere_24cpr(v_sp_242, heff_dup(v_c_245), heff_dup(v_rows_244)));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop_rec(v_col_246, 3);
          V v_e_2417 = v_field_2415;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2417}});
        } else {
          V v_x_2418 = v_field_2415;
          heff_drop(v_x_2418);
          V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_col_246, 1))));
          HeffT2 v_t_2437 = (g_prelude_2etraverse_24s1807059150x502333573_24cpr(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), v_col_246, heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242)}), v_t_2419));
          {
            V v_field_2439 = v_t_2437.f[1];
            int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
            if ((v_tag_2438 == ((int64_t)0ULL))) {
              heff_drop(v_used_240);
              heff_drop(v_bound_241);
              heff_drop(v_sp_242);
              heff_drop(v_vars_243);
              heff_drop(v_rows_244);
              heff_drop(v_c_245);
              V v_e_2441 = v_field_2439;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2441}});
            } else {
              V v_x_2442 = v_field_2439;
              V v_t_2460 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
              HeffT2 v_t_2461 = ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = heff_dup(v_sp_242); V a_3 = heff_dup(v_vars_243); V a_4 = v_rows_244; V a_5 = heff_dup(v_c_245); V a_6 = v_t_2460; HeffT2 r_ = (g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
              {
                V v_field_2463 = v_t_2461.f[1];
                int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                if ((v_tag_2462 == ((int64_t)0ULL))) {
                  heff_drop(v_sp_242);
                  heff_drop(v_vars_243);
                  heff_drop(v_c_245);
                  heff_drop(v_x_2442);
                  V v_e_2465 = v_field_2463;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2465}});
                } else {
                  V v_x_2466 = v_field_2463;
                  HeffT2 v_t_2467 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
                  V v_t_2472;
                  {
                    V v_field_2469 = v_t_2467.f[1];
                    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                    if ((v_tag_2468 == ((int64_t)0ULL))) {
                      V v_v_2471 = v_field_2469;
                      v_t_2472 = v_v_2471;
                    } else {
                      heff_drop(v_field_2469);
                      v_t_2472 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str1);
                    }
                  }
                  V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_t_2472}), heff_dup(v_sp_242)});
                  V v_t_2474 = (g_heff_2eelab_2eclauses_2eappendC(v_x_2442, v_x_2466));
                  V v_f_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2473, v_t_2474}), v_sp_242});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2475}});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_arm_2432 = heff_env(self)[2];
  V v_c_245 = heff_env(self)[3];
  V v_t_2433 = heff_env(self)[4];
  V v_v_2426 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V b_2 = heff_get_n(v_arm_2432, 2, 3); V a_3 = v_c_245; V a_4 = v_t_2433; V a_5 = v_v_2426; V a_6 = v_i_2435; V r_ = (g_heff_2eelab_2eclauses_2earmSub(a_0, a_1, b_2, a_3, a_4, a_5, a_6)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(b_2); r_; });
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0(V self, V *args) {
  V v_t_2420 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_col_246 = heff_env(self)[2];
  V v_used_240 = heff_env(self)[3];
  V v_bound_241 = heff_env(self)[4];
  V v_sp_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2421 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
  V v_v_2426;
  {
    V v_field_2423 = v_t_2421.f[1];
    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
    if ((v_tag_2422 == ((int64_t)0ULL))) {
      V v_v_2425 = v_field_2423;
      v_v_2426 = v_v_2425;
    } else {
      heff_drop(v_field_2423);
      v_v_2426 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str0);
    }
  }
  HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_col_246, 0, 3); V a_1 = heff_rfield(v_t_2420, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_arm_2432;
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      heff_drop_rec(v_t_2420, 4);
      V v_arm_2431 = v_field_2429;
      v_arm_2432 = v_arm_2431;
    } else {
      heff_drop(v_field_2429);
      v_arm_2432 = heff_rec_n(3, shape_row__bad__rows, (V[]){v_t_2420, NTAG(TAG_False), NTAG(TAG_Nil)});
    }
    V v_t_2433 = heff_dup(heff_rfield(v_arm_2432, 0));
    V v_t_2434 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(heff_rfield(v_t_2433, 1))));
    V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1, 1, 6, (V[]){heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_arm_2432), heff_dup(v_c_245), v_t_2433, v_v_2426}), v_t_2434));
    return (g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_c_245, v_arm_2432, v_t_2436));
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2(V self, V *args) {
  V v_row_2443 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2444 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2443, 0, 2), v_c_245));
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_p_2448 = v_field_2446;
      switch (heff_tag_of(v_p_2448)) {
      case TAG_PVar: {
        heff_take_n(v_p_2448, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2448, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2448, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2448, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2448, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2448, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_p_2448);
      }
    } else {
      heff_drop(v_field_2446);
      return NTAG(TAG_True);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str2, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str3, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str4, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str5, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str6, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str7, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str8, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str9, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str10, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str11, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str12, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str13, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str14, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str15, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str16, 5, "False");
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2elitChecks_24cpr(v_sp_242, v_vars_243, v_rows_244, heff_dup(v_c_245), v_l_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_l_246);
      V v_e_2411 = v_field_249;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2411}});
    } else {
      V v_x_2412 = v_field_249;
      heff_drop(v_x_2412);
      V v_vars_2413 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
      HeffT2 v_t_2414 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
      V v_t_2419;
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_v_2418 = v_field_2416;
          v_t_2419 = v_v_2418;
        } else {
          heff_drop(v_field_2416);
          v_t_2419 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str0);
        }
      }
      V v_rows_2420 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_245), v_l_246, v_t_2419, v_rows_244));
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0, 1, 1, (V[]){heff_dup(v_vars_2413)}), v_rows_2420));
      HeffT2 v_t_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), v_vars_2413, v_t_2422));
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_c_245);
          heff_drop(v_l_246);
          V v_e_2427 = v_field_2425;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2427}});
        } else {
          V v_x_2428 = v_field_2425;
          V v_rows_2429 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_245), v_l_246, v_rows_244));
          V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2429));
          HeffT2 v_t_2432 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_t_2431));
          {
            V v_field_2434 = v_t_2432.f[1];
            int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
            if ((v_tag_2433 == ((int64_t)0ULL))) {
              heff_drop(v_sp_242);
              heff_drop(v_vars_243);
              heff_drop(v_c_245);
              heff_drop(v_l_246);
              heff_drop(v_x_2428);
              V v_e_2436 = v_field_2434;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2436}});
            } else {
              V v_x_2437 = v_field_2434;
              HeffT2 v_t_2438 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
              V v_t_2443;
              {
                V v_field_2440 = v_t_2438.f[1];
                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                if ((v_tag_2439 == ((int64_t)0ULL))) {
                  V v_v_2442 = v_field_2440;
                  v_t_2443 = v_v_2442;
                } else {
                  heff_drop(v_field_2440);
                  v_t_2443 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str1);
                }
              }
              V v_t_2463;
              switch (heff_tag_of(v_l_246)) {
              case TAG_At: {
                V v_x11_2444 = heff_dup(heff_field(v_l_246, 0));
                switch (heff_tag_of(v_x11_2444)) {
                case TAG_PatVar: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str2);
                  break;
                }
                case TAG_PatTag: {
                  heff_take_n(v_x11_2444, 0ULL, 3);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str3);
                  break;
                }
                case TAG_PatOp: {
                  heff_take_n(v_x11_2444, 0ULL, 3);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str4);
                  break;
                }
                case TAG_PatInt: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str5);
                  break;
                }
                case TAG_PatFloat: {
                  heff_take_na(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str6);
                  break;
                }
                case TAG_PatString: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str7);
                  break;
                }
                case TAG_PatBinary: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str8);
                  break;
                }
                case TAG_PatRune: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str9);
                  break;
                }
                case TAG_PatRecord: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str10);
                  break;
                }
                case TAG_PatWord: {
                  heff_take_n(v_x11_2444, 0ULL, 1);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str11);
                  break;
                }
                case TAG_PatAs: {
                  heff_take_n(v_x11_2444, 0ULL, 3);
                  v_t_2463 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str12);
                  break;
                }
                default: heff_nomatch(v_x11_2444);
                }
                break;
              }
              default: heff_nomatch(v_l_246);
              }
              V v_t_2464 = (g_heff_2eelab_2eclauses_2elitExpr(heff_dup(v_l_246)));
              V v_t_2467;
              switch (heff_tag_of(v_l_246)) {
              case TAG_At: {
                V v_s_2466 = heff_dup(heff_field(v_l_246, 1));
                v_t_2467 = v_s_2466;
                break;
              }
              default: heff_nomatch(v_l_246);
              }
              V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILitEq, 4, (V[]){v_t_2443, v_sp_242, v_t_2463, v_t_2464}), v_t_2467});
              V v_tsp_2471;
              switch (heff_tag_of(v_l_246)) {
              case TAG_At: {
                V v_s_2470 = heff_dup(heff_field(v_l_246, 1));
                v_tsp_2471 = v_s_2470;
                break;
              }
              default: heff_nomatch(v_l_246);
              }
              V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str13)}), heff_dup(v_tsp_2471)});
              V v_x1_2473 = ({ V a_0 = v_t_2472; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2476;
              switch (heff_tag_of(v_x1_2473)) {
              case TAG_At: {
                V v_s_2475 = heff_field(v_x1_2473, 1);
                heff_take_n(v_x1_2473, 2ULL, 2);
                v_t_2476 = v_s_2475;
                break;
              }
              default: heff_nomatch(v_x1_2473);
              }
              V v_t_2477 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2471, 0)); V rr_ = heff_rec_reuse_nf(v_t_2476, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2478 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str14), v_tsp_2471, NTAG(TAG_Nil)});
              V v_t_2479 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2478, heff_dup(v_t_2477)}), heff_dup(v_x_2428)});
              V v_t_2482;
              switch (heff_tag_of(v_x_2428)) {
              case TAG_At: {
                V v_s_2481 = heff_field(v_x_2428, 1);
                heff_take_n(v_x_2428, 2ULL, 2);
                v_t_2482 = v_s_2481;
                break;
              }
              default: heff_nomatch(v_x_2428);
              }
              V v_t_2483 = ({ V rv_1 = heff_get_n(v_t_2482, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2477, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_tsp_2486;
              switch (heff_tag_of(v_l_246)) {
              case TAG_At: {
                V v_s_2485 = heff_dup(heff_field(v_l_246, 1));
                v_tsp_2486 = v_s_2485;
                break;
              }
              default: heff_nomatch(v_l_246);
              }
              V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str15)}), heff_dup(v_tsp_2486)});
              V v_x1_2488 = ({ V a_0 = v_t_2487; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2491;
              switch (heff_tag_of(v_x1_2488)) {
              case TAG_At: {
                V v_s_2490 = heff_field(v_x1_2488, 1);
                heff_take_n(v_x1_2488, 2ULL, 2);
                v_t_2491 = v_s_2490;
                break;
              }
              default: heff_nomatch(v_x1_2488);
              }
              V v_t_2492 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2486, 0)); V rr_ = heff_rec_reuse_nf(v_t_2491, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2493 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str16), v_tsp_2486, NTAG(TAG_Nil)});
              V v_t_2494 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2493, heff_dup(v_t_2492)}), heff_dup(v_x_2437)});
              V v_t_2497;
              switch (heff_tag_of(v_x_2437)) {
              case TAG_At: {
                V v_s_2496 = heff_field(v_x_2437, 1);
                heff_take_n(v_x_2437, 2ULL, 2);
                v_t_2497 = v_s_2496;
                break;
              }
              default: heff_nomatch(v_x_2437);
              }
              V v_t_2498 = ({ V rv_1 = heff_get_n(v_t_2497, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2492, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2494, v_t_2498}), NTAG(TAG_Nil)});
              V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_t_2483}), v_t_2499});
              V v_t_24103;
              switch (heff_tag_of(v_l_246)) {
              case TAG_At: {
                V v_s_24102 = heff_field(v_l_246, 1);
                heff_take_n(v_l_246, 2ULL, 2);
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_l_246);
              }
              V v_f_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2468, v_t_24100}), v_t_24103});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24104}});
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2413, heff_dup(heff_rfield(v_row_2421, 0)), heff_get_n(v_row_2421, 1, 2)));
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1(V self, V *args) {
  V v_row_2430 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, heff_dup(heff_rfield(v_row_2430, 0)), heff_get_n(v_row_2430, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_fs_246, V v_ys_247, V v_specialized_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2enoRecMix_24cpr(v_rows_244, heff_dup(v_c_245)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_fs_246);
      heff_drop(v_ys_247);
      heff_drop(v_specialized_248);
      V v_e_2413 = v_field_2411;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2413}});
    } else {
      V v_x_2414 = v_field_2411;
      heff_drop(v_x_2414);
      V v_bound_2415 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_bound_241));
      V v_t_2416 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_vars_243)));
      V v_t_2417 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_245), MK_INT(1LL)), heff_dup(v_vars_243)));
      V v_t_2418 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_t_2417));
      V v_vars_2419 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2416, v_t_2418));
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr_lam0, 1, 1, (V[]){heff_dup(v_vars_2419)}), v_specialized_248));
      HeffT2 v_t_2422 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_2415, heff_dup(v_sp_242), v_vars_2419, v_t_2421));
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_c_245);
          heff_drop(v_fs_246);
          heff_drop(v_ys_247);
          V v_e_2426 = v_field_2424;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2426}});
        } else {
          V v_x_2427 = v_field_2424;
          HeffT2 v_t_2428 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
          V v_t_2433;
          {
            V v_field_2430 = v_t_2428.f[1];
            int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
            if ((v_tag_2429 == ((int64_t)0ULL))) {
              V v_v_2432 = v_field_2430;
              v_t_2433 = v_v_2432;
            } else {
              heff_drop(v_field_2430);
              v_t_2433 = ((V)&g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr_str0);
            }
          }
          V v_t_2434 = (g_heff_2eelab_2eclauses_2ezipC(v_fs_246, v_ys_247));
          V v_f_2435 = (g_heff_2eelab_2eclauses_2eletFields(v_sp_242, v_t_2433, v_t_2434, v_x_2427));
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2435}});
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr_lam0(V self, V *args) {
  V v_row_2420 = args[0];
  V v_vars_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2419, heff_dup(heff_rfield(v_row_2420, 0)), heff_get_n(v_row_2420, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str1, 1, "_");

HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244) {
top: ;
  switch (heff_tag_of(v_rows_244)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_vars_243);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_245}});
  }
  case TAG_Cons: {
    V v_row_246 = heff_dup(heff_field(v_rows_244, 0));
    HeffT2 v_t_248 = (g_heff_2eelab_2eclauses_2efindTagLit_24cpr(heff_dup(heff_rfield(v_row_246, 0)), MK_INT(0LL)));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_c_2412 = v_field_2410;
        HeffT2 v_t_2413 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_246, 0, 2), heff_dup(v_c_2412)));
        V v_t_2418;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_p_2417 = v_field_2415;
            v_t_2418 = v_p_2417;
          } else {
            heff_drop(v_field_2415);
            v_t_2418 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str0)});
          }
        }
        return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_2412; V a_6 = v_t_2418; HeffT2 r_ = (g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2418); r_; });
      } else {
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop_tag(v_rows_244, 2);
        heff_drop(v_field_2410);
        V v_t_2419 = (g_heff_2eelab_2eclauses_2ezipC(v_vars_243, heff_take_field(v_row_246, 0)));
        V v_f_2420 = ({ V b_0 = ((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str1); V a_1 = heff_get_n(v_row_246, 1, 2); V a_2 = v_t_2419; V r_ = (g_list_2efoldl_24s901304517x253262467(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2419); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_rows_244)}});
  }
}
V g_heff_2eelab_2eclauses_2edesugarCols_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2edesugarCols_24cpr(V v_params_240, V v_sp_241, V v_rows_242, V v_used_243, V v_cols_244) {
top: ;
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugarCols_24cpr_lam0, 1, 1, (V[]){heff_dup(v_cols_244)}), v_rows_242));
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_243, heff_dup(v_cols_244), heff_dup(v_sp_241), heff_dup(v_cols_244), v_t_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_sp_241);
      heff_drop(v_cols_244);
      V v_e_2411 = v_field_249;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2411}});
    } else {
      V v_x_2412 = v_field_249;
      V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_240));
      V v_t_2414 = (g_heff_2eelab_2eclauses_2edropC(v_t_2413, v_cols_244));
      V v_f_2415 = (g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(v_sp_241, v_x_2412, v_t_2414));
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
    }
  }
}
V g_heff_2eelab_2eclauses_2edesugarCols_24cpr_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_cols_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_cols_244, heff_dup(heff_rfield(v_row_245, 0)), heff_get_n(v_row_245, 1, 2)));
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(heff_rfield(v_x_242, 1)), v_acc_241));
    V v_t_245 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(heff_rfield(v_x_242, 0), v_t_244));
    V t_0 = v_xs_243;
    V t_1 = v_t_245;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str0, 43, "a definition by equations needs an equation");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str1, 11, " pattern(s)");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str2, 6, "` has ");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str3, 19, "every equation of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str4, 18, "the equations of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str5, 37, "` match fewer arguments than it names");
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243) {
top: ;
  HeffT2 v_t_244 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_eqNs_242));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_f_240);
      heff_drop(v_params_241);
      heff_drop(v_sp_243);
      V v_e_248 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_248}});
    } else {
      V v_x_249 = v_field_246;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nil: {
        heff_drop(v_f_240);
        heff_drop(v_params_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_243, ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str0)})}});
      }
      case TAG_Cons: {
        V v_r_2410 = heff_dup(heff_field(v_x_249, 0));
        V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_r_2410, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        HeffT2 v_t_2423 = (g_heff_2eelab_2eclauses_2eforC_24cpr(heff_dup(v_x_249), heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0, 1, 2, (V[]){heff_dup(v_t_2412), heff_dup(v_f_240)})));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_f_240);
            heff_drop(v_params_241);
            heff_drop(v_sp_243);
            heff_drop_tag(v_x_249, 2);
            heff_drop(v_t_2412);
            V v_e_2427 = v_field_2425;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2427}});
          } else {
            V v_x_2428 = v_field_2425;
            heff_drop(v_x_2428);
            V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_241));
            if (heff_intLt_c_lent(v_t_2412, v_t_2429, 2)) {
              heff_drop(v_params_241);
              heff_drop_tag(v_x_249, 2);
              heff_drop(v_t_2412);
              V v_t_2431 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str4), heff_strAppend(v_f_240, ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str5)));
              V v_f_2432 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_243, v_t_2431});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
            } else {
              V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, NTAG(TAG_Nil)});
              V v_t_2434 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_params_241), v_t_2433));
              V v_used_2435 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_249, v_t_2434));
              V v_t_2436 = (g_heff_2eelab_2eclauses_2ecolNames(v_used_2435, heff_dup(v_params_241), heff_dup(v_x_249), MK_INT(0LL), v_t_2412, NTAG(TAG_Nil)));
              return ({ V a_0 = v_params_241; V a_1 = v_sp_243; V a_2 = v_x_249; V a_3 = v_used_2435; V a_4 = v_t_2436; HeffT2 r_ = (g_heff_2eelab_2eclauses_2edesugarCols_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_params_241); r_; });
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x_249)}});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  V v_t_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_2413, 0)));
  if (heff_intEq_c_lent(v_t_2414, v_t_2412, 1)) {
    heff_drop_rec(v_r_2413, 2);
    heff_drop(v_t_2412);
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_2416 = heff_get_n(v_r_2413, 1, 2);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_s_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 2ULL, 2);
      v_t_2419 = v_s_2418;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(heff_intShow(v_t_2412), ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str1));
    V v_t_2421 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str2), v_t_2420));
    V v_t_2422 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2419, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str3), v_t_2421)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
  }
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_243;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(a[0], a[1]);
}