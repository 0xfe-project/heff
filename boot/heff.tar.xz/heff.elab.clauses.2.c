// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CLetIn 34208
#define TAG_CMatch 53053
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_ExplicitParam 63083
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentInteger 22664
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_end 310101
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_size 10026184
#define LBL_sizes 310811820
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_terms 311608737
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_v__len__sizes__used__bound__span[] = {LBL_v, LBL_len, LBL_sizes, LBL_used, LBL_bound, LBL_span};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps_clo;
V g_heff_2eelab_2eclauses_2earmSub(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSub_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSub_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ebinBind(V);
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBind_clo;
V g_heff_2eelab_2eclauses_2ebinBindGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo;
V g_heff_2eelab_2eclauses_2ebinChecks(V, V, V);
V g_heff_2eelab_2eclauses_2ebinChecks_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinChecks_clo;
V g_heff_2eelab_2eclauses_2ebinTest(V);
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTest_clo;
V g_heff_2eelab_2eclauses_2ebinTestGo(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo;
V g_heff_2eelab_2eclauses_2ebinTestOf(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestOf_clo;
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_clo;
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo;
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropAt_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efindTagLit(V, V);
V g_heff_2eelab_2eclauses_2efindTagLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efindTagLit_clo;
V g_heff_2eelab_2eclauses_2efits(V, V, V, V);
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efits_clo;
V g_heff_2eelab_2eclauses_2eforC(V, V);
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eforC_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2elitChecks(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitChecks_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitChecks_clo;
V g_heff_2eelab_2eclauses_2elitExpr(V);
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitExpr_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V, V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1870202557x1229745604(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1870202557x1229745604_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1870202557x1229745604_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enoLitHere(V, V, V);
V g_heff_2eelab_2eclauses_2enoLitHere_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoLitHere_clo;
V g_heff_2eelab_2eclauses_2enoRecMix(V, V);
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoRecMix_clo;
V g_heff_2eelab_2eclauses_2enthC(V, V);
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enthC_clo;
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
V g_heff_2eelab_2eclauses_2epat(V);
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epat_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2erecFieldVar(V, V, V);
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo;
V g_heff_2eelab_2eclauses_2erecSubName(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubName_clo;
V g_heff_2eelab_2eclauses_2erecSubs(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubs_clo;
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_clo;
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameField(V, V);
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameField_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
V g_heff_2eelab_2eclauses_2esegBind(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegBind_clo;
V g_heff_2eelab_2eclauses_2esegRead(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegRead_clo;
V g_heff_2eelab_2eclauses_2esizeOk(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esizeOk_clo;
V g_heff_2eelab_2eclauses_2esoleBin(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_clo;
V g_heff_2eelab_2eclauses_2etagArmStep(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagArmStep_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etraverseC(V, V);
V g_heff_2eelab_2eclauses_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2ewholeBin(V, V);
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewholeBin_clo;
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2eelab_2eclauses_2ezipC(V, V);
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s901304517x253262467(V, V, V);
V g_list_2efoldl_24s901304517x253262467_entry(V self, V *a);
extern Clo g_list_2efoldl_24s901304517x253262467_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1846289357x1055790465(V, V);
V g_list_2emap_24s1846289357x1055790465_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2eelab_2eclauses_2esoleBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esoleBin_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esoleBin(V v_s_240, V v_v_241, V v_ty_242, V v_size_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_At: {
    V v_v1_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24At = heff_take_reuse_n(v_v_241, 1ULL, 2);
    switch (heff_tag_of(v_v1_245)) {
    case TAG_PatVar: {
      V v_x_247 = heff_field(v_v1_245, 0);
      V v_ru_24v1_245_24PatVar = heff_take_reuse_n(v_v1_245, 1ULL, 1);
      switch (heff_tag_of(v_ty_242)) {
      case TAG_SegmentInteger: {
        heff_drop(v_size_243);
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_248 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_248, v_sp_244});
      }
      case TAG_SegmentBinary: {
        switch (heff_tag_of(v_size_243)) {
        case TAG_SizeDefault: {
          heff_drop(v_s_240);
          heff_drop(v_sp_244);
          heff_drop_cell(v_ru_24v_241_24At, 2);
          return heff_tag_at_n(v_ru_24v1_245_24PatVar, TAG_PVar, 1, (V[]){v_x_247});
        }
        case TAG_SizeNumber: {
          heff_take_n(v_size_243, 0ULL, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2410, v_sp_244});
        }
        case TAG_SizeName: {
          V v_ru_24size_243_24SizeName = heff_take_reuse_n(v_size_243, 0ULL, 2);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2413 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24size_243_24SizeName, TAG_PBin, 2, (V[]){v_t_2413, v_sp_244});
        }
        default: return heff_nomatch(v_size_243);
        }
      }
      default: return heff_nomatch(v_ty_242);
      }
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop(v_size_243);
      V v_t_2417 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2417, v_sp_244});
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop(v_size_243);
      V v_t_2421 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2421, v_sp_244});
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2423 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2423, v_sp_244});
    }
    case TAG_PatFloat: {
      heff_take_na(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2425 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2425, v_sp_244});
    }
    case TAG_PatString: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2427 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2427, v_sp_244});
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2429 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2429, v_sp_244});
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2431 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2431, v_sp_244});
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2433 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2433, v_sp_244});
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      heff_drop(v_size_243);
      V v_t_2435 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2435, v_sp_244});
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_245, 0ULL, 3);
      heff_drop(v_size_243);
      V v_t_2439 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2439, v_sp_244});
    }
    default: return heff_nomatch(v_v1_245);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2esoleBin(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eclauses_2eappendC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eclauses_2eappendC_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2eforC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eforC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eforC(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      heff_take_n(v_x1_244, 0ULL, 1);
      V t_0 = v_xs_243;
      V t_1 = v_f_241;
      v_x1_240 = t_0;
      v_f_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eforC(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_entry, 3, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2emapWithIndexC(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry, 4, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2ezipC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ezipC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eclauses_2ezipC_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eallC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eallC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eallC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2edropAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eelab_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24Left = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x1_243_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_246_24Left, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(a[0]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_a_245 = (g_heff_2eelab_2eclauses_2epat(v_a_244));
      switch (heff_tag_of(v_a_245)) {
      case TAG_Left: {
        V v_a_246 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24Left = heff_take_reuse_n(v_a_245, 1ULL, 1);
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_a_243);
        return heff_tag_at_n(v_ru_24a_245_24Left, TAG_Left, 1, (V[]){v_a_246});
      }
      case TAG_Right: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24Right = heff_take_reuse_n(v_a_245, 1ULL, 1);
        V v_x1_248 = (g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(v_xs_242));
        switch (heff_tag_of(v_x1_248)) {
        case TAG_Left: {
          V v_e_249 = heff_field(v_x1_248, 0);
          V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_243);
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_245_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
        }
        case TAG_Right: {
          V v_x_2410 = heff_field(v_x1_248, 0);
          heff_take_n(v_x1_248, 1ULL, 1);
          V v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_247}), v_x_2410});
          return heff_tag_at_n(v_ru_24a_245_24Right, TAG_Right, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x1_248);
        }
      }
      default: return heff_nomatch(v_a_245);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(a[0]);
}
Clo g_heff_2eelab_2eclauses_2elitExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitExpr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2elitExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatTag: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatOp: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatInt: {
      V v_x_2410 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatInt = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x_2410}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatInt, TAG_CInf, 1, (V[]){v_t_2411}), v_sp_242});
    }
    case TAG_PatFloat: {
      double v_x_2412 = heff_tflat_f64(v_x11_241, 0);
      V v_ru_24x11_241_24PatFloat = heff_take_reuse_na(v_x11_241, 0ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatFloat, TAG_CInf, 1, (V[]){v_t_2413}), v_sp_242});
    }
    case TAG_PatString: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatString = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatString, TAG_CInf, 1, (V[]){v_t_2415}), v_sp_242});
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatRune: {
      V v_x_2417 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatRune = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_x_2417}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatRune, TAG_CInf, 1, (V[]){v_t_2418}), v_sp_242});
    }
    case TAG_PatRecord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatAs: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2elitExpr(a[0]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2epatVars(v_t_245));
    V v_t_247 = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatVars_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    return heff_setField(v_d_241, MK_INT(1LL), v_t_243);
  }
  case TAG_PTag: {
    V v_ps_245 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    V v_t_247 = ({ V a_0 = v_ps_245; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_245); r_; });
    return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_PRec: {
    V v_fps_249 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_fps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_249); r_; });
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
  }
  case TAG_PAs: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    V v_p_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_p_2413;
    V t_1 = v_cell_2414;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_PBin: {
    V v_segs_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2418 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2416)));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2418));
    V v_t_2420 = (g_list_2emap_24s939813003x1383013550(v_segs_2416));
    V v_t_2421 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2420));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2419, v_t_2421));
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2422);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatIdents(V v_p_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_247; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_247); r_; });
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_242, 0);
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_t_2411 = ({ V a_0 = v_ps_2410; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2410); r_; });
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_248, v_t_2411});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatBinary: {
      V v_segs_2415 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s1870202557x1229745604(v_segs_2415, v_acc_241);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2417, v_acc_241);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatAs: {
      V v_x_2419 = heff_field(v_p1_242, 0);
      V v_q_2421 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2422 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2419, heff_hole()});
      V v_u_2423 = (g_heff_2eelab_2eclauses_2epatIdents_24dps(v_q_2421, v_acc_241, heff_dup(v_cell_2422)));
      heff_drop(v_u_2423);
      return v_cell_2422;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_TPi: {
      V v_b_245 = heff_field(v_n1_243, 0);
      V v_cod_246 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_cod_246, v_acc_242}));
      return ({ V a_0 = v_r_240; V a_1 = v_b_245; V a_2 = v_t_247; V r_ = (g_heff_2eelab_2eclauses_2epiIdents(a_0, a_1, a_2)); heff_drop(v_b_245); r_; });
    }
    case TAG_TSig: {
      V v_fs_248 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_248; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_248); r_; });
    }
    case TAG_TSum: {
      V v_vs_2421 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_vs_2421; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_vs_2421); r_; });
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TArray: {
      V v_a_2430 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_a_2430, v_acc_242});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInf: {
      V v_i_2432 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2432, v_acc_242});
    }
    case TAG_TChk: {
      V v_c_2433 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2433, v_acc_242});
    }
    case TAG_TNominal: {
      V v_t_2434 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2434, v_acc_242});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsTypF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args) {
  V v_x2_249 = args[0];
  V v_acc_2410 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_249)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24At = heff_take_reuse_n(v_x2_249, 1ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_DeclareField: {
      V v_x_2413 = heff_field(v_x21_2411, 0);
      V v_t_2415 = heff_field(v_x21_2411, 2);
      V v_d_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 13ULL, 4);
      V v_t_2418;
      switch (heff_tag_of(v_d_2416)) {
      case TAG_Nothing: {
        v_t_2418 = v_acc_2410;
        break;
      }
      case TAG_Just: {
        V v_c_2417 = heff_field(v_d_2416, 0);
        heff_take_n(v_d_2416, 1ULL, 1);
        v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_c_2417, v_acc_2410}));
        break;
      }
      default: heff_nomatch(v_d_2416);
      }
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2415, v_t_2418}));
      return heff_tag_at_n(v_ru_24x2_249_24At, TAG_Cons, 2, (V[]){v_x_2413, v_t_2419});
    }
    case TAG_BadFieldDecl: {
      V v_e_2420 = heff_field(v_x21_2411, 0);
      heff_take_n(v_x21_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_249_24At, 2);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2420;
      args[1] = v_acc_2410;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args) {
  V v_x2_2422 = args[0];
  V v_acc_2423 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_At: {
    V v_x21_2424 = heff_field(v_x2_2422, 0);
    heff_take_n(v_x2_2422, 1ULL, 2);
    switch (heff_tag_of(v_x21_2424)) {
    case TAG_TagVariant: {
      V v_args_2428 = heff_field(v_x21_2424, 2);
      heff_take_n(v_x21_2424, 4ULL, 3);
      return ({ V a_0 = heff_get_n(v_r_240, 2, 4); V a_1 = v_args_2428; V a_2 = v_acc_2423; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2428); r_; });
    }
    case TAG_BadVariant: {
      V v_e_2429 = heff_field(v_x21_2424, 0);
      heff_take_n(v_x21_2424, 1ULL, 1);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2429;
      args[1] = v_acc_2423;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2424);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsDeclF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsDeclF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x21_243, 0);
      V v_ty_248 = heff_field(v_x21_243, 3);
      V v_eqs_249 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 25ULL, 5);
      V v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_eqs_249; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_eqs_249); r_; });
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_ty_248, v_t_2420}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_f_245, v_t_2421});
    }
    case TAG_DeclDefine: {
      V v_x_2422 = heff_field(v_x21_243, 0);
      V v_ps_2424 = heff_field(v_x21_243, 2);
      V v_u_2425 = heff_field(v_x21_243, 3);
      V v_body_2426 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 29ULL, 5);
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2426, v_acc_242}));
      V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_u_2425, v_t_2427}));
      V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2424; V a_2 = v_t_2428; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2424); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2422, v_t_2441});
    }
    case TAG_DeclTheory: {
      V v_x_2442 = heff_field(v_x21_243, 0);
      V v_ps_2444 = heff_field(v_x21_243, 2);
      V v_body_2445 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2445, v_acc_242}));
      V v_t_2459 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2444; V a_2 = v_t_2446; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2444); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2442, v_t_2459});
    }
    case TAG_DeclPrimitive: {
      V v_x_2460 = heff_field(v_x21_243, 0);
      V v_t_2462 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2462, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2460, v_t_2463});
    }
    case TAG_DeclTest: {
      V v_x_2464 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 2);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2464, v_acc_242});
    }
    case TAG_DeclWatch: {
      V v_e_2466 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2466, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsDeclF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_a_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2412 = heff_field(v_m_2410, 0);
    V v_ru_24m_2410_24At = heff_take_reuse_n(v_m_2410, 1ULL, 2);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_ps_2416 = heff_field(v_x21_2412, 2);
      V v_rhs_2417 = heff_field(v_x21_2412, 3);
      heff_take_n(v_x21_2412, 13ULL, 4);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_rhs_2417, v_a_2411}));
      V v_t_2419 = ({ V a_0 = v_ps_2416; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a_0, a_1)); heff_drop(v_ps_2416); r_; });
      return heff_tag_at_n(v_ru_24m_2410_24At, TAG_Cons, 2, (V[]){v_f_2414, v_t_2419});
    }
    default: return heff_nomatch(v_x21_2412);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args) {
  V v_m_2429 = args[0];
  V v_a_2430 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2429)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_m_2429, 0);
    V v_ru_24m_2429_24At = heff_take_reuse_n(v_m_2429, 1ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_ExplicitParam: {
      V v_x_2433 = heff_field(v_x21_2431, 0);
      V v_t_2435 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 5ULL, 3);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2435, v_a_2430}));
      return heff_tag_at_n(v_ru_24m_2429_24At, TAG_Cons, 2, (V[]){v_x_2433, v_t_2436});
    }
    case TAG_ImplicitParam: {
      V v_x_2437 = heff_field(v_x21_2431, 0);
      V v_t_2439 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 5ULL, 3);
      V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2439, v_a_2430}));
      return heff_tag_at_n(v_ru_24m_2429_24At, TAG_Cons, 2, (V[]){v_x_2437, v_t_2440});
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_m_2429);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args) {
  V v_m_2447 = args[0];
  V v_a_2448 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2447)) {
  case TAG_At: {
    V v_x21_2449 = heff_field(v_m_2447, 0);
    V v_ru_24m_2447_24At = heff_take_reuse_n(v_m_2447, 1ULL, 2);
    switch (heff_tag_of(v_x21_2449)) {
    case TAG_ExplicitParam: {
      V v_x_2451 = heff_field(v_x21_2449, 0);
      V v_t_2453 = heff_field(v_x21_2449, 2);
      heff_take_n(v_x21_2449, 5ULL, 3);
      V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2453, v_a_2448}));
      return heff_tag_at_n(v_ru_24m_2447_24At, TAG_Cons, 2, (V[]){v_x_2451, v_t_2454});
    }
    case TAG_ImplicitParam: {
      V v_x_2455 = heff_field(v_x21_2449, 0);
      V v_t_2457 = heff_field(v_x21_2449, 2);
      heff_take_n(v_x21_2449, 5ULL, 3);
      V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2457, v_a_2448}));
      return heff_tag_at_n(v_ru_24m_2447_24At, TAG_Cons, 2, (V[]){v_x_2455, v_t_2458});
    }
    default: return heff_nomatch(v_x21_2449);
    }
  }
  default: return heff_nomatch(v_m_2447);
  }
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_a_246)));
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 3);
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_248, v_acc_241));
        v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_249});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2410 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2411;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkSegment: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_245)));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411 = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2erenameAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameAlt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameAlt(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_xs_246 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_p_244)));
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_take_field(v_r_240, 0)}));
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_b_245}), v_sp_243});
      } else {
        heff_drop(v_t_248);
        V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_245}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_249}), v_sp_243});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameAlt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameField(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_ysp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_248 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_246}));
      V v_t_2411;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 5);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_c_249 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_y_244, v_ysp_245, v_t_248, v_t_2411}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2412}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_t_2413}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameField(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(V v_lit_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_2414;
    switch (heff_tag_of(v_m_243)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_m_243, 0);
      heff_take_n(v_m_243, 1ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 3);
        v_t_2414 = heff_strEq(heff_dup(v_lit_240), v_a_248);
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 3);
        v_t_2414 = heff_strEq(heff_dup(v_lit_240), v_a_2411);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_m_243);
    }
    V v_t_2415;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_f_241);
      heff_drop(v_t_2414);
      v_t_2415 = v_rest_244;
    } else {
      heff_drop(v_t_2414);
      v_t_2415 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(v_lit_240, v_f_241, v_rest_244));
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameTypF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameTypF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24TPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2erenamePi(heff_dup(v_r_240), heff_dup(v_b_244)));
      V v_x_247 = heff_take_field(v_r_240, 0);
      V v_t_2424;
      switch (heff_tag_of(v_b_244)) {
      case TAG_PiNamed: {
        V v_y_248 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 3);
        if (heff_strEq_c(v_x_247, v_y_248)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiImplicit: {
        V v_y_2412 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 5);
        if (heff_strEq_c(v_x_247, v_y_2412)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiInstance: {
        V v_y_2418 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 4);
        if (heff_strEq_c(v_x_247, v_y_2418)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_244, 0ULL, 1);
        heff_drop(v_x_247);
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TPi, TAG_TPi, 2, (V[]){v_t_246, v_t_2424}), v_sp_243});
    }
    case TAG_TSig: {
      V v_fs_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSig = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameField_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2427 = (g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(v_r_240, v_t_2426, v_fs_2425));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSig, TAG_TSig, 1, (V[]){v_t_2427}), v_sp_243});
    }
    case TAG_TSum: {
      V v_vs_2428 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSum = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameTypF_lam0, 1, 1, (V[]){v_r_240}), v_vs_2428));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSum, TAG_TSum, 1, (V[]){v_t_2438}), v_sp_243});
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TArray: {
      V v_a_2439 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TArray = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_a_2439}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TArray, TAG_TArray, 1, (V[]){v_t_2440}), v_sp_243});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInf: {
      V v_i_2442 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2442}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TInf, TAG_TInf, 1, (V[]){v_t_2443}), v_sp_243});
    }
    case TAG_TChk: {
      V v_c_2444 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TChk = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2444}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TChk, TAG_TChk, 1, (V[]){v_t_2445}), v_sp_243});
    }
    case TAG_TNominal: {
      V v_t_2446 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2446}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TNominal, TAG_TNominal, 1, (V[]){v_t_2447}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameTypF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args) {
  V v_x2_2429 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_At: {
    V v_x21_2430 = heff_field(v_x2_2429, 0);
    V v_sp_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24At = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_TagVariant: {
      V v_t_2432 = heff_field(v_x21_2430, 0);
      V v_tsp_2433 = heff_field(v_x21_2430, 1);
      V v_args_2434 = heff_field(v_x21_2430, 2);
      heff_take_n(v_x21_2430, 7ULL, 3);
      V v_t_2435 = (g_list_2emap(heff_get_n(v_r_240, 4, 5), v_args_2434));
      return heff_tag_at_n(v_ru_24x2_2429_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_2432, v_tsp_2433, v_t_2435}), v_sp_2431});
    }
    case TAG_BadVariant: {
      V v_e_2436 = heff_field(v_x21_2430, 0);
      heff_take_n(v_x21_2430, 1ULL, 1);
      V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2436}));
      return heff_tag_at_n(v_ru_24x2_2429_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_t_2437}), v_sp_2431});
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eanyIn_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2eanyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eanyIn(V v_c_240, V v_n_241, V v_a_242) {
top: ;
  V v_ys_243 = (g_list_2emap_24f1539731936x1117725130(((V)&g_heff_2eelab_2eclauses_2eanyIn_str0), MK_INT(0LL), v_n_241));
  V v_xs_244 = heff_take_field(v_a_242, 0);
  V v_t_245 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_244)));
  V v_t_246 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_244));
  V v_t_247 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_243, v_t_246));
  V v_pats_248 = (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_247));
  return ({ V rv_0 = v_pats_248; V rr_ = heff_rec_reuse_nf(v_a_242, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eanyIn(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagArmStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagArmStep_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagArmStep(V v_c_240, V v_col_241, V v_t_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagArmStep_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_t_242)}), heff_dup(heff_rfield(v_col_241, 2))));
    V v_t_247 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(v_t_242), NTAG(TAG_False), heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, v_t_246})});
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_t_242, 0)), v_t_247, heff_take_field(v_col_241, 0)));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_take_field(v_col_241, 1)});
    return ({ V rv_0 = v_t_248; V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_col_241, 4ULL, 3, shape_arms__order__anys, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_arm_2410 = heff_field(v_x5_244, 0);
    heff_drop(v_c_240);
    V v_t_2411 = heff_dup(heff_rfield(v_arm_2410, 1));
    V v_t_2414 = heff_bool(((heff_dup(v_t_2411) == NTAG(TAG_True)) || ({ V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_arm_2410, 0)), 1, 4); int c_ = !heff_intEq_c(heff_dup(heff_rfield(v_t_242, 1)), heff_dup(v_t_2412)); heff_drop(v_t_2412); c_; })));
    heff_drop(v_t_2411);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_dup(heff_rfield(v_arm_2410, 2))});
    V v_t_2416 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(heff_rfield(v_arm_2410, 0)), v_t_2414, v_t_2415});
    V v_t_2417 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_242, 0, 4), v_t_2416, heff_take_field(v_col_241, 0)));
    return ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_col_241, 6ULL, 3, shape_arms__order__anys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagArmStep(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, heff_get_n(v_t_242, 1, 4), v_a_245));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColGo_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2etagColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColGo_entry, 4, 0};

V g_heff_2eelab_2eclauses_2etagColGo(V v_c_240, V v_v_241, V v_col_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    return v_col_242;
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_244, 0), heff_dup(v_c_240)));
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2etagColGo_str0)});
      break;
    }
    case TAG_Just: {
      V v_p_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_248 = v_p_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_249 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_v_241); V a_2 = v_col_242; V a_3 = heff_dup(v_r_244); V a_4 = v_t_248; V r_ = (g_heff_2eelab_2eclauses_2etagColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_248); r_; });
    V t_0 = v_c_240;
    V t_1 = v_v_241;
    V t_2 = v_t_249;
    V t_3 = v_rest_245;
    v_c_240 = t_0;
    v_v_241 = t_1;
    v_col_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2etagColGo(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str1, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str3, 46, "a literal and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str5, 88, "literals are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2elitChecks_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2elitChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitChecks_entry, 5, 0};

V g_heff_2eelab_2eclauses_2elitChecks(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244) {
top: ;
  V v_t_2420 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_lam0, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_c_243);
    heff_drop(v_t_2420);
    V v_t_2423;
    switch (heff_tag_of(v_l_244)) {
    case TAG_At: {
      V v_s_2422 = heff_field(v_l_244, 1);
      v_t_2423 = heff_dup(v_s_2422);
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2423, ((V)&g_heff_2eelab_2eclauses_2elitChecks_str1)})});
  } else {
    heff_drop(v_t_2420);
    V v_t_2439 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_lam1, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_c_243);
      heff_drop(v_t_2439);
      V v_t_2442;
      switch (heff_tag_of(v_l_244)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_l_244, 1);
        v_t_2442 = heff_dup(v_s_2441);
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2442, ((V)&g_heff_2eelab_2eclauses_2elitChecks_str3)})});
    } else {
      heff_drop(v_t_2439);
      V v_t_2458 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_lam2, 1, 1, (V[]){v_c_243}), v_rows_242));
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop(v_t_2458);
        V v_t_2461;
        switch (heff_tag_of(v_l_244)) {
        case TAG_At: {
          V v_s_2460 = heff_field(v_l_244, 1);
          v_t_2461 = heff_dup(v_s_2460);
          break;
        }
        default: heff_nomatch(v_l_244);
        }
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2461, ((V)&g_heff_2eelab_2eclauses_2elitChecks_str5)})});
      } else {
        heff_drop(v_t_2458);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2elitChecks(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2elitChecks_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_row_245, 0, 2); V a_1 = v_c_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_x1_248 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_x1_248 = v_p_247;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_PVar: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_248, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_lam1(V self, V *args) {
  V v_row_2424 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = ({ V b_0 = heff_get_n(v_row_2424, 0, 2); V a_1 = v_c_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2427;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    v_x1_2427 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_str2)});
    break;
  }
  case TAG_Just: {
    V v_p_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    v_x1_2427 = v_p_2426;
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2427, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2427, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2427, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2427, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_lam2(V self, V *args) {
  V v_row_2443 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = ({ V b_0 = heff_get_n(v_row_2443, 0, 2); V a_1 = v_c_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2446;
  switch (heff_tag_of(v_t_2444)) {
  case TAG_Nothing: {
    v_x1_2446 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_str4)});
    break;
  }
  case TAG_Just: {
    V v_p_2445 = heff_field(v_t_2444, 0);
    heff_take_n(v_t_2444, 1ULL, 1);
    v_x1_2446 = v_p_2445;
    break;
  }
  default: heff_nomatch(v_t_2444);
  }
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2446, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2446, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2446, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2446, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2446, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2446, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSubs_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecSubs_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSubs_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecSubs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSubs_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSubs(V v_used_240, V v_bound_241, V v_c_242, V v_rows_243) {
top: ;
  V v_t_2420 = (g_heff_2eelab_2eclauses_2econcatMapC(heff_clo_n(g_heff_2eelab_2eclauses_2erecSubs_lam0, 1, 1, (V[]){heff_dup(v_c_242)}), v_rows_243));
  V v_t_2421 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2420));
  return (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecSubs_lam1, 1, 4, (V[]){v_c_242, v_rows_243, heff_dup(v_used_240), heff_dup(v_bound_241)}), v_t_2421));
}
V g_heff_2eelab_2eclauses_2erecSubs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2erecSubs(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2erecSubs_lam0(V self, V *args) {
  V v_row_244 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V b_0 = heff_get_n(v_row_244, 0, 2); V a_1 = v_c_242; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_x1_247 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSubs_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_x1_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_PVar: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_247, 0ULL, 3);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2413 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2419 = v_fps_2413;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PBin: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  return (g_list_2emap_24s1415906091x1371825187(v_t_2419));
}
V g_heff_2eelab_2eclauses_2erecSubs_lam1(V self, V *args) {
  V v_f_2422 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_rows_243 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = (g_heff_2eelab_2eclauses_2erecFieldVar(v_c_242, v_rows_243, heff_dup(v_f_2422)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2423; V a_3 = v_f_2422; V r_ = (g_heff_2eelab_2eclauses_2erecSubName(a_0, a_1, a_2, a_3)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(v_t_2423); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str0, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str1, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str2, 6, "intMod");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str3, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str4, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2esizeOk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esizeOk_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esizeOk(V v_k_240, V v_ty_241, V v_size_242, V v_w_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 6);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_size_242, 0ULL, 1);
      heff_drop_rec(v_k_240, 6);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_ru_24size_242_24SizeName = heff_take_reuse_n(v_size_242, 0ULL, 2);
      V v_sp_248 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_249 = heff_tag_at_n(v_ru_24size_242_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_248)});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_sp_248});
      V v_t_2411 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_w_243), heff_dup(heff_rfield(v_k_240, 5))));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_args_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
      V v_sp_2414 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str0)}), heff_dup(v_sp_2414)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), v_args_2413));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2415, v_t_2416}), v_sp_2414});
      V v_t_2418 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_w_243), heff_dup(heff_rfield(v_k_240, 5))));
      V v_sp_2419 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(64LL)}), heff_dup(v_sp_2419)});
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2420}), v_sp_2419});
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      V v_args_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2422});
      V v_sp_2424 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str1)}), heff_dup(v_sp_2424)});
      V v_t_2426 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2424), v_args_2423));
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2425, v_t_2426}), v_sp_2424});
      V v_t_2428 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 5))));
      V v_sp_2429 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_2429)});
      V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), v_sp_2429});
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2432});
      V v_sp_2434 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str2)}), heff_dup(v_sp_2434)});
      V v_t_2436 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2434), v_args_2433));
      V v_i_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2435, v_t_2436}), v_sp_2434});
      V v_t_2440;
      switch (heff_tag_of(v_i_2437)) {
      case TAG_At: {
        V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
        v_t_2440 = v_s_2439;
        break;
      }
      default: heff_nomatch(v_i_2437);
      }
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2437}), v_t_2440});
      V v_sp_2442 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2442)});
      V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2443}), v_sp_2442});
      V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
      V v_args_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2445});
      V v_sp_2447 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str3)}), heff_dup(v_sp_2447)});
      V v_t_2449 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2447), v_args_2446));
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2448, v_t_2449}), v_sp_2447});
      V v_t_2451 = (g_heff_2eelab_2eclauses_2eandC(v_t_2450, v_rest_244, heff_dup(heff_rfield(v_k_240, 5))));
      V v_t_2452 = (g_heff_2eelab_2eclauses_2eandC(v_t_2427, v_t_2451, heff_dup(heff_rfield(v_k_240, 5))));
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2417, v_t_2452, heff_get_n(v_k_240, 5, 6)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 6);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_size_242, 0ULL, 1);
      heff_drop_rec(v_k_240, 6);
      heff_drop(v_w_243);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_ru_24size_242_24SizeName = heff_take_reuse_n(v_size_242, 0ULL, 2);
      V v_sp_2456 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2457 = heff_tag_at_n(v_ru_24size_242_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2456)});
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2457}), v_sp_2456});
      V v_t_2459 = (g_heff_2eelab_2eclauses_2eoffC(v_w_243, heff_dup(heff_rfield(v_k_240, 5))));
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
      V v_args_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2460});
      V v_sp_2462 = heff_dup(heff_rfield(v_k_240, 5));
      V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str4)}), heff_dup(v_sp_2462)});
      V v_t_2464 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2462), v_args_2461));
      V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2463, v_t_2464}), v_sp_2462});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2465, v_rest_244, heff_get_n(v_k_240, 5, 6)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2esizeOk(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efits_str0, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efits_entry, 4, 0};

V g_heff_2eelab_2eclauses_2efits(V v_k_240, V v_off_241, V v_w_242, V v_rest_243) {
top: ;
  V v_t_244 = heff_intAdd(heff_take_field(v_off_241, 0), heff_take_field(v_w_242, 0));
  V v_t_245 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_241, 1, 2), heff_get_n(v_w_242, 1, 2)));
  V v_t_246 = (g_heff_2eelab_2eclauses_2eoffC(heff_rec_n(2, shape_bits__terms, (V[]){v_t_244, v_t_245}), heff_dup(heff_rfield(v_k_240, 5))));
  V v_sp_247 = heff_dup(heff_rfield(v_k_240, 5));
  V v_t_248 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 1)});
  V v_t_249 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_247)})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_247}), NTAG(TAG_Nil)});
  V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2410});
  V v_sp_2412 = heff_dup(heff_rfield(v_k_240, 5));
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efits_str0)}), heff_dup(v_sp_2412)});
  V v_t_2414 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2412), v_args_2411));
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_2412});
  return (g_heff_2eelab_2eclauses_2eandC(v_t_2415, v_rest_243, heff_get_n(v_k_240, 5, 6)));
}
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efits(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ebinTest_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ebinTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTest_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebinTest(V v_k_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2eelab_2eclauses_2ebinTest_lam0, 4, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinTest(a[0]);
}
V g_heff_2eelab_2eclauses_2ebinTest_lam0(V self, V *args) {
  V v_env_241 = args[0];
  V v_i_242 = args[1];
  V v_off_243 = args[2];
  V v_segs_244 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2eelab_2eclauses_2ebinTest(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_245; V a_1 = v_k_240; V a_2 = v_env_241; V a_3 = v_i_242; V a_4 = v_off_243; V a_5 = v_segs_244; V r_ = (g_heff_2eelab_2eclauses_2ebinTestGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_segs_244); r_; });
}
Clo g_heff_2eelab_2eclauses_2esegBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegBind_entry, 10, 0};

V g_heff_2eelab_2eclauses_2esegBind(V v_b_240, V v_k_241, V v_env_242, V v_ys_243, V v_off_244, V v_s_245, V v_rest_246, V v_body_247, V v_w_248, V v_x10_249) {
top: ;
  switch (heff_tag_of(v_x10_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_241, 6);
    heff_drop_rec(v_s_245, 5);
    V v_t_2410 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_248, 0));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_248, 1, 2)));
    return heff_tail(heff_get_n(v_b_240, 0, 1), 5, (V[]){v_env_242, v_ys_243, heff_rec_n(2, shape_bits__terms, (V[]){v_t_2410, v_t_2411}), v_rest_246, v_body_247});
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x10_249, 0);
    V v_ru_24x10_249_24Just = heff_take_reuse_n(v_x10_249, 1ULL, 1);
    switch (heff_tag_of(v_ys_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_b_240, 1);
      heff_drop_rec(v_k_241, 6);
      heff_drop(v_env_242);
      heff_drop_rec(v_off_244, 2);
      heff_drop_rec(v_s_245, 5);
      heff_drop(v_rest_246);
      heff_drop_rec(v_w_248, 2);
      heff_drop(v_x_2412);
      heff_drop_cell(v_ru_24x10_249_24Just, 1);
      return v_body_247;
    }
    case TAG_Cons: {
      V v_y_2413 = heff_field(v_ys_243, 0);
      V v_ys2_2414 = heff_field(v_ys_243, 1);
      V v_ru_24ys_243_24Cons = heff_take_reuse_n(v_ys_243, 3ULL, 2);
      V v_rhs_2415 = ({ V a_0 = heff_dup(v_k_241); V a_1 = heff_dup(v_off_244); V a_2 = heff_dup(v_w_248); V a_3 = heff_dup(v_s_245); V b_4 = heff_dup(heff_rfield(v_s_245, 1)); V a_5 = heff_get_n(v_s_245, 2, 5); V r_ = (g_heff_2eelab_2eclauses_2esegRead(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
      V v_t_2416 = heff_tag_at_n(v_ru_24ys_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, heff_dup(v_y_2413)}), v_env_242});
      V v_t_2417 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_248, 0));
      V v_t_2418 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_248, 1, 2)));
      V v_body_2419 = heff_tr(heff_call(heff_get_n(v_b_240, 0, 1), 5, (V[]){v_t_2416, v_ys2_2414, heff_rec_n(2, shape_bits__terms, (V[]){v_t_2417, v_t_2418}), v_rest_246, v_body_247}));
      V v_sp_2420 = heff_get_n(v_k_241, 5, 6);
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x10_249_24Just, TAG_PatVar, 1, (V[]){v_y_2413}), heff_dup(v_sp_2420)});
      V v_t_2424;
      switch (heff_tag_of(v_body_2419)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_body_2419, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_body_2419);
      }
      V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2420, 0)); V rr_ = heff_rec_reuse_nf(v_t_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2421, v_body_2419}), v_t_2425});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2415, v_t_2426}), v_sp_2420});
    }
    default: return heff_nomatch(v_ys_243);
    }
  }
  default: return heff_nomatch(v_x10_249);
  }
}
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegBind(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinBindGo_entry, 7, 0};

V g_heff_2eelab_2eclauses_2ebinBindGo(V v_b_240, V v_k_241, V v_env_242, V v_ys_243, V v_off_244, V v_x6_245, V v_body_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_k_241);
    heff_drop(v_env_242);
    heff_drop(v_ys_243);
    heff_drop(v_off_244);
    return v_body_246;
  }
  case TAG_Cons: {
    V v_s_247 = heff_field(v_x6_245, 0);
    V v_rest_248 = heff_field(v_x6_245, 1);
    V v_t_249 = (g_heff_2eelab_2eclauses_2ewidthBy(v_env_242, heff_dup(heff_rfield(v_s_247, 4)), heff_rfield(v_s_247, 1), heff_dup(heff_rfield(v_s_247, 2)), heff_rfield(v_s_247, 0)));
    V v_t_2410 = heff_dup(heff_rfield(v_s_247, 0));
    V v_t_2431;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_x11_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      switch (heff_tag_of(v_x11_2411)) {
      case TAG_PatVar: {
        V v_x_2413 = heff_field(v_x11_2411, 0);
        V v_ru_24x11_2411_24PatVar = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
        if (heff_strEq_c(heff_dup(v_x_2413), ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str0))) {
          heff_drop(v_x_2413);
          heff_drop_cell(v_ru_24x11_2411_24PatVar, 1);
          v_t_2431 = NTAG(TAG_Nothing);
        } else {
          v_t_2431 = heff_tag_at_n(v_ru_24x11_2411_24PatVar, TAG_Just, 1, (V[]){v_x_2413});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_2411, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_2411, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_2411, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_2411, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2411);
      }
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    return (g_heff_2eelab_2eclauses_2esegBind(v_b_240, v_k_241, v_env_242, v_ys_243, v_off_244, heff_dup(v_s_247), heff_dup(v_rest_248), v_body_246, v_t_249, v_t_2431));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2eclauses_2ebinBindGo(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str2, 1, "_");
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry, 7, 0};

V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_col_246) {
top: ;
  V v_x1_247 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop_rec(v_col_246, 3);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 0ULL, 1);
    V v_x1_2410 = (g_heff_2eelab_2eclauses_2enoLitHere(v_sp_242, heff_dup(v_c_245), v_rows_244));
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Left = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop_rec(v_col_246, 3);
      heff_drop_cell(v_ru_24x1_247_24Right, 1);
      return heff_tag_at_n(v_ru_24x1_2410_24Left, TAG_Left, 1, (V[]){v_e_2411});
    }
    case TAG_Right: {
      V v_ru_24x1_2410_24Right = heff_take_reuse_n(v_x1_2410, 0ULL, 1);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_col_246, 1))));
      V v_x1_2425 = (g_heff_2eelab_2eclauses_2etraverseC(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), v_col_246, heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242)}), v_t_2413));
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Left: {
        V v_e_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        heff_drop_cell(v_ru_24x1_247_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Left, 1, (V[]){v_e_2426});
      }
      case TAG_Right: {
        V v_x_2427 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        V v_t_2443 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam2, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
        V v_x1_2444 = ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = heff_dup(v_sp_242); V a_3 = heff_dup(v_vars_243); V a_4 = v_rows_244; V a_5 = heff_dup(v_c_245); V a_6 = v_t_2443; V r_ = (g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
        switch (heff_tag_of(v_x1_2444)) {
        case TAG_Left: {
          V v_e_2445 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_c_245);
          heff_drop_cell(v_ru_24x1_247_24Right, 1);
          heff_drop(v_x_2427);
          return heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Left, 1, (V[]){v_e_2445});
        }
        case TAG_Right: {
          V v_x_2446 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          V v_t_2447 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
          V v_t_2449;
          switch (heff_tag_of(v_t_2447)) {
          case TAG_Nothing: {
            v_t_2449 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str2);
            break;
          }
          case TAG_Just: {
            V v_v_2448 = heff_field(v_t_2447, 0);
            heff_take_n(v_t_2447, 1ULL, 1);
            v_t_2449 = v_v_2448;
            break;
          }
          default: heff_nomatch(v_t_2447);
          }
          V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_IVar, 1, (V[]){v_t_2449}), heff_dup(v_sp_242)});
          V v_t_2451 = (g_heff_2eelab_2eclauses_2eappendC(v_x_2427, v_x_2446));
          V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2450, v_t_2451}), v_sp_242});
          return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){v_t_2452});
        }
        default: return heff_nomatch(v_x1_2444);
        }
      }
      default: return heff_nomatch(v_x1_2425);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam1(V self, V *args) {
  V v_i_2423 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_t_2421 = heff_env(self)[2];
  V v_v_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2421; V a_3 = v_v_2417; V a_4 = v_i_2423; V r_ = (g_heff_2eelab_2eclauses_2earmSub(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_used_240); heff_drop(v_bound_241); r_; });
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0(V self, V *args) {
  V v_t_2414 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_col_246 = heff_env(self)[2];
  V v_used_240 = heff_env(self)[3];
  V v_bound_241 = heff_env(self)[4];
  V v_sp_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
  V v_v_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_v_2417 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_v_2417 = v_v_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_x2_2418 = ({ V a_0 = heff_dup(heff_rfield(v_t_2414, 0)); V b_1 = heff_get_n(v_col_246, 0, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_arm_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_arm_2420 = heff_rec_n(3, shape_row__bad__rows, (V[]){v_t_2414, NTAG(TAG_False), NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_arm_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    heff_drop_rec(v_t_2414, 4);
    v_arm_2420 = v_arm_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2421 = heff_dup(heff_rfield(v_arm_2420, 0));
  V v_t_2422 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(heff_rfield(v_t_2421, 1))));
  V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam1, 1, 4, (V[]){heff_dup(v_used_240), heff_dup(v_bound_241), v_t_2421, v_v_2417}), v_t_2422));
  return (g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_c_245, v_arm_2420, v_t_2424));
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam2(V self, V *args) {
  V v_row_2428 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = ({ V b_0 = heff_get_n(v_row_2428, 0, 2); V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2431;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    v_x1_2431 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str1)});
    break;
  }
  case TAG_Just: {
    V v_p_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    v_x1_2431 = v_p_2430;
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2431, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2431, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2431, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2431, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry, 6, 0};

V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_t_2422 = (g_heff_2eelab_2eclauses_2econcatMapC(heff_clo_n(g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), v_rows_244));
  V v_t_2423 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2422));
  V v_t_2424 = (g_heff_2eelab_2eclauses_2erecSubs(v_used_240, v_bound_241, heff_dup(v_c_245), heff_dup(v_rows_244)));
  return (g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2423, v_t_2424));
}
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_x1_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_x1_249 = v_p_248;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2421;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2415 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 2);
    v_t_2421 = v_fps_2415;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PBin: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return (g_list_2emap_24s1415906091x1371825187(v_t_2421));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str4, 4, "Bits");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str6, 12, "builtin.Bool");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str7, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str8, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str9, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str11, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str12, 5, "False");
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_entry, 10, 0};

V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247, V v_xs_248, V v_ys_249) {
top: ;
  V v_x1_2410 = (g_heff_2eelab_2eclauses_2ebinChecks(v_rows_244, heff_dup(v_c_245), heff_dup(v_bsp_247)));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Left: {
    V v_e_2411 = heff_field(v_x1_2410, 0);
    V v_ru_24x1_2410_24Left = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop(v_segs_246);
    heff_drop_rec(v_bsp_247, 2);
    heff_drop(v_xs_248);
    heff_drop(v_ys_249);
    return heff_tag_at_n(v_ru_24x1_2410_24Left, TAG_Left, 1, (V[]){v_e_2411});
  }
  case TAG_Right: {
    V v_ru_24x1_2410_24Right = heff_take_reuse_n(v_x1_2410, 0ULL, 1);
    V v_bound_2413 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_249), heff_dup(v_bound_241)));
    V v_vars_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_vars_243), heff_dup(v_ys_249)));
    V v_rows_2428 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam0, 2, 3, (V[]){heff_dup(v_c_245), v_xs_248, heff_dup(v_ys_249)}), heff_dup(v_rows_244)));
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam1, 1, 1, (V[]){heff_dup(v_vars_2414)}), v_rows_2428));
    V v_x1_2431 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(heff_dup(v_used_240), v_bound_2413, heff_dup(v_sp_242), v_vars_2414, v_t_2430));
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x1_2431, 0);
      V v_ru_24x1_2431_24Left = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_segs_246);
      heff_drop_rec(v_bsp_247, 2);
      heff_drop(v_ys_249);
      heff_drop_cell(v_ru_24x1_2410_24Right, 1);
      return heff_tag_at_n(v_ru_24x1_2431_24Left, TAG_Left, 1, (V[]){v_e_2432});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x1_2431, 0);
      V v_ru_24x1_2431_24Right = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
      V v_rows_2434 = (g_heff_2eelab_2eclauses_2edropC(MK_INT(1LL), v_rows_244));
      V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam2, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2434));
      V v_x1_2437 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(heff_dup(v_used_240), heff_dup(v_bound_241), v_sp_242, heff_dup(v_vars_243), v_t_2436));
      switch (heff_tag_of(v_x1_2437)) {
      case TAG_Left: {
        V v_e_2438 = heff_field(v_x1_2437, 0);
        heff_take_n(v_x1_2437, 1ULL, 1);
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_vars_243);
        heff_drop(v_c_245);
        heff_drop(v_segs_246);
        heff_drop_rec(v_bsp_247, 2);
        heff_drop(v_ys_249);
        heff_drop_cell(v_ru_24x1_2410_24Right, 1);
        heff_drop(v_x_2433);
        return heff_tag_at_n(v_ru_24x1_2431_24Right, TAG_Left, 1, (V[]){v_e_2438});
      }
      case TAG_Right: {
        V v_x_2439 = heff_field(v_x1_2437, 0);
        V v_ru_24x1_2437_24Right = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
        V v_t_2440 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
        V v_t_2442;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_Nothing: {
          v_t_2442 = ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str2);
          break;
        }
        case TAG_Just: {
          V v_v_2441 = heff_field(v_t_2440, 0);
          heff_take_n(v_t_2440, 1ULL, 1);
          v_t_2442 = v_v_2441;
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        V v_t_2443 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
        V v_t_2445;
        switch (heff_tag_of(v_t_2443)) {
        case TAG_Nothing: {
          v_t_2445 = ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str3);
          break;
        }
        case TAG_Just: {
          V v_v_2444 = heff_field(v_t_2443, 0);
          heff_take_n(v_t_2443, 1ULL, 1);
          v_t_2445 = v_v_2444;
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        V v_t_2446 = (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_t_2445, ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str4))));
        V v_t_2447 = (g_list_2emap_24s939813003x1383013550(heff_dup(v_segs_246)));
        V v_t_2448 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2447));
        V v_t_2449 = (g_heff_2eelab_2eclauses_2ewholeBin(v_segs_246, ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str5)));
        V v_t_2450 = (g_heff_2eelab_2eclauses_2ebinTestOf(heff_rec_n(6, shape_v__len__sizes__used__bound__span, (V[]){v_t_2442, v_t_2446, v_t_2448, heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_bsp_247)}), heff_dup(v_segs_246), v_t_2449));
        V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2431_24Right, TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str6)}), heff_dup(v_bsp_247)});
        V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2437_24Right, TAG_TInf, 1, (V[]){v_t_2451}), heff_dup(v_bsp_247)});
        V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2450, v_t_2452}), heff_dup(v_bsp_247)});
        V v_t_2454 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str7), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
        V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str8)}), heff_dup(v_bsp_247)});
        V v_x1_2456 = ({ V a_0 = v_t_2455; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2459;
        switch (heff_tag_of(v_x1_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_field(v_x1_2456, 1);
          heff_take_n(v_x1_2456, 2ULL, 2);
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_x1_2456);
        }
        V v_t_2460 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2459, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_p_2461 = heff_tag_n(TAG_At, 2, (V[]){v_t_2454, v_t_2460});
        V v_t_2462 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
        V v_t_2464;
        switch (heff_tag_of(v_t_2462)) {
        case TAG_Nothing: {
          v_t_2464 = ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str9);
          break;
        }
        case TAG_Just: {
          V v_v_2463 = heff_field(v_t_2462, 0);
          heff_take_n(v_t_2462, 1ULL, 1);
          v_t_2464 = v_v_2463;
          break;
        }
        default: heff_nomatch(v_t_2462);
        }
        V v_t_2465 = heff_rec_n(6, shape_v__len__sizes__used__bound__span, (V[]){v_t_2464, ((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str10), NTAG(TAG_Nil), v_used_240, v_bound_241, heff_dup(v_bsp_247)});
        V v_t_2466 = (g_heff_2eelab_2eclauses_2ebinBind(v_t_2465));
        V v_t_2467 = heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        V v_e_2468 = heff_tr(heff_call(heff_get_n(v_t_2466, 0, 1), 5, (V[]){NTAG(TAG_Nil), v_ys_249, v_t_2467, v_segs_246, v_x_2433}));
        V v_t_2471;
        switch (heff_tag_of(v_p_2461)) {
        case TAG_At: {
          V v_s_2470 = heff_dup(heff_field(v_p_2461, 1));
          v_t_2471 = v_s_2470;
          break;
        }
        default: heff_nomatch(v_p_2461);
        }
        V v_t_2474;
        switch (heff_tag_of(v_e_2468)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_e_2468, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_e_2468);
        }
        V v_t_2475 = ({ V rv_1 = heff_get_n(v_t_2474, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2471, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2476 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2461, v_e_2468}), v_t_2475});
        V v_t_2477 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str11), heff_dup(v_bsp_247), NTAG(TAG_Nil)});
        V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str12)}), heff_dup(v_bsp_247)});
        V v_x1_2479 = ({ V a_0 = v_t_2478; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2482;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_At: {
          V v_s_2481 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 2ULL, 2);
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_t_2483 = ({ V rv_0 = heff_dup(heff_rfield(v_bsp_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2482, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_p_2484 = heff_tag_n(TAG_At, 2, (V[]){v_t_2477, v_t_2483});
        V v_t_2487;
        switch (heff_tag_of(v_p_2484)) {
        case TAG_At: {
          V v_s_2486 = heff_dup(heff_field(v_p_2484, 1));
          v_t_2487 = v_s_2486;
          break;
        }
        default: heff_nomatch(v_p_2484);
        }
        V v_t_2490;
        switch (heff_tag_of(v_x_2439)) {
        case TAG_At: {
          V v_s_2489 = heff_dup(heff_field(v_x_2439, 1));
          v_t_2490 = v_s_2489;
          break;
        }
        default: heff_nomatch(v_x_2439);
        }
        V v_t_2491 = ({ V rv_1 = heff_get_n(v_t_2490, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2487, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2484, v_x_2439}), v_t_2491});
        V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2492, NTAG(TAG_Nil)});
        V v_t_2494 = heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2493})});
        return heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2494, v_bsp_247})});
      }
      default: return heff_nomatch(v_x1_2437);
      }
    }
    default: return heff_nomatch(v_x1_2431);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam0(V self, V *args) {
  V v_i_2415 = args[0];
  V v_row_2416 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  V v_ys_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intEq_c(v_i_2415, MK_INT(0LL))) {
    heff_drop(v_ys_249);
    V v_xs_2418 = heff_take_field(v_row_2416, 0);
    V v_t_2419 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_xs_2418)));
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str0)}), NTAG(TAG_Nil)});
    V v_t_2421 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_245, MK_INT(1LL)), v_xs_2418));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2420, v_t_2421));
    V v_t_2423 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2419, v_t_2422));
    V v_t_2424 = (g_list_2emap_24s796727596x829078925(v_xs_248));
    V v_pats_2425 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2423, v_t_2424));
    return ({ V rv_0 = v_pats_2425; V rr_ = heff_rec_reuse_nf(v_row_2416, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_c_245);
    heff_drop(v_xs_248);
    V v_t_2426 = (g_list_2emap_24s1846289357x1055790465(((V)&g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_str1), v_ys_249));
    V v_pats_2427 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_row_2416, 0), v_t_2426));
    return ({ V rv_0 = v_pats_2427; V rr_ = heff_rec_reuse_nf(v_row_2416, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam1(V self, V *args) {
  V v_row_2429 = args[0];
  V v_vars_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2414, heff_dup(heff_rfield(v_row_2429, 0)), heff_get_n(v_row_2429, 1, 2)));
}
V g_heff_2eelab_2eclauses_2ebinaryWith_24s675956591x542234800_lam2(V self, V *args) {
  V v_row_2435 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, heff_dup(heff_rfield(v_row_2435, 0)), heff_get_n(v_row_2435, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str1, 1, "_");
Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry, 5, 0};

V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244) {
top: ;
  switch (heff_tag_of(v_rows_244)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_vars_243);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_row_246 = heff_dup(heff_field(v_rows_244, 0));
    V v_t_248 = (g_heff_2eelab_2eclauses_2efindTagLit(heff_rfield(v_row_246, 0), MK_INT(0LL)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop_tag(v_rows_244, 2);
      V v_t_249 = (g_heff_2eelab_2eclauses_2ezipC(v_vars_243, heff_take_field(v_row_246, 0)));
      V v_t_2410 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str0); V a_1 = heff_get_n(v_row_246, 1, 2); V a_2 = v_t_249; V r_ = (g_list_2efoldl_24s901304517x253262467(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2410});
    }
    case TAG_Just: {
      V v_c_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2412 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = heff_dup(v_c_2411); V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2414;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        v_t_2414 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str1)});
        break;
      }
      case TAG_Just: {
        V v_p_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        v_t_2414 = v_p_2413;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      return (g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_2411, v_t_2414));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_rows_244);
  }
}
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(heff_rfield(v_x_242, 1)), v_acc_241));
    V v_t_245 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(heff_rfield(v_x_242, 0), v_t_244));
    V t_0 = v_xs_243;
    V t_1 = v_t_245;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_243;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f650056853x543635120(a[0], a[1]);
}