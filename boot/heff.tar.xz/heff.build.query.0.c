// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_binder 558177493
#define LBL_broken 566525696
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_expecting 1746726246
#define LBL_fields 672433636
#define LBL_from 9647217
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_member 869372357
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_to 10466
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_uses 10094739
#define LBL_watches 1357821955
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__kind__span__selection__children[] = {LBL_name, LBL_kind, LBL_span, LBL_selection, LBL_children};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2edefinitionIn(V, V, V);
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionIn_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedFits(V, V, V, V);
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedFits_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V, V, V, V);
V g_heff_2ebuild_2equery_2efixityLine(V, V, V);
V g_heff_2ebuild_2equery_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efixityLine_clo;
V g_heff_2ebuild_2equery_2einFileFound(V, V, V, V, V);
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileFound_clo;
V g_heff_2ebuild_2equery_2einFileSites(V, V, V, V);
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileSites_clo;
V g_heff_2ebuild_2equery_2einStringGo(V, V, V, V);
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einStringGo_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eisLabelAt(V, V, V);
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisLabelAt_clo;
V g_heff_2ebuild_2equery_2ekindOf(V, V);
V g_heff_2ebuild_2equery_2ekindOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ekindOf_clo;
HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ebuild_2equery_2elocalFound(V, V, V);
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalFound_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2esumTags(V);
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esumTags_clo;
V g_heff_2ebuild_2equery_2esymbolWith(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolWith_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2esymbolsGo(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2euseOf(V, V, V);
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2euseOf_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_list_2eany_24s1011930416x23610018(V, V);
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a);
extern Clo g_list_2eany_24s1011930416x23610018_clo;
V g_list_2eany_24s1690524253x1144193326(V, V);
V g_list_2eany_24s1690524253x1144193326_entry(V self, V *a);
extern Clo g_list_2eany_24s1690524253x1144193326_clo;
V g_list_2eany_24s464681941x898021545(V, V);
V g_list_2eany_24s464681941x898021545_entry(V self, V *a);
extern Clo g_list_2eany_24s464681941x898021545_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V, V);
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
HeffT2 g_list_2efind_24s764539875x1185200879_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1950790755x1251737354(V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_clo;
V g_list_2ekeepIf_24s257286374x378693326(V, V);
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1651437062x1594169608(V, V);
V g_list_2emap_24f1651437062x1594169608_entry(V self, V *a);
extern Clo g_list_2emap_24f1651437062x1594169608_clo;
V g_list_2emap_24f530523215x314966509(V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_clo;
V g_list_2emap_24f922554743x1845028609(V, V);
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_clo;
V g_list_2emap_24s1224226459x189329095(V, V, V);
V g_list_2emap_24s1224226459x189329095_entry(V self, V *a);
extern Clo g_list_2emap_24s1224226459x189329095_clo;
V g_list_2emap_24s1276696116x507290452(V, V);
V g_list_2emap_24s1276696116x507290452_entry(V self, V *a);
extern Clo g_list_2emap_24s1276696116x507290452_clo;
V g_list_2emap_24s148260373x1589531897(V, V, V);
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2esortBy_24s1895001621x1916669639(V);
V g_list_2esortBy_24s1895001621x1916669639_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1895001621x1916669639_clo;
V g_list_2esortBy_24s475241097x1080260612(V);
V g_list_2esortBy_24s475241097x1080260612_entry(V self, V *a);
extern Clo g_list_2esortBy_24s475241097x1080260612_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_entry, 1, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ(a[0]);
}
Clo g_heff_2ebuild_2equery_2ewordAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242) {
top: ;
  if (heff_intEq_c_lent(v_p_241, MK_INT(0LL), 2)) {
    int64_t v_t_243 = (heff_unbox_word(v_p_241) + heff_unbox_word(heff_strLength_lent(v_x_242, 0)));
    V v_c_244 = heff_strByteAt_lent(v_src_240, heff_box_word(v_t_243), 2);
    V v_ret_24bool = heff_bool(((heff_peek_word(v_c_244) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_244) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_244) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_244)) ? !(heff_peek_word(v_c_244) <= ((int64_t)57ULL)) : 1)))))));
    heff_drop(v_c_244);
    return v_ret_24bool;
  } else {
    V v_c_245 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)));
    if (((heff_peek_word(v_c_245) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_245) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_245) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_245)) ? !(heff_peek_word(v_c_245) <= ((int64_t)57ULL)) : 1))))))) {
      heff_drop(v_c_245);
      V v_t_246 = heff_intAdd(v_p_241, heff_strLength_lent(v_x_242, 0));
      V v_c_247 = heff_strByteAt_lent(v_src_240, v_t_246, 2);
      V v_ret_24bool = heff_bool(((heff_peek_word(v_c_247) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_247) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_247) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_247)) ? !(heff_peek_word(v_c_247) <= ((int64_t)57ULL)) : 1)))))));
      heff_drop(v_c_247);
      return v_ret_24bool;
    } else {
      heff_drop(v_p_241);
      heff_drop(v_c_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ewordAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str0, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str2, 5, "error");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str3, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str4, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str6, 2, "  ");
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexplain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexplain_entry, 1, 0};

V g_heff_2ebuild_2equery_2eexplain(V v_c_240) {
top: ;
  V v_source_241 = heff_take_field(v_c_240, 3);
  V v_top_242 = heff_take_field(v_c_240, 5);
  V v_diags_243 = heff_get_n(v_c_240, 6, 14);
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam0, 1, 1, (V[]){heff_dup(v_source_241)}), heff_get_n(v_top_242, 8, 9)));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam1, 1, 1, (V[]){v_source_241}), v_diags_243));
  return (g_prelude_2e_2b_2b(v_t_2411, v_t_2419));
}
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eexplain(a[0]);
}
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args) {
  V v_ev_244 = args[0];
  V v_source_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_245 = heff_take_field(v_ev_244, 0);
  V v_kind_246 = heff_take_field(v_ev_244, 1);
  V v_text_247 = heff_get_n(v_ev_244, 2, 3);
  V v_t_248 = ({ V a_0 = v_source_241; V a_1 = v_span_245; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_241); r_; });
  V v_t_249 = heff_tr(heff_call(v_text_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2410 = heff_strAppend(v_kind_246, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str0), v_t_249));
  return heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str1), v_t_2410));
}
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args) {
  V v_d_2412 = args[0];
  V v_source_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2413 = heff_take_field(v_d_2412, 3);
  V v_severity_2414 = heff_take_field(v_d_2412, 1);
  V v_msg_2415 = heff_get_n(v_d_2412, 2, 5);
  V v_t_2416 = ({ V a_0 = v_source_241; V a_1 = v_span_2413; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_241); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_severity_2414)) {
  case TAG_SError: {
    v_t_2417 = ((V)&g_heff_2ebuild_2equery_2eexplain_str2);
    break;
  }
  case TAG_SWarning: {
    v_t_2417 = ((V)&g_heff_2ebuild_2equery_2eexplain_str3);
    break;
  }
  case TAG_SDebug: {
    v_t_2417 = ((V)&g_heff_2ebuild_2equery_2eexplain_str4);
    break;
  }
  default: heff_nomatch(v_severity_2414);
  }
  V v_t_2418 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str5), v_msg_2415));
  return heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str6), v_t_2418));
}
Clo g_heff_2ebuild_2equery_2etypedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etypedFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2etypedFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    V v_c_242 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)46ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_242);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2etypedFrom(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_box_word(v_i_241)}});
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
Clo g_heff_2ebuild_2equery_2eeqTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eeqTarget_entry, 2, 0};

V g_heff_2ebuild_2equery_2eeqTarget(V v_a_240, V v_b_241) {
top: ;
  V v_key_242 = heff_take_field(v_b_241, 0);
  V v_member_243 = heff_take_field(v_b_241, 1);
  V v_local_244 = heff_get_n(v_b_241, 2, 3);
  V v_key_245 = heff_take_field(v_a_240, 0);
  V v_member_246 = heff_take_field(v_a_240, 1);
  V v_local_247 = heff_get_n(v_a_240, 2, 3);
  if (heff_strEq_c(v_key_245, v_key_242)) {
    V v_x2_248 = v_member_243;
    switch (heff_tag_of(v_member_246)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nothing: {
        V v_x2_249 = v_local_244;
        switch (heff_tag_of(v_local_247)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x2_249, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_local_247, 0);
          heff_take_n(v_local_247, 1ULL, 1);
          V v_start_2412 = heff_take_field(v_a_2411, 0);
          V v_end_2413 = heff_get_n(v_a_2411, 1, 2);
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            heff_drop(v_start_2412);
            heff_drop(v_end_2413);
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            V v_b_2414 = heff_field(v_x2_249, 0);
            heff_take_n(v_x2_249, 1ULL, 1);
            V v_start_2415 = heff_take_field(v_b_2414, 0);
            V v_end_2416 = heff_get_n(v_b_2414, 1, 2);
            V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_start_2412, v_start_2415, 0) && heff_intEq_c_lent(v_end_2413, v_end_2416, 0)));
            heff_drop(v_start_2412);
            heff_drop(v_end_2413);
            heff_drop(v_start_2415);
            heff_drop(v_end_2416);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        default: return heff_nomatch(v_local_247);
        }
      }
      case TAG_Just: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop(v_local_244);
        heff_drop(v_local_247);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    case TAG_Just: {
      V v_a_2418 = heff_field(v_member_246, 0);
      heff_take_n(v_member_246, 1ULL, 1);
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nothing: {
        heff_drop(v_local_244);
        heff_drop(v_local_247);
        heff_drop(v_a_2418);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_x2_248, 0);
        heff_take_n(v_x2_248, 1ULL, 1);
        if (heff_strEq_c(v_a_2418, v_b_2419)) {
          V v_x2_2420 = v_local_244;
          switch (heff_tag_of(v_local_247)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_Nothing: {
              return NTAG(TAG_True);
            }
            case TAG_Just: {
              heff_take_n(v_x2_2420, 0ULL, 1);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          case TAG_Just: {
            V v_a_2422 = heff_field(v_local_247, 0);
            heff_take_n(v_local_247, 1ULL, 1);
            V v_start_2423 = heff_take_field(v_a_2422, 0);
            V v_end_2424 = heff_get_n(v_a_2422, 1, 2);
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_Nothing: {
              heff_drop(v_start_2423);
              heff_drop(v_end_2424);
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2425 = heff_field(v_x2_2420, 0);
              heff_take_n(v_x2_2420, 1ULL, 1);
              V v_start_2426 = heff_take_field(v_b_2425, 0);
              V v_end_2427 = heff_get_n(v_b_2425, 1, 2);
              V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_start_2423, v_start_2426, 0) && heff_intEq_c_lent(v_end_2424, v_end_2427, 0)));
              heff_drop(v_start_2423);
              heff_drop(v_end_2424);
              heff_drop(v_start_2426);
              heff_drop(v_end_2427);
              return v_ret_24bool;
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          default: return heff_nomatch(v_local_247);
          }
        } else {
          heff_drop(v_local_244);
          heff_drop(v_local_247);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_member_246);
    }
  } else {
    heff_drop(v_member_243);
    heff_drop(v_local_244);
    heff_drop(v_member_246);
    heff_drop(v_local_247);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eeqTarget(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2edeclSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edeclSites_entry, 2, 0};

V g_heff_2ebuild_2equery_2edeclSites(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      V v_t_249 = (g_list_2emap_24s1675313341x192238134(v_eqs_248));
      V v_sps_2410 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_fsp_245, v_t_249});
      HeffT2 v_t_2411 = (g_list_2efind_24s279352081x1530195138_24cpr(v_f_244, heff_get_n(v_c_240, 7, 14)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_o_2414 = v_field_2413;
          return (g_list_2emap_24s148260373x1589531897(heff_get_n(v_o_2414, 1, 2), v_f_244, v_sps_2410));
        } else {
          heff_drop(v_f_244);
          heff_drop_tag(v_sps_2410, 2);
          heff_drop(v_field_2413);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclDefine: {
      V v_x_2415 = heff_field(v_x21_242, 0);
      V v_xsp_2416 = heff_field(v_x21_242, 1);
      V v_body_2419 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      HeffT2 v_t_2420 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_2415, heff_dup(heff_rfield(v_c_240, 7))));
      V v_t_2425;
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_o_2423 = v_field_2422;
          V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2416, NTAG(TAG_Nil)});
          v_t_2425 = (g_list_2emap_24s148260373x1589531897(heff_get_n(v_o_2423, 1, 2), heff_dup(v_x_2415), v_t_2424));
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_xsp_2416);
          heff_drop(v_field_2422);
          v_t_2425 = NTAG(TAG_Nil);
        }
      }
      V v_ms_2426 = ({ V a_0 = v_body_2419; V r_ = (g_heff_2ebuild_2equery_2esumTags(a_0)); heff_drop(v_body_2419); r_; });
      HeffT2 v_t_2427 = ({ V a_0 = v_x_2415; V a_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, a_1)); heff_drop(v_x_2415); r_; });
      V v_t_2431;
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_o_2430 = v_field_2429;
          v_t_2431 = (g_list_2emap_24s1276696116x507290452(heff_get_n(v_o_2430, 1, 2), v_ms_2426));
        } else {
          heff_drop(v_ms_2426);
          heff_drop(v_field_2429);
          v_t_2431 = NTAG(TAG_Nil);
        }
      }
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2425, v_t_2431);
    }
    case TAG_DeclTheory: {
      V v_x_2432 = heff_field(v_x21_242, 0);
      V v_xsp_2433 = heff_field(v_x21_242, 1);
      V v_x214_2435 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      switch (heff_tag_of(v_x214_2435)) {
      case TAG_At: {
        V v_x2141_2436 = heff_field(v_x214_2435, 0);
        V v_ru_24x214_2435_24At = heff_take_reuse_n(v_x214_2435, 1ULL, 2);
        switch (heff_tag_of(v_x2141_2436)) {
        case TAG_EVar: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETag: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EInt: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EFloat: {
          heff_take_na(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EString: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EBinary: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ERune: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWord: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EApp: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EProject: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ENamed: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EPi: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELam: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EAnn: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ESpec: {
          heff_take_n(v_x2141_2436, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ESig: {
          V v_fs_2462 = heff_field(v_x2141_2436, 0);
          heff_take_n(v_x2141_2436, 1ULL, 1);
          HeffT2 v_t_2463 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_2432, heff_dup(heff_rfield(v_c_240, 7))));
          V v_t_2468;
          {
            V v_field_2465 = v_t_2463.f[1];
            int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
            if ((v_tag_2464 == ((int64_t)0ULL))) {
              V v_o_2466 = v_field_2465;
              V v_t_2467 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2433, NTAG(TAG_Nil)});
              v_t_2468 = (g_list_2emap_24s148260373x1589531897(heff_get_n(v_o_2466, 1, 2), heff_dup(v_x_2432), v_t_2467));
            } else {
              heff_drop_cell(v_ru_24x2_241_24At, 2);
              heff_drop(v_xsp_2433);
              heff_drop(v_field_2465);
              v_t_2468 = NTAG(TAG_Nil);
            }
          }
          V v_t_2469 = (g_list_2emap_24s2000102784x314586828(v_fs_2462));
          V v_ms_2470 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2469));
          HeffT2 v_t_2471 = ({ V a_0 = v_x_2432; V a_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, a_1)); heff_drop(v_x_2432); r_; });
          V v_t_2475;
          {
            V v_field_2473 = v_t_2471.f[1];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_o_2474 = v_field_2473;
              v_t_2475 = (g_list_2emap_24s1276696116x507290452(heff_get_n(v_o_2474, 1, 2), v_ms_2470));
            } else {
              heff_drop(v_ms_2470);
              heff_drop(v_field_2473);
              v_t_2475 = NTAG(TAG_Nil);
            }
          }
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x214_2435_24At, v_t_2468, v_t_2475));
        }
        case TAG_ESum: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EStruct: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EUpdate: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EMatch: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELetIn: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EDo: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELocal: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EInvalid: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EAssign: {
          heff_take_n(v_x2141_2436, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWhile: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EFor: {
          heff_take_n(v_x2141_2436, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EIfThen: {
          heff_take_n(v_x2141_2436, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EBreak: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EContinue: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EReturn: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ENest: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELazy: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETuple: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETry: {
          heff_take_n(v_x2141_2436, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWith: {
          heff_take_n(v_x2141_2436, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2432);
          heff_drop(v_xsp_2433);
          heff_drop_cell(v_ru_24x214_2435_24At, 2);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_x2141_2436);
        }
      }
      default: return heff_nomatch(v_x214_2435);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_24107 = heff_field(v_x21_242, 0);
      V v_sp_24108 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      HeffT2 v_t_24110 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_24107, heff_get_n(v_c_240, 7, 14)));
      {
        V v_field_24112 = v_t_24110.f[1];
        int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
        if ((v_tag_24111 == ((int64_t)0ULL))) {
          V v_o_24113 = v_field_24112;
          V v_t_24114 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_sp_24108, NTAG(TAG_Nil)});
          return (g_list_2emap_24s148260373x1589531897(heff_get_n(v_o_24113, 1, 2), v_x_24107, v_t_24114));
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24107);
          heff_drop(v_sp_24108);
          heff_drop(v_field_24112);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclTest: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edeclSites(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 1ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_x_243, v_off_241));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_i_248 = v_field_247;
        V v_t_249 = heff_dup(heff_rfield(v_i_248, 2));
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nothing: {
          heff_drop(v_program_240);
          heff_drop_cell(v_ru_24x1_242_24Cons, 2);
          heff_drop_rec(v_i_248, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_k_2410 = heff_field(v_t_249, 0);
          heff_take_n(v_t_249, 1ULL, 1);
          V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
          V v_t_2414 = (g_list_2emap_24tok2(v_ru_24x1_242_24Cons, heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0, 1, 1, (V[]){heff_dup(v_k_2410)}), v_t_2411));
          V v_x1_2415 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2414));
          switch (heff_tag_of(v_x1_2415)) {
          case TAG_Nil: {
            heff_drop_rec(v_i_248, 5);
            heff_drop(v_k_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_x_2416 = heff_field(v_x1_2415, 0);
            heff_take_n(v_x1_2415, 1ULL, 2);
            V v_f_2418 = (g_heff_2ebuild_2equery_2edefinitionIn(v_i_248, v_k_2410, v_x_2416));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2415)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_t_249)}});
        }
      } else {
        heff_drop(v_program_240);
        heff_drop_cell(v_ru_24x1_242_24Cons, 2);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
V g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0(V self, V *args) {
  V v_c2_2412 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c2_2412, 5)), 6, 9);
  return ({ V a_0 = v_k_2410; V a_1 = heff_dup(v_c2_2412); V b_2 = heff_get_n(v_c2_2412, 7, 14); V a_3 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(v_k_2410); heff_drop(b_2); heff_drop(v_t_2413); r_; });
}

HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_list_2efind_24s1953031388x2120050076_24cpr(v_k_241, heff_get_n(v_c_242, 7, 14)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_rest_243);
        V v_o_247 = v_field_246;
        V v_f_248 = heff_get_n(v_o_247, 0, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      } else {
        heff_drop(v_field_246);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  HeffT2 v_t_244 = (g_list_2efind_24s764539875x1185200879_24cpr(v_off_243, heff_get_n(v_ls_242, 1, 2)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_f_247 = v_field_246;
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
      V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
      HeffT2 v_t_2413 = (g_list_2efind_24s1140544609x424148735_24cpr(v_f_247, v_t_2412));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_s_2416 = v_field_2415;
          V v_t_2417 = heff_get_n(v_s_2416, 0, 3);
          V v_t_2418 = heff_dup(heff_rfield(v_t_2417, 1));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nothing: {
            HeffT2 v_t_2419 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2417, 0)));
            {
              V v_field_2421 = v_t_2419.f[1];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                V v_x_2422 = v_field_2421;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2417, v_x_2422})}});
              } else {
                heff_drop_rec(v_t_2417, 3);
                heff_drop(v_field_2421);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Just: {
            V v_m_2423 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 1);
            heff_drop(v_program_240);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2417, v_m_2423})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        } else {
          heff_drop(v_program_240);
          heff_drop(v_field_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_program_240);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_2410));
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_249));
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalFound_entry, 3, 0};

V g_heff_2ebuild_2equery_2elocalFound(V v_c_240, V v_ls_241, V v_off_242) {
top: ;
  HeffT2 v_t_249 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2equery_2elocalFound_lam0, 1, 1, (V[]){v_off_242}), heff_get_n(v_ls_241, 0, 2)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_l_2412 = v_field_2411;
      V v_binder_2413 = heff_take_field(v_l_2412, 1);
      V v_name_2414 = heff_get_n(v_l_2412, 0, 3);
      V v_t_2415 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_c_240, 1, 14), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_binder_2413})});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2415, v_name_2414})});
    } else {
      heff_drop_rec(v_c_240, 14);
      heff_drop(v_field_2411);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalFound(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_off_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binder_244 = heff_take_field(v_l_243, 1);
  V v_uses_245 = heff_get_n(v_l_243, 2, 3);
  V v_sp_246 = v_binder_244;
  V v_start_247 = heff_take_field(v_sp_246, 0);
  V v_end_248 = heff_get_n(v_sp_246, 1, 2);
  if ((heff_intLe_c_lent(v_start_247, v_off_242, 0) && heff_intLe_c_lent(v_off_242, v_end_248, 0))) {
    heff_drop(v_off_242);
    heff_drop(v_uses_245);
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    return ({ V a_0 = v_off_242; V a_1 = v_uses_245; V r_ = (g_list_2eany_24s464681941x898021545(a_0, a_1)); heff_drop(v_uses_245); r_; });
  }
}
Clo g_heff_2ebuild_2equery_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etargetIn_entry, 4, 0};

V g_heff_2ebuild_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(heff_dup(v_c_241), heff_dup(v_off_243)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_i_247 = v_field_246;
      V v_key_248 = heff_take_field(v_i_247, 2);
      V v_member_249 = heff_take_field(v_i_247, 3);
      V v_name_2410 = heff_get_n(v_i_247, 1, 5);
      switch (heff_tag_of(v_key_248)) {
      case TAG_Nothing: {
        heff_drop(v_member_249);
        heff_drop(v_name_2410);
        HeffT2 v_t_2411 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(heff_dup(v_program_240), heff_dup(v_c_241), heff_dup(v_off_243)));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          HeffT2 v_t_2414 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            V v_x2_2417 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_field_2416);
              heff_drop(v_x2_2417);
              V v_x_2418 = v_field_2413;
              return heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
            } else {
              heff_drop(v_field_2413);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                heff_drop(v_x2_2417);
                V v_x_2419 = v_field_2416;
                return heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
              } else {
                heff_drop(v_field_2416);
                return v_x2_2417;
              }
            }
          }
        }
      }
      case TAG_Just: {
        V v_k_2420 = heff_field(v_key_248, 0);
        V v_ru_24key_248_24Just = heff_take_reuse_n(v_key_248, 1ULL, 1);
        heff_drop(v_c_241);
        heff_drop(v_ls_242);
        heff_drop(v_off_243);
        V v_t_2421;
        if ((heff_dup(v_member_249) == NTAG(TAG_True))) {
          heff_drop(v_member_249);
          v_t_2421 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2420, heff_tag_n(TAG_Just, 1, (V[]){v_name_2410}), NTAG(TAG_Nothing)});
        } else {
          heff_drop(v_member_249);
          heff_drop(v_name_2410);
          v_t_2421 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2420, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        }
        V v_t_2422 = heff_dup(heff_rfield(v_t_2421, 1));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          HeffT2 v_t_2423 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2421, 0)));
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2425;
              return heff_tag_at_n(v_ru_24key_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2421, v_x_2426})});
            } else {
              heff_drop_cell(v_ru_24key_248_24Just, 1);
              heff_drop_rec(v_t_2421, 3);
              heff_drop(v_field_2425);
              return NTAG(TAG_Nothing);
            }
          }
        }
        case TAG_Just: {
          V v_m_2427 = heff_field(v_t_2422, 0);
          heff_take_n(v_t_2422, 1ULL, 1);
          heff_drop(v_program_240);
          return heff_tag_at_n(v_ru_24key_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2421, v_m_2427})});
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      default: return heff_nomatch(v_key_248);
      }
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_2428 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(heff_dup(v_program_240), heff_dup(v_c_241), heff_dup(v_off_243)));
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        HeffT2 v_t_2431 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
        {
          V v_field_2433 = v_t_2431.f[1];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          V v_x2_2434 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
          if ((v_tag_2429 == ((int64_t)0ULL))) {
            heff_drop(v_field_2433);
            heff_drop(v_x2_2434);
            V v_x_2435 = v_field_2430;
            return heff_tag_n(TAG_Just, 1, (V[]){v_x_2435});
          } else {
            heff_drop(v_field_2430);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              heff_drop(v_x2_2434);
              V v_x_2436 = v_field_2433;
              return heff_tag_n(TAG_Just, 1, (V[]){v_x_2436});
            } else {
              heff_drop(v_field_2433);
              return v_x2_2434;
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2etargetIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2euseOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2euseOf_entry, 3, 0};

V g_heff_2ebuild_2equery_2euseOf(V v_t_240, V v_name_241, V v_i_242) {
top: ;
  V v_key_243 = heff_take_field(v_i_242, 2);
  V v_member_244 = heff_take_field(v_i_242, 3);
  V v_name_245 = heff_take_field(v_i_242, 1);
  V v_span_246 = heff_get_n(v_i_242, 0, 5);
  V v_key_247 = heff_take_field(v_t_240, 0);
  V v_member_248 = heff_get_n(v_t_240, 1, 3);
  switch (heff_tag_of(v_key_243)) {
  case TAG_Nothing: {
    heff_drop(v_member_244);
    heff_drop(v_name_245);
    heff_drop_rec(v_span_246, 2);
    heff_drop(v_key_247);
    heff_drop(v_member_248);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_a_249 = heff_field(v_key_243, 0);
    V v_ru_24key_243_24Just = heff_take_reuse_n(v_key_243, 1ULL, 1);
    if (heff_strEq_c(v_a_249, v_key_247)) {
      if ((heff_dup(v_member_244) == NTAG(TAG_True))) {
        heff_drop(v_member_244);
        switch (heff_tag_of(v_member_248)) {
        case TAG_Nothing: {
          heff_drop(v_name_245);
          heff_drop_rec(v_span_246, 2);
          heff_drop_cell(v_ru_24key_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_member_248, 0);
          heff_take_n(v_member_248, 1ULL, 1);
          if (heff_strEq_c(v_a_2410, v_name_245)) {
            V v_x_2411 = heff_take_field(v_span_246, 0);
            V v_y_2412 = heff_intSub(heff_dup(heff_rfield(v_span_246, 1)), heff_strLength_lent(v_name_241, 0));
            V v_t_2413;
            if (heff_intLe_c_lent(v_x_2411, v_y_2412, 0)) {
              heff_drop(v_x_2411);
              v_t_2413 = v_y_2412;
            } else {
              heff_drop(v_y_2412);
              v_t_2413 = v_x_2411;
            }
            V v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_span_246, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_at_n(v_ru_24key_243_24Just, TAG_Just, 1, (V[]){v_t_2414});
          } else {
            heff_drop_rec(v_span_246, 2);
            heff_drop_cell(v_ru_24key_243_24Just, 1);
            return NTAG(TAG_Nothing);
          }
        }
        default: return heff_nomatch(v_member_248);
        }
      } else {
        heff_drop(v_member_244);
        heff_drop(v_name_245);
        switch (heff_tag_of(v_member_248)) {
        case TAG_Nothing: {
          V v_x_2415 = heff_take_field(v_span_246, 0);
          V v_y_2416 = heff_intSub(heff_dup(heff_rfield(v_span_246, 1)), heff_strLength_lent(v_name_241, 0));
          V v_t_2417;
          if (heff_intLe_c_lent(v_x_2415, v_y_2416, 0)) {
            heff_drop(v_x_2415);
            v_t_2417 = v_y_2416;
          } else {
            heff_drop(v_y_2416);
            v_t_2417 = v_x_2415;
          }
          V v_t_2418 = ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_span_246, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_at_n(v_ru_24key_243_24Just, TAG_Just, 1, (V[]){v_t_2418});
        }
        case TAG_Just: {
          heff_take_n(v_member_248, 0ULL, 1);
          heff_drop_rec(v_span_246, 2);
          heff_drop_cell(v_ru_24key_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_member_248);
        }
      }
    } else {
      heff_drop(v_member_244);
      heff_drop(v_name_245);
      heff_drop_rec(v_span_246, 2);
      heff_drop(v_member_248);
      heff_drop_cell(v_ru_24key_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_key_243);
  }
}
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2euseOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2efixityLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityLine_str1, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityLine_str2, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityLine_str3, 5, "infix");
Clo g_heff_2ebuild_2equery_2efixityLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efixityLine_entry, 3, 0};

V g_heff_2ebuild_2equery_2efixityLine(V v_name_240, V v_src_241, V v_p_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2efixityLine_str0), v_src_241, v_p_242, 1);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_244 = v_j_243;
  }
  V v_ws_245 = ({ V a_0 = heff_dup(v_p_242); V b_1 = heff_strSlice_lent(v_src_241, v_p_242, v_t_244, 6); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsOf(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_ws_245)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_w_246 = heff_dup(heff_field(v_ws_245, 0));
    if ((heff_strEq_c(heff_dup(heff_rfield(v_w_246, 0)), ((V)&g_heff_2ebuild_2equery_2efixityLine_str1)) || (heff_strEq_c(heff_dup(heff_rfield(v_w_246, 0)), ((V)&g_heff_2ebuild_2equery_2efixityLine_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_w_246, 0)), ((V)&g_heff_2ebuild_2equery_2efixityLine_str3))))) {
      heff_drop_rec(v_w_246, 2);
      return (g_list_2emap_24f1651437062x1594169608(v_name_240, v_ws_245));
    } else {
      heff_drop_tag(v_ws_245, 2);
      heff_drop_rec(v_w_246, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_ws_245);
  }
}
V g_heff_2ebuild_2equery_2efixityLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2efixityLine(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2elineStartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elineStartOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2elineStartOf(V v_src_240, V v_p_241) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_p_241, 1) && !(heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)))) == ((int64_t)10ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_p_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_p_241 = t_1;
    goto top;
  } else {
    return v_p_241;
  }
}
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elineStartOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2einStringGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einStringGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2einStringGo(V v_src_240, V v_i_241, V v_p_242, V v_inside_243) {
top: ;
  if (heff_intLe_c_lent(v_p_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    return v_inside_243;
  } else {
    if (((heff_dup(v_inside_243) == NTAG(TAG_True)) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)92ULL)))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(2LL));
      V t_2 = v_p_242;
      V t_3 = v_inside_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_p_242 = t_2;
      v_inside_243 = t_3;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)34ULL))) {
        V v_t_244 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
        heff_drop(v_inside_243);
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_t_244;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2einStringGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eisLabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisLabelAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2eisLabelAt(V v_src_240, V v_p_241, V v_n_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242))));
  V v_ret_24bool = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_t_243, 0)) == ((int64_t)61ULL)) && ({ V v_t_244 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242)))); int c_ = ({ V v_x_245 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_t_244), MK_INT(1LL))); int c_ = ((heff_peek_word(v_x_245) == ((int64_t)61ULL)) ? 0 : ({ V v_x_246 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_246, 1) && ({ V v_t_247 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_249 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_247), MK_INT(1LL))); int c_ = ((heff_peek_word(v_t_249) == ((int64_t)123ULL)) || ({ V v_t_248 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_2410 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_248), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2410) == ((int64_t)44ULL)); heff_drop(v_t_2410); c_; }); heff_drop(v_t_248); c_; })); heff_drop(v_t_249); c_; }); heff_drop(v_t_247); c_; })); heff_drop(v_x_246); c_; })); heff_drop(v_x_245); c_; }); heff_drop(v_t_244); c_; })));
  heff_drop(v_p_241);
  heff_drop(v_n_242);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eisLabelAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eexpectedFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedFits_entry, 4, 0};

V g_heff_2ebuild_2equery_2eexpectedFits(V v_t_240, V v_src_241, V v_n_242, V v_p_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_241, heff_dup(v_p_243)));
  V v_x1_245 = (g_heff_2ebuild_2equery_2einStringGo(v_src_241, v_t_244, heff_dup(v_p_243), NTAG(TAG_False)));
  if (!(heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    V v_t_246 = heff_get_n(v_t_240, 1, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_x1_247 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, v_p_243, v_n_242));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
      heff_drop(v_x1_247);
      return v_ret_24bool;
    }
    case TAG_Just: {
      V v_m_248 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_m_248, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_m_248, MK_INT(0LL), 2)) <= ((int64_t)90ULL)) : 1)) {
        heff_drop(v_m_248);
        V v_t_249 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, heff_dup(v_p_243), v_n_242));
        V v_ret_24bool = heff_bool(((heff_dup(v_t_249) == NTAG(TAG_True)) || (heff_intLt_c_lent(MK_INT(0LL), v_p_243, 1) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_241), heff_intSub(heff_dup(v_p_243), MK_INT(1LL)))) == ((int64_t)46ULL)))));
        heff_drop(v_p_243);
        heff_drop(v_t_249);
        return v_ret_24bool;
      } else {
        heff_drop(v_m_248);
        V v_x1_2410 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, v_p_243, v_n_242));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
        heff_drop(v_x1_2410);
        return v_ret_24bool;
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_n_242);
    heff_drop(v_p_243);
    heff_drop(v_x1_245);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eexpectedFits(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str0, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str1, 8, "-- | >>>");
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexpectedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2eexpectedIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_source_243 = heff_take_field(v_c_242, 3);
  V v_top_244 = heff_get_n(v_c_242, 5, 14);
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_top_244, 4, 9)));
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam0, 2, 3, (V[]){v_source_243, v_t_240, heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eexpectedIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_source_243 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_t_240; V a_1 = v_source_243; V a_2 = heff_strLength(v_name_241); V a_3 = v_p_2424; V r_ = (g_heff_2ebuild_2equery_2eexpectedFits(a_0, a_1, a_2, a_3)); heff_drop(v_source_243); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_source_243 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_248 = heff_dup(v_source_243);
  V v_sp_249 = heff_dup(heff_rfield(v_x_247, 0));
  V v_start_2410 = heff_take_field(v_sp_249, 0);
  V v_end_2411 = heff_get_n(v_sp_249, 1, 2);
  V v_start_2412 = v_start_2410;
  V v_t_2413 = heff_strSlice(heff_dup(v_src_248), heff_dup(v_start_2412), heff_intAdd(v_start_2412, MK_INT(8LL)));
  V v_t_2414 = heff_bool(heff_strEq_c_lent(v_t_2413, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str0), 2));
  heff_drop(v_t_2413);
  V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_src_248; V a_2 = v_end_2411; V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(a_0, a_1, a_2)); heff_drop(v_t_2414); heff_drop(v_src_248); heff_drop(v_end_2411); r_; });
  V v_src_2416 = heff_dup(v_source_243);
  V v_sp_2417 = heff_get_n(v_x_247, 0, 2);
  V v_start_2418 = heff_take_field(v_sp_2417, 0);
  V v_end_2419 = heff_get_n(v_sp_2417, 1, 2);
  V v_start_2420 = v_start_2418;
  V v_t_2421 = heff_strSlice(heff_dup(v_src_2416), heff_dup(v_start_2420), heff_intAdd(v_start_2420, MK_INT(8LL)));
  V v_t_2422 = heff_bool(heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str1), 2));
  heff_drop(v_t_2421);
  V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_src_2416; V a_2 = v_end_2419; V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(a_0, a_1, a_2)); heff_drop(v_t_2422); heff_drop(v_src_2416); heff_drop(v_end_2419); r_; });
  V v_t_2425 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam1, 1, 3, (V[]){v_t_240, heff_dup(v_source_243), heff_dup(v_name_241)}); V a_1 = v_name_241; V a_2 = v_source_243; V a_3 = heff_get_n(v_t_2415, 1, 3); V a_4 = heff_get_n(v_t_2423, 2, 3); V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsIn(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_name_241); heff_drop(v_source_243); r_; });
  return (g_prelude_2e_2b_2b(v_t_2425, v_acc_246));
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileFound_entry, 5, 0};

V g_heff_2ebuild_2equery_2einFileFound(V v_t_240, V v_name_241, V v_c_242, V v_ss_243, V v_found_244) {
top: ;
  V v_defs_245 = (g_list_2emap_24s388004800x1261967008(v_ss_243));
  V v_t_248;
  switch (heff_tag_of(v_found_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_248 = (g_heff_2ebuild_2equery_2emoreIn(v_t_240, v_name_241, heff_dup(v_c_242)));
    break;
  }
  default: heff_nomatch(v_found_244);
  }
  V v_spans_249 = (g_prelude_2e_2b_2b(v_found_244, v_t_248));
  V v_t_2410 = (g_list_2esortBy_24s1895001621x1916669639(v_spans_249));
  V v_t_2411 = (g_heff_2ebuild_2equery_2enubByStart(v_t_2410));
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileFound_lam0, 1, 2, (V[]){v_defs_245, v_c_242}), v_t_2411));
}
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2einFileFound(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args) {
  V v_sp_2412 = args[0];
  V v_defs_245 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_defines_2413 = ({ V a_0 = heff_dup(v_sp_2412); V a_1 = v_defs_245; V r_ = (g_list_2eany_24s1690524253x1144193326(a_0, a_1)); heff_drop(v_defs_245); r_; });
  return heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_c_242, 1)), heff_get_n(v_c_242, 3, 14), v_sp_2412, v_defines_2413});
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileSites_entry, 4, 0};

V g_heff_2ebuild_2equery_2einFileSites(V v_t_240, V v_name_241, V v_c_242, V v_ss_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_242, 5)), 7, 9);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam0, 1, 2, (V[]){heff_dup(v_t_240), heff_dup(v_name_241)}), v_t_244));
  V v_t_247 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_246));
  V v_t_248 = (g_list_2emap_24s388004800x1261967008(heff_dup(v_ss_243)));
  V v_t_249 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_242, 4)));
  HeffT2 v_t_2410 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_249));
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[0]);
    v_t_2414 = (g_list_2emap_24f922554743x1845028609(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam1, 1, 1, (V[]){heff_dup(v_ss_243)}), v_field_2412));
  }
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_248, v_t_2414));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_247, v_t_2415));
  return (g_heff_2ebuild_2equery_2einFileFound(v_t_240, v_name_241, v_c_242, v_ss_243, v_t_2416));
}
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2einFileSites(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_t_240; V a_1 = v_name_241; V a_2 = v_i_245; V r_ = (g_heff_2ebuild_2equery_2euseOf(a_0, a_1, a_2)); heff_drop(v_name_241); r_; });
}
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args) {
  V v_f_2413 = args[0];
  V v_ss_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_f_2413; V a_1 = v_ss_243; V r_ = (g_list_2eany_24s1011930416x23610018(a_0, a_1)); heff_drop(v_ss_243); r_; });
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eoccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eoccurrences_entry, 3, 0};

V g_heff_2ebuild_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24f297647854x479783049(NTAG(TAG_Nil), v_program_240));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam0, 2, 2, (V[]){v_t_241, heff_dup(v_name_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  }
  case TAG_Just: {
    V v_b_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HeffT2 v_t_2416 = (g_list_2efind_24s2106830784x1074299306_24cpr(v_t_241, v_program_240));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_c_2419 = v_field_2418;
        V v_t_2420 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2419, 4)));
        V v_t_2421 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2420));
        HeffT2 v_t_2422 = (g_list_2efind_24s343666469x451168509_24cpr(heff_dup(v_b_2415), heff_get_n(v_t_2421, 0, 2)));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_l_2425 = v_field_2424;
            V v_binder_2426 = heff_take_field(v_l_2425, 1);
            V v_uses_2427 = heff_get_n(v_l_2425, 2, 3);
            V v_t_2428 = (g_list_2esortBy_24s1895001621x1916669639(heff_tag_n(TAG_Cons, 2, (V[]){v_binder_2426, v_uses_2427})));
            HEFF_LAST return g_list_2emap_24s1224226459x189329095(v_c_2419, v_b_2415, v_t_2428);
          } else {
            heff_drop(v_b_2415);
            heff_drop_rec(v_c_2419, 14);
            heff_drop(v_field_2424);
            return NTAG(TAG_Nil);
          }
        }
      } else {
        heff_drop(v_b_2415);
        heff_drop(v_field_2418);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2equery_2eoccurrences(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2equery_2edeclSites(v_x_246, v_x_249));
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_248));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2412, 0, 3), v_t_241));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_246, 4))));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam1, 2, 1, (V[]){heff_dup(v_x_246)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam2, 1, 1, (V[]){heff_dup(v_t_241)}), v_t_2411));
  V v_t_2414 = ({ V a_0 = v_t_241; V a_1 = v_name_242; V a_2 = v_x_246; V a_3 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2einFileSites(a_0, a_1, a_2, a_3)); heff_drop(v_name_242); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_245));
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry, 2, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_d_242 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if (((heff_peek_word(v_d_242) == ((int64_t)47ULL)) ? 0 : ((heff_peek_word(v_d_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_d_242) == ((int64_t)39ULL)) || ((heff_peek_word(v_d_242) == ((int64_t)47ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)57ULL)))))))))) {
      heff_drop(v_d_242);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_d_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry, 23, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V v_box_24lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_box_24lit_248, V v_box_24lit_249, V v_box_24lit_2410, V v_box_24lit_2411, V v_box_24lit_2412, V v_box_24lit_2413, V v_box_24lit_2414, V v_box_24lit_2415, V v_box_24lit_2416, V v_box_24lit_2417, V v_box_24lit_2418, V v_box_24lit_2419, V v_box_24lit_2420, V v_s_2421, V v_box_24i_2422) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_lit_245 = heff_unbox_word(v_box_24lit_245);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_248 = heff_unbox_word(v_box_24lit_248);
  int64_t v_lit_249 = heff_unbox_word(v_box_24lit_249);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
  int64_t v_lit_2411 = heff_unbox_word(v_box_24lit_2411);
  int64_t v_lit_2412 = heff_unbox_word(v_box_24lit_2412);
  int64_t v_lit_2413 = heff_unbox_word(v_box_24lit_2413);
  int64_t v_lit_2414 = heff_unbox_word(v_box_24lit_2414);
  int64_t v_lit_2415 = heff_unbox_word(v_box_24lit_2415);
  int64_t v_lit_2416 = heff_unbox_word(v_box_24lit_2416);
  int64_t v_lit_2417 = heff_unbox_word(v_box_24lit_2417);
  int64_t v_lit_2418 = heff_unbox_word(v_box_24lit_2418);
  int64_t v_lit_2419 = heff_unbox_word(v_box_24lit_2419);
  int64_t v_lit_2420 = heff_unbox_word(v_box_24lit_2420);
  int64_t v_i_2422 = heff_unbox_word(v_box_24i_2422);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_2421, 0)) <= v_i_2422)) {
    return NTAG(TAG_True);
  } else {
    V v_a_2423 = heff_strByteAt_lent(v_s_2421, heff_box_word(v_i_2422), 2);
    if ((((heff_peek_word(v_a_2423) == v_lit_240) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_241) || ((heff_peek_word(v_a_2423) == v_lit_242) || ((heff_peek_word(v_a_2423) == v_lit_243) || (((v_lit_244 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_245)) || (((v_lit_246 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_247)) || ((v_lit_248 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_249)))))))) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2410) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2411) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2412) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2413) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2414) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2415) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2416) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2417) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2418) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2419) ? 0 : !(heff_peek_word(v_a_2423) == v_lit_2420))))))))))))) {
      heff_drop(v_a_2423);
      int64_t t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      int64_t t_8 = v_lit_248;
      int64_t t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      int64_t t_11 = v_lit_2411;
      int64_t t_12 = v_lit_2412;
      int64_t t_13 = v_lit_2413;
      int64_t t_14 = v_lit_2414;
      int64_t t_15 = v_lit_2415;
      int64_t t_16 = v_lit_2416;
      int64_t t_17 = v_lit_2417;
      int64_t t_18 = v_lit_2418;
      int64_t t_19 = v_lit_2419;
      int64_t t_20 = v_lit_2420;
      V t_21 = v_s_2421;
      int64_t t_22 = (v_i_2422 + ((int64_t)1ULL));
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_lit_2412 = t_12;
      v_lit_2413 = t_13;
      v_lit_2414 = t_14;
      v_lit_2415 = t_15;
      v_lit_2416 = t_16;
      v_lit_2417 = t_17;
      v_lit_2418 = t_18;
      v_lit_2419 = t_19;
      v_lit_2420 = t_20;
      v_s_2421 = t_21;
      v_i_2422 = t_22;
      goto top;
    } else {
      heff_drop(v_a_2423);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a) {
  (void)self;
  V a21 = a[21]; V r = g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15], a[16], a[17], a[18], a[19], a[20], a21, a[22]); heff_drop(a21); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2, 43, "` is a primitive: its name is the runtime's");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4, 4, "` is");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5, 1, "`");

HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V v_t_240, V v_old_241, V v_new_242) {
top: ;
  V v_member_243 = heff_take_field(v_t_240, 1);
  V v_local_244 = heff_take_field(v_t_240, 2);
  V v_key_245 = heff_get_n(v_t_240, 0, 3);
  V v_t_247;
  switch (heff_tag_of(v_member_243)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_member_243, 0ULL, 1);
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_member_243);
  }
  V v_t_2415;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2420;
    switch (heff_tag_of(v_local_244)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_local_244, 0ULL, 1);
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_local_244);
    }
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      v_t_2415 = heff_bool(!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0), v_key_245, MK_INT(0LL), 5)));
      heff_drop(v_key_245);
      break;
    }
    case TAG_False: {
      heff_drop(v_key_245);
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
  } else {
    heff_drop(v_local_244);
    heff_drop(v_key_245);
    heff_drop(v_t_247);
    v_t_2415 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_new_242);
    V v_f_249 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
  }
  case TAG_False: {
    V v_x_2410 = (g_heff_2ebuild_2equery_2enameClass(v_old_241));
    V v_y_2411 = (g_heff_2ebuild_2equery_2enameClass(v_new_242));
    if (!heff_intEq_c_lent(v_x_2410, v_y_2411, 0)) {
      heff_drop(v_x_2410);
      heff_drop(v_y_2411);
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4)));
      V v_f_2413 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5), heff_strAppend(v_new_242, v_t_2412));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
    } else {
      heff_drop(v_old_241);
      heff_drop(v_new_242);
      heff_drop(v_x_2410);
      heff_drop(v_y_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_2415)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecommentAbove_str0, 2, "--");
Clo g_heff_2ebuild_2equery_2ecommentAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecommentAbove_entry, 3, 0};

V g_heff_2ebuild_2equery_2ecommentAbove(V v_src_240, V v_start_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_start_241, MK_INT(0LL), 2)) {
    heff_drop(v_start_241);
    return v_acc_242;
  } else {
    V v_t_243 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
    V v_s_244 = heff_strSlice(heff_dup(v_src_240), v_t_243, heff_intSub(heff_dup(v_start_241), MK_INT(1LL)));
    V v_t_245 = (g_prelude_2eskipSpaces(v_s_244, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
    V v_t_247 = (g_prelude_2eskipSpaces(v_s_244, heff_box_word(v_t_246), MK_INT(-1LL)));
    V v_s_248 = heff_strSlice(v_s_244, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_248, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2equery_2ecommentAbove_str0))) {
      V v_t_249 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_t_2410 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_s_2411 = heff_strSlice(heff_dup(v_src_240), v_t_2410, heff_intSub(v_start_241, MK_INT(1LL)));
      V v_t_2412 = (g_prelude_2eskipSpaces(v_s_2411, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_s_2411, 0)) - ((int64_t)1ULL));
      V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2411, heff_box_word(v_t_2413), MK_INT(-1LL)));
      V v_t_2415 = heff_strSlice(v_s_2411, v_t_2412, heff_intAdd(v_t_2414, MK_INT(1LL)));
      V t_0 = v_src_240;
      V t_1 = v_t_249;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_acc_242});
      v_src_240 = t_0;
      v_start_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_start_241);
      return v_acc_242;
    }
  }
}
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2ecommentAbove(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str0, 3, ">>>");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str1, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str3, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str4, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str5, 3, "```");
Clo g_heff_2ebuild_2equery_2edocMdStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMdStep_entry, 3, 0};

V g_heff_2ebuild_2equery_2edocMdStep(V v_lang_240, V v_m_241, V v_l_242) {
top: ;
  V v_code_243 = heff_take_field(v_m_241, 1);
  V v_out_244 = heff_take_field(v_m_241, 0);
  V v_expecting_245 = heff_get_n(v_m_241, 2, 3);
  if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2equery_2edocMdStep_str0))) {
    heff_drop(v_expecting_245);
    V v_t_246;
    if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
      heff_drop(v_lang_240);
      heff_drop(v_code_243);
      v_t_246 = v_out_244;
    } else {
      heff_drop(v_code_243);
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2equery_2edocMdStep_str1), v_lang_240), v_out_244});
    }
    return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_246}), NTAG(TAG_True), NTAG(TAG_True)});
  } else {
    heff_drop(v_lang_240);
    if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
      if ((heff_dup(v_expecting_245) == NTAG(TAG_True))) {
        heff_drop(v_expecting_245);
        V v_t_247 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
        V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_248), MK_INT(-1LL)));
        V v_t_2410 = heff_strSlice(heff_dup(v_l_242), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
        V v_x1_2411 = heff_bool(heff_strEq_c_lent(v_t_2410, ((V)&g_heff_2ebuild_2equery_2edocMdStep_str2), 2));
        heff_drop(v_t_2410);
        if (!(heff_dup(v_x1_2411) == NTAG(TAG_True))) {
          heff_drop(v_code_243);
          heff_drop(v_x1_2411);
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_out_244}), NTAG(TAG_True), NTAG(TAG_True)});
        } else {
          heff_drop(v_x1_2411);
          V v_t_2412;
          if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
            heff_drop(v_code_243);
            v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str3), v_out_244});
          } else {
            heff_drop(v_code_243);
            v_t_2412 = v_out_244;
          }
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2412}), NTAG(TAG_False), NTAG(TAG_False)});
        }
      } else {
        heff_drop(v_expecting_245);
        V v_t_2413;
        if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
          heff_drop(v_code_243);
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str4), v_out_244});
        } else {
          heff_drop(v_code_243);
          v_t_2413 = v_out_244;
        }
        return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2413}), NTAG(TAG_False), NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_expecting_245);
      V v_t_2414;
      if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
        heff_drop(v_code_243);
        v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str5), v_out_244});
      } else {
        heff_drop(v_code_243);
        v_t_2414 = v_out_244;
      }
      return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2414}), NTAG(TAG_False), NTAG(TAG_False)});
    }
  }
}
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocMdStep(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ekindOf_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2ekindOf_str1, 7, "theory ");
Clo g_heff_2ebuild_2equery_2ekindOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ekindOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2ekindOf(V v_x_240, V v_text_241) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_text_241, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2ekindOf_str0))) {
    return MK_INT(10LL);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_text_241, MK_INT(0LL), MK_INT(7LL), 6), ((V)&g_heff_2ebuild_2equery_2ekindOf_str1))) {
      return MK_INT(11LL);
    } else {
      V v_c_242 = heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2);
      if (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_242) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) ? !(heff_peek_word(v_c_242) <= ((int64_t)57ULL)) : 1))))))) {
        heff_drop(v_c_242);
        return MK_INT(25LL);
      } else {
        heff_drop(v_c_242);
        return MK_INT(12LL);
      }
    }
  }
}
V g_heff_2ebuild_2equery_2ekindOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ekindOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_ty_246));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_eqs_247)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s496727651x1448898893(a_0, a_1)); heff_drop(v_t_249); r_; });
      return (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    }
    case TAG_DeclDefine: {
      V v_ps_2413 = heff_field(v_x21_241, 2);
      V v_u_2414 = heff_field(v_x21_241, 3);
      V v_body_2415 = heff_field(v_x21_241, 4);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2413)));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_u_2414));
      V v_t_2419 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2415));
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
    }
    case TAG_DeclTheory: {
      V v_ps_2423 = heff_field(v_x21_241, 2);
      V v_body_2424 = heff_field(v_x21_241, 3);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2423)));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2424));
      return (g_prelude_2e_2b_2b(v_t_2426, v_t_2427));
    }
    case TAG_DeclPrimitive: {
      V v_t_2430 = heff_field(v_x21_241, 2);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2430);
    }
    case TAG_DeclTest: {
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      V v_e_2433 = heff_field(v_x21_241, 0);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2433);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str0, 5, "data ");
Clo g_heff_2ebuild_2equery_2esymbolWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolWith_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolWith(V v_c_240, V v_o_241, V v_sp_242, V v_own_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(heff_rfield(v_sp_242, 1)));
  V v_t_245 = ({ V a_0 = heff_rfield(v_o_241, 0); V a_1 = v_t_244; V r_ = (g_heff_2ebuild_2equery_2ekindOf(a_0, a_1)); heff_drop(v_t_244); r_; });
  HeffT2 v_t_246 = (g_list_2efind_24s1702704581x1717241719_24cpr(heff_dup(v_own_243)));
  V v_t_2410;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_s_249 = v_field_248;
      v_t_2410 = heff_get_n(v_s_249, 2, 3);
    } else {
      heff_drop(v_field_248);
      v_t_2410 = (g_heff_2ebuild_2equery_2enameInGo(heff_rfield(v_c_240, 3), heff_rfield(v_o_241, 0), heff_dup(v_sp_242), heff_dup(heff_rfield(v_sp_242, 0))));
    }
  }
  V v_t_2411 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_sp_242); V a_2 = MK_INT(5LL); V b_3 = ((V)&g_heff_2ebuild_2equery_2esymbolWith_str0); V a_4 = MK_INT(22LL); V a_5 = MK_INT(8LL); V a_6 = v_own_243; V r_ = (g_list_2emap_24f530523215x314966509(a_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_3); r_; });
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_240, 4, 14)));
  V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_list_2ekeepIf_24s1950790755x1251737354(heff_dup(v_sp_242), v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2414));
  return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_get_n(v_o_241, 0, 2), v_t_245, v_sp_242, v_t_2410, v_t_2415});
}
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolWith(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_244);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        heff_take_n(v_x41_246, 2ULL, 2);
        V v_t_2410 = (g_list_2ekeepIf_24s257286374x378693326(heff_dup(v_sp_249), heff_dup(v_ss_241)));
        V v_t_2411 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_244, v_sp_249, v_t_2410));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
        V v_u_2413 = (g_heff_2ebuild_2equery_2esymbolsGo_24dps(v_c_240, v_ss_241, v_os_245, v_sps_247, heff_dup(v_cell_2412)));
        heff_drop(v_u_2413);
        return v_cell_2412;
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2esymbols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbols_entry, 1, 0};

V g_heff_2ebuild_2equery_2esymbols(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 4))));
  V v_t_245 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_247 = (g_heff_2ebuild_2equery_2esymbolsGo(heff_dup(v_c_240), v_t_245, heff_dup(heff_rfield(v_c_240, 7)), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam1, 1, 1, (V[]){v_c_240}), v_t_248));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_247, v_t_2415));
  HEFF_LAST return g_list_2esortBy_24s475241097x1080260612(v_t_2416);
}
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbols(a[0]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_243));
  return (g_prelude_2e_2b_2b(v_t_244, v_acc_242));
}
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args) {
  V v_p_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_p_249, 0);
    V v_sp_2411 = heff_field(v_p_249, 1);
    heff_take_n(v_p_249, 3ULL, 2);
    V v_t_2412 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_2411, 0)), heff_dup(heff_rfield(v_sp_2411, 1)));
    V v_t_2413 = ({ V a_0 = v_x_2410; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2equery_2ekindOf(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_2411); V a_3 = heff_dup(heff_rfield(v_sp_2411, 0)); V r_ = (g_heff_2ebuild_2equery_2enameInGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){v_x_2410, v_t_2413, v_sp_2411, v_t_2414, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_p_249);
  }
}