// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define LBL_binder 558177493
#define LBL_broken 566525696
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_end 310101
#define LBL_expecting 1746726246
#define LBL_exposes 1070285678
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_from 9647217
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_member 869372357
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_selection 2055983820
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_to 10466
#define LBL_top 324559
#define LBL_uses 10094739
#define LBL_watches 1357821955
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__kind__span__selection__children[] = {LBL_name, LBL_kind, LBL_span, LBL_selection, LBL_children};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V, V, V, V);
V g_heff_2ebuild_2equery_2einFile(V, V, V);
V g_heff_2ebuild_2equery_2einFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFile_clo;
V g_heff_2ebuild_2equery_2einStringGo(V, V, V, V);
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einStringGo_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eisLabelAt(V, V, V);
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisLabelAt_clo;
V g_heff_2ebuild_2equery_2ekindOf(V, V);
V g_heff_2ebuild_2equery_2ekindOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ekindOf_clo;
HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2elocalDefinition(V, V);
V g_heff_2ebuild_2equery_2elocalDefinition_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDefinition_clo;
V g_heff_2ebuild_2equery_2elocalFound(V, V, V);
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalFound_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2esymbolsGo(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_list_2eany_24s1011930416x23610018(V, V);
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a);
extern Clo g_list_2eany_24s1011930416x23610018_clo;
V g_list_2eany_24s1690524253x1144193326(V, V);
V g_list_2eany_24s1690524253x1144193326_entry(V self, V *a);
extern Clo g_list_2eany_24s1690524253x1144193326_clo;
V g_list_2eany_24s464681941x898021545(V, V);
V g_list_2eany_24s464681941x898021545_entry(V self, V *a);
extern Clo g_list_2eany_24s464681941x898021545_clo;
V g_list_2eascending_24s390745979x1196509894(V, V, V);
V g_list_2eascending_24s390745979x1196509894_entry(V self, V *a);
extern Clo g_list_2eascending_24s390745979x1196509894_clo;
V g_list_2edescending_24s1679501129x89119467(V, V, V);
V g_list_2edescending_24s1679501129x89119467_entry(V self, V *a);
extern Clo g_list_2edescending_24s1679501129x89119467_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V, V);
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
HeffT2 g_list_2efind_24s764539875x1185200879_24cpr(V, V);
HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1950790755x1251737354(V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_clo;
V g_list_2ekeepIf_24s257286374x378693326(V, V);
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f530523215x314966509(V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_clo;
V g_list_2emap_24f922554743x1845028609(V, V);
V g_list_2emap_24f922554743x1845028609_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_clo;
V g_list_2emap_24s1392650298x1192381411(V, V, V);
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_clo;
V g_list_2emap_24s148260373x1589531897(V, V, V);
V g_list_2emap_24s148260373x1589531897_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s384717234x223264907(V, V);
V g_list_2emap_24s384717234x223264907_entry(V self, V *a);
extern Clo g_list_2emap_24s384717234x223264907_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1094647646x865851942(V, V);
V g_list_2emergeRuns_24s1094647646x865851942_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1094647646x865851942_clo;
V g_list_2esortOn_24s227026999x1111027886(V);
V g_list_2esortOn_24s227026999x1111027886_entry(V self, V *a);
extern Clo g_list_2esortOn_24s227026999x1111027886_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_entry, 1, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ(a[0]);
}
Clo g_heff_2ebuild_2equery_2ewordAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242) {
top: ;
  if (heff_intEq_c_lent(v_p_241, MK_INT(0LL), 2)) {
    int64_t v_t_243 = (heff_unbox_word(v_p_241) + heff_unbox_word(heff_strLength_lent(v_x_242, 0)));
    V v_c_244 = heff_strByteAt_lent(v_src_240, heff_box_word(v_t_243), 2);
    V v_ret_24bool = heff_bool(((heff_peek_word(v_c_244) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_244) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_244) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_244)) ? !(heff_peek_word(v_c_244) <= ((int64_t)57ULL)) : 1)))))));
    heff_drop(v_c_244);
    return v_ret_24bool;
  } else {
    V v_c_245 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)));
    if (((heff_peek_word(v_c_245) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_245) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_245) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_245)) ? !(heff_peek_word(v_c_245) <= ((int64_t)57ULL)) : 1))))))) {
      heff_drop(v_c_245);
      V v_t_246 = heff_intAdd(v_p_241, heff_strLength_lent(v_x_242, 0));
      V v_c_247 = heff_strByteAt_lent(v_src_240, v_t_246, 2);
      V v_ret_24bool = heff_bool(((heff_peek_word(v_c_247) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_247) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_247) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_247)) ? !(heff_peek_word(v_c_247) <= ((int64_t)57ULL)) : 1)))))));
      heff_drop(v_c_247);
      return v_ret_24bool;
    } else {
      heff_drop(v_p_241);
      heff_drop(v_c_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ewordAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2etypedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etypedFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2etypedFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    V v_c_242 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)46ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_242);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2etypedFrom(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_box_word(v_i_241)}});
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
Clo g_heff_2ebuild_2equery_2eeqTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eeqTarget_entry, 2, 0};

V g_heff_2ebuild_2equery_2eeqTarget(V v_a_240, V v_b_241) {
top: ;
  V v_key_242 = heff_take_field(v_b_241, 0);
  V v_member_243 = heff_take_field(v_b_241, 1);
  V v_local_244 = heff_get_n(v_b_241, 2, 3);
  V v_key_245 = heff_take_field(v_a_240, 0);
  V v_member_246 = heff_take_field(v_a_240, 1);
  V v_local_247 = heff_get_n(v_a_240, 2, 3);
  if (heff_strEq_c(v_key_245, v_key_242)) {
    V v_x2_248 = v_member_243;
    switch (heff_tag_of(v_member_246)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nothing: {
        V v_x2_249 = v_local_244;
        switch (heff_tag_of(v_local_247)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x2_249, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_local_247, 0);
          heff_take_n(v_local_247, 1ULL, 1);
          V v_start_2412 = heff_take_field(v_a_2411, 0);
          V v_end_2413 = heff_get_n(v_a_2411, 1, 2);
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            heff_drop(v_start_2412);
            heff_drop(v_end_2413);
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            V v_b_2414 = heff_field(v_x2_249, 0);
            heff_take_n(v_x2_249, 1ULL, 1);
            V v_start_2415 = heff_take_field(v_b_2414, 0);
            V v_end_2416 = heff_get_n(v_b_2414, 1, 2);
            V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_start_2412, v_start_2415, 0) && heff_intEq_c_lent(v_end_2413, v_end_2416, 0)));
            heff_drop(v_start_2412);
            heff_drop(v_end_2413);
            heff_drop(v_start_2415);
            heff_drop(v_end_2416);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        default: return heff_nomatch(v_local_247);
        }
      }
      case TAG_Just: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop(v_local_244);
        heff_drop(v_local_247);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    case TAG_Just: {
      V v_a_2418 = heff_field(v_member_246, 0);
      heff_take_n(v_member_246, 1ULL, 1);
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nothing: {
        heff_drop(v_local_244);
        heff_drop(v_local_247);
        heff_drop(v_a_2418);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_x2_248, 0);
        heff_take_n(v_x2_248, 1ULL, 1);
        if (heff_strEq_c(v_a_2418, v_b_2419)) {
          V v_x2_2420 = v_local_244;
          switch (heff_tag_of(v_local_247)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_Nothing: {
              return NTAG(TAG_True);
            }
            case TAG_Just: {
              heff_take_n(v_x2_2420, 0ULL, 1);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          case TAG_Just: {
            V v_a_2422 = heff_field(v_local_247, 0);
            heff_take_n(v_local_247, 1ULL, 1);
            V v_start_2423 = heff_take_field(v_a_2422, 0);
            V v_end_2424 = heff_get_n(v_a_2422, 1, 2);
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_Nothing: {
              heff_drop(v_start_2423);
              heff_drop(v_end_2424);
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2425 = heff_field(v_x2_2420, 0);
              heff_take_n(v_x2_2420, 1ULL, 1);
              V v_start_2426 = heff_take_field(v_b_2425, 0);
              V v_end_2427 = heff_get_n(v_b_2425, 1, 2);
              V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_start_2423, v_start_2426, 0) && heff_intEq_c_lent(v_end_2424, v_end_2427, 0)));
              heff_drop(v_start_2423);
              heff_drop(v_end_2424);
              heff_drop(v_start_2426);
              heff_drop(v_end_2427);
              return v_ret_24bool;
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          default: return heff_nomatch(v_local_247);
          }
        } else {
          heff_drop(v_local_244);
          heff_drop(v_local_247);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_member_246);
    }
  } else {
    heff_drop(v_member_243);
    heff_drop(v_local_244);
    heff_drop(v_member_246);
    heff_drop(v_local_247);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eeqTarget(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2edeclSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edeclSites_entry, 2, 0};

V g_heff_2ebuild_2equery_2edeclSites(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      V v_t_249 = (g_list_2emap_24s1675313341x192238134(v_eqs_248));
      V v_sps_2410 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_fsp_245, v_t_249});
      HeffT2 v_t_2411 = ({ V a_0 = v_f_244; V b_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_o_2414 = v_field_2413;
          return (g_list_2emap_24s148260373x1589531897(heff_get_n(v_o_2414, 1, 2), v_f_244, v_sps_2410));
        } else {
          heff_drop(v_f_244);
          heff_drop_tag(v_sps_2410, 2);
          heff_drop(v_field_2413);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclDefine: {
      V v_x_2415 = heff_field(v_x21_242, 0);
      V v_xsp_2416 = heff_field(v_x21_242, 1);
      V v_body_2419 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      HeffT2 v_t_2420 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_2415, heff_rfield(v_c_240, 7)));
      V v_t_2429;
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_o_2423 = v_field_2422;
          V v_t_2424 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_o_2423, 1, 2), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
          V v_a_2425 = heff_take_field(v_xsp_2416, 0);
          V v_a_2426 = heff_intSub(heff_dup(heff_rfield(v_xsp_2416, 1)), heff_strLength_lent(v_x_2415, 0));
          V v_t_2427;
          if (heff_intLe_c_lent(v_a_2425, v_a_2426, 0)) {
            heff_drop(v_a_2425);
            v_t_2427 = v_a_2426;
          } else {
            heff_drop(v_a_2426);
            v_t_2427 = v_a_2425;
          }
          V v_t_2428 = ({ V rv_0 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_xsp_2416, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_2424, heff_dup(v_x_2415), v_t_2428}), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop_rec(v_xsp_2416, 2);
          heff_drop(v_field_2422);
          v_t_2429 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2430 = v_body_2419;
      V v_ms_2494;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_At: {
        V v_x11_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 2);
        switch (heff_tag_of(v_x11_2431)) {
        case TAG_EVar: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ENotationVar: {
          heff_take_n(v_x11_2431, 0ULL, 3);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EString: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBinary: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ERune: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EWord: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EProject: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ENamed: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPi: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EAnn: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ESpec: {
          heff_take_n(v_x11_2431, 0ULL, 4);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ESig: {
          V v_fs_2460 = heff_field(v_x11_2431, 0);
          heff_take_n(v_x11_2431, 1ULL, 1);
          V v_t_2461 = (g_list_2emap_24s2000102784x314586828(v_fs_2460));
          v_ms_2494 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2461));
          break;
        }
        case TAG_ESum: {
          V v_alts_2462 = heff_field(v_x11_2431, 0);
          heff_take_n(v_x11_2431, 1ULL, 1);
          V v_t_2463 = (g_list_2emap_24s173442543x1801751270(v_alts_2462));
          v_ms_2494 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2463));
          break;
        }
        case TAG_EStruct: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EUpdate: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELetIn: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EDo: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELocal: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EInvalid: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EAssign: {
          heff_take_n(v_x11_2431, 0ULL, 3);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EWhile: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFor: {
          heff_take_n(v_x11_2431, 0ULL, 3);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EIfThen: {
          heff_take_n(v_x11_2431, 0ULL, 2);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBreak: {
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EContinue: {
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EReturn: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ENest: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELazy: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETuple: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETry: {
          heff_take_n(v_x11_2431, 0ULL, 1);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EWith: {
          heff_take_n(v_x11_2431, 0ULL, 4);
          v_ms_2494 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_x11_2431);
        }
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      HeffT2 v_t_2495 = ({ V a_0 = v_x_2415; V b_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(v_x_2415); heff_drop(b_1); r_; });
      V v_t_2499;
      {
        V v_field_2497 = v_t_2495.f[1];
        int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
        if ((v_tag_2496 == ((int64_t)0ULL))) {
          V v_o_2498 = v_field_2497;
          v_t_2499 = (g_list_2emap_24s384717234x223264907(heff_get_n(v_o_2498, 1, 2), v_ms_2494));
        } else {
          heff_drop(v_ms_2494);
          heff_drop(v_field_2497);
          v_t_2499 = NTAG(TAG_Nil);
        }
      }
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2429, v_t_2499);
    }
    case TAG_DeclTheory: {
      V v_x_24100 = heff_field(v_x21_242, 0);
      V v_xsp_24101 = heff_field(v_x21_242, 1);
      V v_x214_24103 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      switch (heff_tag_of(v_x214_24103)) {
      case TAG_At: {
        V v_x2141_24104 = heff_field(v_x214_24103, 0);
        V v_ru_24x214_24103_24At = heff_take_reuse_n(v_x214_24103, 1ULL, 2);
        switch (heff_tag_of(v_x2141_24104)) {
        case TAG_EVar: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ENotationVar: {
          heff_take_n(v_x2141_24104, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETag: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EInt: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EFloat: {
          heff_take_nf(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EString: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EBinary: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ERune: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWord: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EApp: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EProject: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ENamed: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EPi: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELam: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EAnn: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ESpec: {
          heff_take_n(v_x2141_24104, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ESig: {
          V v_fs_24133 = heff_field(v_x2141_24104, 0);
          heff_take_n(v_x2141_24104, 1ULL, 1);
          HeffT2 v_t_24134 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_24100, heff_rfield(v_c_240, 7)));
          V v_t_24143;
          {
            V v_field_24136 = v_t_24134.f[1];
            int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
            if ((v_tag_24135 == ((int64_t)0ULL))) {
              V v_o_24137 = v_field_24136;
              V v_t_24138 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_o_24137, 1, 2), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
              V v_a_24139 = heff_take_field(v_xsp_24101, 0);
              V v_a_24140 = heff_intSub(heff_dup(heff_rfield(v_xsp_24101, 1)), heff_strLength_lent(v_x_24100, 0));
              V v_t_24141;
              if (heff_intLe_c_lent(v_a_24139, v_a_24140, 0)) {
                heff_drop(v_a_24139);
                v_t_24141 = v_a_24140;
              } else {
                heff_drop(v_a_24140);
                v_t_24141 = v_a_24139;
              }
              V v_t_24142 = ({ V rv_0 = v_t_24141; V rr_ = heff_rec_reuse_nf(v_xsp_24101, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              v_t_24143 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_24138, heff_dup(v_x_24100), v_t_24142}), NTAG(TAG_Nil)});
            } else {
              heff_drop_cell(v_ru_24x2_241_24At, 2);
              heff_drop_rec(v_xsp_24101, 2);
              heff_drop(v_field_24136);
              v_t_24143 = NTAG(TAG_Nil);
            }
          }
          V v_t_24144 = (g_list_2emap_24s2000102784x314586828(v_fs_24133));
          V v_ms_24145 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_24144));
          HeffT2 v_t_24146 = ({ V a_0 = v_x_24100; V b_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(v_x_24100); heff_drop(b_1); r_; });
          V v_t_24150;
          {
            V v_field_24148 = v_t_24146.f[1];
            int64_t v_tag_24147 = ((int64_t)v_t_24146.f[0]);
            if ((v_tag_24147 == ((int64_t)0ULL))) {
              V v_o_24149 = v_field_24148;
              v_t_24150 = (g_list_2emap_24s384717234x223264907(heff_get_n(v_o_24149, 1, 2), v_ms_24145));
            } else {
              heff_drop(v_ms_24145);
              heff_drop(v_field_24148);
              v_t_24150 = NTAG(TAG_Nil);
            }
          }
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x214_24103_24At, v_t_24143, v_t_24150));
        }
        case TAG_ESum: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EStruct: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EUpdate: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EMatch: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELetIn: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EDo: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELocal: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EInvalid: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EAssign: {
          heff_take_n(v_x2141_24104, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWhile: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EFor: {
          heff_take_n(v_x2141_24104, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EIfThen: {
          heff_take_n(v_x2141_24104, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EBreak: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EContinue: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EReturn: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ENest: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ELazy: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETuple: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_ETry: {
          heff_take_n(v_x2141_24104, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        case TAG_EWith: {
          heff_take_n(v_x2141_24104, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24100);
          heff_drop_rec(v_xsp_24101, 2);
          heff_drop_cell(v_ru_24x214_24103_24At, 2);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_x2141_24104);
        }
      }
      default: return heff_nomatch(v_x214_24103);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_24182 = heff_field(v_x21_242, 0);
      V v_sp_24183 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      HeffT2 v_t_24185 = ({ V a_0 = v_x_24182; V b_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_24187 = v_t_24185.f[1];
        int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
        if ((v_tag_24186 == ((int64_t)0ULL))) {
          V v_o_24188 = v_field_24187;
          V v_t_24189 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_o_24188, 1, 2), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
          V v_a_24190 = heff_take_field(v_sp_24183, 0);
          V v_a_24191 = heff_intSub(heff_dup(heff_rfield(v_sp_24183, 1)), heff_strLength_lent(v_x_24182, 0));
          V v_t_24192;
          if (heff_intLe_c_lent(v_a_24190, v_a_24191, 0)) {
            heff_drop(v_a_24190);
            v_t_24192 = v_a_24191;
          } else {
            heff_drop(v_a_24191);
            v_t_24192 = v_a_24190;
          }
          V v_t_24193 = ({ V rv_0 = v_t_24192; V rr_ = heff_rec_reuse_nf(v_sp_24183, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_24189, v_x_24182, v_t_24193}), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24182);
          heff_drop_rec(v_sp_24183, 2);
          heff_drop(v_field_24187);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclTest: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edeclSites(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2elocalDefinition_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2elocalDefinition_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2elocalDefinition_lam2(V self, V *args);
V g_heff_2ebuild_2equery_2elocalDefinition_lam3(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalDefinition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalDefinition_entry, 2, 0};

V g_heff_2ebuild_2equery_2elocalDefinition(V v_c_240, V v_off_241) {
top: ;
  V v_c_242 = heff_dup(v_c_240);
  V v_path_243 = heff_take_field(v_c_242, 1);
  V v_source_244 = heff_get_n(v_c_242, 3, 14);
  V v_t_245 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_240, 4)));
  HeffT2 v_t_246 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_245));
  V v_x1_2426;
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_off_249 = heff_dup(v_off_241);
    HeffT2 v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalDefinition_lam0, 1, 1, (V[]){heff_dup(v_off_249)}); V a_1 = v_field_247; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_field_247); r_; });
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_field_248);
        heff_drop(v_off_249);
        V v_l_2419 = v_field_2418;
        V v_t_2420 = heff_rec_n(3, shape_path__source__span, (V[]){v_path_243, v_source_244, heff_get_n(v_l_2419, 1, 3)});
        v_x1_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
      } else {
        heff_drop(v_field_2418);
        HeffT2 v_t_2421 = ({ V a_0 = v_off_249; V a_1 = v_field_248; HeffT2 r_ = (g_list_2efind_24s764539875x1185200879_24cpr(a_0, a_1)); heff_drop(v_field_248); r_; });
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_f_2424 = v_field_2423;
            V v_t_2425 = heff_rec_n(3, shape_path__source__span, (V[]){v_path_243, v_source_244, heff_get_n(v_f_2424, 1, 3)});
            v_x1_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
          } else {
            heff_drop(v_path_243);
            heff_drop(v_source_244);
            heff_drop(v_field_2423);
            v_x1_2426 = NTAG(TAG_Nothing);
          }
        }
      }
    }
  }
  V v_xs_2427 = heff_dup(heff_rfield(v_c_240, 4));
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
  V v_t_2432 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalDefinition_lam1, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  HeffT2 v_t_2433 = ({ V a_0 = v_off_241; V a_1 = v_t_2432; HeffT2 r_ = (g_list_2efind_24s845102114x2128838930_24cpr(a_0, a_1)); heff_drop(v_t_2432); r_; });
  V v_x2_2451;
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_s_2436 = v_field_2435;
      V v_target_2437 = heff_take_field(v_s_2436, 0);
      V v_span_2438 = heff_get_n(v_s_2436, 2, 3);
      V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 4))));
      V v_ss_2443 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalDefinition_lam2, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2439; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
      HeffT2 v_t_2445 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalDefinition_lam3, 1, 1, (V[]){v_target_2437}); V a_1 = v_ss_2443; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_ss_2443); r_; });
      V v_t_2449;
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          heff_drop(v_span_2438);
          V v_s2_2448 = v_field_2447;
          v_t_2449 = heff_get_n(v_s2_2448, 2, 3);
        } else {
          heff_drop(v_field_2447);
          v_t_2449 = v_span_2438;
        }
      }
      V v_t_2450 = heff_rec_n(3, shape_path__source__span, (V[]){heff_take_field(v_c_240, 1), heff_get_n(v_c_240, 3, 14), v_t_2449});
      v_x2_2451 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2450});
    } else {
      heff_drop_rec(v_c_240, 14);
      heff_drop(v_field_2435);
      v_x2_2451 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nothing: {
    return v_x2_2451;
  }
  case TAG_Just: {
    V v_x_2452 = heff_field(v_x1_2426, 0);
    V v_ru_24x1_2426_24Just = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
    heff_drop(v_x2_2451);
    return heff_tag_at_n(v_ru_24x1_2426_24Just, TAG_Just, 1, (V[]){v_x_2452});
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
V g_heff_2ebuild_2equery_2elocalDefinition_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalDefinition(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2elocalDefinition_lam0(V self, V *args) {
  V v_l_2410 = args[0];
  V v_off_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binder_2411 = heff_take_field(v_l_2410, 1);
  V v_uses_2412 = heff_get_n(v_l_2410, 2, 3);
  V v_sp_2413 = v_binder_2411;
  V v_start_2414 = heff_take_field(v_sp_2413, 0);
  V v_end_2415 = heff_get_n(v_sp_2413, 1, 2);
  if ((heff_intLe_c_lent(v_start_2414, v_off_249, 0) && heff_intLe_c_lent(v_off_249, v_end_2415, 0))) {
    heff_drop(v_off_249);
    heff_drop(v_uses_2412);
    heff_drop(v_start_2414);
    heff_drop(v_end_2415);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_start_2414);
    heff_drop(v_end_2415);
    return ({ V a_0 = v_off_249; V a_1 = v_uses_2412; V r_ = (g_list_2eany_24s464681941x898021545(a_0, a_1)); heff_drop(v_uses_2412); r_; });
  }
}
V g_heff_2ebuild_2equery_2elocalDefinition_lam1(V self, V *args) {
  V v_acc_2429 = args[0];
  V v_x_2430 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_2430));
  return (g_prelude_2e_2b_2b(v_t_2431, v_acc_2429));
}
V g_heff_2ebuild_2equery_2elocalDefinition_lam2(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_x_2441 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_2441));
  return (g_prelude_2e_2b_2b(v_t_2442, v_acc_2440));
}
V g_heff_2ebuild_2equery_2elocalDefinition_lam3(V self, V *args) {
  V v_s2_2444 = args[0];
  V v_target_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s2_2444, 0, 3), v_target_2437));
}

HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    HeffT2 v_t_244 = (g_list_2efind_24s1953031388x2120050076_24cpr(v_k_241, heff_rfield(v_c_242, 7)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_o_247 = v_field_246;
        V v_f_248 = heff_get_n(v_o_247, 0, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      } else {
        heff_drop(v_field_246);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  HeffT2 v_t_244 = ({ V a_0 = v_off_243; V b_1 = heff_get_n(v_ls_242, 1, 2); HeffT2 r_ = (g_list_2efind_24s764539875x1185200879_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_f_247 = v_field_246;
      V v_xs_248 = heff_dup(heff_rfield(v_c_241, 4));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      HeffT2 v_t_2414 = ({ V a_0 = v_f_247; V a_1 = v_t_2413; HeffT2 r_ = (g_list_2efind_24s1140544609x424148735_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_s_2417 = v_field_2416;
          V v_t_2418 = heff_get_n(v_s_2417, 0, 3);
          V v_t_2419 = heff_dup(heff_rfield(v_t_2418, 1));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nothing: {
            HeffT2 v_t_2420 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2418, 0)));
            {
              V v_field_2422 = v_t_2420.f[1];
              int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
              if ((v_tag_2421 == ((int64_t)0ULL))) {
                V v_x_2423 = v_field_2422;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2418, v_x_2423})}});
              } else {
                heff_drop_rec(v_t_2418, 3);
                heff_drop(v_field_2422);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Just: {
            V v_m_2424 = heff_field(v_t_2419, 0);
            heff_take_n(v_t_2419, 1ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2418, v_m_2424})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2419)}});
          }
        } else {
          heff_drop(v_field_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_2411));
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_2410));
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalFound_entry, 3, 0};

V g_heff_2ebuild_2equery_2elocalFound(V v_c_240, V v_ls_241, V v_off_242) {
top: ;
  HeffT2 v_t_249 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalFound_lam0, 1, 1, (V[]){v_off_242}); V b_1 = heff_get_n(v_ls_241, 0, 2); HeffT2 r_ = (g_list_2efind_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_l_2412 = v_field_2411;
      V v_binder_2413 = heff_take_field(v_l_2412, 1);
      V v_name_2414 = heff_get_n(v_l_2412, 0, 3);
      V v_t_2415 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_c_240, 1, 14), NTAG(TAG_Nothing), heff_tag_n(TAG_Just, 1, (V[]){v_binder_2413})});
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2415, v_name_2414})});
    } else {
      heff_drop_rec(v_c_240, 14);
      heff_drop(v_field_2411);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalFound(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_off_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binder_244 = heff_take_field(v_l_243, 1);
  V v_uses_245 = heff_get_n(v_l_243, 2, 3);
  V v_sp_246 = v_binder_244;
  V v_start_247 = heff_take_field(v_sp_246, 0);
  V v_end_248 = heff_get_n(v_sp_246, 1, 2);
  if ((heff_intLe_c_lent(v_start_247, v_off_242, 0) && heff_intLe_c_lent(v_off_242, v_end_248, 0))) {
    heff_drop(v_off_242);
    heff_drop(v_uses_245);
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    return ({ V a_0 = v_off_242; V a_1 = v_uses_245; V r_ = (g_list_2eany_24s464681941x898021545(a_0, a_1)); heff_drop(v_uses_245); r_; });
  }
}
Clo g_heff_2ebuild_2equery_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etargetIn_entry, 4, 0};

V g_heff_2ebuild_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(heff_dup(v_c_241), heff_dup(v_off_243)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_i_247 = v_field_246;
      V v_key_248 = heff_take_field(v_i_247, 2);
      V v_member_249 = heff_take_field(v_i_247, 3);
      V v_name_2410 = heff_get_n(v_i_247, 1, 5);
      switch (heff_tag_of(v_key_248)) {
      case TAG_Nothing: {
        heff_drop(v_member_249);
        heff_drop(v_name_2410);
        HeffT2 v_t_2411 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          HeffT2 v_t_2414 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            V v_x2_2417 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_field_2416);
              heff_drop(v_x2_2417);
              V v_x_2418 = v_field_2413;
              return heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
            } else {
              heff_drop(v_field_2413);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                heff_drop(v_x2_2417);
                V v_x_2419 = v_field_2416;
                return heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
              } else {
                heff_drop(v_field_2416);
                return v_x2_2417;
              }
            }
          }
        }
      }
      case TAG_Just: {
        V v_k_2420 = heff_field(v_key_248, 0);
        V v_ru_24key_248_24Just = heff_take_reuse_n(v_key_248, 1ULL, 1);
        heff_drop(v_c_241);
        heff_drop(v_ls_242);
        heff_drop(v_off_243);
        V v_t_2421;
        if ((heff_dup(v_member_249) == NTAG(TAG_True))) {
          heff_drop(v_member_249);
          v_t_2421 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2420, heff_tag_n(TAG_Just, 1, (V[]){v_name_2410}), NTAG(TAG_Nothing)});
        } else {
          heff_drop(v_member_249);
          heff_drop(v_name_2410);
          v_t_2421 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2420, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        }
        V v_t_2422 = heff_dup(heff_rfield(v_t_2421, 1));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          HeffT2 v_t_2423 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2421, 0)));
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2425;
              return heff_tag_at_n(v_ru_24key_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2421, v_x_2426})});
            } else {
              heff_drop_cell(v_ru_24key_248_24Just, 1);
              heff_drop_rec(v_t_2421, 3);
              heff_drop(v_field_2425);
              return NTAG(TAG_Nothing);
            }
          }
        }
        case TAG_Just: {
          V v_m_2427 = heff_field(v_t_2422, 0);
          heff_take_n(v_t_2422, 1ULL, 1);
          return heff_tag_at_n(v_ru_24key_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2421, v_m_2427})});
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      default: return heff_nomatch(v_key_248);
      }
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_2428 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        HeffT2 v_t_2431 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
        {
          V v_field_2433 = v_t_2431.f[1];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          V v_x2_2434 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
          if ((v_tag_2429 == ((int64_t)0ULL))) {
            heff_drop(v_field_2433);
            heff_drop(v_x2_2434);
            V v_x_2435 = v_field_2430;
            return heff_tag_n(TAG_Just, 1, (V[]){v_x_2435});
          } else {
            heff_drop(v_field_2430);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              heff_drop(v_x2_2434);
              V v_x_2436 = v_field_2433;
              return heff_tag_n(TAG_Just, 1, (V[]){v_x_2436});
            } else {
              heff_drop(v_field_2433);
              return v_x2_2434;
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2etargetIn(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elineStartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elineStartOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2elineStartOf(V v_src_240, V v_p_241) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_p_241, 1) && !(heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)))) == ((int64_t)10ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_p_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_p_241 = t_1;
    goto top;
  } else {
    return v_p_241;
  }
}
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elineStartOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2einStringGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einStringGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2einStringGo(V v_src_240, V v_i_241, V v_p_242, V v_inside_243) {
top: ;
  if (heff_intLe_c_lent(v_p_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    return v_inside_243;
  } else {
    if (((heff_dup(v_inside_243) == NTAG(TAG_True)) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)92ULL)))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(2LL));
      V t_2 = v_p_242;
      V t_3 = v_inside_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_p_242 = t_2;
      v_inside_243 = t_3;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)34ULL))) {
        V v_t_244 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
        heff_drop(v_inside_243);
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_t_244;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2einStringGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eisLabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisLabelAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2eisLabelAt(V v_src_240, V v_p_241, V v_n_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242))));
  V v_ret_24bool = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_t_243, 0)) == ((int64_t)61ULL)) && ({ V v_t_244 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242)))); int c_ = ({ V v_x_245 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_t_244), MK_INT(1LL))); int c_ = ((heff_peek_word(v_x_245) == ((int64_t)61ULL)) ? 0 : ({ V v_x_246 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_246, 1) && ({ V v_t_247 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_249 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_247), MK_INT(1LL))); int c_ = ((heff_peek_word(v_t_249) == ((int64_t)123ULL)) || ({ V v_t_248 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_2410 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_248), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2410) == ((int64_t)44ULL)); heff_drop(v_t_2410); c_; }); heff_drop(v_t_248); c_; })); heff_drop(v_t_249); c_; }); heff_drop(v_t_247); c_; })); heff_drop(v_x_246); c_; })); heff_drop(v_x_245); c_; }); heff_drop(v_t_244); c_; })));
  heff_drop(v_p_241);
  heff_drop(v_n_242);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eisLabelAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str0, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str1, 8, "-- | >>>");
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexpectedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2eexpectedIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_top_243 = heff_take_field(v_c_242, 5);
  V v_source_244 = heff_get_n(v_c_242, 3, 14);
  V v_xs_245 = heff_get_n(v_top_243, 4, 10);
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam0, 2, 3, (V[]){v_source_244, v_t_240, heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eexpectedIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_source_244 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = v_t_240;
  V v_src_2427 = v_source_244;
  V v_n_2428 = heff_strLength(v_name_241);
  V v_p_2429 = v_p_2425;
  V v_t_2430 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_2427, heff_dup(v_p_2429)));
  V v_x1_2431 = (g_heff_2ebuild_2equery_2einStringGo(v_src_2427, v_t_2430, heff_dup(v_p_2429), NTAG(TAG_False)));
  if (!(heff_dup(v_x1_2431) == NTAG(TAG_True))) {
    heff_drop(v_x1_2431);
    V v_t_2432 = heff_get_n(v_t_2426, 1, 3);
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      V v_x1_2433 = ({ V a_0 = v_src_2427; V a_1 = v_p_2429; V a_2 = v_n_2428; V r_ = (g_heff_2ebuild_2equery_2eisLabelAt(a_0, a_1, a_2)); heff_drop(v_src_2427); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
      heff_drop(v_x1_2433);
      return v_ret_24bool;
    }
    case TAG_Just: {
      V v_m_2434 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_m_2434, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_m_2434, MK_INT(0LL), 2)) <= ((int64_t)90ULL)) : 1)) {
        heff_drop(v_m_2434);
        V v_t_2435 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_2427, heff_dup(v_p_2429), v_n_2428));
        V v_ret_24bool = heff_bool(((heff_dup(v_t_2435) == NTAG(TAG_True)) || (heff_intLt_c_lent(MK_INT(0LL), v_p_2429, 1) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_2427), heff_intSub(heff_dup(v_p_2429), MK_INT(1LL)))) == ((int64_t)46ULL)))));
        heff_drop(v_src_2427);
        heff_drop(v_p_2429);
        heff_drop(v_t_2435);
        return v_ret_24bool;
      } else {
        heff_drop(v_m_2434);
        V v_x1_2436 = ({ V a_0 = v_src_2427; V a_1 = v_p_2429; V a_2 = v_n_2428; V r_ = (g_heff_2ebuild_2equery_2eisLabelAt(a_0, a_1, a_2)); heff_drop(v_src_2427); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2436) == NTAG(TAG_True)));
        heff_drop(v_x1_2436);
        return v_ret_24bool;
      }
    }
    default: return heff_nomatch(v_t_2432);
    }
  } else {
    heff_drop_rec(v_t_2426, 3);
    heff_drop(v_src_2427);
    heff_drop(v_n_2428);
    heff_drop(v_p_2429);
    heff_drop(v_x1_2431);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_source_244 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_249 = heff_dup(v_source_244);
  V v_sp_2410 = heff_dup(heff_rfield(v_x_248, 0));
  V v_start_2411 = heff_take_field(v_sp_2410, 0);
  V v_end_2412 = heff_get_n(v_sp_2410, 1, 2);
  V v_start_2413 = v_start_2411;
  V v_t_2414 = heff_strSlice(heff_dup(v_src_249), heff_dup(v_start_2413), heff_intAdd(v_start_2413, MK_INT(8LL)));
  V v_t_2415 = heff_bool(heff_strEq_c_lent(v_t_2414, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str0), 2));
  heff_drop(v_t_2414);
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_src_249; V a_2 = v_end_2412; V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(a_0, a_1, a_2)); heff_drop(v_end_2412); r_; });
  V v_src_2417 = heff_dup(v_source_244);
  V v_sp_2418 = heff_get_n(v_x_248, 0, 2);
  V v_start_2419 = heff_take_field(v_sp_2418, 0);
  V v_end_2420 = heff_get_n(v_sp_2418, 1, 2);
  V v_start_2421 = v_start_2419;
  V v_t_2422 = heff_strSlice(heff_dup(v_src_2417), heff_dup(v_start_2421), heff_intAdd(v_start_2421, MK_INT(8LL)));
  V v_t_2423 = heff_bool(heff_strEq_c_lent(v_t_2422, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str1), 2));
  heff_drop(v_t_2422);
  V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_src_2417; V a_2 = v_end_2420; V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(a_0, a_1, a_2)); heff_drop(v_end_2420); r_; });
  V v_t_2437 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam1, 1, 3, (V[]){v_t_240, heff_dup(v_source_244), heff_dup(v_name_241)}); V a_1 = v_name_241; V a_2 = v_source_244; V a_3 = heff_get_n(v_t_2416, 1, 3); V a_4 = heff_get_n(v_t_2424, 2, 3); V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsIn(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_name_241); heff_drop(v_source_244); r_; });
  return (g_prelude_2e_2b_2b(v_t_2437, v_acc_247));
}
V g_heff_2ebuild_2equery_2einFile_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam2(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam3(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam4(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam5(V self, V *args);
V g_heff_2ebuild_2equery_2einFile_lam6(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFile_entry, 3, 0};

V g_heff_2ebuild_2equery_2einFile(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_t_243 = heff_dup(v_t_240);
  V v_name_244 = v_name_241;
  V v_c_245 = heff_dup(v_c_242);
  V v_xs_246 = heff_dup(heff_rfield(v_c_242, 4));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam0, 2, 1, (V[]){v_c_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_ss_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam1, 1, 1, (V[]){v_t_240}), v_t_2411));
  V v_t_2414 = heff_dup(v_t_243);
  V v_name_2415 = heff_dup(v_name_244);
  V v_c_2416 = heff_dup(v_c_245);
  V v_ss_2417 = heff_dup(v_ss_2413);
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_c_245, 5)), 7, 10);
  V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam2, 1, 2, (V[]){heff_dup(v_t_243), heff_dup(v_name_244)}), v_t_2418));
  V v_t_2441 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2440));
  V v_t_2442 = (g_list_2emap_24s388004800x1261967008(heff_dup(v_ss_2413)));
  V v_t_2443 = v_t_243;
  V v_member_2444 = heff_take_field(v_t_2443, 1);
  V v_local_2445 = heff_take_field(v_t_2443, 2);
  V v_key_2446 = heff_get_n(v_t_2443, 0, 3);
  V v_name_2447 = v_name_244;
  V v_c_2448 = heff_dup(v_c_245);
  V v_exposes_2449 = heff_take_field(v_c_2448, 13);
  V v_source_2450 = heff_take_field(v_c_2448, 3);
  V v_own_2451 = heff_get_n(v_c_2448, 7, 14);
  V v_t_2463;
  switch (heff_tag_of(v_member_2444)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_local_2445)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_exposes_2449)) {
      case TAG_Nothing: {
        heff_drop(v_key_2446);
        heff_drop(v_name_2447);
        heff_drop(v_source_2450);
        heff_drop(v_own_2451);
        v_t_2463 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_es_2452 = heff_field(v_exposes_2449, 0);
        heff_take_n(v_exposes_2449, 1ULL, 1);
        V v_t_2458 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam3, 1, 3, (V[]){heff_dup(v_name_2447), v_own_2451, v_key_2446}), v_es_2452));
        v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam4, 1, 2, (V[]){v_source_2450, v_name_2447}), v_t_2458));
        break;
      }
      default: heff_nomatch(v_exposes_2449);
      }
      break;
    }
    case TAG_Just: {
      heff_take_n(v_local_2445, 0ULL, 1);
      heff_drop(v_key_2446);
      heff_drop(v_name_2447);
      heff_drop(v_exposes_2449);
      heff_drop(v_source_2450);
      heff_drop(v_own_2451);
      v_t_2463 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_local_2445);
    }
    break;
  }
  case TAG_Just: {
    heff_take_n(v_member_2444, 0ULL, 1);
    heff_drop(v_local_2445);
    heff_drop(v_key_2446);
    heff_drop(v_name_2447);
    heff_drop(v_exposes_2449);
    heff_drop(v_source_2450);
    heff_drop(v_own_2451);
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_member_2444);
  }
  V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2463));
  V v_t_2472;
  switch (heff_tag_of(v_ss_2413)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_245, 14);
    v_t_2472 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2467 = ({ V a_0 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V b_1 = heff_get_n(v_c_245, 4, 14); V r_ = (g_list_2efoldl_24s44351024x1408738471(a_0, b_1)); heff_drop(b_1); r_; });
    HeffT2 v_t_2468 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_2467));
    {
      V v_field_2470 = v_t_2468.f[1];
      heff_drop(v_t_2468.f[0]);
      v_t_2472 = (g_list_2emap_24f922554743x1845028609(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam5, 1, 1, (V[]){v_ss_2413}), v_field_2470));
    }
    break;
  }
  default: heff_nomatch(v_ss_2413);
  }
  V v_t_2473 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2472));
  V v_found_2474 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2473));
  V v_defs_2475 = (g_list_2emap_24s388004800x1261967008(v_ss_2417));
  V v_t_2478;
  switch (heff_tag_of(v_found_2474)) {
  case TAG_Nil: {
    heff_drop(v_t_2414);
    heff_drop(v_name_2415);
    v_t_2478 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_2478 = (g_heff_2ebuild_2equery_2emoreIn(v_t_2414, v_name_2415, heff_dup(v_c_2416)));
    break;
  }
  default: heff_nomatch(v_found_2474);
  }
  V v_spans_2479 = (g_prelude_2e_2b_2b(v_found_2474, v_t_2478));
  V v_t_2480 = (g_list_2esortOn_24s227026999x1111027886(v_spans_2479));
  V v_t_2481 = (g_heff_2ebuild_2equery_2enubByStart(v_t_2480));
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFile_lam6, 1, 2, (V[]){v_defs_2475, v_c_2416}), v_t_2481));
}
V g_heff_2ebuild_2equery_2einFile_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2einFile(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2einFile_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2equery_2edeclSites(v_c_242, v_x_249));
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_248));
}
V g_heff_2ebuild_2equery_2einFile_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2412, 0, 3), v_t_240));
}
V g_heff_2ebuild_2equery_2einFile_lam2(V self, V *args) {
  V v_i_2419 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_name_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = v_t_243;
  V v_key_2421 = heff_take_field(v_t_2420, 0);
  V v_member_2422 = heff_get_n(v_t_2420, 1, 3);
  V v_name_2423 = v_name_244;
  V v_i_2424 = v_i_2419;
  V v_key_2425 = heff_take_field(v_i_2424, 2);
  V v_member_2426 = heff_take_field(v_i_2424, 3);
  V v_name_2427 = heff_take_field(v_i_2424, 1);
  V v_span_2428 = heff_get_n(v_i_2424, 0, 5);
  switch (heff_tag_of(v_key_2425)) {
  case TAG_Nothing: {
    heff_drop(v_key_2421);
    heff_drop(v_member_2422);
    heff_drop(v_name_2423);
    heff_drop(v_member_2426);
    heff_drop(v_name_2427);
    heff_drop_rec(v_span_2428, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_a_2429 = heff_field(v_key_2425, 0);
    V v_ru_24key_2425_24Just = heff_take_reuse_n(v_key_2425, 1ULL, 1);
    if (heff_strEq_c(v_a_2429, v_key_2421)) {
      if ((heff_dup(v_member_2426) == NTAG(TAG_True))) {
        heff_drop(v_member_2426);
        switch (heff_tag_of(v_member_2422)) {
        case TAG_Nothing: {
          heff_drop(v_name_2423);
          heff_drop(v_name_2427);
          heff_drop_rec(v_span_2428, 2);
          heff_drop_cell(v_ru_24key_2425_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_a_2430 = heff_field(v_member_2422, 0);
          heff_take_n(v_member_2422, 1ULL, 1);
          if (heff_strEq_c(v_a_2430, v_name_2427)) {
            V v_x_2431 = heff_take_field(v_span_2428, 0);
            V v_y_2432 = heff_intSub(heff_dup(heff_rfield(v_span_2428, 1)), heff_strLength(v_name_2423));
            V v_t_2433;
            if (heff_intLe_c_lent(v_x_2431, v_y_2432, 0)) {
              heff_drop(v_x_2431);
              v_t_2433 = v_y_2432;
            } else {
              heff_drop(v_y_2432);
              v_t_2433 = v_x_2431;
            }
            V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_span_2428, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_at_n(v_ru_24key_2425_24Just, TAG_Just, 1, (V[]){v_t_2434});
          } else {
            heff_drop(v_name_2423);
            heff_drop_rec(v_span_2428, 2);
            heff_drop_cell(v_ru_24key_2425_24Just, 1);
            return NTAG(TAG_Nothing);
          }
        }
        default: return heff_nomatch(v_member_2422);
        }
      } else {
        heff_drop(v_member_2426);
        heff_drop(v_name_2427);
        switch (heff_tag_of(v_member_2422)) {
        case TAG_Nothing: {
          V v_x_2435 = heff_take_field(v_span_2428, 0);
          V v_y_2436 = heff_intSub(heff_dup(heff_rfield(v_span_2428, 1)), heff_strLength(v_name_2423));
          V v_t_2437;
          if (heff_intLe_c_lent(v_x_2435, v_y_2436, 0)) {
            heff_drop(v_x_2435);
            v_t_2437 = v_y_2436;
          } else {
            heff_drop(v_y_2436);
            v_t_2437 = v_x_2435;
          }
          V v_t_2438 = ({ V rv_0 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_span_2428, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_at_n(v_ru_24key_2425_24Just, TAG_Just, 1, (V[]){v_t_2438});
        }
        case TAG_Just: {
          heff_take_n(v_member_2422, 0ULL, 1);
          heff_drop(v_name_2423);
          heff_drop_rec(v_span_2428, 2);
          heff_drop_cell(v_ru_24key_2425_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_member_2422);
        }
      }
    } else {
      heff_drop(v_member_2422);
      heff_drop(v_name_2423);
      heff_drop(v_member_2426);
      heff_drop(v_name_2427);
      heff_drop_rec(v_span_2428, 2);
      heff_drop_cell(v_ru_24key_2425_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_key_2425);
  }
}
V g_heff_2ebuild_2equery_2einFile_lam3(V self, V *args) {
  V v_e_2453 = args[0];
  V v_name_2447 = heff_env(self)[0];
  V v_own_2451 = heff_env(self)[1];
  V v_key_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_e_2453, 0, 3), heff_dup(v_name_2447))) {
    HeffT2 v_t_2454 = ({ V a_0 = v_name_2447; V a_1 = v_own_2451; HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, a_1)); heff_drop(v_name_2447); heff_drop(v_own_2451); r_; });
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_o_2457 = v_field_2456;
        V v_ret_24bool = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_o_2457, 1)), heff_dup(v_key_2446)));
        heff_drop(v_key_2446);
        heff_drop_rec(v_o_2457, 2);
        return v_ret_24bool;
      } else {
        heff_drop(v_key_2446);
        heff_drop(v_field_2456);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop(v_name_2447);
    heff_drop(v_own_2451);
    heff_drop(v_key_2446);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2einFile_lam4(V self, V *args) {
  V v_e_2459 = args[0];
  V v_source_2450 = heff_env(self)[0];
  V v_name_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_sp_2460 = heff_get_n(v_e_2459, 2, 3);
  return ({ V a_0 = v_source_2450; V a_1 = v_name_2447; V a_2 = heff_dup(v_sp_2460); V a_3 = heff_get_n(v_sp_2460, 0, 2); V r_ = (g_heff_2ebuild_2equery_2enameInGo(a_0, a_1, a_2, a_3)); heff_drop(v_source_2450); heff_drop(v_name_2447); r_; });
}
V g_heff_2ebuild_2equery_2einFile_lam5(V self, V *args) {
  V v_f_2471 = args[0];
  V v_ss_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_f_2471; V a_1 = v_ss_2413; V r_ = (g_list_2eany_24s1011930416x23610018(a_0, a_1)); heff_drop_tag(v_ss_2413, 2); r_; });
}
V g_heff_2ebuild_2equery_2einFile_lam6(V self, V *args) {
  V v_sp_2482 = args[0];
  V v_defs_2475 = heff_env(self)[0];
  V v_c_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_defines_2483 = ({ V a_0 = heff_dup(v_sp_2482); V a_1 = v_defs_2475; V r_ = (g_list_2eany_24s1690524253x1144193326(a_0, a_1)); heff_drop(v_defs_2475); r_; });
  return heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_c_2416, 1)), heff_get_n(v_c_2416, 3, 14), v_sp_2482, v_defines_2483});
}
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eoccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eoccurrences_entry, 3, 0};

V g_heff_2ebuild_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24f297647854x479783049(NTAG(TAG_Nil), v_program_240));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam0, 2, 2, (V[]){v_t_241, v_name_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  }
  case TAG_Just: {
    V v_b_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_name_242);
    HeffT2 v_t_249 = ({ V a_0 = v_t_241; V a_1 = v_program_240; HeffT2 r_ = (g_list_2efind_24s2106830784x1074299306_24cpr(a_0, a_1)); heff_drop(v_program_240); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_c_2412 = v_field_2411;
        V v_t_2413 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2412, 4)));
        V v_t_2414 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2413));
        HeffT2 v_t_2415 = ({ V a_0 = heff_dup(v_b_248); V b_1 = heff_get_n(v_t_2414, 0, 2); HeffT2 r_ = (g_list_2efind_24s343666469x451168509_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_l_2418 = v_field_2417;
            V v_binder_2419 = heff_take_field(v_l_2418, 1);
            V v_uses_2420 = heff_get_n(v_l_2418, 2, 3);
            V v_t_2421 = (g_list_2esortOn_24s227026999x1111027886(heff_tag_n(TAG_Cons, 2, (V[]){v_binder_2419, v_uses_2420})));
            HEFF_LAST return g_list_2emap_24s1392650298x1192381411(v_b_248, v_c_2412, v_t_2421);
          } else {
            heff_drop(v_b_248);
            heff_drop_rec(v_c_2412, 14);
            heff_drop(v_field_2417);
            return NTAG(TAG_Nil);
          }
        }
      } else {
        heff_drop(v_b_248);
        heff_drop(v_field_2411);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eoccurrences(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2ebuild_2equery_2einFile(v_t_241, v_name_242, v_x_246));
  return (g_prelude_2e_2b_2b(v_t_247, v_acc_245));
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry, 2, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_d_242 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if (((heff_peek_word(v_d_242) == ((int64_t)47ULL)) ? 0 : ((heff_peek_word(v_d_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_d_242) == ((int64_t)39ULL)) || ((heff_peek_word(v_d_242) == ((int64_t)47ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_d_242)) && (heff_peek_word(v_d_242) <= ((int64_t)57ULL)))))))))) {
      heff_drop(v_d_242);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_d_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry, 23, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V v_box_24lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_box_24lit_248, V v_box_24lit_249, V v_box_24lit_2410, V v_box_24lit_2411, V v_box_24lit_2412, V v_box_24lit_2413, V v_box_24lit_2414, V v_box_24lit_2415, V v_box_24lit_2416, V v_box_24lit_2417, V v_box_24lit_2418, V v_box_24lit_2419, V v_box_24lit_2420, V v_s_2421, V v_box_24i_2422) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_lit_245 = heff_unbox_word(v_box_24lit_245);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_248 = heff_unbox_word(v_box_24lit_248);
  int64_t v_lit_249 = heff_unbox_word(v_box_24lit_249);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
  int64_t v_lit_2411 = heff_unbox_word(v_box_24lit_2411);
  int64_t v_lit_2412 = heff_unbox_word(v_box_24lit_2412);
  int64_t v_lit_2413 = heff_unbox_word(v_box_24lit_2413);
  int64_t v_lit_2414 = heff_unbox_word(v_box_24lit_2414);
  int64_t v_lit_2415 = heff_unbox_word(v_box_24lit_2415);
  int64_t v_lit_2416 = heff_unbox_word(v_box_24lit_2416);
  int64_t v_lit_2417 = heff_unbox_word(v_box_24lit_2417);
  int64_t v_lit_2418 = heff_unbox_word(v_box_24lit_2418);
  int64_t v_lit_2419 = heff_unbox_word(v_box_24lit_2419);
  int64_t v_lit_2420 = heff_unbox_word(v_box_24lit_2420);
  int64_t v_i_2422 = heff_unbox_word(v_box_24i_2422);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_2421, 0)) <= v_i_2422)) {
    return NTAG(TAG_True);
  } else {
    V v_a_2423 = heff_strByteAt_lent(v_s_2421, heff_box_word(v_i_2422), 2);
    if ((((heff_peek_word(v_a_2423) == v_lit_240) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_241) || ((heff_peek_word(v_a_2423) == v_lit_242) || ((heff_peek_word(v_a_2423) == v_lit_243) || (((v_lit_244 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_245)) || (((v_lit_246 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_247)) || ((v_lit_248 <= heff_peek_word(v_a_2423)) && (heff_peek_word(v_a_2423) <= v_lit_249)))))))) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2410) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2411) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2412) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2413) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2414) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2415) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2416) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2417) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2418) ? 0 : ((heff_peek_word(v_a_2423) == v_lit_2419) ? 0 : !(heff_peek_word(v_a_2423) == v_lit_2420))))))))))))) {
      heff_drop(v_a_2423);
      int64_t t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      int64_t t_8 = v_lit_248;
      int64_t t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      int64_t t_11 = v_lit_2411;
      int64_t t_12 = v_lit_2412;
      int64_t t_13 = v_lit_2413;
      int64_t t_14 = v_lit_2414;
      int64_t t_15 = v_lit_2415;
      int64_t t_16 = v_lit_2416;
      int64_t t_17 = v_lit_2417;
      int64_t t_18 = v_lit_2418;
      int64_t t_19 = v_lit_2419;
      int64_t t_20 = v_lit_2420;
      V t_21 = v_s_2421;
      int64_t t_22 = (v_i_2422 + ((int64_t)1ULL));
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_lit_2412 = t_12;
      v_lit_2413 = t_13;
      v_lit_2414 = t_14;
      v_lit_2415 = t_15;
      v_lit_2416 = t_16;
      v_lit_2417 = t_17;
      v_lit_2418 = t_18;
      v_lit_2419 = t_19;
      v_lit_2420 = t_20;
      v_s_2421 = t_21;
      v_i_2422 = t_22;
      goto top;
    } else {
      heff_drop(v_a_2423);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a) {
  (void)self;
  V a21 = a[21]; V r = g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15], a[16], a[17], a[18], a[19], a[20], a21, a[22]); heff_drop(a21); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2, 43, "` is a primitive: its name is the runtime's");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5, 4, "` is");

HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V v_t_240, V v_old_241, V v_new_242) {
top: ;
  V v_member_243 = heff_take_field(v_t_240, 1);
  V v_local_244 = heff_take_field(v_t_240, 2);
  V v_key_245 = heff_get_n(v_t_240, 0, 3);
  V v_t_247;
  switch (heff_tag_of(v_member_243)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_member_243, 0ULL, 1);
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_member_243);
  }
  V v_t_2415;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2420;
    switch (heff_tag_of(v_local_244)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_local_244, 0ULL, 1);
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_local_244);
    }
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      v_t_2415 = heff_bool(!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0), v_key_245, MK_INT(0LL), 5)));
      heff_drop(v_key_245);
      break;
    }
    case TAG_False: {
      heff_drop(v_key_245);
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
  } else {
    heff_drop(v_local_244);
    heff_drop(v_key_245);
    heff_drop(v_t_247);
    v_t_2415 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_new_242);
    V v_f_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1), v_old_241), ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
  }
  case TAG_False: {
    V v_x_2410 = (g_heff_2ebuild_2equery_2enameClass(v_old_241));
    V v_y_2411 = (g_heff_2ebuild_2equery_2enameClass(v_new_242));
    if (!heff_intEq_c_lent(v_x_2410, v_y_2411, 0)) {
      heff_drop(v_x_2410);
      heff_drop(v_y_2411);
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3), v_new_242), ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4));
      V v_f_2413 = heff_strAppend(heff_strAppend(v_t_2412, v_old_241), ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
    } else {
      heff_drop(v_old_241);
      heff_drop(v_new_242);
      heff_drop(v_x_2410);
      heff_drop(v_y_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_2415)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecommentAbove_str0, 2, "--");
Clo g_heff_2ebuild_2equery_2ecommentAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecommentAbove_entry, 3, 0};

V g_heff_2ebuild_2equery_2ecommentAbove(V v_src_240, V v_start_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_start_241, MK_INT(0LL), 2)) {
    heff_drop(v_start_241);
    return v_acc_242;
  } else {
    V v_t_243 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
    V v_s_244 = heff_strSlice(heff_dup(v_src_240), v_t_243, heff_intSub(heff_dup(v_start_241), MK_INT(1LL)));
    V v_t_245 = (g_prelude_2eskipSpaces(v_s_244, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
    V v_t_247 = (g_prelude_2eskipSpaces(v_s_244, heff_box_word(v_t_246), MK_INT(-1LL)));
    V v_s_248 = heff_strSlice(v_s_244, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_248, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2equery_2ecommentAbove_str0))) {
      V v_t_249 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_t_2410 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_s_2411 = heff_strSlice(heff_dup(v_src_240), v_t_2410, heff_intSub(v_start_241, MK_INT(1LL)));
      V v_t_2412 = (g_prelude_2eskipSpaces(v_s_2411, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_s_2411, 0)) - ((int64_t)1ULL));
      V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2411, heff_box_word(v_t_2413), MK_INT(-1LL)));
      V v_t_2415 = heff_strSlice(v_s_2411, v_t_2412, heff_intAdd(v_t_2414, MK_INT(1LL)));
      V t_0 = v_src_240;
      V t_1 = v_t_249;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_acc_242});
      v_src_240 = t_0;
      v_start_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_start_241);
      return v_acc_242;
    }
  }
}
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2ecommentAbove(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str0, 3, ">>>");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str1, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str3, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str4, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str5, 3, "```");
Clo g_heff_2ebuild_2equery_2edocMdStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMdStep_entry, 3, 0};

V g_heff_2ebuild_2equery_2edocMdStep(V v_lang_240, V v_m_241, V v_l_242) {
top: ;
  V v_code_243 = heff_take_field(v_m_241, 1);
  V v_out_244 = heff_take_field(v_m_241, 0);
  V v_expecting_245 = heff_get_n(v_m_241, 2, 3);
  if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2equery_2edocMdStep_str0))) {
    heff_drop(v_expecting_245);
    V v_t_246;
    if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
      heff_drop(v_lang_240);
      heff_drop(v_code_243);
      v_t_246 = v_out_244;
    } else {
      heff_drop(v_code_243);
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2equery_2edocMdStep_str1), v_lang_240), v_out_244});
    }
    return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_246}), NTAG(TAG_True), NTAG(TAG_True)});
  } else {
    heff_drop(v_lang_240);
    if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
      if ((heff_dup(v_expecting_245) == NTAG(TAG_True))) {
        heff_drop(v_expecting_245);
        V v_t_247 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
        V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_248), MK_INT(-1LL)));
        V v_t_2410 = heff_strSlice(heff_dup(v_l_242), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
        V v_x1_2411 = heff_bool(heff_strEq_c_lent(v_t_2410, ((V)&g_heff_2ebuild_2equery_2edocMdStep_str2), 2));
        heff_drop(v_t_2410);
        if (!(heff_dup(v_x1_2411) == NTAG(TAG_True))) {
          heff_drop(v_code_243);
          heff_drop(v_x1_2411);
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_out_244}), NTAG(TAG_True), NTAG(TAG_True)});
        } else {
          heff_drop(v_x1_2411);
          V v_t_2412;
          if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
            heff_drop(v_code_243);
            v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str3), v_out_244});
          } else {
            heff_drop(v_code_243);
            v_t_2412 = v_out_244;
          }
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2412}), NTAG(TAG_False), NTAG(TAG_False)});
        }
      } else {
        heff_drop(v_expecting_245);
        V v_t_2413;
        if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
          heff_drop(v_code_243);
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str4), v_out_244});
        } else {
          heff_drop(v_code_243);
          v_t_2413 = v_out_244;
        }
        return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2413}), NTAG(TAG_False), NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_expecting_245);
      V v_t_2414;
      if ((heff_dup(v_code_243) == NTAG(TAG_True))) {
        heff_drop(v_code_243);
        v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str5), v_out_244});
      } else {
        heff_drop(v_code_243);
        v_t_2414 = v_out_244;
      }
      return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2414}), NTAG(TAG_False), NTAG(TAG_False)});
    }
  }
}
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocMdStep(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ekindOf_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2ekindOf_str1, 7, "theory ");
Clo g_heff_2ebuild_2equery_2ekindOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ekindOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2ekindOf(V v_x_240, V v_text_241) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_text_241, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2ekindOf_str0))) {
    return MK_INT(10LL);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_text_241, MK_INT(0LL), MK_INT(7LL), 6), ((V)&g_heff_2ebuild_2equery_2ekindOf_str1))) {
      return MK_INT(11LL);
    } else {
      V v_c_242 = heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2);
      if (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_242) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) ? !(heff_peek_word(v_c_242) <= ((int64_t)57ULL)) : 1))))))) {
        heff_drop(v_c_242);
        return MK_INT(25LL);
      } else {
        heff_drop(v_c_242);
        return MK_INT(12LL);
      }
    }
  }
}
V g_heff_2ebuild_2equery_2ekindOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ekindOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolsGo_str0, 5, "data ");
Clo g_heff_2ebuild_2equery_2esymbolsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_244);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        heff_take_n(v_x41_246, 2ULL, 2);
        V v_c_2410 = heff_dup(v_c_240);
        V v_o_2411 = v_o_244;
        V v_sp_2412 = heff_dup(v_sp_249);
        V v_own_2413 = (g_list_2ekeepIf_24s257286374x378693326(v_sp_249, heff_dup(v_ss_241)));
        V v_t_2414 = heff_strSlice(heff_dup(heff_rfield(v_c_2410, 3)), heff_dup(heff_rfield(v_sp_2412, 0)), heff_dup(heff_rfield(v_sp_2412, 1)));
        V v_t_2415 = ({ V a_0 = heff_rfield(v_o_2411, 0); V a_1 = v_t_2414; V r_ = (g_heff_2ebuild_2equery_2ekindOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
        HeffT2 v_t_2416 = (g_list_2efind_24s1702704581x1717241719_24cpr(v_own_2413));
        V v_t_2420;
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_s_2419 = v_field_2418;
            v_t_2420 = heff_get_n(v_s_2419, 2, 3);
          } else {
            heff_drop(v_field_2418);
            v_t_2420 = (g_heff_2ebuild_2equery_2enameInGo(heff_rfield(v_c_2410, 3), heff_rfield(v_o_2411, 0), heff_dup(v_sp_2412), heff_dup(heff_rfield(v_sp_2412, 0))));
          }
        }
        V v_t_2421 = ({ V a_0 = heff_dup(v_c_2410); V a_1 = heff_dup(v_sp_2412); V a_2 = MK_INT(5LL); V b_3 = ((V)&g_heff_2ebuild_2equery_2esymbolsGo_str0); V a_4 = MK_INT(22LL); V a_5 = MK_INT(8LL); V a_6 = v_own_2413; V r_ = (g_list_2emap_24f530523215x314966509(a_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_3); r_; });
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_2410, 4, 14)));
        V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2422); r_; });
        V v_t_2424 = (g_list_2ekeepIf_24s1950790755x1251737354(heff_dup(v_sp_2412), v_t_2423));
        V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_243_24Cons, v_t_2421, v_t_2424));
        V v_t_2426 = heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_get_n(v_o_2411, 0, 2), v_t_2415, v_sp_2412, v_t_2420, v_t_2425});
        V v_cell_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
        V v_u_2428 = (g_heff_2ebuild_2equery_2esymbolsGo_24dps(v_c_240, v_ss_241, v_os_245, v_sps_247, heff_dup(v_cell_2427)));
        heff_drop(v_u_2428);
        return v_cell_2427;
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2esymbols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbols_entry, 1, 0};

V g_heff_2ebuild_2equery_2esymbols(V v_c_240) {
top: ;
  V v_xs_241 = heff_dup(heff_rfield(v_c_240, 4));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_246 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 10);
  V v_t_248 = (g_heff_2ebuild_2equery_2esymbolsGo(heff_dup(v_c_240), v_t_246, heff_dup(heff_rfield(v_c_240, 7)), v_t_247));
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 10);
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam1, 1, 1, (V[]){v_c_240}), v_t_249));
  V v_x2_2417 = (g_prelude_2e_2b_2b(v_t_248, v_t_2416));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24Cons = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_xs_2419)) {
    case TAG_Nil: {
      V v_t_2420 = heff_tag_at_n(v_ru_24x2_2417_24Cons, TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_2421 = heff_field(v_xs_2419, 0);
      V v_ys_2422 = heff_field(v_xs_2419, 1);
      V v_ru_24xs_2419_24Cons = heff_take_reuse_n(v_xs_2419, 3ULL, 2);
      V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_x_2418, 2)), 0, 2);
      V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_y_2421, 2)), 0, 2);
      if (heff_intLe_c(v_t_2423, v_t_2424)) {
        V v_t_2425 = heff_tag_at_n(v_ru_24x2_2417_24Cons, TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
        v_t_2427 = (g_list_2eascending_24s390745979x1196509894(heff_dup(v_y_2421), heff_tag_at_n(v_ru_24xs_2419_24Cons, TAG_Cons, 2, (V[]){v_y_2421, v_t_2425}), v_ys_2422));
      } else {
        V v_t_2426 = heff_tag_at_n(v_ru_24x2_2417_24Cons, TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
        v_t_2427 = (g_list_2edescending_24s1679501129x89119467(heff_dup(v_y_2421), heff_tag_at_n(v_ru_24xs_2419_24Cons, TAG_Cons, 2, (V[]){v_y_2421, v_t_2426}), v_ys_2422));
      }
      break;
    }
    default: heff_nomatch(v_xs_2419);
    }
    return (g_list_2emergeRuns_24s1094647646x865851942(NTAG(TAG_Nil), v_t_2427));
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbols(a[0]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_244));
  return (g_prelude_2e_2b_2b(v_t_245, v_acc_243));
}
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_sp_2412 = heff_field(v_p_2410, 1);
    heff_take_n(v_p_2410, 3ULL, 2);
    V v_t_2413 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_2412, 0)), heff_dup(heff_rfield(v_sp_2412, 1)));
    V v_t_2414 = ({ V a_0 = v_x_2411; V a_1 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2ekindOf(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = v_x_2411; V a_2 = heff_dup(v_sp_2412); V a_3 = heff_dup(heff_rfield(v_sp_2412, 0)); V r_ = (g_heff_2ebuild_2equery_2enameInGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){v_x_2411, v_t_2414, v_sp_2412, v_t_2415, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_p_2410);
  }
}