// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define LBL_op 10312
V g_intShow_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2edigitsFrom(V, V, V);
V g_prelude_2edigitsFrom_entry(V self, V *a);
extern Clo g_prelude_2edigitsFrom_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2emaybe_24s1822328499x1781525065(V, V);
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1822328499x1781525065_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2eshowInt_get(void);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2esplitFrom_2ebackwards_240(V, V);
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_2ebackwards_240_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2ewordsFrom_2ebackwards_240(V, V);
V g_prelude_2ewordsFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_2ebackwards_240_clo;

static V g_prelude_2eshowInt_val;
static HEFF_ONCE g_prelude_2eshowInt_st;
static V g_prelude_2eshowInt_init(void) {
  return heff_dup(g_intShow_get());
}
V g_prelude_2eshowInt_get(void) {
  if (HEFF_DONE(g_prelude_2eshowInt_st)) return g_prelude_2eshowInt_val;
  return heff_global(&g_prelude_2eshowInt_val, &g_prelude_2eshowInt_st, g_prelude_2eshowInt_init);
}
Clo g_prelude_2e_2b_2b_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_entry, 2, 0};

V g_prelude_2e_2b_2b(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2e_2b_2b(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b(a[0], a[1]);
}
Clo g_prelude_2eindexFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eindexFrom_entry, 3, 0};

V g_prelude_2eindexFrom(V v_needle_240, V v_s_241, V v_i_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
  if (heff_intLt_c(heff_strLength(heff_dup(v_s_241)), v_t_243)) {
    heff_drop(v_needle_240);
    heff_drop(v_s_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_245 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_241), heff_dup(v_i_242), v_t_245), heff_dup(v_needle_240))) {
      heff_drop(v_needle_240);
      heff_drop(v_s_241);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_242});
    } else {
      V t_0 = v_needle_240;
      V t_1 = v_s_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_needle_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
}
V g_prelude_2eindexFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eindexFrom(a[0], a[1], a[2]);
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 4, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(heff_dup(v_sep_240), heff_dup(v_s_241), heff_dup(v_i_242)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_sep_240);
    V v_t_245 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength(v_s_241));
    return (g_prelude_2esplitFrom_2ebackwards_240(heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_acc_243}), NTAG(TAG_Nil)));
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_dup(v_j_246), heff_strLength(heff_dup(v_sep_240)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_241), v_i_242, v_j_246), v_acc_243});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = v_t_248;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esplitFrom(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_242))) {
    V v_t_246;
    if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
    } else {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_t_246 = v_acc_243;
    }
    return (g_prelude_2ewordsFrom_2ebackwards_240(v_t_246, NTAG(TAG_Nil)));
  } else {
    V v_c_247 = heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_242));
    if (heff_intEq_c(heff_dup(v_c_247), MK_INT(32LL))) {
      heff_drop(v_c_247);
      V v_t_2410;
      if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
        v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_2410 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_2410;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_c_247), MK_INT(9LL))) {
        heff_drop(v_c_247);
        V v_t_2413;
        if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
        } else {
          heff_drop(v_start_241);
          v_t_2413 = v_acc_243;
        }
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_t_2413;
        v_s_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        if (heff_intEq_c(heff_dup(v_c_247), MK_INT(10LL))) {
          heff_drop(v_c_247);
          V v_t_2416;
          if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
            v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
          } else {
            heff_drop(v_start_241);
            v_t_2416 = v_acc_243;
          }
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_t_2416;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          if (heff_intEq_c(v_c_247, MK_INT(13LL))) {
            V v_t_2419;
            if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
              v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
            } else {
              heff_drop(v_start_241);
              v_t_2419 = v_acc_243;
            }
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_t_2419;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            V t_0 = v_s_240;
            V t_1 = v_start_241;
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_acc_243;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ewordsFrom(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_i_241, V v_step_242) {
top: ;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)))) {
      V v_c_245 = heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241));
      if (heff_intEq_c(heff_dup(v_c_245), MK_INT(32LL))) {
        heff_drop(v_c_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
        V t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      } else {
        if (heff_intEq_c(heff_dup(v_c_245), MK_INT(9LL))) {
          heff_drop(v_c_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
          V t_2 = v_step_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_step_242 = t_2;
          goto top;
        } else {
          if (heff_intEq_c(heff_dup(v_c_245), MK_INT(10LL))) {
            heff_drop(v_c_245);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
            V t_2 = v_step_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_step_242 = t_2;
            goto top;
          } else {
            if (heff_intEq_c(v_c_245, MK_INT(13LL))) {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
              V t_2 = v_step_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_step_242 = t_2;
              goto top;
            } else {
              heff_drop(v_s_240);
              heff_drop(v_step_242);
              return v_i_241;
            }
          }
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_step_242);
      return v_i_241;
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_step_242);
    return v_i_241;
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eskipSpaces(a[0], a[1], a[2]);
}
Clo g_prelude_2edigitsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edigitsFrom_entry, 3, 0};

V g_prelude_2edigitsFrom(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){v_n_242});
  } else {
    if (heff_intLe_c(MK_INT(48LL), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)))) {
      if (heff_intLe_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(57LL))) {
        V v_t_246 = heff_intSub(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(48LL));
        V v_t_247 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), v_t_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_n_242 = t_2;
        goto top;
      } else {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_n_242);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_prelude_2edigitsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edigitsFrom(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2eparseInt_str0, 1, "-");
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  if (heff_intEq_c(heff_strLength(heff_dup(v_s_240)), MK_INT(0LL))) {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_prelude_2eparseInt_str0))) {
      if (heff_intEq_c(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL))) {
        heff_drop(v_s_240);
        return NTAG(TAG_Nothing);
      } else {
        V v_x3_244 = (g_prelude_2edigitsFrom(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_245 = heff_field(v_x3_244, 0);
          V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_x_245)});
        }
        default: return heff_nomatch(v_x3_244);
        }
      }
    } else {
      return (g_prelude_2edigitsFrom(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eparseInt(a[0]);
}
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str0, 3, "===");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str1, 1, "<");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str2, 2, "<=");
Clo g_prelude_2emaybe_24s1822328499x1781525065_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emaybe_24s1822328499x1781525065_entry, 2, 0};

V g_prelude_2emaybe_24s1822328499x1781525065(V v_d_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nothing: {
    return v_d_240;
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24Just = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_d_240);
    V v_t_243 = heff_get_n(v_x_242, 1, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSub: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpMul: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpDiv: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRem: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpEq: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str0)});
    }
    case TAG_OpLt: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str1)});
    }
    case TAG_OpLe: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str2)});
    }
    case TAG_OpAnd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpOr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpXor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShl: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShow: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSqrt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFloor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emaybe_24s1822328499x1781525065(a[0], a[1]);
}