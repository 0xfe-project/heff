// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CDrop 58400
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_col 308218
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_fixed 298804110
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_path 9928940
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_intShow_get(void);
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24dps(V, V, V);
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24dps_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo;
V g_prelude_2e_2b_2b_24f1521533208x253309881(V, V, V);
V g_prelude_2e_2b_2b_24f1521533208x253309881_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1521533208x253309881_clo;
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590(V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f201610143x1454021782(V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f201610143x1454021782_clo;
V g_prelude_2e_2b_2b_24f201610143x1454021782_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_clo;
V g_prelude_2e_2b_2b_24f214727426x610923392(V, V);
V g_prelude_2e_2b_2b_24f214727426x610923392_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f214727426x610923392_clo;
V g_prelude_2e_2b_2b_24f214727426x610923392_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f214727426x610923392_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f214727426x610923392_24dps_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670(V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_24dps_clo;
V g_prelude_2e_2b_2b_24f903834997x2034796740(V, V, V);
V g_prelude_2e_2b_2b_24f903834997x2034796740_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f903834997x2034796740_clo;
V g_prelude_2e_2b_2b_24f903834997x2034796740_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f903834997x2034796740_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f903834997x2034796740_24dps_clo;
V g_prelude_2edigitsFrom(V, V, V);
V g_prelude_2edigitsFrom_entry(V self, V *a);
extern Clo g_prelude_2edigitsFrom_clo;
V g_prelude_2emaybe_24s1822328499x1781525065(V, V);
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1822328499x1781525065_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2eshowInt_get(void);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2esplitFrom_2ebackwards_240(V, V);
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_2ebackwards_240_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2ewordsFrom_2ebackwards_240(V, V);
V g_prelude_2ewordsFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_2ebackwards_240_clo;
Clo g_prelude_2estrFind_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2estrFind_entry, 3, 0};

V g_prelude_2estrFind(V v_needle_240, V v_s_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), MK_INT(0LL))) {
    heff_drop(v_i_242);
    V t_0 = v_needle_240;
    V t_1 = v_s_241;
    V t_2 = MK_INT(0LL);
    v_needle_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    V v_t_244 = heff_intAdd(heff_dup(v_i_242), heff_strLength_lent(v_needle_240, 0));
    if (heff_intLt_c(heff_strLength_lent(v_s_241, 0), v_t_244)) {
      heff_drop(v_needle_240);
      heff_drop(v_s_241);
      heff_drop(v_i_242);
      return MK_INT(-1LL);
    } else {
      V v_t_246 = heff_intAdd(heff_dup(v_i_242), heff_strLength_lent(v_needle_240, 0));
      if (heff_strEq_c(heff_strSlice_lent(v_s_241, v_i_242, v_t_246, 4), heff_dup(v_needle_240))) {
        heff_drop(v_needle_240);
        heff_drop(v_s_241);
        return v_i_242;
      } else {
        V t_0 = v_needle_240;
        V t_1 = v_s_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_needle_240 = t_0;
        v_s_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
    }
  }
}
V g_prelude_2estrFind_entry(V self, V *a) {
  (void)self;
  return g_prelude_2estrFind(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_entry, 2, 0};

V g_prelude_2e_2b_2b(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_prelude_2e_2b_2b_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 5, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_j_243, V v_acc_244) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_243), MK_INT(0LL))) {
    heff_drop(v_sep_240);
    heff_drop(v_j_243);
    V v_t_246 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength(v_s_241));
    return (g_prelude_2esplitFrom_2ebackwards_240(heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_acc_244}), NTAG(TAG_Nil)));
  } else {
    V v_t_247 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_248 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_249 = (g_prelude_2estrFind(heff_dup(v_sep_240), heff_dup(v_s_241), v_t_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_i_242, v_j_243, 6), v_acc_244});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = v_t_249;
    V t_4 = v_t_2410;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_j_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esplitFrom(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_242))) {
    V v_t_246;
    if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
    } else {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_t_246 = v_acc_243;
    }
    return (g_prelude_2ewordsFrom_2ebackwards_240(v_t_246, NTAG(TAG_Nil)));
  } else {
    V v_c_247 = heff_strByteAt_lent(v_s_240, v_i_242, 0);
    if (heff_intEq_c(heff_dup(v_c_247), MK_INT(32LL))) {
      heff_drop(v_c_247);
      V v_t_2410;
      if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
        v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_2410 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_2410;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_c_247), MK_INT(9LL))) {
        heff_drop(v_c_247);
        V v_t_2413;
        if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2), v_acc_243});
        } else {
          heff_drop(v_start_241);
          v_t_2413 = v_acc_243;
        }
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_t_2413;
        v_s_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        if (heff_intEq_c(heff_dup(v_c_247), MK_INT(10LL))) {
          heff_drop(v_c_247);
          V v_t_2416;
          if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
            v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2), v_acc_243});
          } else {
            heff_drop(v_start_241);
            v_t_2416 = v_acc_243;
          }
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_t_2416;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          if (heff_intEq_c(v_c_247, MK_INT(13LL))) {
            V v_t_2419;
            if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
              v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2), v_acc_243});
            } else {
              heff_drop(v_start_241);
              v_t_2419 = v_acc_243;
            }
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_t_2419;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            V t_0 = v_s_240;
            V t_1 = v_start_241;
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_acc_243;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ewordsFrom(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_i_241, V v_step_242) {
top: ;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
      V v_c_245 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
      if (heff_intEq_c(heff_dup(v_c_245), MK_INT(32LL))) {
        heff_drop(v_c_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
        V t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      } else {
        if (heff_intEq_c(heff_dup(v_c_245), MK_INT(9LL))) {
          heff_drop(v_c_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
          V t_2 = v_step_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_step_242 = t_2;
          goto top;
        } else {
          if (heff_intEq_c(heff_dup(v_c_245), MK_INT(10LL))) {
            heff_drop(v_c_245);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
            V t_2 = v_step_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_step_242 = t_2;
            goto top;
          } else {
            if (heff_intEq_c(v_c_245, MK_INT(13LL))) {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
              V t_2 = v_step_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_step_242 = t_2;
              goto top;
            } else {
              heff_drop(v_s_240);
              heff_drop(v_step_242);
              return v_i_241;
            }
          }
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_step_242);
      return v_i_241;
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_step_242);
    return v_i_241;
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eskipSpaces(a[0], a[1], a[2]);
}
Clo g_prelude_2edigitsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edigitsFrom_entry, 3, 0};

V g_prelude_2edigitsFrom(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){v_n_242});
  } else {
    if (heff_intLe_c(MK_INT(48LL), heff_strByteAt_lent(v_s_240, v_i_241, 0))) {
      if (heff_intLe_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(57LL))) {
        V v_t_246 = heff_intSub(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(48LL));
        V v_t_247 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), v_t_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_n_242 = t_2;
        goto top;
      } else {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_n_242);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_prelude_2edigitsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edigitsFrom(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2eparseInt_str0, 1, "-");
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  if (heff_intEq_c(heff_strLength_lent(v_s_240, 0), MK_INT(0LL))) {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_prelude_2eparseInt_str0))) {
      if (heff_intEq_c(heff_strLength_lent(v_s_240, 0), MK_INT(1LL))) {
        heff_drop(v_s_240);
        return NTAG(TAG_Nothing);
      } else {
        V v_x3_244 = (g_prelude_2edigitsFrom(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_245 = heff_field(v_x3_244, 0);
          V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_x_245)});
        }
        default: return heff_nomatch(v_x3_244);
        }
      }
    } else {
      return (g_prelude_2edigitsFrom(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eparseInt(a[0]);
}

static V g_prelude_2eshowInt_val;
static HEFF_ONCE g_prelude_2eshowInt_st;
static V g_prelude_2eshowInt_init(void) {
  return heff_dup(g_intShow_get());
}
V g_prelude_2eshowInt_get(void) {
  if (HEFF_DONE(g_prelude_2eshowInt_st)) return g_prelude_2eshowInt_val;
  return heff_global(&g_prelude_2eshowInt_val, &g_prelude_2eshowInt_st, g_prelude_2eshowInt_init);
}
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str0, 3, "===");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str1, 1, "<");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str2, 2, "<=");
Clo g_prelude_2emaybe_24s1822328499x1781525065_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emaybe_24s1822328499x1781525065_entry, 2, 0};

V g_prelude_2emaybe_24s1822328499x1781525065(V v_d_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nothing: {
    return v_d_240;
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24Just = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_d_240);
    V v_t_243 = heff_get_n(v_x_242, 1, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSub: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpMul: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpDiv: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRem: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpEq: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str0)});
    }
    case TAG_OpLt: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str1)});
    }
    case TAG_OpLe: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str2)});
    }
    case TAG_OpAnd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpOr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpXor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShl: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShow: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSqrt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFloor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emaybe_24s1822328499x1781525065(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_244});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_entry, 2, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_t_245 = (g_list_2efilter_24s727803713x1346936525(v_x_242, v_xs_243));
    V v_u_246 = (g_prelude_2e_2b_2b_24f368057430x559112032_24dps(v_ys_240, v_t_245, heff_dup(v_cell_244)));
    heff_drop(v_u_246);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V v_t_247 = (g_list_2efilter_24s727803713x1346936525(v_x_243, v_xs_244));
    V t_0 = v_ys_240;
    V t_1 = v_t_247;
    V t_2 = v_cell_245;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_entry, 3, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250(V v_ys_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return (g_prelude_2e_2b_2b(v_xs_244, v_ys_240));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(v_ys_240, heff_intSub(v_i_241, MK_INT(1LL)), v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V v_ys_240, V v_i_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V v_t_247 = (g_prelude_2e_2b_2b(v_xs_245, v_ys_240));
      return heff_setField(v_d_243, MK_INT(1LL), v_t_247);
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ys_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_ys_240 = t_0;
      v_i_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_entry, 3, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251(V v_ys_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(v_ys_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V v_ys_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1572068627x1632985590_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1572068627x1632985590(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_CDrop, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1572068627x1632985590(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_CDrop, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_entry, 2, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f709746438x971999636_24dps(v_ys_240, v_x12_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_cell_247;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_entry, 3, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(v_ys_240, v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f58476578x2140998212(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_strAppend(heff_dup(v_lit_241), v_x_243);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_dup(v_lit_241), v_x_244);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1727312714x1365290191_entry, 9, 0};

V g_prelude_2e_2b_2b_24f1727312714x1365290191(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_xs_247, 0);
    V v_xs2_2410 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs2_2410);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_ys_248, 0);
      V v_ys2_2412 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
      V v_t_2414 = heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246));
      V v_x_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_strAppend(heff_dup(v_lit_245), v_t_2414));
      V v_cell_2416 = heff_tag_at_n(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){v_x_2415, heff_hole()});
      V v_u_2417 = (g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs2_2410, v_ys2_2412, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_prelude_2e_2b_2b_24f1727312714x1365290191_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1727312714x1365290191(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry, 10, 0};

V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_247, 0);
    V v_xs2_2411 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs2_2411);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_ys_248, 0);
      V v_ys2_2413 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2410, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
      V v_t_2415 = heff_strAppend(heff_intShow(v_y_2412), heff_dup(v_lit_246));
      V v_x_2416 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_strAppend(heff_dup(v_lit_245), v_t_2415));
      V v_cell_2417 = heff_tag_at_n(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){v_x_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs2_2411;
      V t_8 = v_ys2_2413;
      V t_9 = v_cell_2417;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_xs_247 = t_7;
      v_ys_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_x_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_str0), v_x_242));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367(a[0], a[1]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_x_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0), v_x_243));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_x_247 = v_y_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1521533208x253309881_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1521533208x253309881_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1521533208x253309881(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_241))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1521533208x253309881_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1521533208x253309881(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_241))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f201610143x1454021782_str0, 6, "import");
HEFF_LIT(g_prelude_2e_2b_2b_24f201610143x1454021782_str1, 0, "");
Clo g_prelude_2e_2b_2b_24f201610143x1454021782_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f201610143x1454021782_entry, 2, 0};

V g_prelude_2e_2b_2b_24f201610143x1454021782(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_242, 2, 3), 1, 2);
    V v_x_246 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_prelude_2e_2b_2b_24f201610143x1454021782_str0), ((V)&g_prelude_2e_2b_2b_24f201610143x1454021782_str1), v_t_244, v_t_245, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f201610143x1454021782_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f201610143x1454021782_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f201610143x1454021782(a[0], a[1]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_str0, 6, "import");
HEFF_LIT(g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_str1, 0, "");
Clo g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f201610143x1454021782_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    V v_t_246 = heff_get_n(heff_get_n(v_x_243, 2, 3), 1, 2);
    V v_x_247 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_str0), ((V)&g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_str1), v_t_245, v_t_246, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f201610143x1454021782_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f201610143x1454021782_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_entry, 3, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_246;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275(V v_ys_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_sp_243 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_str0), 2)) {
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_x_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_243, NTAG(TAG_False)});
        V v_t_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_246, v_t_247});
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2412, v_ys_240);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2416); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2417, v_ys_240);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2422); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2423, v_ys_240);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2426); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2427, v_ys_240);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_p1_242, 0);
      V v_p12_2430 = heff_field(v_p1_242, 1);
      V v_q_2431 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_sp_243);
      V v_x_2432 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_p12_2430, NTAG(TAG_False)});
      V v_cell_2433 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2432, heff_hole()});
      V v_u_2434 = (g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(v_ys_240, v_q_2431, heff_dup(v_cell_2433)));
      heff_drop(v_u_2434);
      return v_cell_2433;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1537904782x516751275(a[0], a[1]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V v_ys_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_241, 0);
    V v_sp_244 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      if (heff_strEq_c_lent(v_x_245, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0), 2)) {
        heff_drop(v_sp_244);
        heff_drop(v_x_245);
        return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
      } else {
        V v_x_247 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_sp_244, NTAG(TAG_False)});
        V v_t_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_t_248}));
      }
    }
    case TAG_PatTag: {
      V v_ps_2411 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
    }
    case TAG_PatOp: {
      V v_ps_2417 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2417));
      V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2418); r_; });
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2420);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatBinary: {
      V v_segs_2424 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2426, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2427);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatRecord: {
      V v_fs_2429 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2429));
      V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2430); r_; });
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2432);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatAs: {
      V v_x_2434 = heff_field(v_p1_243, 0);
      V v_p12_2435 = heff_field(v_p1_243, 1);
      V v_q_2436 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 7ULL, 3);
      heff_drop(v_sp_244);
      V v_x_2437 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2434, v_p12_2435, NTAG(TAG_False)});
      V v_cell_2438 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2437, heff_hole()});
      V v_u_2439 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2438));
      heff_drop(v_u_2439);
      V t_0 = v_ys_240;
      V t_1 = v_q_2436;
      V t_2 = v_cell_2438;
      v_ys_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f738852651x284559611_entry, 2, 0};

V g_prelude_2e_2b_2b_24f738852651x284559611(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = (g_heff_2ebuild_2edriver_2elean(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f738852651x284559611_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f738852651x284559611(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f738852651x284559611_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f738852651x284559611_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = (g_heff_2ebuild_2edriver_2elean(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f738852651x284559611_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f903834997x2034796740_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f903834997x2034796740_entry, 3, 0};

V g_prelude_2e_2b_2b_24f903834997x2034796740(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241))) {
      heff_drop_rec(v_x_243, 13);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f903834997x2034796740_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f903834997x2034796740_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f903834997x2034796740(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f903834997x2034796740_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f903834997x2034796740_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f903834997x2034796740_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
      heff_drop_rec(v_x_244, 13);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f903834997x2034796740_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f903834997x2034796740_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f214727426x610923392_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f214727426x610923392_entry, 2, 0};

V g_prelude_2e_2b_2b_24f214727426x610923392(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 0, 13);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f214727426x610923392_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f214727426x610923392_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f214727426x610923392(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f214727426x610923392_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f214727426x610923392_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f214727426x610923392_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 0, 13);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f214727426x610923392_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f214727426x610923392_24dps(a[0], a[1], a[2]);
}