// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_prelude_2eshowInt_val;
static int g_prelude_2eshowInt_st;
static V g_prelude_2eshowInt_init(void) {
  return heff_dup(g_intShow_get());
}
V g_prelude_2eshowInt_get(void) {
  if (g_prelude_2eshowInt_st == 2) return g_prelude_2eshowInt_val;
  if (g_prelude_2eshowInt_st == 1) heff_fail("defined by itself");
  g_prelude_2eshowInt_st = 1;
  g_prelude_2eshowInt_val = heff_tr(g_prelude_2eshowInt_init());
  g_prelude_2eshowInt_st = 2;
  return g_prelude_2eshowInt_val;
}
Clo g_prelude_2emap_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_entry, 2, 0};

V g_prelude_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap(v_f_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap(a[0], a[1]);
}
Clo g_prelude_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_entry, 3, 0};

V g_prelude_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2efoldl_24s0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s0_entry, 2, 0};

V g_prelude_2efoldl_24s0(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s0_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s0(a[0], a[1]);
}
Clo g_prelude_2efilter_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_entry, 2, 0};

V g_prelude_2efilter(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2efilter(v_p_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efilter_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1_entry, 2, 0};

V g_prelude_2efoldl_24s1(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd(v_z_240, MK_INT(1LL));
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2econcatList_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2econcatList_entry, 2, 0};

V g_prelude_2econcatList(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2econcatList(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2econcatList_entry(V self, V *a) {
  (void)self;
  return g_prelude_2econcatList(a[0], a[1]);
}
Clo g_prelude_2etake_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etake_entry, 2, 0};

V g_prelude_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2etake(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etake_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etake(a[0], a[1]);
}
Clo g_prelude_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edrop_entry, 2, 0};

V g_prelude_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2edrop_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edrop(a[0], a[1]);
}
Clo g_prelude_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_entry, 3, 0};

V g_prelude_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith(v_f_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith(a[0], a[1], a[2]);
}
Clo g_prelude_2eany_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_entry, 2, 0};

V g_prelude_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2eany_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eall_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_entry, 2, 0};

V g_prelude_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2eall_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efind_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_entry, 2, 0};

V g_prelude_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efind_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2elookupBy_entry, 3, 0};

V g_prelude_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      }
      case TAG_False: {
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2elookupBy_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2elookupBy(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2efoldl_24s2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2_entry, 2, 0};

V g_prelude_2efoldl_24s2(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd(v_z_240, heff_dup(v_x_242));
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2erange_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2erange_entry, 2, 0};

V g_prelude_2erange(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_b_241), heff_dup(v_a_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_240), (g_prelude_2erange(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_prelude_2erange_entry(V self, V *a) {
  (void)self;
  return g_prelude_2erange(a[0], a[1]);
}
Clo g_prelude_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ereplicate_entry, 2, 0};

V g_prelude_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), (g_prelude_2ereplicate(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_prelude_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ereplicate(a[0], a[1]);
}
Clo g_prelude_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_entry, 3, 0};

V g_prelude_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_prelude_2emerge(v_le_240, v_xs2_244, heff_tag(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, (g_prelude_2emerge(v_le_240, heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246))});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2emerge_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge(a[0], a[1], a[2]);
}
Clo g_prelude_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_entry, 2, 0};

V g_prelude_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
      V v_t_247 = heff_intDiv(v_t_246, MK_INT(2LL));
      V v_t_248 = (g_prelude_2etake(v_t_247, heff_dup(v_xs_241)));
      V v_t_249 = (g_prelude_2esortBy(heff_dup(v_le_240), v_t_248));
      V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
      V v_t_2411 = heff_intDiv(v_t_2410, MK_INT(2LL));
      V v_t_2412 = (g_prelude_2edrop(v_t_2411, v_xs_241));
      V v_t_2413 = (g_prelude_2esortBy(heff_dup(v_le_240), v_t_2412));
      return (g_prelude_2emerge(v_le_240, v_t_249, v_t_2413));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy(a[0], a[1]);
}
Clo g_prelude_2eindexFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eindexFrom_entry, 3, 0};

V g_prelude_2eindexFrom(V v_needle_240, V v_s_241, V v_i_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
  V v_t_244 = heff_intLt(heff_strLength(heff_dup(v_s_241)), v_t_243);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_needle_240);
    heff_drop(v_s_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_245 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
    V v_t_246 = heff_strEq(heff_strSlice(heff_dup(v_s_241), heff_dup(v_i_242), v_t_245), heff_dup(v_needle_240));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_needle_240);
      heff_drop(v_s_241);
      return heff_tag(TAG_Just, 1, (V[]){v_i_242});
    }
    case TAG_False: {
      V t_0 = v_needle_240;
      V t_1 = v_s_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_needle_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2eindexFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eindexFrom(a[0], a[1], a[2]);
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 4, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(heff_dup(v_sep_240), heff_dup(v_s_241), heff_dup(v_i_242)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_sep_240);
    V v_t_245 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength(v_s_241));
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_acc_243})));
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_dup(v_j_246), heff_strLength(heff_dup(v_sep_240)));
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_241), v_i_242, v_j_246), v_acc_243});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = v_t_248;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esplitFrom(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s3_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2efoldl_24s3_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s3_entry, 2, 0};

V g_prelude_2efoldl_24s3(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s3_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s3_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s3(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
    V v_xs_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_xs_246 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
      break;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_xs_246 = v_acc_243;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_False: {
    V v_c_247 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_242));
    V v_t_248 = heff_intEq(heff_dup(v_c_247), MK_INT(32LL));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_c_247);
      V v_t_249 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
      V v_t_2410;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop(v_start_241);
        v_t_2410 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_2410;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    case TAG_False: {
      V v_t_2411 = heff_intEq(heff_dup(v_c_247), MK_INT(9LL));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_c_247);
        V v_t_2412 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
        V v_t_2413;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
          break;
        }
        case TAG_False: {
          heff_drop(v_start_241);
          v_t_2413 = v_acc_243;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_t_2413;
        v_s_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_False: {
        V v_t_2414 = heff_intEq(heff_dup(v_c_247), MK_INT(10LL));
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          heff_drop(v_c_247);
          V v_t_2415 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
          V v_t_2416;
          switch (heff_tag_of(v_t_2415)) {
          case TAG_True: {
            v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
            break;
          }
          case TAG_False: {
            heff_drop(v_start_241);
            v_t_2416 = v_acc_243;
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_t_2416;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
        case TAG_False: {
          V v_t_2417 = heff_intEq(v_c_247, MK_INT(13LL));
          switch (heff_tag_of(v_t_2417)) {
          case TAG_True: {
            V v_t_2418 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
            V v_t_2419;
            switch (heff_tag_of(v_t_2418)) {
            case TAG_True: {
              v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
              break;
            }
            case TAG_False: {
              heff_drop(v_start_241);
              v_t_2419 = v_acc_243;
              break;
            }
            default: heff_nomatch(v_t_2418);
            }
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_t_2419;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
          case TAG_False: {
            V t_0 = v_s_240;
            V t_1 = v_start_241;
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_acc_243;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
          default: return heff_nomatch(v_t_2417);
          }
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ewordsFrom(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s4_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2efoldl_24s4_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s4_entry, 2, 0};

V g_prelude_2efoldl_24s4(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s4_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s4_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s4(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_i_241, V v_step_242) {
top: ;
  V v_t_243 = heff_intLe(MK_INT(0LL), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_intLt(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_c_245 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
      V v_t_246 = heff_intEq(heff_dup(v_c_245), MK_INT(32LL));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_c_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
        V t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      }
      case TAG_False: {
        V v_t_247 = heff_intEq(heff_dup(v_c_245), MK_INT(9LL));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_c_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
          V t_2 = v_step_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_step_242 = t_2;
          goto top;
        }
        case TAG_False: {
          V v_t_248 = heff_intEq(heff_dup(v_c_245), MK_INT(10LL));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_c_245);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
            V t_2 = v_step_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_step_242 = t_2;
            goto top;
          }
          case TAG_False: {
            V v_t_249 = heff_intEq(v_c_245, MK_INT(13LL));
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
              V t_2 = v_step_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_step_242 = t_2;
              goto top;
            }
            case TAG_False: {
              heff_drop(v_s_240);
              heff_drop(v_step_242);
              return v_i_241;
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_step_242);
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_step_242);
    return v_i_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eskipSpaces(a[0], a[1], a[2]);
}
Clo g_prelude_2edigitsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edigitsFrom_entry, 3, 0};

V g_prelude_2edigitsFrom(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_tag(TAG_Just, 1, (V[]){v_n_242});
  }
  case TAG_False: {
    V v_t_244 = heff_intLe(MK_INT(48LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(57LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = heff_intSub(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(48LL));
        V v_t_247 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), v_t_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_n_242 = t_2;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_n_242);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_prelude_2edigitsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edigitsFrom(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eparseInt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  V v_t_241 = heff_intEq(heff_strLength(heff_dup(v_s_240)), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_242 = heff_strEq(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_prelude_2eparseInt_str0));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_intEq(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_s_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_x3_244 = (g_prelude_2edigitsFrom(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_245 = heff_field(v_x3_244, 0);
          V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
          return heff_tag_at(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_x_245)});
        }
        default: return heff_nomatch(v_x3_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    case TAG_False: {
      return (g_prelude_2edigitsFrom(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eparseInt(a[0]);
}
Clo g_prelude_2emap_24s5_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s5_entry, 1, 0};

V g_prelude_2emap_24s5(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s5(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s5_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s5(a[0]);
}
Clo g_prelude_2emap_24s6_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s6_entry, 1, 0};

V g_prelude_2emap_24s6(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s6(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s6_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s6(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s13_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_prelude_2efoldl_24s13_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s13_entry, 2, 0};

V g_prelude_2efoldl_24s13(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s13_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s13_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s13(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s19_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s19_entry, 1, 0};

V g_prelude_2emap_24s19(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_looser), (g_prelude_2emap_24s19(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s19_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s19(a[0]);
}
Clo g_prelude_2efoldl_24s21_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s21_entry, 2, 0};

V g_prelude_2efoldl_24s21(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s21_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s21(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eany_24s22_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s22_entry, 1, 0};

V g_prelude_2eany_24s22(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_name), heff_dup(g_heff_2eimport_2ebuiltinModule_get()));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s22_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s22(a[0]); heff_drop(a[0]); return r;
}
V g_prelude_2efoldl_24s41_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s41_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s41_entry, 2, 0};

V g_prelude_2efoldl_24s41(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo(g_prelude_2efoldl_24s41_lam0, 1, 1, (V[]){v_x_242}), heff_get(heff_dup(v_z_240), LBL_local)});
    V v_t_246 = heff_rec(2, shape_178_114, (V[]){v_t_245, heff_get(v_z_240, LBL_global)});
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s41_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s41(a[0], a[1]);
}
V g_prelude_2efoldl_24s41_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_244);
  return heff_tag(TAG_Ok, 1, (V[]){v_x_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s42_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
Clo g_prelude_2emap_24s42_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s42_entry, 1, 0};

V g_prelude_2emap_24s42(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_v2_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = heff_strAppend(v_x_243, heff_strAppend(((V)&g_prelude_2emap_24s42_str0), ({ V b_0 = NTAG(TAG_False); V a_1 = v_v2_244; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_v2_244); r_; })));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s42(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s42_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s42(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s43_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s43_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s43_entry, 1, 0};

V g_prelude_2emap_24s43(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s43_str0), ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_241; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_241); r_; }));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s43(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s43_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s43(a[0]);
}
Clo g_prelude_2emap_24s44_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s44_entry, 1, 0};

V g_prelude_2emap_24s44(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s44(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s44_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s44(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2efoldl_24s45_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_prelude_2efoldl_24s45_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s45_entry, 2, 0};

V g_prelude_2efoldl_24s45(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s45_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s45_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s45(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s46_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2efoldl_24s46_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s46_entry, 2, 0};

V g_prelude_2efoldl_24s46(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s46_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s46_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s46(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s52_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s52_entry, 1, 0};

V g_prelude_2emap_24s52(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eargOf_24s51(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s52(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s52_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s52(a[0]);
}
Clo g_prelude_2emap_24s53_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s53_entry, 1, 0};

V g_prelude_2emap_24s53(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2epresyntax_2eclassifyTermF_24s49(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_IsInferable: {
      V v_i_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_i_244)) {
      case TAG_At: {
        V v_s_246 = heff_dup(heff_field(v_i_244, 1));
        v_t_247 = v_s_246;
        break;
      }
      default: heff_nomatch(v_i_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_248 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_c_248;
      break;
    }
    case TAG_IsType: {
      V v_t_249 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s53(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s53_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s53(a[0]);
}
Clo g_prelude_2emap_24s56_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s56_entry, 1, 0};

V g_prelude_2emap_24s56(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldDeclOf_24s55(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s56(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s56_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s56(a[0]);
}
Clo g_prelude_2emap_24s58_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s58_entry, 1, 0};

V g_prelude_2emap_24s58(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2epresyntax_2eclassifyTermF_24s49(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_IsInferable: {
      V v_i_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_i_244)) {
      case TAG_At: {
        V v_s_246 = heff_dup(heff_field(v_i_244, 1));
        v_t_247 = v_s_246;
        break;
      }
      default: heff_nomatch(v_i_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_248 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_c_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_c_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_c_248);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_248}), v_t_2411});
      break;
    }
    case TAG_IsType: {
      V v_t_2412 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_t_2412;
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s58(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s58_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s58(a[0]);
}
Clo g_prelude_2emap_24s59_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s59_entry, 1, 0};

V g_prelude_2emap_24s59(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2evariantOf_24s57(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s59(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s59_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s59(a[0]);
}
Clo g_prelude_2emap_24s61_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s61_entry, 1, 0};

V g_prelude_2emap_24s61(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldSetOf_24s60(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s61(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s61_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s61(a[0]);
}
Clo g_prelude_2emap_24s63_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s63_entry, 1, 0};

V g_prelude_2emap_24s63(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2ealtOf_24s62(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s63(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s63_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s63(a[0]);
}
Clo g_prelude_2emap_24s64_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s64_entry, 1, 0};

V g_prelude_2emap_24s64(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eequationOf_24s48(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s64(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s64_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s64(a[0]);
}
Clo g_prelude_2emap_24s66_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s66_entry, 1, 0};

V g_prelude_2emap_24s66(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eparamOf_24s65(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s66(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s66_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s66(a[0]);
}
Clo g_prelude_2emap_24s68_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s68_entry, 1, 0};

V g_prelude_2emap_24s68(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2echkNode_24s67(v_n_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s68(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s68_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s68(a[0]);
}
Clo g_prelude_2emap_24s69_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s69_entry, 1, 0};

V g_prelude_2emap_24s69(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_243)) {
      case TAG_SetField: {
        V v_x_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_e_247 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24SetField = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_e_247)) {
        case TAG_At: {
          V v_n_248 = heff_field(v_e_247, 0);
          V v_sp_249 = heff_field(v_e_247, 1);
          heff_take_n(v_e_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2epresyntax_2echkNode_24s67(v_n_248));
          v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2410, v_sp_249});
          break;
        }
        default: heff_nomatch(v_e_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24SetField, TAG_SetField, 3, (V[]){v_x_245, v_sp_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2412 = heff_field(v_x_243, 0);
        V v_ru_24x_243_24BadFieldSet = heff_take_reuse_n(v_x_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_e_2412)) {
        case TAG_At: {
          V v_n_2413 = heff_field(v_e_2412, 0);
          V v_sp_2414 = heff_field(v_e_2412, 1);
          heff_take_n(v_e_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s67(v_n_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
          break;
        }
        default: heff_nomatch(v_e_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s69(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s69_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s69(a[0]);
}
Clo g_prelude_2emap_24s70_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s70_entry, 1, 0};

V g_prelude_2emap_24s70(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x_243, 0);
        V v_b_246 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_b_246)) {
        case TAG_At: {
          V v_n_247 = heff_field(v_b_246, 0);
          V v_sp_248 = heff_field(v_b_246, 1);
          heff_take_n(v_b_246, 3ULL, 2);
          V v_t_249 = (g_heff_2epresyntax_2echkNode_24s67(v_n_247));
          v_t_2410 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_249, v_sp_248});
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        v_t_2411 = heff_tag_at(v_ru_24x_241_24At, TAG_MkAlt, 2, (V[]){v_p_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2412 = heff_tag(TAG_At, 2, (V[]){v_t_2411, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s70(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s70_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s70(a[0]);
}
Clo g_prelude_2emap_24s72_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s72_entry, 1, 0};

V g_prelude_2emap_24s72(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkEquation: {
        V v_f_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_ps_247 = heff_field(v_x_243, 2);
        V v_rhs_248 = heff_field(v_x_243, 3);
        V v_ru_24x_243_24MkEquation = heff_take_reuse_n(v_x_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_rhs_248)) {
        case TAG_At: {
          V v_n_249 = heff_field(v_rhs_248, 0);
          V v_sp_2410 = heff_field(v_rhs_248, 1);
          heff_take_n(v_rhs_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2epresyntax_2echkNode_24s67(v_n_249));
          v_t_2412 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
          break;
        }
        default: heff_nomatch(v_rhs_248);
        }
        v_t_2413 = heff_tag_at(v_ru_24x_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_245, v_sp_246, v_ps_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2414 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2emap_24s72(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s72_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s72(a[0]);
}
Clo g_prelude_2emap_24s78_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s78_entry, 1, 0};

V g_prelude_2emap_24s78(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2efieldDeclN_24s77(v_x_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s78(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s78_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s78(a[0]);
}
Clo g_prelude_2emap_24s79_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s79_entry, 1, 0};

V g_prelude_2emap_24s79(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s79(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s79_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s79(a[0]);
}
Clo g_prelude_2emap_24s80_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s80_entry, 1, 0};

V g_prelude_2emap_24s80(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_TagVariant: {
        V v_x_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_ts_247 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24TagVariant = heff_take_reuse_n(v_x_243, 7ULL, 3);
        v_t_2412 = heff_tag_at(v_ru_24x_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_x_245, v_sp_246, (g_prelude_2emap_24s79(v_ts_247))});
        break;
      }
      case TAG_BadVariant: {
        V v_e_248 = heff_field(v_x_243, 0);
        V v_ru_24x_243_24BadVariant = heff_take_reuse_n(v_x_243, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_e_248)) {
        case TAG_At: {
          V v_n_249 = heff_field(v_e_248, 0);
          V v_sp_2410 = heff_field(v_e_248, 1);
          heff_take_n(v_e_248, 3ULL, 2);
          v_t_2411 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_2410, v_n_249));
          break;
        }
        default: heff_nomatch(v_e_248);
        }
        v_t_2412 = heff_tag_at(v_ru_24x_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2412, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s80(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s80_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s80(a[0]);
}
Clo g_prelude_2emap_24s82_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s82_entry, 1, 0};

V g_prelude_2emap_24s82(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_243)) {
      case TAG_ArgExplicit: {
        V v_c_245 = heff_field(v_x_243, 0);
        V v_ru_24x_243_24ArgExplicit = heff_take_reuse_n(v_x_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_249;
        switch (heff_tag_of(v_c_245)) {
        case TAG_At: {
          V v_n_246 = heff_field(v_c_245, 0);
          V v_sp_247 = heff_field(v_c_245, 1);
          heff_take_n(v_c_245, 3ULL, 2);
          V v_t_248 = (g_heff_2epresyntax_2echkNode_24s67(v_n_246));
          v_t_249 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_248, v_sp_247});
          break;
        }
        default: heff_nomatch(v_c_245);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_x_2410 = heff_field(v_x_243, 0);
        V v_ru_24x_243_24ArgProject = heff_take_reuse_n(v_x_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_x_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_x_2411 = heff_field(v_x_243, 0);
        V v_c_2412 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_n_2413 = heff_field(v_c_2412, 0);
          V v_sp_2414 = heff_field(v_c_2412, 1);
          heff_take_n(v_c_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s67(v_n_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_241_24At, TAG_ArgNamed, 2, (V[]){v_x_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2418 = heff_tag(TAG_At, 2, (V[]){v_t_2417, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s82(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s82_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s82(a[0]);
}
Clo g_prelude_2emap_24s73_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s73_entry, 1, 0};

V g_prelude_2emap_24s73(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_t_247 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24ExplicitParam = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_t_247)) {
        case TAG_At: {
          V v_n_248 = heff_field(v_t_247, 0);
          V v_sp_249 = heff_field(v_t_247, 1);
          heff_take_n(v_t_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_249, v_n_248));
          break;
        }
        default: heff_nomatch(v_t_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_245, v_sp_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2411 = heff_field(v_x_243, 0);
        V v_sp_2412 = heff_field(v_x_243, 1);
        V v_t_2413 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24ImplicitParam = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_n_2414 = heff_field(v_t_2413, 0);
          V v_sp_2415 = heff_field(v_t_2413, 1);
          heff_take_n(v_t_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_2415, v_n_2414));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2411, v_sp_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2417, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s73(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s73_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s73(a[0]);
}
Clo g_prelude_2emap_24s83_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s83_entry, 1, 0};

V g_prelude_2emap_24s83(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_t_247 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24ExplicitParam = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_t_247)) {
        case TAG_At: {
          V v_n_248 = heff_field(v_t_247, 0);
          V v_sp_249 = heff_field(v_t_247, 1);
          heff_take_n(v_t_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_249, v_n_248));
          break;
        }
        default: heff_nomatch(v_t_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_245, v_sp_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2411 = heff_field(v_x_243, 0);
        V v_sp_2412 = heff_field(v_x_243, 1);
        V v_t_2413 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24ImplicitParam = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_n_2414 = heff_field(v_t_2413, 0);
          V v_sp_2415 = heff_field(v_t_2413, 1);
          heff_take_n(v_t_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_2415, v_n_2414));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2411, v_sp_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2417, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s83(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s83_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s83(a[0]);
}
Clo g_prelude_2emap_24s84_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s84_entry, 1, 0};

V g_prelude_2emap_24s84(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2edeclN_24s71(v_x_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s84(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s84_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s84(a[0]);
}
Clo g_prelude_2emap_24s86_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s86_entry, 1, 0};

V g_prelude_2emap_24s86(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_x_243)) {
      case TAG_SetField: {
        V v_x_245 = heff_field(v_x_243, 0);
        V v_sp_246 = heff_field(v_x_243, 1);
        V v_e_247 = heff_field(v_x_243, 2);
        V v_ru_24x_243_24SetField = heff_take_reuse_n(v_x_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_e_247)) {
        case TAG_At: {
          V v_n_248 = heff_field(v_e_247, 0);
          V v_sp_249 = heff_field(v_e_247, 1);
          heff_take_n(v_e_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2echkDe_24s85(v_sp_249, v_n_248));
          break;
        }
        default: heff_nomatch(v_e_247);
        }
        v_t_2415 = heff_tag_at(v_ru_24x_243_24SetField, TAG_SetField, 3, (V[]){v_x_245, v_sp_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2411 = heff_field(v_x_243, 0);
        V v_ru_24x_243_24BadFieldSet = heff_take_reuse_n(v_x_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_e_2411)) {
        case TAG_At: {
          V v_n_2412 = heff_field(v_e_2411, 0);
          V v_sp_2413 = heff_field(v_e_2411, 1);
          heff_take_n(v_e_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2epresyntax_2echkDe_24s85(v_sp_2413, v_n_2412));
          break;
        }
        default: heff_nomatch(v_e_2411);
        }
        v_t_2415 = heff_tag_at(v_ru_24x_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_sp_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2416, (g_prelude_2emap_24s86(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s86_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s86(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s89_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_prelude_2efoldl_24s89_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s89_entry, 2, 0};

V g_prelude_2efoldl_24s89(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s89_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s89_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s89(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2efoldl_24s90_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 124, 32}};
Clo g_prelude_2efoldl_24s90_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s90_entry, 2, 0};

V g_prelude_2efoldl_24s90(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s90_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s90_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s90(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s177_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
Clo g_prelude_2emap_24s177_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s177_entry, 1, 0};

V g_prelude_2emap_24s177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_prelude_2emap_24s177_str0), v_x_241), (g_prelude_2emap_24s177(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s177_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s177(a[0]);
}
Clo g_prelude_2efoldl_24s187_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s187_entry, 2, 0};

V g_prelude_2efoldl_24s187(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTermF_24s186(v_e2_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s187_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s187(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s188_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s188_entry, 2, 0};

V g_prelude_2efoldl_24s188(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTermF_24s186(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s188_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s188(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s189_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s189_entry, 2, 0};

V g_prelude_2efoldl_24s189(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_it2_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_it2_245)) {
      case TAG_MkPair: {
        V v_b_247 = heff_field(v_it2_245, 1);
        v_t_248 = (g_heff_2erename_2eglobalsTermF_24s186(v_b_247));
        break;
      }
      default: heff_nomatch(v_it2_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s189_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s189(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s191_entry, 2, 0};

V g_prelude_2efoldl_24s191(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_t2_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTypeF_24s190(v_t2_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s191_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s191(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s192_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s192_entry, 2, 0};

V g_prelude_2efoldl_24s192(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTypeF_24s190(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s192_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s192(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s193_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s193_entry, 2, 0};

V g_prelude_2efoldl_24s193(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_ts_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_ts_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s192(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s193_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s193(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efilter_24s197_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s197_entry, 1, 0};

V g_prelude_2efilter_24s197(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_x_241)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s197(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s197_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s197(a[0]);
}
Clo g_prelude_2efoldl_24s198_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s198_entry, 2, 0};

V g_prelude_2efoldl_24s198(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s198_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s198(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s200_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s200_entry, 2, 0};

V g_prelude_2emerge_24s200(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s200(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s200(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s200_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s200(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s199_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s199_entry, 1, 0};

V g_prelude_2esortBy_24s199(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s199(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s199(v_t_2411));
      return (g_prelude_2emerge_24s200(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s199_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s199(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s201_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s201_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s201_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s201_entry, 1, 0};

V g_prelude_2emap_24s201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_span), LBL_start);
    V v_t_244 = heff_get(heff_get(v_x_241, LBL_span), LBL_end);
    V v_t_245 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_prelude_2emap_24s201_str0), ((V)&g_prelude_2emap_24s201_str1), v_t_243, v_t_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s201(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s201_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s201(a[0]);
}
Clo g_prelude_2emerge_24s203_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s203_entry, 2, 0};

V g_prelude_2emerge_24s203(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s203(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s203(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s203_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s203(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s202_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s202_entry, 1, 0};

V g_prelude_2esortBy_24s202(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s202(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s202(v_t_2411));
      return (g_prelude_2emerge_24s203(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s202_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s202(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s204_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s204_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s204_entry, 1, 0};

V g_prelude_2emap_24s204(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_320_83_341_337_321_84, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), heff_tag(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_prelude_2emap_24s204_str0), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s204(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s204_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s204(a[0]);
}
Clo g_prelude_2emap_24s205_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s205_entry, 1, 0};

V g_prelude_2emap_24s205(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_320_83_341_337_321_84, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), NTAG(TAG_Nothing), heff_get(v_x_241, LBL_text), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s205(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s205_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s205(a[0]);
}
Clo g_prelude_2emap_24s226_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s226_entry, 1, 0};

V g_prelude_2emap_24s226(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s226(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s226_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s226(a[0]);
}
Clo g_prelude_2emap_24s228_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s228_entry, 1, 0};

V g_prelude_2emap_24s228(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esurface_2easNameE(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s228(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s228_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s228(a[0]);
}
Clo g_prelude_2emap_24s230_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s230_entry, 1, 0};

V g_prelude_2emap_24s230(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_EProject, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)});
    V v_t_244 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_243, v_t_244}), (g_prelude_2emap_24s230(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s230_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s230(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_prelude_2efoldl_24s233_str0 = {{0x80000000u, K_STR, 0}, 50, 50, {97, 32, 115, 112, 101, 99, 105, 97, 108, 105, 115, 97, 116, 105, 111, 110, 32, 115, 101, 116, 115, 32, 97, 32, 102, 105, 101, 108, 100, 32, 98, 121, 32, 105, 116, 115, 32, 110, 97, 109, 101, 58, 32, 96, 120, 32, 61, 32, 118, 96}};
Clo g_prelude_2efoldl_24s233_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s233_entry, 2, 0};

V g_prelude_2efoldl_24s233(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x_242, 0);
      V v_fsp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x21_244, 0);
        V v_v_248 = heff_field(v_x21_244, 2);
        heff_take_n(v_x21_244, 5ULL, 3);
        V v_a_2411;
        switch (heff_tag_of(v_z_240)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_z_240, 1));
          v_a_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_z_240);
        }
        V v_t_2412 = heff_rec(2, shape_320_83, (V[]){heff_get(v_a_2411, LBL_start), heff_get(heff_dup(v_fsp_245), LBL_end)});
        v_t_2414 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_ESpec, 4, (V[]){v_z_240, v_x_246, v_fsp_245, v_v_248}), v_t_2412});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_x21_244, 0ULL, 1);
        heff_drop(v_z_240);
        v_t_2414 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_EInvalid, 1, (V[]){((V)&g_prelude_2efoldl_24s233_str0)}), v_fsp_245});
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s233_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s233(a[0], a[1]);
}
Clo g_prelude_2emap_24s245_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s245_entry, 1, 0};

V g_prelude_2emap_24s245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s245(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s245_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s245(a[0]);
}
Clo g_prelude_2emap_24s246_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s246_entry, 1, 0};

V g_prelude_2emap_24s246(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_prelude_2emap_24s246(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s246_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s246(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_prelude_2emap_24s247_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {116, 104, 101, 32, 102, 105, 120, 105, 116, 121, 32, 111, 102, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_prelude_2emap_24s247_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {96, 32, 105, 115, 32, 100, 101, 99, 108, 97, 114, 101, 100, 32, 116, 119, 105, 99, 101}};
Clo g_prelude_2emap_24s247_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s247_entry, 1, 0};

V g_prelude_2emap_24s247(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s247_str0), heff_strAppend(heff_get(heff_dup(v_x_241), LBL_text), ((V)&g_prelude_2emap_24s247_str1)));
    V v_t_244 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    V v_t_245 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_243, v_t_244, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s247(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s247_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s247(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s248_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_prelude_2emap_24s248_str1 = {{0x80000000u, K_STR, 0}, 28, 28, {96, 32, 105, 115, 32, 115, 121, 110, 116, 97, 120, 44, 32, 110, 111, 116, 32, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114}};
Clo g_prelude_2emap_24s248_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s248_entry, 1, 0};

V g_prelude_2emap_24s248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s248_str0), heff_strAppend(heff_get(heff_dup(v_x_241), LBL_text), ((V)&g_prelude_2emap_24s248_str1)));
    V v_t_244 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    V v_t_245 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_243, v_t_244, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s248(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s248_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s248(a[0]);
}
Clo g_prelude_2efilter_24s249_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s249_entry, 1, 0};

V g_prelude_2efilter_24s249(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)}));
    V v_t_244 = ({ V a_0 = v_t_243; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s249(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s249_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s249(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s250_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_prelude_2emap_24s250_str1 = {{0x80000000u, K_STR, 0}, 54, 54, {96, 32, 104, 97, 115, 32, 110, 111, 32, 102, 105, 120, 105, 116, 121, 32, 116, 111, 32, 98, 101, 32, 97, 98, 111, 118, 101, 32, 111, 114, 32, 98, 101, 108, 111, 119, 58, 32, 100, 101, 99, 108, 97, 114, 101, 32, 105, 116, 32, 102, 105, 114, 115, 116}};
Clo g_prelude_2emap_24s250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s250_entry, 1, 0};

V g_prelude_2emap_24s250(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s250_str0), heff_strAppend(heff_get(heff_dup(v_x_241), LBL_text), ((V)&g_prelude_2emap_24s250_str1)));
    V v_t_244 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    V v_t_245 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_243, v_t_244, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s250(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s250(a[0]);
}
Clo g_prelude_2emap_24s251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s251_entry, 1, 0};

V g_prelude_2emap_24s251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ops);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_op_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      V v_t_246 = (g_prelude_2emap_24s246(heff_get(heff_dup(v_x_241), LBL_ops)));
      V v_t_247 = heff_rec(3, shape_130_15_218, (V[]){heff_get(v_op_244, LBL_text), heff_get(v_x_241, LBL_assoc), v_t_246});
      v_t_248 = heff_tag(TAG_Just, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s251(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s251(a[0]);
}
Clo g_prelude_2efilter_24s252_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s252_entry, 1, 0};

V g_prelude_2efilter_24s252(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(heff_dup(v_x_241), LBL_ops); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x1_244 = heff_intEq(v_t_243, MK_INT(0LL));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s252(v_xs_242))});
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s252_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s252(a[0]);
}
Clo g_prelude_2emap_24s271_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s271_entry, 1, 0};

V g_prelude_2emap_24s271(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end)});
    V v_t_244 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get(v_x_241, LBL_msg), v_t_243, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s271(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s271_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s271(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s290_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_prelude_2emap_24s290_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s290_entry, 1, 0};

V g_prelude_2emap_24s290(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_PVar, 1, (V[]){((V)&g_prelude_2emap_24s290_str0)}), (g_prelude_2emap_24s290(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s290_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s290(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s291_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_prelude_2efoldl_24s291_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s291_entry, 2, 0};

V g_prelude_2efoldl_24s291(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2418;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_v_244 = heff_field(v_x_242, 0);
      V v_p_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_p_245)) {
      case TAG_PVar: {
        V v_x_246 = heff_field(v_p_245, 0);
        V v_t_247 = heff_strEq(heff_dup(v_x_246), ((V)&g_prelude_2efoldl_24s291_str0));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          v_t_2418 = v_z_240;
          break;
        }
        case TAG_False: {
          V v_t_248 = heff_strEq(heff_dup(v_x_246), heff_dup(v_v_244));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            v_t_2418 = v_z_240;
            break;
          }
          case TAG_False: {
            V v_t_249 = (g_heff_2eclauses_2erenamer(heff_dup(v_x_246), heff_dup(v_v_244)));
            v_t_2418 = heff_tr(heff_apply(heff_get(v_t_249, LBL_chk), 1, (V[]){v_z_240}));
            break;
          }
          default: heff_nomatch(v_t_248);
          }
          break;
        }
        default: heff_nomatch(v_t_247);
        }
        break;
      }
      case TAG_PTag: {
        v_t_2418 = v_z_240;
        break;
      }
      case TAG_PLit: {
        v_t_2418 = v_z_240;
        break;
      }
      case TAG_PRec: {
        v_t_2418 = v_z_240;
        break;
      }
      case TAG_PAs: {
        v_t_2418 = v_z_240;
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s291_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s291(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s304_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s304_entry, 2, 0};

V g_prelude_2efoldl_24s304(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s194(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s304_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s304(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s389_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s389_entry, 2, 0};

V g_prelude_2efoldl_24s389(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_map_2einsert_24s194(heff_dup(v_l_246), heff_dup(v_i_244), v_z_240));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s389_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s389(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s414_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s414_entry, 2, 0};

V g_prelude_2efoldl_24s414(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_get(heff_dup(v_x_242), LBL_sol);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec(2, shape_198_314, (V[]){heff_get(heff_dup(v_x_242), LBL_name), heff_get(v_x_242, LBL_span)});
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s414_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s414(a[0], a[1]);
}
Clo g_prelude_2eany_24s415_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s415_entry, 1, 0};

V g_prelude_2eany_24s415(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s415_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s415(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s416_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s416_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_prelude_2emap_24s416_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s416_entry, 1, 0};

V g_prelude_2emap_24s416(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s416_str0), heff_strAppend(v_t_243, ((V)&g_prelude_2emap_24s416_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s416(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s416_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s416(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s417_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s417_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_prelude_2emap_24s417_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s417_entry, 1, 0};

V g_prelude_2emap_24s417(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intLt(heff_dup(v_x_241), MK_INT(0LL));
    V v_t_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_prelude_2emap_24s417_str0), heff_strAppend(v_t_244, ((V)&g_prelude_2emap_24s417_str1)));
      break;
    }
    case TAG_False: {
      v_t_245 = heff_intShow(v_x_241);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s417(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s417_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s417(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s421_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s421_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s421_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s421_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s421_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_prelude_2emap_24s421_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s421_entry, 1, 0};

V g_prelude_2emap_24s421(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_k_243 = heff_field(v_x_241, 0);
      V v_v_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2eprint_2eescFrom(v_k_243, MK_INT(0LL)));
      V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s421_str0), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s421_str1)));
      V v_t_247 = ({ V a_0 = v_v_244; V r_ = (g_heff_2eprint_2earmOf_24s419(a_0)); heff_drop(v_v_244); r_; });
      v_t_248 = heff_strAppend(((V)&g_prelude_2emap_24s421_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2emap_24s421_str3), heff_strAppend(v_t_247, ((V)&g_prelude_2emap_24s421_str4)))));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s421(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s421_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s421(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2emap_24s424_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s424_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s424_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_prelude_2emap_24s424_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s424_entry, 1, 0};

V g_prelude_2emap_24s424(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_k_243 = heff_field(v_x_241, 0);
      V v_v_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2eprint_2eescFrom(v_k_243, MK_INT(0LL)));
      V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s424_str0), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s424_str1)));
      V v_xs_247 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), heff_arrayToList(v_v_244)));
      V v_t_248 = ({ V a_0 = v_xs_247; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_247); r_; });
      V v_t_249 = heff_strAppend(((V)&g_prelude_2emap_24s424_str2), heff_strAppend(v_t_248, ((V)&g_prelude_2emap_24s424_str3)));
      V v_t_2410 = heff_strAppend(((V)&g_prelude_2emap_24s424_str4), heff_strAppend(v_t_249, ((V)&g_prelude_2emap_24s424_str5)));
      v_t_2411 = heff_strAppend(((V)&g_prelude_2emap_24s424_str6), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2emap_24s424_str7), heff_strAppend(v_t_2410, ((V)&g_prelude_2emap_24s424_str8)))));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s424(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s424_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s424(a[0]);
}
Clo g_prelude_2emap_24s426_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s426_entry, 1, 0};

V g_prelude_2emap_24s426(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_name), (g_prelude_2emap_24s426(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s426_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s426(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s430_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_prelude_2emap_24s430_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s430_entry, 1, 0};

V g_prelude_2emap_24s430(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_prelude_2emap_24s430_str0), (g_prelude_2emap_24s430(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s430_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s430(a[0]);
}
Clo g_prelude_2emap_24s431_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s431_entry, 1, 0};

V g_prelude_2emap_24s431(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s431(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s431_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s431(a[0]);
}
Clo g_prelude_2efoldl_24s471_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s471_entry, 2, 0};

V g_prelude_2efoldl_24s471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s471_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s471(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s472_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s472_entry, 2, 0};

V g_prelude_2efoldl_24s472(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s7(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_get(heff_dup(v_z_240), LBL_broken)));
    V v_t_245 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_z_240), LBL_order), heff_get(heff_dup(v_z_240), LBL_entries), heff_get(v_z_240, LBL_aliases), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s472_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s472(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s473_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s473_entry, 2, 0};

V g_prelude_2efoldl_24s473(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s473_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s473(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s475_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s475_entry, 1, 0};

V g_prelude_2emap_24s475(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_module), (g_prelude_2emap_24s475(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s475_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s475(a[0]);
}
Clo g_prelude_2efoldl_24s476_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s476_entry, 2, 0};

V g_prelude_2efoldl_24s476(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_l2_244 = heff_get(heff_dup(v_x_242), LBL_level);
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_l2_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_l2_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_l2_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_l2_244;
        break;
      }
      default: heff_nomatch(v_l2_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_l2_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_l2_244;
        break;
      }
      default: heff_nomatch(v_l2_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s476_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s476(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s477_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s477_entry, 1, 0};

V g_prelude_2emap_24s477(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_SGlobal, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_key)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_x_241, LBL_name), v_t_243});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s477(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s477_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s477(a[0]);
}
Clo g_prelude_2efoldl_24s478_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s478_entry, 2, 0};

V g_prelude_2efoldl_24s478(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_get(heff_dup(v_x_242), LBL_fixities);
    V v_t_245 = (g_heff_2efixity_2eappendF(heff_get(heff_dup(v_z_240), LBL_groups), heff_get(heff_dup(v_b_244), LBL_groups)));
    V v_t_246 = (g_heff_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2efixity_2eappendF(heff_get(v_z_240, LBL_above), heff_get(v_b_244, LBL_above)));
    V v_t_248 = (g_heff_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec(2, shape_119_0, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s478_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s478(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s479_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s479_entry, 1, 0};

V g_prelude_2emap_24s479(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2ehint(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s479(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s479_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s479(a[0]);
}
Clo g_prelude_2efoldl_24s481_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s481_entry, 2, 0};

V g_prelude_2efoldl_24s481(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_imps_244 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2emap_24s426(heff_get(heff_dup(v_imps_244), LBL_imports)));
    V v_ms_246 = (g_heff_2edriver_2enubStrD(v_t_245));
    V v_t_247 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_ms_246));
    V v_t_248 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_imps_244; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_247; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_247); r_; });
    V v_t_249 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = (g_heff_2edriver_2eappendD(v_z_240, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s481_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s481(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s482_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_prelude_2emap_24s482_lam0(V self, V *args); static Clo g_prelude_2emap_24s482_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s482_lam0, 1, 0};
Clo g_prelude_2emap_24s482_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s482_entry, 1, 0};

V g_prelude_2emap_24s482(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec(5, shape_314_198_152_188_351, (V[]){heff_get(heff_dup(v_x_241), LBL_span), heff_get(heff_dup(v_x_241), LBL_name), heff_get(heff_dup(v_x_241), LBL_key), heff_get(v_x_241, LBL_member), ((V)&g_prelude_2emap_24s482_lam0_clo)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s482(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s482_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s482(a[0]);
}
V g_prelude_2emap_24s482_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_prelude_2emap_24s482_str0);
}
Clo g_prelude_2efoldl_24s483_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s483_entry, 2, 0};

V g_prelude_2efoldl_24s483(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_imps_244 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2emap_24s426(heff_get(heff_dup(v_imps_244), LBL_imports)));
    V v_ms_246 = (g_heff_2edriver_2enubStrD(v_t_245));
    V v_t_247 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_ms_246));
    V v_t_248 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_imps_244; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_247; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_heff_2edriver_2elean(v_t_248));
    V v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s483_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s483(a[0], a[1]);
}
Clo g_prelude_2emap_24s484_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s484_entry, 1, 0};

V g_prelude_2emap_24s484(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_key), (g_prelude_2emap_24s484(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s484_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s484(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s485_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {101, 114, 114, 111, 114, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s485_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 58, 32}};
Clo g_prelude_2emap_24s485_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s485_entry, 1, 0};

V g_prelude_2emap_24s485(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intShow(heff_get(heff_dup(v_x_241), LBL_code));
    V v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s485_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_prelude_2emap_24s485_str1), heff_get(v_x_241, LBL_msg))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s485(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s485_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s485(a[0]);
}
Clo g_prelude_2efoldl_24s486_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s486_entry, 2, 0};

V g_prelude_2efoldl_24s486(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_y_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_x_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s7(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s486_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s486(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s487_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s487_entry, 1, 0};

V g_prelude_2emap_24s487(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_t_245, LBL_start), (g_prelude_2emap_24s487(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s487_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s487(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s488_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s488_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s488_entry, 1, 0};

V g_prelude_2emap_24s488(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s488_str0)), (g_prelude_2emap_24s488(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s488_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s488(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s489_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 45, 32}};
Clo g_prelude_2emap_24s489_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s489_entry, 1, 0};

V g_prelude_2emap_24s489(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_prelude_2emap_24s489_str0), v_x_241), (g_prelude_2emap_24s489(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s489_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s489(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s490_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2efoldl_24s490_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s490_entry, 2, 0};

V g_prelude_2efoldl_24s490(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_prelude_2efoldl_24s490_str0), heff_get(heff_dup(v_x_242), LBL_value), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_245 = (g_prelude_2emap_24s489(v_t_244));
    V v_t_246 = (g_heff_2edriver_2epromoteAt(v_z_240, heff_get(heff_dup(v_x_242), LBL_expectFrom), heff_get(heff_dup(v_x_242), LBL_expectTo), v_t_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s490_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s490(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s491_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s491_entry, 1, 0};

V g_prelude_2emap_24s491(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s491(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s491_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s491(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s492_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s492_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s492_entry, 1, 0};

V g_prelude_2emap_24s492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str4);
      break;
    }
    case TAG_VStr: {
      V v_s_249 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2411 = v_s_249;
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str5);
      break;
    }
    case TAG_VErased: {
      v_t_2411 = ((V)&g_prelude_2emap_24s492_str6);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s492(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s492_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s492(a[0]);
}
Clo g_prelude_2emap_24s493_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s493_entry, 1, 0};

V g_prelude_2emap_24s493(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s493(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s493_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s493(a[0]);
}
Clo g_prelude_2efilter_24s495_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s495_entry, 1, 0};

V g_prelude_2efilter_24s495(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_severity);
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s495(v_xs_242))});
    }
    case TAG_SWarning: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s495_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s495(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_prelude_2emap_24s498_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s498_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s498_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s498_entry, 1, 0};

V g_prelude_2emap_24s498(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s498_str0), heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s498_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s498(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s498_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s498(a[0]);
}
Clo g_prelude_2efilter_24s499_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s499_entry, 1, 0};

V g_prelude_2efilter_24s499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_dup(v_x_241), heff_dup(g_heff_2eimport_2ebuiltinModule_get()));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s499(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s499_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s499(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_prelude_2emap_24s500_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s500_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 97, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s500_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s500_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s500_entry, 1, 0};

V g_prelude_2emap_24s500(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s500_str0), heff_strAppend(heff_get(heff_dup(v_x_241), LBL_module), heff_strAppend(((V)&g_prelude_2emap_24s500_str1), heff_strAppend(heff_get(v_x_241, LBL_alias), ((V)&g_prelude_2emap_24s500_str2)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s500(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s500_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s500(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efilter_24s501_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2efilter_24s501_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s501_entry, 1, 0};

V g_prelude_2efilter_24s501(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_dup(v_x_241), ((V)&g_prelude_2efilter_24s501_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s501(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s501_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s501(a[0]);
}
Clo g_prelude_2efoldl_24s502_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s502_entry, 2, 0};

V g_prelude_2efoldl_24s502(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eglueOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s502_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s502(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s503_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s503_entry, 2, 0};

V g_prelude_2efoldl_24s503(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s503_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s503(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s511_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s511_entry, 1, 0};

V g_prelude_2emap_24s511(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_e2_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_e2_244; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_e2_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s511(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s511_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s511(a[0]);
}
Clo g_prelude_2emap_24s512_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s512_entry, 1, 0};

V g_prelude_2emap_24s512(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s512(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s512_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s512(a[0]);
}
Clo g_prelude_2emap_24s513_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s513_entry, 1, 0};

V g_prelude_2emap_24s513(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s513(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s513_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s513(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s514_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
Clo g_prelude_2efoldl_24s514_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s514_entry, 2, 0};

V g_prelude_2efoldl_24s514(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s514_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s514_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s514(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s515_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s515_entry, 1, 0};

V g_prelude_2emap_24s515(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s515(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s515_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s515(a[0]);
}
Clo g_prelude_2efoldl_24s516_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s516_entry, 2, 0};

V g_prelude_2efoldl_24s516(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2esimplify_2eflat(heff_get(heff_dup(v_x_242), LBL_body)));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_get(heff_dup(v_x_242), LBL_key); V a_2 = v_t_244; V r_ = (g_heff_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s516_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s516(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s517_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s517_entry, 1, 0};

V g_prelude_2emap_24s517(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, (g_prelude_2emap_24s517(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s517_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s517(a[0]);
}
Clo g_prelude_2emap_24s518_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s518_entry, 1, 0};

V g_prelude_2emap_24s518(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, (g_prelude_2emap_24s518(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s518_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s518(a[0]);
}
Clo g_prelude_2efoldl_24s519_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s519_entry, 2, 0};

V g_prelude_2efoldl_24s519(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_y_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s7(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s519_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s519(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s520_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s520_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_prelude_2efoldl_24s520_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s520_entry, 2, 0};

V g_prelude_2efoldl_24s520(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 2ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_z_240)) {
    case TAG_MkPair: {
      V v_xs_244 = heff_field(v_z_240, 0);
      V v_n_245 = heff_field(v_z_240, 1);
      heff_take_n(v_z_240, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2efoldl_24s520_str0), heff_strAppend(((V)&g_prelude_2efoldl_24s520_str1), heff_intShow(heff_dup(v_n_245))));
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_xs_244}), heff_intAdd(v_n_245, MK_INT(1LL))});
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s520_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s520(a[0], a[1]);
}
Clo g_prelude_2emap_24s521_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s521_entry, 1, 0};

V g_prelude_2emap_24s521(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_x_241}), (g_prelude_2emap_24s521(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s521_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s521(a[0]);
}
Clo g_prelude_2emap_24s522_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s522_entry, 1, 0};

V g_prelude_2emap_24s522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), (g_prelude_2emap_24s522(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s522_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s522(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s523_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_prelude_2ezipWith_24s523_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s523_entry, 2, 0};

V g_prelude_2ezipWith_24s523(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246;
      switch (heff_tag_of(v_x_242)) {
      case TAG_True: {
        v_t_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_y_244; V r_ = (g_heff_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_y_244); r_; });
        break;
      }
      case TAG_False: {
        heff_drop(v_y_244);
        v_t_246 = ((V)&g_prelude_2ezipWith_24s523_str0);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s523(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s523_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s523(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s524_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s524_entry, 2, 0};

V g_prelude_2efoldl_24s524(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_intLe(heff_dup(v_z_240), heff_dup(v_x_242));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = v_z_240;
      break;
    }
    case TAG_False: {
      heff_drop(v_z_240);
      v_t_245 = heff_dup(v_x_242);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s524_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s524(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eany_24s525_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s525_entry, 1, 0};

V g_prelude_2eany_24s525(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s525_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s525(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2eany_24s526_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s526_entry, 1, 0};

V g_prelude_2eany_24s526(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_x13_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_x13_245)) {
      case TAG_EVar: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2432 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x13_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s526_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s526(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2ezipWith_24s530_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s530_entry, 2, 0};

V g_prelude_2ezipWith_24s530(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_x_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), (g_prelude_2ezipWith_24s530(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s530_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s530(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s533_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s533_entry, 2, 0};

V g_prelude_2efoldl_24s533(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_dup(v_x_242), LBL_body);
    V v_t_2432;
    switch (heff_tag_of(v_t_244)) {
    case TAG_EVar: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_247); r_; });
      v_t_2432 = (g_map_2einsert_24s7(heff_get(heff_dup(v_x_242), LBL_key), v_t_249, v_z_240));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2432;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s533_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s533(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2ezipWith_24s544_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s544_entry, 2, 0};

V g_prelude_2ezipWith_24s544(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_t_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_t_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_vs_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_vs_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), (g_prelude_2ezipWith_24s544(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s544_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s544(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s568_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s568_entry, 2, 0};

V g_prelude_2efoldl_24s568(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2elift_2eliftGo_24s545(heff_dup(v_x_242), heff_get(heff_dup(v_x_242), LBL_body)));
    V v_t_248;
    switch (heff_tag_of(v_t_244)) {
    case TAG_MkPair: {
      V v_b_245 = heff_field(v_t_244, 0);
      V v_acc_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      V v_t_247 = heff_rec(3, shape_152_198_28, (V[]){heff_get(heff_dup(v_x_242), LBL_key), heff_get(v_x_242, LBL_name), v_b_245});
      v_t_248 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_acc_246, LBL_out)))});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s568_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s568(a[0], a[1]);
}
Clo g_prelude_2econcatMap_24s567_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2econcatMap_24s567_entry, 1, 0};

V g_prelude_2econcatMap_24s567(V v_xs_240) {
top: ;
  V v_t_241 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_240));
  return (g_prelude_2efoldl_24s568(NTAG(TAG_Nil), v_t_241));
}
V g_prelude_2econcatMap_24s567_entry(V self, V *a) {
  (void)self;
  return g_prelude_2econcatMap_24s567(a[0]);
}
Clo g_prelude_2efoldl_24s569_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s569_entry, 2, 0};

V g_prelude_2efoldl_24s569(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s7(heff_get(heff_dup(v_x_242), LBL_key), heff_get(heff_dup(v_x_242), LBL_body), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s569_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s569(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s570_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s570_entry, 2, 0};

V g_prelude_2efoldl_24s570(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemit_2evalueRefs(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s570_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s570(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s571_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s571_entry, 2, 0};

V g_prelude_2efoldl_24s571(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eemit_2evalueRefs(v_e2_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s571_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s571(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s572_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s572_entry, 2, 0};

V g_prelude_2efoldl_24s572(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_b_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eemit_2evalueRefs(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s572_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s572(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eany_24s573_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s573_entry, 1, 0};

V g_prelude_2eany_24s573(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_b_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eemit_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s573_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s573(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2efoldl_24s574_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s574_entry, 2, 0};

V g_prelude_2efoldl_24s574(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_b_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2eemit_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s574_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s574(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s575_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s575_entry, 2, 0};

V g_prelude_2efoldl_24s575(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_r_244 = (g_heff_2eemit_2ebindName(heff_get(heff_dup(v_z_240), LBL_env), v_x_242));
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_r_244), LBL_js), NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2econcatList(heff_get(v_z_240, LBL_js), v_t_245));
    V v_t_247 = heff_rec(2, shape_150_87, (V[]){v_t_246, heff_get(v_r_244, LBL_env)});
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s575_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s575(a[0], a[1]);
}
Clo g_prelude_2emap_24s576_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s576_entry, 1, 0};

V g_prelude_2emap_24s576(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_code), (g_prelude_2emap_24s576(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s576_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s576(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s577_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s577_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 61, 62, 32}};
Clo g_prelude_2emap_24s577_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s577_entry, 1, 0};

V g_prelude_2emap_24s577(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s577_str0), heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s577_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s577(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s577_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s577(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s579_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_prelude_2emap_24s579_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s579_entry, 1, 0};

V g_prelude_2emap_24s579(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s579_str0)), (g_prelude_2emap_24s579(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s579_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s579(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2ezipWith_24s580_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
Clo g_prelude_2ezipWith_24s580_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s580_entry, 2, 0};

V g_prelude_2ezipWith_24s580(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_prelude_2ezipWith_24s580_str0), v_y_244));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s580(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s580_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s580(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s602_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s602_entry, 2, 0};

V g_prelude_2efoldl_24s602(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_y_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = ({ V a_0 = v_z_240; V a_1 = v_t_246; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_246); r_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s602_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s602(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s603_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s603_entry, 2, 0};

V g_prelude_2efoldl_24s603(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_b_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_247); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s603_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s603(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s604_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s604_entry, 2, 0};

V g_prelude_2efoldl_24s604(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V a_0 = v_z_240; V b_1 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2eprimUses(a_0, b_1)); heff_drop(b_1); r_; });
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s604_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s604(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s605_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s605_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s605_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s605_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_prelude_2emap_24s605_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s605_entry, 1, 0};

V g_prelude_2emap_24s605(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_k_243 = heff_get(v_x_241, LBL_key);
    V v_xs_244 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s605_str0), heff_dup(v_k_243), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
    V v_x2_248;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nil: {
      v_x2_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 2);
      v_x2_248 = heff_tag(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    V v_x0_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      v_x0_2410 = v_k_243;
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      heff_drop(v_k_243);
      v_x0_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_x0_2410)), MK_INT(1LL));
    V v_t_2412 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_x0_2410), v_t_2411));
    V v_t_2413 = (g_heff_2eemit_2espellAt(v_x0_2410, v_t_2412));
    V v_s_2414 = (g_heff_2eemit_2esafeChars(v_t_2413, MK_INT(0LL), ((V)&g_prelude_2emap_24s605_str1)));
    V v_t_2415 = heff_strEq(heff_dup(v_s_2414), ((V)&g_prelude_2emap_24s605_str2));
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop(v_s_2414);
      v_t_2416 = ((V)&g_prelude_2emap_24s605_str3);
      break;
    }
    case TAG_False: {
      v_t_2416 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = (g_heff_2eemit_2esafeRes(v_t_2416));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, (g_prelude_2emap_24s605(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s605_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s605(a[0]);
}
Clo g_prelude_2efoldl_24s606_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s606_entry, 2, 0};

V g_prelude_2efoldl_24s606(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s7(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s606_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s606(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s607_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s607_entry, 2, 0};

V g_prelude_2efoldl_24s607(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2evalueRefs(b_0)); heff_drop(b_0); r_; });
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s607_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s607(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efilter_24s608_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_prelude_2efilter_24s608_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s608_entry, 1, 0};

V g_prelude_2efilter_24s608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(1LL)), ((V)&g_prelude_2efilter_24s608_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s608(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s608_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s608(a[0]);
}
Clo g_prelude_2emap_24s609_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s609_entry, 1, 0};

V g_prelude_2emap_24s609(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2eexportNameOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s609(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s609_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s609(a[0]);
}
Clo g_prelude_2emap_24s610_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s610_entry, 1, 0};

V g_prelude_2emap_24s610(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2ehostLineOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s610(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s610_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s610(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_prelude_2emap_24s611_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s611_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
Clo g_prelude_2emap_24s611_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s611_entry, 1, 0};

V g_prelude_2emap_24s611(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_prelude_2emap_24s611_str0));
    V v_t_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_strSlice(heff_dup(v_x_241), MK_INT(13LL), heff_strLength(v_x_241));
      v_t_245 = heff_strAppend(((V)&g_prelude_2emap_24s611_str1), v_t_244);
      break;
    }
    case TAG_False: {
      v_t_245 = v_x_241;
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s611(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s611_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s611(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_prelude_2efilter_24s612_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
Clo g_prelude_2efilter_24s612_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s612_entry, 1, 0};

V g_prelude_2efilter_24s612(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(7LL)), ((V)&g_prelude_2efilter_24s612_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s612(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s612_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s612(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s613_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s613_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s613_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s613_entry, 1, 0};

V g_prelude_2emap_24s613(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s613_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_244 = (g_heff_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_prelude_2emap_24s613_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2emap_24s613(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s613_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s613(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_prelude_2efilter_24s614_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
Clo g_prelude_2efilter_24s614_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s614_entry, 1, 0};

V g_prelude_2efilter_24s614(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(7LL)), ((V)&g_prelude_2efilter_24s614_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s614(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s614_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s614(a[0]);
}
Clo g_prelude_2eany_24s615_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s615_entry, 1, 0};

V g_prelude_2eany_24s615(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strEq(heff_dup(v_x_241), heff_dup(g_heff_2eemit_2etrampolineStr_get()));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s615_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s615(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s616_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s616_entry, 1, 0};

V g_prelude_2emap_24s616(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_k_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec(2, shape_198_152, (V[]){heff_dup(v_k_243), v_k_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s616(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s616_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s616(a[0]);
}
Clo g_prelude_2emap_24s617_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s617_entry, 1, 0};

V g_prelude_2emap_24s617(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s617(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s617_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s617(a[0]);
}
Clo g_prelude_2emap_24s618_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s618_entry, 1, 0};

V g_prelude_2emap_24s618(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s618(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s618_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s618(a[0]);
}
Clo g_prelude_2efoldl_24s619_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s619_entry, 2, 0};

V g_prelude_2efoldl_24s619(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_x1_244 = (g_heff_2eemitc_2etagsLbls(v_x_242));
    V v_t_2410;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_ts_245 = heff_field(v_x1_244, 0);
      V v_ls_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_ts2_247 = heff_field(v_z_240, 0);
        V v_ls2_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2econcatList(v_ts_245, v_ts2_247));
        v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, (g_prelude_2econcatList(v_ls_246, v_ls2_248))});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s619_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s619(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s620_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s620_entry, 2, 0};

V g_prelude_2efoldl_24s620(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_vs_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_vs_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s620_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s620(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s621_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s621_entry, 2, 0};

V g_prelude_2efoldl_24s621(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s621_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s621(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s622_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s622_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_prelude_2emap_24s622_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s622_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_prelude_2emap_24s622_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s622_entry, 1, 0};

V g_prelude_2emap_24s622(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s622_str0), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2emap_24s622_str1))));
    V v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s622_str2), heff_strAppend(v_t_243, ((V)&g_prelude_2emap_24s622_str3)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s622(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s622_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s622(a[0]);
}
Clo g_prelude_2eall_24s623_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s623_entry, 1, 0};

V g_prelude_2eall_24s623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_pre);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_get(heff_dup(v_x_241), LBL_post);
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_243, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eall_24s623_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s623(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s624_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s624_entry, 1, 0};

V g_prelude_2emap_24s624(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_arg), (g_prelude_2emap_24s624(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s624_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s624(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s625_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s625_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2ezipWith_24s625_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s625_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2ezipWith_24s625_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s625_entry, 2, 0};

V g_prelude_2ezipWith_24s625(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_get(heff_dup(v_x_242), LBL_pre);
      V v_t_2412;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V v_t_247 = heff_strAppend(((V)&g_prelude_2ezipWith_24s625_str0), heff_intShow(heff_dup(v_y_244)));
        V v_t_248 = heff_strAppend(((V)&g_prelude_2ezipWith_24s625_str1), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_prelude_2ezipWith_24s625_str2), heff_strAppend(heff_get(heff_dup(v_x_242), LBL_arg), ((V)&g_prelude_2ezipWith_24s625_str3)))));
        V v_t_249 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        v_t_2412 = heff_rec(3, shape_12_251_249, (V[]){v_t_247, v_t_249, heff_get(v_x_242, LBL_post)});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        heff_drop_cell(v_ru_24xs_240_24Cons, 2);
        heff_drop(v_y_244);
        v_t_2412 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2ezipWith_24s625(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s625_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s625(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s626_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s626_entry, 2, 0};

V g_prelude_2efoldl_24s626(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_pre), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s626_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s626(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s627_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s627_entry, 2, 0};

V g_prelude_2efoldl_24s627(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_post), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s627_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s627(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s628_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s628_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s628_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2ezipWith_24s628_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 61, 32, 97, 114, 103, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s628_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 59}};
Clo g_prelude_2ezipWith_24s628_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s628_entry, 2, 0};

V g_prelude_2ezipWith_24s628(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2ezipWith_24s628_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2ezipWith_24s628_str1))));
      V v_t_247 = heff_strAppend(((V)&g_prelude_2ezipWith_24s628_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2ezipWith_24s628_str3), heff_strAppend(heff_intShow(v_y_244), ((V)&g_prelude_2ezipWith_24s628_str4)))));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith_24s628(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s628_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s628(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s629_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s629_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s629_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_prelude_2ezipWith_24s629_str3 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 61, 32, 104, 101, 102, 102, 95, 101, 110, 118, 40, 115, 101, 108, 102, 41, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s629_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 59}};
Clo g_prelude_2ezipWith_24s629_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s629_entry, 2, 0};

V g_prelude_2ezipWith_24s629(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2ezipWith_24s629_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2ezipWith_24s629_str1))));
      V v_t_247 = heff_strAppend(((V)&g_prelude_2ezipWith_24s629_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2ezipWith_24s629_str3), heff_strAppend(heff_intShow(v_y_244), ((V)&g_prelude_2ezipWith_24s629_str4)))));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith_24s629(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s629_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s629(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s630_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2ezipWith_24s630_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s630_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2ezipWith_24s630_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s630_entry, 2, 0};

V g_prelude_2ezipWith_24s630(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2ezipWith_24s630_str0), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_prelude_2ezipWith_24s630_str1), heff_strAppend(v_x_242, ((V)&g_prelude_2ezipWith_24s630_str2)))));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s630(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s630_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s630(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s631_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s631_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2ezipWith_24s631_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 61, 32, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s631_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2ezipWith_24s631_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s631_entry, 2, 0};

V g_prelude_2ezipWith_24s631(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2ezipWith_24s631_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2ezipWith_24s631_str1))));
      V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2ezipWith_24s631_str2), heff_strAppend(heff_intShow(v_y_244), ((V)&g_prelude_2ezipWith_24s631_str3))));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith_24s631(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s631_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s631(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2ezipWith_24s632_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 114, 103, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s632_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {93, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s632_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2ezipWith_24s632_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s632_entry, 2, 0};

V g_prelude_2ezipWith_24s632(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_prelude_2ezipWith_24s632_str0), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_prelude_2ezipWith_24s632_str1), heff_strAppend(v_x_242, ((V)&g_prelude_2ezipWith_24s632_str2)))));
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s632(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s632_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s632(a[0], a[1]);
}
Clo g_prelude_2eany_24s633_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s633_entry, 1, 0};

V g_prelude_2eany_24s633(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s633_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s633(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2ezipWith_24s634_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s634_entry, 2, 0};

V g_prelude_2ezipWith_24s634(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_prelude_2ezipWith_24s634(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s634_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s634(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s635_entry, 2, 0};

V g_prelude_2efoldl_24s635(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s635_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s635(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s636_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s636_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s636_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s636_entry, 1, 0};

V g_prelude_2emap_24s636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s636_str0), heff_strAppend(((V)&g_prelude_2emap_24s636_str1), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2emap_24s636_str2)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s636(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s636(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s637_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s637_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
Clo g_prelude_2emap_24s637_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s637_entry, 1, 0};

V g_prelude_2emap_24s637(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s637_str0), heff_strAppend(heff_intShow(v_x_241), ((V)&g_prelude_2emap_24s637_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s637(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s637_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s637(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2emap_24s638_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s638_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 41, 59}};
Clo g_prelude_2emap_24s638_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s638_entry, 1, 0};

V g_prelude_2emap_24s638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s638_str0), heff_strAppend(heff_intShow(v_x_241), ((V)&g_prelude_2emap_24s638_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s638(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s638_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s638(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s653_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s653_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_prelude_2emap_24s653_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s653_entry, 1, 0};

V g_prelude_2emap_24s653(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s653_str0), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s653_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s653(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s653_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s653(a[0]);
}
Clo g_prelude_2emerge_24s655_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s655_entry, 2, 0};

V g_prelude_2emerge_24s655(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_y_247 = heff_dup(heff_field(v_x_242, 1));
        v_t_248 = v_y_247;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2411;
      switch (heff_tag_of(v_y_244)) {
      case TAG_MkPair: {
        V v_y_2410 = heff_dup(heff_field(v_y_244, 1));
        v_t_2411 = v_y_2410;
        break;
      }
      default: heff_nomatch(v_y_244);
      }
      V v_t_2412 = heff_intLe(v_t_248, v_t_2411);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s655(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s655(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s655_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s655(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s654_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s654_entry, 1, 0};

V g_prelude_2esortBy_24s654(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s654(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s654(v_t_2411));
      return (g_prelude_2emerge_24s655(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s654_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s654(a[0]);
}
Clo g_prelude_2eany_24s656_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s656_entry, 1, 0};

V g_prelude_2eany_24s656(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      V v_x1_248;
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_244));
        v_t_2410 = (g_heff_2eemitc_2ebuildsSize(v_t_249, heff_dup(v_b_245)));
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s656_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s656(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s657_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s657_entry, 1, 0};

V g_prelude_2emap_24s657(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_xs_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_xs_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_245); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s657(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s657_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s657(a[0]);
}
Clo g_prelude_2efoldl_24s658_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s658_entry, 2, 0};

V g_prelude_2efoldl_24s658(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s658_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s658(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s659_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s659_entry, 2, 0};

V g_prelude_2efoldl_24s659(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s659_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s659(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s660_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s660_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s660_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s660_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s660_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s660_entry, 1, 0};

V g_prelude_2emap_24s660(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s660_str0), (g_heff_2eemitc_2emangleW(v_t_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2emap_24s660_str1))));
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410 = heff_strAppend(((V)&g_prelude_2emap_24s660_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2emap_24s660_str3), heff_intShow(v_t_249))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s660(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s660_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s660(a[0]);
}
Clo g_prelude_2efilter_24s661_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s661_entry, 1, 0};

V g_prelude_2efilter_24s661(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_246)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s661(v_xs_242))});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s661_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s661(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s662_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s662_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s662_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s662_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s662_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s662_entry, 1, 0};

V g_prelude_2emap_24s662(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_dup(heff_field(v_x_241, 0));
      v_l_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s662_str0), (g_heff_2eemitc_2emangleW(v_l_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2emap_24s662_str1))));
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410 = heff_strAppend(((V)&g_prelude_2emap_24s662_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2emap_24s662_str3), heff_intShow(v_t_249))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s662(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s662_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s662(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s663_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s663_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_prelude_2emap_24s663_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 117, 105, 110, 116, 51, 50, 95, 116, 32, 115, 104, 97, 112, 101, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s663_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s663_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
Clo g_prelude_2emap_24s663_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s663_entry, 1, 0};

V g_prelude_2emap_24s663(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s663_str0), heff_dup(v_x_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_prelude_2emap_24s663_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strAppend(((V)&g_prelude_2emap_24s663_str2), heff_strAppend(v_x_241, heff_strAppend(((V)&g_prelude_2emap_24s663_str3), heff_strAppend(v_t_246, ((V)&g_prelude_2emap_24s663_str4)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2emap_24s663(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s663_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s663(a[0]);
}
Clo g_prelude_2efoldl_24s664_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s664_entry, 2, 0};

V g_prelude_2efoldl_24s664(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_protos), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s664_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s664(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s665_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s665_entry, 2, 0};

V g_prelude_2efoldl_24s665(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s665_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s665(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s666_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s666_entry, 2, 0};

V g_prelude_2efoldl_24s666(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_code), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s666_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s666(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s667_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s667_entry, 2, 0};

V g_prelude_2efoldl_24s667(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_dup(v_x_242), LBL_body);
    V v_t_2432;
    switch (heff_tag_of(v_t_244)) {
    case TAG_EVar: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_247); r_; });
      v_t_2432 = (g_map_2einsert_24s7(heff_get(heff_dup(v_x_242), LBL_key), v_t_249, v_z_240));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = v_z_240;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2432 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2432;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s667_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s667(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2efoldl_24s668_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
Clo g_prelude_2efoldl_24s668_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s668_entry, 2, 0};

V g_prelude_2efoldl_24s668(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2enamesInGo(((V)&g_prelude_2efoldl_24s668_str0), heff_get(heff_dup(v_x_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s668_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s668(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2efoldl_24s669_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
Clo g_prelude_2efoldl_24s669_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s669_entry, 2, 0};

V g_prelude_2efoldl_24s669(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2enamesInGo(((V)&g_prelude_2efoldl_24s669_str0), heff_get(heff_dup(v_x_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s669_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s669(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_prelude_2emap_24s670_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s670_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_prelude_2emap_24s670_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {101, 120, 116, 101, 114, 110, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s670_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2emap_24s670_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s670_entry, 1, 0};

V g_prelude_2emap_24s670(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_prelude_2emap_24s670_str0));
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = (g_prelude_2eindexFrom(((V)&g_prelude_2emap_24s670_str1), heff_dup(v_x_241), MK_INT(0LL)));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_t_246 = v_x_241;
        break;
      }
      case TAG_Just: {
        V v_at_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s670_str2), heff_strAppend(heff_strSlice(v_x_241, MK_INT(11LL), v_at_245), ((V)&g_prelude_2emap_24s670_str3)));
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      break;
    }
    case TAG_False: {
      v_t_246 = (g_heff_2eemitc_2epubLine(v_x_241));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s670(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s670_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s670(a[0]);
}
Clo g_prelude_2efoldl_24s671_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s671_entry, 2, 0};

V g_prelude_2efoldl_24s671(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x2_2413 = (g_map_2elookup_24s8(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      heff_take_n(v_x2_2413, 1ULL, 1);
      v_t_2415 = v_x_2414;
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s7(v_t_246, heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s671_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s671(a[0], a[1]);
}
Clo g_prelude_2emap_24s672_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s672_entry, 1, 0};

V g_prelude_2emap_24s672(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2epubLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s672(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s672_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s672(a[0]);
}
Clo g_prelude_2emap_24s673_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s673_entry, 1, 0};

V g_prelude_2emap_24s673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strSlice(heff_dup(v_x_241), MK_INT(7LL), heff_strLength(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s673(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s673_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s673(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_prelude_2efilter_24s674_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 103, 95}};
Clo g_prelude_2efilter_24s674_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s674_entry, 1, 0};

V g_prelude_2efilter_24s674(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_prelude_2efilter_24s674_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s674(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s674_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s674(a[0]);
}
Clo g_prelude_2efoldl_24s675_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s675_entry, 2, 0};

V g_prelude_2efoldl_24s675(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_k_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_d_244 = heff_dup(heff_field(v_x_242, 0));
      v_k_246 = heff_get(v_d_244, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_at_247 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_k_246), MK_INT(0LL), MK_INT(-1LL)));
    V v_t_248 = heff_intLt(heff_dup(v_at_247), MK_INT(0LL));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_at_247);
      v_t_249 = v_k_246;
      break;
    }
    case TAG_False: {
      v_t_249 = heff_strSlice(v_k_246, MK_INT(0LL), v_at_247);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_k_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_d_2410 = heff_dup(heff_field(v_x_242, 0));
      v_k_2412 = heff_get(v_d_2410, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_at_2413 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_k_2412), MK_INT(0LL), MK_INT(-1LL)));
    V v_t_2414 = heff_intLt(heff_dup(v_at_2413), MK_INT(0LL));
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      heff_drop(v_at_2413);
      v_t_2415 = v_k_2412;
      break;
    }
    case TAG_False: {
      v_t_2415 = heff_strSlice(v_k_2412, MK_INT(0LL), v_at_2413);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_x2_2416 = (g_map_2elookup_24s8(v_t_2415, v_z_240));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2419 = (g_map_2einsert_24s7(v_t_249, heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_t_2418}), v_z_240));
    V t_0 = v_t_2419;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s675_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s675(a[0], a[1]);
}
Clo g_prelude_2emap_24s676_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s676_entry, 1, 0};

V g_prelude_2emap_24s676(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_body), (g_prelude_2emap_24s676(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s676_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s676(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_prelude_2emap_24s677_str0 = {{0x80000000u, K_STR, 0}, 23, 23, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95}};
Clo g_prelude_2emap_24s677_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s677_entry, 1, 0};

V g_prelude_2emap_24s677(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(23LL)), ((V)&g_prelude_2emap_24s677_str0));
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      v_t_244 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eemitc_2eidentAt(v_x_241, MK_INT(23LL), MK_INT(23LL)))});
      break;
    }
    case TAG_False: {
      heff_drop(v_x_241);
      v_t_244 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s677(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s677_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s677(a[0]);
}
Clo g_prelude_2efoldl_24s678_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s678_entry, 2, 0};

V g_prelude_2efoldl_24s678(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s678_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s678(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s679_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s679_entry, 2, 0};

V g_prelude_2efoldl_24s679(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2edoc_2e_3c_3e(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s679_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s679(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s680_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s680_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s680_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s680_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s680_entry, 1, 0};

V g_prelude_2emap_24s680(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s680_str0), heff_get(v_x_241, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_prelude_2emap_24s680_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s678(a_0, a_1)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_prelude_2emap_24s680_str2));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s680(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s680_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s680(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s681_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s681_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s681_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s681_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s681_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s681_entry, 1, 0};

V g_prelude_2emap_24s681(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s681_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_prelude_2emap_24s681_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s678(a_0, a_1)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_prelude_2emap_24s681_str2));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_248, heff_tag(TAG_Text, 1, (V[]){((V)&g_prelude_2emap_24s681_str3)})));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s681(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s681_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s681(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2eany_24s690_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {45, 45, 32, 102, 109, 116, 58, 32, 115, 107, 105, 112}};
Clo g_prelude_2eany_24s690_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s690_entry, 1, 0};

V g_prelude_2eany_24s690(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_get(heff_dup(v_x_241), LBL_text);
    V v_t_244 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength(heff_dup(v_s_243))));
    V v_t_245 = heff_strEq(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_prelude_2eany_24s690_str0));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s690_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s690(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s691_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s691_entry, 1, 0};

V g_prelude_2emap_24s691(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_prelude_2emap_24s691(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s691_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s691(a[0]);
}
Clo g_prelude_2emap_24s692_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s692_entry, 1, 0};

V g_prelude_2emap_24s692(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength(heff_dup(v_x_241))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), (g_prelude_2emap_24s692(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s692_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s692(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s693_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s693_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s693_entry, 1, 0};

V g_prelude_2emap_24s693(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_prelude_2emap_24s693_str0), v_x_241), (g_prelude_2emap_24s693(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s693_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s693(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s694_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s694_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s694_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s694_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_prelude_2emap_24s694_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s694_entry, 1, 0};

V g_prelude_2emap_24s694(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_q_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24MkFieldPat = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2eformat_2epatKey(v_q_244));
      V v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      V v_parts_247 = heff_tag_at(v_ru_24x_241_24MkFieldPat, TAG_Cons, 2, (V[]){v_x_243, v_t_246});
      V v_x2_248 = (g_prelude_2emap_24s693(v_parts_247));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_prelude_2emap_24s694_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      v_t_2412 = heff_strAppend(((V)&g_prelude_2emap_24s694_str1), heff_strAppend(((V)&g_prelude_2emap_24s694_str2), heff_strAppend(v_t_2411, ((V)&g_prelude_2emap_24s694_str3))));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s694(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s694_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s694(a[0]);
}
Clo g_prelude_2emap_24s695_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s695_entry, 1, 0};

V g_prelude_2emap_24s695(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eformat_2epatKey(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s695(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s695_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s695(a[0]);
}
Clo g_prelude_2emap_24s700_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s700_entry, 1, 0};

V g_prelude_2emap_24s700(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_msg), (g_prelude_2emap_24s700(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s700_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s700(a[0]);
}
Clo g_prelude_2emap_24s701_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s701_entry, 1, 0};

V g_prelude_2emap_24s701(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_s_243 = heff_get(v_x_241, LBL_text);
    V v_t_244 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength(heff_dup(v_s_243))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), (g_prelude_2emap_24s701(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s701_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s701(a[0]);
}
Clo g_prelude_2eall_24s705_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s705_entry, 1, 0};

V g_prelude_2eall_24s705(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_intLe(MK_INT(48LL), heff_dup(v_x_241));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intLe(heff_dup(v_x_241), MK_INT(57LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eall_24s705_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s705(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s706_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s706_entry, 1, 0};

V g_prelude_2emap_24s706(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2eparseInt(v_x_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_t_245 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_t_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s706(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s706_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s706(a[0]);
}
Clo g_prelude_2eall_24s707_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s707_entry, 1, 0};

V g_prelude_2eall_24s707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_intLe(MK_INT(97LL), heff_dup(v_x_241));
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      v_t_244 = heff_intLe(heff_dup(v_x_241), MK_INT(122LL));
      break;
    }
    case TAG_False: {
      v_t_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      V v_t_245 = heff_intLe(MK_INT(65LL), heff_dup(v_x_241));
      V v_t_2411;
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = heff_intLe(heff_dup(v_x_241), MK_INT(90LL));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        case TAG_False: {
          V v_t_247 = heff_intLe(MK_INT(48LL), heff_dup(v_x_241));
          switch (heff_tag_of(v_t_247)) {
          case TAG_True: {
            V v_t_248 = heff_intLe(heff_dup(v_x_241), MK_INT(57LL));
            switch (heff_tag_of(v_t_248)) {
            case TAG_True: {
              v_t_2411 = NTAG(TAG_True);
              break;
            }
            case TAG_False: {
              v_t_2411 = heff_intEq(heff_dup(v_x_241), MK_INT(95LL));
              break;
            }
            default: heff_nomatch(v_t_248);
            }
            break;
          }
          case TAG_False: {
            v_t_2411 = heff_intEq(heff_dup(v_x_241), MK_INT(95LL));
            break;
          }
          default: heff_nomatch(v_t_247);
          }
          break;
        }
        default: heff_nomatch(v_t_246);
        }
        break;
      }
      case TAG_False: {
        V v_t_249 = heff_intLe(MK_INT(48LL), heff_dup(v_x_241));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V v_t_2410 = heff_intLe(heff_dup(v_x_241), MK_INT(57LL));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            v_t_2411 = NTAG(TAG_True);
            break;
          }
          case TAG_False: {
            v_t_2411 = heff_intEq(heff_dup(v_x_241), MK_INT(95LL));
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          break;
        }
        case TAG_False: {
          v_t_2411 = heff_intEq(heff_dup(v_x_241), MK_INT(95LL));
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eall_24s707_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s707(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2ezipWith_24s708_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s708_entry, 2, 0};

V g_prelude_2ezipWith_24s708(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_y_244, LBL_name), v_x_242});
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s708(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s708_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s708(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s712_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s712_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s712_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s712_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s712_entry, 1, 0};

V g_prelude_2emap_24s712(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(heff_get(heff_dup(v_x_241), LBL_path), heff_strAppend(((V)&g_prelude_2emap_24s712_str0), heff_strAppend(heff_get(heff_dup(v_x_241), LBL_version), heff_strAppend(((V)&g_prelude_2emap_24s712_str1), heff_strAppend(heff_get(v_x_241, LBL_hash), ((V)&g_prelude_2emap_24s712_str2))))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s712(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s712_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s712(a[0]);
}
Clo g_prelude_2emerge_24s714_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s714_entry, 2, 0};

V g_prelude_2emerge_24s714(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s714(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s714(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s714_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s714(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s713_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s713_entry, 1, 0};

V g_prelude_2esortBy_24s713(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s713(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s713(v_t_2411));
      return (g_prelude_2emerge_24s714(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s713_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s713(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2efoldl_24s715_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
Clo g_prelude_2efoldl_24s715_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s715_entry, 2, 0};

V g_prelude_2efoldl_24s715(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s715_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s715_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s715(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2efoldl_24s716_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
Clo g_prelude_2efoldl_24s716_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s716_entry, 2, 0};

V g_prelude_2efoldl_24s716(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s716_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s716_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s716(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s717_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s717_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {44, 32, 112, 97, 116, 104, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2emap_24s717_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {44, 32, 118, 101, 114, 115, 105, 111, 110, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s717_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_prelude_2emap_24s717_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s717_entry, 1, 0};

V g_prelude_2emap_24s717(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_path)));
    V v_t_245 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_version)));
    V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s717_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_prelude_2emap_24s717_str1), heff_strAppend(v_t_244, heff_strAppend(((V)&g_prelude_2emap_24s717_str2), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s717_str3)))))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s717(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s717_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s717(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s718_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s718_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 100, 105, 114, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s718_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_prelude_2emap_24s718_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s718_entry, 1, 0};

V g_prelude_2emap_24s718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_dir)));
    V v_t_245 = heff_strAppend(((V)&g_prelude_2emap_24s718_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_prelude_2emap_24s718_str1), heff_strAppend(v_t_244, ((V)&g_prelude_2emap_24s718_str2)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s718(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s718_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s718(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s719_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_prelude_2efoldl_24s719_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s719_entry, 2, 0};

V g_prelude_2efoldl_24s719(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s719_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s719_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s719(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s721_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
Clo g_prelude_2emap_24s721_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s721_entry, 1, 0};

V g_prelude_2emap_24s721(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_prelude_2emap_24s721_str0), (g_prelude_2emap_24s721(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s721_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s721(a[0]);
}
Clo g_prelude_2emap_24s722_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s722_entry, 1, 0};

V g_prelude_2emap_24s722(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_path)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s722(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s722_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s722(a[0]);
}
Clo g_prelude_2efoldl_24s723_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s723_entry, 2, 0};

V g_prelude_2efoldl_24s723(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_x_242), LBL_path), heff_get(heff_dup(v_z_240), LBL_path));
    V v_t_2412;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_x2_245 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_x_242), LBL_version)));
      V v_t_247;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_246 = heff_field(v_x2_245, 0);
        heff_take_n(v_x2_245, 1ULL, 1);
        v_t_247 = v_x_246;
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      V v_x2_248 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_z_240), LBL_version)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_x2_248, 0);
        heff_take_n(v_x2_248, 1ULL, 1);
        v_t_2410 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_z_240);
        v_t_2412 = heff_dup(v_x_242);
        break;
      }
      case TAG_False: {
        v_t_2412 = v_z_240;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_False: {
      v_t_2412 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s723_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s723(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_prelude_2efoldl_24s724_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s724_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s724_entry, 2, 0};

V g_prelude_2efoldl_24s724(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_prelude_2eany(heff_clo(g_prelude_2efoldl_24s724_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_z_240));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_247 = (g_prelude_2econcatList(v_z_240, v_t_246));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s724_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s724(a[0], a[1]);
}
V g_prelude_2efoldl_24s724_lam0(V self, V *args) {
  V v_y_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_y_244, LBL_path), heff_get(v_x_242, LBL_path));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s725_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
Clo g_prelude_2emap_24s725_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s725_entry, 1, 0};

V g_prelude_2emap_24s725(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_245 = heff_strEq(v_t_244, ((V)&g_prelude_2emap_24s725_str0));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
      break;
    }
    case TAG_False: {
      v_t_247 = v_x_241;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2emap_24s725(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s725_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s725(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2efoldl_24s726_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 45, 62, 32}};
Clo g_prelude_2efoldl_24s726_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s726_entry, 2, 0};

V g_prelude_2efoldl_24s726(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s726_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s726_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s726(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s727_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s727_entry, 1, 0};

V g_prelude_2emap_24s727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_path), (g_prelude_2emap_24s727(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s727_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s727(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2efoldl_24s728_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
Clo g_prelude_2efoldl_24s728_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s728_entry, 2, 0};

V g_prelude_2efoldl_24s728(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s728_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s728_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s728(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s729_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s729_entry, 2, 0};

V g_prelude_2efoldl_24s729(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2elocals_2epatternBinders(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s729_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s729(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s730_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s730_entry, 2, 0};

V g_prelude_2efoldl_24s730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_q_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2elocals_2epatternBinders(heff_dup(v_q_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s730_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s730(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s740_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s740_entry, 1, 0};

V g_prelude_2emap_24s740(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_use), (g_prelude_2emap_24s740(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s740_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s740(a[0]);
}
Clo g_prelude_2efilter_24s741_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s741_entry, 1, 0};

V g_prelude_2efilter_24s741(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s741(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s741_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s741(a[0]);
}
Clo g_prelude_2emap_24s742_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s742_entry, 1, 0};

V g_prelude_2emap_24s742(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_name);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_span);
    V v_t_245 = heff_rec(3, shape_198_98_360, (V[]){v_t_243, v_t_244, heff_get(v_x_241, LBL_use)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s742(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s742_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s742(a[0]);
}
Clo g_prelude_2efilter_24s743_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s743_entry, 1, 0};

V g_prelude_2efilter_24s743(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s743(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s743_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s743(a[0]);
}
Clo g_prelude_2efoldl_24s744_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s744_entry, 2, 0};

V g_prelude_2efoldl_24s744(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_b_244 = (g_heff_2elocals_2edeclaration(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(heff_get(heff_dup(v_z_240), LBL_binders), heff_get(heff_dup(v_b_244), LBL_binders)));
    V v_t_246 = (g_prelude_2econcatList(heff_get(v_z_240, LBL_uses), heff_get(v_b_244, LBL_uses)));
    V t_0 = heff_rec(2, shape_26_363, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s744_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s744(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s746_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s746_entry, 2, 0};

V g_prelude_2emerge_24s746(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s746(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s746(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s746_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s746(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s745_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s745_entry, 1, 0};

V g_prelude_2esortBy_24s745(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s745(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s745(v_t_2411));
      return (g_prelude_2emerge_24s746(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s745_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s745(a[0]);
}
Clo g_prelude_2emerge_24s748_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s748_entry, 2, 0};

V g_prelude_2emerge_24s748(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
      V v_t_247 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_248 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_end);
      V v_t_249 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      V v_t_2410 = heff_intLe(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s748(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s748(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s748_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s748(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s747_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s747_entry, 1, 0};

V g_prelude_2esortBy_24s747(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s747(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s747(v_t_2411));
      return (g_prelude_2emerge_24s748(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s747_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s747(a[0]);
}
Clo g_prelude_2emerge_24s750_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s750_entry, 2, 0};

V g_prelude_2emerge_24s750(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_strLt(heff_get(heff_dup(v_y_244), LBL_label), heff_get(heff_dup(v_x_242), LBL_label));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s750(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s750(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s750_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s750(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s749_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s749_entry, 1, 0};

V g_prelude_2esortBy_24s749(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s749(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s749(v_t_2411));
      return (g_prelude_2emerge_24s750(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s749_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s749(a[0]);
}
Clo g_prelude_2emap_24s751_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s751_entry, 1, 0};

V g_prelude_2emap_24s751(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_198_314, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s751(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s751_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s751(a[0]);
}
Clo g_prelude_2emap_24s752_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s752_entry, 1, 0};

V g_prelude_2emap_24s752(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s752(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s752_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s752(a[0]);
}
Clo g_prelude_2emap_24s753_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s753_entry, 1, 0};

V g_prelude_2emap_24s753(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_198_314, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s753(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s753_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s753(a[0]);
}
Clo g_prelude_2emap_24s754_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s754_entry, 1, 0};

V g_prelude_2emap_24s754(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_span), (g_prelude_2emap_24s754(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s754_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s754(a[0]);
}
Clo g_prelude_2efoldl_24s757_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s757_entry, 2, 0};

V g_prelude_2efoldl_24s757(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2426;
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_f_247 = heff_field(v_t_246, 0);
      V v_fsp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 4);
      v_t_2426 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_rec(3, shape_198_154_314, (V[]){v_f_247, MK_INT(12LL), v_fsp_248}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2427 = (g_prelude_2econcatList(v_t_2426, v_z_240));
    V t_0 = v_t_2427;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s757_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s757(a[0], a[1]);
}
Clo g_prelude_2efind_24s758_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_24s758_entry, 1, 0};

V g_prelude_2efind_24s758(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    V v_x1_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_x1_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_x1_245 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efind_24s758_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind_24s758(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2efilter_24s759_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s759_entry, 1, 0};

V g_prelude_2efilter_24s759(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s759(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s759_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s759(a[0]);
}
Clo g_prelude_2efoldl_24s763_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s763_entry, 2, 0};

V g_prelude_2efoldl_24s763(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s763_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s763(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s764_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s764_entry, 2, 0};

V g_prelude_2efoldl_24s764(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_DeclareField: {
        V v_t_248 = heff_field(v_it1_244, 2);
        V v_d_249 = heff_field(v_it1_244, 3);
        V v_t_2410 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_t_248)));
        V v_t_2412;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_d_249, 0);
          v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_x_2411)));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        v_t_2414 = (g_prelude_2econcatList(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_e_2413 = heff_field(v_it1_244, 0);
        v_t_2414 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_2413)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2econcatList(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s764_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s764(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s765_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s765_entry, 2, 0};

V g_prelude_2efoldl_24s765(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_TagVariant: {
        V v_args_248 = heff_field(v_it1_244, 2);
        V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_args_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_prelude_2efoldl_24s763(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_e_2410 = heff_field(v_it1_244, 0);
        v_t_2411 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_2410)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2econcatList(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s765_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s765(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s766_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s766_entry, 2, 0};

V g_prelude_2efoldl_24s766(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_SetField: {
        V v_e_248 = heff_field(v_it1_244, 2);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_248)));
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_249 = heff_field(v_it1_244, 0);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_249)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2econcatList(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s766_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s766(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s767_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s767_entry, 2, 0};

V g_prelude_2efoldl_24s767(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_MkAlt: {
        V v_e_247 = heff_field(v_it1_244, 1);
        v_t_248 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_247)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s767_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s767(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s768_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s768_entry, 2, 0};

V g_prelude_2efoldl_24s768(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_StmtBind: {
        V v_e_248 = heff_field(v_it1_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_248)));
        break;
      }
      case TAG_StmtLet: {
        V v_e_2410 = heff_field(v_it1_244, 1);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_2410)));
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2411 = heff_field(v_it1_244, 0);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_e_2411)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2econcatList(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s768_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s768(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s769_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s769_entry, 2, 0};

V g_prelude_2efoldl_24s769(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalDeclF_24s760(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s769_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s769(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s761_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s761_entry, 2, 0};

V g_prelude_2efoldl_24s761(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_it1_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_MkEquation: {
        V v_rhs_249 = heff_field(v_it1_244, 3);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_rhs_249)));
        break;
      }
      default: heff_nomatch(v_it1_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2econcatList(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s761_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s761(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s770_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s770_entry, 2, 0};

V g_prelude_2efoldl_24s770(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_ExplicitParam: {
        V v_t_248 = heff_field(v_x21_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_t_248)));
        break;
      }
      case TAG_ImplicitParam: {
        V v_t_2411 = heff_field(v_x21_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s762(heff_dup(v_t_2411)));
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2econcatList(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s770_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s770(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s772_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s772_entry, 2, 0};

V g_prelude_2emerge_24s772(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_247 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      V v_t_248 = heff_intLe(v_t_246, v_t_247);
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s772(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s772(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s772_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s772(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s771_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s771_entry, 1, 0};

V g_prelude_2esortBy_24s771(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s771(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s771(v_t_2411));
      return (g_prelude_2emerge_24s772(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s771_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s771(a[0]);
}
Clo g_prelude_2efoldl_24s786_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s786_entry, 2, 0};

V g_prelude_2efoldl_24s786(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x_242, 0);
      V v_h_245 = heff_field(v_x_242, 1);
      V v_x3_246 = (g_map_2elookup_24s9(heff_dup(v_k_244), v_z_240));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_t_248 = (g_map_2einsert_24s7(heff_dup(v_k_244), heff_dup(v_h_245), v_z_240));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_246, 0ULL, 1);
        v_t_248 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s786_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s786(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s787_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s787_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s787_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_prelude_2emap_24s787_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s787_entry, 1, 0};

V g_prelude_2emap_24s787(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_assoc);
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_AssocLeft: {
      v_t_244 = MK_INT(0LL);
      break;
    }
    case TAG_AssocRight: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_AssocNone: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_245 = heff_get(heff_dup(v_x_241), LBL_ops);
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_prelude_2emap_24s787_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_t_245, 0);
      V v_xs_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_249 = heff_strAppend(heff_get(v_x_241, LBL_id), heff_strAppend(((V)&g_prelude_2emap_24s787_str1), heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_prelude_2emap_24s787_str2), v_t_248))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s787(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s787_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s787(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s788_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {62}};
Clo g_prelude_2emap_24s788_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s788_entry, 1, 0};

V g_prelude_2emap_24s788(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(heff_get(heff_dup(v_x_241), LBL_tighter), heff_strAppend(((V)&g_prelude_2emap_24s788_str0), heff_get(v_x_241, LBL_looser)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s788(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s788_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s788(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s789_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2efoldl_24s789_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s789_entry, 2, 0};

V g_prelude_2efoldl_24s789(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(((V)&g_prelude_2efoldl_24s789_str0), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s789_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s789(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s790_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_prelude_2efoldl_24s790_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s790_entry, 2, 0};

V g_prelude_2efoldl_24s790(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_prelude_2efoldl_24s790_str0), v_x_242));
    V v_t_246 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s790_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s790(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s791_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_prelude_2efoldl_24s791_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s791_entry, 2, 0};

V g_prelude_2efoldl_24s791(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_s_244 = heff_get(heff_dup(v_x_242), LBL_id);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_s_244)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_prelude_2efoldl_24s791_str0), v_s_244));
    V v_t_247 = heff_get(heff_dup(v_x_242), LBL_assoc);
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_AssocLeft: {
      v_t_248 = MK_INT(0LL);
      break;
    }
    case TAG_AssocRight: {
      v_t_248 = MK_INT(1LL);
      break;
    }
    case TAG_AssocNone: {
      v_t_248 = MK_INT(2LL);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_xs_249 = heff_get(v_x_242, LBL_ops);
    V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_249));
    V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_249));
    V v_t_2412 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), (g_prelude_2efoldl_24s790(NTAG(TAG_Nil), v_t_2411))});
    V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_248), v_t_2412});
    V v_t_2414 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_2413}), v_z_240));
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s791_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s791(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s792_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efoldl_24s792_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_prelude_2efoldl_24s792_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s792_entry, 2, 0};

V g_prelude_2efoldl_24s792(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_s_244 = heff_get(heff_dup(v_x_242), LBL_tighter);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_s_244)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_prelude_2efoldl_24s792_str0), v_s_244));
    V v_s_247 = heff_get(v_x_242, LBL_looser);
    V v_t_248 = heff_intShow(heff_strLength(heff_dup(v_s_247)));
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_prelude_2efoldl_24s792_str1), v_s_247));
    V v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_2410}), v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s792_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s792(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s793_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s793_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s793_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
Clo g_prelude_2emap_24s793_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s793_entry, 1, 0};

V g_prelude_2emap_24s793(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_kh_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_kh_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_it_246 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s793_str0), heff_dup(v_kh_245), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2411;
    switch (heff_tag_of(v_it_246)) {
    case TAG_Nil: {
      v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_kh_245, ((V)&g_prelude_2emap_24s793_str1)});
      break;
    }
    case TAG_Cons: {
      V v_k_247 = heff_field(v_it_246, 0);
      V v_it2_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_Nil: {
        heff_drop(v_k_247);
        v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_kh_245, ((V)&g_prelude_2emap_24s793_str2)});
        break;
      }
      case TAG_Cons: {
        V v_h_249 = heff_field(v_it2_248, 0);
        heff_take_n(v_it2_248, 1ULL, 2);
        heff_drop(v_kh_245);
        v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_k_247, v_h_249});
        break;
      }
      default: heff_nomatch(v_it2_248);
      }
      break;
    }
    default: heff_nomatch(v_it_246);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s793(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s793_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s793(a[0]);
}
Clo g_prelude_2efilter_24s794_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s794_entry, 1, 0};

V g_prelude_2efilter_24s794(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intEq(heff_get(heff_dup(v_x_241), LBL_parent), MK_INT(0LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s794(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s794_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s794(a[0]);
}
Clo g_prelude_2efoldl_24s797_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s797_entry, 2, 0};

V g_prelude_2efoldl_24s797(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_get(heff_dup(v_z_240), LBL_errors)});
    V v_t_245 = heff_rec(5, shape_312_89_240_229_230, (V[]){heff_get(heff_dup(v_z_240), LBL_sources), v_t_244, heff_get(heff_dup(v_z_240), LBL_paths), heff_get(heff_dup(v_z_240), LBL_package), heff_get(v_z_240, LBL_packages)});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s797_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s797(a[0], a[1]);
}
Clo g_prelude_2eany_24s798_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s798_entry, 1, 0};

V g_prelude_2eany_24s798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_243 = (g_prelude_2efilter_24s495(heff_get(heff_dup(v_x_241), LBL_diags)));
    V v_x1_246;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      v_x1_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_x1_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    switch (heff_tag_of(v_x1_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s798_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s798(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s799_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s799_entry, 1, 0};

V g_prelude_2emap_24s799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_198_152, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s799(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s799_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s799(a[0]);
}
Clo g_prelude_2emap_24s800_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s800_entry, 1, 0};

V g_prelude_2emap_24s800(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s800(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s800_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s800(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s801_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s801_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
Clo g_prelude_2emap_24s801_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s801_entry, 1, 0};

V g_prelude_2emap_24s801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s801_str0), heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s801_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s801(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s801_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s801(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2efilter_24s802_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 99}};
Clo g_prelude_2efilter_24s802_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s802_entry, 1, 0};

V g_prelude_2efilter_24s802(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(2LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_245 = heff_strEq(v_t_244, ((V)&g_prelude_2efilter_24s802_str0));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s802(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s802_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s802(a[0]);
}
Clo g_prelude_2efoldl_24s803_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s803_entry, 2, 0};

V g_prelude_2efoldl_24s803(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_build), LBL_ships);
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s803_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s803(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2efilter_24s804_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_prelude_2efilter_24s804_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s804_entry, 1, 0};

V g_prelude_2efilter_24s804(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(1LL)), ((V)&g_prelude_2efilter_24s804_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s804(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s804_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s804(a[0]);
}
Clo g_prelude_2efoldl_24s805_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s805_entry, 2, 0};

V g_prelude_2efoldl_24s805(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_xs_244 = (g_prelude_2efilter_24s495(heff_get(heff_dup(v_x_242), LBL_diags)));
    V v_t_245 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_244); r_; });
    V t_0 = heff_intAdd(v_z_240, v_t_245);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s805_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s805(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efilter_24s810_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s810_entry, 1, 0};

V g_prelude_2efilter_24s810(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_watch), LBL_holds);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s810(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s810_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s810(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s811_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 32, 32, 32, 32, 32}};
Clo g_prelude_2emap_24s811_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s811_entry, 1, 0};

V g_prelude_2emap_24s811(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_prelude_2emap_24s811_str0), v_x_241), (g_prelude_2emap_24s811(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s811_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s811(a[0]);
}
Clo g_prelude_2efilter_24s812_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s812_entry, 1, 0};

V g_prelude_2efilter_24s812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ok);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s812(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s812_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s812(a[0]);
}
Clo g_prelude_2emap_24s813_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s813_entry, 1, 0};

V g_prelude_2emap_24s813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s813(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s813_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s813(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s814_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s814_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s814_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s814_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_prelude_2emap_24s814_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s814_entry, 1, 0};

V g_prelude_2emap_24s814(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_k_243 = heff_field(v_x_241, 0);
      V v_v_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2ejson_2eescapeGo(v_k_243, MK_INT(0LL), ((V)&g_prelude_2emap_24s814_str0)));
      V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s814_str1), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s814_str2)));
      v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_prelude_2emap_24s814_str3), ({ V a_0 = v_v_244; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop(v_v_244); r_; })));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2emap_24s814(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s814_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s814(a[0]);
}
Clo g_prelude_2emap_24s815_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s815_entry, 1, 0};

V g_prelude_2emap_24s815(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2elean(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s815(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s815_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s815(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s817_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s817_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 116, 97, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s817_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {108, 97, 98, 101, 108}};
Clo g_prelude_2emap_24s817_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s817_entry, 1, 0};

V g_prelude_2emap_24s817(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_label)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s817_str0), heff_tag(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag(TAG_JString, 1, (V[]){heff_get(v_x_241, LBL_detail)});
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s817_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s817_str2), v_t_243}), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_247}), (g_prelude_2emap_24s817(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s817_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s817(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2efind_24s818_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
Clo g_prelude_2efind_24s818_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_24s818_entry, 1, 0};

V g_prelude_2efind_24s818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_strEq(v_t_245, ((V)&g_prelude_2efind_24s818_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efind_24s818_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind_24s818(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2efind_24s819_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};
Clo g_prelude_2efind_24s819_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_24s819_entry, 1, 0};

V g_prelude_2efind_24s819(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_strEq(v_t_245, ((V)&g_prelude_2efind_24s819_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efind_24s819_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind_24s819(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s820_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s820_entry, 1, 0};

V g_prelude_2emap_24s820(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_long), (g_prelude_2emap_24s820(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s820_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s820(a[0]);
}
Clo g_prelude_2emap_24s821_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s821_entry, 1, 0};

V g_prelude_2emap_24s821(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_short), (g_prelude_2emap_24s821(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s821_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s821(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s822_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s822_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
Clo g_prelude_2eany_24s822_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s822_entry, 1, 0};

V g_prelude_2eany_24s822(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strLength(heff_get(heff_dup(v_x_241), LBL_short));
    V v_t_244 = heff_intLt(MK_INT(1LL), v_t_243);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_245 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_short), ((V)&g_prelude_2eany_24s822_str0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_246 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_short), ((V)&g_prelude_2eany_24s822_str1));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s822_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s822(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2eany_24s823_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s823_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s823_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s823_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
Clo g_prelude_2eany_24s823_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s823_entry, 1, 0};

V g_prelude_2eany_24s823(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_long), ((V)&g_prelude_2eany_24s823_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_244 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_short), ((V)&g_prelude_2eany_24s823_str1));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_245 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_long), ((V)&g_prelude_2eany_24s823_str2));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V v_t_246 = (g_prelude_2eindexFrom(((V)&g_prelude_2eany_24s823_str3), heff_get(heff_dup(v_x_241), LBL_long), MK_INT(0LL)));
          switch (heff_tag_of(v_t_246)) {
          case TAG_Nothing: {
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          }
          case TAG_Just: {
            heff_take_n(v_t_246, 0ULL, 1);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s823_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s823(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eany_24s824_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2eany_24s824_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s824_entry, 1, 0};

V g_prelude_2eany_24s824(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strEq(heff_get(heff_dup(v_x_241), LBL_meta), ((V)&g_prelude_2eany_24s824_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_get(heff_dup(v_x_241), LBL_values);
      V v_x1_247;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        v_x1_247 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        v_x1_247 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      switch (heff_tag_of(v_x1_247)) {
      case TAG_True: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s824_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s824(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s828_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
Clo g_prelude_2emap_24s828_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s828_entry, 1, 0};

V g_prelude_2emap_24s828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strAppend(((V)&g_prelude_2emap_24s828_str0), heff_get(v_x_241, LBL_long));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s828(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s828_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s828(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s829_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s829_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s829_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s829_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s829_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s829_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s829_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
Clo g_prelude_2emap_24s829_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s829_entry, 1, 0};

V g_prelude_2emap_24s829(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_arity);
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      v_t_244 = heff_get(v_x_241, LBL_meta);
      break;
    }
    case TAG_Optional: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s829_str0), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s829_str1)));
      break;
    }
    case TAG_Many: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s829_str2), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s829_str3)));
      break;
    }
    case TAG_Some: {
      v_t_244 = heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s829_str4));
      break;
    }
    case TAG_Rest: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s829_str5), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s829_str6)));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s829(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s829_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s829(a[0]);
}
Clo g_prelude_2emap_24s830_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s830_entry, 1, 0};

V g_prelude_2emap_24s830(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s830(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s830_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s830(a[0]);
}
Clo g_prelude_2emap_24s831_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s831_entry, 1, 0};

V g_prelude_2emap_24s831(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get(v_x_241, LBL_doc)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s831(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s831_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s831(a[0]);
}
Clo g_prelude_2efilter_24s832_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s832_entry, 1, 0};

V g_prelude_2efilter_24s832(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_shown);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s832(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s832_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s832(a[0]);
}
Clo g_prelude_2emap_24s833_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s833_entry, 1, 0};

V g_prelude_2emap_24s833(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s833(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s833_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s833(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s834_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
Clo g_prelude_2emap_24s834_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s834_entry, 1, 0};

V g_prelude_2emap_24s834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_prelude_2emap_24s834_str0), v_x_241), (g_prelude_2emap_24s834(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s834_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s834(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s835_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s835_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s835_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s835_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s835_entry, 1, 0};

V g_prelude_2emap_24s835(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_w_243 = heff_get(heff_dup(v_x_241), LBL_name);
    V v_doc_244 = heff_get(v_x_241, LBL_doc);
    V v_t_245 = heff_strEq(heff_dup(v_doc_244), ((V)&g_prelude_2emap_24s835_str0));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_doc_244);
      v_t_246 = v_w_243;
      break;
    }
    case TAG_False: {
      v_t_246 = heff_strAppend(v_w_243, heff_strAppend(((V)&g_prelude_2emap_24s835_str1), v_doc_244));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_prelude_2emap_24s835_str2)), (g_prelude_2emap_24s835(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s835_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s835(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s836_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s836_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s836_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s836_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s836_entry, 1, 0};

V g_prelude_2emap_24s836(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_w_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_dup(heff_field(v_x_241, 0));
      v_w_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_doc_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_doc_248 = v_y_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = heff_strEq(heff_dup(v_doc_248), ((V)&g_prelude_2emap_24s836_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_doc_248);
      v_t_2410 = v_w_245;
      break;
    }
    case TAG_False: {
      v_t_2410 = heff_strAppend(v_w_245, heff_strAppend(((V)&g_prelude_2emap_24s836_str1), v_doc_248));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_prelude_2emap_24s836_str2)), (g_prelude_2emap_24s836(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s836_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s836(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s837_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_prelude_2emap_24s837_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s837_entry, 1, 0};

V g_prelude_2emap_24s837(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_241, ((V)&g_prelude_2emap_24s837_str0)), (g_prelude_2emap_24s837(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s837_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s837(a[0]);
}
Clo g_prelude_2econcatList_24s1353_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2econcatList_24s1353_entry, 1, 0};

V g_prelude_2econcatList_24s1353(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_app_2eheff_2emain_2etoolCommands_24s1352_get());
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2econcatList_24s1353(v_xs_242))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2econcatList_24s1353_entry(V self, V *a) {
  (void)self;
  return g_prelude_2econcatList_24s1353(a[0]);
}