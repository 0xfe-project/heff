// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_ERecord 5518
#define TAG_ESpec 56652
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_Many 40086
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_None 17785
#define TAG_Ok 9325
#define TAG_One 26866
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Optional 11609
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PSelf 48502
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Rest 61983
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_Some 35657
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Text 56194
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_arg 306384
#define LBL_arity 294440695
#define LBL_assoc 294479919
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_build 295453320
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_detail 611917692
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_doc 309170
#define LBL_el 9998
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_fixed 298804110
#define LBL_fixities 357800079
#define LBL_global 704121550
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_js 10160
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_protos 967342774
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_ships 310766033
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops[] = {LBL_id, LBL_assoc, LBL_ops};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_order__entries__aliases__broken[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2earity_2earityOne(V, V);
V g_heff_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2earity_2earityOne_clo;
V g_heff_2eclauses_2erenamer(V, V);
V g_heff_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenamer_clo;
V g_heff_2edriver_2eappendD(V, V);
V g_heff_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2edriver_2eappendD_clo;
V g_heff_2edriver_2eclosureGo(V, V, V);
V g_heff_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2eclosureGo_clo;
V g_heff_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabNeeding_clo;
V g_heff_2edriver_2eenvOne(V, V);
V g_heff_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eenvOne_clo;
V g_heff_2edriver_2eglueOne(V, V);
V g_heff_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eglueOne_clo;
V g_heff_2edriver_2ehint(V);
V g_heff_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2edriver_2ehint_clo;
V g_heff_2edriver_2elabelOfV(V);
V g_heff_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2elabelOfV_clo;
V g_heff_2edriver_2elean(V);
V g_heff_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2edriver_2elean_clo;
V g_heff_2edriver_2enubStrD(V);
V g_heff_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubStrD_clo;
V g_heff_2edriver_2eoutcomeOfV(V);
V g_heff_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2eoutcomeOfV_clo;
V g_heff_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2edriver_2epromoteAt_clo;
V g_heff_2eeffect_2edropLastD(V);
V g_heff_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eeffect_2edropLastD_clo;
V g_heff_2eemit_2ebindName(V, V);
V g_heff_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebindName_clo;
V g_heff_2eemit_2eexportNameOf(V);
V g_heff_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eexportNameOf_clo;
V g_heff_2eemit_2ehostLineOf(V);
V g_heff_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ehostLineOf_clo;
V g_heff_2eemit_2elastDotFrom(V, V);
V g_heff_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastDotFrom_clo;
V g_heff_2eemit_2eprimUses(V, V);
V g_heff_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimUses_clo;
V g_heff_2eemit_2esafeChars(V, V, V);
V g_heff_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeChars_clo;
V g_heff_2eemit_2esafeRes(V);
V g_heff_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeRes_clo;
V g_heff_2eemit_2espellAt(V, V);
V g_heff_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2eemit_2espellAt_clo;
V g_heff_2eemit_2etailApp(V);
V g_heff_2eemit_2etailApp_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailApp_clo;
V g_heff_2eemit_2etailGlobals(V);
V g_heff_2eemit_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailGlobals_clo;
V g_heff_2eemit_2etrampolineStr_get(void);
V g_heff_2eemit_2evalueRefs(V);
V g_heff_2eemit_2evalueRefs_entry(V self, V *a);
extern Clo g_heff_2eemit_2evalueRefs_clo;
V g_heff_2eemitc_2earityOne(V, V);
V g_heff_2eemitc_2earityOne_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earityOne_clo;
V g_heff_2eemitc_2eborAll(V, V);
V g_heff_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborAll_clo;
V g_heff_2eemitc_2eborDef(V, V);
V g_heff_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborDef_clo;
V g_heff_2eemitc_2ebuildsSize(V, V);
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebuildsSize_clo;
V g_heff_2eemitc_2eelemS(V, V);
V g_heff_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemS_clo;
V g_heff_2eemitc_2efreeOf(V, V);
V g_heff_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeOf_clo;
V g_heff_2eemitc_2eidentAt(V, V, V);
V g_heff_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eidentAt_clo;
V g_heff_2eemitc_2eknownTags_get(void);
V g_heff_2eemitc_2elastDotGo(V, V, V);
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elastDotGo_clo;
V g_heff_2eemitc_2emangleW(V, V, V, V);
V g_heff_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleW_clo;
V g_heff_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enamesInGo_clo;
V g_heff_2eemitc_2eprimCloDef(V);
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimCloDef_clo;
V g_heff_2eemitc_2epubLine(V);
V g_heff_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epubLine_clo;
V g_heff_2eemitc_2eshapeDef(V);
V g_heff_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eshapeDef_clo;
V g_heff_2eemitc_2etagsLbls(V);
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etagsLbls_clo;
V g_heff_2efixed_2efloat32Ops_get(void);
V g_heff_2efixed_2eintOps_get(void);
V g_heff_2efixity_2eappendF(V, V);
V g_heff_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2efixity_2eappendF_clo;
V g_heff_2efixity_2enubByE(V);
V g_heff_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByE_clo;
V g_heff_2efixity_2enubByG(V);
V g_heff_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByG_clo;
V g_heff_2efixity_2ereserved_get(void);
V g_heff_2efmt_2eimports_2espacesOf(V);
V g_heff_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2espacesOf_clo;
V g_heff_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2eformat_2epatKey(V);
V g_heff_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2epatKey_clo;
V g_heff_2eimport_2eimplicitImports_get(void);
V g_heff_2eimport_2eimportsOf(V, V);
V g_heff_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsOf_clo;
V g_heff_2eimport_2erenamed(V, V);
V g_heff_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2eimport_2erenamed_clo;
V g_heff_2eimport_2espaces(V);
V g_heff_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2eimport_2espaces_clo;
V g_heff_2einterp_2eshowValGo(V, V);
V g_heff_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eshowValGo_clo;
V g_heff_2eir_2efreshBindOne(V, V);
V g_heff_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshBindOne_clo;
V g_heff_2eir_2eglobalsGo(V);
V g_heff_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2eir_2eglobalsGo_clo;
V g_heff_2eir_2eisValue(V);
V g_heff_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2eir_2eisValue_clo;
V g_heff_2eir_2enubI(V);
V g_heff_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2eir_2enubI_clo;
V g_heff_2ejson_2eescapeGo(V, V, V);
V g_heff_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2ejson_2eescapeGo_clo;
V g_heff_2ejson_2estringify(V);
V g_heff_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2ejson_2estringify_clo;
V g_heff_2elift_2eliftGo_24s104003089x2047780485(V, V, V);
V g_heff_2elift_2eliftGo_24s104003089x2047780485_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s104003089x2047780485_clo;
V g_heff_2elocals_2edeclaration(V);
V g_heff_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclaration_clo;
V g_heff_2elocals_2epatternBinders(V);
V g_heff_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2epatternBinders_clo;
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(V);
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_clo;
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(V);
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_clo;
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564(V, V);
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkDe_24s1632343938x112901564_clo;
V g_heff_2epresyntax_2echkNode_24s769858677x299167023(V);
V g_heff_2epresyntax_2echkNode_24s769858677x299167023_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkNode_24s769858677x299167023_clo;
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(V);
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_clo;
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013(V);
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edeclN_24s819476248x1348827013_clo;
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(V);
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_clo;
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(V);
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_clo;
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(V);
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_clo;
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(V);
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_clo;
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(V);
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_clo;
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(V, V);
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_clo;
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(V);
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_clo;
V g_heff_2eprims_2efixedImpl(V);
V g_heff_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2eprims_2efixedImpl_clo;
V g_heff_2eprint_2earmOf_24s139775371x1736504365(V);
V g_heff_2eprint_2earmOf_24s139775371x1736504365_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_24s139775371x1736504365_clo;
V g_heff_2eprint_2ecommaSep(V);
V g_heff_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eprint_2ecommaSep_clo;
V g_heff_2eprint_2eescFrom(V, V);
V g_heff_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescFrom_clo;
V g_heff_2eprint_2epr_get(void);
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(V);
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_clo;
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(V);
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_clo;
V g_heff_2eproject_2enewerGo(V, V);
V g_heff_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2enewerGo_clo;
V g_heff_2eproject_2equoted(V);
V g_heff_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2eproject_2equoted_clo;
V g_heff_2eproject_2esumBefore(V, V);
V g_heff_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2eproject_2esumBefore_clo;
V g_heff_2eproject_2eversion(V);
V g_heff_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2eproject_2eversion_clo;
V g_heff_2equery_2elocalDeclF_24s535437546x2025255677(V);
V g_heff_2equery_2elocalDeclF_24s535437546x2025255677_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalDeclF_24s535437546x2025255677_clo;
V g_heff_2equery_2elocalTermF_24s1158823265x601317201(V);
V g_heff_2equery_2elocalTermF_24s1158823265x601317201_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalTermF_24s1158823265x601317201_clo;
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(V);
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_clo;
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(V);
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_clo;
V g_heff_2esimplify_2eflat(V);
V g_heff_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eflat_clo;
V g_heff_2esimplify_2esgFlat(V, V, V);
V g_heff_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esgFlat_clo;
V g_heff_2espec_2ebindOne(V, V);
V g_heff_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2espec_2ebindOne_clo;
V g_heff_2espec_2ekeyGo(V, V);
V g_heff_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ekeyGo_clo;
V g_heff_2esurface_2easNameE(V);
V g_heff_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esurface_2easNameE_clo;
V g_heff_2esurface_2eidentOf(V);
V g_heff_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eidentOf_clo;
V g_heff_2etoplevel_2ethawOne(V, V);
V g_heff_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ethawOne_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2eall(V, V);
V g_prelude_2eall_entry(V self, V *a);
extern Clo g_prelude_2eall_clo;
V g_prelude_2eall_24s1095920613x165325623(V, V, V);
V g_prelude_2eall_24s1095920613x165325623_entry(V self, V *a);
extern Clo g_prelude_2eall_24s1095920613x165325623_clo;
V g_prelude_2eall_24s1176014659x1280298318(V);
V g_prelude_2eall_24s1176014659x1280298318_entry(V self, V *a);
extern Clo g_prelude_2eall_24s1176014659x1280298318_clo;
V g_prelude_2eall_24s632542597x363082259(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_prelude_2eall_24s632542597x363082259_entry(V self, V *a);
extern Clo g_prelude_2eall_24s632542597x363082259_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2eany_24s1185451557x1725025605(V);
V g_prelude_2eany_24s1185451557x1725025605_entry(V self, V *a);
extern Clo g_prelude_2eany_24s1185451557x1725025605_clo;
V g_prelude_2eany_24s1590645509x196373689(V, V);
V g_prelude_2eany_24s1590645509x196373689_entry(V self, V *a);
extern Clo g_prelude_2eany_24s1590645509x196373689_clo;
V g_prelude_2eany_24s1630892143x990483949(V);
V g_prelude_2eany_24s1630892143x990483949_entry(V self, V *a);
extern Clo g_prelude_2eany_24s1630892143x990483949_clo;
V g_prelude_2eany_24s1963868307x1860200435(V);
V g_prelude_2eany_24s1963868307x1860200435_entry(V self, V *a);
extern Clo g_prelude_2eany_24s1963868307x1860200435_clo;
V g_prelude_2eany_24s2123146976x1090108363(V);
V g_prelude_2eany_24s2123146976x1090108363_entry(V self, V *a);
extern Clo g_prelude_2eany_24s2123146976x1090108363_clo;
V g_prelude_2eany_24s306565984x776318930(V);
V g_prelude_2eany_24s306565984x776318930_entry(V self, V *a);
extern Clo g_prelude_2eany_24s306565984x776318930_clo;
V g_prelude_2eany_24s338218608x1930042456(V, V, V, V, V, V);
V g_prelude_2eany_24s338218608x1930042456_entry(V self, V *a);
extern Clo g_prelude_2eany_24s338218608x1930042456_clo;
V g_prelude_2eany_24s438096394x623120595(V);
V g_prelude_2eany_24s438096394x623120595_entry(V self, V *a);
extern Clo g_prelude_2eany_24s438096394x623120595_clo;
V g_prelude_2eany_24s452699088x1271436644(V);
V g_prelude_2eany_24s452699088x1271436644_entry(V self, V *a);
extern Clo g_prelude_2eany_24s452699088x1271436644_clo;
V g_prelude_2eany_24s486367843x134447435(V);
V g_prelude_2eany_24s486367843x134447435_entry(V self, V *a);
extern Clo g_prelude_2eany_24s486367843x134447435_clo;
V g_prelude_2eany_24s588349713x1374270364(V, V, V, V);
V g_prelude_2eany_24s588349713x1374270364_entry(V self, V *a);
extern Clo g_prelude_2eany_24s588349713x1374270364_clo;
V g_prelude_2eany_24s827288872x1370860167(V);
V g_prelude_2eany_24s827288872x1370860167_entry(V self, V *a);
extern Clo g_prelude_2eany_24s827288872x1370860167_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2edigitsFrom(V, V, V);
V g_prelude_2edigitsFrom_entry(V self, V *a);
extern Clo g_prelude_2edigitsFrom_clo;
V g_prelude_2edrop(V, V);
V g_prelude_2edrop_entry(V self, V *a);
extern Clo g_prelude_2edrop_clo;
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efilter_24s1056866665x1882138159(V);
V g_prelude_2efilter_24s1056866665x1882138159_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1056866665x1882138159_clo;
V g_prelude_2efilter_24s1076841276x1319703925(V);
V g_prelude_2efilter_24s1076841276x1319703925_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1076841276x1319703925_clo;
V g_prelude_2efilter_24s1338078379x1447244245(V, V, V, V);
V g_prelude_2efilter_24s1338078379x1447244245_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1338078379x1447244245_clo;
V g_prelude_2efilter_24s1514461241x1644469075(V);
V g_prelude_2efilter_24s1514461241x1644469075_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1514461241x1644469075_clo;
V g_prelude_2efilter_24s1597546471x2138686503(V);
V g_prelude_2efilter_24s1597546471x2138686503_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1597546471x2138686503_clo;
V g_prelude_2efilter_24s1642131147x1885675035(V, V, V, V);
V g_prelude_2efilter_24s1642131147x1885675035_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1642131147x1885675035_clo;
V g_prelude_2efilter_24s1700824619x1565819740(V);
V g_prelude_2efilter_24s1700824619x1565819740_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1700824619x1565819740_clo;
V g_prelude_2efilter_24s1893795724x726475325(V, V);
V g_prelude_2efilter_24s1893795724x726475325_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1893795724x726475325_clo;
V g_prelude_2efilter_24s189668615x351352663(V, V);
V g_prelude_2efilter_24s189668615x351352663_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s189668615x351352663_clo;
V g_prelude_2efilter_24s1987049161x529776488(V);
V g_prelude_2efilter_24s1987049161x529776488_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1987049161x529776488_clo;
V g_prelude_2efilter_24s1995665332x305653225(V, V, V, V);
V g_prelude_2efilter_24s1995665332x305653225_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1995665332x305653225_clo;
V g_prelude_2efilter_24s2061636403x27832284(V);
V g_prelude_2efilter_24s2061636403x27832284_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s2061636403x27832284_clo;
V g_prelude_2efilter_24s37718278x420368011(V);
V g_prelude_2efilter_24s37718278x420368011_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s37718278x420368011_clo;
V g_prelude_2efilter_24s419026844x1025599777(V, V, V);
V g_prelude_2efilter_24s419026844x1025599777_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s419026844x1025599777_clo;
V g_prelude_2efilter_24s47197728x1723782535(V);
V g_prelude_2efilter_24s47197728x1723782535_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s47197728x1723782535_clo;
V g_prelude_2efilter_24s568328629x1584314777(V);
V g_prelude_2efilter_24s568328629x1584314777_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s568328629x1584314777_clo;
V g_prelude_2efilter_24s627362487x853718923(V, V);
V g_prelude_2efilter_24s627362487x853718923_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s627362487x853718923_clo;
V g_prelude_2efilter_24s640953257x788905679(V);
V g_prelude_2efilter_24s640953257x788905679_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s640953257x788905679_clo;
V g_prelude_2efilter_24s758020682x2002616678(V);
V g_prelude_2efilter_24s758020682x2002616678_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s758020682x2002616678_clo;
V g_prelude_2efind(V, V);
V g_prelude_2efind_entry(V self, V *a);
extern Clo g_prelude_2efind_clo;
V g_prelude_2efind_24s1637404220x1380860409(V);
V g_prelude_2efind_24s1637404220x1380860409_entry(V self, V *a);
extern Clo g_prelude_2efind_24s1637404220x1380860409_clo;
V g_prelude_2efind_24s1996057548x665004299(V, V);
V g_prelude_2efind_24s1996057548x665004299_entry(V self, V *a);
extern Clo g_prelude_2efind_24s1996057548x665004299_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1046327220x1508260955(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2efoldl_24s1046327220x1508260955_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1046327220x1508260955_clo;
V g_prelude_2efoldl_24s1053087238x1725706605(V, V);
V g_prelude_2efoldl_24s1053087238x1725706605_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1053087238x1725706605_clo;
V g_prelude_2efoldl_24s1053521454x4814067(V, V);
V g_prelude_2efoldl_24s1053521454x4814067_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1053521454x4814067_clo;
V g_prelude_2efoldl_24s1064255209x1797926961(V, V);
V g_prelude_2efoldl_24s1064255209x1797926961_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1064255209x1797926961_clo;
V g_prelude_2efoldl_24s1075493002x264635373(V, V, V, V, V);
V g_prelude_2efoldl_24s1075493002x264635373_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1075493002x264635373_clo;
V g_prelude_2efoldl_24s1105146645x999250186(V, V, V);
V g_prelude_2efoldl_24s1105146645x999250186_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1105146645x999250186_clo;
V g_prelude_2efoldl_24s1117851236x353501360(V, V);
V g_prelude_2efoldl_24s1117851236x353501360_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1117851236x353501360_clo;
V g_prelude_2efoldl_24s1163606919x177582362(V, V);
V g_prelude_2efoldl_24s1163606919x177582362_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1163606919x177582362_clo;
V g_prelude_2efoldl_24s1176465913x1306324629(V, V);
V g_prelude_2efoldl_24s1176465913x1306324629_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1176465913x1306324629_clo;
V g_prelude_2efoldl_24s1205656800x1876272428(V, V);
V g_prelude_2efoldl_24s1205656800x1876272428_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1205656800x1876272428_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s124340812x1866980185(V, V);
V g_prelude_2efoldl_24s124340812x1866980185_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s124340812x1866980185_clo;
V g_prelude_2efoldl_24s1249505547x1425104476(V, V);
V g_prelude_2efoldl_24s1249505547x1425104476_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1249505547x1425104476_clo;
V g_prelude_2efoldl_24s1262644577x604058569(V, V);
V g_prelude_2efoldl_24s1262644577x604058569_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1262644577x604058569_clo;
V g_prelude_2efoldl_24s1316058048x1858230739(V, V);
V g_prelude_2efoldl_24s1316058048x1858230739_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1316058048x1858230739_clo;
V g_prelude_2efoldl_24s1357015314x1549495538(V, V);
V g_prelude_2efoldl_24s1357015314x1549495538_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1357015314x1549495538_clo;
V g_prelude_2efoldl_24s1357790075x1883916922(V, V);
V g_prelude_2efoldl_24s1357790075x1883916922_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1357790075x1883916922_clo;
V g_prelude_2efoldl_24s1377741640x1185496867(V, V);
V g_prelude_2efoldl_24s1377741640x1185496867_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1377741640x1185496867_clo;
V g_prelude_2efoldl_24s1389621742x246323093(V, V);
V g_prelude_2efoldl_24s1389621742x246323093_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1389621742x246323093_clo;
V g_prelude_2efoldl_24s1392147342x903269690(V, V);
V g_prelude_2efoldl_24s1392147342x903269690_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1392147342x903269690_clo;
V g_prelude_2efoldl_24s1431458237x755517792(V, V);
V g_prelude_2efoldl_24s1431458237x755517792_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1431458237x755517792_clo;
V g_prelude_2efoldl_24s1444443463x1097393542(V, V);
V g_prelude_2efoldl_24s1444443463x1097393542_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1444443463x1097393542_clo;
V g_prelude_2efoldl_24s1445726280x1015515073(V, V);
V g_prelude_2efoldl_24s1445726280x1015515073_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1445726280x1015515073_clo;
V g_prelude_2efoldl_24s1484914594x961890250(V, V);
V g_prelude_2efoldl_24s1484914594x961890250_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1484914594x961890250_clo;
V g_prelude_2efoldl_24s1492741819x1368648142(V, V, V, V, V, V, V, V, V);
V g_prelude_2efoldl_24s1492741819x1368648142_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1492741819x1368648142_clo;
V g_prelude_2efoldl_24s1519881281x245433162(V, V);
V g_prelude_2efoldl_24s1519881281x245433162_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1519881281x245433162_clo;
V g_prelude_2efoldl_24s1526645111x1945750140(V, V, V);
V g_prelude_2efoldl_24s1526645111x1945750140_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1526645111x1945750140_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1576253813x218506563(V, V);
V g_prelude_2efoldl_24s1576253813x218506563_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1576253813x218506563_clo;
V g_prelude_2efoldl_24s161191159x1526680900(V, V, V);
V g_prelude_2efoldl_24s161191159x1526680900_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s161191159x1526680900_clo;
V g_prelude_2efoldl_24s1646985801x1714719388(V, V);
V g_prelude_2efoldl_24s1646985801x1714719388_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1646985801x1714719388_clo;
V g_prelude_2efoldl_24s1673264634x1364192364(V, V);
V g_prelude_2efoldl_24s1673264634x1364192364_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1673264634x1364192364_clo;
V g_prelude_2efoldl_24s1700457534x694272192(V, V);
V g_prelude_2efoldl_24s1700457534x694272192_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1700457534x694272192_clo;
V g_prelude_2efoldl_24s1711014586x982785069(V, V);
V g_prelude_2efoldl_24s1711014586x982785069_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1711014586x982785069_clo;
V g_prelude_2efoldl_24s1736949044x1572399628(V, V);
V g_prelude_2efoldl_24s1736949044x1572399628_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1736949044x1572399628_clo;
V g_prelude_2efoldl_24s1766835601x1856285269(V, V);
V g_prelude_2efoldl_24s1766835601x1856285269_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1766835601x1856285269_clo;
V g_prelude_2efoldl_24s1793737101x1852648432(V, V);
V g_prelude_2efoldl_24s1793737101x1852648432_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1793737101x1852648432_clo;
V g_prelude_2efoldl_24s1820263712x281039405(V, V, V);
V g_prelude_2efoldl_24s1820263712x281039405_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1820263712x281039405_clo;
V g_prelude_2efoldl_24s1822565136x94632375(V, V);
V g_prelude_2efoldl_24s1822565136x94632375_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1822565136x94632375_clo;
V g_prelude_2efoldl_24s1838030138x788027388(V, V);
V g_prelude_2efoldl_24s1838030138x788027388_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1838030138x788027388_clo;
V g_prelude_2efoldl_24s1853020597x2079987308(V, V);
V g_prelude_2efoldl_24s1853020597x2079987308_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1853020597x2079987308_clo;
V g_prelude_2efoldl_24s1922900173x1150302326(V, V);
V g_prelude_2efoldl_24s1922900173x1150302326_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1922900173x1150302326_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2efoldl_24s1945742092x1723113759(V, V);
V g_prelude_2efoldl_24s1945742092x1723113759_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1945742092x1723113759_clo;
V g_prelude_2efoldl_24s1973736539x1572903678(V, V, V);
V g_prelude_2efoldl_24s1973736539x1572903678_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1973736539x1572903678_clo;
V g_prelude_2efoldl_24s1999424249x920937090(V, V);
V g_prelude_2efoldl_24s1999424249x920937090_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1999424249x920937090_clo;
V g_prelude_2efoldl_24s2013519703x136854689(V, V);
V g_prelude_2efoldl_24s2013519703x136854689_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2013519703x136854689_clo;
V g_prelude_2efoldl_24s2029768733x1302724432(V, V);
V g_prelude_2efoldl_24s2029768733x1302724432_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2029768733x1302724432_clo;
V g_prelude_2efoldl_24s2083806868x1400260102(V, V);
V g_prelude_2efoldl_24s2083806868x1400260102_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2083806868x1400260102_clo;
V g_prelude_2efoldl_24s2095293338x1796005627(V, V);
V g_prelude_2efoldl_24s2095293338x1796005627_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2095293338x1796005627_clo;
V g_prelude_2efoldl_24s2095412982x241182197(V, V);
V g_prelude_2efoldl_24s2095412982x241182197_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2095412982x241182197_clo;
V g_prelude_2efoldl_24s2097992228x1423179758(V, V, V, V);
V g_prelude_2efoldl_24s2097992228x1423179758_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2097992228x1423179758_clo;
V g_prelude_2efoldl_24s2108860153x2035442283(V, V);
V g_prelude_2efoldl_24s2108860153x2035442283_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2108860153x2035442283_clo;
V g_prelude_2efoldl_24s2112793642x1092684128(V, V);
V g_prelude_2efoldl_24s2112793642x1092684128_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2112793642x1092684128_clo;
V g_prelude_2efoldl_24s232250958x604861464(V, V);
V g_prelude_2efoldl_24s232250958x604861464_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s232250958x604861464_clo;
V g_prelude_2efoldl_24s237886021x1218291248(V, V);
V g_prelude_2efoldl_24s237886021x1218291248_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s237886021x1218291248_clo;
V g_prelude_2efoldl_24s279165385x1755149541(V, V);
V g_prelude_2efoldl_24s279165385x1755149541_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s279165385x1755149541_clo;
V g_prelude_2efoldl_24s279777603x1686732349(V, V);
V g_prelude_2efoldl_24s279777603x1686732349_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s279777603x1686732349_clo;
V g_prelude_2efoldl_24s350630889x2058245268(V, V);
V g_prelude_2efoldl_24s350630889x2058245268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s350630889x2058245268_clo;
V g_prelude_2efoldl_24s403972348x911066463(V, V);
V g_prelude_2efoldl_24s403972348x911066463_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s403972348x911066463_clo;
V g_prelude_2efoldl_24s456121611x843305022(V, V);
V g_prelude_2efoldl_24s456121611x843305022_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s456121611x843305022_clo;
V g_prelude_2efoldl_24s466644717x1386269885(V, V);
V g_prelude_2efoldl_24s466644717x1386269885_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s466644717x1386269885_clo;
V g_prelude_2efoldl_24s495138018x796798243(V, V);
V g_prelude_2efoldl_24s495138018x796798243_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s495138018x796798243_clo;
V g_prelude_2efoldl_24s501072750x238687786(V, V);
V g_prelude_2efoldl_24s501072750x238687786_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s501072750x238687786_clo;
V g_prelude_2efoldl_24s506072539x1484723861(V, V);
V g_prelude_2efoldl_24s506072539x1484723861_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s506072539x1484723861_clo;
V g_prelude_2efoldl_24s50628766x1053431923(V, V);
V g_prelude_2efoldl_24s50628766x1053431923_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s50628766x1053431923_clo;
V g_prelude_2efoldl_24s531085679x1988854183(V, V);
V g_prelude_2efoldl_24s531085679x1988854183_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s531085679x1988854183_clo;
V g_prelude_2efoldl_24s551054150x174860098(V, V);
V g_prelude_2efoldl_24s551054150x174860098_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s551054150x174860098_clo;
V g_prelude_2efoldl_24s590241118x1980030762(V, V);
V g_prelude_2efoldl_24s590241118x1980030762_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s590241118x1980030762_clo;
V g_prelude_2efoldl_24s604575616x906292544(V, V);
V g_prelude_2efoldl_24s604575616x906292544_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s604575616x906292544_clo;
V g_prelude_2efoldl_24s623933082x1825074454(V, V);
V g_prelude_2efoldl_24s623933082x1825074454_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s623933082x1825074454_clo;
V g_prelude_2efoldl_24s656731303x133259214(V, V, V, V);
V g_prelude_2efoldl_24s656731303x133259214_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s656731303x133259214_clo;
V g_prelude_2efoldl_24s672667169x1604568063(V, V, V, V);
V g_prelude_2efoldl_24s672667169x1604568063_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s672667169x1604568063_clo;
V g_prelude_2efoldl_24s676400863x2047065740(V, V);
V g_prelude_2efoldl_24s676400863x2047065740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s676400863x2047065740_clo;
V g_prelude_2efoldl_24s678795091x847683496(V, V);
V g_prelude_2efoldl_24s678795091x847683496_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s678795091x847683496_clo;
V g_prelude_2efoldl_24s680066967x839815107(V, V);
V g_prelude_2efoldl_24s680066967x839815107_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s680066967x839815107_clo;
V g_prelude_2efoldl_24s681048622x785935498(V, V);
V g_prelude_2efoldl_24s681048622x785935498_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s681048622x785935498_clo;
V g_prelude_2efoldl_24s701395232x704703097(V, V);
V g_prelude_2efoldl_24s701395232x704703097_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s701395232x704703097_clo;
V g_prelude_2efoldl_24s769801084x309638513(V, V);
V g_prelude_2efoldl_24s769801084x309638513_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s769801084x309638513_clo;
V g_prelude_2efoldl_24s803210893x1036700122(V, V);
V g_prelude_2efoldl_24s803210893x1036700122_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s803210893x1036700122_clo;
V g_prelude_2efoldl_24s809825463x1159518974(V, V, V, V, V);
V g_prelude_2efoldl_24s809825463x1159518974_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s809825463x1159518974_clo;
V g_prelude_2efoldl_24s816873524x558560359(V, V);
V g_prelude_2efoldl_24s816873524x558560359_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s816873524x558560359_clo;
V g_prelude_2efoldl_24s819361743x1297375170(V, V);
V g_prelude_2efoldl_24s819361743x1297375170_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s819361743x1297375170_clo;
V g_prelude_2efoldl_24s847320519x792667925(V, V);
V g_prelude_2efoldl_24s847320519x792667925_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s847320519x792667925_clo;
V g_prelude_2efoldl_24s848659184x39013903(V, V);
V g_prelude_2efoldl_24s848659184x39013903_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s848659184x39013903_clo;
V g_prelude_2efoldl_24s864016152x1913649801(V, V);
V g_prelude_2efoldl_24s864016152x1913649801_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s864016152x1913649801_clo;
V g_prelude_2efoldl_24s87535414x694612571(V, V);
V g_prelude_2efoldl_24s87535414x694612571_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s87535414x694612571_clo;
V g_prelude_2efoldl_24s896300760x849537974(V, V);
V g_prelude_2efoldl_24s896300760x849537974_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s896300760x849537974_clo;
V g_prelude_2efoldl_24s909551427x1807771490(V, V);
V g_prelude_2efoldl_24s909551427x1807771490_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s909551427x1807771490_clo;
V g_prelude_2efoldl_24s984477481x2143447432(V, V);
V g_prelude_2efoldl_24s984477481x2143447432_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s984477481x2143447432_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2elookupBy(V, V, V);
V g_prelude_2elookupBy_entry(V self, V *a);
extern Clo g_prelude_2elookupBy_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1020043107x1371161197(V);
V g_prelude_2emap_24s1020043107x1371161197_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1020043107x1371161197_clo;
V g_prelude_2emap_24s1042490692x1702390136(V);
V g_prelude_2emap_24s1042490692x1702390136_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1042490692x1702390136_clo;
V g_prelude_2emap_24s1042627293x2039157317(V, V, V, V, V, V, V);
V g_prelude_2emap_24s1042627293x2039157317_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1042627293x2039157317_clo;
V g_prelude_2emap_24s1046782722x1317586010(V, V, V, V, V, V, V, V, V, V, V);
V g_prelude_2emap_24s1046782722x1317586010_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1046782722x1317586010_clo;
V g_prelude_2emap_24s1073181564x1056668167(V, V, V, V, V);
V g_prelude_2emap_24s1073181564x1056668167_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1073181564x1056668167_clo;
V g_prelude_2emap_24s1083963057x1681851055(V);
V g_prelude_2emap_24s1083963057x1681851055_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1083963057x1681851055_clo;
V g_prelude_2emap_24s1097491904x416138181(V);
V g_prelude_2emap_24s1097491904x416138181_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1097491904x416138181_clo;
V g_prelude_2emap_24s1105939642x992420831(V, V, V, V, V, V, V);
V g_prelude_2emap_24s1105939642x992420831_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1105939642x992420831_clo;
V g_prelude_2emap_24s1170054603x901729204(V);
V g_prelude_2emap_24s1170054603x901729204_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1170054603x901729204_clo;
V g_prelude_2emap_24s1213322018x576418267(V);
V g_prelude_2emap_24s1213322018x576418267_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1213322018x576418267_clo;
V g_prelude_2emap_24s1224661136x1529143690(V);
V g_prelude_2emap_24s1224661136x1529143690_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1224661136x1529143690_clo;
V g_prelude_2emap_24s1248084495x1713083677(V, V, V, V, V, V);
V g_prelude_2emap_24s1248084495x1713083677_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1248084495x1713083677_clo;
V g_prelude_2emap_24s1276521852x477277004(V);
V g_prelude_2emap_24s1276521852x477277004_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1276521852x477277004_clo;
V g_prelude_2emap_24s1295898052x1915853031(V);
V g_prelude_2emap_24s1295898052x1915853031_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1295898052x1915853031_clo;
V g_prelude_2emap_24s1304302839x769116801(V);
V g_prelude_2emap_24s1304302839x769116801_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1304302839x769116801_clo;
V g_prelude_2emap_24s1309194388x1478532932(V);
V g_prelude_2emap_24s1309194388x1478532932_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1309194388x1478532932_clo;
V g_prelude_2emap_24s1319686775x2043462729(V);
V g_prelude_2emap_24s1319686775x2043462729_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1319686775x2043462729_clo;
V g_prelude_2emap_24s1338266682x1095943031(V, V, V, V);
V g_prelude_2emap_24s1338266682x1095943031_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1338266682x1095943031_clo;
V g_prelude_2emap_24s1340987657x1082998826(V);
V g_prelude_2emap_24s1340987657x1082998826_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1340987657x1082998826_clo;
V g_prelude_2emap_24s1375608508x1745238686(V);
V g_prelude_2emap_24s1375608508x1745238686_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1375608508x1745238686_clo;
V g_prelude_2emap_24s1376040924x483198033(V);
V g_prelude_2emap_24s1376040924x483198033_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1376040924x483198033_clo;
V g_prelude_2emap_24s1384090898x1957594759(V);
V g_prelude_2emap_24s1384090898x1957594759_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1384090898x1957594759_clo;
V g_prelude_2emap_24s1410920902x1892852593(V, V, V, V);
V g_prelude_2emap_24s1410920902x1892852593_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1410920902x1892852593_clo;
V g_prelude_2emap_24s1429136355x479526015(V, V);
V g_prelude_2emap_24s1429136355x479526015_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1429136355x479526015_clo;
V g_prelude_2emap_24s1439972680x346961496(V);
V g_prelude_2emap_24s1439972680x346961496_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1439972680x346961496_clo;
V g_prelude_2emap_24s1448703749x94773476(V);
V g_prelude_2emap_24s1448703749x94773476_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1448703749x94773476_clo;
V g_prelude_2emap_24s1449394102x85632237(V);
V g_prelude_2emap_24s1449394102x85632237_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1449394102x85632237_clo;
V g_prelude_2emap_24s1457492563x2144644264(V);
V g_prelude_2emap_24s1457492563x2144644264_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1457492563x2144644264_clo;
V g_prelude_2emap_24s1465322528x1075776197(V);
V g_prelude_2emap_24s1465322528x1075776197_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1465322528x1075776197_clo;
V g_prelude_2emap_24s1465695349x56206694(V, V);
V g_prelude_2emap_24s1465695349x56206694_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1465695349x56206694_clo;
V g_prelude_2emap_24s1472739944x318103388(V);
V g_prelude_2emap_24s1472739944x318103388_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1472739944x318103388_clo;
V g_prelude_2emap_24s1479019137x857976527(V);
V g_prelude_2emap_24s1479019137x857976527_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1479019137x857976527_clo;
V g_prelude_2emap_24s1487602620x924655663(V);
V g_prelude_2emap_24s1487602620x924655663_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1487602620x924655663_clo;
V g_prelude_2emap_24s1491261851x220013917(V);
V g_prelude_2emap_24s1491261851x220013917_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1491261851x220013917_clo;
V g_prelude_2emap_24s1504295295x438292075(V);
V g_prelude_2emap_24s1504295295x438292075_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1504295295x438292075_clo;
V g_prelude_2emap_24s15155233x988412698(V);
V g_prelude_2emap_24s15155233x988412698_entry(V self, V *a);
extern Clo g_prelude_2emap_24s15155233x988412698_clo;
V g_prelude_2emap_24s1530006173x935542988(V);
V g_prelude_2emap_24s1530006173x935542988_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1530006173x935542988_clo;
V g_prelude_2emap_24s1537567598x716246174(V, V, V);
V g_prelude_2emap_24s1537567598x716246174_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1537567598x716246174_clo;
V g_prelude_2emap_24s1548800724x1090490128(V);
V g_prelude_2emap_24s1548800724x1090490128_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1548800724x1090490128_clo;
V g_prelude_2emap_24s1557394611x1393897318(V);
V g_prelude_2emap_24s1557394611x1393897318_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1557394611x1393897318_clo;
V g_prelude_2emap_24s1559710030x546042594(V, V);
V g_prelude_2emap_24s1559710030x546042594_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1559710030x546042594_clo;
V g_prelude_2emap_24s1570887738x875765683(V);
V g_prelude_2emap_24s1570887738x875765683_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1570887738x875765683_clo;
V g_prelude_2emap_24s1581021428x1223114127(V);
V g_prelude_2emap_24s1581021428x1223114127_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1581021428x1223114127_clo;
V g_prelude_2emap_24s1632715577x1165353341(V, V, V, V);
V g_prelude_2emap_24s1632715577x1165353341_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1632715577x1165353341_clo;
V g_prelude_2emap_24s1637992403x1199034636(V);
V g_prelude_2emap_24s1637992403x1199034636_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1637992403x1199034636_clo;
V g_prelude_2emap_24s1639847025x48103675(V);
V g_prelude_2emap_24s1639847025x48103675_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1639847025x48103675_clo;
V g_prelude_2emap_24s1645030849x525483621(V);
V g_prelude_2emap_24s1645030849x525483621_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1645030849x525483621_clo;
V g_prelude_2emap_24s1647342657x2122972612(V);
V g_prelude_2emap_24s1647342657x2122972612_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1647342657x2122972612_clo;
V g_prelude_2emap_24s1662385255x221899605(V);
V g_prelude_2emap_24s1662385255x221899605_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1662385255x221899605_clo;
V g_prelude_2emap_24s1670578341x1649699234(V, V);
V g_prelude_2emap_24s1670578341x1649699234_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1670578341x1649699234_clo;
V g_prelude_2emap_24s1681132721x1100845580(V);
V g_prelude_2emap_24s1681132721x1100845580_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1681132721x1100845580_clo;
V g_prelude_2emap_24s1687423457x355380534(V);
V g_prelude_2emap_24s1687423457x355380534_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1687423457x355380534_clo;
V g_prelude_2emap_24s1688359605x701894798(V);
V g_prelude_2emap_24s1688359605x701894798_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1688359605x701894798_clo;
V g_prelude_2emap_24s1694032985x57198631(V);
V g_prelude_2emap_24s1694032985x57198631_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1694032985x57198631_clo;
V g_prelude_2emap_24s1716181342x353410538(V);
V g_prelude_2emap_24s1716181342x353410538_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1716181342x353410538_clo;
V g_prelude_2emap_24s173337351x1152519035(V, V, V, V);
V g_prelude_2emap_24s173337351x1152519035_entry(V self, V *a);
extern Clo g_prelude_2emap_24s173337351x1152519035_clo;
V g_prelude_2emap_24s17448335x896291650(V);
V g_prelude_2emap_24s17448335x896291650_entry(V self, V *a);
extern Clo g_prelude_2emap_24s17448335x896291650_clo;
V g_prelude_2emap_24s1749182240x1466970014(V);
V g_prelude_2emap_24s1749182240x1466970014_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1749182240x1466970014_clo;
V g_prelude_2emap_24s175191143x639839450(V);
V g_prelude_2emap_24s175191143x639839450_entry(V self, V *a);
extern Clo g_prelude_2emap_24s175191143x639839450_clo;
V g_prelude_2emap_24s1774533623x1679457808(V);
V g_prelude_2emap_24s1774533623x1679457808_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1774533623x1679457808_clo;
V g_prelude_2emap_24s1777922978x1620890802(V, V, V, V, V, V, V, V);
V g_prelude_2emap_24s1777922978x1620890802_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1777922978x1620890802_clo;
V g_prelude_2emap_24s1792226203x1962008905(V, V, V, V, V, V, V);
V g_prelude_2emap_24s1792226203x1962008905_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1792226203x1962008905_clo;
V g_prelude_2emap_24s1814443606x828128923(V, V);
V g_prelude_2emap_24s1814443606x828128923_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1814443606x828128923_clo;
V g_prelude_2emap_24s1843312214x961377872(V);
V g_prelude_2emap_24s1843312214x961377872_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1843312214x961377872_clo;
V g_prelude_2emap_24s1853832113x1514640231(V);
V g_prelude_2emap_24s1853832113x1514640231_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1853832113x1514640231_clo;
V g_prelude_2emap_24s1865958870x1922568484(V);
V g_prelude_2emap_24s1865958870x1922568484_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1865958870x1922568484_clo;
V g_prelude_2emap_24s1867549772x132002572(V, V, V, V, V, V);
V g_prelude_2emap_24s1867549772x132002572_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1867549772x132002572_clo;
V g_prelude_2emap_24s1877418456x1713671328(V);
V g_prelude_2emap_24s1877418456x1713671328_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1877418456x1713671328_clo;
V g_prelude_2emap_24s1915255123x866970157(V, V, V);
V g_prelude_2emap_24s1915255123x866970157_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1915255123x866970157_clo;
V g_prelude_2emap_24s1921933910x1036692167(V, V);
V g_prelude_2emap_24s1921933910x1036692167_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1921933910x1036692167_clo;
V g_prelude_2emap_24s1929921403x2017858336(V);
V g_prelude_2emap_24s1929921403x2017858336_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1929921403x2017858336_clo;
V g_prelude_2emap_24s200728978x966202520(V);
V g_prelude_2emap_24s200728978x966202520_entry(V self, V *a);
extern Clo g_prelude_2emap_24s200728978x966202520_clo;
V g_prelude_2emap_24s2025198057x415178258(V);
V g_prelude_2emap_24s2025198057x415178258_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2025198057x415178258_clo;
V g_prelude_2emap_24s2054100617x1212500015(V, V, V, V);
V g_prelude_2emap_24s2054100617x1212500015_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2054100617x1212500015_clo;
V g_prelude_2emap_24s2082593756x791667152(V);
V g_prelude_2emap_24s2082593756x791667152_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2082593756x791667152_clo;
V g_prelude_2emap_24s2083806615x1058260173(V);
V g_prelude_2emap_24s2083806615x1058260173_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2083806615x1058260173_clo;
V g_prelude_2emap_24s211374770x467200965(V, V, V, V, V, V);
V g_prelude_2emap_24s211374770x467200965_entry(V self, V *a);
extern Clo g_prelude_2emap_24s211374770x467200965_clo;
V g_prelude_2emap_24s211672092x1360624114(V);
V g_prelude_2emap_24s211672092x1360624114_entry(V self, V *a);
extern Clo g_prelude_2emap_24s211672092x1360624114_clo;
V g_prelude_2emap_24s2124417180x1682105150(V);
V g_prelude_2emap_24s2124417180x1682105150_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2124417180x1682105150_clo;
V g_prelude_2emap_24s2130727578x764334370(V);
V g_prelude_2emap_24s2130727578x764334370_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2130727578x764334370_clo;
V g_prelude_2emap_24s2144452760x1823476610(V);
V g_prelude_2emap_24s2144452760x1823476610_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2144452760x1823476610_clo;
V g_prelude_2emap_24s229671972x1653917392(V);
V g_prelude_2emap_24s229671972x1653917392_entry(V self, V *a);
extern Clo g_prelude_2emap_24s229671972x1653917392_clo;
V g_prelude_2emap_24s242074595x1610727405(V, V, V, V, V, V, V);
V g_prelude_2emap_24s242074595x1610727405_entry(V self, V *a);
extern Clo g_prelude_2emap_24s242074595x1610727405_clo;
V g_prelude_2emap_24s246962053x1319174229(V, V);
V g_prelude_2emap_24s246962053x1319174229_entry(V self, V *a);
extern Clo g_prelude_2emap_24s246962053x1319174229_clo;
V g_prelude_2emap_24s265029017x1822716883(V);
V g_prelude_2emap_24s265029017x1822716883_entry(V self, V *a);
extern Clo g_prelude_2emap_24s265029017x1822716883_clo;
V g_prelude_2emap_24s271878692x1909813941(V);
V g_prelude_2emap_24s271878692x1909813941_entry(V self, V *a);
extern Clo g_prelude_2emap_24s271878692x1909813941_clo;
V g_prelude_2emap_24s291974946x1668376991(V);
V g_prelude_2emap_24s291974946x1668376991_entry(V self, V *a);
extern Clo g_prelude_2emap_24s291974946x1668376991_clo;
V g_prelude_2emap_24s297378115x1885194799(V);
V g_prelude_2emap_24s297378115x1885194799_entry(V self, V *a);
extern Clo g_prelude_2emap_24s297378115x1885194799_clo;
V g_prelude_2emap_24s350412458x837611148(V, V);
V g_prelude_2emap_24s350412458x837611148_entry(V self, V *a);
extern Clo g_prelude_2emap_24s350412458x837611148_clo;
V g_prelude_2emap_24s354657900x1587558784(V);
V g_prelude_2emap_24s354657900x1587558784_entry(V self, V *a);
extern Clo g_prelude_2emap_24s354657900x1587558784_clo;
V g_prelude_2emap_24s399995414x989248031(V, V, V);
V g_prelude_2emap_24s399995414x989248031_entry(V self, V *a);
extern Clo g_prelude_2emap_24s399995414x989248031_clo;
V g_prelude_2emap_24s403955490x958947996(V, V, V, V, V, V, V);
V g_prelude_2emap_24s403955490x958947996_entry(V self, V *a);
extern Clo g_prelude_2emap_24s403955490x958947996_clo;
V g_prelude_2emap_24s404693216x603828942(V, V, V, V);
V g_prelude_2emap_24s404693216x603828942_entry(V self, V *a);
extern Clo g_prelude_2emap_24s404693216x603828942_clo;
V g_prelude_2emap_24s490045439x1540849353(V, V);
V g_prelude_2emap_24s490045439x1540849353_entry(V self, V *a);
extern Clo g_prelude_2emap_24s490045439x1540849353_clo;
V g_prelude_2emap_24s494516475x121191125(V);
V g_prelude_2emap_24s494516475x121191125_entry(V self, V *a);
extern Clo g_prelude_2emap_24s494516475x121191125_clo;
V g_prelude_2emap_24s504509305x1309437118(V);
V g_prelude_2emap_24s504509305x1309437118_entry(V self, V *a);
extern Clo g_prelude_2emap_24s504509305x1309437118_clo;
V g_prelude_2emap_24s52210753x799200641(V);
V g_prelude_2emap_24s52210753x799200641_entry(V self, V *a);
extern Clo g_prelude_2emap_24s52210753x799200641_clo;
V g_prelude_2emap_24s531459667x996402587(V);
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a);
extern Clo g_prelude_2emap_24s531459667x996402587_clo;
V g_prelude_2emap_24s534301229x255644933(V);
V g_prelude_2emap_24s534301229x255644933_entry(V self, V *a);
extern Clo g_prelude_2emap_24s534301229x255644933_clo;
V g_prelude_2emap_24s546221959x1645923250(V);
V g_prelude_2emap_24s546221959x1645923250_entry(V self, V *a);
extern Clo g_prelude_2emap_24s546221959x1645923250_clo;
V g_prelude_2emap_24s554277126x598800825(V);
V g_prelude_2emap_24s554277126x598800825_entry(V self, V *a);
extern Clo g_prelude_2emap_24s554277126x598800825_clo;
V g_prelude_2emap_24s566279366x471477086(V, V);
V g_prelude_2emap_24s566279366x471477086_entry(V self, V *a);
extern Clo g_prelude_2emap_24s566279366x471477086_clo;
V g_prelude_2emap_24s588898442x1763987159(V);
V g_prelude_2emap_24s588898442x1763987159_entry(V self, V *a);
extern Clo g_prelude_2emap_24s588898442x1763987159_clo;
V g_prelude_2emap_24s597794505x1651330542(V, V, V, V, V, V, V);
V g_prelude_2emap_24s597794505x1651330542_entry(V self, V *a);
extern Clo g_prelude_2emap_24s597794505x1651330542_clo;
V g_prelude_2emap_24s60916294x70162967(V);
V g_prelude_2emap_24s60916294x70162967_entry(V self, V *a);
extern Clo g_prelude_2emap_24s60916294x70162967_clo;
V g_prelude_2emap_24s612293031x749451349(V);
V g_prelude_2emap_24s612293031x749451349_entry(V self, V *a);
extern Clo g_prelude_2emap_24s612293031x749451349_clo;
V g_prelude_2emap_24s615600838x450168446(V, V);
V g_prelude_2emap_24s615600838x450168446_entry(V self, V *a);
extern Clo g_prelude_2emap_24s615600838x450168446_clo;
V g_prelude_2emap_24s64875302x2104538803(V);
V g_prelude_2emap_24s64875302x2104538803_entry(V self, V *a);
extern Clo g_prelude_2emap_24s64875302x2104538803_clo;
V g_prelude_2emap_24s651029960x996908055(V);
V g_prelude_2emap_24s651029960x996908055_entry(V self, V *a);
extern Clo g_prelude_2emap_24s651029960x996908055_clo;
V g_prelude_2emap_24s651634357x426945616(V);
V g_prelude_2emap_24s651634357x426945616_entry(V self, V *a);
extern Clo g_prelude_2emap_24s651634357x426945616_clo;
V g_prelude_2emap_24s656438675x1758438999(V, V, V, V, V);
V g_prelude_2emap_24s656438675x1758438999_entry(V self, V *a);
extern Clo g_prelude_2emap_24s656438675x1758438999_clo;
V g_prelude_2emap_24s6666188x1439341245(V);
V g_prelude_2emap_24s6666188x1439341245_entry(V self, V *a);
extern Clo g_prelude_2emap_24s6666188x1439341245_clo;
V g_prelude_2emap_24s67362943x99565768(V);
V g_prelude_2emap_24s67362943x99565768_entry(V self, V *a);
extern Clo g_prelude_2emap_24s67362943x99565768_clo;
V g_prelude_2emap_24s684503405x117589606(V);
V g_prelude_2emap_24s684503405x117589606_entry(V self, V *a);
extern Clo g_prelude_2emap_24s684503405x117589606_clo;
V g_prelude_2emap_24s687737756x1010305734(V);
V g_prelude_2emap_24s687737756x1010305734_entry(V self, V *a);
extern Clo g_prelude_2emap_24s687737756x1010305734_clo;
V g_prelude_2emap_24s69486363x771070912(V, V, V, V, V, V);
V g_prelude_2emap_24s69486363x771070912_entry(V self, V *a);
extern Clo g_prelude_2emap_24s69486363x771070912_clo;
V g_prelude_2emap_24s697897431x2046530597(V);
V g_prelude_2emap_24s697897431x2046530597_entry(V self, V *a);
extern Clo g_prelude_2emap_24s697897431x2046530597_clo;
V g_prelude_2emap_24s706234375x797630515(V);
V g_prelude_2emap_24s706234375x797630515_entry(V self, V *a);
extern Clo g_prelude_2emap_24s706234375x797630515_clo;
V g_prelude_2emap_24s714974688x1763196797(V);
V g_prelude_2emap_24s714974688x1763196797_entry(V self, V *a);
extern Clo g_prelude_2emap_24s714974688x1763196797_clo;
V g_prelude_2emap_24s751962069x1815060025(V);
V g_prelude_2emap_24s751962069x1815060025_entry(V self, V *a);
extern Clo g_prelude_2emap_24s751962069x1815060025_clo;
V g_prelude_2emap_24s752906154x1709852375(V, V, V);
V g_prelude_2emap_24s752906154x1709852375_entry(V self, V *a);
extern Clo g_prelude_2emap_24s752906154x1709852375_clo;
V g_prelude_2emap_24s760761549x776536213(V);
V g_prelude_2emap_24s760761549x776536213_entry(V self, V *a);
extern Clo g_prelude_2emap_24s760761549x776536213_clo;
V g_prelude_2emap_24s764047539x1158385979(V);
V g_prelude_2emap_24s764047539x1158385979_entry(V self, V *a);
extern Clo g_prelude_2emap_24s764047539x1158385979_clo;
V g_prelude_2emap_24s772488398x992379409(V);
V g_prelude_2emap_24s772488398x992379409_entry(V self, V *a);
extern Clo g_prelude_2emap_24s772488398x992379409_clo;
V g_prelude_2emap_24s7771255x22951525(V);
V g_prelude_2emap_24s7771255x22951525_entry(V self, V *a);
extern Clo g_prelude_2emap_24s7771255x22951525_clo;
V g_prelude_2emap_24s792566809x1637979488(V, V);
V g_prelude_2emap_24s792566809x1637979488_entry(V self, V *a);
extern Clo g_prelude_2emap_24s792566809x1637979488_clo;
V g_prelude_2emap_24s816432673x804125000(V);
V g_prelude_2emap_24s816432673x804125000_entry(V self, V *a);
extern Clo g_prelude_2emap_24s816432673x804125000_clo;
V g_prelude_2emap_24s842967967x223843022(V);
V g_prelude_2emap_24s842967967x223843022_entry(V self, V *a);
extern Clo g_prelude_2emap_24s842967967x223843022_clo;
V g_prelude_2emap_24s860552613x788263739(V);
V g_prelude_2emap_24s860552613x788263739_entry(V self, V *a);
extern Clo g_prelude_2emap_24s860552613x788263739_clo;
V g_prelude_2emap_24s913954207x1153178935(V);
V g_prelude_2emap_24s913954207x1153178935_entry(V self, V *a);
extern Clo g_prelude_2emap_24s913954207x1153178935_clo;
V g_prelude_2emap_24s914971304x1928750522(V);
V g_prelude_2emap_24s914971304x1928750522_entry(V self, V *a);
extern Clo g_prelude_2emap_24s914971304x1928750522_clo;
V g_prelude_2emap_24s91703316x860383118(V);
V g_prelude_2emap_24s91703316x860383118_entry(V self, V *a);
extern Clo g_prelude_2emap_24s91703316x860383118_clo;
V g_prelude_2emap_24s934124169x1828361008(V, V, V, V, V, V, V, V);
V g_prelude_2emap_24s934124169x1828361008_entry(V self, V *a);
extern Clo g_prelude_2emap_24s934124169x1828361008_clo;
V g_prelude_2emap_24s974831774x882761225(V);
V g_prelude_2emap_24s974831774x882761225_entry(V self, V *a);
extern Clo g_prelude_2emap_24s974831774x882761225_clo;
V g_prelude_2emaybe_24s1564285205x84298940(V, V);
V g_prelude_2emaybe_24s1564285205x84298940_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1564285205x84298940_clo;
V g_prelude_2emerge(V, V, V);
V g_prelude_2emerge_entry(V self, V *a);
extern Clo g_prelude_2emerge_clo;
V g_prelude_2emerge_24s1272611763x329559950(V, V);
V g_prelude_2emerge_24s1272611763x329559950_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s1272611763x329559950_clo;
V g_prelude_2emerge_24s1366678805x1489829848(V, V);
V g_prelude_2emerge_24s1366678805x1489829848_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s1366678805x1489829848_clo;
V g_prelude_2emerge_24s1524561266x851549973(V, V);
V g_prelude_2emerge_24s1524561266x851549973_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s1524561266x851549973_clo;
V g_prelude_2emerge_24s2128431283x1958701110(V, V);
V g_prelude_2emerge_24s2128431283x1958701110_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s2128431283x1958701110_clo;
V g_prelude_2emerge_24s425238775x1129884419(V, V);
V g_prelude_2emerge_24s425238775x1129884419_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s425238775x1129884419_clo;
V g_prelude_2emerge_24s647676823x121149293(V, V);
V g_prelude_2emerge_24s647676823x121149293_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s647676823x121149293_clo;
V g_prelude_2emerge_24s751234234x1956863352(V, V);
V g_prelude_2emerge_24s751234234x1956863352_entry(V self, V *a);
extern Clo g_prelude_2emerge_24s751234234x1956863352_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2erange(V, V);
V g_prelude_2erange_entry(V self, V *a);
extern Clo g_prelude_2erange_clo;
V g_prelude_2ereplicate(V, V);
V g_prelude_2ereplicate_entry(V self, V *a);
extern Clo g_prelude_2ereplicate_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esortBy(V, V);
V g_prelude_2esortBy_entry(V self, V *a);
extern Clo g_prelude_2esortBy_clo;
V g_prelude_2esortBy_24s1126449973x1849170820(V);
V g_prelude_2esortBy_24s1126449973x1849170820_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s1126449973x1849170820_clo;
V g_prelude_2esortBy_24s1510757765x2064206644(V);
V g_prelude_2esortBy_24s1510757765x2064206644_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s1510757765x2064206644_clo;
V g_prelude_2esortBy_24s2011755074x583809521(V);
V g_prelude_2esortBy_24s2011755074x583809521_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s2011755074x583809521_clo;
V g_prelude_2esortBy_24s2054846137x538107791(V);
V g_prelude_2esortBy_24s2054846137x538107791_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s2054846137x538107791_clo;
V g_prelude_2esortBy_24s2110005585x1390303319(V);
V g_prelude_2esortBy_24s2110005585x1390303319_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s2110005585x1390303319_clo;
V g_prelude_2esortBy_24s41792244x2038093117(V);
V g_prelude_2esortBy_24s41792244x2038093117_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s41792244x2038093117_clo;
V g_prelude_2esortBy_24s836118211x1760819460(V);
V g_prelude_2esortBy_24s836118211x1760819460_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s836118211x1760819460_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2etake(V, V);
V g_prelude_2etake_entry(V self, V *a);
extern Clo g_prelude_2etake_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2ezipWith(V, V, V);
V g_prelude_2ezipWith_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_clo;
V g_prelude_2ezipWith_24s1130233364x669931997(V, V);
V g_prelude_2ezipWith_24s1130233364x669931997_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s1130233364x669931997_clo;
V g_prelude_2ezipWith_24s1919317536x560404246(V, V, V, V, V, V, V, V);
V g_prelude_2ezipWith_24s1919317536x560404246_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s1919317536x560404246_clo;
V g_prelude_2ezipWith_24s2068631943x1980308664(V, V);
V g_prelude_2ezipWith_24s2068631943x1980308664_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s2068631943x1980308664_clo;
V g_prelude_2ezipWith_24s265785801x162300510(V, V, V);
V g_prelude_2ezipWith_24s265785801x162300510_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s265785801x162300510_clo;
V g_prelude_2ezipWith_24s380110282x409842715(V, V, V, V, V, V, V, V, V);
V g_prelude_2ezipWith_24s380110282x409842715_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s380110282x409842715_clo;
V g_prelude_2ezipWith_24s63513682x397084279(V, V);
V g_prelude_2ezipWith_24s63513682x397084279_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s63513682x397084279_clo;
V g_prelude_2ezipWith_24s707462069x132290260(V, V);
V g_prelude_2ezipWith_24s707462069x132290260_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s707462069x132290260_clo;
V g_prelude_2ezipWith_24s710811621x1872285139(V, V, V, V, V);
V g_prelude_2ezipWith_24s710811621x1872285139_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s710811621x1872285139_clo;
V g_prelude_2ezipWith_24s836893971x454572333(V, V, V);
V g_prelude_2ezipWith_24s836893971x454572333_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s836893971x454572333_clo;
V g_prelude_2ezipWith_24s843461613x1902654784(V, V);
V g_prelude_2ezipWith_24s843461613x1902654784_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s843461613x1902654784_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_prelude_2emap_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_entry, 2, 0};

V g_prelude_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap(v_f_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap(a[0], a[1]);
}
Clo g_prelude_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_entry, 3, 0};

V g_prelude_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2efoldl_24s1546929672x1472202881_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1546929672x1472202881_entry, 2, 0};

V g_prelude_2efoldl_24s1546929672x1472202881(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1546929672x1472202881(a[0], a[1]);
}
Clo g_prelude_2efilter_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_entry, 2, 0};

V g_prelude_2efilter(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2efilter(v_p_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efilter_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1226147011x367015740_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1226147011x367015740_entry, 3, 0};

V g_prelude_2efoldl_24s1226147011x367015740(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1226147011x367015740(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2econcatList_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2econcatList_entry, 2, 0};

V g_prelude_2econcatList(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2econcatList(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2econcatList_entry(V self, V *a) {
  (void)self;
  return g_prelude_2econcatList(a[0], a[1]);
}
Clo g_prelude_2etake_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etake_entry, 2, 0};

V g_prelude_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2etake(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etake_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etake(a[0], a[1]);
}
Clo g_prelude_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edrop_entry, 2, 0};

V g_prelude_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2edrop_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edrop(a[0], a[1]);
}
Clo g_prelude_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_entry, 3, 0};

V g_prelude_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith(v_f_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith(a[0], a[1], a[2]);
}
Clo g_prelude_2eany_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_entry, 2, 0};

V g_prelude_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2eany_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eall_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_entry, 2, 0};

V g_prelude_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2eall_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efind_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_entry, 2, 0};

V g_prelude_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efind_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2elookupBy_entry, 3, 0};

V g_prelude_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      }
      case TAG_False: {
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2elookupBy_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2elookupBy(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2efoldl_24s279165385x1755149541_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s279165385x1755149541_entry, 2, 0};

V g_prelude_2efoldl_24s279165385x1755149541(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd(v_z_240, heff_dup(v_x_242));
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s279165385x1755149541_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s279165385x1755149541(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2erange_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2erange_entry, 2, 0};

V g_prelude_2erange(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_b_241), heff_dup(v_a_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_240), (g_prelude_2erange(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_prelude_2erange_entry(V self, V *a) {
  (void)self;
  return g_prelude_2erange(a[0], a[1]);
}
Clo g_prelude_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ereplicate_entry, 2, 0};

V g_prelude_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), (g_prelude_2ereplicate(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_prelude_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ereplicate(a[0], a[1]);
}
Clo g_prelude_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_entry, 3, 0};

V g_prelude_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_prelude_2emerge(v_le_240, v_xs2_244, heff_tag(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, (g_prelude_2emerge(v_le_240, heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246))});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2emerge_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge(a[0], a[1], a[2]);
}
Clo g_prelude_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_entry, 2, 0};

V g_prelude_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = heff_intDiv(v_t_246, MK_INT(2LL));
      V v_t_248 = (g_prelude_2etake(v_t_247, heff_dup(v_xs_241)));
      V v_t_249 = (g_prelude_2esortBy(heff_dup(v_le_240), v_t_248));
      V v_t_2410 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2411 = heff_intDiv(v_t_2410, MK_INT(2LL));
      V v_t_2412 = (g_prelude_2edrop(v_t_2411, v_xs_241));
      V v_t_2413 = (g_prelude_2esortBy(heff_dup(v_le_240), v_t_2412));
      return (g_prelude_2emerge(v_le_240, v_t_249, v_t_2413));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy(a[0], a[1]);
}
Clo g_prelude_2eindexFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eindexFrom_entry, 3, 0};

V g_prelude_2eindexFrom(V v_needle_240, V v_s_241, V v_i_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
  V v_t_244 = heff_intLt(heff_strLength(heff_dup(v_s_241)), v_t_243);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_needle_240);
    heff_drop(v_s_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_245 = heff_intAdd(heff_dup(v_i_242), heff_strLength(heff_dup(v_needle_240)));
    V v_t_246 = heff_strEq(heff_strSlice(heff_dup(v_s_241), heff_dup(v_i_242), v_t_245), heff_dup(v_needle_240));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_needle_240);
      heff_drop(v_s_241);
      return heff_tag(TAG_Just, 1, (V[]){v_i_242});
    }
    case TAG_False: {
      V t_0 = v_needle_240;
      V t_1 = v_s_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_needle_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2eindexFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eindexFrom(a[0], a[1], a[2]);
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 4, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(heff_dup(v_sep_240), heff_dup(v_s_241), heff_dup(v_i_242)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_sep_240);
    V v_t_245 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength(v_s_241));
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_acc_243})));
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_dup(v_j_246), heff_strLength(heff_dup(v_sep_240)));
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_241), v_i_242, v_j_246), v_acc_243});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = v_t_248;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esplitFrom(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2efoldl_24s1939305664x1902528268_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1939305664x1902528268_entry, 3, 0};

V g_prelude_2efoldl_24s1939305664x1902528268(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strAppend(v_z_241, heff_strAppend(heff_dup(v_lit_240), heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1939305664x1902528268(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
    V v_xs_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_xs_246 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
      break;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_xs_246 = v_acc_243;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_False: {
    V v_c_247 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_242));
    V v_t_248 = heff_intEq(heff_dup(v_c_247), MK_INT(32LL));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_c_247);
      V v_t_249 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
      V v_t_2410;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop(v_start_241);
        v_t_2410 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_2410;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    case TAG_False: {
      V v_t_2411 = heff_intEq(heff_dup(v_c_247), MK_INT(9LL));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_c_247);
        V v_t_2412 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
        V v_t_2413;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
          break;
        }
        case TAG_False: {
          heff_drop(v_start_241);
          v_t_2413 = v_acc_243;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_t_2413;
        v_s_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_False: {
        V v_t_2414 = heff_intEq(heff_dup(v_c_247), MK_INT(10LL));
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          heff_drop(v_c_247);
          V v_t_2415 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
          V v_t_2416;
          switch (heff_tag_of(v_t_2415)) {
          case TAG_True: {
            v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
            break;
          }
          case TAG_False: {
            heff_drop(v_start_241);
            v_t_2416 = v_acc_243;
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_t_2416;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
        case TAG_False: {
          V v_t_2417 = heff_intEq(v_c_247, MK_INT(13LL));
          switch (heff_tag_of(v_t_2417)) {
          case TAG_True: {
            V v_t_2418 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
            V v_t_2419;
            switch (heff_tag_of(v_t_2418)) {
            case TAG_True: {
              v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
              break;
            }
            case TAG_False: {
              heff_drop(v_start_241);
              v_t_2419 = v_acc_243;
              break;
            }
            default: heff_nomatch(v_t_2418);
            }
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_t_2419;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
          case TAG_False: {
            V t_0 = v_s_240;
            V t_1 = v_start_241;
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_acc_243;
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
          default: return heff_nomatch(v_t_2417);
          }
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ewordsFrom(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_i_241, V v_step_242) {
top: ;
  V v_t_243 = heff_intLe(MK_INT(0LL), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_intLt(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_c_245 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
      V v_t_246 = heff_intEq(heff_dup(v_c_245), MK_INT(32LL));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_c_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
        V t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      }
      case TAG_False: {
        V v_t_247 = heff_intEq(heff_dup(v_c_245), MK_INT(9LL));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_c_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
          V t_2 = v_step_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_step_242 = t_2;
          goto top;
        }
        case TAG_False: {
          V v_t_248 = heff_intEq(heff_dup(v_c_245), MK_INT(10LL));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_c_245);
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
            V t_2 = v_step_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_step_242 = t_2;
            goto top;
          }
          case TAG_False: {
            V v_t_249 = heff_intEq(v_c_245, MK_INT(13LL));
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, heff_dup(v_step_242));
              V t_2 = v_step_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_step_242 = t_2;
              goto top;
            }
            case TAG_False: {
              heff_drop(v_s_240);
              heff_drop(v_step_242);
              return v_i_241;
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_step_242);
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_step_242);
    return v_i_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eskipSpaces(a[0], a[1], a[2]);
}
Clo g_prelude_2edigitsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2edigitsFrom_entry, 3, 0};

V g_prelude_2edigitsFrom(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_tag(TAG_Just, 1, (V[]){v_n_242});
  }
  case TAG_False: {
    V v_t_244 = heff_intLe(MK_INT(48LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(57LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = heff_intSub(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(48LL));
        V v_t_247 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), v_t_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_n_242 = t_2;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_n_242);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_prelude_2edigitsFrom_entry(V self, V *a) {
  (void)self;
  return g_prelude_2edigitsFrom(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2eparseInt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  V v_t_241 = heff_intEq(heff_strLength(heff_dup(v_s_240)), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_242 = heff_strEq(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_prelude_2eparseInt_str0));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_intEq(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_s_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_x3_244 = (g_prelude_2edigitsFrom(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_245 = heff_field(v_x3_244, 0);
          V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
          return heff_tag_at(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_x_245)});
        }
        default: return heff_nomatch(v_x3_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    case TAG_False: {
      return (g_prelude_2edigitsFrom(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  return g_prelude_2eparseInt(a[0]);
}
Clo g_prelude_2emap_24s1581021428x1223114127_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1581021428x1223114127_entry, 1, 0};

V g_prelude_2emap_24s1581021428x1223114127(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1581021428x1223114127(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1581021428x1223114127_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1581021428x1223114127(a[0]);
}
Clo g_prelude_2emap_24s531459667x996402587_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s531459667x996402587_entry, 1, 0};

V g_prelude_2emap_24s531459667x996402587(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s531459667x996402587(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s531459667x996402587(a[0]);
}
V g_prelude_2efoldl_24s2029768733x1302724432_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s2029768733x1302724432_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2029768733x1302724432_entry, 2, 0};

V g_prelude_2efoldl_24s2029768733x1302724432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_246 = (g_prelude_2emap(heff_clo(g_prelude_2efoldl_24s2029768733x1302724432_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_t_244));
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2029768733x1302724432_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2029768733x1302724432(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_prelude_2efoldl_24s2029768733x1302724432_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(2, shape_fixed__op, (V[]){v_x_242, v_a_245});
}
Clo g_prelude_2emap_24s1083963057x1681851055_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1083963057x1681851055_entry, 1, 0};

V g_prelude_2emap_24s1083963057x1681851055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_looser), (g_prelude_2emap_24s1083963057x1681851055(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1083963057x1681851055_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1083963057x1681851055(a[0]);
}
Clo g_prelude_2efoldl_24s2083806868x1400260102_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2083806868x1400260102_entry, 2, 0};

V g_prelude_2efoldl_24s2083806868x1400260102(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2083806868x1400260102_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2083806868x1400260102(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1639847025x48103675_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1639847025x48103675_entry, 1, 0};

V g_prelude_2emap_24s1639847025x48103675(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_name), (g_prelude_2emap_24s1639847025x48103675(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1639847025x48103675_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1639847025x48103675(a[0]);
}
V g_prelude_2efoldl_24s1519881281x245433162_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s1519881281x245433162_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1519881281x245433162_entry, 2, 0};

V g_prelude_2efoldl_24s1519881281x245433162(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_prelude_2efoldl_24s1519881281x245433162_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), heff_dup(g_heff_2eimport_2eimplicitImports_get())));
    V v_t_246 = (g_prelude_2econcatList(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1519881281x245433162_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1519881281x245433162(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_prelude_2efoldl_24s1519881281x245433162_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_a_244, LBL_name), v_x_242);
}
V g_prelude_2efoldl_24s680066967x839815107_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s680066967x839815107_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s680066967x839815107_entry, 2, 0};

V g_prelude_2efoldl_24s680066967x839815107(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo(g_prelude_2efoldl_24s680066967x839815107_lam0, 1, 1, (V[]){v_x_242}), heff_get(heff_dup(v_z_240), LBL_local)});
    V v_t_246 = heff_rec(2, shape_local__global, (V[]){v_t_245, heff_get(v_z_240, LBL_global)});
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s680066967x839815107_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s680066967x839815107(a[0], a[1]);
}
V g_prelude_2efoldl_24s680066967x839815107_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_244);
  return heff_tag(TAG_Ok, 1, (V[]){v_x_242});
}
Clo g_prelude_2emap_24s1670578341x1649699234_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1670578341x1649699234_entry, 2, 0};

V g_prelude_2emap_24s1670578341x1649699234(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      v_t_246 = heff_strAppend(v_a_244, heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_False); V a_1 = v_a_245; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_245); r_; })));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1670578341x1649699234(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1670578341x1649699234_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1670578341x1649699234(a[0], a[1]);
}
Clo g_prelude_2emap_24s615600838x450168446_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s615600838x450168446_entry, 2, 0};

V g_prelude_2emap_24s615600838x450168446(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; }));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s615600838x450168446(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s615600838x450168446_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s615600838x450168446(a[0], a[1]);
}
Clo g_prelude_2emap_24s265029017x1822716883_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s265029017x1822716883_entry, 1, 0};

V g_prelude_2emap_24s265029017x1822716883(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s265029017x1822716883(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s265029017x1822716883_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s265029017x1822716883(a[0]);
}
Clo g_prelude_2emap_24s684503405x117589606_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s684503405x117589606_entry, 1, 0};

V g_prelude_2emap_24s684503405x117589606(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s684503405x117589606(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s684503405x117589606_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s684503405x117589606(a[0]);
}
Clo g_prelude_2emap_24s67362943x99565768_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s67362943x99565768_entry, 1, 0};

V g_prelude_2emap_24s67362943x99565768(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_248;
      break;
    }
    case TAG_IsType: {
      V v_a_249 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s67362943x99565768(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s67362943x99565768_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s67362943x99565768(a[0]);
}
Clo g_prelude_2emap_24s354657900x1587558784_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s354657900x1587558784_entry, 1, 0};

V g_prelude_2emap_24s354657900x1587558784(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s354657900x1587558784(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s354657900x1587558784_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s354657900x1587558784(a[0]);
}
Clo g_prelude_2emap_24s842967967x223843022_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s842967967x223843022_entry, 1, 0};

V g_prelude_2emap_24s842967967x223843022(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_248)) {
      case TAG_At: {
        V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
        v_t_2411 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_a_248}), v_t_2411});
      break;
    }
    case TAG_IsType: {
      V v_a_2412 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_2412;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s842967967x223843022(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s842967967x223843022_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s842967967x223843022(a[0]);
}
Clo g_prelude_2emap_24s1491261851x220013917_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1491261851x220013917_entry, 1, 0};

V g_prelude_2emap_24s1491261851x220013917(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1491261851x220013917(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1491261851x220013917_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1491261851x220013917(a[0]);
}
Clo g_prelude_2emap_24s1170054603x901729204_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1170054603x901729204_entry, 1, 0};

V g_prelude_2emap_24s1170054603x901729204(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1170054603x901729204(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1170054603x901729204_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1170054603x901729204(a[0]);
}
Clo g_prelude_2emap_24s1472739944x318103388_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1472739944x318103388_entry, 1, 0};

V g_prelude_2emap_24s1472739944x318103388(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1472739944x318103388(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1472739944x318103388_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1472739944x318103388(a[0]);
}
Clo g_prelude_2emap_24s1340987657x1082998826_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1340987657x1082998826_entry, 1, 0};

V g_prelude_2emap_24s1340987657x1082998826(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1340987657x1082998826(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1340987657x1082998826_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1340987657x1082998826(a[0]);
}
Clo g_prelude_2emap_24s504509305x1309437118_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s504509305x1309437118_entry, 1, 0};

V g_prelude_2emap_24s504509305x1309437118(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s504509305x1309437118(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s504509305x1309437118_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s504509305x1309437118(a[0]);
}
Clo g_prelude_2emap_24s1449394102x85632237_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1449394102x85632237_entry, 1, 0};

V g_prelude_2emap_24s1449394102x85632237(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_246));
          v_t_249 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_241_24At, TAG_ArgNamed, 2, (V[]){v_a_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s1449394102x85632237(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1449394102x85632237_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1449394102x85632237(a[0]);
}
Clo g_prelude_2emap_24s760761549x776536213_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s760761549x776536213_entry, 1, 0};

V g_prelude_2emap_24s760761549x776536213(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s760761549x776536213(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s760761549x776536213_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s760761549x776536213(a[0]);
}
Clo g_prelude_2emap_24s1687423457x355380534_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1687423457x355380534_entry, 1, 0};

V g_prelude_2emap_24s1687423457x355380534(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1687423457x355380534(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1687423457x355380534_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1687423457x355380534(a[0]);
}
Clo g_prelude_2emap_24s271878692x1909813941_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s271878692x1909813941_entry, 1, 0};

V g_prelude_2emap_24s271878692x1909813941(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        v_t_2412 = heff_tag_at(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, (g_prelude_2emap_24s1687423457x355380534(v_a_247))});
        break;
      }
      case TAG_BadVariant: {
        V v_a_248 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2412 = heff_tag_at(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2412, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2emap_24s271878692x1909813941(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s271878692x1909813941_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s271878692x1909813941(a[0]);
}
Clo g_prelude_2emap_24s1097491904x416138181_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1097491904x416138181_entry, 1, 0};

V g_prelude_2emap_24s1097491904x416138181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1097491904x416138181(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1097491904x416138181_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1097491904x416138181(a[0]);
}
Clo g_prelude_2emap_24s7771255x22951525_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s7771255x22951525_entry, 1, 0};

V g_prelude_2emap_24s7771255x22951525(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_248));
          v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s7771255x22951525(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s7771255x22951525_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s7771255x22951525(a[0]);
}
Clo g_prelude_2emap_24s1439972680x346961496_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1439972680x346961496_entry, 1, 0};

V g_prelude_2emap_24s1439972680x346961496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_247));
          v_t_2410 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at(v_ru_24x_241_24At, TAG_MkAlt, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s1439972680x346961496(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1439972680x346961496_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1439972680x346961496(a[0]);
}
Clo g_prelude_2emap_24s1276521852x477277004_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1276521852x477277004_entry, 1, 0};

V g_prelude_2emap_24s1276521852x477277004(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_249));
          v_t_2412 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2emap_24s1276521852x477277004(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1276521852x477277004_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1276521852x477277004(a[0]);
}
Clo g_prelude_2emap_24s1548800724x1090490128_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1548800724x1090490128_entry, 1, 0};

V g_prelude_2emap_24s1548800724x1090490128(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s1548800724x1090490128(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1548800724x1090490128_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1548800724x1090490128(a[0]);
}
Clo g_prelude_2emap_24s914971304x1928750522_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s914971304x1928750522_entry, 1, 0};

V g_prelude_2emap_24s914971304x1928750522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2edeclN_24s819476248x1348827013(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s914971304x1928750522(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s914971304x1928750522_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s914971304x1928750522(a[0]);
}
Clo g_prelude_2emap_24s588898442x1763987159_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s588898442x1763987159_entry, 1, 0};

V g_prelude_2emap_24s588898442x1763987159(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_at(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2416, (g_prelude_2emap_24s588898442x1763987159(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s588898442x1763987159_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s588898442x1763987159(a[0]);
}
Clo g_prelude_2emap_24s1559710030x546042594_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1559710030x546042594_entry, 2, 0};

V g_prelude_2emap_24s1559710030x546042594(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), (g_prelude_2emap_24s1559710030x546042594(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1559710030x546042594_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1559710030x546042594(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s623933082x1825074454_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s623933082x1825074454_entry, 2, 0};

V g_prelude_2efoldl_24s623933082x1825074454(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s623933082x1825074454_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s623933082x1825074454(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s676400863x2047065740_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s676400863x2047065740_entry, 2, 0};

V g_prelude_2efoldl_24s676400863x2047065740(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s676400863x2047065740_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s676400863x2047065740(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s466644717x1386269885_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s466644717x1386269885_entry, 2, 0};

V g_prelude_2efoldl_24s466644717x1386269885(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s466644717x1386269885_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s466644717x1386269885(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1484914594x961890250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1484914594x961890250_entry, 2, 0};

V g_prelude_2efoldl_24s1484914594x961890250(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s466644717x1386269885(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1484914594x961890250_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1484914594x961890250(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1853020597x2079987308_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1853020597x2079987308_entry, 2, 0};

V g_prelude_2efoldl_24s1853020597x2079987308(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1853020597x2079987308_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1853020597x2079987308(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s124340812x1866980185_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s124340812x1866980185_entry, 2, 0};

V g_prelude_2efoldl_24s124340812x1866980185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s124340812x1866980185_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s124340812x1866980185(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efilter_24s1893795724x726475325_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1893795724x726475325_entry, 2, 0};

V g_prelude_2efilter_24s1893795724x726475325(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLt(heff_dup(v_lit_240), heff_strLength(heff_dup(v_x_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2efilter_24s1893795724x726475325(v_lit_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efilter_24s1893795724x726475325_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1893795724x726475325(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1445726280x1015515073_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1445726280x1015515073_entry, 2, 0};

V g_prelude_2efoldl_24s1445726280x1015515073(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1445726280x1015515073_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1445726280x1015515073(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s2128431283x1958701110_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s2128431283x1958701110_entry, 2, 0};

V g_prelude_2emerge_24s2128431283x1958701110(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s2128431283x1958701110(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s2128431283x1958701110(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s2128431283x1958701110_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s2128431283x1958701110(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s2054846137x538107791_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s2054846137x538107791_entry, 1, 0};

V g_prelude_2esortBy_24s2054846137x538107791(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s2054846137x538107791(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s2054846137x538107791(v_t_2411));
      return (g_prelude_2emerge_24s2128431283x1958701110(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s2054846137x538107791_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s2054846137x538107791(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s91703316x860383118_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s91703316x860383118_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s91703316x860383118_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s91703316x860383118_entry, 1, 0};

V g_prelude_2emap_24s91703316x860383118(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_span), LBL_start);
    V v_t_244 = heff_get(heff_get(v_x_241, LBL_span), LBL_end);
    V v_t_245 = heff_rec(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_prelude_2emap_24s91703316x860383118_str0), ((V)&g_prelude_2emap_24s91703316x860383118_str1), v_t_243, v_t_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s91703316x860383118(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s91703316x860383118_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s91703316x860383118(a[0]);
}
Clo g_prelude_2emerge_24s1366678805x1489829848_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s1366678805x1489829848_entry, 2, 0};

V g_prelude_2emerge_24s1366678805x1489829848(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s1366678805x1489829848(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s1366678805x1489829848(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s1366678805x1489829848_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s1366678805x1489829848(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s2011755074x583809521_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s2011755074x583809521_entry, 1, 0};

V g_prelude_2esortBy_24s2011755074x583809521(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s2011755074x583809521(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s2011755074x583809521(v_t_2411));
      return (g_prelude_2emerge_24s1366678805x1489829848(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s2011755074x583809521_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s2011755074x583809521(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1384090898x1957594759_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s1384090898x1957594759_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1384090898x1957594759_entry, 1, 0};

V g_prelude_2emap_24s1384090898x1957594759(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), heff_tag(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_prelude_2emap_24s1384090898x1957594759_str0), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1384090898x1957594759(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1384090898x1957594759_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1384090898x1957594759(a[0]);
}
Clo g_prelude_2emap_24s6666188x1439341245_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s6666188x1439341245_entry, 1, 0};

V g_prelude_2emap_24s6666188x1439341245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), NTAG(TAG_Nothing), heff_get(v_x_241, LBL_text), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s6666188x1439341245(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s6666188x1439341245_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s6666188x1439341245(a[0]);
}
Clo g_prelude_2emap_24s1694032985x57198631_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1694032985x57198631_entry, 1, 0};

V g_prelude_2emap_24s1694032985x57198631(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1694032985x57198631(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1694032985x57198631_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1694032985x57198631(a[0]);
}
Clo g_prelude_2emap_24s291974946x1668376991_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s291974946x1668376991_entry, 1, 0};

V g_prelude_2emap_24s291974946x1668376991(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esurface_2easNameE(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s291974946x1668376991(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s291974946x1668376991_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s291974946x1668376991(a[0]);
}
Clo g_prelude_2emap_24s297378115x1885194799_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s297378115x1885194799_entry, 1, 0};

V g_prelude_2emap_24s297378115x1885194799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_EProject, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)});
    V v_t_244 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_243, v_t_244}), (g_prelude_2emap_24s297378115x1885194799(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s297378115x1885194799_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s297378115x1885194799(a[0]);
}
Clo g_prelude_2efoldl_24s1105146645x999250186_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1105146645x999250186_entry, 3, 0};

V g_prelude_2efoldl_24s1105146645x999250186(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_a_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_a_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2412, LBL_start), heff_get(heff_dup(v_a_246), LBL_end)});
        v_t_2415 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1105146645x999250186_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1105146645x999250186(a[0], a[1], a[2]);
}
Clo g_prelude_2emap_24s52210753x799200641_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s52210753x799200641_entry, 1, 0};

V g_prelude_2emap_24s52210753x799200641(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s52210753x799200641(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s52210753x799200641_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s52210753x799200641(a[0]);
}
Clo g_prelude_2emap_24s1530006173x935542988_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1530006173x935542988_entry, 1, 0};

V g_prelude_2emap_24s1530006173x935542988(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_prelude_2emap_24s1530006173x935542988(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1530006173x935542988_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1530006173x935542988(a[0]);
}
Clo g_prelude_2emap_24s1338266682x1095943031_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1338266682x1095943031_entry, 4, 0};

V g_prelude_2emap_24s1338266682x1095943031(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_text), heff_dup(v_lit_242)));
    V v_t_247 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_248 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), v_t_246, v_t_247, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s1338266682x1095943031(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s1338266682x1095943031_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1338266682x1095943031(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2efilter_24s1076841276x1319703925_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1076841276x1319703925_entry, 1, 0};

V g_prelude_2efilter_24s1076841276x1319703925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)}));
    V v_t_244 = ({ V a_0 = v_t_243; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1076841276x1319703925(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1076841276x1319703925_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1076841276x1319703925(a[0]);
}
Clo g_prelude_2emap_24s534301229x255644933_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s534301229x255644933_entry, 1, 0};

V g_prelude_2emap_24s534301229x255644933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ops);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_op_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      V v_t_246 = (g_prelude_2emap_24s1530006173x935542988(heff_get(heff_dup(v_x_241), LBL_ops)));
      V v_t_247 = heff_rec(3, shape_id__assoc__ops, (V[]){heff_get(v_op_244, LBL_text), heff_get(v_x_241, LBL_assoc), v_t_246});
      v_t_248 = heff_tag(TAG_Just, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s534301229x255644933(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s534301229x255644933_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s534301229x255644933(a[0]);
}
Clo g_prelude_2efilter_24s1995665332x305653225_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1995665332x305653225_entry, 4, 0};

V g_prelude_2efilter_24s1995665332x305653225(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V b_2 = heff_get(heff_dup(v_x_244), LBL_ops); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_a_247 = heff_intEq(v_t_246, heff_dup(v_lit_242));
    switch (heff_tag_of(v_a_247)) {
    case TAG_True: {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_prelude_2efilter_24s1995665332x305653225(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
    default: return heff_nomatch(v_a_247);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2efilter_24s1995665332x305653225_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1995665332x305653225(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emap_24s1479019137x857976527_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1479019137x857976527_entry, 1, 0};

V g_prelude_2emap_24s1479019137x857976527(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end)});
    V v_t_244 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get(v_x_241, LBL_msg), v_t_243, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1479019137x857976527(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1479019137x857976527_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1479019137x857976527(a[0]);
}
Clo g_prelude_2emap_24s1921933910x1036692167_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1921933910x1036692167_entry, 2, 0};

V g_prelude_2emap_24s1921933910x1036692167(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), (g_prelude_2emap_24s1921933910x1036692167(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1921933910x1036692167_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1921933910x1036692167(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1526645111x1945750140_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1526645111x1945750140_entry, 3, 0};

V g_prelude_2efoldl_24s1526645111x1945750140(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2419;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        V v_t_248 = heff_strEq(heff_dup(v_a_247), heff_dup(v_lit_240));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          v_t_2419 = v_z_241;
          break;
        }
        case TAG_False: {
          V v_t_249 = heff_strEq(heff_dup(v_a_247), heff_dup(v_a_245));
          switch (heff_tag_of(v_t_249)) {
          case TAG_True: {
            v_t_2419 = v_z_241;
            break;
          }
          case TAG_False: {
            V v_t_2410 = (g_heff_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
            v_t_2419 = heff_tr(heff_apply(heff_get(v_t_2410, LBL_chk), 1, (V[]){v_z_241}));
            break;
          }
          default: heff_nomatch(v_t_249);
          }
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        break;
      }
      case TAG_PTag: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2419 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1526645111x1945750140_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1526645111x1945750140(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2efoldl_24s1377741640x1185496867_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1377741640x1185496867_entry, 2, 0};

V g_prelude_2efoldl_24s1377741640x1185496867(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1377741640x1185496867_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1377741640x1185496867(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s848659184x39013903_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s848659184x39013903_entry, 2, 0};

V g_prelude_2efoldl_24s848659184x39013903(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_l_246), heff_dup(v_i_244), v_z_240));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s848659184x39013903_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s848659184x39013903(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s2095412982x241182197_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2095412982x241182197_entry, 2, 0};

V g_prelude_2efoldl_24s2095412982x241182197(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_get(heff_dup(v_x_242), LBL_sol);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec(2, shape_name__span, (V[]){heff_get(heff_dup(v_x_242), LBL_name), heff_get(v_x_242, LBL_span)});
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2095412982x241182197_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s2095412982x241182197(a[0], a[1]);
}
Clo g_prelude_2eany_24s306565984x776318930_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s306565984x776318930_entry, 1, 0};

V g_prelude_2eany_24s306565984x776318930(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s306565984x776318930_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s306565984x776318930(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s612293031x749451349_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s612293031x749451349_entry, 1, 0};

V g_prelude_2emap_24s612293031x749451349(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eprims_2efixedImpl(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s612293031x749451349(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s612293031x749451349_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s612293031x749451349(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1681132721x1100845580_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1681132721x1100845580_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_prelude_2emap_24s1681132721x1100845580_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1681132721x1100845580_entry, 1, 0};

V g_prelude_2emap_24s1681132721x1100845580(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s1681132721x1100845580_str0), heff_strAppend(v_t_243, ((V)&g_prelude_2emap_24s1681132721x1100845580_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1681132721x1100845580(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1681132721x1100845580_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1681132721x1100845580(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s1465322528x1075776197_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1465322528x1075776197_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_prelude_2emap_24s1465322528x1075776197_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1465322528x1075776197_entry, 1, 0};

V g_prelude_2emap_24s1465322528x1075776197(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intLt(heff_dup(v_x_241), MK_INT(0LL));
    V v_t_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_prelude_2emap_24s1465322528x1075776197_str0), heff_strAppend(v_t_244, ((V)&g_prelude_2emap_24s1465322528x1075776197_str1)));
      break;
    }
    case TAG_False: {
      v_t_245 = heff_intShow(v_x_241);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1465322528x1075776197(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1465322528x1075776197_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1465322528x1075776197(a[0]);
}
Clo g_prelude_2emap_24s1792226203x1962008905_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1792226203x1962008905_entry, 7, 0};

V g_prelude_2emap_24s1792226203x1962008905(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2emap_24s1792226203x1962008905(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s1792226203x1962008905_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1792226203x1962008905(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2emap_24s1105939642x992420831_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1105939642x992420831_entry, 7, 0};

V g_prelude_2emap_24s1105939642x992420831(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2emap_24s1105939642x992420831(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s1105939642x992420831_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1105939642x992420831(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2emap_24s1046782722x1317586010_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1046782722x1317586010_entry, 11, 0};

V g_prelude_2emap_24s1046782722x1317586010(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2421;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      heff_take_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2eprint_2eescFrom(v_a_2413, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      v_t_2421 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)))));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2421, (g_prelude_2emap_24s1046782722x1317586010(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412))});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_prelude_2emap_24s1046782722x1317586010_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1046782722x1317586010(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_prelude_2emap_24s1042627293x2039157317_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1042627293x2039157317_entry, 7, 0};

V g_prelude_2emap_24s1042627293x2039157317(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2earmOf_24s139775371x1736504365(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2emap_24s1042627293x2039157317(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s1042627293x2039157317_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1042627293x2039157317(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2efilter_24s1987049161x529776488_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1987049161x529776488_entry, 1, 0};

V g_prelude_2efilter_24s1987049161x529776488(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1987049161x529776488(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1987049161x529776488_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1987049161x529776488(a[0]);
}
Clo g_prelude_2eany_24s1963868307x1860200435_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s1963868307x1860200435_entry, 1, 0};

V g_prelude_2eany_24s1963868307x1860200435(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s1963868307x1860200435_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s1963868307x1860200435(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s1774533623x1679457808_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1774533623x1679457808_entry, 1, 0};

V g_prelude_2emap_24s1774533623x1679457808(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_el)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1774533623x1679457808(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1774533623x1679457808_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1774533623x1679457808(a[0]);
}
Clo g_prelude_2emap_24s490045439x1540849353_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s490045439x1540849353_entry, 2, 0};

V g_prelude_2emap_24s490045439x1540849353(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), (g_prelude_2emap_24s490045439x1540849353(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s490045439x1540849353_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s490045439x1540849353(a[0], a[1]);
}
Clo g_prelude_2emap_24s751962069x1815060025_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s751962069x1815060025_entry, 1, 0};

V g_prelude_2emap_24s751962069x1815060025(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s751962069x1815060025(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s751962069x1815060025_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s751962069x1815060025(a[0]);
}
Clo g_prelude_2efoldl_24s2013519703x136854689_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2013519703x136854689_entry, 2, 0};

V g_prelude_2efoldl_24s2013519703x136854689(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2013519703x136854689_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2013519703x136854689(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s551054150x174860098_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s551054150x174860098_entry, 2, 0};

V g_prelude_2efoldl_24s551054150x174860098(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_get(heff_dup(v_z_240), LBL_broken)));
    V v_t_245 = heff_rec(4, shape_order__entries__aliases__broken, (V[]){heff_get(heff_dup(v_z_240), LBL_order), heff_get(heff_dup(v_z_240), LBL_entries), heff_get(v_z_240, LBL_aliases), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s551054150x174860098_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s551054150x174860098(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1711014586x982785069_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1711014586x982785069_entry, 2, 0};

V g_prelude_2efoldl_24s1711014586x982785069(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1711014586x982785069_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1711014586x982785069(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s772488398x992379409_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s772488398x992379409_entry, 1, 0};

V g_prelude_2emap_24s772488398x992379409(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_module), (g_prelude_2emap_24s772488398x992379409(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s772488398x992379409_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s772488398x992379409(a[0]);
}
Clo g_prelude_2efoldl_24s87535414x694612571_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s87535414x694612571_entry, 2, 0};

V g_prelude_2efoldl_24s87535414x694612571(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_get(heff_dup(v_x_242), LBL_level);
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s87535414x694612571_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s87535414x694612571(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1042490692x1702390136_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1042490692x1702390136_entry, 1, 0};

V g_prelude_2emap_24s1042490692x1702390136(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_SGlobal, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_key)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_x_241, LBL_name), v_t_243});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1042490692x1702390136(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1042490692x1702390136_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1042490692x1702390136(a[0]);
}
Clo g_prelude_2efoldl_24s1793737101x1852648432_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1793737101x1852648432_entry, 2, 0};

V g_prelude_2efoldl_24s1793737101x1852648432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_get(heff_dup(v_x_242), LBL_fixities);
    V v_t_245 = (g_heff_2efixity_2eappendF(heff_get(heff_dup(v_z_240), LBL_groups), heff_get(heff_dup(v_a_244), LBL_groups)));
    V v_t_246 = (g_heff_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2efixity_2eappendF(heff_get(v_z_240, LBL_above), heff_get(v_a_244, LBL_above)));
    V v_t_248 = (g_heff_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec(2, shape_groups__above, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1793737101x1852648432_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1793737101x1852648432(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s706234375x797630515_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s706234375x797630515_entry, 1, 0};

V g_prelude_2emap_24s706234375x797630515(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2ehint(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s706234375x797630515(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s706234375x797630515_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s706234375x797630515(a[0]);
}
Clo g_prelude_2efoldl_24s1053087238x1725706605_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1053087238x1725706605_entry, 2, 0};

V g_prelude_2efoldl_24s1053087238x1725706605(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_x_242), LBL_implicit), heff_get(heff_dup(v_x_242), LBL_source)));
    V v_a_245 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_renames); V a_1 = v_t_244; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_prelude_2emap_24s1639847025x48103675(heff_get(heff_dup(v_a_245), LBL_imports)));
    V v_a_247 = (g_heff_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1053087238x1725706605_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1053087238x1725706605(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s2082593756x791667152_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_prelude_2emap_24s2082593756x791667152_lam0(V self, V *args); static Clo g_prelude_2emap_24s2082593756x791667152_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2082593756x791667152_lam0, 1, 0};
Clo g_prelude_2emap_24s2082593756x791667152_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2082593756x791667152_entry, 1, 0};

V g_prelude_2emap_24s2082593756x791667152(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec(5, shape_span__name__key__member__ty, (V[]){heff_get(heff_dup(v_x_241), LBL_span), heff_get(heff_dup(v_x_241), LBL_name), heff_get(heff_dup(v_x_241), LBL_key), heff_get(v_x_241, LBL_member), ((V)&g_prelude_2emap_24s2082593756x791667152_lam0_clo)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s2082593756x791667152(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2082593756x791667152_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2082593756x791667152(a[0]);
}
V g_prelude_2emap_24s2082593756x791667152_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_prelude_2emap_24s2082593756x791667152_str0);
}
Clo g_prelude_2efoldl_24s819361743x1297375170_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s819361743x1297375170_entry, 2, 0};

V g_prelude_2efoldl_24s819361743x1297375170(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_x_242), LBL_implicit), heff_get(heff_dup(v_x_242), LBL_source)));
    V v_a_245 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_renames); V a_1 = v_t_244; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_prelude_2emap_24s1639847025x48103675(heff_get(heff_dup(v_a_245), LBL_imports)));
    V v_a_247 = (g_heff_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_heff_2edriver_2elean(v_t_249));
    V v_t_2411 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2edriver_2eappendD(v_z_240, v_t_2411));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s819361743x1297375170_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s819361743x1297375170(a[0], a[1]);
}
Clo g_prelude_2emap_24s2025198057x415178258_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2025198057x415178258_entry, 1, 0};

V g_prelude_2emap_24s2025198057x415178258(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_key), (g_prelude_2emap_24s2025198057x415178258(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2025198057x415178258_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2025198057x415178258(a[0]);
}
Clo g_prelude_2emap_24s752906154x1709852375_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s752906154x1709852375_entry, 3, 0};

V g_prelude_2emap_24s752906154x1709852375(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_get(heff_dup(v_x_243), LBL_code));
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_241), heff_get(v_x_243, LBL_msg))));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s752906154x1709852375(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2emap_24s752906154x1709852375_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s752906154x1709852375(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s1945742092x1723113759_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1945742092x1723113759_entry, 2, 0};

V g_prelude_2efoldl_24s1945742092x1723113759(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1945742092x1723113759_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1945742092x1723113759(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s200728978x966202520_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s200728978x966202520_entry, 1, 0};

V g_prelude_2emap_24s200728978x966202520(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_t_245, LBL_start), (g_prelude_2emap_24s200728978x966202520(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s200728978x966202520_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s200728978x966202520(a[0]);
}
Clo g_prelude_2emap_24s566279366x471477086_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s566279366x471477086_entry, 2, 0};

V g_prelude_2emap_24s566279366x471477086(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_prelude_2emap_24s566279366x471477086(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s566279366x471477086_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s566279366x471477086(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s809825463x1159518974_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s809825463x1159518974_entry, 5, 0};

V g_prelude_2efoldl_24s809825463x1159518974(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_prelude_2esplitFrom(heff_dup(v_lit_241), heff_get(heff_dup(v_x_245), LBL_value), heff_dup(v_lit_242), NTAG(TAG_Nil)));
    V v_t_248 = (g_prelude_2emap_24s1559710030x546042594(heff_dup(v_lit_240), v_t_247));
    V v_t_249 = (g_heff_2edriver_2epromoteAt(v_z_243, heff_get(heff_dup(v_x_245), LBL_expectFrom), heff_get(heff_dup(v_x_245), LBL_expectTo), v_t_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_249;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_prelude_2efoldl_24s809825463x1159518974_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s809825463x1159518974(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
Clo g_prelude_2emap_24s175191143x639839450_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s175191143x639839450_entry, 1, 0};

V g_prelude_2emap_24s175191143x639839450(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s175191143x639839450(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s175191143x639839450_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s175191143x639839450(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s860552613x788263739_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s860552613x788263739_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s860552613x788263739_entry, 1, 0};

V g_prelude_2emap_24s860552613x788263739(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2412 = v_s_2410;
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str6);
      break;
    }
    case TAG_VErased: {
      v_t_2412 = ((V)&g_prelude_2emap_24s860552613x788263739_str7);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s860552613x788263739(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s860552613x788263739_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s860552613x788263739(a[0]);
}
Clo g_prelude_2emap_24s687737756x1010305734_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s687737756x1010305734_entry, 1, 0};

V g_prelude_2emap_24s687737756x1010305734(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s687737756x1010305734(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s687737756x1010305734_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s687737756x1010305734(a[0]);
}
Clo g_prelude_2efilter_24s1056866665x1882138159_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1056866665x1882138159_entry, 1, 0};

V g_prelude_2efilter_24s1056866665x1882138159(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_severity);
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1056866665x1882138159(v_xs_242))});
    }
    case TAG_SWarning: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1056866665x1882138159_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1056866665x1882138159(a[0]);
}
Clo g_prelude_2emap_24s1537567598x716246174_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1537567598x716246174_entry, 3, 0};

V g_prelude_2emap_24s1537567598x716246174(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1537567598x716246174(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2emap_24s1537567598x716246174_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1537567598x716246174(a[0], a[1], a[2]);
}
Clo g_prelude_2emap_24s1410920902x1892852593_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1410920902x1892852593_entry, 4, 0};

V g_prelude_2emap_24s1410920902x1892852593(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_module), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(v_x_244, LBL_alias), heff_dup(v_lit_242)))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1410920902x1892852593(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s1410920902x1892852593_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1410920902x1892852593(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2efilter_24s627362487x853718923_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s627362487x853718923_entry, 2, 0};

V g_prelude_2efilter_24s627362487x853718923(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strEq(heff_dup(v_x_242), heff_dup(v_lit_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2efilter_24s627362487x853718923(v_lit_240, v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efilter_24s627362487x853718923_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s627362487x853718923(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s2095293338x1796005627_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2095293338x1796005627_entry, 2, 0};

V g_prelude_2efoldl_24s2095293338x1796005627(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eglueOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2095293338x1796005627_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2095293338x1796005627(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1766835601x1856285269_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1766835601x1856285269_entry, 2, 0};

V g_prelude_2efoldl_24s1766835601x1856285269(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1766835601x1856285269_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1766835601x1856285269(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1224661136x1529143690_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1224661136x1529143690_entry, 1, 0};

V g_prelude_2emap_24s1224661136x1529143690(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1224661136x1529143690(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1224661136x1529143690_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1224661136x1529143690(a[0]);
}
Clo g_prelude_2emap_24s1749182240x1466970014_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1749182240x1466970014_entry, 1, 0};

V g_prelude_2emap_24s1749182240x1466970014(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1749182240x1466970014(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1749182240x1466970014_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1749182240x1466970014(a[0]);
}
Clo g_prelude_2emap_24s1448703749x94773476_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1448703749x94773476_entry, 1, 0};

V g_prelude_2emap_24s1448703749x94773476(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1448703749x94773476(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1448703749x94773476_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1448703749x94773476(a[0]);
}
Clo g_prelude_2efoldl_24s803210893x1036700122_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s803210893x1036700122_entry, 2, 0};

V g_prelude_2efoldl_24s803210893x1036700122(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s803210893x1036700122_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s803210893x1036700122(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1295898052x1915853031_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1295898052x1915853031_entry, 1, 0};

V g_prelude_2emap_24s1295898052x1915853031(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1295898052x1915853031(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1295898052x1915853031_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1295898052x1915853031(a[0]);
}
Clo g_prelude_2efoldl_24s1700457534x694272192_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1700457534x694272192_entry, 2, 0};

V g_prelude_2efoldl_24s1700457534x694272192(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2esimplify_2eflat(heff_get(heff_dup(v_x_242), LBL_body)));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_get(heff_dup(v_x_242), LBL_key); V a_2 = v_t_244; V r_ = (g_heff_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1700457534x694272192_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1700457534x694272192(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1645030849x525483621_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1645030849x525483621_entry, 1, 0};

V g_prelude_2emap_24s1645030849x525483621(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2432, (g_prelude_2emap_24s1645030849x525483621(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1645030849x525483621_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1645030849x525483621(a[0]);
}
Clo g_prelude_2emap_24s1716181342x353410538_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1716181342x353410538_entry, 1, 0};

V g_prelude_2emap_24s1716181342x353410538(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2432, (g_prelude_2emap_24s1716181342x353410538(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1716181342x353410538_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1716181342x353410538(a[0]);
}
Clo g_prelude_2efoldl_24s1431458237x755517792_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1431458237x755517792_entry, 2, 0};

V g_prelude_2efoldl_24s1431458237x755517792(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1431458237x755517792_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1431458237x755517792(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1075493002x264635373_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1075493002x264635373_entry, 5, 0};

V g_prelude_2efoldl_24s1075493002x264635373(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      heff_take_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_intShow(heff_dup(v_a_248))));
      v_t_2410 = heff_tag_at(v_ru_24x3_244_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_a_247}), heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2410;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_prelude_2efoldl_24s1075493002x264635373_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1075493002x264635373(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2emap_24s2083806615x1058260173_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2083806615x1058260173_entry, 1, 0};

V g_prelude_2emap_24s2083806615x1058260173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_x_241}), (g_prelude_2emap_24s2083806615x1058260173(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2083806615x1058260173_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2083806615x1058260173(a[0]);
}
Clo g_prelude_2emap_24s764047539x1158385979_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s764047539x1158385979_entry, 1, 0};

V g_prelude_2emap_24s764047539x1158385979(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), (g_prelude_2emap_24s764047539x1158385979(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s764047539x1158385979_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s764047539x1158385979(a[0]);
}
Clo g_prelude_2ezipWith_24s836893971x454572333_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s836893971x454572333_entry, 3, 0};

V g_prelude_2ezipWith_24s836893971x454572333(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_243)) {
      case TAG_True: {
        v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_y_245; V r_ = (g_heff_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_y_245); r_; });
        break;
      }
      case TAG_False: {
        heff_drop(v_y_245);
        v_t_247 = heff_dup(v_lit_240);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith_24s836893971x454572333(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2ezipWith_24s836893971x454572333_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s836893971x454572333(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s1163606919x177582362_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1163606919x177582362_entry, 2, 0};

V g_prelude_2efoldl_24s1163606919x177582362(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_intLe(heff_dup(v_z_240), heff_dup(v_x_242));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = v_z_240;
      break;
    }
    case TAG_False: {
      heff_drop(v_z_240);
      v_t_245 = heff_dup(v_x_242);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1163606919x177582362_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1163606919x177582362(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s279777603x1686732349_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s279777603x1686732349_entry, 2, 0};

V g_prelude_2efoldl_24s279777603x1686732349(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2eir_2enubI(v_t_244));
    V v_t_246 = (g_prelude_2econcatList(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s279777603x1686732349_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s279777603x1686732349(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eany_24s438096394x623120595_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s438096394x623120595_entry, 1, 0};

V g_prelude_2eany_24s438096394x623120595(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2435;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_x13_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_x13_245)) {
      case TAG_EVar: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x13_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s438096394x623120595_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s438096394x623120595(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2ezipWith_24s1130233364x669931997_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s1130233364x669931997_entry, 2, 0};

V g_prelude_2ezipWith_24s1130233364x669931997(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), (g_prelude_2ezipWith_24s1130233364x669931997(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s1130233364x669931997_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s1130233364x669931997(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s2108860153x2035442283_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2108860153x2035442283_entry, 2, 0};

V g_prelude_2efoldl_24s2108860153x2035442283(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2108860153x2035442283_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2108860153x2035442283(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2ezipWith_24s707462069x132290260_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s707462069x132290260_entry, 2, 0};

V g_prelude_2ezipWith_24s707462069x132290260(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), (g_prelude_2ezipWith_24s707462069x132290260(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s707462069x132290260_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s707462069x132290260(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1820263712x281039405_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1820263712x281039405_entry, 3, 0};

V g_prelude_2efoldl_24s1820263712x281039405(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2elift_2eliftGo_24s104003089x2047780485(heff_dup(v_lit_240), heff_dup(v_x_243), heff_get(heff_dup(v_x_243), LBL_body)));
    V v_t_249;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_x_243), LBL_key), heff_get(v_x_243, LBL_name), v_a_246});
      v_t_249 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(v_a_247, LBL_out)))});
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2410 = (g_prelude_2econcatList(v_t_249, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1820263712x281039405_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1820263712x281039405(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s678795091x847683496_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s678795091x847683496_entry, 2, 0};

V g_prelude_2efoldl_24s678795091x847683496(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_get(heff_dup(v_x_242), LBL_key), heff_get(heff_dup(v_x_242), LBL_body), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s678795091x847683496_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s678795091x847683496(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1176465913x1306324629_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1176465913x1306324629_entry, 2, 0};

V g_prelude_2efoldl_24s1176465913x1306324629(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemit_2evalueRefs(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1176465913x1306324629_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1176465913x1306324629(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1357790075x1883916922_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1357790075x1883916922_entry, 2, 0};

V g_prelude_2efoldl_24s1357790075x1883916922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eemit_2evalueRefs(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1357790075x1883916922_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1357790075x1883916922(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s456121611x843305022_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s456121611x843305022_entry, 2, 0};

V g_prelude_2efoldl_24s456121611x843305022(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eemit_2evalueRefs(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s456121611x843305022_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s456121611x843305022(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2eany_24s452699088x1271436644_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s452699088x1271436644_entry, 1, 0};

V g_prelude_2eany_24s452699088x1271436644(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eemit_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s452699088x1271436644_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s452699088x1271436644(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2efoldl_24s909551427x1807771490_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s909551427x1807771490_entry, 2, 0};

V g_prelude_2efoldl_24s909551427x1807771490(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2eemit_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s909551427x1807771490_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s909551427x1807771490(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1205656800x1876272428_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1205656800x1876272428_entry, 2, 0};

V g_prelude_2efoldl_24s1205656800x1876272428(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2eemit_2ebindName(heff_get(heff_dup(v_z_240), LBL_env), v_x_242));
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_a_244), LBL_js), NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2econcatList(heff_get(v_z_240, LBL_js), v_t_245));
    V v_t_247 = heff_rec(2, shape_js__env, (V[]){v_t_246, heff_get(v_a_244, LBL_env)});
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1205656800x1876272428_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1205656800x1876272428(a[0], a[1]);
}
Clo g_prelude_2emap_24s651634357x426945616_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s651634357x426945616_entry, 1, 0};

V g_prelude_2emap_24s651634357x426945616(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_code), (g_prelude_2emap_24s651634357x426945616(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s651634357x426945616_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s651634357x426945616(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emaybe_24s1564285205x84298940_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emaybe_24s1564285205x84298940_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emaybe_24s1564285205x84298940_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 61}};
Clo g_prelude_2emaybe_24s1564285205x84298940_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emaybe_24s1564285205x84298940_entry, 2, 0};

V g_prelude_2emaybe_24s1564285205x84298940(V v_d_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nothing: {
    return v_d_240;
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24Just = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_d_240);
    V v_t_243 = heff_get(v_x_242, LBL_op);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSub: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpMul: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpDiv: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRem: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpEq: {
      return heff_tag_at(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1564285205x84298940_str0)});
    }
    case TAG_OpLt: {
      return heff_tag_at(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1564285205x84298940_str1)});
    }
    case TAG_OpLe: {
      return heff_tag_at(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1564285205x84298940_str2)});
    }
    case TAG_OpAnd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpOr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpXor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShl: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShow: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSqrt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFloor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2emaybe_24s1564285205x84298940_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emaybe_24s1564285205x84298940(a[0], a[1]);
}
Clo g_prelude_2ezipWith_24s265785801x162300510_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s265785801x162300510_entry, 3, 0};

V g_prelude_2ezipWith_24s265785801x162300510(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2ezipWith_24s265785801x162300510(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_prelude_2ezipWith_24s265785801x162300510_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s265785801x162300510(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s1262644577x604058569_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1262644577x604058569_entry, 2, 0};

V g_prelude_2efoldl_24s1262644577x604058569(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = ({ V a_0 = v_z_240; V a_1 = v_t_246; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_246); r_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1262644577x604058569_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1262644577x604058569(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1249505547x1425104476_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1249505547x1425104476_entry, 2, 0};

V g_prelude_2efoldl_24s1249505547x1425104476(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_247); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1249505547x1425104476_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1249505547x1425104476(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s403972348x911066463_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s403972348x911066463_entry, 2, 0};

V g_prelude_2efoldl_24s403972348x911066463(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V a_0 = v_z_240; V b_1 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2eprimUses(a_0, b_1)); heff_drop(b_1); r_; });
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s403972348x911066463_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s403972348x911066463(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s934124169x1828361008_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s934124169x1828361008_entry, 8, 0};

V g_prelude_2emap_24s934124169x1828361008(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = heff_get(v_x_248, LBL_key);
    V v_a_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2410), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_2412 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_a_2411));
    V v_a_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_a_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      v_a_2415 = heff_tag(TAG_Just, 1, (V[]){v_a_2413});
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_a_2417;
    switch (heff_tag_of(v_a_2415)) {
    case TAG_Nothing: {
      v_a_2417 = v_a_2410;
      break;
    }
    case TAG_Just: {
      V v_a_2416 = heff_field(v_a_2415, 0);
      heff_take_n(v_a_2415, 1ULL, 1);
      heff_drop(v_a_2410);
      v_a_2417 = v_a_2416;
      break;
    }
    default: heff_nomatch(v_a_2415);
    }
    V v_t_2418 = heff_intSub(heff_strLength(heff_dup(v_a_2417)), heff_dup(v_lit_242));
    V v_t_2419 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_a_2417), v_t_2418));
    V v_t_2420 = (g_heff_2eemit_2espellAt(v_a_2417, v_t_2419));
    V v_a_2421 = (g_heff_2eemit_2esafeChars(v_t_2420, heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2422 = heff_strEq(heff_dup(v_a_2421), heff_dup(v_lit_245));
    V v_t_2423;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_a_2421);
      v_t_2423 = heff_dup(v_lit_246);
      break;
    }
    case TAG_False: {
      v_t_2423 = v_a_2421;
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_t_2424 = (g_heff_2eemit_2esafeRes(v_t_2423));
    return heff_tag_at(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2424, (g_prelude_2emap_24s934124169x1828361008(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249))});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2emap_24s934124169x1828361008_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s934124169x1828361008(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_prelude_2efoldl_24s1576253813x218506563_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1576253813x218506563_entry, 2, 0};

V g_prelude_2efoldl_24s1576253813x218506563(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1576253813x218506563_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1576253813x218506563(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s50628766x1053431923_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s50628766x1053431923_entry, 2, 0};

V g_prelude_2efoldl_24s50628766x1053431923(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2evalueRefs(b_0)); heff_drop(b_0); r_; });
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s50628766x1053431923_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s50628766x1053431923(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efilter_24s1642131147x1885675035_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1642131147x1885675035_entry, 4, 0};

V g_prelude_2efilter_24s1642131147x1885675035(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strEq(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_prelude_2efilter_24s1642131147x1885675035(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2efilter_24s1642131147x1885675035_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1642131147x1885675035(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emap_24s1213322018x576418267_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1213322018x576418267_entry, 1, 0};

V g_prelude_2emap_24s1213322018x576418267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2eexportNameOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1213322018x576418267(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1213322018x576418267_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1213322018x576418267(a[0]);
}
Clo g_prelude_2emap_24s1865958870x1922568484_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1865958870x1922568484_entry, 1, 0};

V g_prelude_2emap_24s1865958870x1922568484(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2ehostLineOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1865958870x1922568484(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1865958870x1922568484_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1865958870x1922568484(a[0]);
}
Clo g_prelude_2emap_24s69486363x771070912_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s69486363x771070912_entry, 6, 0};

V g_prelude_2emap_24s69486363x771070912(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strEq(heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_244), heff_strLength(v_x_246));
      v_t_2410 = heff_strAppend(heff_dup(v_lit_243), v_t_249);
      break;
    }
    case TAG_False: {
      v_t_2410 = v_x_246;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s69486363x771070912(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_prelude_2emap_24s69486363x771070912_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s69486363x771070912(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_prelude_2emap_24s656438675x1758438999_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s656438675x1758438999_entry, 5, 0};

V g_prelude_2emap_24s656438675x1758438999(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), v_x_245, heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_248 = (g_heff_2eeffect_2edropLastD(v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      v_t_2411 = heff_dup(v_lit_242);
      break;
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_248, 0);
      V v_a_2410 = heff_field(v_a_248, 1);
      heff_take_n(v_a_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = heff_dup(v_lit_243); V a_1 = v_a_249; V a_2 = v_a_2410; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_a_2410); r_; });
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    return heff_tag_at(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_prelude_2emap_24s656438675x1758438999(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2emap_24s656438675x1758438999_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s656438675x1758438999(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2efilter_24s1338078379x1447244245_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1338078379x1447244245_entry, 4, 0};

V g_prelude_2efilter_24s1338078379x1447244245(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strEq(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_prelude_2efilter_24s1338078379x1447244245(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
    case TAG_False: {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2efilter_24s1338078379x1447244245_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1338078379x1447244245(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2eany_24s2123146976x1090108363_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s2123146976x1090108363_entry, 1, 0};

V g_prelude_2eany_24s2123146976x1090108363(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_strEq(heff_dup(v_x_241), heff_dup(g_heff_2eemit_2etrampolineStr_get()));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s2123146976x1090108363_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s2123146976x1090108363(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s1647342657x2122972612_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1647342657x2122972612_entry, 1, 0};

V g_prelude_2emap_24s1647342657x2122972612(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1647342657x2122972612(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1647342657x2122972612_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1647342657x2122972612(a[0]);
}
Clo g_prelude_2emap_24s1570887738x875765683_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1570887738x875765683_entry, 1, 0};

V g_prelude_2emap_24s1570887738x875765683(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1570887738x875765683(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1570887738x875765683_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1570887738x875765683(a[0]);
}
Clo g_prelude_2efoldl_24s1444443463x1097393542_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1444443463x1097393542_entry, 2, 0};

V g_prelude_2efoldl_24s1444443463x1097393542(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2eemitc_2etagsLbls(v_x_242));
    V v_t_2410;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2econcatList(v_a_245, v_a_247));
        v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, (g_prelude_2econcatList(v_a_246, v_a_248))});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1444443463x1097393542_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1444443463x1097393542(a[0], a[1]);
}
Clo g_prelude_2emap_24s64875302x2104538803_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s64875302x2104538803_entry, 1, 0};

V g_prelude_2emap_24s64875302x2104538803(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s64875302x2104538803(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s64875302x2104538803_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s64875302x2104538803(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s714974688x1763196797_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s714974688x1763196797_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s714974688x1763196797_entry, 1, 0};

V g_prelude_2emap_24s714974688x1763196797(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2emap_24s714974688x1763196797_str0)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s714974688x1763196797(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s714974688x1763196797_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s714974688x1763196797(a[0]);
}
Clo g_prelude_2efoldl_24s1316058048x1858230739_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1316058048x1858230739_entry, 2, 0};

V g_prelude_2efoldl_24s1316058048x1858230739(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1316058048x1858230739_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1316058048x1858230739(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s501072750x238687786_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s501072750x238687786_entry, 2, 0};

V g_prelude_2efoldl_24s501072750x238687786(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s501072750x238687786_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s501072750x238687786(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s403955490x958947996_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s403955490x958947996_entry, 7, 0};

V g_prelude_2emap_24s403955490x958947996(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_247, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_249, heff_dup(v_lit_245)));
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s403955490x958947996(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s403955490x958947996_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s403955490x958947996(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2eall_24s1176014659x1280298318_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s1176014659x1280298318_entry, 1, 0};

V g_prelude_2eall_24s1176014659x1280298318(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_pre);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_get(heff_dup(v_x_241), LBL_post);
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_243, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eall_24s1176014659x1280298318_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s1176014659x1280298318(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s1637992403x1199034636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1637992403x1199034636_entry, 1, 0};

V g_prelude_2emap_24s1637992403x1199034636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_arg), (g_prelude_2emap_24s1637992403x1199034636(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1637992403x1199034636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1637992403x1199034636(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2ezipWith_24s843461613x1902654784_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2ezipWith_24s843461613x1902654784_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2ezipWith_24s843461613x1902654784_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2ezipWith_24s843461613x1902654784_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_prelude_2ezipWith_24s843461613x1902654784_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s843461613x1902654784_entry, 2, 0};

V g_prelude_2ezipWith_24s843461613x1902654784(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_get(heff_dup(v_x_242), LBL_pre);
      V v_t_2412;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V v_t_247 = heff_strAppend(((V)&g_prelude_2ezipWith_24s843461613x1902654784_str0), heff_intShow(heff_dup(v_y_244)));
        V v_t_248 = heff_strAppend(((V)&g_prelude_2ezipWith_24s843461613x1902654784_str1), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_prelude_2ezipWith_24s843461613x1902654784_str2), heff_strAppend(heff_get(heff_dup(v_x_242), LBL_arg), ((V)&g_prelude_2ezipWith_24s843461613x1902654784_str3)))));
        V v_t_249 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        v_t_2412 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_247, v_t_249, heff_get(v_x_242, LBL_post)});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        heff_drop_cell(v_ru_24xs_240_24Cons, 2);
        heff_drop(v_y_244);
        v_t_2412 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2ezipWith_24s843461613x1902654784(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s843461613x1902654784_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s843461613x1902654784(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1053521454x4814067_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1053521454x4814067_entry, 2, 0};

V g_prelude_2efoldl_24s1053521454x4814067(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_pre), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1053521454x4814067_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1053521454x4814067(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s604575616x906292544_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s604575616x906292544_entry, 2, 0};

V g_prelude_2efoldl_24s604575616x906292544(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_post), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s604575616x906292544_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s604575616x906292544(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2ezipWith_24s380110282x409842715_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s380110282x409842715_entry, 9, 0};

V g_prelude_2ezipWith_24s380110282x409842715(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_xs_247, 0);
    V v_xs2_2410 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs2_2410);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_ys_248, 0);
      V v_ys2_2412 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_245), heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246)))));
      return heff_tag_at(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_prelude_2ezipWith_24s380110282x409842715(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs2_2410, v_ys2_2412))});
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_prelude_2ezipWith_24s380110282x409842715_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s380110282x409842715(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_prelude_2ezipWith_24s710811621x1872285139_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s710811621x1872285139_entry, 5, 0};

V g_prelude_2ezipWith_24s710811621x1872285139(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_y_247), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_245, heff_dup(v_lit_242)))));
      return heff_tag_at(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2ezipWith_24s710811621x1872285139(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248))});
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_prelude_2ezipWith_24s710811621x1872285139_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s710811621x1872285139(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2ezipWith_24s1919317536x560404246_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s1919317536x560404246_entry, 8, 0};

V g_prelude_2ezipWith_24s1919317536x560404246(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_xs_246, V v_ys_247) {
top: ;
  switch (heff_tag_of(v_xs_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_ys_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_xs_246, 0);
    V v_xs2_249 = heff_field(v_xs_246, 1);
    V v_ru_24xs_246_24Cons = heff_take_reuse_n(v_xs_246, 3ULL, 2);
    switch (heff_tag_of(v_ys_247)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_x_248);
      heff_drop(v_xs2_249);
      heff_drop_cell(v_ru_24xs_246_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2410 = heff_field(v_ys_247, 0);
      V v_ys2_2411 = heff_field(v_ys_247, 1);
      heff_take_n(v_ys_247, 3ULL, 2);
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), (g_heff_2eemitc_2emangleW(v_x_248, heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243))));
      V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(heff_intShow(v_y_2410), heff_dup(v_lit_245))));
      return heff_tag_at(v_ru_24xs_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, (g_prelude_2ezipWith_24s1919317536x560404246(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs2_249, v_ys2_2411))});
    }
    default: return heff_nomatch(v_ys_247);
    }
  }
  default: return heff_nomatch(v_xs_246);
  }
}
V g_prelude_2ezipWith_24s1919317536x560404246_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s1919317536x560404246(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_prelude_2eany_24s1185451557x1725025605_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s1185451557x1725025605_entry, 1, 0};

V g_prelude_2eany_24s1185451557x1725025605(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s1185451557x1725025605_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s1185451557x1725025605(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2ezipWith_24s2068631943x1980308664_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s2068631943x1980308664_entry, 2, 0};

V g_prelude_2ezipWith_24s2068631943x1980308664(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_prelude_2ezipWith_24s2068631943x1980308664(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s2068631943x1980308664_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s2068631943x1980308664(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s495138018x796798243_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s495138018x796798243_entry, 2, 0};

V g_prelude_2efoldl_24s495138018x796798243(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s495138018x796798243_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s495138018x796798243(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s211374770x467200965_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s211374770x467200965_entry, 6, 0};

V g_prelude_2emap_24s211374770x467200965(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_246, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)))));
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s211374770x467200965(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_prelude_2emap_24s211374770x467200965_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s211374770x467200965(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_prelude_2emap_24s1915255123x866970157_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1915255123x866970157_entry, 3, 0};

V g_prelude_2emap_24s1915255123x866970157(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241)));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s1915255123x866970157(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2emap_24s1915255123x866970157_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1915255123x866970157(a[0], a[1], a[2]);
}
Clo g_prelude_2emap_24s1632715577x1165353341_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1632715577x1165353341_entry, 4, 0};

V g_prelude_2emap_24s1632715577x1165353341(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s1632715577x1165353341(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s1632715577x1165353341_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1632715577x1165353341(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2eany_24s1630892143x990483949_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s1630892143x990483949_entry, 1, 0};

V g_prelude_2eany_24s1630892143x990483949(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      V v_x1_248;
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_2410 = (g_heff_2eemitc_2ebuildsSize(v_t_249, heff_dup(v_b_245)));
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s1630892143x990483949_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s1630892143x990483949(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s399995414x989248031_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s399995414x989248031_entry, 3, 0};

V g_prelude_2emap_24s399995414x989248031(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_a_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_247; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_a_247); r_; });
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_prelude_2emap_24s399995414x989248031(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2emap_24s399995414x989248031_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s399995414x989248031(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s1646985801x1714719388_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1646985801x1714719388_entry, 2, 0};

V g_prelude_2efoldl_24s1646985801x1714719388(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1646985801x1714719388_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1646985801x1714719388(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1999424249x920937090_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1999424249x920937090_entry, 2, 0};

V g_prelude_2efoldl_24s1999424249x920937090(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1999424249x920937090_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1999424249x920937090(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s597794505x1651330542_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s597794505x1651330542_entry, 7, 0};

V g_prelude_2emap_24s597794505x1651330542(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_a_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_a_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2415))));
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_prelude_2emap_24s597794505x1651330542(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s597794505x1651330542_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s597794505x1651330542(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2efilter_24s568328629x1584314777_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s568328629x1584314777_entry, 1, 0};

V g_prelude_2efilter_24s568328629x1584314777(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s568328629x1584314777(v_xs_242))});
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s568328629x1584314777_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s568328629x1584314777(a[0]);
}
Clo g_prelude_2emap_24s1487602620x924655663_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1487602620x924655663_entry, 1, 0};

V g_prelude_2emap_24s1487602620x924655663(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2eshapeDef(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1487602620x924655663(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1487602620x924655663_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1487602620x924655663(a[0]);
}
Clo g_prelude_2efoldl_24s2112793642x1092684128_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2112793642x1092684128_entry, 2, 0};

V g_prelude_2efoldl_24s2112793642x1092684128(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_protos), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s2112793642x1092684128_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2112793642x1092684128(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s864016152x1913649801_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s864016152x1913649801_entry, 2, 0};

V g_prelude_2efoldl_24s864016152x1913649801(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s864016152x1913649801_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s864016152x1913649801(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s531085679x1988854183_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s531085679x1988854183_entry, 2, 0};

V g_prelude_2efoldl_24s531085679x1988854183(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_x_242), LBL_code), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s531085679x1988854183_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s531085679x1988854183(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efilter_24s640953257x788905679_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s640953257x788905679_entry, 1, 0};

V g_prelude_2efilter_24s640953257x788905679(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s640953257x788905679(v_xs_242))});
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s640953257x788905679_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s640953257x788905679(a[0]);
}
Clo g_prelude_2efoldl_24s2097992228x1423179758_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s2097992228x1423179758_entry, 4, 0};

V g_prelude_2efoldl_24s2097992228x1423179758(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2eemitc_2enamesInGo(heff_dup(v_lit_240), heff_get(heff_dup(v_x_244), LBL_text), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_prelude_2efoldl_24s2097992228x1423179758_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s2097992228x1423179758(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_prelude_2efoldl_24s1389621742x246323093_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1389621742x246323093_entry, 2, 0};

V g_prelude_2efoldl_24s1389621742x246323093(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1389621742x246323093_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1389621742x246323093(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1822565136x94632375_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1822565136x94632375_entry, 2, 0};

V g_prelude_2efoldl_24s1822565136x94632375(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2413 = (g_map_2elookup_24s1546226666x2146984184(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 1);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_246, heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1822565136x94632375_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1822565136x94632375(a[0], a[1]);
}
Clo g_prelude_2emap_24s1504295295x438292075_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1504295295x438292075_entry, 1, 0};

V g_prelude_2emap_24s1504295295x438292075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2epubLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1504295295x438292075(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1504295295x438292075_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1504295295x438292075(a[0]);
}
Clo g_prelude_2emap_24s1429136355x479526015_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1429136355x479526015_entry, 2, 0};

V g_prelude_2emap_24s1429136355x479526015(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1429136355x479526015(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1429136355x479526015_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1429136355x479526015(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_prelude_2efilter_24s2061636403x27832284_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 103, 95}};
Clo g_prelude_2efilter_24s2061636403x27832284_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s2061636403x27832284_entry, 1, 0};

V g_prelude_2efilter_24s2061636403x27832284(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_prelude_2efilter_24s2061636403x27832284_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s2061636403x27832284(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s2061636403x27832284_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s2061636403x27832284(a[0]);
}
Clo g_prelude_2efoldl_24s1046327220x1508260955_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1046327220x1508260955_entry, 10, 0};

V g_prelude_2efoldl_24s1046327220x1508260955(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get(v_a_2412, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_a_2414), heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2416 = heff_intLt(heff_dup(v_a_2415), heff_dup(v_lit_242));
    V v_t_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_a_2415);
      v_t_2417 = v_a_2414;
      break;
    }
    case TAG_False: {
      v_t_2417 = heff_strSlice(v_a_2414, heff_dup(v_lit_243), v_a_2415);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_a_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2420 = heff_get(v_a_2418, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2421 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_a_2420), heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2422 = heff_intLt(heff_dup(v_a_2421), heff_dup(v_lit_246));
    V v_t_2423;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_a_2421);
      v_t_2423 = v_a_2420;
      break;
    }
    case TAG_False: {
      v_t_2423 = heff_strSlice(v_a_2420, heff_dup(v_lit_247), v_a_2421);
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_a_2424 = (g_map_2elookup_24s1546226666x2146984184(v_t_2423, v_z_248));
    V v_t_2426;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2425 = heff_field(v_a_2424, 0);
      heff_take_n(v_a_2424, 1ULL, 1);
      v_t_2426 = v_a_2425;
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_t_2417, heff_tag_at(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2426}), v_z_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2427;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_prelude_2efoldl_24s1046327220x1508260955_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1046327220x1508260955(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_prelude_2emap_24s1853832113x1514640231_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1853832113x1514640231_entry, 1, 0};

V g_prelude_2emap_24s1853832113x1514640231(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_t_245, LBL_body), (g_prelude_2emap_24s1853832113x1514640231(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1853832113x1514640231_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1853832113x1514640231(a[0]);
}
Clo g_prelude_2efoldl_24s1117851236x353501360_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1117851236x353501360_entry, 2, 0};

V g_prelude_2efoldl_24s1117851236x353501360(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2eir_2eglobalsGo(heff_get(heff_dup(v_a_244), LBL_body)));
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get(v_a_244, LBL_key), (g_heff_2eir_2enubI(v_t_246))});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1117851236x353501360_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1117851236x353501360(a[0], a[1]);
}
Clo g_prelude_2emap_24s60916294x70162967_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s60916294x70162967_entry, 1, 0};

V g_prelude_2emap_24s60916294x70162967(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_body), (g_prelude_2emap_24s60916294x70162967(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s60916294x70162967_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s60916294x70162967(a[0]);
}
Clo g_prelude_2emap_24s1248084495x1713083677_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1248084495x1713083677_entry, 6, 0};

V g_prelude_2emap_24s1248084495x1713083677(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    V v_t_249 = heff_strEq(v_t_248, heff_dup(v_lit_242));
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      v_t_2410 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eemitc_2eidentAt(v_x_246, heff_dup(v_lit_243), heff_dup(v_lit_244)))});
      break;
    }
    case TAG_False: {
      heff_drop(v_x_246);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s1248084495x1713083677(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_prelude_2emap_24s1248084495x1713083677_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1248084495x1713083677(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_prelude_2efoldl_24s350630889x2058245268_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s350630889x2058245268_entry, 2, 0};

V g_prelude_2efoldl_24s350630889x2058245268(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strAppend(v_z_240, heff_strAppend(heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s350630889x2058245268_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s350630889x2058245268(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1673264634x1364192364_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1673264634x1364192364_entry, 2, 0};

V g_prelude_2efoldl_24s1673264634x1364192364(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2edoc_2e_3c_3e(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1673264634x1364192364_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1673264634x1364192364(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s2124417180x1682105150_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s2124417180x1682105150_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s2124417180x1682105150_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_prelude_2emap_24s2124417180x1682105150_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2124417180x1682105150_entry, 1, 0};

V g_prelude_2emap_24s2124417180x1682105150(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s2124417180x1682105150_str0), heff_get(v_x_241, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_prelude_2emap_24s2124417180x1682105150_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s350630889x2058245268(a_0, a_1)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_prelude_2emap_24s2124417180x1682105150_str2));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s2124417180x1682105150(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2124417180x1682105150_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2124417180x1682105150(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1688359605x701894798_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1688359605x701894798_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1688359605x701894798_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1688359605x701894798_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_prelude_2emap_24s1688359605x701894798_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1688359605x701894798_entry, 1, 0};

V g_prelude_2emap_24s1688359605x701894798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_prelude_2emap_24s1688359605x701894798_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_prelude_2emap_24s1688359605x701894798_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s350630889x2058245268(a_0, a_1)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_prelude_2emap_24s1688359605x701894798_str2));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_248, heff_tag(TAG_Text, 1, (V[]){((V)&g_prelude_2emap_24s1688359605x701894798_str3)})));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s1688359605x701894798(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1688359605x701894798_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1688359605x701894798(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2eany_24s486367843x134447435_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {45, 45, 32, 102, 109, 116, 58, 32, 115, 107, 105, 112}};
Clo g_prelude_2eany_24s486367843x134447435_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s486367843x134447435_entry, 1, 0};

V g_prelude_2eany_24s486367843x134447435(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_get(heff_dup(v_x_241), LBL_text);
    V v_t_244 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength(heff_dup(v_s_243))));
    V v_t_245 = heff_strEq(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_prelude_2eany_24s486367843x134447435_str0));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s486367843x134447435_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s486367843x134447435(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s1662385255x221899605_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1662385255x221899605_entry, 1, 0};

V g_prelude_2emap_24s1662385255x221899605(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_prelude_2emap_24s1662385255x221899605(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1662385255x221899605_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1662385255x221899605(a[0]);
}
Clo g_prelude_2emap_24s211672092x1360624114_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s211672092x1360624114_entry, 1, 0};

V g_prelude_2emap_24s211672092x1360624114(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength(heff_dup(v_x_241))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), (g_prelude_2emap_24s211672092x1360624114(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s211672092x1360624114_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s211672092x1360624114(a[0]);
}
Clo g_prelude_2emap_24s242074595x1610727405_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s242074595x1610727405_entry, 7, 0};

V g_prelude_2emap_24s242074595x1610727405(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_prelude_2emap_24s1559710030x546042594(heff_dup(v_lit_242), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      v_t_2418 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2417, heff_dup(v_lit_245))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_prelude_2emap_24s242074595x1610727405(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2emap_24s242074595x1610727405_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s242074595x1610727405(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_prelude_2emap_24s229671972x1653917392_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s229671972x1653917392_entry, 1, 0};

V g_prelude_2emap_24s229671972x1653917392(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eformat_2epatKey(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s229671972x1653917392(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s229671972x1653917392_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s229671972x1653917392(a[0]);
}
Clo g_prelude_2emap_24s913954207x1153178935_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s913954207x1153178935_entry, 1, 0};

V g_prelude_2emap_24s913954207x1153178935(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_msg), (g_prelude_2emap_24s913954207x1153178935(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s913954207x1153178935_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s913954207x1153178935(a[0]);
}
Clo g_prelude_2emap_24s792566809x1637979488_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s792566809x1637979488_entry, 2, 0};

V g_prelude_2emap_24s792566809x1637979488(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get(v_x_242, LBL_text);
    V v_t_245 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_244), heff_strLength(heff_dup(v_a_244))));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_a_244, heff_dup(v_lit_240), v_t_245), (g_prelude_2emap_24s792566809x1637979488(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s792566809x1637979488_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s792566809x1637979488(a[0], a[1]);
}
Clo g_prelude_2eall_24s1095920613x165325623_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s1095920613x165325623_entry, 3, 0};

V g_prelude_2eall_24s1095920613x165325623(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_intLe(heff_dup(v_lit_240), heff_dup(v_x_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intLe(heff_dup(v_x_243), heff_dup(v_lit_241));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2eall_24s1095920613x165325623_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s1095920613x165325623(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_prelude_2emap_24s1465695349x56206694_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1465695349x56206694_entry, 2, 0};

V g_prelude_2emap_24s1465695349x56206694(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = (g_prelude_2eparseInt(v_x_242));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s1465695349x56206694(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1465695349x56206694_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1465695349x56206694(a[0], a[1]);
}
Clo g_prelude_2eall_24s632542597x363082259_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eall_24s632542597x363082259_entry, 13, 0};

V g_prelude_2eall_24s632542597x363082259(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_t_2415 = heff_intLe(heff_dup(v_lit_240), heff_dup(v_x_2413));
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      v_t_2416 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_241));
      break;
    }
    case TAG_False: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    }
    case TAG_False: {
      V v_t_2417 = heff_intLe(heff_dup(v_lit_242), heff_dup(v_x_2413));
      V v_t_2423;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        V v_t_2418 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_243));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          v_t_2423 = NTAG(TAG_True);
          break;
        }
        case TAG_False: {
          V v_t_2419 = heff_intLe(heff_dup(v_lit_244), heff_dup(v_x_2413));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_True: {
            V v_t_2420 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_245));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_True: {
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_False: {
              v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_246));
              break;
            }
            default: heff_nomatch(v_t_2420);
            }
            break;
          }
          case TAG_False: {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_247));
            break;
          }
          default: heff_nomatch(v_t_2419);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_False: {
        V v_t_2421 = heff_intLe(heff_dup(v_lit_248), heff_dup(v_x_2413));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          V v_t_2422 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_249));
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            v_t_2423 = NTAG(TAG_True);
            break;
          }
          case TAG_False: {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2410));
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          break;
        }
        case TAG_False: {
          v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2411));
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        heff_drop(v_lit_2410);
        heff_drop(v_lit_2411);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_prelude_2eall_24s632542597x363082259_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eall_24s632542597x363082259(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12]); heff_drop(a[12]); return r;
}
Clo g_prelude_2ezipWith_24s63513682x397084279_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ezipWith_24s63513682x397084279_entry, 2, 0};

V g_prelude_2ezipWith_24s63513682x397084279(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_y_244, LBL_name), v_x_242});
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2ezipWith_24s63513682x397084279(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2ezipWith_24s63513682x397084279_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ezipWith_24s63513682x397084279(a[0], a[1]);
}
Clo g_prelude_2emap_24s173337351x1152519035_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s173337351x1152519035_entry, 4, 0};

V g_prelude_2emap_24s173337351x1152519035(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_get(heff_dup(v_x_244), LBL_path), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_version), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(v_x_244, LBL_hash), heff_dup(v_lit_242))))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s173337351x1152519035(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s173337351x1152519035_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s173337351x1152519035(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emerge_24s751234234x1956863352_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s751234234x1956863352_entry, 2, 0};

V g_prelude_2emerge_24s751234234x1956863352(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s751234234x1956863352(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s751234234x1956863352(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s751234234x1956863352_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s751234234x1956863352(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s1510757765x2064206644_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s1510757765x2064206644_entry, 1, 0};

V g_prelude_2esortBy_24s1510757765x2064206644(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s1510757765x2064206644(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s1510757765x2064206644(v_t_2411));
      return (g_prelude_2emerge_24s751234234x1956863352(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s1510757765x2064206644_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s1510757765x2064206644(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s974831774x882761225_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s974831774x882761225_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {44, 32, 112, 97, 116, 104, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_prelude_2emap_24s974831774x882761225_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {44, 32, 118, 101, 114, 115, 105, 111, 110, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s974831774x882761225_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_prelude_2emap_24s974831774x882761225_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s974831774x882761225_entry, 1, 0};

V g_prelude_2emap_24s974831774x882761225(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_path)));
    V v_t_245 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_version)));
    V v_t_246 = heff_strAppend(((V)&g_prelude_2emap_24s974831774x882761225_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_prelude_2emap_24s974831774x882761225_str1), heff_strAppend(v_t_244, heff_strAppend(((V)&g_prelude_2emap_24s974831774x882761225_str2), heff_strAppend(v_t_245, ((V)&g_prelude_2emap_24s974831774x882761225_str3)))))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_prelude_2emap_24s974831774x882761225(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s974831774x882761225_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s974831774x882761225(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_prelude_2emap_24s2144452760x1823476610_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_prelude_2emap_24s2144452760x1823476610_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 100, 105, 114, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_prelude_2emap_24s2144452760x1823476610_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_prelude_2emap_24s2144452760x1823476610_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2144452760x1823476610_entry, 1, 0};

V g_prelude_2emap_24s2144452760x1823476610(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_dir)));
    V v_t_245 = heff_strAppend(((V)&g_prelude_2emap_24s2144452760x1823476610_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_prelude_2emap_24s2144452760x1823476610_str1), heff_strAppend(v_t_244, ((V)&g_prelude_2emap_24s2144452760x1823476610_str2)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s2144452760x1823476610(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2144452760x1823476610_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2144452760x1823476610(a[0]);
}
Clo g_prelude_2emap_24s2130727578x764334370_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2130727578x764334370_entry, 1, 0};

V g_prelude_2emap_24s2130727578x764334370(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_path)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s2130727578x764334370(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s2130727578x764334370_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2130727578x764334370(a[0]);
}
Clo g_prelude_2efoldl_24s701395232x704703097_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s701395232x704703097_entry, 2, 0};

V g_prelude_2efoldl_24s701395232x704703097(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_x_242), LBL_path), heff_get(heff_dup(v_z_240), LBL_path));
    V v_t_2412;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_a_245 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_x_242), LBL_version)));
      V v_t_247;
      switch (heff_tag_of(v_a_245)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V v_a_248 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_z_240), LBL_version)));
      V v_t_2410;
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        v_t_2410 = v_a_249;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      V v_t_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_z_240);
        v_t_2412 = heff_dup(v_x_242);
        break;
      }
      case TAG_False: {
        v_t_2412 = v_z_240;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_False: {
      v_t_2412 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s701395232x704703097_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s701395232x704703097(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_prelude_2efoldl_24s1064255209x1797926961_lam0(V self, V *args);
Clo g_prelude_2efoldl_24s1064255209x1797926961_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1064255209x1797926961_entry, 2, 0};

V g_prelude_2efoldl_24s1064255209x1797926961(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_prelude_2eany(heff_clo(g_prelude_2efoldl_24s1064255209x1797926961_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_z_240));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_247 = (g_prelude_2econcatList(v_z_240, v_t_246));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1064255209x1797926961_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1064255209x1797926961(a[0], a[1]);
}
V g_prelude_2efoldl_24s1064255209x1797926961_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_a_244, LBL_path), heff_get(v_x_242, LBL_path));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s1304302839x769116801_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
Clo g_prelude_2emap_24s1304302839x769116801_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1304302839x769116801_entry, 1, 0};

V g_prelude_2emap_24s1304302839x769116801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_245 = heff_strEq(v_t_244, ((V)&g_prelude_2emap_24s1304302839x769116801_str0));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
      break;
    }
    case TAG_False: {
      v_t_247 = v_x_241;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_prelude_2emap_24s1304302839x769116801(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1304302839x769116801_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1304302839x769116801(a[0]);
}
Clo g_prelude_2emap_24s816432673x804125000_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s816432673x804125000_entry, 1, 0};

V g_prelude_2emap_24s816432673x804125000(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_path), (g_prelude_2emap_24s816432673x804125000(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s816432673x804125000_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s816432673x804125000(a[0]);
}
Clo g_prelude_2efoldl_24s1357015314x1549495538_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1357015314x1549495538_entry, 2, 0};

V g_prelude_2efoldl_24s1357015314x1549495538(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2elocals_2epatternBinders(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1357015314x1549495538_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1357015314x1549495538(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s681048622x785935498_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s681048622x785935498_entry, 2, 0};

V g_prelude_2efoldl_24s681048622x785935498(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2econcatList(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s681048622x785935498_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s681048622x785935498(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1557394611x1393897318_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1557394611x1393897318_entry, 1, 0};

V g_prelude_2emap_24s1557394611x1393897318(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_use), (g_prelude_2emap_24s1557394611x1393897318(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1557394611x1393897318_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1557394611x1393897318(a[0]);
}
Clo g_prelude_2efilter_24s47197728x1723782535_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s47197728x1723782535_entry, 1, 0};

V g_prelude_2efilter_24s47197728x1723782535(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s47197728x1723782535(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s47197728x1723782535_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s47197728x1723782535(a[0]);
}
Clo g_prelude_2emap_24s17448335x896291650_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s17448335x896291650_entry, 1, 0};

V g_prelude_2emap_24s17448335x896291650(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_name);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_span);
    V v_t_245 = heff_rec(3, shape_name__field__use, (V[]){v_t_243, v_t_244, heff_get(v_x_241, LBL_use)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2emap_24s17448335x896291650(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s17448335x896291650_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s17448335x896291650(a[0]);
}
Clo g_prelude_2efilter_24s37718278x420368011_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s37718278x420368011_entry, 1, 0};

V g_prelude_2efilter_24s37718278x420368011(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s37718278x420368011(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s37718278x420368011_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s37718278x420368011(a[0]);
}
Clo g_prelude_2efoldl_24s769801084x309638513_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s769801084x309638513_entry, 2, 0};

V g_prelude_2efoldl_24s769801084x309638513(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2elocals_2edeclaration(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(heff_get(heff_dup(v_z_240), LBL_binders), heff_get(heff_dup(v_a_244), LBL_binders)));
    V v_t_246 = (g_prelude_2econcatList(heff_get(v_z_240, LBL_uses), heff_get(v_a_244, LBL_uses)));
    V t_0 = heff_rec(2, shape_binders__uses, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s769801084x309638513_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s769801084x309638513(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s647676823x121149293_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s647676823x121149293_entry, 2, 0};

V g_prelude_2emerge_24s647676823x121149293(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_intLe(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s647676823x121149293(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s647676823x121149293(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s647676823x121149293_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s647676823x121149293(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s836118211x1760819460_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s836118211x1760819460_entry, 1, 0};

V g_prelude_2esortBy_24s836118211x1760819460(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s836118211x1760819460(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s836118211x1760819460(v_t_2411));
      return (g_prelude_2emerge_24s647676823x121149293(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s836118211x1760819460_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s836118211x1760819460(a[0]);
}
Clo g_prelude_2emerge_24s425238775x1129884419_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s425238775x1129884419_entry, 2, 0};

V g_prelude_2emerge_24s425238775x1129884419(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
      V v_t_247 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_248 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_end);
      V v_t_249 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      V v_t_2410 = heff_intLe(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s425238775x1129884419(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s425238775x1129884419(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s425238775x1129884419_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s425238775x1129884419(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s1126449973x1849170820_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s1126449973x1849170820_entry, 1, 0};

V g_prelude_2esortBy_24s1126449973x1849170820(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s1126449973x1849170820(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s1126449973x1849170820(v_t_2411));
      return (g_prelude_2emerge_24s425238775x1129884419(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s1126449973x1849170820_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s1126449973x1849170820(a[0]);
}
Clo g_prelude_2emerge_24s1272611763x329559950_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s1272611763x329559950_entry, 2, 0};

V g_prelude_2emerge_24s1272611763x329559950(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_strLt(heff_get(heff_dup(v_y_244), LBL_label), heff_get(heff_dup(v_x_242), LBL_label));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s1272611763x329559950(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s1272611763x329559950(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s1272611763x329559950_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s1272611763x329559950(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s41792244x2038093117_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s41792244x2038093117_entry, 1, 0};

V g_prelude_2esortBy_24s41792244x2038093117(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s41792244x2038093117(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s41792244x2038093117(v_t_2411));
      return (g_prelude_2emerge_24s1272611763x329559950(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s41792244x2038093117_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s41792244x2038093117(a[0]);
}
Clo g_prelude_2emap_24s15155233x988412698_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s15155233x988412698_entry, 1, 0};

V g_prelude_2emap_24s15155233x988412698(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s15155233x988412698(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s15155233x988412698_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s15155233x988412698(a[0]);
}
Clo g_prelude_2emap_24s1877418456x1713671328_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1877418456x1713671328_entry, 1, 0};

V g_prelude_2emap_24s1877418456x1713671328(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_prelude_2emap_24s1877418456x1713671328(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1877418456x1713671328_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1877418456x1713671328(a[0]);
}
Clo g_prelude_2emap_24s494516475x121191125_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s494516475x121191125_entry, 1, 0};

V g_prelude_2emap_24s494516475x121191125(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2emap_24s494516475x121191125(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s494516475x121191125_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s494516475x121191125(a[0]);
}
Clo g_prelude_2emap_24s1376040924x483198033_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1376040924x483198033_entry, 1, 0};

V g_prelude_2emap_24s1376040924x483198033(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_span), (g_prelude_2emap_24s1376040924x483198033(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1376040924x483198033_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1376040924x483198033(a[0]);
}
Clo g_prelude_2efoldl_24s1973736539x1572903678_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1973736539x1572903678_entry, 3, 0};

V g_prelude_2efoldl_24s1973736539x1572903678(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2427;
    switch (heff_tag_of(v_t_247)) {
    case TAG_DeclEquations: {
      V v_a_248 = heff_field(v_t_247, 0);
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 4);
      v_t_2427 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec(3, shape_name__kind__span, (V[]){v_a_248, heff_dup(v_lit_240), v_a_249}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_247, 0ULL, 5);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_247, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2428 = (g_prelude_2econcatList(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s1973736539x1572903678_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1973736539x1572903678(a[0], a[1], a[2]);
}
Clo g_prelude_2efind_24s1637404220x1380860409_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_24s1637404220x1380860409_entry, 1, 0};

V g_prelude_2efind_24s1637404220x1380860409(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    V v_a_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_a_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_a_245 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_a_245)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    default: return heff_nomatch(v_a_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efind_24s1637404220x1380860409_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind_24s1637404220x1380860409(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2efilter_24s1597546471x2138686503_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1597546471x2138686503_entry, 1, 0};

V g_prelude_2efilter_24s1597546471x2138686503(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1597546471x2138686503(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1597546471x2138686503_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1597546471x2138686503(a[0]);
}
Clo g_prelude_2efoldl_24s816873524x558560359_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s816873524x558560359_entry, 2, 0};

V g_prelude_2efoldl_24s816873524x558560359(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s816873524x558560359_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s816873524x558560359(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s506072539x1484723861_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s506072539x1484723861_entry, 2, 0};

V g_prelude_2efoldl_24s506072539x1484723861(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2econcatList(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2413)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2econcatList(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s506072539x1484723861_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s506072539x1484723861(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1922900173x1150302326_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1922900173x1150302326_entry, 2, 0};

V g_prelude_2efoldl_24s1922900173x1150302326(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_prelude_2efoldl_24s816873524x558560359(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2410)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2econcatList(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1922900173x1150302326_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1922900173x1150302326(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s590241118x1980030762_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s590241118x1980030762_entry, 2, 0};

V g_prelude_2efoldl_24s590241118x1980030762(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_249)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2econcatList(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s590241118x1980030762_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s590241118x1980030762(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s237886021x1218291248_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s237886021x1218291248_entry, 2, 0};

V g_prelude_2efoldl_24s237886021x1218291248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_247)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2econcatList(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s237886021x1218291248_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s237886021x1218291248(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s984477481x2143447432_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s984477481x2143447432_entry, 2, 0};

V g_prelude_2efoldl_24s984477481x2143447432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_StmtBind: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_StmtLet: {
        V v_a_2410 = heff_field(v_a_244, 1);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2410)));
        break;
      }
      case TAG_StmtExpr: {
        V v_a_2411 = heff_field(v_a_244, 0);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2econcatList(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s984477481x2143447432_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s984477481x2143447432(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s1392147342x903269690_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1392147342x903269690_entry, 2, 0};

V g_prelude_2efoldl_24s1392147342x903269690(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_249)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2econcatList(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1392147342x903269690_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1392147342x903269690(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s896300760x849537974_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s896300760x849537974_entry, 2, 0};

V g_prelude_2efoldl_24s896300760x849537974(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2econcatList(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s896300760x849537974_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s896300760x849537974(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s232250958x604861464_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s232250958x604861464_entry, 2, 0};

V g_prelude_2efoldl_24s232250958x604861464(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalDeclF_24s535437546x2025255677(v_x_242));
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s232250958x604861464_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s232250958x604861464(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emerge_24s1524561266x851549973_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emerge_24s1524561266x851549973_entry, 2, 0};

V g_prelude_2emerge_24s1524561266x851549973(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_247 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      V v_t_248 = heff_intLe(v_t_246, v_t_247);
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2emerge_24s1524561266x851549973(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_prelude_2emerge_24s1524561266x851549973(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2emerge_24s1524561266x851549973_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emerge_24s1524561266x851549973(a[0], a[1]);
}
Clo g_prelude_2esortBy_24s2110005585x1390303319_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esortBy_24s2110005585x1390303319_entry, 1, 0};

V g_prelude_2esortBy_24s2110005585x1390303319(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_prelude_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_prelude_2esortBy_24s2110005585x1390303319(v_t_247));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_prelude_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_prelude_2esortBy_24s2110005585x1390303319(v_t_2411));
      return (g_prelude_2emerge_24s1524561266x851549973(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_prelude_2esortBy_24s2110005585x1390303319_entry(V self, V *a) {
  (void)self;
  return g_prelude_2esortBy_24s2110005585x1390303319(a[0]);
}
Clo g_prelude_2efoldl_24s1736949044x1572399628_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1736949044x1572399628_entry, 2, 0};

V g_prelude_2efoldl_24s1736949044x1572399628(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_a_244), v_z_240));
      switch (heff_tag_of(v_a_246)) {
      case TAG_Nothing: {
        v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_a_244), heff_dup(v_a_245), v_z_240));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_248 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1736949044x1572399628_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s1736949044x1572399628(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s1777922978x1620890802_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1777922978x1620890802_entry, 8, 0};

V g_prelude_2emap_24s1777922978x1620890802(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_get(heff_dup(v_x_248), LBL_assoc);
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_AssocLeft: {
      v_t_2411 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2411 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2411 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = heff_get(heff_dup(v_x_248), LBL_ops);
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = heff_dup(v_lit_245);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_t_2412, 0);
      V v_a_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = heff_dup(v_lit_246); V a_1 = v_a_2413; V a_2 = v_a_2414; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_a_2414); r_; });
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = heff_strAppend(heff_get(v_x_248, LBL_id), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_2411), heff_strAppend(heff_dup(v_lit_244), v_t_2415))));
    return heff_tag_at(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_prelude_2emap_24s1777922978x1620890802(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249))});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2emap_24s1777922978x1620890802_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1777922978x1620890802(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_prelude_2emap_24s246962053x1319174229_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s246962053x1319174229_entry, 2, 0};

V g_prelude_2emap_24s246962053x1319174229(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_get(heff_dup(v_x_242), LBL_tighter), heff_strAppend(heff_dup(v_lit_240), heff_get(v_x_242, LBL_looser)));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s246962053x1319174229(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s246962053x1319174229_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s246962053x1319174229(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s161191159x1526680900_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s161191159x1526680900_entry, 3, 0};

V g_prelude_2efoldl_24s161191159x1526680900(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2econcatList(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2efoldl_24s161191159x1526680900_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s161191159x1526680900(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s1492741819x1368648142_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1492741819x1368648142_entry, 9, 0};

V g_prelude_2efoldl_24s1492741819x1368648142(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_z_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return v_z_247;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x3_248, 0);
    V v_xs_2410 = heff_field(v_x3_248, 1);
    V v_ru_24x3_248_24Cons = heff_take_reuse_n(v_x3_248, 3ULL, 2);
    V v_a_2411 = heff_get(heff_dup(v_x_249), LBL_id);
    V v_t_2412 = heff_intShow(heff_strLength(heff_dup(v_a_2411)));
    V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_a_2411));
    V v_t_2414 = heff_get(heff_dup(v_x_249), LBL_assoc);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_AssocLeft: {
      v_t_2415 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2415 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2415 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_a_2416 = heff_get(v_x_249, LBL_ops);
    V v_t_2417 = (g_prelude_2efoldl_24s1226147011x367015740(heff_dup(v_lit_244), heff_dup(v_lit_245), v_a_2416));
    V v_t_2418 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_a_2416));
    V v_t_2419 = heff_tag_at(v_ru_24x3_248_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), (g_prelude_2efoldl_24s161191159x1526680900(heff_dup(v_lit_246), NTAG(TAG_Nil), v_t_2418))});
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2419});
    V v_t_2421 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_2413, v_t_2420}), v_z_247));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_t_2421;
    V t_8 = v_xs_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_z_247 = t_7;
    v_x3_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x3_248);
  }
}
V g_prelude_2efoldl_24s1492741819x1368648142_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1492741819x1368648142(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_prelude_2efoldl_24s672667169x1604568063_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s672667169x1604568063_entry, 4, 0};

V g_prelude_2efoldl_24s672667169x1604568063(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = heff_get(heff_dup(v_x_244), LBL_tighter);
    V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
    V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_a_246));
    V v_a_249 = heff_get(v_x_244, LBL_looser);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(heff_dup(v_lit_241), v_a_249));
    V v_t_2412 = heff_tag_at(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2412}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_prelude_2efoldl_24s672667169x1604568063_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s672667169x1604568063(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emap_24s1073181564x1056668167_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1073181564x1056668167_entry, 5, 0};

V g_prelude_2emap_24s1073181564x1056668167(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_249), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_2415;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_242)});
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nil: {
        heff_drop(v_a_2411);
        v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_243)});
        break;
      }
      case TAG_Cons: {
        V v_a_2413 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 2);
        heff_drop(v_a_249);
        v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, v_a_2413});
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2415, (g_prelude_2emap_24s1073181564x1056668167(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2emap_24s1073181564x1056668167_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1073181564x1056668167(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2efilter_24s189668615x351352663_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s189668615x351352663_entry, 2, 0};

V g_prelude_2efilter_24s189668615x351352663(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intEq(heff_get(heff_dup(v_x_242), LBL_parent), heff_dup(v_lit_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_prelude_2efilter_24s189668615x351352663(v_lit_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efilter_24s189668615x351352663_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s189668615x351352663(a[0], a[1]);
}
Clo g_prelude_2efoldl_24s1838030138x788027388_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s1838030138x788027388_entry, 2, 0};

V g_prelude_2efoldl_24s1838030138x788027388(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_get(heff_dup(v_z_240), LBL_errors)});
    V v_t_245 = heff_rec(5, shape_sources__errors__paths__package__packages, (V[]){heff_get(heff_dup(v_z_240), LBL_sources), v_t_244, heff_get(heff_dup(v_z_240), LBL_paths), heff_get(heff_dup(v_z_240), LBL_package), heff_get(v_z_240, LBL_packages)});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s1838030138x788027388_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efoldl_24s1838030138x788027388(a[0], a[1]);
}
Clo g_prelude_2eany_24s827288872x1370860167_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s827288872x1370860167_entry, 1, 0};

V g_prelude_2eany_24s827288872x1370860167(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_prelude_2efilter_24s1056866665x1882138159(heff_get(heff_dup(v_x_241), LBL_diags)));
    V v_a_246;
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      v_a_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_a_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2eany_24s827288872x1370860167_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s827288872x1370860167(a[0]); heff_drop(a[0]); return r;
}
Clo g_prelude_2emap_24s546221959x1645923250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s546221959x1645923250_entry, 1, 0};

V g_prelude_2emap_24s546221959x1645923250(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_name__key, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s546221959x1645923250(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s546221959x1645923250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s546221959x1645923250(a[0]);
}
Clo g_prelude_2emap_24s554277126x598800825_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s554277126x598800825_entry, 1, 0};

V g_prelude_2emap_24s554277126x598800825(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s554277126x598800825(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s554277126x598800825_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s554277126x598800825(a[0]);
}
Clo g_prelude_2efilter_24s419026844x1025599777_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s419026844x1025599777_entry, 3, 0};

V g_prelude_2efilter_24s419026844x1025599777(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_x_243)), heff_strLength(heff_dup(v_lit_240)));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), v_t_245, heff_strLength(heff_dup(v_x_243)));
    V v_t_247 = heff_strEq(v_t_246, heff_dup(v_lit_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_prelude_2efilter_24s419026844x1025599777(v_lit_240, v_lit_241, v_xs_244))});
    }
    case TAG_False: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2efilter_24s419026844x1025599777_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s419026844x1025599777(a[0], a[1], a[2]);
}
Clo g_prelude_2efoldl_24s847320519x792667925_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s847320519x792667925_entry, 2, 0};

V g_prelude_2efoldl_24s847320519x792667925(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_build), LBL_ships);
    V v_t_245 = (g_prelude_2econcatList(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2efoldl_24s847320519x792667925_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s847320519x792667925(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2efoldl_24s656731303x133259214_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efoldl_24s656731303x133259214_entry, 4, 0};

V g_prelude_2efoldl_24s656731303x133259214(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_a_246 = (g_prelude_2efilter_24s1056866665x1882138159(heff_get(heff_dup(v_x_244), LBL_diags)));
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_246; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_247);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_prelude_2efoldl_24s656731303x133259214_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efoldl_24s656731303x133259214(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_prelude_2efilter_24s1514461241x1644469075_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1514461241x1644469075_entry, 1, 0};

V g_prelude_2efilter_24s1514461241x1644469075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_watch), LBL_holds);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1514461241x1644469075(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1514461241x1644469075_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1514461241x1644469075(a[0]);
}
Clo g_prelude_2efilter_24s1700824619x1565819740_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s1700824619x1565819740_entry, 1, 0};

V g_prelude_2efilter_24s1700824619x1565819740(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ok);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s1700824619x1565819740(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s1700824619x1565819740_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s1700824619x1565819740(a[0]);
}
Clo g_prelude_2emap_24s1843312214x961377872_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1843312214x961377872_entry, 1, 0};

V g_prelude_2emap_24s1843312214x961377872(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1843312214x961377872(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1843312214x961377872_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1843312214x961377872(a[0]);
}
Clo g_prelude_2emap_24s1867549772x132002572_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1867549772x132002572_entry, 6, 0};

V g_prelude_2emap_24s1867549772x132002572(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_246, 0);
      V v_a_249 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 3ULL, 2);
      V v_t_2410 = (g_heff_2ejson_2eescapeGo(v_a_248, heff_dup(v_lit_241), heff_dup(v_lit_242)));
      V v_t_2411 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2410, heff_dup(v_lit_243)));
      v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(heff_dup(v_lit_244), ({ V a_0 = v_a_249; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop(v_a_249); r_; })));
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_prelude_2emap_24s1867549772x132002572(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_prelude_2emap_24s1867549772x132002572_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1867549772x132002572(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_prelude_2emap_24s1375608508x1745238686_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1375608508x1745238686_entry, 1, 0};

V g_prelude_2emap_24s1375608508x1745238686(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2elean(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1375608508x1745238686(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1375608508x1745238686_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1375608508x1745238686(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s697897431x2046530597_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_prelude_2emap_24s697897431x2046530597_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 116, 97, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_prelude_2emap_24s697897431x2046530597_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {108, 97, 98, 101, 108}};
Clo g_prelude_2emap_24s697897431x2046530597_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s697897431x2046530597_entry, 1, 0};

V g_prelude_2emap_24s697897431x2046530597(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_label)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s697897431x2046530597_str0), heff_tag(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag(TAG_JString, 1, (V[]){heff_get(v_x_241, LBL_detail)});
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s697897431x2046530597_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_prelude_2emap_24s697897431x2046530597_str2), v_t_243}), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_247}), (g_prelude_2emap_24s697897431x2046530597(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s697897431x2046530597_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s697897431x2046530597(a[0]);
}
Clo g_prelude_2efind_24s1996057548x665004299_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efind_24s1996057548x665004299_entry, 2, 0};

V g_prelude_2efind_24s1996057548x665004299(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_strEq(v_t_246, heff_dup(v_lit_240));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2efind_24s1996057548x665004299_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2efind_24s1996057548x665004299(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s651029960x996908055_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s651029960x996908055_entry, 1, 0};

V g_prelude_2emap_24s651029960x996908055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_long), (g_prelude_2emap_24s651029960x996908055(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s651029960x996908055_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s651029960x996908055(a[0]);
}
Clo g_prelude_2emap_24s1309194388x1478532932_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1309194388x1478532932_entry, 1, 0};

V g_prelude_2emap_24s1309194388x1478532932(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_short), (g_prelude_2emap_24s1309194388x1478532932(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1309194388x1478532932_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1309194388x1478532932(a[0]);
}
Clo g_prelude_2eany_24s588349713x1374270364_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s588349713x1374270364_entry, 4, 0};

V g_prelude_2eany_24s588349713x1374270364(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_get(heff_dup(v_x_244), LBL_short));
    V v_t_247 = heff_intLt(heff_dup(v_lit_240), v_t_246);
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_248 = heff_strEq(heff_get(heff_dup(v_x_244), LBL_short), heff_dup(v_lit_241));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_249 = heff_strEq(heff_get(heff_dup(v_x_244), LBL_short), heff_dup(v_lit_242));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_xs_245;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_x2_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2eany_24s588349713x1374270364_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s588349713x1374270364(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_prelude_2eany_24s338218608x1930042456_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s338218608x1930042456_entry, 6, 0};

V g_prelude_2eany_24s338218608x1930042456(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_strEq(heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_240));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_249 = heff_strEq(heff_get(heff_dup(v_x_246), LBL_short), heff_dup(v_lit_241));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2410 = heff_strEq(heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_242));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          heff_drop(v_lit_243);
          heff_drop(v_lit_244);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V v_t_2411 = (g_prelude_2eindexFrom(heff_dup(v_lit_243), heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_244)));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_Nothing: {
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_xs_247;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_x2_245 = t_5;
            goto top;
          }
          case TAG_Just: {
            heff_take_n(v_t_2411, 0ULL, 1);
            heff_drop(v_lit_240);
            heff_drop(v_lit_241);
            heff_drop(v_lit_242);
            heff_drop(v_lit_243);
            heff_drop(v_lit_244);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_prelude_2eany_24s338218608x1930042456_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s338218608x1930042456(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
Clo g_prelude_2eany_24s1590645509x196373689_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eany_24s1590645509x196373689_entry, 2, 0};

V g_prelude_2eany_24s1590645509x196373689(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_x_242), LBL_meta), heff_dup(v_lit_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_get(heff_dup(v_x_242), LBL_values);
      V v_a_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_a_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_a_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_a_248)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_248);
      }
    }
    case TAG_False: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2eany_24s1590645509x196373689_entry(V self, V *a) {
  (void)self;
  V r = g_prelude_2eany_24s1590645509x196373689(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_prelude_2emap_24s350412458x837611148_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s350412458x837611148_entry, 2, 0};

V g_prelude_2emap_24s350412458x837611148(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_get(v_x_242, LBL_long));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s350412458x837611148(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s350412458x837611148_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s350412458x837611148(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1319686775x2043462729_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1319686775x2043462729_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1319686775x2043462729_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s1319686775x2043462729_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_prelude_2emap_24s1319686775x2043462729_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_prelude_2emap_24s1319686775x2043462729_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_prelude_2emap_24s1319686775x2043462729_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
Clo g_prelude_2emap_24s1319686775x2043462729_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1319686775x2043462729_entry, 1, 0};

V g_prelude_2emap_24s1319686775x2043462729(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_arity);
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      v_t_244 = heff_get(v_x_241, LBL_meta);
      break;
    }
    case TAG_Optional: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s1319686775x2043462729_str0), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s1319686775x2043462729_str1)));
      break;
    }
    case TAG_Many: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s1319686775x2043462729_str2), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s1319686775x2043462729_str3)));
      break;
    }
    case TAG_Some: {
      v_t_244 = heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s1319686775x2043462729_str4));
      break;
    }
    case TAG_Rest: {
      v_t_244 = heff_strAppend(((V)&g_prelude_2emap_24s1319686775x2043462729_str5), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_prelude_2emap_24s1319686775x2043462729_str6)));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1319686775x2043462729(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1319686775x2043462729_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1319686775x2043462729(a[0]);
}
Clo g_prelude_2emap_24s1457492563x2144644264_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1457492563x2144644264_entry, 1, 0};

V g_prelude_2emap_24s1457492563x2144644264(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1457492563x2144644264(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1457492563x2144644264_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1457492563x2144644264(a[0]);
}
Clo g_prelude_2emap_24s1020043107x1371161197_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1020043107x1371161197_entry, 1, 0};

V g_prelude_2emap_24s1020043107x1371161197(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get(v_x_241, LBL_doc)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_prelude_2emap_24s1020043107x1371161197(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1020043107x1371161197_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1020043107x1371161197(a[0]);
}
Clo g_prelude_2efilter_24s758020682x2002616678_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2efilter_24s758020682x2002616678_entry, 1, 0};

V g_prelude_2efilter_24s758020682x2002616678(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_shown);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_prelude_2efilter_24s758020682x2002616678(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2efilter_24s758020682x2002616678_entry(V self, V *a) {
  (void)self;
  return g_prelude_2efilter_24s758020682x2002616678(a[0]);
}
Clo g_prelude_2emap_24s1929921403x2017858336_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1929921403x2017858336_entry, 1, 0};

V g_prelude_2emap_24s1929921403x2017858336(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_prelude_2emap_24s1929921403x2017858336(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2emap_24s1929921403x2017858336_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1929921403x2017858336(a[0]);
}
Clo g_prelude_2emap_24s2054100617x1212500015_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s2054100617x1212500015_entry, 4, 0};

V g_prelude_2emap_24s2054100617x1212500015(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_246 = heff_get(heff_dup(v_x_244), LBL_name);
    V v_a_247 = heff_get(v_x_244, LBL_doc);
    V v_t_248 = heff_strEq(heff_dup(v_a_247), heff_dup(v_lit_240));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_a_247);
      v_t_249 = v_a_246;
      break;
    }
    case TAG_False: {
      v_t_249 = heff_strAppend(v_a_246, heff_strAppend(heff_dup(v_lit_241), v_a_247));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_242)), (g_prelude_2emap_24s2054100617x1212500015(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s2054100617x1212500015_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s2054100617x1212500015(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emap_24s404693216x603828942_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s404693216x603828942_entry, 4, 0};

V g_prelude_2emap_24s404693216x603828942(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strEq(heff_dup(v_a_2411), heff_dup(v_lit_240));
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_248;
      break;
    }
    case TAG_False: {
      v_t_2413 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), (g_prelude_2emap_24s404693216x603828942(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2emap_24s404693216x603828942_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s404693216x603828942(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2emap_24s1814443606x828128923_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emap_24s1814443606x828128923_entry, 2, 0};

V g_prelude_2emap_24s1814443606x828128923(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_prelude_2emap_24s1814443606x828128923(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2emap_24s1814443606x828128923_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emap_24s1814443606x828128923(a[0], a[1]);
}