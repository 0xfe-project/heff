// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Alone 55333
#define TAG_Catch 6517
#define TAG_Directory 35277
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Listen 55096
#define TAG_Main 39920
#define TAG_MkGroup 19195
#define TAG_MkWith 3751
#define TAG_NewKey 33294
#define TAG_NotRun 12703
#define TAG_Open 48267
#define TAG_Other 45236
#define TAG_Park 64043
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_RAct 26891
#define TAG_RDone 16778
#define TAG_RKey 36568
#define TAG_RPark 33316
#define TAG_RSpawn 40406
#define TAG_RWake 45052
#define TAG_RYield 3356
#define TAG_ReadDirectory 46629
#define TAG_Regular 40886
#define TAG_ReleaseListener 49395
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Wake 10253
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_address 1231649329
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_connectTimeout 188913094
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_hmap 9701563
#define LBL_host 9704047
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_parked 951723316
#define LBL_path 9928940
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ready 309745085
#define LBL_ret 322331
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_url 325609
#define LBL_wanted 1152016858
#define LBL_woken 314670230
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__woken__parked__next__pending__turns[] = {LBL_ready, LBL_woken, LBL_parked, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__connectTimeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_connectTimeout, LBL_follow};
V g_co_2e_3c_2b_3e_24s1404263853x1546533042(V);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1404263853x1546533042_clo;
V g_co_2eop_24s1015281915x1399722043(V, V, V, V);
V g_co_2eop_24s1015281915x1399722043_entry(V self, V *a);
extern Clo g_co_2eop_24s1015281915x1399722043_clo;
V g_co_2eop_24s1628839587x1321325607(V, V, V, V);
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a);
extern Clo g_co_2eop_24s1628839587x1321325607_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_green_2ealone(V, V);
V g_green_2ealone_entry(V self, V *a);
extern Clo g_green_2ealone_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s1139265617x957540378(V, V, V, V, V, V);
V g_green_2ego_24s1139265617x957540378_entry(V self, V *a);
extern Clo g_green_2ego_24s1139265617x957540378_clo;
V g_green_2ethenRes(V, V, V);
V g_green_2ethenRes_entry(V self, V *a);
extern Clo g_green_2ethenRes_clo;
V g_green_2eview(V, V);
V g_green_2eview_entry(V self, V *a);
extern Clo g_green_2eview_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500(V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600(V, V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(V, V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_clo;
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528(V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_clo;
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(V, V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2eany_24s1255781029x1672221493(V, V);
V g_list_2eany_24s1255781029x1672221493_entry(V self, V *a);
extern Clo g_list_2eany_24s1255781029x1672221493_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s853072390x1205192752(V, V, V, V, V, V);
V g_list_2ekeepIf_24s853072390x1205192752_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s853072390x1205192752_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f577516032x134284914(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f577516032x134284914_entry(V self, V *a);
extern Clo g_list_2emap_24f577516032x134284914_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_243), heff_strLength_lent(v_p_240, 0));
    if ((heff_strEq_c_lent(v_t_244, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2), 2) || ({ int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL)); int c_ = ({ V v_t_2421 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_245), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2ebuild_2edev_2etypeOf_str3), 2); heff_drop(v_t_2421); c_; }); c_; }))) {
      heff_drop(v_t_244);
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str4);
    } else {
      heff_drop(v_t_244);
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_246), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edev_2etypeOf_str5))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str6);
      } else {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
        V v_t_249 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_248), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edev_2etypeOf_str7))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str8);
        } else {
          int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
          V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str9))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str10);
          } else {
            int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2413 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2412), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2edev_2etypeOf_str11))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str12);
            } else {
              int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2415 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2414), heff_strLength_lent(v_p_240, 0));
              if ((heff_strEq_c_lent(v_t_2415, ((V)&g_heff_2ebuild_2edev_2etypeOf_str13), 2) || ({ int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2422 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2422, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14), 2); heff_drop(v_t_2422); c_; }); c_; }))) {
                heff_drop(v_t_2415);
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
              } else {
                heff_drop(v_t_2415);
                int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                V v_t_2418 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2417), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                } else {
                  int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                  V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                  } else {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str20);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str17, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str19, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str20, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str22, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str24, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str25, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str26, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str27, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str28, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str29, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str30, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str32, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str33, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str34, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str35, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str37, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str38, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str42, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str44, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str45, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str46, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str47, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str49, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str50, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str51, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str52, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str53, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str55, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str56, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str57, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str58, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str59, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str60, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str61, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str63, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str64, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str65, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str66, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str67, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str68, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str69, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str70, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str71, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str72, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str74, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str75, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str76, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str77, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str78, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str79, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str80, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str81, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str82, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str83, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str84, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str85, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str86, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str87, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str88, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str89, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str90, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str91, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str92, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str93, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str94, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str95, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str96, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str97, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str98, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str99, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str100, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str101, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str102, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str103, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str104, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str105, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str106, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str107, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str108, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str109, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str110, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str111, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str112, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str114, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str115, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str116, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str117, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str118, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str119, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str120, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str121, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str122, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str123, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str124, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str125, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str126, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str127, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str128, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str129, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str130, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str131, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str132, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str133, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str134, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str135, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str136, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str137, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str138, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str139, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str140, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str141, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str142, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str143, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str144, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str145, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str146, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str147, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str148, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str149, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str150, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str151, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str152, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str153, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str154, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str155, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str156, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str157, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str158, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str159, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str160, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str161, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str162, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str163, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str164, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str165, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str166, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str167, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str168, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str169, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str170, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str171, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str172, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str173, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str174, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str175, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str176, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str177, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str178, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str179, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str180, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str181, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str182, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str183, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str184, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str185, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str186, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str187, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str188, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str189, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str190, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam4, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam10, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam14, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam20, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam21, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam27, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam29, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam36, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam45, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam51, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam52, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam58, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam63_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam63, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam65(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam66(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam68(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam67(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam69(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam69, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam70(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam70, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam72(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam71(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam73(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam75(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam74(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam76(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam76, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_entry, 4, 0};

V g_heff_2ebuild_2edev_2eanswer(V v_e_240, V v_disk_241, V v_st_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_disk_241);
    heff_drop(v_st_242);
    return ((V)&g_heff_2ebuild_2edev_2eanswer_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_243, 0);
    V v_x22_249 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str3), 2)) {
      switch (heff_tag_of(v_x22_249)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_disk_241);
        heff_drop(v_st_242);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam1, 2, 1, (V[]){v_x21_248});
      }
      case TAG_Cons: {
        V v_x221_2415 = heff_dup(heff_field(v_x22_249, 0));
        V v_x222_2416 = heff_dup(heff_field(v_x22_249, 1));
        if (heff_strEq_c_lent(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str8), 2)) {
          heff_drop(v_x221_2415);
          switch (heff_tag_of(v_x222_2416)) {
          case TAG_Nil: {
            heff_drop(v_x21_248);
            heff_drop_tag(v_x22_249, 2);
            V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str9)));
            V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str10)));
            V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
            V v_a_2420 = ({ V a_0 = v_st_242; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
            V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2420));
            V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str11)));
            V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
            V v_s_2424 = ({ V a_0 = v_st_242; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2423); r_; });
            V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
            V v_c_2426 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2425));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam2, 2, 1, (V[]){v_c_2426});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2416, 0ULL, 2);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str17), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str18), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str19), 2)))) {
              V v_x1_2438 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_2438) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_2438);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam4_clo);
              } else {
                heff_drop(v_x1_2438);
                V v_t_2445;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_2445 = ((V)&g_heff_2ebuild_2edev_2eanswer_str23);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2443 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_2444 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str24); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_2445, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str25)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str26)));
                  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str27)));
                  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
                  V v_a_2449 = ({ V a_0 = v_st_242; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
                  V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2449));
                  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str28))));
                  V v_t_2452 = (g_std_2epath_2ejoin(v_t_2450, v_t_2451));
                  V v_s_2453 = ({ V a_0 = v_st_242; V a_1 = v_t_2452; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2452); r_; });
                  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2453));
                  V v_c_2455 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2454));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam5, 2, 2, (V[]){v_c_2455, v_x21_248});
                } else {
                  V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str30)));
                  V v_t_2461 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_2462 = (g_std_2epath_2ejoin(v_t_2460, v_t_2461));
                  V v_t_2463 = ({ V a_0 = v_st_242; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2462); r_; });
                  V v_s_2469 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam7, 2, 1, (V[]){v_st_242}), v_t_2463, v_x22_249));
                  V v_t_2470 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2469));
                  V v_c_2471 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2470));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam8, 2, 2, (V[]){v_c_2471, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam10_clo);
            }
          }
          default: return heff_nomatch(v_x222_2416);
          }
        } else {
          if (heff_strEq_c(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str36))) {
            switch (heff_tag_of(v_x222_2416)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_2483 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str37)));
              V v_t_2484 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_2485 = (g_std_2epath_2ejoin(v_t_2483, v_t_2484));
              V v_a_2486 = ({ V a_0 = v_st_242; V a_1 = v_t_2485; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2485); r_; });
              V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2486));
              V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str38)));
              V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
              V v_s_2490 = ({ V a_0 = v_st_242; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2489); r_; });
              V v_t_2491 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2490));
              V v_c_2492 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_2491));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam11, 2, 5, (V[]){v_c_2492, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2416, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str42), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str43), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str44), 2)))) {
                V v_x1_24110 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24110) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24110);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam14_clo);
                } else {
                  heff_drop(v_x1_24110);
                  V v_t_24117;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24117 = ((V)&g_heff_2ebuild_2edev_2eanswer_str48);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24115 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24116 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24117 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str49); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24117, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str50)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24118 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str51)));
                    V v_t_24119 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str52)));
                    V v_t_24120 = (g_std_2epath_2ejoin(v_t_24118, v_t_24119));
                    V v_a_24121 = ({ V a_0 = v_st_242; V a_1 = v_t_24120; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24120); r_; });
                    V v_t_24122 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24121));
                    V v_t_24123 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str53))));
                    V v_t_24124 = (g_std_2epath_2ejoin(v_t_24122, v_t_24123));
                    V v_s_24125 = ({ V a_0 = v_st_242; V a_1 = v_t_24124; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24124); r_; });
                    V v_t_24126 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24125));
                    V v_c_24127 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24126));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam15, 2, 2, (V[]){v_c_24127, v_x21_248});
                  } else {
                    V v_t_24132 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str55)));
                    V v_t_24133 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24134 = (g_std_2epath_2ejoin(v_t_24132, v_t_24133));
                    V v_t_24135 = ({ V a_0 = v_st_242; V a_1 = v_t_24134; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24134); r_; });
                    V v_s_24141 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam17, 2, 1, (V[]){v_st_242}), v_t_24135, v_x22_249));
                    V v_t_24142 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24141));
                    V v_c_24143 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24142));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam18, 2, 2, (V[]){v_c_24143, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam20_clo);
              }
            }
            default: return heff_nomatch(v_x222_2416);
            }
          } else {
            heff_drop(v_x222_2416);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str61), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str62), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str63), 2)))) {
              V v_x1_24155 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24155) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24155);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam21_clo);
              } else {
                heff_drop(v_x1_24155);
                V v_t_24162;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24162 = ((V)&g_heff_2ebuild_2edev_2eanswer_str67);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24160 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24161 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24162 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str68); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24162, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str69)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24163 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str70)));
                  V v_t_24164 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str71)));
                  V v_t_24165 = (g_std_2epath_2ejoin(v_t_24163, v_t_24164));
                  V v_a_24166 = ({ V a_0 = v_st_242; V a_1 = v_t_24165; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24165); r_; });
                  V v_t_24167 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24166));
                  V v_t_24168 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str72))));
                  V v_t_24169 = (g_std_2epath_2ejoin(v_t_24167, v_t_24168));
                  V v_s_24170 = ({ V a_0 = v_st_242; V a_1 = v_t_24169; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24169); r_; });
                  V v_t_24171 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24170));
                  V v_c_24172 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24171));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam22, 2, 2, (V[]){v_c_24172, v_x21_248});
                } else {
                  V v_t_24177 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str74)));
                  V v_t_24178 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24179 = (g_std_2epath_2ejoin(v_t_24177, v_t_24178));
                  V v_t_24180 = ({ V a_0 = v_st_242; V a_1 = v_t_24179; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24179); r_; });
                  V v_s_24186 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam24, 2, 1, (V[]){v_st_242}), v_t_24180, v_x22_249));
                  V v_t_24187 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24186));
                  V v_c_24188 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24187));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam25, 2, 2, (V[]){v_c_24188, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam27_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_249);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str80), 2)) {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_x21_248);
          V v_e_24200 = v_e_240;
          V v_disk_24201 = v_disk_241;
          V v_t_24202 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str81)));
          V v_t_24203 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str82)));
          V v_t_24204 = (g_std_2epath_2ejoin(v_t_24202, v_t_24203));
          V v_s_24205 = ({ V a_0 = v_st_242; V a_1 = v_t_24204; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24204); r_; });
          V v_path_24206 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24205));
          V v_lit_24207 = heff_dup(v_e_24200);
          V v_ev_24210 = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam28, 1, 1, (V[]){v_disk_24201});
          V v_path_24211 = v_path_24206;
          V v_t_24212 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24211; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_24214 = heff_tr(heff_call(v_ev_24210, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_24212, ((V)&g_heff_2ebuild_2edev_2eanswer_lam29_clo)})}));
          V v_c_24233 = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam30, 2, 3, (V[]){v_lit_24207, v_t_24214, v_path_24211});
          V v_t_24234 = (g_exception_2eattempted(v_e_24200));
          V v_c_24239 = heff_tr(heff_call(v_c_24233, 2, (V[]){v_t_24234, ((V)&g_heff_2ebuild_2edev_2eanswer_lam36_clo)}));
          V v_c_24246 = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam38, 2, 1, (V[]){v_c_24239});
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam40, 2, 1, (V[]){v_c_24246});
        }
        case TAG_Cons: {
          V v_x221_24262 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24263 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24262, ((V)&g_heff_2ebuild_2edev_2eanswer_str99))) {
            switch (heff_tag_of(v_x222_24263)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_24264 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str100)));
              V v_t_24265 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_24266 = (g_std_2epath_2ejoin(v_t_24264, v_t_24265));
              V v_a_24267 = ({ V a_0 = v_st_242; V a_1 = v_t_24266; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24266); r_; });
              V v_t_24268 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24267));
              V v_t_24269 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str101)));
              V v_t_24270 = (g_std_2epath_2ejoin(v_t_24268, v_t_24269));
              V v_s_24271 = ({ V a_0 = v_st_242; V a_1 = v_t_24270; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24270); r_; });
              V v_t_24272 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24271));
              V v_c_24273 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_24272));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam42, 2, 5, (V[]){v_c_24273, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24263, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str105), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str106), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str107), 2)))) {
                V v_x1_24291 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24291) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24291);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam45_clo);
                } else {
                  heff_drop(v_x1_24291);
                  V v_t_24298;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24298 = ((V)&g_heff_2ebuild_2edev_2eanswer_str111);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24296 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24297 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24298 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str112); V a_1 = v_x_24296; V a_2 = v_xs_24297; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24297); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24298, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str113)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24299 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str114)));
                    V v_t_24300 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str115)));
                    V v_t_24301 = (g_std_2epath_2ejoin(v_t_24299, v_t_24300));
                    V v_a_24302 = ({ V a_0 = v_st_242; V a_1 = v_t_24301; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24301); r_; });
                    V v_t_24303 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24302));
                    V v_t_24304 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str116))));
                    V v_t_24305 = (g_std_2epath_2ejoin(v_t_24303, v_t_24304));
                    V v_s_24306 = ({ V a_0 = v_st_242; V a_1 = v_t_24305; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24305); r_; });
                    V v_t_24307 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24306));
                    V v_c_24308 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24307));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam46, 2, 2, (V[]){v_c_24308, v_x21_248});
                  } else {
                    V v_t_24313 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str118)));
                    V v_t_24314 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24315 = (g_std_2epath_2ejoin(v_t_24313, v_t_24314));
                    V v_t_24316 = ({ V a_0 = v_st_242; V a_1 = v_t_24315; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24315); r_; });
                    V v_s_24322 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam48, 2, 1, (V[]){v_st_242}), v_t_24316, v_x22_249));
                    V v_t_24323 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24322));
                    V v_c_24324 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24323));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam49, 2, 2, (V[]){v_c_24324, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam51_clo);
              }
            }
            default: return heff_nomatch(v_x222_24263);
            }
          } else {
            heff_drop(v_x222_24263);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str124), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str125), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str126), 2)))) {
              V v_x1_24336 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24336) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24336);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam52_clo);
              } else {
                heff_drop(v_x1_24336);
                V v_t_24343;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24343 = ((V)&g_heff_2ebuild_2edev_2eanswer_str130);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24341 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24342 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24343 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str131); V a_1 = v_x_24341; V a_2 = v_xs_24342; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24342); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24343, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str132)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24344 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str133)));
                  V v_t_24345 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str134)));
                  V v_t_24346 = (g_std_2epath_2ejoin(v_t_24344, v_t_24345));
                  V v_a_24347 = ({ V a_0 = v_st_242; V a_1 = v_t_24346; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24346); r_; });
                  V v_t_24348 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24347));
                  V v_t_24349 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str135))));
                  V v_t_24350 = (g_std_2epath_2ejoin(v_t_24348, v_t_24349));
                  V v_s_24351 = ({ V a_0 = v_st_242; V a_1 = v_t_24350; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24350); r_; });
                  V v_t_24352 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24351));
                  V v_c_24353 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24352));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam53, 2, 2, (V[]){v_c_24353, v_x21_248});
                } else {
                  V v_t_24358 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str137)));
                  V v_t_24359 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24360 = (g_std_2epath_2ejoin(v_t_24358, v_t_24359));
                  V v_t_24361 = ({ V a_0 = v_st_242; V a_1 = v_t_24360; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24360); r_; });
                  V v_s_24367 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam55, 2, 1, (V[]){v_st_242}), v_t_24361, v_x22_249));
                  V v_t_24368 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24367));
                  V v_c_24369 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24368));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam56, 2, 2, (V[]){v_c_24369, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam58_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      } else {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_e_240);
          heff_drop(v_disk_241);
          heff_drop(v_st_242);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam59, 2, 1, (V[]){v_x21_248});
        }
        case TAG_Cons: {
          V v_x221_24386 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24387 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24386, ((V)&g_heff_2ebuild_2edev_2eanswer_str147))) {
            switch (heff_tag_of(v_x222_24387)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_24388 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str148)));
              V v_t_24389 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_24390 = (g_std_2epath_2ejoin(v_t_24388, v_t_24389));
              V v_a_24391 = ({ V a_0 = v_st_242; V a_1 = v_t_24390; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24390); r_; });
              V v_t_24392 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24391));
              V v_t_24393 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str149)));
              V v_t_24394 = (g_std_2epath_2ejoin(v_t_24392, v_t_24393));
              V v_s_24395 = ({ V a_0 = v_st_242; V a_1 = v_t_24394; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24394); r_; });
              V v_t_24396 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24395));
              V v_c_24397 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_24396));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam60, 2, 5, (V[]){v_c_24397, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24387, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str153), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str154), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str155), 2)))) {
                V v_x1_24415 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24415) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24415);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam63_clo);
                } else {
                  heff_drop(v_x1_24415);
                  V v_t_24422;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24422 = ((V)&g_heff_2ebuild_2edev_2eanswer_str159);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24420 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24421 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24422 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str160); V a_1 = v_x_24420; V a_2 = v_xs_24421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24421); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24422, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str161)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24423 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str162)));
                    V v_t_24424 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str163)));
                    V v_t_24425 = (g_std_2epath_2ejoin(v_t_24423, v_t_24424));
                    V v_a_24426 = ({ V a_0 = v_st_242; V a_1 = v_t_24425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24425); r_; });
                    V v_t_24427 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24426));
                    V v_t_24428 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str164))));
                    V v_t_24429 = (g_std_2epath_2ejoin(v_t_24427, v_t_24428));
                    V v_s_24430 = ({ V a_0 = v_st_242; V a_1 = v_t_24429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24429); r_; });
                    V v_t_24431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24430));
                    V v_c_24432 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24431));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam64, 2, 2, (V[]){v_c_24432, v_x21_248});
                  } else {
                    V v_t_24437 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str166)));
                    V v_t_24438 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24439 = (g_std_2epath_2ejoin(v_t_24437, v_t_24438));
                    V v_t_24440 = ({ V a_0 = v_st_242; V a_1 = v_t_24439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24439); r_; });
                    V v_s_24446 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam66, 2, 1, (V[]){v_st_242}), v_t_24440, v_x22_249));
                    V v_t_24447 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24446));
                    V v_c_24448 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24447));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam67, 2, 2, (V[]){v_c_24448, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam69_clo);
              }
            }
            default: return heff_nomatch(v_x222_24387);
            }
          } else {
            heff_drop(v_x222_24387);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str172), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str173), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str174), 2)))) {
              V v_x1_24460 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24460) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24460);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam70_clo);
              } else {
                heff_drop(v_x1_24460);
                V v_t_24467;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24467 = ((V)&g_heff_2ebuild_2edev_2eanswer_str178);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24465 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24466 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24467 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str179); V a_1 = v_x_24465; V a_2 = v_xs_24466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24466); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24467, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str180)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24468 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str181)));
                  V v_t_24469 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str182)));
                  V v_t_24470 = (g_std_2epath_2ejoin(v_t_24468, v_t_24469));
                  V v_a_24471 = ({ V a_0 = v_st_242; V a_1 = v_t_24470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24470); r_; });
                  V v_t_24472 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24471));
                  V v_t_24473 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str183))));
                  V v_t_24474 = (g_std_2epath_2ejoin(v_t_24472, v_t_24473));
                  V v_s_24475 = ({ V a_0 = v_st_242; V a_1 = v_t_24474; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24474); r_; });
                  V v_t_24476 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24475));
                  V v_c_24477 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24476));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam71, 2, 2, (V[]){v_c_24477, v_x21_248});
                } else {
                  V v_t_24482 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str185)));
                  V v_t_24483 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24484 = (g_std_2epath_2ejoin(v_t_24482, v_t_24483));
                  V v_t_24485 = ({ V a_0 = v_st_242; V a_1 = v_t_24484; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24484); r_; });
                  V v_s_24491 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam73, 2, 1, (V[]){v_st_242}), v_t_24485, v_x22_249));
                  V v_t_24492 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24491));
                  V v_c_24493 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24492));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam74, 2, 2, (V[]){v_c_24493, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam76_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eanswer(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_str1)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_246, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str2))});
  V f_ = v_k_245;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str4), v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str5));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str6), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2413, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str7))});
  V f_ = v_k_2411;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_str14)}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str15), v_kind_2430}), v_t_2431});
  V v_t_2434;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edev_2eanswer_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2435 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2432, heff_bytesFromString(v_t_2434)});
  V f_ = v_k_2428;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam3, 1, 1, (V[]){v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str20), ((V)&g_heff_2ebuild_2edev_2eanswer_str21)}), NTAG(TAG_Nil)});
  V v_t_2442 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2441, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str22))});
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str29)); V a_1 = v_x_2458; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam6, 1, 2, (V[]){v_x21_248, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args) {
  V v_p_2464 = args[0];
  V v_x_2465 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_2464));
  V v_t_2467 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_2465));
  V v_t_2468 = (g_std_2epath_2ejoin(v_t_2466, v_t_2467));
  return ({ V a_0 = v_st_242; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2468); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_2477 = ((V)&g_heff_2ebuild_2edev_2eanswer_str31);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_x22_249, 0);
    V v_xs_2476 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_2477 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str32); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_2478 = ({ V a_0 = v_t_2477; V a_1 = v_x_2474; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2474); r_; });
  V f_ = v_k_2473;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam9, 1, 2, (V[]){v_x22_249, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  heff_drop(v_hd_2479);
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str33), ((V)&g_heff_2ebuild_2edev_2eanswer_str34)}), NTAG(TAG_Nil)});
  V v_t_2482 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2481, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str35))});
  V f_ = v_k_2480;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  V v_k_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24107 = ({ V a_0 = v_x21_248; V a_1 = v_x_24106; V a_2 = v_x_2495; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24106); heff_drop(v_x_2495); r_; });
  V f_ = v_k_2494;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args) {
  V v_x_2495 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_2493 = heff_env(self)[4];
  V v_k_2494 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2496 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str39)));
  V v_t_2497 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str40)));
  V v_t_2498 = (g_std_2epath_2ejoin(v_t_2496, v_t_2497));
  V v_a_2499 = ({ V a_0 = v_st_242; V a_1 = v_t_2498; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2498); r_; });
  V v_t_24100 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2499));
  V v_t_24101 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str41))));
  V v_t_24102 = (g_std_2epath_2ejoin(v_t_24100, v_t_24101));
  V v_s_24103 = ({ V a_0 = v_st_242; V a_1 = v_t_24102; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24102); r_; });
  V v_t_24104 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24103));
  V v_c_24105 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24104; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24104); r_; });
  V f_ = v_c_24105;
  heff_room[0] = v_hd_2493;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam13, 1, 3, (V[]){v_x21_248, v_x_2495, v_k_2494});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  V v_c_2492 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2492;
  args[0] = heff_dup(v_hd_2493);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam12, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_2493, v_k_2494});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  heff_drop(v_hd_24111);
  V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str45), ((V)&g_heff_2ebuild_2edev_2eanswer_str46)}), NTAG(TAG_Nil)});
  V v_t_24114 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24113, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str47))});
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args) {
  V v_x_24130 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24129 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24131 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str54)); V a_1 = v_x_24130; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24130); r_; });
  V f_ = v_k_24129;
  args[0] = v_x_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_c_24127 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24127;
  args[0] = v_hd_24128;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam16, 1, 2, (V[]){v_x21_248, v_k_24129});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args) {
  V v_p_24136 = args[0];
  V v_x_24137 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24138 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24136));
  V v_t_24139 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24137));
  V v_t_24140 = (g_std_2epath_2ejoin(v_t_24138, v_t_24139));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24140; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24140); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args) {
  V v_x_24146 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24149;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24149 = ((V)&g_heff_2ebuild_2edev_2eanswer_str56);
    break;
  }
  case TAG_Cons: {
    V v_x_24147 = heff_field(v_x22_249, 0);
    V v_xs_24148 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24149 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str57); V a_1 = v_x_24147; V a_2 = v_xs_24148; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24148); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24150 = ({ V a_0 = v_t_24149; V a_1 = v_x_24146; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24146); r_; });
  V f_ = v_k_24145;
  args[0] = v_x_24150;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24143;
  args[0] = v_hd_24144;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam19, 1, 2, (V[]){v_x22_249, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args) {
  V v_hd_24151 = args[0];
  V v_k_24152 = args[1];
  heff_drop(v_hd_24151);
  V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str58), ((V)&g_heff_2ebuild_2edev_2eanswer_str59)}), NTAG(TAG_Nil)});
  V v_t_24154 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24153, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str60))});
  V f_ = v_k_24152;
  args[0] = v_t_24154;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args) {
  V v_hd_24156 = args[0];
  V v_k_24157 = args[1];
  heff_drop(v_hd_24156);
  V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str64), ((V)&g_heff_2ebuild_2edev_2eanswer_str65)}), NTAG(TAG_Nil)});
  V v_t_24159 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24158, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str66))});
  V f_ = v_k_24157;
  args[0] = v_t_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args) {
  V v_x_24175 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24174 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24176 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str73)); V a_1 = v_x_24175; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24175); r_; });
  V f_ = v_k_24174;
  args[0] = v_x_24176;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args) {
  V v_hd_24173 = args[0];
  V v_k_24174 = args[1];
  V v_c_24172 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24172;
  args[0] = v_hd_24173;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam23, 1, 2, (V[]){v_x21_248, v_k_24174});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args) {
  V v_p_24181 = args[0];
  V v_x_24182 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24183 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24181));
  V v_t_24184 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24182));
  V v_t_24185 = (g_std_2epath_2ejoin(v_t_24183, v_t_24184));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24185; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24185); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args) {
  V v_x_24191 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24190 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24194;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24194 = ((V)&g_heff_2ebuild_2edev_2eanswer_str75);
    break;
  }
  case TAG_Cons: {
    V v_x_24192 = heff_field(v_x22_249, 0);
    V v_xs_24193 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24194 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str76); V a_1 = v_x_24192; V a_2 = v_xs_24193; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24193); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24195 = ({ V a_0 = v_t_24194; V a_1 = v_x_24191; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24191); r_; });
  V f_ = v_k_24190;
  args[0] = v_x_24195;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k_24190 = args[1];
  V v_c_24188 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24188;
  args[0] = v_hd_24189;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam26, 1, 2, (V[]){v_x22_249, v_k_24190});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args) {
  V v_hd_24196 = args[0];
  V v_k_24197 = args[1];
  heff_drop(v_hd_24196);
  V v_t_24198 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str77), ((V)&g_heff_2ebuild_2edev_2eanswer_str78)}), NTAG(TAG_Nil)});
  V v_t_24199 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24198, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str79))});
  V f_ = v_k_24197;
  args[0] = v_t_24199;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args) {
  V v_p_231002_24208 = args[0];
  V v_disk_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24209 = heff_tr(heff_call(v_disk_24201, 1, (V[]){v_p_231002_24208}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_24209});
}
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args) {
  V v_r_24213 = args[0];
  return v_r_24213;
}
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args) {
  V v_hd_24219 = args[0];
  V v_k2_24220 = args[1];
  V v_err_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24221 = heff_take_field(v_hd_24219, 1);
  V v_malg_24222 = heff_get_n(v_hd_24219, 2, 3);
  V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24218})});
  V v_t_24224 = heff_tr(heff_call(v_malg_24222, 1, (V[]){v_t_24223}));
  V f_ = v_bind_24221;
  args[0] = v_t_24224;
  args[1] = v_k2_24220;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args) {
  V v_hd_24226 = args[0];
  V v_k_24227 = args[1];
  V v_x_24225 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24226);
  V f_ = v_k_24227;
  args[0] = v_x_24225;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args) {
  V v_n_24230 = args[0];
  V v_path_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24231 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_24230));
  return (g_std_2epath_2ejoin(v_path_24211, v_t_24231));
}
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args) {
  V v_x_24229 = args[0];
  V v_path_24211 = heff_env(self)[0];
  V v_k_24216 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24232 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam35, 1, 1, (V[]){v_path_24211}), v_x_24229));
  V f_ = v_k_24216;
  args[0] = v_x_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args) {
  V v_x_24217 = args[0];
  V v_hd_24215 = heff_env(self)[0];
  V v_path_24211 = heff_env(self)[1];
  V v_k_24216 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24228;
  switch (heff_tag_of(v_x_24217)) {
  case TAG_Left: {
    V v_err_24218 = heff_field(v_x_24217, 0);
    heff_take_n(v_x_24217, 1ULL, 1);
    v_t_24228 = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam32, 2, 1, (V[]){v_err_24218});
    break;
  }
  case TAG_Right: {
    V v_x_24225 = heff_field(v_x_24217, 0);
    heff_take_n(v_x_24217, 1ULL, 1);
    v_t_24228 = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam33, 2, 1, (V[]){v_x_24225});
    break;
  }
  default: heff_nomatch(v_x_24217);
  }
  V f_ = v_t_24228;
  heff_room[0] = v_hd_24215;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam34, 1, 2, (V[]){v_path_24211, v_k_24216});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args) {
  V v_hd_24215 = args[0];
  V v_k_24216 = args[1];
  V v_lit_24207 = heff_env(self)[0];
  V v_t_24214 = heff_env(self)[1];
  V v_path_24211 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s1628839587x1321325607(v_lit_24207, v_t_24214, heff_dup(v_hd_24215), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam31, 1, 3, (V[]){v_hd_24215, v_path_24211, v_k_24216})));
}
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args) {
  V v_hd_24237 = args[0];
  V v_k_24238 = args[1];
  V v_x_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24237);
  V f_ = v_k_24238;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24236});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args) {
  V v_x_24235 = args[0];
  V v_x_24236 = (g_list_2emap_24s219049803x1458391381(v_x_24235));
  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam37, 2, 1, (V[]){v_x_24236});
}
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args) {
  V v_x_24242 = args[0];
  V v_k_24241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24245;
  switch (heff_tag_of(v_x_24242)) {
  case TAG_Left: {
    heff_take_n(v_x_24242, 0ULL, 1);
    v_t_24245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_24244 = heff_field(v_x_24242, 0);
    V v_ru_24x_24242_24Right = heff_take_reuse_n(v_x_24242, 1ULL, 1);
    v_t_24245 = heff_tag_at_n(v_ru_24x_24242_24Right, TAG_Just, 1, (V[]){v_y_24244});
    break;
  }
  default: heff_nomatch(v_x_24242);
  }
  V f_ = v_k_24241;
  args[0] = v_t_24245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args) {
  V v_hd_24240 = args[0];
  V v_k_24241 = args[1];
  V v_c_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24239;
  args[0] = v_hd_24240;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam39, 1, 1, (V[]){v_k_24241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args) {
  V v_x_24249 = args[0];
  V v_k_24248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_found_24250 = v_x_24249;
  V v_kind_24251 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str83); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_24253;
  switch (heff_tag_of(v_found_24250)) {
  case TAG_Nothing: {
    v_t_24253 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_24252 = heff_field(v_found_24250, 0);
    heff_take_n(v_found_24250, 1ULL, 1);
    v_t_24253 = v_x_24252;
    break;
  }
  default: heff_nomatch(v_found_24250);
  }
  V v_t_24254 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str84); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eanswer_str85); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eanswer_str86); V b_7 = ((V)&g_heff_2ebuild_2edev_2eanswer_str87); V b_8 = ((V)&g_heff_2ebuild_2edev_2eanswer_str88); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eanswer_str89); V a_12 = v_t_24253; V r_ = (g_list_2emap_24f577516032x134284914(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_24255 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_ys_24256 = (g_prelude_2e_2b_2b(v_t_24254, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str90), v_t_24255})));
  V v_t_24257 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str91), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str92), v_ys_24256})});
  V v_text_24258 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str93); V a_1 = ((V)&g_heff_2ebuild_2edev_2eanswer_str94); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str95), v_t_24257}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_24259 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str96), ((V)&g_heff_2ebuild_2edev_2eanswer_str97)}), NTAG(TAG_Nil)});
  V v_t_24260 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str98), v_kind_24251}), v_t_24259});
  V v_x_24261 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_24260, heff_bytesFromString(v_text_24258)});
  V f_ = v_k_24248;
  args[0] = v_x_24261;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args) {
  V v_hd_24247 = args[0];
  V v_k_24248 = args[1];
  V v_c_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24246;
  args[0] = v_hd_24247;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam41, 1, 1, (V[]){v_k_24248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args) {
  V v_x_24287 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24276 = heff_env(self)[1];
  V v_k_24275 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24288 = ({ V a_0 = v_x21_248; V a_1 = v_x_24287; V a_2 = v_x_24276; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24287); heff_drop(v_x_24276); r_; });
  V f_ = v_k_24275;
  args[0] = v_x_24288;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args) {
  V v_x_24276 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24274 = heff_env(self)[4];
  V v_k_24275 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24277 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str102)));
  V v_t_24278 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str103)));
  V v_t_24279 = (g_std_2epath_2ejoin(v_t_24277, v_t_24278));
  V v_a_24280 = ({ V a_0 = v_st_242; V a_1 = v_t_24279; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24279); r_; });
  V v_t_24281 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24280));
  V v_t_24282 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str104))));
  V v_t_24283 = (g_std_2epath_2ejoin(v_t_24281, v_t_24282));
  V v_s_24284 = ({ V a_0 = v_st_242; V a_1 = v_t_24283; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24283); r_; });
  V v_t_24285 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24284));
  V v_c_24286 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24285; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24285); r_; });
  V f_ = v_c_24286;
  heff_room[0] = v_hd_24274;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam44, 1, 3, (V[]){v_x21_248, v_x_24276, v_k_24275});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args) {
  V v_hd_24274 = args[0];
  V v_k_24275 = args[1];
  V v_c_24273 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24273;
  args[0] = heff_dup(v_hd_24274);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam43, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24274, v_k_24275});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args) {
  V v_hd_24292 = args[0];
  V v_k_24293 = args[1];
  heff_drop(v_hd_24292);
  V v_t_24294 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str108), ((V)&g_heff_2ebuild_2edev_2eanswer_str109)}), NTAG(TAG_Nil)});
  V v_t_24295 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24294, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str110))});
  V f_ = v_k_24293;
  args[0] = v_t_24295;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args) {
  V v_x_24311 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24310 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24312 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str117)); V a_1 = v_x_24311; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24311); r_; });
  V f_ = v_k_24310;
  args[0] = v_x_24312;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args) {
  V v_hd_24309 = args[0];
  V v_k_24310 = args[1];
  V v_c_24308 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24308;
  args[0] = v_hd_24309;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam47, 1, 2, (V[]){v_x21_248, v_k_24310});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args) {
  V v_p_24317 = args[0];
  V v_x_24318 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24319 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24317));
  V v_t_24320 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24318));
  V v_t_24321 = (g_std_2epath_2ejoin(v_t_24319, v_t_24320));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24321; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24321); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args) {
  V v_x_24327 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24326 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24330;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24330 = ((V)&g_heff_2ebuild_2edev_2eanswer_str119);
    break;
  }
  case TAG_Cons: {
    V v_x_24328 = heff_field(v_x22_249, 0);
    V v_xs_24329 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24330 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str120); V a_1 = v_x_24328; V a_2 = v_xs_24329; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24329); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24331 = ({ V a_0 = v_t_24330; V a_1 = v_x_24327; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24327); r_; });
  V f_ = v_k_24326;
  args[0] = v_x_24331;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args) {
  V v_hd_24325 = args[0];
  V v_k_24326 = args[1];
  V v_c_24324 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24324;
  args[0] = v_hd_24325;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam50, 1, 2, (V[]){v_x22_249, v_k_24326});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args) {
  V v_hd_24332 = args[0];
  V v_k_24333 = args[1];
  heff_drop(v_hd_24332);
  V v_t_24334 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str121), ((V)&g_heff_2ebuild_2edev_2eanswer_str122)}), NTAG(TAG_Nil)});
  V v_t_24335 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24334, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str123))});
  V f_ = v_k_24333;
  args[0] = v_t_24335;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args) {
  V v_hd_24337 = args[0];
  V v_k_24338 = args[1];
  heff_drop(v_hd_24337);
  V v_t_24339 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str127), ((V)&g_heff_2ebuild_2edev_2eanswer_str128)}), NTAG(TAG_Nil)});
  V v_t_24340 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24339, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str129))});
  V f_ = v_k_24338;
  args[0] = v_t_24340;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args) {
  V v_x_24356 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24355 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24357 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str136)); V a_1 = v_x_24356; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24356); r_; });
  V f_ = v_k_24355;
  args[0] = v_x_24357;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args) {
  V v_hd_24354 = args[0];
  V v_k_24355 = args[1];
  V v_c_24353 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24353;
  args[0] = v_hd_24354;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam54, 1, 2, (V[]){v_x21_248, v_k_24355});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args) {
  V v_p_24362 = args[0];
  V v_x_24363 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24364 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24362));
  V v_t_24365 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24363));
  V v_t_24366 = (g_std_2epath_2ejoin(v_t_24364, v_t_24365));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24366; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24366); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args) {
  V v_x_24372 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24371 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24375;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24375 = ((V)&g_heff_2ebuild_2edev_2eanswer_str138);
    break;
  }
  case TAG_Cons: {
    V v_x_24373 = heff_field(v_x22_249, 0);
    V v_xs_24374 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24375 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str139); V a_1 = v_x_24373; V a_2 = v_xs_24374; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24374); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24376 = ({ V a_0 = v_t_24375; V a_1 = v_x_24372; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24372); r_; });
  V f_ = v_k_24371;
  args[0] = v_x_24376;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args) {
  V v_hd_24370 = args[0];
  V v_k_24371 = args[1];
  V v_c_24369 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24369;
  args[0] = v_hd_24370;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam57, 1, 2, (V[]){v_x22_249, v_k_24371});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args) {
  V v_hd_24377 = args[0];
  V v_k_24378 = args[1];
  heff_drop(v_hd_24377);
  V v_t_24379 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str140), ((V)&g_heff_2ebuild_2edev_2eanswer_str141)}), NTAG(TAG_Nil)});
  V v_t_24380 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24379, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str142))});
  V f_ = v_k_24378;
  args[0] = v_t_24380;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args) {
  V v_hd_24381 = args[0];
  V v_k_24382 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24381);
  V v_t_24383 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str143), v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str144));
  V v_t_24384 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str145), v_t_24383}), NTAG(TAG_Nil)});
  V v_t_24385 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24384, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str146))});
  V f_ = v_k_24382;
  args[0] = v_t_24385;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args) {
  V v_x_24411 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24400 = heff_env(self)[1];
  V v_k_24399 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24412 = ({ V a_0 = v_x21_248; V a_1 = v_x_24411; V a_2 = v_x_24400; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24411); heff_drop(v_x_24400); r_; });
  V f_ = v_k_24399;
  args[0] = v_x_24412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args) {
  V v_x_24400 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24398 = heff_env(self)[4];
  V v_k_24399 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24401 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str150)));
  V v_t_24402 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str151)));
  V v_t_24403 = (g_std_2epath_2ejoin(v_t_24401, v_t_24402));
  V v_a_24404 = ({ V a_0 = v_st_242; V a_1 = v_t_24403; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24403); r_; });
  V v_t_24405 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24404));
  V v_t_24406 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str152))));
  V v_t_24407 = (g_std_2epath_2ejoin(v_t_24405, v_t_24406));
  V v_s_24408 = ({ V a_0 = v_st_242; V a_1 = v_t_24407; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24407); r_; });
  V v_t_24409 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24408));
  V v_c_24410 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24409; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24409); r_; });
  V f_ = v_c_24410;
  heff_room[0] = v_hd_24398;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam62, 1, 3, (V[]){v_x21_248, v_x_24400, v_k_24399});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args) {
  V v_hd_24398 = args[0];
  V v_k_24399 = args[1];
  V v_c_24397 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24397;
  args[0] = heff_dup(v_hd_24398);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam61, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24398, v_k_24399});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args) {
  V v_hd_24416 = args[0];
  V v_k_24417 = args[1];
  heff_drop(v_hd_24416);
  V v_t_24418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str156), ((V)&g_heff_2ebuild_2edev_2eanswer_str157)}), NTAG(TAG_Nil)});
  V v_t_24419 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24418, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str158))});
  V f_ = v_k_24417;
  args[0] = v_t_24419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam65(V self, V *args) {
  V v_x_24435 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24436 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str165)); V a_1 = v_x_24435; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24435); r_; });
  V f_ = v_k_24434;
  args[0] = v_x_24436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args) {
  V v_hd_24433 = args[0];
  V v_k_24434 = args[1];
  V v_c_24432 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24432;
  args[0] = v_hd_24433;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam65, 1, 2, (V[]){v_x21_248, v_k_24434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam66(V self, V *args) {
  V v_p_24441 = args[0];
  V v_x_24442 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24443 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24441));
  V v_t_24444 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24442));
  V v_t_24445 = (g_std_2epath_2ejoin(v_t_24443, v_t_24444));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24445); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam68(V self, V *args) {
  V v_x_24451 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24454;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24454 = ((V)&g_heff_2ebuild_2edev_2eanswer_str167);
    break;
  }
  case TAG_Cons: {
    V v_x_24452 = heff_field(v_x22_249, 0);
    V v_xs_24453 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24454 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str168); V a_1 = v_x_24452; V a_2 = v_xs_24453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24453); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24455 = ({ V a_0 = v_t_24454; V a_1 = v_x_24451; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24451); r_; });
  V f_ = v_k_24450;
  args[0] = v_x_24455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam67(V self, V *args) {
  V v_hd_24449 = args[0];
  V v_k_24450 = args[1];
  V v_c_24448 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24448;
  args[0] = v_hd_24449;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam68, 1, 2, (V[]){v_x22_249, v_k_24450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam69(V self, V *args) {
  V v_hd_24456 = args[0];
  V v_k_24457 = args[1];
  heff_drop(v_hd_24456);
  V v_t_24458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str169), ((V)&g_heff_2ebuild_2edev_2eanswer_str170)}), NTAG(TAG_Nil)});
  V v_t_24459 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24458, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str171))});
  V f_ = v_k_24457;
  args[0] = v_t_24459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam70(V self, V *args) {
  V v_hd_24461 = args[0];
  V v_k_24462 = args[1];
  heff_drop(v_hd_24461);
  V v_t_24463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str175), ((V)&g_heff_2ebuild_2edev_2eanswer_str176)}), NTAG(TAG_Nil)});
  V v_t_24464 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24463, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str177))});
  V f_ = v_k_24462;
  args[0] = v_t_24464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam72(V self, V *args) {
  V v_x_24480 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24481 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str184)); V a_1 = v_x_24480; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24480); r_; });
  V f_ = v_k_24479;
  args[0] = v_x_24481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam71(V self, V *args) {
  V v_hd_24478 = args[0];
  V v_k_24479 = args[1];
  V v_c_24477 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24477;
  args[0] = v_hd_24478;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam72, 1, 2, (V[]){v_x21_248, v_k_24479});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam73(V self, V *args) {
  V v_p_24486 = args[0];
  V v_x_24487 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24488 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24486));
  V v_t_24489 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24487));
  V v_t_24490 = (g_std_2epath_2ejoin(v_t_24488, v_t_24489));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24490; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24490); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam75(V self, V *args) {
  V v_x_24496 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24499;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24499 = ((V)&g_heff_2ebuild_2edev_2eanswer_str186);
    break;
  }
  case TAG_Cons: {
    V v_x_24497 = heff_field(v_x22_249, 0);
    V v_xs_24498 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24499 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str187); V a_1 = v_x_24497; V a_2 = v_xs_24498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24498); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24500 = ({ V a_0 = v_t_24499; V a_1 = v_x_24496; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24496); r_; });
  V f_ = v_k_24495;
  args[0] = v_x_24500;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam74(V self, V *args) {
  V v_hd_24494 = args[0];
  V v_k_24495 = args[1];
  V v_c_24493 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24493;
  args[0] = v_hd_24494;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam75, 1, 2, (V[]){v_x22_249, v_k_24495});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam76(V self, V *args) {
  V v_hd_24501 = args[0];
  V v_k_24502 = args[1];
  heff_drop(v_hd_24501);
  V v_t_24503 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str188), ((V)&g_heff_2ebuild_2edev_2eanswer_str189)}), NTAG(TAG_Nil)});
  V v_t_24504 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24503, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str190))});
  V f_ = v_k_24502;
  args[0] = v_t_24504;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str3, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str4, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam7, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam2(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_entry, 2, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500(V v_e_240, V v_st_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str0)));
  V v_c_243 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_242));
  V v_t_244 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_249 = heff_tr(heff_call(v_c_243, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam2, 2, 3, (V[]){v_c_249, v_e_240, v_st_241});
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500(a[0], a[1]);
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_246 = (g_list_2emap_24s219049803x1458391381(v_x_245));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam1, 2, 1, (V[]){v_x_246});
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam4(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str2)));
  heff_drop(v_t_2418);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam6, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam7(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam10(V self, V *args) {
  V v_x_2436 = args[0];
  V v_bad_2432 = heff_env(self)[0];
  V v_apps_2433 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2436);
  V v_t_2437;
  if (heff_intLt_c(MK_INT(0LL), v_bad_2432)) {
    heff_drop(v_apps_2433);
    v_t_2437 = NTAG(TAG_Nil);
  } else {
    v_t_2437 = v_apps_2433;
  }
  V f_ = v_k_2411;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bad_2432 = heff_take_field(v_x_2431, 1);
  V v_apps_2433 = heff_get_n(v_x_2431, 0, 2);
  V v_t_2434 = heff_tag_n(TAG_End, 2, (V[]){v_x_2427, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam10, 1, 3, (V[]){v_bad_2432, v_apps_2433, v_k_2411})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_y_2422 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str4)));
  V v_t_2429 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2430 = (g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(heff_dup(v_e_240), v_st_241, v_t_2428, heff_dup(v_x_2427), v_t_2429, v_y_2422));
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam9, 1, 4, (V[]){v_x_2427, v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam4_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam5, 1, 4, (V[]){v_st_241, v_e_240, v_hd_2410, v_k_2411})));
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_total_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_y_2422));
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_str3), v_total_2423, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam7_clo)})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2426, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam8, 1, 5, (V[]){v_st_241, v_e_240, v_y_2422, v_hd_2410, v_k_2411})));
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500_lam3, 1, 4, (V[]){v_e_240, v_hd_2410, v_st_241, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_entry, 4, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(V v_e_240, V v_r_241, V v_p_242, V v_p_243) {
top: ;
  V v_out_244 = heff_take_field(v_r_241, 1);
  V v_err_245 = heff_get_n(v_r_241, 2, 3);
  V v_t_246 = heff_tag_n(TAG_Write, 2, (V[]){v_out_244, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam0, 1, 4, (V[]){v_err_245, v_e_240, v_p_242, v_p_243}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_str0), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_p_242, v_p_243));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_err_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_245, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027_lam1, 1, 3, (V[]){v_e_240, v_p_242, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_entry, 4, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(V v_e_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam0, 1, 4, (V[]){v_e_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam3(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam9(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam10(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_dup(heff_rfield(v_x_2413, 0));
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Exited: {
    V v_n_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    if (heff_intEq_c(v_n_2418, MK_INT(0LL))) {
      heff_drop_rec(v_x_2413, 3);
      V v_c_2419 = (g_heff_2ebuild_2edev_2eappsNow_24s317876645x823565500(v_e_240, v_st_241));
      V f_ = v_c_2419;
      heff_room[0] = v_hd_242;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam6, 1, 1, (V[]){v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(v_e_240, v_x_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam7, 1, 1, (V[]){v_k_243})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(v_e_240, v_x_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam8, 1, 1, (V[]){v_k_243})));
  }
  case TAG_TimedOut: {
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(v_e_240, v_x_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam9, 1, 1, (V[]){v_k_243})));
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s1318396389x1704739027(v_e_240, v_x_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam10, 1, 1, (V[]){v_k_243})));
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tag_n(TAG_End, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam5, 1, 5, (V[]){v_x_2413, v_e_240, v_st_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_str1), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_248), v_x_244, v_t_249, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam3_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam4, 1, 5, (V[]){v_x_248, v_e_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_lam2, 1, 5, (V[]){v_x_244, v_e_240, v_hd_242, v_st_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str0, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str1, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str2, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str3, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str6, 9, "not run: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str7, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str8, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str9, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_entry, 5, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(V v_e_240, V v_acc_241, V v_x2_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_245, 1)), 2, (V[]){heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam0, 1, 6, (V[]){v_r_245, v_acc_241, v_e_240, v_rest_246, v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(v_e_240, v_acc_241, v_rest_246, v_p_243, v_p_244));
}
V g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_245, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b(v_acc_241, v_t_248));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(v_e_240, v_t_249, v_rest_246, v_p_243, v_p_244));
  }
  case TAG_Just: {
    V v_ran_2410 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str0), heff_get_n(v_r_245, 0, 2));
    V v_t_2412 = heff_get_n(v_ran_2410, 0, 3);
    V v_t_2421;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Exited: {
      V v_n_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str1), heff_intShow(v_n_2413));
      break;
    }
    case TAG_Signalled: {
      V v_n_2414 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str2), heff_intShow(v_n_2414));
      break;
    }
    case TAG_TimedOut: {
      v_t_2421 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str3);
      break;
    }
    case TAG_NotRun: {
      V v_err_2415 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_path_2416 = heff_take_field(v_err_2415, 3);
      V v_name_2417 = heff_take_field(v_err_2415, 1);
      V v_message_2418 = heff_get_n(v_err_2415, 2, 4);
      V v_t_2419 = heff_strAppend(heff_strAppend(v_path_2416, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str4)), v_name_2417);
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str5)), v_message_2418);
      v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str6), v_t_2420);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str7)), v_t_2421);
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str8)), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_str9));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466_lam1, 1, 5, (V[]){v_e_240, v_acc_241, v_rest_246, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_entry, 7, 0};

V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(V v_e_240, V v_st_241, V v_d_242, V v_stamp_243, V v_running_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Sleep, 2, (V[]){heff_box_word((((int64_t)250999999ULL) / ((int64_t)1000000ULL))), NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam0, 1, 7, (V[]){v_e_240, v_running_244, v_hd_245, v_st_241, heff_dup(v_stamp_243), v_d_242, v_k_246})));
}
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_x_2417; V a_4 = v_x_2412; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2417); r_; });
  }
  case TAG_Just: {
    V v_argv_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_x_2412);
    heff_drop(v_hd_245);
    V v_t_2420 = heff_intAdd(heff_take_field(v_d_242, 0), MK_INT(1LL));
    V v_t_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_d_242, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_246;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2421, v_argv_2419, v_x_2417});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_stamp_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_xs_2416 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  if (heff_strEq_c_lent(v_x_2417, v_stamp_243, 0)) {
    heff_drop(v_x_2417);
    return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_stamp_243; V a_4 = v_x_2412; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_stamp_243); r_; });
  } else {
    heff_drop(v_stamp_243);
    return (g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam3, 1, 7, (V[]){v_e_240, v_st_241, v_d_242, v_x_2417, v_x_2412, v_hd_245, v_k_246})));
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2413 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(heff_dup(v_e_240), heff_dup(v_st_241), NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam2, 1, 7, (V[]){v_stamp_243, v_e_240, v_st_241, v_d_242, v_x_2412, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_running_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_stamp_243 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2411);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1695415755x727510466(heff_dup(v_e_240), NTAG(TAG_Nil), v_running_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_lam1, 1, 6, (V[]){v_e_240, v_st_241, v_hd_245, v_stamp_243, v_d_242, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str5, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str7, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str10, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam0, 3, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam3, 3, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_entry, 4, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600(V v_e_240, V v_st_241, V v_d_242, V v_apps_243) {
top: ;
  V v_builds_244 = heff_take_field(v_d_242, 0);
  V v_wanted_245 = heff_get_n(v_d_242, 1, 5);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str0)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str1)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_s_249 = ({ V a_0 = v_st_241; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_249));
  V v_c_2411 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2410; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2410); r_; });
  V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2416 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam1, 2, 6, (V[]){v_c_2416, v_st_241, v_e_240, v_builds_244, v_wanted_245, v_apps_243});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2414 = args[1];
  V v_k_2415 = args[2];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam5(V self, V *args) {
  V v_a_2438 = args[0];
  V v_wanted_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_a_2438, 1)), 0, 3);
  if (heff_strEq_c(v_t_2439, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str6))) {
    switch (heff_tag_of(v_wanted_2437)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2438, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return ({ V a_0 = v_a_2438; V a_1 = v_wanted_2437; V r_ = (g_list_2eany_24s1255781029x1672221493(a_0, a_1)); heff_drop_tag(v_wanted_2437, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2437);
    }
  } else {
    heff_drop_rec(v_a_2438, 2);
    heff_drop(v_wanted_2437);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_builds_244 = heff_env(self)[0];
  V v_wanted_245 = heff_env(self)[1];
  V v_apps_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str5), heff_intShow(v_builds_244));
  V v_wanted_2437 = v_wanted_245;
  V v_argv_2442 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam5, 1, 1, (V[]){v_wanted_2437}), v_apps_243));
  V v_t_2448;
  switch (heff_tag_of(v_argv_2442)) {
  case TAG_Nil: {
    v_t_2448 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str7);
    break;
  }
  case TAG_Cons: {
    V v_x2_2445 = (g_list_2emap_24s2104774589x596860835(v_argv_2442));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_xs_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      v_t_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str9); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2445);
    }
    break;
  }
  default: heff_nomatch(v_argv_2442);
  }
  V v_str_2449 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str10)), v_t_2448);
  V v_t_2450 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2449, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str11)), NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_builds_244 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_wanted_245 = heff_env(self)[4];
  V v_apps_243 = heff_env(self)[5];
  V v_k_2418 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str2)));
  V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str3)));
  V v_t_2422 = (g_std_2epath_2ejoin(v_t_2420, v_t_2421));
  V v_a_2423 = ({ V a_0 = v_st_241; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_a_2423));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_str4)));
  V v_t_2426 = (g_std_2epath_2ejoin(v_t_2424, v_t_2425));
  V v_s_2427 = ({ V a_0 = v_st_241; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2426); r_; });
  V v_path_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2427));
  V v_c_2429 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2428; V a_2 = heff_intShow(heff_dup(v_builds_244)); V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2428); r_; });
  V v_t_2430 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2434 = heff_tr(heff_call(v_c_2429, 2, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam3_clo)}));
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam4, 1, 6, (V[]){v_builds_244, v_wanted_245, v_apps_243, v_e_240, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_builds_244 = heff_env(self)[3];
  V v_wanted_245 = heff_env(self)[4];
  V v_apps_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600_lam2, 1, 7, (V[]){v_st_241, v_e_240, v_builds_244, v_hd_2417, v_wanted_245, v_apps_243, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str3, 34, "heff dev: cannot serve the pages: ");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str5, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam14(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_entry, 5, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(V v_e_240, V v_st_241, V v_d_242, V v_stamp_243, V v_apps_244) {
top: ;
  V v_t_245 = (g_list_2eany_24s105899861x584770213(v_apps_244));
  if (((heff_dup(v_t_245) == NTAG(TAG_True)) && !(heff_dup(heff_rfield(v_d_242, 4)) == NTAG(TAG_True)))) {
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam0, 2, 5, (V[]){v_e_240, v_d_242, v_st_241, v_stamp_243, v_apps_244});
  } else {
    heff_drop(v_t_245);
    V v_c_2455 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s1479980717x1199368600(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_d_242), heff_dup(v_apps_244)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam14, 2, 6, (V[]){v_c_2455, v_d_242, v_apps_244, v_e_240, v_st_241, v_stamp_243});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam6, 3, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2418;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam5, 3, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam4, 1, 1, (V[]){v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam2(V self, V *args) {
  V v_pg_2414 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_apps_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_pg_2414);
  V v_t_2415 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_242, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2416 = (g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(v_e_240, v_st_241, v_t_2415, v_stamp_243, v_apps_244));
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam3, 2, 1, (V[]){v_c_2416});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  V v_k_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2429;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2427;
  heff_room[2] = v_k_2428;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam7(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam8, 1, 2, (V[]){v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam12(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam11(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam12, 3, 1, (V[]){v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam10(V self, V *args) {
  V v_x_2446 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_apps_244 = heff_env(self)[4];
  V v_hd_2431 = heff_env(self)[5];
  V v_k_2432 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2446);
  V v_t_2447 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_242, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2448 = (g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(v_e_240, v_st_241, v_t_2447, v_stamp_243, v_apps_244));
  V f_ = v_c_2448;
  heff_room[0] = v_hd_2431;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam11, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam9(V self, V *args) {
  V v_err_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_apps_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2433 = heff_take_field(v_err_2430, 3);
  V v_name_2434 = heff_take_field(v_err_2430, 1);
  V v_message_2435 = heff_get_n(v_err_2430, 2, 4);
  V v_t_2436 = heff_strAppend(heff_strAppend(v_path_2433, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str1)), v_name_2434);
  V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str2)), v_message_2435);
  V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str3), v_t_2437), ((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str4));
  V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam10, 1, 7, (V[]){v_d_242, v_e_240, v_st_241, v_stamp_243, v_apps_244, v_hd_2431, v_k_2432})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam13(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2454;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_246;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_apps_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_249 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2411;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_242, 2)), v_t_2411});
  V v_t_2413 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str0), v_t_2412}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2426 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_240), v_t_2413, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam2, 1, 5, (V[]){heff_dup(v_d_242), heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_stamp_243), heff_dup(v_apps_244)})));
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam7, 2, 1, (V[]){v_c_2426}), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam9, 3, 5, (V[]){heff_dup(v_e_240), v_d_242, v_st_241, v_stamp_243, v_apps_244})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam13, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_apps_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam1, 1, 7, (V[]){v_d_242, v_e_240, v_st_241, v_stamp_243, v_apps_244, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam16(V self, V *args) {
  V v_a_2460 = args[0];
  V v_wanted_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_get_n(heff_dup(heff_rfield(v_a_2460, 1)), 0, 3);
  if (heff_strEq_c(v_t_2461, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_str5))) {
    switch (heff_tag_of(v_wanted_2459)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2460, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return ({ V a_0 = v_a_2460; V a_1 = v_wanted_2459; V r_ = (g_list_2eany_24s1255781029x1672221493(a_0, a_1)); heff_drop_tag(v_wanted_2459, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2459);
    }
  } else {
    heff_drop_rec(v_a_2460, 2);
    heff_drop(v_wanted_2459);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam17(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2456 = heff_env(self)[2];
  V v_k_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_dev_2467 = heff_take_field(v_x_2466, 0);
  V v_stamp_2468 = heff_take_field(v_x_2466, 2);
  V v_apps_2469 = heff_get_n(v_x_2466, 1, 3);
  V v_t_2470 = (g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(v_e_240, v_st_241, v_dev_2467, v_stamp_2468, v_apps_2469));
  V f_ = v_t_2470;
  heff_room[0] = v_hd_2456;
  heff_room[1] = v_k_2457;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam15(V self, V *args) {
  V v_x_2458 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_apps_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_stamp_243 = heff_env(self)[4];
  V v_hd_2456 = heff_env(self)[5];
  V v_k_2457 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2458);
  V v_wanted_2459 = heff_dup(heff_rfield(v_d_242, 1));
  V v_t_2464 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam16, 1, 1, (V[]){v_wanted_2459}), v_apps_244));
  V v_c_2465 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(heff_dup(v_e_240), heff_dup(v_st_241), v_d_242, v_stamp_243, NTAG(TAG_Nil), v_t_2464));
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_hd_2456);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam17, 1, 4, (V[]){v_e_240, v_st_241, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam14(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_apps_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_stamp_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_lam15, 1, 7, (V[]){v_d_242, v_apps_244, v_e_240, v_st_241, v_stamp_243, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str4, 10, "keep-alive");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str7, 9, ": curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str8, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str9, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str11, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str12, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str13, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str14, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str15, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam2, 4, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam6(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657(V v_lit_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_target_245 = heff_take_field(v_req_242, 1);
  V v_method_246 = heff_take_field(v_req_242, 0);
  V v_headers_247 = heff_take_field(v_req_242, 3);
  V v_body_248 = heff_get_n(v_req_242, 4, 6);
  V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str0); V b_1 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str1); V b_2 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str2); V b_3 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str3); V b_4 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str4); V a_5 = v_headers_247; V r_ = (g_list_2ekeepIf_24s853072390x1205192752(b_0, b_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  V v_rq_2410 = heff_rec_n(7, shape_url__method__headers__body__timeout__connectTimeout__follow, (V[]){heff_strAppend(heff_dup(v_to_241), v_target_245), v_method_246, v_t_249, v_body_248, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_lit_2411 = v_lit_240;
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_2410, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam0_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_p_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_hd_2416 = v_z_243;
  V v_k2_2431 = heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam1, 1, 2, (V[]){v_to_241, v_z_244});
  V v_t_2457;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_InL: {
    V v_x_2432 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InL = heff_take_reuse_n(v_p_2415, 1ULL, 1);
    heff_drop_rec(v_lit_2411, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_2432)) {
    case TAG_Spawn: {
      V v_c_2433 = heff_field(v_x_2432, 0);
      V v_x_2434 = heff_field(v_x_2432, 1);
      V v_ru_24x_2432_24Spawn = heff_take_reuse_n(v_x_2432, 3ULL, 2);
      V v_t_2435 = heff_tr(heff_call(v_c_2433, 2, (V[]){heff_dup(v_hd_2416), heff_dup(heff_rfield(v_hd_2416, 0))}));
      v_t_2443 = heff_tag_at_n(v_ru_24x_2432_24Spawn, TAG_Spawn, 2, (V[]){v_t_2435, v_x_2434});
      break;
    }
    case TAG_Yield: {
      V v_x_2436 = heff_field(v_x_2432, 0);
      V v_ru_24x_2432_24Yield = heff_take_reuse_n(v_x_2432, 1ULL, 1);
      v_t_2443 = heff_tag_at_n(v_ru_24x_2432_24Yield, TAG_Yield, 1, (V[]){v_x_2436});
      break;
    }
    case TAG_NewKey: {
      V v_k_2437 = heff_field(v_x_2432, 0);
      V v_ru_24x_2432_24NewKey = heff_take_reuse_n(v_x_2432, 1ULL, 1);
      v_t_2443 = heff_tag_at_n(v_ru_24x_2432_24NewKey, TAG_NewKey, 1, (V[]){v_k_2437});
      break;
    }
    case TAG_Wake: {
      V v_ch_2438 = heff_field(v_x_2432, 0);
      V v_v_2439 = heff_field(v_x_2432, 1);
      V v_x_2440 = heff_field(v_x_2432, 2);
      V v_ru_24x_2432_24Wake = heff_take_reuse_n(v_x_2432, 7ULL, 3);
      v_t_2443 = heff_tag_at_n(v_ru_24x_2432_24Wake, TAG_Wake, 3, (V[]){v_ch_2438, v_v_2439, v_x_2440});
      break;
    }
    case TAG_Park: {
      V v_ch_2441 = heff_field(v_x_2432, 0);
      V v_k_2442 = heff_field(v_x_2432, 1);
      V v_ru_24x_2432_24Park = heff_take_reuse_n(v_x_2432, 3ULL, 2);
      v_t_2443 = heff_tag_at_n(v_ru_24x_2432_24Park, TAG_Park, 2, (V[]){v_ch_2441, v_k_2442});
      break;
    }
    default: heff_nomatch(v_x_2432);
    }
    v_t_2457 = heff_tag_at_n(v_ru_24p_2415_24InL, TAG_InL, 1, (V[]){v_t_2443});
    break;
  }
  case TAG_InR: {
    V v_y_2444 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InR = heff_take_reuse_n(v_p_2415, 1ULL, 1);
    V v_t_2456 = heff_tr(heff_call(heff_get_n(v_lit_2411, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam2_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam4, 2, 1, (V[]){heff_dup(v_hd_2416)})}), heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam6, 1, 1, (V[]){heff_dup(v_hd_2416)}), v_y_2444}));
    v_t_2457 = heff_tag_at_n(v_ru_24p_2415_24InR, TAG_InR, 1, (V[]){v_t_2456});
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_2457}));
  return heff_tail(heff_get_n(v_hd_2416, 1, 3), 2, (V[]){v_t_2458, v_k2_2431});
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_to_2418 = v_to_241;
  heff_drop(v_to_2418);
  V v_x2_2419 = v_x_2417;
  V v_x_2430;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    V v_url_2421 = heff_take_field(v_err_2420, 2);
    V v_code_2422 = heff_take_field(v_err_2420, 0);
    V v_message_2423 = heff_get_n(v_err_2420, 1, 3);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str5), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str6)}), NTAG(TAG_Nil)});
    V v_t_2425 = heff_strAppend(heff_strAppend(v_url_2421, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str7)), heff_intShow(v_code_2422));
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str8)), v_message_2423);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str9), v_t_2426), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str10));
    v_x_2430 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_2424, heff_bytesFromString(v_t_2427)});
    break;
  }
  case TAG_Right: {
    V v_res_2428 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str11); V b_1 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str12); V b_2 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str13); V b_3 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str14); V b_4 = ((V)&g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_str15); V a_5 = heff_take_field(v_res_2428, 1); V r_ = (g_list_2ekeepIf_24s853072390x1205192752(b_0, b_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
    v_x_2430 = ({ V rv_1 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_res_2428, 5ULL, 3, shape_status__headers__body, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V f_ = v_z_244;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam3(V self, V *args) {
  V v_x_2449 = args[0];
  V v_g_2445 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2450 = heff_tr(heff_call(v_g_2445, 1, (V[]){v_x_2449}));
  V f_ = v_k_2448;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam2(V self, V *args) {
  V v_g_2445 = args[0];
  V v_c_2446 = args[1];
  V v_hd_2447 = args[2];
  V v_k_2448 = args[3];
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam3, 1, 2, (V[]){v_g_2445, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_g_2451 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = heff_tr(heff_call(v_g_2451, 1, (V[]){v_x_2453}));
  V f_ = heff_get_n(v_hd_2416, 0, 3);
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam4(V self, V *args) {
  V v_g_2451 = args[0];
  V v_m_2452 = args[1];
  V v_hd_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
  args[0] = v_m_2452;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam5, 1, 2, (V[]){v_g_2451, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_lam6(V self, V *args) {
  V v_c_2455 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2455;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_get_n(v_hd_2416, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str6, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str7, 0, "");
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam4, 4, 0};
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam2(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056(V v_lit_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    V v_t_244 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
    V v_target_245 = heff_get_n(v_req_243, 1, 6);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str0), v_target_245, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_path_247 = v_target_245;
    } else {
      v_path_247 = heff_strSlice(v_target_245, MK_INT(0LL), v_j_246);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V a_0 = v_s_248; V b_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_248); heff_drop(b_1); r_; });
    HEFF_LAST return g_heff_2ebuild_2edev_2eanswer(v_t_244, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam0_clo), v_st_241, v_t_249);
  }
  case TAG_Just: {
    V v_to_2417 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2418 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2419 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str3), v_target_2418, MK_INT(0LL), 5);
    V v_path_2420;
    if (heff_intLt_c_lent(v_j_2419, MK_INT(0LL), 2)) {
      heff_drop(v_j_2419);
      v_path_2420 = v_target_2418;
    } else {
      v_path_2420 = heff_strSlice(v_target_2418, MK_INT(0LL), v_j_2419);
    }
    V v_s_2421 = heff_strSlice(heff_dup(v_path_2420), MK_INT(1LL), heff_strLength(v_path_2420));
    V v_x1_2422 = ({ V a_0 = v_s_2421; V b_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str5), v_s_2421, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2421); heff_drop(b_1); r_; });
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str6)));
    V v_t_2426;
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_x1_2422, 0);
      heff_take_n(v_x1_2422, 1ULL, 2);
      v_t_2426 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x1_2422);
    }
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_t_2426));
    V v_t_2428 = (g_std_2epath_2ejoin(v_t_2423, v_t_2427));
    V v_s_2429 = ({ V a_0 = v_st_241; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2429));
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2430); r_; });
    V v_a_2433 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_2431, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam2, 2, 5, (V[]){v_a_2433, v_lit_240, v_st_241, v_req_243, v_to_2417});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam1(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_req_243 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  V v_to_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    return ({ V a_0 = v_lit_240; V a_1 = v_st_241; V a_2 = v_req_243; V a_3 = v_hd_2434; V a_4 = v_k_2435; V a_5 = v_to_2417; V b_6 = NTAG(TAG_False); V r_ = (g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_s_2441 = heff_field(v_x_2439, 0);
    heff_take_n(v_x_2439, 1ULL, 1);
    V v_t_2442 = heff_get_n(v_s_2441, 0, 4);
    V v_t_2443;
    switch (heff_tag_of(v_t_2442)) {
    case TAG_Regular: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2442);
    }
    return ({ V a_0 = v_lit_240; V a_1 = v_st_241; V a_2 = v_req_243; V a_3 = v_hd_2434; V a_4 = v_k_2435; V a_5 = v_to_2417; V a_6 = v_t_2443; V r_ = (g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2443); r_; });
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam5(V self, V *args) {
  V v_x_2455 = args[0];
  V v_g_2451 = heff_env(self)[0];
  V v_k_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2456 = heff_tr(heff_call(v_g_2451, 1, (V[]){v_x_2455}));
  V f_ = v_k_2454;
  args[0] = v_x_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam4(V self, V *args) {
  V v_g_2451 = args[0];
  V v_c_2452 = args[1];
  V v_hd_2453 = args[2];
  V v_k_2454 = args[3];
  V f_ = v_c_2452;
  args[0] = v_hd_2453;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam5, 1, 2, (V[]){v_g_2451, v_k_2454});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_g_2457 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_call(v_g_2457, 1, (V[]){v_x_2459}));
  V f_ = heff_get_n(v_hd_2438, 0, 3);
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam6(V self, V *args) {
  V v_g_2457 = args[0];
  V v_m_2458 = args[1];
  V v_hd_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2438, 1));
  args[0] = v_m_2458;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam7, 1, 2, (V[]){v_g_2457, v_hd_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam8(V self, V *args) {
  V v_c_2461 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2461;
  heff_room[0] = heff_dup(v_hd_2438);
  heff_room[1] = heff_get_n(v_hd_2438, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam2(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_a_2433 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_req_243 = heff_env(self)[3];
  V v_to_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_lit_2436 = v_a_2433;
  V v_lit_2437 = heff_dup(v_lit_240);
  V v_hd_2438 = heff_dup(v_hd_2434);
  V v_k2_2444 = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam3, 1, 6, (V[]){v_lit_240, v_st_241, v_req_243, v_hd_2434, v_k_2435, v_to_2417});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_2436})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2462 = heff_tr(heff_call(heff_get_n(v_lit_2437, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam4_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam6, 2, 1, (V[]){heff_dup(v_hd_2438)})}), heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_lam8, 1, 1, (V[]){heff_dup(v_hd_2438)}), v_t_2450}));
  V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_2438, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})}));
  V f_ = heff_get_n(v_hd_2438, 1, 3);
  args[0] = v_t_2463;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str1, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str4, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str9, 36, "heff dev: cannot serve the pages at ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam8, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam7, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam9, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam11(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam11, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam21(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam21, 4, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam24(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam24, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam26(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam26, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam29(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam29, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam27(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam33(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam35(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_entry, 5, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528(V v_e_240, V v_port_241, V v_proxy_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam1, 1, 5, (V[]){v_port_241, v_e_240, v_proxy_242, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam8(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2453 = args[1];
  V v_k_2454 = args[2];
  heff_drop(v_x_2452);
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  heff_drop(v_x_2449);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam8_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2448);
  V f_ = v_k_2433;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam7_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam9(V self, V *args) {
  V v_i_2456 = args[0];
  return v_i_2456;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam11(V self, V *args) {
  V v_x_2461 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2461});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam12(V self, V *args) {
  V v_m_2462 = args[0];
  V v_f_2463 = args[1];
  V v_e_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2443; V a_1 = v_m_2462; V a_2 = v_f_2463; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_2443); r_; });
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam14(V self, V *args) {
  V v_u_2470 = args[0];
  V v_x_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2470);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2469});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam15(V self, V *args) {
  V v_u_2472 = args[0];
  V v_x_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2472);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2471});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam16(V self, V *args) {
  V v_n_2474 = args[0];
  V v_k_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tr(heff_call(v_k_2473, 1, (V[]){v_n_2474}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2475});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam17(V self, V *args) {
  V v_u_2479 = args[0];
  V v_x_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2479);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2478});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam18(V self, V *args) {
  V v_v_2482 = args[0];
  V v_k_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2483 = heff_tr(heff_call(v_k_2481, 1, (V[]){v_v_2482}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2483});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam20(V self, V *args) {
  V v_x_2487 = args[0];
  V v_g_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_tr(heff_call(v_g_2485, 1, (V[]){v_x_2487}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2488});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam19(V self, V *args) {
  V v_g_2485 = args[0];
  V v_r_2486 = args[1];
  V v_e_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2465; V a_1 = v_r_2486; V a_2 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam20, 1, 1, (V[]){v_g_2485}); V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop_rec(v_e_2465, 2); r_; });
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam22(V self, V *args) {
  V v_x_2493 = args[0];
  V v_g_2489 = heff_env(self)[0];
  V v_k_2492 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2494 = heff_tr(heff_call(v_g_2489, 1, (V[]){v_x_2493}));
  V f_ = v_k_2492;
  args[0] = v_x_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam21(V self, V *args) {
  V v_g_2489 = args[0];
  V v_c_2490 = args[1];
  V v_hd_2491 = args[2];
  V v_k_2492 = args[3];
  V f_ = v_c_2490;
  args[0] = v_hd_2491;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam22, 1, 2, (V[]){v_g_2489, v_k_2492});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam23(V self, V *args) {
  V v_r_2495 = args[0];
  V v_e_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_green_2ealone(v_e_2465, v_r_2495));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam13(V self, V *args) {
  V v_p_2464 = args[0];
  V v_e_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2465 = v_e_2443;
  V v_x2_2466 = v_p_2464;
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_InL: {
    V v_x21_2467 = heff_field(v_x2_2466, 0);
    V v_ru_24x2_2466_24InL = heff_take_reuse_n(v_x2_2466, 1ULL, 1);
    heff_drop_rec(v_e_2465, 2);
    switch (heff_tag_of(v_x21_2467)) {
    case TAG_Spawn: {
      V v_c_2468 = heff_field(v_x21_2467, 0);
      V v_x_2469 = heff_field(v_x21_2467, 1);
      V v_ru_24x21_2467_24Spawn = heff_take_reuse_n(v_x21_2467, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_2466_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_2467_24Spawn, TAG_RSpawn, 2, (V[]){v_c_2468, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam14, 1, 1, (V[]){v_x_2469})});
    }
    case TAG_Yield: {
      V v_x_2471 = heff_field(v_x21_2467, 0);
      heff_take_n(v_x21_2467, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_2466_24InL, TAG_RYield, 1, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam15, 1, 1, (V[]){v_x_2471})});
    }
    case TAG_NewKey: {
      V v_k_2473 = heff_field(v_x21_2467, 0);
      heff_take_n(v_x21_2467, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_2466_24InL, TAG_RKey, 1, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam16, 1, 1, (V[]){v_k_2473})});
    }
    case TAG_Wake: {
      V v_ch_2476 = heff_field(v_x21_2467, 0);
      V v_v_2477 = heff_field(v_x21_2467, 1);
      V v_x_2478 = heff_field(v_x21_2467, 2);
      V v_ru_24x21_2467_24Wake = heff_take_reuse_n(v_x21_2467, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_2466_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_2467_24Wake, TAG_RWake, 3, (V[]){v_ch_2476, v_v_2477, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam17, 1, 1, (V[]){v_x_2478})});
    }
    case TAG_Park: {
      V v_ch_2480 = heff_field(v_x21_2467, 0);
      V v_k_2481 = heff_field(v_x21_2467, 1);
      V v_ru_24x21_2467_24Park = heff_take_reuse_n(v_x21_2467, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_2466_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_2467_24Park, TAG_RPark, 2, (V[]){v_ch_2480, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam18, 1, 1, (V[]){v_k_2481})});
    }
    default: return heff_nomatch(v_x21_2467);
    }
  }
  case TAG_InR: {
    V v_q_2484 = heff_field(v_x2_2466, 0);
    V v_ru_24x2_2466_24InR = heff_take_reuse_n(v_x2_2466, 1ULL, 1);
    V v_t_2496 = heff_tr(heff_call(heff_dup(heff_rfield(v_e_2465, 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam19, 2, 1, (V[]){heff_dup(v_e_2465)})}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam21_clo)}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam23, 1, 1, (V[]){heff_dup(v_e_2465)}), v_q_2484}));
    V v_t_2497 = heff_tr(heff_call(((V)&g_co_2eop_24s1015281915x1399722043_clo), 2, (V[]){v_e_2465, v_t_2496}));
    return heff_tag_at_n(v_ru_24x2_2466_24InR, TAG_RAct, 1, (V[]){v_t_2497});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam24(V self, V *args) {
  V v_x_2498 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2498});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_c_2446 = heff_env(self)[0];
  V v_e_2443 = heff_env(self)[1];
  V v_lit_2442 = heff_env(self)[2];
  V v_hd_2447 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tr(heff_call(v_c_2446, 2, (V[]){heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam11_clo), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam12, 2, 1, (V[]){heff_dup(v_e_2443)}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam13, 1, 1, (V[]){heff_dup(v_e_2443)})}), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam24_clo)}));
  V v_t_24100 = (g_green_2eview(v_e_2443, heff_tag_n(TAG_Main, 1, (V[]){v_t_2499})));
  V v_t_24101 = ({ V a_0 = v_lit_2442; V a_1 = v_e_2443; V a_2 = heff_tag_n(TAG_MkGroup, 1, (V[]){v_x_2460}); V a_3 = NTAG(TAG_Alone); V a_4 = heff_rec_n(6, shape_ready__woken__parked__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}); V a_5 = v_t_24100; V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_2443); r_; });
  V f_ = v_t_24101;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2455;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_proxy_242 = heff_env(self)[2];
  V v_listener_2427 = heff_env(self)[3];
  V v_hd_2432 = heff_env(self)[4];
  V v_k_2433 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2441);
  V v_lit_2442 = heff_dup(v_e_240);
  V v_e_2443 = heff_dup(v_e_240);
  V v_t_2444;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str6))) {
    v_t_2444 = NTAG(TAG_Windows);
  } else {
    v_t_2444 = NTAG(TAG_Posix);
  }
  V v_t_2445 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_clo), 3, (V[]){heff_dup(v_e_240), v_t_2444, v_proxy_242}));
  V v_c_2446 = heff_tr(heff_call(((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_clo), 4, (V[]){v_e_240, MK_INT(30000LL), v_listener_2427, v_t_2445}));
  V v_hd_2447 = v_hd_2432;
  V v_k_2455 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam6, 1, 1, (V[]){v_k_2433});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam9_clo)})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_lit_2442), v_t_2459, heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam10, 1, 5, (V[]){v_c_2446, v_e_2443, v_lit_2442, v_hd_2447, v_k_2455})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_t_2431 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_proxy_242 = heff_env(self)[3];
  V v_listener_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam5, 1, 6, (V[]){v_e_240, v_x_2413, v_proxy_242, v_listener_2427, v_hd_2432, v_k_2433})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam3(V self, V *args) {
  V v_listener_2427 = args[0];
  V v_port_241 = heff_env(self)[0];
  V v_proxy_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str1), v_port_241), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str2));
  V v_t_2430;
  switch (heff_tag_of(v_proxy_242)) {
  case TAG_Nothing: {
    v_t_2430 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str3);
    break;
  }
  case TAG_Just: {
    V v_x_2429 = heff_dup(heff_field(v_proxy_242, 0));
    v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str4), v_x_2429);
    break;
  }
  default: heff_nomatch(v_proxy_242);
  }
  V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2428, v_t_2430), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str5));
  return heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam4, 2, 5, (V[]){v_t_2431, v_e_240, v_x_2413, v_proxy_242, v_listener_2427});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam25(V self, V *args) {
  V v_x_24104 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_24104;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2420;
  heff_room[2] = v_k_2421;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam26(V self, V *args) {
  V v_r_24107 = args[0];
  return v_r_24107;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam29(V self, V *args) {
  V v_r_24117 = args[0];
  return v_r_24117;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam30(V self, V *args) {
  V v_x_24121 = args[0];
  V v_e_2422 = heff_env(self)[0];
  V v_p_24103 = heff_env(self)[1];
  V v_p_24105 = heff_env(self)[2];
  V v_x_24116 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24121)) {
  case TAG_Left: {
    V v_err_24122 = heff_field(v_x_24121, 0);
    V v_ru_24x_24121_24Left = heff_take_reuse_n(v_x_24121, 1ULL, 1);
    heff_drop(v_x_24116);
    V v_t_24123 = heff_tag_at_n(v_ru_24x_24121_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24122})});
    return (g_co_2eop_24s310169282x2049378029(v_e_2422, v_t_24123, v_p_24103, v_p_24105));
  }
  case TAG_Right: {
    heff_take_n(v_x_24121, 0ULL, 1);
    heff_drop(v_e_2422);
    heff_drop(v_p_24103);
    V f_ = v_p_24105;
    args[0] = v_x_24116;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24121);
  }
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam28(V self, V *args) {
  V v_x_24116 = args[0];
  V v_x_24114 = heff_env(self)[0];
  V v_e_2422 = heff_env(self)[1];
  V v_p_24103 = heff_env(self)[2];
  V v_p_24105 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReleaseListener, 2, (V[]){v_x_24114, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam29_clo)})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_2422), heff_tag_n(TAG_InR, 1, (V[]){v_t_24120}), heff_dup(v_p_24103), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam30, 1, 4, (V[]){v_e_2422, v_p_24103, v_p_24105, v_x_24116})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam27(V self, V *args) {
  V v_x_24111 = args[0];
  V v_e_2422 = heff_env(self)[0];
  V v_p_24103 = heff_env(self)[1];
  V v_p_24105 = heff_env(self)[2];
  V v_body_24102 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24111)) {
  case TAG_Left: {
    V v_err_24112 = heff_field(v_x_24111, 0);
    V v_ru_24x_24111_24Left = heff_take_reuse_n(v_x_24111, 1ULL, 1);
    heff_drop_clo(v_body_24102, 4);
    V v_t_24113 = heff_tag_at_n(v_ru_24x_24111_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24112})});
    return (g_co_2eop_24s310169282x2049378029(v_e_2422, v_t_24113, v_p_24103, v_p_24105));
  }
  case TAG_Right: {
    V v_x_24114 = heff_field(v_x_24111, 0);
    heff_take_n(v_x_24111, 1ULL, 1);
    V v_c_24115 = heff_tr(heff_call(v_body_24102, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_24114)})}));
    V f_ = v_c_24115;
    heff_room[0] = heff_dup(v_p_24103);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam28, 1, 4, (V[]){v_x_24114, v_e_2422, v_p_24103, v_p_24105});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24111);
  }
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_2419 = heff_env(self)[1];
  V v_port_241 = heff_env(self)[2];
  V v_proxy_242 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_e_2422 = heff_dup(v_e_240);
  V v_address_2423 = v_t_2419;
  V v_port_2424 = heff_take_field(v_address_2423, 1);
  V v_host_2425 = heff_get_n(v_address_2423, 0, 2);
  V v_backlog_2426 = MK_INT(64LL);
  V v_body_24102 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam3, 1, 4, (V[]){v_port_241, v_proxy_242, v_e_240, v_x_2413});
  V v_p_24103 = heff_dup(v_hd_2420);
  V v_p_24105 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam25, 1, 2, (V[]){v_hd_2420, v_k_2421});
  V v_port_24106 = v_port_2424;
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Listen, 4, (V[]){v_host_2425, v_port_24106, v_backlog_2426, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam26_clo)})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_2422), heff_tag_n(TAG_InR, 1, (V[]){v_t_24110}), heff_dup(v_p_24103), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam27, 1, 4, (V[]){v_e_2422, v_p_24103, v_p_24105, v_body_24102})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam34(V self, V *args) {
  V v_x_24150 = args[0];
  V v_hd_24151 = args[1];
  V v_k_24152 = args[2];
  V v_x_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24150);
  heff_drop(v_hd_24151);
  V f_ = v_k_24152;
  args[0] = v_x_24149;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam33(V self, V *args) {
  V v_x_24149 = args[0];
  V v_k_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_24127;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam34, 3, 1, (V[]){v_x_24149});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam32(V self, V *args) {
  V v_x_24141 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_24126 = heff_env(self)[1];
  V v_k_24127 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24141);
  V v_t_24142 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24147})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24148}), v_hd_24126, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam33, 1, 1, (V[]){v_k_24127})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam31(V self, V *args) {
  V v_err_24125 = args[0];
  V v_hd_24126 = args[1];
  V v_k_24127 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_address_24128 = heff_take_field(v_err_24125, 3);
  V v_name_24129 = heff_take_field(v_err_24125, 1);
  V v_message_24130 = heff_get_n(v_err_24125, 2, 4);
  V v_t_24131 = heff_strAppend(heff_strAppend(v_address_24128, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str7)), v_name_24129);
  V v_t_24132 = heff_strAppend(heff_strAppend(v_t_24131, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str8)), v_message_24130);
  V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str9), v_t_24132), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str10));
  V v_t_24134 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24133, NTAG(TAG_MkUnit)});
  V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
  V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
  V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
  V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24140}), heff_dup(v_hd_24126), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam32, 1, 3, (V[]){v_e_240, v_hd_24126, v_k_24127})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam35(V self, V *args) {
  V v_x_24154 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_24154;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_port_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_proxy_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2414 = (g_prelude_2eparseInt_24cpr(v_port_241));
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = MK_INT(8000LL);
    }
  }
  V v_t_2419 = heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_str0), v_t_2418});
  V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam2, 2, 5, (V[]){heff_dup(v_e_240), v_t_2419, v_port_241, v_proxy_242, v_x_2413}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam31, 3, 1, (V[]){heff_dup(v_e_240)})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24153, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_lam35, 1, 2, (V[]){v_hd_243, v_k_244})));
}