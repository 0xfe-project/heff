// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Main 39920
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_body 9524841
#define LBL_chans 295981947
#define LBL_ended 298010324
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_host 9704047
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_ready 309745085
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_url 325609
#define LBL_waiting 1348170899
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s2088512805x623284879(V, V, V, V, V, V);
V g_co_2eop_24s2088512805x623284879_entry(V self, V *a);
extern Clo g_co_2eop_24s2088512805x623284879_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s633950905x694375709(V, V, V, V);
V g_green_2ego_24s633950905x694375709_entry(V self, V *a);
extern Clo g_green_2ego_24s633950905x694375709_clo;
V g_green_2eview_24s1017855520x282345245(V);
V g_green_2eview_24s1017855520x282345245_entry(V self, V *a);
extern Clo g_green_2eview_24s1017855520x282345245_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2ekeepIf_24s2044822566x1809079154(V, V, V, V, V, V);
V g_list_2ekeepIf_24s2044822566x1809079154_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2044822566x1809079154_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2134631892x1602276853(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2134631892x1602276853_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2134631892x1602276853_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2ewithListener_24s1426613277x1843796189(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s1426613277x1843796189_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s1426613277x1843796189_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2ereactor_2eoutside_24s1108339440x749645818(V);
V g_std_2ereactor_2eoutside_24s1108339440x749645818_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s1108339440x749645818_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str22, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_244), heff_strLength_lent(v_p_240, 0));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2))) {
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str3);
    } else {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2edev_2etypeOf_str4))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str5);
      } else {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
        V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str6))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str7);
        } else {
          int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
          V v_t_2414 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2413), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edev_2etypeOf_str8))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str9);
          } else {
            int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2417 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2edev_2etypeOf_str10))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str11);
            } else {
              int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
              if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str12))) {
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str13);
              } else {
                int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                V v_t_2423 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2422), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
                } else {
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                  V v_t_2426 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2425), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                  } else {
                    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                    V v_t_2429 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2428), heff_strLength_lent(v_p_240, 0));
                    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                    } else {
                      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                      V v_t_2432 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2431), heff_strLength_lent(v_p_240, 0));
                      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2edev_2etypeOf_str20))) {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str21);
                      } else {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str22);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str19, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str20, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str21, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str23, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str24, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str26, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str27, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str28, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str29, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str37, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str38, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str42, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str43, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str45, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str46, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str47, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str48, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str50, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str51, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str52, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str53, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str55, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str56, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str58, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str59, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str60, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str61, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str72, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str74, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str75, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str77, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str78, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str79, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str80, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str81, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str82, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str83, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str84, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str85, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str86, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str87, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str88, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str90, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str91, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str92, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str93, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str94, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str95, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str96, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str107, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str108, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str109, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str110, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str111, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str114, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str115, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str116, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str117, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str118, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str119, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str120, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str121, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str122, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str123, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str124, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str126, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str127, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str128, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str129, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str130, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str131, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str132, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam9, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam18, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam24, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam35, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam41, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam51, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam57, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_entry, 4, 0};

V g_heff_2ebuild_2edev_2eanswer(V v_e_240, V v_disk_241, V v_st_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_disk_241);
    return ((V)&g_heff_2ebuild_2edev_2eanswer_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_243, 0);
    V v_x22_249 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str3), 2)) {
      switch (heff_tag_of(v_x22_249)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_disk_241);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam1, 2, 1, (V[]){v_x21_248});
      }
      case TAG_Cons: {
        V v_x221_2416 = heff_dup(heff_field(v_x22_249, 0));
        V v_x222_2417 = heff_dup(heff_field(v_x22_249, 1));
        if (heff_strEq_c_lent(v_x221_2416, ((V)&g_heff_2ebuild_2edev_2eanswer_str8), 2)) {
          heff_drop(v_x221_2416);
          switch (heff_tag_of(v_x222_2417)) {
          case TAG_Nil: {
            heff_drop(v_x21_248);
            heff_drop_tag(v_x22_249, 2);
            heff_drop_cell(v_ru_24x2_243_24Cons, 2);
            V v_t_2419 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str9)));
            V v_t_2420 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str10)));
            V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
            V v_a_2422 = ({ V a_0 = v_st_242; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
            V v_t_2423 = (g_std_2epath_2eparse(v_st_242, v_a_2422));
            V v_t_2424 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str11)));
            V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
            V v_s_2426 = ({ V a_0 = v_st_242; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); r_; });
            V v_t_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2426; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
            V v_c_2428 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2427; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam2, 2, 1, (V[]){v_c_2428});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2417, 0ULL, 2);
            V v_x1_2440 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_2440) == NTAG(TAG_True))) {
              heff_drop(v_x1_2440);
              V v_t_2443;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_2443 = ((V)&g_heff_2ebuild_2edev_2eanswer_str17);
                break;
              }
              case TAG_Cons: {
                V v_x_2441 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_2442 = heff_dup(heff_field(v_x22_249, 1));
                v_t_2443 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str18); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_2443, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str19)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_2445 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str20)));
                V v_t_2446 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str21)));
                V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
                V v_a_2448 = ({ V a_0 = v_st_242; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2447); r_; });
                V v_t_2449 = (g_std_2epath_2eparse(v_st_242, v_a_2448));
                V v_t_2450 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str22))));
                V v_t_2451 = (g_std_2epath_2ejoin(v_t_2449, v_t_2450));
                V v_s_2452 = ({ V a_0 = v_st_242; V a_1 = v_t_2451; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2451); r_; });
                V v_t_2453 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2452; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_2454 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2453; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam4, 2, 2, (V[]){v_c_2454, v_x21_248});
              } else {
                V v_t_2459 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str24)));
                V v_t_2460 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
                V v_t_2462 = ({ V a_0 = v_st_242; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2461); r_; });
                V v_s_2468 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam6, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_2462, v_x22_249));
                V v_t_2469 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2468; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_2470 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2469; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2469); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam7, 2, 2, (V[]){v_c_2470, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_2440);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam9_clo);
            }
          }
          default: return heff_nomatch(v_x222_2417);
          }
        } else {
          if (heff_strEq_c(v_x221_2416, ((V)&g_heff_2ebuild_2edev_2eanswer_str30))) {
            switch (heff_tag_of(v_x222_2417)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_2483 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str31)));
              V v_t_2484 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_2485 = (g_std_2epath_2ejoin(v_t_2483, v_t_2484));
              V v_a_2486 = ({ V a_0 = v_st_242; V a_1 = v_t_2485; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2485); r_; });
              V v_t_2487 = (g_std_2epath_2eparse(v_st_242, v_a_2486));
              V v_t_2488 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str32)));
              V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
              V v_s_2490 = ({ V a_0 = v_st_242; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2489); r_; });
              V v_t_2491 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2490; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_2492 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_2491; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2491); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam10, 2, 5, (V[]){v_c_2492, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2417, 0ULL, 2);
              V v_x1_24110 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24110) == NTAG(TAG_True))) {
                heff_drop(v_x1_24110);
                V v_t_24113;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24113 = ((V)&g_heff_2ebuild_2edev_2eanswer_str36);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24111 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24112 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24113 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str37); V a_1 = v_x_24111; V a_2 = v_xs_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24112); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24113, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str38)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24115 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str39)));
                  V v_t_24116 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str40)));
                  V v_t_24117 = (g_std_2epath_2ejoin(v_t_24115, v_t_24116));
                  V v_a_24118 = ({ V a_0 = v_st_242; V a_1 = v_t_24117; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24117); r_; });
                  V v_t_24119 = (g_std_2epath_2eparse(v_st_242, v_a_24118));
                  V v_t_24120 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str41))));
                  V v_t_24121 = (g_std_2epath_2ejoin(v_t_24119, v_t_24120));
                  V v_s_24122 = ({ V a_0 = v_st_242; V a_1 = v_t_24121; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24121); r_; });
                  V v_t_24123 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24122; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24124 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24123; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24123); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam13, 2, 2, (V[]){v_c_24124, v_x21_248});
                } else {
                  V v_t_24129 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str43)));
                  V v_t_24130 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24131 = (g_std_2epath_2ejoin(v_t_24129, v_t_24130));
                  V v_t_24132 = ({ V a_0 = v_st_242; V a_1 = v_t_24131; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24131); r_; });
                  V v_s_24138 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam15, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24132, v_x22_249));
                  V v_t_24139 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24138; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24140 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24139; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24139); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam16, 2, 2, (V[]){v_c_24140, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24110);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam18_clo);
              }
            }
            default: return heff_nomatch(v_x222_2417);
            }
          } else {
            heff_drop(v_x222_2417);
            V v_x1_24152 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24152) == NTAG(TAG_True))) {
              heff_drop(v_x1_24152);
              V v_t_24155;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24155 = ((V)&g_heff_2ebuild_2edev_2eanswer_str49);
                break;
              }
              case TAG_Cons: {
                V v_x_24153 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24154 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24155 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str50); V a_1 = v_x_24153; V a_2 = v_xs_24154; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24154); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24155, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str51)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24157 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str52)));
                V v_t_24158 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str53)));
                V v_t_24159 = (g_std_2epath_2ejoin(v_t_24157, v_t_24158));
                V v_a_24160 = ({ V a_0 = v_st_242; V a_1 = v_t_24159; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24159); r_; });
                V v_t_24161 = (g_std_2epath_2eparse(v_st_242, v_a_24160));
                V v_t_24162 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str54))));
                V v_t_24163 = (g_std_2epath_2ejoin(v_t_24161, v_t_24162));
                V v_s_24164 = ({ V a_0 = v_st_242; V a_1 = v_t_24163; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24163); r_; });
                V v_t_24165 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24164; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24166 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24165; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24165); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam19, 2, 2, (V[]){v_c_24166, v_x21_248});
              } else {
                V v_t_24171 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str56)));
                V v_t_24172 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24173 = (g_std_2epath_2ejoin(v_t_24171, v_t_24172));
                V v_t_24174 = ({ V a_0 = v_st_242; V a_1 = v_t_24173; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24173); r_; });
                V v_s_24180 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam21, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24174, v_x22_249));
                V v_t_24181 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24180; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24182 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24181; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24181); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam22, 2, 2, (V[]){v_c_24182, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24152);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam24_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_249);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str62), 2)) {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_x21_248);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          V v_t_24195 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str63)));
          V v_t_24196 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str64)));
          V v_t_24197 = (g_std_2epath_2ejoin(v_t_24195, v_t_24196));
          V v_s_24198 = ({ V a_0 = v_st_242; V a_1 = v_t_24197; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24197); r_; });
          V v_t_24199 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24198; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_c_24200 = (g_heff_2eutil_2efiles_2ereadDirectory(v_e_240, v_disk_241, v_t_24199));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam25, 2, 1, (V[]){v_c_24200});
        }
        case TAG_Cons: {
          V v_x221_24205 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24206 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24205, ((V)&g_heff_2ebuild_2edev_2eanswer_str65))) {
            switch (heff_tag_of(v_x222_24206)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24208 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str66)));
              V v_t_24209 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24210 = (g_std_2epath_2ejoin(v_t_24208, v_t_24209));
              V v_a_24211 = ({ V a_0 = v_st_242; V a_1 = v_t_24210; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24210); r_; });
              V v_t_24212 = (g_std_2epath_2eparse(v_st_242, v_a_24211));
              V v_t_24213 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str67)));
              V v_t_24214 = (g_std_2epath_2ejoin(v_t_24212, v_t_24213));
              V v_s_24215 = ({ V a_0 = v_st_242; V a_1 = v_t_24214; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24214); r_; });
              V v_t_24216 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24215; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_24217 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_24216; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24216); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam27, 2, 5, (V[]){v_c_24217, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24206, 0ULL, 2);
              V v_x1_24235 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24235) == NTAG(TAG_True))) {
                heff_drop(v_x1_24235);
                V v_t_24238;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24238 = ((V)&g_heff_2ebuild_2edev_2eanswer_str71);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24236 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24237 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24238 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str72); V a_1 = v_x_24236; V a_2 = v_xs_24237; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24237); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24238, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str73)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24240 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str74)));
                  V v_t_24241 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str75)));
                  V v_t_24242 = (g_std_2epath_2ejoin(v_t_24240, v_t_24241));
                  V v_a_24243 = ({ V a_0 = v_st_242; V a_1 = v_t_24242; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24242); r_; });
                  V v_t_24244 = (g_std_2epath_2eparse(v_st_242, v_a_24243));
                  V v_t_24245 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str76))));
                  V v_t_24246 = (g_std_2epath_2ejoin(v_t_24244, v_t_24245));
                  V v_s_24247 = ({ V a_0 = v_st_242; V a_1 = v_t_24246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24246); r_; });
                  V v_t_24248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24249 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24248; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24248); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam30, 2, 2, (V[]){v_c_24249, v_x21_248});
                } else {
                  V v_t_24254 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str78)));
                  V v_t_24255 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24256 = (g_std_2epath_2ejoin(v_t_24254, v_t_24255));
                  V v_t_24257 = ({ V a_0 = v_st_242; V a_1 = v_t_24256; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24256); r_; });
                  V v_s_24263 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam32, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24257, v_x22_249));
                  V v_t_24264 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24263; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24265 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24264; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24264); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam33, 2, 2, (V[]){v_c_24265, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24235);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam35_clo);
              }
            }
            default: return heff_nomatch(v_x222_24206);
            }
          } else {
            heff_drop(v_x222_24206);
            V v_x1_24277 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24277) == NTAG(TAG_True))) {
              heff_drop(v_x1_24277);
              V v_t_24280;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24280 = ((V)&g_heff_2ebuild_2edev_2eanswer_str84);
                break;
              }
              case TAG_Cons: {
                V v_x_24278 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24279 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24280 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str85); V a_1 = v_x_24278; V a_2 = v_xs_24279; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24279); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24280, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str86)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24282 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str87)));
                V v_t_24283 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str88)));
                V v_t_24284 = (g_std_2epath_2ejoin(v_t_24282, v_t_24283));
                V v_a_24285 = ({ V a_0 = v_st_242; V a_1 = v_t_24284; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24284); r_; });
                V v_t_24286 = (g_std_2epath_2eparse(v_st_242, v_a_24285));
                V v_t_24287 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str89))));
                V v_t_24288 = (g_std_2epath_2ejoin(v_t_24286, v_t_24287));
                V v_s_24289 = ({ V a_0 = v_st_242; V a_1 = v_t_24288; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24288); r_; });
                V v_t_24290 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24289; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24291 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24290; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24290); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam36, 2, 2, (V[]){v_c_24291, v_x21_248});
              } else {
                V v_t_24296 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str91)));
                V v_t_24297 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24298 = (g_std_2epath_2ejoin(v_t_24296, v_t_24297));
                V v_t_24299 = ({ V a_0 = v_st_242; V a_1 = v_t_24298; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24298); r_; });
                V v_s_24305 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam38, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24299, v_x22_249));
                V v_t_24306 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24305; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24307 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24306; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24306); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam39, 2, 2, (V[]){v_c_24307, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24277);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam41_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      } else {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_e_240);
          heff_drop(v_disk_241);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam42, 2, 1, (V[]){v_x21_248});
        }
        case TAG_Cons: {
          V v_x221_24324 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24325 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24324, ((V)&g_heff_2ebuild_2edev_2eanswer_str101))) {
            switch (heff_tag_of(v_x222_24325)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24327 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str102)));
              V v_t_24328 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24329 = (g_std_2epath_2ejoin(v_t_24327, v_t_24328));
              V v_a_24330 = ({ V a_0 = v_st_242; V a_1 = v_t_24329; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24329); r_; });
              V v_t_24331 = (g_std_2epath_2eparse(v_st_242, v_a_24330));
              V v_t_24332 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str103)));
              V v_t_24333 = (g_std_2epath_2ejoin(v_t_24331, v_t_24332));
              V v_s_24334 = ({ V a_0 = v_st_242; V a_1 = v_t_24333; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24333); r_; });
              V v_t_24335 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24334; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_24336 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_24335; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24335); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam43, 2, 5, (V[]){v_c_24336, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24325, 0ULL, 2);
              V v_x1_24354 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24354) == NTAG(TAG_True))) {
                heff_drop(v_x1_24354);
                V v_t_24357;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24357 = ((V)&g_heff_2ebuild_2edev_2eanswer_str107);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24355 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24356 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24357 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str108); V a_1 = v_x_24355; V a_2 = v_xs_24356; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24356); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24357, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str109)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24359 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str110)));
                  V v_t_24360 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str111)));
                  V v_t_24361 = (g_std_2epath_2ejoin(v_t_24359, v_t_24360));
                  V v_a_24362 = ({ V a_0 = v_st_242; V a_1 = v_t_24361; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24361); r_; });
                  V v_t_24363 = (g_std_2epath_2eparse(v_st_242, v_a_24362));
                  V v_t_24364 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str112))));
                  V v_t_24365 = (g_std_2epath_2ejoin(v_t_24363, v_t_24364));
                  V v_s_24366 = ({ V a_0 = v_st_242; V a_1 = v_t_24365; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24365); r_; });
                  V v_t_24367 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24366; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24368 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24367; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24367); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam46, 2, 2, (V[]){v_c_24368, v_x21_248});
                } else {
                  V v_t_24373 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str114)));
                  V v_t_24374 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24375 = (g_std_2epath_2ejoin(v_t_24373, v_t_24374));
                  V v_t_24376 = ({ V a_0 = v_st_242; V a_1 = v_t_24375; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24375); r_; });
                  V v_s_24382 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam48, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24376, v_x22_249));
                  V v_t_24383 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24382; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24384 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24383; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24383); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam49, 2, 2, (V[]){v_c_24384, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24354);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam51_clo);
              }
            }
            default: return heff_nomatch(v_x222_24325);
            }
          } else {
            heff_drop(v_x222_24325);
            V v_x1_24396 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24396) == NTAG(TAG_True))) {
              heff_drop(v_x1_24396);
              V v_t_24399;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24399 = ((V)&g_heff_2ebuild_2edev_2eanswer_str120);
                break;
              }
              case TAG_Cons: {
                V v_x_24397 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24398 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24399 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str121); V a_1 = v_x_24397; V a_2 = v_xs_24398; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24398); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24399, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str122)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24401 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str123)));
                V v_t_24402 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str124)));
                V v_t_24403 = (g_std_2epath_2ejoin(v_t_24401, v_t_24402));
                V v_a_24404 = ({ V a_0 = v_st_242; V a_1 = v_t_24403; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24403); r_; });
                V v_t_24405 = (g_std_2epath_2eparse(v_st_242, v_a_24404));
                V v_t_24406 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str125))));
                V v_t_24407 = (g_std_2epath_2ejoin(v_t_24405, v_t_24406));
                V v_s_24408 = ({ V a_0 = v_st_242; V a_1 = v_t_24407; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24407); r_; });
                V v_t_24409 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24408; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24410 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24409; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24409); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam52, 2, 2, (V[]){v_c_24410, v_x21_248});
              } else {
                V v_t_24415 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str127)));
                V v_t_24416 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24417 = (g_std_2epath_2ejoin(v_t_24415, v_t_24416));
                V v_t_24418 = ({ V a_0 = v_st_242; V a_1 = v_t_24417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24417); r_; });
                V v_s_24424 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam54, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24418, v_x22_249));
                V v_t_24425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24424; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24426 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24425; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24425); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam55, 2, 2, (V[]){v_c_24426, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24396);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam57_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edev_2eanswer(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_str1)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_246, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str2))});
  V f_ = v_k_245;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str4), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str5)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str6), v_t_2413}), NTAG(TAG_Nil)});
  V v_t_2415 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2414, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str7))});
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2432 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_str14)}), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str15), v_kind_2432}), v_t_2433});
  V v_t_2436;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nothing: {
    v_t_2436 = ((V)&g_heff_2ebuild_2edev_2eanswer_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2435 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    v_t_2436 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V v_t_2437 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2434, heff_bytesFromString(v_t_2436)});
  V f_ = v_k_2430;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam3, 1, 1, (V[]){v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2458 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str23)); V a_1 = v_x_2457; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2457); r_; });
  V f_ = v_k_2456;
  args[0] = v_x_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_c_2454 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2454;
  args[0] = v_hd_2455;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam5, 1, 2, (V[]){v_x21_248, v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args) {
  V v_p_2463 = args[0];
  V v_x_2464 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = (g_std_2epath_2eparse(v_st_242, v_p_2463));
  V v_t_2466 = (g_std_2epath_2eparse(v_st_242, v_x_2464));
  V v_t_2467 = (g_std_2epath_2ejoin(v_t_2465, v_t_2466));
  return ({ V a_0 = v_st_242; V a_1 = v_t_2467; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2467); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_2472 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_2476 = ((V)&g_heff_2ebuild_2edev_2eanswer_str25);
    break;
  }
  case TAG_Cons: {
    V v_x_2474 = heff_field(v_x22_249, 0);
    V v_xs_2475 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_2476 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str26); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_2477 = ({ V a_0 = v_t_2476; V a_1 = v_x_2473; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2473); r_; });
  V f_ = v_k_2472;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2470;
  args[0] = v_hd_2471;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam8, 1, 2, (V[]){v_x22_249, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  heff_drop(v_hd_2478);
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str27), ((V)&g_heff_2ebuild_2edev_2eanswer_str28)}), NTAG(TAG_Nil)});
  V v_t_2481 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2480, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str29))});
  V f_ = v_k_2479;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  V v_k_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24107 = ({ V a_0 = v_x21_248; V a_1 = v_x_24106; V a_2 = v_x_2495; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24106); heff_drop(v_x_2495); r_; });
  V f_ = v_k_2494;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args) {
  V v_x_2495 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_2493 = heff_env(self)[4];
  V v_k_2494 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2496 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str33)));
  V v_t_2497 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str34)));
  V v_t_2498 = (g_std_2epath_2ejoin(v_t_2496, v_t_2497));
  V v_a_2499 = ({ V a_0 = v_st_242; V a_1 = v_t_2498; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2498); r_; });
  V v_t_24100 = (g_std_2epath_2eparse(v_st_242, v_a_2499));
  V v_t_24101 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str35))));
  V v_t_24102 = (g_std_2epath_2ejoin(v_t_24100, v_t_24101));
  V v_s_24103 = ({ V a_0 = v_st_242; V a_1 = v_t_24102; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24102); r_; });
  V v_t_24104 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24103; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24105 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24104; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24104); r_; });
  V f_ = v_c_24105;
  heff_room[0] = v_hd_2493;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam12, 1, 3, (V[]){v_x21_248, v_x_2495, v_k_2494});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  V v_c_2492 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2492;
  args[0] = heff_dup(v_hd_2493);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam11, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_2493, v_k_2494});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args) {
  V v_x_24127 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24128 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str42)); V a_1 = v_x_24127; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24127); r_; });
  V f_ = v_k_24126;
  args[0] = v_x_24128;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k_24126 = args[1];
  V v_c_24124 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24124;
  args[0] = v_hd_24125;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam14, 1, 2, (V[]){v_x21_248, v_k_24126});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args) {
  V v_p_24133 = args[0];
  V v_x_24134 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24135 = (g_std_2epath_2eparse(v_st_242, v_p_24133));
  V v_t_24136 = (g_std_2epath_2eparse(v_st_242, v_x_24134));
  V v_t_24137 = (g_std_2epath_2ejoin(v_t_24135, v_t_24136));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24137; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24137); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args) {
  V v_x_24143 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24142 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24146;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24146 = ((V)&g_heff_2ebuild_2edev_2eanswer_str44);
    break;
  }
  case TAG_Cons: {
    V v_x_24144 = heff_field(v_x22_249, 0);
    V v_xs_24145 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24146 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str45); V a_1 = v_x_24144; V a_2 = v_xs_24145; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24145); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24147 = ({ V a_0 = v_t_24146; V a_1 = v_x_24143; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24143); r_; });
  V f_ = v_k_24142;
  args[0] = v_x_24147;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args) {
  V v_hd_24141 = args[0];
  V v_k_24142 = args[1];
  V v_c_24140 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24140;
  args[0] = v_hd_24141;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam17, 1, 2, (V[]){v_x22_249, v_k_24142});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args) {
  V v_hd_24148 = args[0];
  V v_k_24149 = args[1];
  heff_drop(v_hd_24148);
  V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str46), ((V)&g_heff_2ebuild_2edev_2eanswer_str47)}), NTAG(TAG_Nil)});
  V v_t_24151 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24150, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str48))});
  V f_ = v_k_24149;
  args[0] = v_t_24151;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args) {
  V v_x_24169 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24168 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24170 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str55)); V a_1 = v_x_24169; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24169); r_; });
  V f_ = v_k_24168;
  args[0] = v_x_24170;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k_24168 = args[1];
  V v_c_24166 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24166;
  args[0] = v_hd_24167;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam20, 1, 2, (V[]){v_x21_248, v_k_24168});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args) {
  V v_p_24175 = args[0];
  V v_x_24176 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24177 = (g_std_2epath_2eparse(v_st_242, v_p_24175));
  V v_t_24178 = (g_std_2epath_2eparse(v_st_242, v_x_24176));
  V v_t_24179 = (g_std_2epath_2ejoin(v_t_24177, v_t_24178));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24179; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24179); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args) {
  V v_x_24185 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24184 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24188;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24188 = ((V)&g_heff_2ebuild_2edev_2eanswer_str57);
    break;
  }
  case TAG_Cons: {
    V v_x_24186 = heff_field(v_x22_249, 0);
    V v_xs_24187 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24188 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str58); V a_1 = v_x_24186; V a_2 = v_xs_24187; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24187); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24189 = ({ V a_0 = v_t_24188; V a_1 = v_x_24185; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24185); r_; });
  V f_ = v_k_24184;
  args[0] = v_x_24189;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args) {
  V v_hd_24183 = args[0];
  V v_k_24184 = args[1];
  V v_c_24182 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24182;
  args[0] = v_hd_24183;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam23, 1, 2, (V[]){v_x22_249, v_k_24184});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args) {
  V v_hd_24190 = args[0];
  V v_k_24191 = args[1];
  heff_drop(v_hd_24190);
  V v_t_24192 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str59), ((V)&g_heff_2ebuild_2edev_2eanswer_str60)}), NTAG(TAG_Nil)});
  V v_t_24193 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24192, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str61))});
  V f_ = v_k_24191;
  args[0] = v_t_24193;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args) {
  V v_x_24203 = args[0];
  V v_k_24202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24204 = ({ V a_0 = v_x_24203; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24203); r_; });
  V f_ = v_k_24202;
  args[0] = v_x_24204;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args) {
  V v_hd_24201 = args[0];
  V v_k_24202 = args[1];
  V v_c_24200 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24200;
  args[0] = v_hd_24201;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam26, 1, 1, (V[]){v_k_24202});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args) {
  V v_x_24231 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24220 = heff_env(self)[1];
  V v_k_24219 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24232 = ({ V a_0 = v_x21_248; V a_1 = v_x_24231; V a_2 = v_x_24220; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24231); heff_drop(v_x_24220); r_; });
  V f_ = v_k_24219;
  args[0] = v_x_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args) {
  V v_x_24220 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24218 = heff_env(self)[4];
  V v_k_24219 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24221 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str68)));
  V v_t_24222 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str69)));
  V v_t_24223 = (g_std_2epath_2ejoin(v_t_24221, v_t_24222));
  V v_a_24224 = ({ V a_0 = v_st_242; V a_1 = v_t_24223; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24223); r_; });
  V v_t_24225 = (g_std_2epath_2eparse(v_st_242, v_a_24224));
  V v_t_24226 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str70))));
  V v_t_24227 = (g_std_2epath_2ejoin(v_t_24225, v_t_24226));
  V v_s_24228 = ({ V a_0 = v_st_242; V a_1 = v_t_24227; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24227); r_; });
  V v_t_24229 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24228; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24230 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24229; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24229); r_; });
  V f_ = v_c_24230;
  heff_room[0] = v_hd_24218;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam29, 1, 3, (V[]){v_x21_248, v_x_24220, v_k_24219});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args) {
  V v_hd_24218 = args[0];
  V v_k_24219 = args[1];
  V v_c_24217 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24217;
  args[0] = heff_dup(v_hd_24218);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam28, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24218, v_k_24219});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args) {
  V v_x_24252 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24251 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24253 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str77)); V a_1 = v_x_24252; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24252); r_; });
  V f_ = v_k_24251;
  args[0] = v_x_24253;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args) {
  V v_hd_24250 = args[0];
  V v_k_24251 = args[1];
  V v_c_24249 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24249;
  args[0] = v_hd_24250;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam31, 1, 2, (V[]){v_x21_248, v_k_24251});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args) {
  V v_p_24258 = args[0];
  V v_x_24259 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24260 = (g_std_2epath_2eparse(v_st_242, v_p_24258));
  V v_t_24261 = (g_std_2epath_2eparse(v_st_242, v_x_24259));
  V v_t_24262 = (g_std_2epath_2ejoin(v_t_24260, v_t_24261));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24262; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24262); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args) {
  V v_x_24268 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24267 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24271;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24271 = ((V)&g_heff_2ebuild_2edev_2eanswer_str79);
    break;
  }
  case TAG_Cons: {
    V v_x_24269 = heff_field(v_x22_249, 0);
    V v_xs_24270 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24271 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str80); V a_1 = v_x_24269; V a_2 = v_xs_24270; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24270); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24272 = ({ V a_0 = v_t_24271; V a_1 = v_x_24268; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24268); r_; });
  V f_ = v_k_24267;
  args[0] = v_x_24272;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args) {
  V v_hd_24266 = args[0];
  V v_k_24267 = args[1];
  V v_c_24265 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24265;
  args[0] = v_hd_24266;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam34, 1, 2, (V[]){v_x22_249, v_k_24267});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args) {
  V v_hd_24273 = args[0];
  V v_k_24274 = args[1];
  heff_drop(v_hd_24273);
  V v_t_24275 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str81), ((V)&g_heff_2ebuild_2edev_2eanswer_str82)}), NTAG(TAG_Nil)});
  V v_t_24276 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24275, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str83))});
  V f_ = v_k_24274;
  args[0] = v_t_24276;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args) {
  V v_x_24294 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24293 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24295 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str90)); V a_1 = v_x_24294; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24294); r_; });
  V f_ = v_k_24293;
  args[0] = v_x_24295;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args) {
  V v_hd_24292 = args[0];
  V v_k_24293 = args[1];
  V v_c_24291 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24291;
  args[0] = v_hd_24292;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam37, 1, 2, (V[]){v_x21_248, v_k_24293});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args) {
  V v_p_24300 = args[0];
  V v_x_24301 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24302 = (g_std_2epath_2eparse(v_st_242, v_p_24300));
  V v_t_24303 = (g_std_2epath_2eparse(v_st_242, v_x_24301));
  V v_t_24304 = (g_std_2epath_2ejoin(v_t_24302, v_t_24303));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24304; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24304); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args) {
  V v_x_24310 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24309 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24313 = ((V)&g_heff_2ebuild_2edev_2eanswer_str92);
    break;
  }
  case TAG_Cons: {
    V v_x_24311 = heff_field(v_x22_249, 0);
    V v_xs_24312 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24313 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str93); V a_1 = v_x_24311; V a_2 = v_xs_24312; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24312); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24314 = ({ V a_0 = v_t_24313; V a_1 = v_x_24310; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24310); r_; });
  V f_ = v_k_24309;
  args[0] = v_x_24314;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args) {
  V v_hd_24308 = args[0];
  V v_k_24309 = args[1];
  V v_c_24307 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24307;
  args[0] = v_hd_24308;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam40, 1, 2, (V[]){v_x22_249, v_k_24309});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args) {
  V v_hd_24315 = args[0];
  V v_k_24316 = args[1];
  heff_drop(v_hd_24315);
  V v_t_24317 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str94), ((V)&g_heff_2ebuild_2edev_2eanswer_str95)}), NTAG(TAG_Nil)});
  V v_t_24318 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24317, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str96))});
  V f_ = v_k_24316;
  args[0] = v_t_24318;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args) {
  V v_hd_24319 = args[0];
  V v_k_24320 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24319);
  V v_t_24321 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str97), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str98)));
  V v_t_24322 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str99), v_t_24321}), NTAG(TAG_Nil)});
  V v_t_24323 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24322, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str100))});
  V f_ = v_k_24320;
  args[0] = v_t_24323;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args) {
  V v_x_24350 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24339 = heff_env(self)[1];
  V v_k_24338 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24351 = ({ V a_0 = v_x21_248; V a_1 = v_x_24350; V a_2 = v_x_24339; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24350); heff_drop(v_x_24339); r_; });
  V f_ = v_k_24338;
  args[0] = v_x_24351;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args) {
  V v_x_24339 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24337 = heff_env(self)[4];
  V v_k_24338 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24340 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str104)));
  V v_t_24341 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str105)));
  V v_t_24342 = (g_std_2epath_2ejoin(v_t_24340, v_t_24341));
  V v_a_24343 = ({ V a_0 = v_st_242; V a_1 = v_t_24342; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24342); r_; });
  V v_t_24344 = (g_std_2epath_2eparse(v_st_242, v_a_24343));
  V v_t_24345 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str106))));
  V v_t_24346 = (g_std_2epath_2ejoin(v_t_24344, v_t_24345));
  V v_s_24347 = ({ V a_0 = v_st_242; V a_1 = v_t_24346; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24346); r_; });
  V v_t_24348 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24347; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24349 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24348; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24348); r_; });
  V f_ = v_c_24349;
  heff_room[0] = v_hd_24337;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam45, 1, 3, (V[]){v_x21_248, v_x_24339, v_k_24338});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args) {
  V v_hd_24337 = args[0];
  V v_k_24338 = args[1];
  V v_c_24336 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24336;
  args[0] = heff_dup(v_hd_24337);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam44, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24337, v_k_24338});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args) {
  V v_x_24371 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24370 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24372 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str113)); V a_1 = v_x_24371; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24371); r_; });
  V f_ = v_k_24370;
  args[0] = v_x_24372;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args) {
  V v_hd_24369 = args[0];
  V v_k_24370 = args[1];
  V v_c_24368 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24368;
  args[0] = v_hd_24369;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam47, 1, 2, (V[]){v_x21_248, v_k_24370});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args) {
  V v_p_24377 = args[0];
  V v_x_24378 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24379 = (g_std_2epath_2eparse(v_st_242, v_p_24377));
  V v_t_24380 = (g_std_2epath_2eparse(v_st_242, v_x_24378));
  V v_t_24381 = (g_std_2epath_2ejoin(v_t_24379, v_t_24380));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24381; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24381); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args) {
  V v_x_24387 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24386 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24390;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24390 = ((V)&g_heff_2ebuild_2edev_2eanswer_str115);
    break;
  }
  case TAG_Cons: {
    V v_x_24388 = heff_field(v_x22_249, 0);
    V v_xs_24389 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24390 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str116); V a_1 = v_x_24388; V a_2 = v_xs_24389; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24389); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24391 = ({ V a_0 = v_t_24390; V a_1 = v_x_24387; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24387); r_; });
  V f_ = v_k_24386;
  args[0] = v_x_24391;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args) {
  V v_hd_24385 = args[0];
  V v_k_24386 = args[1];
  V v_c_24384 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24384;
  args[0] = v_hd_24385;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam50, 1, 2, (V[]){v_x22_249, v_k_24386});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args) {
  V v_hd_24392 = args[0];
  V v_k_24393 = args[1];
  heff_drop(v_hd_24392);
  V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str117), ((V)&g_heff_2ebuild_2edev_2eanswer_str118)}), NTAG(TAG_Nil)});
  V v_t_24395 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24394, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str119))});
  V f_ = v_k_24393;
  args[0] = v_t_24395;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args) {
  V v_x_24413 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24414 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str126)); V a_1 = v_x_24413; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24413); r_; });
  V f_ = v_k_24412;
  args[0] = v_x_24414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args) {
  V v_hd_24411 = args[0];
  V v_k_24412 = args[1];
  V v_c_24410 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24410;
  args[0] = v_hd_24411;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam53, 1, 2, (V[]){v_x21_248, v_k_24412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args) {
  V v_p_24419 = args[0];
  V v_x_24420 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24421 = (g_std_2epath_2eparse(v_st_242, v_p_24419));
  V v_t_24422 = (g_std_2epath_2eparse(v_st_242, v_x_24420));
  V v_t_24423 = (g_std_2epath_2ejoin(v_t_24421, v_t_24422));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24423); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args) {
  V v_x_24429 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24432;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24432 = ((V)&g_heff_2ebuild_2edev_2eanswer_str128);
    break;
  }
  case TAG_Cons: {
    V v_x_24430 = heff_field(v_x22_249, 0);
    V v_xs_24431 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24432 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str129); V a_1 = v_x_24430; V a_2 = v_xs_24431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24431); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24433 = ({ V a_0 = v_t_24432; V a_1 = v_x_24429; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24429); r_; });
  V f_ = v_k_24428;
  args[0] = v_x_24433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args) {
  V v_hd_24427 = args[0];
  V v_k_24428 = args[1];
  V v_c_24426 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24426;
  args[0] = v_hd_24427;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam56, 1, 2, (V[]){v_x22_249, v_k_24428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args) {
  V v_hd_24434 = args[0];
  V v_k_24435 = args[1];
  heff_drop(v_hd_24434);
  V v_t_24436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str130), ((V)&g_heff_2ebuild_2edev_2eanswer_str131)}), NTAG(TAG_Nil)});
  V v_t_24437 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24436, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str132))});
  V f_ = v_k_24435;
  args[0] = v_t_24437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_244 = heff_field(v_ps2_242, 0);
        V v_ps22_245 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_244, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_245)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_245);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Exited: {
      V v_n_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0), heff_intShow(v_n_2411));
      break;
    }
    case TAG_Signalled: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1), heff_intShow(v_n_2412));
      break;
    }
    case TAG_TimedOut: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5)));
    V v_t_2415 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2414);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6), v_t_2415), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s2088512805x623284879(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242));
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_dup(v_to_241), heff_take_field(v_req_242, 1));
  V v_t_246 = (g_list_2ekeepIf_24s2044822566x1809079154(((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str4), heff_take_field(v_req_242, 3)));
  V v_rq_247 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){v_t_245, heff_take_field(v_req_242, 0), v_t_246, heff_get_n(v_req_242, 4, 6), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_249 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_247, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0_clo)})}));
  return (g_co_2eop_24s1876960293x1282655859(v_t_249, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_to_241; V a_1 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str2, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str4, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str9, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry, 8, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(V v_nt_240, V v_rx_241, V v_web_242, V v_nx_243, V v_port_244, V v_proxy_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1, 1, 8, (V[]){v_port_244, v_nt_240, v_nx_243, v_proxy_245, v_rx_241, v_web_242, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5(V self, V *args) {
  V v_p_2320307_2442 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2320307_2442}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2443});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6(V self, V *args) {
  V v_p_2320210_2445 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2320210_2445}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2446});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  heff_drop(v_x_2454);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  heff_drop(v_x_2451);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2425;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2423 = heff_env(self)[4];
  V v_t_2438 = heff_env(self)[5];
  V v_hd_2424 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str6))) {
    v_t_2441 = NTAG(TAG_Windows);
  } else {
    v_t_2441 = NTAG(TAG_Posix);
  }
  V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5, 1, 1, (V[]){v_web_242}), v_t_2441, v_proxy_245}));
  V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6, 1, 1, (V[]){v_nt_240}); V a_1 = v_listener_2423; V a_2 = v_t_2444; V r_ = heff_tr(g_std_2ehttp_2eserver_2eserveConcurrently_24s2134631892x1602276853(a_0, a_1, a_2)); heff_drop(v_listener_2423); r_; });
  V v_t_2448 = (g_green_2eview_24s1017855520x282345245(heff_tag_n(TAG_Main, 1, (V[]){v_t_2447})));
  V v_t_2449 = (g_green_2ego_24s633950905x694375709(v_t_2438, v_x_2439, heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}), v_t_2448));
  V f_ = v_t_2449;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_web_242 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  V v_listener_2423 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_std_2ereactor_2eoutside_24s1108339440x749645818(v_rx_241));
  V f_ = heff_dup(heff_rfield(v_t_2438, 0));
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4, 1, 8, (V[]){v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_t_2438, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2(V self, V *args) {
  V v_listener_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V v_proxy_245 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_web_242 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427;
  switch (heff_tag_of(v_proxy_245)) {
  case TAG_Nothing: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_dup(heff_field(v_proxy_245, 0));
    v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str2), v_x_2426);
    break;
  }
  default: heff_nomatch(v_proxy_245);
  }
  V v_t_2428 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str3), v_t_2427));
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str4), v_t_2428), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str5));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3, 1, 8, (V[]){v_rx_241, v_hd_2424, v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_k_2425})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2458 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2460;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2458;
  heff_room[2] = v_k_2459;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11, 1, 2, (V[]){v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_2485 = args[1];
  V v_k_2486 = args[2];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2484);
  heff_drop(v_hd_2485);
  V f_ = v_k_2486;
  args[0] = v_x_2483;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14(V self, V *args) {
  V v_x_2483 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15, 3, 1, (V[]){v_x_2483});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13(V self, V *args) {
  V v_x_2475 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_2462, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14, 1, 1, (V[]){v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12(V self, V *args) {
  V v_err_2461 = args[0];
  V v_hd_2462 = args[1];
  V v_k_2463 = args[2];
  V v_port_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str7), heff_take_field(v_err_2461, 2));
  V v_t_2465 = heff_strAppend(heff_get_n(v_err_2461, 1, 3), v_t_2464);
  V v_t_2466 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str8), v_t_2465));
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str9), v_t_2466), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str10));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2467, NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_hd_2462), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13, 1, 2, (V[]){v_hd_2462, v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2488;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_246;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_nx_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2417 = (g_prelude_2eparseInt_24cpr(v_port_244));
  V v_t_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2419);
      v_t_2422 = MK_INT(8000LL);
    }
  }
  V v_c_2457 = (g_std_2enet_2ewithListener_24s1426613277x1843796189(heff_dup(v_nt_240), heff_dup(v_nx_243), heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str0), v_t_2422}), MK_INT(64LL), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2, 3, 6, (V[]){v_proxy_245, heff_dup(v_port_244), v_rx_241, v_x_2416, v_web_242, v_nt_240})));
  V v_t_2487 = heff_tr(heff_call(v_nx_243, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10, 2, 1, (V[]){v_c_2457}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12, 3, 1, (V[]){v_port_244})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2487, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}