// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Terminate 62553
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_child 295989558
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_root 10001833
#define LBL_running 1782641667
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_url 325609
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__child[] = {LBL_name, LBL_child};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_running__pages__builds__wanted__port__proxy[] = {LBL_running, LBL_pages, LBL_builds, LBL_wanted, LBL_port, LBL_proxy};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1432398912x140120706(V, V, V, V, V, V);
V g_co_2eop_24s1432398912x140120706_entry(V self, V *a);
extern Clo g_co_2eop_24s1432398912x140120706_clo;
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s237119878x1482184422(V, V, V, V, V);
V g_co_2eop_24s237119878x1482184422_entry(V self, V *a);
extern Clo g_co_2eop_24s237119878x1482184422_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_clo;
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539(V, V, V, V);
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497(V, V, V);
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_clo;
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993(V, V, V);
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_clo;
V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552(V, V, V);
V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s514881809x1990693194(V, V, V, V, V, V);
V g_list_2efilter_24s514881809x1990693194_entry(V self, V *a);
extern Clo g_list_2efilter_24s514881809x1990693194_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str22, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_244), heff_strLength_lent(v_p_240, 0));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2))) {
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str3);
    } else {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2edev_2etypeOf_str4))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str5);
      } else {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
        V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str6))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str7);
        } else {
          int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
          V v_t_2414 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2413), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edev_2etypeOf_str8))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str9);
          } else {
            int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2417 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2edev_2etypeOf_str10))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str11);
            } else {
              int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
              if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str12))) {
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str13);
              } else {
                int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                V v_t_2423 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2422), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
                } else {
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                  V v_t_2426 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2425), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                  } else {
                    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                    V v_t_2429 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2428), heff_strLength_lent(v_p_240, 0));
                    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                    } else {
                      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                      V v_t_2432 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2431), heff_strLength_lent(v_p_240, 0));
                      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2edev_2etypeOf_str20))) {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str21);
                      } else {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str22);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_244 = heff_field(v_ps2_242, 0);
        V v_ps22_245 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_244, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_245)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_245);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str3, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str6, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str7, 3, "-O1");
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry, 4, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str0), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2429;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2424, 1)))) {
    heff_drop_rec(v_x_2424, 2);
    v_t_2429 = NTAG(TAG_Nil);
  } else {
    v_t_2429 = heff_get_n(v_x_2424, 0, 2);
  }
  V f_ = v_k_243;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2425}));
  return (g_co_2eop_24s94900133x232571340(v_t_2426, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5, 1, 2, (V[]){v_x_2424, v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str2), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str3)));
  V v_t_2418 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str4), v_t_2417));
  V v_t_2419 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str5), v_t_2418, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str6), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str7)});
  V v_t_2420 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2422;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_c_2423 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2419; V a_3 = heff_dup(v_x_2416); V a_4 = v_t_2420; V a_5 = v_t_2422; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4, 1, 4, (V[]){v_x_2416, v_prog_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_total_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str1), v_total_2413, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2415, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3, 1, 5, (V[]){v_st_241, v_x_2410, v_prog_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_lam0, 1, 0};
Clo g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_entry, 3, 0};

V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Terminate, 2, (V[]){heff_get_n(v_r_243, 1, 2), ((V)&g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s237119878x1482184422(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str4, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str5, 1, "\012");
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam1, 1, 0};
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_entry, 3, 0};

V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993(V v_st_240, V v_acc_241, V v_a_242) {
top: ;
  V v_t_243 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str0), ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str1)));
  V v_n_244 = heff_dup(heff_rfield(v_a_242, 0));
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_Posix: {
    v_t_245 = v_n_244;
    break;
  }
  case TAG_Windows: {
    v_t_245 = heff_strAppend(v_n_244, ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str2));
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_cmd_246 = (g_std_2epath_2ejoin(v_st_240, v_t_243, v_t_245));
  return heff_clo_n(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam0, 2, 3, (V[]){v_cmd_246, v_a_242, v_acc_241});
}
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V f_ = v_k_248;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_a_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str4), heff_get_n(v_a_242, 0, 2));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str5)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_247, heff_clo_n(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam3, 1, 2, (V[]){v_k_248, v_acc_241})));
  }
  case TAG_Just: {
    V v_child_2426 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_hd_247);
    V v_t_2427 = heff_rec_n(2, shape_name__child, (V[]){heff_get_n(v_a_242, 0, 2), v_child_2426});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_x_2429 = (g_prelude_2e_2b_2b(v_acc_241, v_t_2428));
    V f_ = v_k_248;
    args[0] = v_x_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_cmd_246 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_cmd_246, NTAG(TAG_Nil), ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_str3), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam1_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(v_t_2416, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993_lam2, 1, 4, (V[]){v_a_242, v_hd_247, v_k_248, v_acc_241})));
}
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_entry, 3, 0};

V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497(V v_st_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2edev_2estarted_24s1305088774x1663709993(v_st_240, v_acc_241, heff_dup(v_a_245)));
    return heff_clo_n(g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam1, 2, 3, (V[]){v_c_247, heff_dup(v_st_240), heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_st_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497(a_0, a_1, a_2)); heff_drop(v_st_240); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497_lam2, 1, 4, (V[]){v_st_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_str1, 0, "");
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam2, 1, 0};
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_entry, 4, 0};

V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539(V v_d_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244 = heff_dup(heff_rfield(v_d_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam0_clo)})});
      V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
      V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam1, 1, 3, (V[]){v_d_240, v_p_242, v_p_243})));
    }
    case TAG_Just: {
      V v_c_2425 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop_rec(v_d_240, 6);
      heff_drop(v_p_242);
      return heff_tail(v_p_243, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_c_2425})});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){heff_get_n(v_d_240, 1, 6)});
  }
}
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam2(V self, V *args) {
  V v_s_2418 = args[0];
  return v_s_2418;
}
V g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_take_field(v_d_240, 5);
  V v_t_2415;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_240, 4, 6), v_t_2415});
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2412, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_str0), v_t_2416}), ((V)&g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_str1), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539_lam2_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, v_p_242, v_p_243));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str5, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str6, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str9, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str10, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str12, 1, "c");
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam2, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam4, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_entry, 5, 0};

V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(V v_prog_240, V v_st_241, V v_d_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(v_prog_240, v_st_241, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam0, 1, 4, (V[]){v_d_242, v_hd_243, heff_dup(v_st_241), v_k_244})));
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam2(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam4(V self, V *args) {
  V v_ok_2418 = args[0];
  return v_ok_2418;
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam6(V self, V *args) {
  V v_a_2428 = args[0];
  V v_wanted_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_a_2428, 1)), 0, 3);
  if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str5))) {
    switch (heff_tag_of(v_wanted_2427)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2428, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2433 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2428, 0, 2)}));
      return ({ V a_0 = v_t_2433; V a_1 = v_wanted_2427; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2427, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2427);
    }
  } else {
    heff_drop_rec(v_a_2428, 2);
    heff_drop(v_wanted_2427);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam8(V self, V *args) {
  V v_a_2451 = args[0];
  V v_wanted_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_a_2451, 1)), 0, 3);
  if (heff_strEq_c(v_t_2452, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str12))) {
    switch (heff_tag_of(v_wanted_2450)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2451, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2456 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2451, 0, 2)}));
      return ({ V a_0 = v_t_2456; V a_1 = v_wanted_2450; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2450, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2450);
    }
  } else {
    heff_drop_rec(v_a_2451, 2);
    heff_drop(v_wanted_2450);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2462 = heff_intAdd(heff_take_field(v_d_242, 2), MK_INT(1LL));
  V v_t_2463 = ({ V rv_0 = v_x_2459; V rv_1 = v_x_2461; V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_d_242, 56ULL, 6, shape_running__pages__builds__wanted__port__proxy, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_244;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2460 = ({ V a_0 = v_x_245; V r_ = (g_list_2eany_24s105899861x584770213(a_0)); heff_drop(v_x_245); r_; });
  return ({ V a_0 = heff_dup(v_d_242); V a_1 = v_t_2460; V a_2 = v_hd_243; V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam10, 1, 3, (V[]){v_d_242, v_x_2459, v_k_244}); V r_ = (g_heff_2ebuild_2edev_2epagesFor_24s185284918x850361539(a_0, a_1, a_2, a_3)); heff_drop(v_t_2460); r_; });
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2449);
  V v_wanted_2450 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2457 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam8, 1, 1, (V[]){v_wanted_2450}), heff_dup(v_x_245)));
  V v_c_2458 = ({ V a_0 = v_st_241; V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2457; V r_ = (g_heff_2ebuild_2edev_2estartAll_24s683646470x209949497(a_0, a_1, a_2)); heff_drop(v_st_241); heff_drop(v_t_2457); r_; });
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam9, 1, 4, (V[]){v_x_245, v_d_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_intAdd(heff_dup(heff_rfield(v_d_242, 2)), MK_INT(1LL));
  V v_wanted_2427 = heff_dup(heff_rfield(v_d_242, 3));
  V v_as_2434 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam6, 1, 1, (V[]){v_wanted_2427}), heff_dup(v_x_245)));
  V v_t_2440;
  switch (heff_tag_of(v_as_2434)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str6);
    break;
  }
  case TAG_Cons: {
    V v_x2_2437 = (g_list_2emap_24s2104774589x596860835(v_as_2434));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      v_t_2440 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str8); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    break;
  }
  default: heff_nomatch(v_as_2434);
  }
  V v_t_2441 = heff_strAppend(heff_intShow(v_t_2426), heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str9), v_t_2440));
  V v_str_2442 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str10), v_t_2441);
  V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2442, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str11)), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam7, 1, 5, (V[]){v_d_242, v_x_245, v_st_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str2), ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str3)));
  V v_path_2416 = (g_std_2epath_2ejoin(v_st_241, v_t_2415, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str4)));
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_d_242, 2)), MK_INT(1LL));
  V v_t_2419 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2416, heff_intShow(v_t_2417), ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam4_clo)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam5, 1, 5, (V[]){v_d_242, v_x_245, v_hd_243, v_st_241, v_k_244})));
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_path_247 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str0), ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_str1)));
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam2_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam3, 1, 5, (V[]){v_st_241, v_d_242, v_hd_243, v_x_245, v_k_244})));
}
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2edev_2estopAll_24s781859578x560121552(heff_dup(heff_rfield(v_d_242, 0)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_lam1, 1, 5, (V[]){v_st_241, v_hd_243, v_d_242, v_x_245, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam0, 1, 0};
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_TryWait, 2, (V[]){heff_dup(heff_rfield(v_r_244, 1)), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam0_clo)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam1, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_2415 = (g_prelude_2e_2b_2b(v_acc_240, v_t_2414));
    return (g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(v_t_2415, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_2416 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2417 = heff_get_n(v_ran_2416, 0, 3);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Exited: {
      V v_n_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str0), heff_intShow(v_n_2418));
      break;
    }
    case TAG_Signalled: {
      V v_n_2419 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str1), heff_intShow(v_n_2419));
      break;
    }
    case TAG_TimedOut: {
      v_t_2420 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2420 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str3);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str4), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str5)));
    V v_t_2422 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2421);
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str6), v_t_2422), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_str7));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s1432398912x140120706(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_p_242));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_dup(v_to_241), heff_take_field(v_req_242, 1));
  V v_t_246 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str4), heff_take_field(v_req_242, 3)));
  V v_rq_247 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){v_t_245, heff_take_field(v_req_242, 0), v_t_246, heff_get_n(v_req_242, 4, 6), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_249 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_247, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0_clo)})}));
  return (g_co_2eop_24s162716155x1210144019(v_t_249, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_to_241; V a_1 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}