// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_MakeDirectory 16793
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1938432363x1897732959(V, V, V, V, V, V);
V g_co_2eop_24s1938432363x1897732959_entry(V self, V *a);
extern Clo g_co_2eop_24s1938432363x1897732959_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eplus_24s638448470x237911921_get(void);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo;
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_clo;
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2eisDirectory_24s2052326249x1177764416(V);
V g_std_2efilesystem_2eisDirectory_24s2052326249x1177764416_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisDirectory_24s2052326249x1177764416_clo;
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str22, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_244), heff_strLength_lent(v_p_240, 0));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2))) {
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str3);
    } else {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2edev_2etypeOf_str4))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str5);
      } else {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
        V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str6))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str7);
        } else {
          int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
          V v_t_2414 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2413), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edev_2etypeOf_str8))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str9);
          } else {
            int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2417 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2edev_2etypeOf_str10))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str11);
            } else {
              int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
              if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str12))) {
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str13);
              } else {
                int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                V v_t_2423 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2422), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
                } else {
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                  V v_t_2426 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2425), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                  } else {
                    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                    V v_t_2429 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2428), heff_strLength_lent(v_p_240, 0));
                    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                    } else {
                      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                      V v_t_2432 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2431), heff_strLength_lent(v_p_240, 0));
                      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2edev_2etypeOf_str20))) {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str21);
                      } else {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str22);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str19, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str20, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str21, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str23, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str24, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str26, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str27, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str28, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str29, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str37, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str38, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str42, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str43, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str45, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str46, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str47, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str48, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str50, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str51, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str52, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str53, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str55, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str56, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str58, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str59, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str60, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str61, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str72, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str74, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str75, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str77, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str78, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str79, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str80, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str81, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str82, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str83, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str84, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str85, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str86, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str87, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str88, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str90, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str91, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str92, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str93, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str94, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str95, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str96, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str107, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str108, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str109, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str110, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str111, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str114, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str115, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str116, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str117, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str118, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str119, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str120, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str121, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str122, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str123, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str124, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str126, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str127, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str128, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str129, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str130, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str131, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str132, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam5, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam9, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam12, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam13, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam17, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam21, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam24, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam25, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam29, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam32, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam33, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam36, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam40, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam44, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam47, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam48, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam52, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam55, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam57, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam61, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam65(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam65, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam67(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam66(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam68(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam68_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam68, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam69(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam69, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam71(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam70(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam72(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam73(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam73, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_lam75(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam74(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam76(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam76, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_entry, 4, 0};

V g_heff_2ebuild_2edev_2eanswer(V v_e_240, V v_disk_241, V v_st_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_disk_241);
    return ((V)&g_heff_2ebuild_2edev_2eanswer_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_243, 0);
    V v_x22_249 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str3), 2)) {
      switch (heff_tag_of(v_x22_249)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_disk_241);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam1, 2, 1, (V[]){v_x21_248});
      }
      case TAG_Cons: {
        V v_x221_2416 = heff_dup(heff_field(v_x22_249, 0));
        V v_x222_2417 = heff_dup(heff_field(v_x22_249, 1));
        if (heff_strEq_c_lent(v_x221_2416, ((V)&g_heff_2ebuild_2edev_2eanswer_str8), 2)) {
          heff_drop(v_x221_2416);
          switch (heff_tag_of(v_x222_2417)) {
          case TAG_Nil: {
            heff_drop(v_x21_248);
            heff_drop_tag(v_x22_249, 2);
            heff_drop_cell(v_ru_24x2_243_24Cons, 2);
            V v_t_2419 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str9)));
            V v_t_2420 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str10)));
            V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
            V v_a_2422 = ({ V a_0 = v_st_242; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
            V v_t_2423 = (g_std_2epath_2eparse(v_st_242, v_a_2422));
            V v_t_2424 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str11)));
            V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
            V v_s_2426 = ({ V a_0 = v_st_242; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); r_; });
            V v_path_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2426; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
            V v_t_2430 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2edev_2eanswer_lam2_clo)})}));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam3, 2, 2, (V[]){v_e_240, v_t_2430});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2417, 0ULL, 2);
            V v_x1_2442 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_2442) == NTAG(TAG_True))) {
              heff_drop(v_x1_2442);
              V v_t_2445;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_2445 = ((V)&g_heff_2ebuild_2edev_2eanswer_str17);
                break;
              }
              case TAG_Cons: {
                V v_x_2443 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_2444 = heff_dup(heff_field(v_x22_249, 1));
                v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str18); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_2445, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str19)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_2447 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str20)));
                V v_t_2448 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str21)));
                V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
                V v_a_2450 = ({ V a_0 = v_st_242; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2449); r_; });
                V v_t_2451 = (g_std_2epath_2eparse(v_st_242, v_a_2450));
                V v_t_2452 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str22))));
                V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
                V v_s_2454 = ({ V a_0 = v_st_242; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2453); r_; });
                V v_path_2455 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2454; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_2456 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2455; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2455); r_; });
                V v_t_2458 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2456, ((V)&g_heff_2ebuild_2edev_2eanswer_lam5_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam6, 2, 3, (V[]){v_e_240, v_t_2458, v_x21_248});
              } else {
                V v_t_2463 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str24)));
                V v_t_2464 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_2465 = (g_std_2epath_2ejoin(v_t_2463, v_t_2464));
                V v_t_2466 = ({ V a_0 = v_st_242; V a_1 = v_t_2465; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2465); r_; });
                V v_s_2472 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam8, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_2466, v_x22_249));
                V v_path_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2472; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_2474 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2473; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2473); r_; });
                V v_t_2476 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2474, ((V)&g_heff_2ebuild_2edev_2eanswer_lam9_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam10, 2, 3, (V[]){v_e_240, v_t_2476, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_2442);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam12_clo);
            }
          }
          default: return heff_nomatch(v_x222_2417);
          }
        } else {
          if (heff_strEq_c(v_x221_2416, ((V)&g_heff_2ebuild_2edev_2eanswer_str30))) {
            switch (heff_tag_of(v_x222_2417)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_2489 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str31)));
              V v_t_2490 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_2491 = (g_std_2epath_2ejoin(v_t_2489, v_t_2490));
              V v_a_2492 = ({ V a_0 = v_st_242; V a_1 = v_t_2491; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2491); r_; });
              V v_t_2493 = (g_std_2epath_2eparse(v_st_242, v_a_2492));
              V v_t_2494 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str32)));
              V v_t_2495 = (g_std_2epath_2ejoin(v_t_2493, v_t_2494));
              V v_s_2496 = ({ V a_0 = v_st_242; V a_1 = v_t_2495; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2495); r_; });
              V v_path_2497 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2496; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_2498 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2497; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2497); r_; });
              V v_t_24100 = heff_tr(heff_call(heff_dup(v_disk_241), 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2498, ((V)&g_heff_2ebuild_2edev_2eanswer_lam13_clo)})}));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam14, 2, 5, (V[]){v_e_240, v_t_24100, heff_dup(v_st_242), v_x21_248, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2417, 0ULL, 2);
              V v_x1_24118 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24118) == NTAG(TAG_True))) {
                heff_drop(v_x1_24118);
                V v_t_24121;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24121 = ((V)&g_heff_2ebuild_2edev_2eanswer_str36);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24119 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24120 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24121 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str37); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24121, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str38)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24123 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str39)));
                  V v_t_24124 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str40)));
                  V v_t_24125 = (g_std_2epath_2ejoin(v_t_24123, v_t_24124));
                  V v_a_24126 = ({ V a_0 = v_st_242; V a_1 = v_t_24125; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24125); r_; });
                  V v_t_24127 = (g_std_2epath_2eparse(v_st_242, v_a_24126));
                  V v_t_24128 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str41))));
                  V v_t_24129 = (g_std_2epath_2ejoin(v_t_24127, v_t_24128));
                  V v_s_24130 = ({ V a_0 = v_st_242; V a_1 = v_t_24129; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24129); r_; });
                  V v_path_24131 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24130; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24132 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24131; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24131); r_; });
                  V v_t_24134 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24132, ((V)&g_heff_2ebuild_2edev_2eanswer_lam17_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam18, 2, 3, (V[]){v_e_240, v_t_24134, v_x21_248});
                } else {
                  V v_t_24139 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str43)));
                  V v_t_24140 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24141 = (g_std_2epath_2ejoin(v_t_24139, v_t_24140));
                  V v_t_24142 = ({ V a_0 = v_st_242; V a_1 = v_t_24141; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24141); r_; });
                  V v_s_24148 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam20, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24142, v_x22_249));
                  V v_path_24149 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24148; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24150 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24149; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24149); r_; });
                  V v_t_24152 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24150, ((V)&g_heff_2ebuild_2edev_2eanswer_lam21_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam22, 2, 3, (V[]){v_e_240, v_t_24152, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24118);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam24_clo);
              }
            }
            default: return heff_nomatch(v_x222_2417);
            }
          } else {
            heff_drop(v_x222_2417);
            V v_x1_24164 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24164) == NTAG(TAG_True))) {
              heff_drop(v_x1_24164);
              V v_t_24167;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24167 = ((V)&g_heff_2ebuild_2edev_2eanswer_str49);
                break;
              }
              case TAG_Cons: {
                V v_x_24165 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24166 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24167 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str50); V a_1 = v_x_24165; V a_2 = v_xs_24166; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24166); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24167, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str51)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24169 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str52)));
                V v_t_24170 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str53)));
                V v_t_24171 = (g_std_2epath_2ejoin(v_t_24169, v_t_24170));
                V v_a_24172 = ({ V a_0 = v_st_242; V a_1 = v_t_24171; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24171); r_; });
                V v_t_24173 = (g_std_2epath_2eparse(v_st_242, v_a_24172));
                V v_t_24174 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str54))));
                V v_t_24175 = (g_std_2epath_2ejoin(v_t_24173, v_t_24174));
                V v_s_24176 = ({ V a_0 = v_st_242; V a_1 = v_t_24175; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24175); r_; });
                V v_path_24177 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24176; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24178 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24177; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24177); r_; });
                V v_t_24180 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24178, ((V)&g_heff_2ebuild_2edev_2eanswer_lam25_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam26, 2, 3, (V[]){v_e_240, v_t_24180, v_x21_248});
              } else {
                V v_t_24185 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str56)));
                V v_t_24186 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24187 = (g_std_2epath_2ejoin(v_t_24185, v_t_24186));
                V v_t_24188 = ({ V a_0 = v_st_242; V a_1 = v_t_24187; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24187); r_; });
                V v_s_24194 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam28, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24188, v_x22_249));
                V v_path_24195 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24194; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24196 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24195; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24195); r_; });
                V v_t_24198 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24196, ((V)&g_heff_2ebuild_2edev_2eanswer_lam29_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam30, 2, 3, (V[]){v_e_240, v_t_24198, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24164);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam32_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_249);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str62), 2)) {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_x21_248);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          V v_t_24211 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str63)));
          V v_t_24212 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str64)));
          V v_t_24213 = (g_std_2epath_2ejoin(v_t_24211, v_t_24212));
          V v_s_24214 = ({ V a_0 = v_st_242; V a_1 = v_t_24213; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24213); r_; });
          V v_path_24215 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24214; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_24216 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24215; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24215); r_; });
          V v_t_24218 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_24216, ((V)&g_heff_2ebuild_2edev_2eanswer_lam33_clo)})}));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam34, 2, 2, (V[]){v_e_240, v_t_24218});
        }
        case TAG_Cons: {
          V v_x221_24223 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24224 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24223, ((V)&g_heff_2ebuild_2edev_2eanswer_str65))) {
            switch (heff_tag_of(v_x222_24224)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24226 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str66)));
              V v_t_24227 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24228 = (g_std_2epath_2ejoin(v_t_24226, v_t_24227));
              V v_a_24229 = ({ V a_0 = v_st_242; V a_1 = v_t_24228; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24228); r_; });
              V v_t_24230 = (g_std_2epath_2eparse(v_st_242, v_a_24229));
              V v_t_24231 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str67)));
              V v_t_24232 = (g_std_2epath_2ejoin(v_t_24230, v_t_24231));
              V v_s_24233 = ({ V a_0 = v_st_242; V a_1 = v_t_24232; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24232); r_; });
              V v_path_24234 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24233; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_24235 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24234; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24234); r_; });
              V v_t_24237 = heff_tr(heff_call(heff_dup(v_disk_241), 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24235, ((V)&g_heff_2ebuild_2edev_2eanswer_lam36_clo)})}));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam37, 2, 5, (V[]){v_e_240, v_t_24237, heff_dup(v_st_242), v_x21_248, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24224, 0ULL, 2);
              V v_x1_24255 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24255) == NTAG(TAG_True))) {
                heff_drop(v_x1_24255);
                V v_t_24258;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24258 = ((V)&g_heff_2ebuild_2edev_2eanswer_str71);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24256 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24257 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24258 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str72); V a_1 = v_x_24256; V a_2 = v_xs_24257; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24257); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24258, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str73)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24260 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str74)));
                  V v_t_24261 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str75)));
                  V v_t_24262 = (g_std_2epath_2ejoin(v_t_24260, v_t_24261));
                  V v_a_24263 = ({ V a_0 = v_st_242; V a_1 = v_t_24262; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24262); r_; });
                  V v_t_24264 = (g_std_2epath_2eparse(v_st_242, v_a_24263));
                  V v_t_24265 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str76))));
                  V v_t_24266 = (g_std_2epath_2ejoin(v_t_24264, v_t_24265));
                  V v_s_24267 = ({ V a_0 = v_st_242; V a_1 = v_t_24266; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24266); r_; });
                  V v_path_24268 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24267; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24269 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24268; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24268); r_; });
                  V v_t_24271 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24269, ((V)&g_heff_2ebuild_2edev_2eanswer_lam40_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam41, 2, 3, (V[]){v_e_240, v_t_24271, v_x21_248});
                } else {
                  V v_t_24276 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str78)));
                  V v_t_24277 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24278 = (g_std_2epath_2ejoin(v_t_24276, v_t_24277));
                  V v_t_24279 = ({ V a_0 = v_st_242; V a_1 = v_t_24278; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24278); r_; });
                  V v_s_24285 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam43, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24279, v_x22_249));
                  V v_path_24286 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24285; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24287 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24286; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24286); r_; });
                  V v_t_24289 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24287, ((V)&g_heff_2ebuild_2edev_2eanswer_lam44_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam45, 2, 3, (V[]){v_e_240, v_t_24289, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24255);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam47_clo);
              }
            }
            default: return heff_nomatch(v_x222_24224);
            }
          } else {
            heff_drop(v_x222_24224);
            V v_x1_24301 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24301) == NTAG(TAG_True))) {
              heff_drop(v_x1_24301);
              V v_t_24304;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24304 = ((V)&g_heff_2ebuild_2edev_2eanswer_str84);
                break;
              }
              case TAG_Cons: {
                V v_x_24302 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24303 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24304 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str85); V a_1 = v_x_24302; V a_2 = v_xs_24303; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24303); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24304, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str86)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24306 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str87)));
                V v_t_24307 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str88)));
                V v_t_24308 = (g_std_2epath_2ejoin(v_t_24306, v_t_24307));
                V v_a_24309 = ({ V a_0 = v_st_242; V a_1 = v_t_24308; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24308); r_; });
                V v_t_24310 = (g_std_2epath_2eparse(v_st_242, v_a_24309));
                V v_t_24311 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str89))));
                V v_t_24312 = (g_std_2epath_2ejoin(v_t_24310, v_t_24311));
                V v_s_24313 = ({ V a_0 = v_st_242; V a_1 = v_t_24312; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24312); r_; });
                V v_path_24314 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24313; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24315 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24314; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24314); r_; });
                V v_t_24317 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24315, ((V)&g_heff_2ebuild_2edev_2eanswer_lam48_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam49, 2, 3, (V[]){v_e_240, v_t_24317, v_x21_248});
              } else {
                V v_t_24322 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str91)));
                V v_t_24323 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24324 = (g_std_2epath_2ejoin(v_t_24322, v_t_24323));
                V v_t_24325 = ({ V a_0 = v_st_242; V a_1 = v_t_24324; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24324); r_; });
                V v_s_24331 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam51, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24325, v_x22_249));
                V v_path_24332 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24331; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24333 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24332; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24332); r_; });
                V v_t_24335 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24333, ((V)&g_heff_2ebuild_2edev_2eanswer_lam52_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam53, 2, 3, (V[]){v_e_240, v_t_24335, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24301);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam55_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      } else {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_e_240);
          heff_drop(v_disk_241);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam56, 2, 1, (V[]){v_x21_248});
        }
        case TAG_Cons: {
          V v_x221_24352 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24353 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24352, ((V)&g_heff_2ebuild_2edev_2eanswer_str101))) {
            switch (heff_tag_of(v_x222_24353)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24355 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str102)));
              V v_t_24356 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24357 = (g_std_2epath_2ejoin(v_t_24355, v_t_24356));
              V v_a_24358 = ({ V a_0 = v_st_242; V a_1 = v_t_24357; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24357); r_; });
              V v_t_24359 = (g_std_2epath_2eparse(v_st_242, v_a_24358));
              V v_t_24360 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str103)));
              V v_t_24361 = (g_std_2epath_2ejoin(v_t_24359, v_t_24360));
              V v_s_24362 = ({ V a_0 = v_st_242; V a_1 = v_t_24361; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24361); r_; });
              V v_path_24363 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24362; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_24364 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24363; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24363); r_; });
              V v_t_24366 = heff_tr(heff_call(heff_dup(v_disk_241), 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24364, ((V)&g_heff_2ebuild_2edev_2eanswer_lam57_clo)})}));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam58, 2, 5, (V[]){v_e_240, v_t_24366, heff_dup(v_st_242), v_x21_248, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24353, 0ULL, 2);
              V v_x1_24384 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24384) == NTAG(TAG_True))) {
                heff_drop(v_x1_24384);
                V v_t_24387;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24387 = ((V)&g_heff_2ebuild_2edev_2eanswer_str107);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24385 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24386 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24387 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str108); V a_1 = v_x_24385; V a_2 = v_xs_24386; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24386); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24387, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str109)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24389 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str110)));
                  V v_t_24390 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str111)));
                  V v_t_24391 = (g_std_2epath_2ejoin(v_t_24389, v_t_24390));
                  V v_a_24392 = ({ V a_0 = v_st_242; V a_1 = v_t_24391; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24391); r_; });
                  V v_t_24393 = (g_std_2epath_2eparse(v_st_242, v_a_24392));
                  V v_t_24394 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str112))));
                  V v_t_24395 = (g_std_2epath_2ejoin(v_t_24393, v_t_24394));
                  V v_s_24396 = ({ V a_0 = v_st_242; V a_1 = v_t_24395; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24395); r_; });
                  V v_path_24397 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24396; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24398 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24397; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24397); r_; });
                  V v_t_24400 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24398, ((V)&g_heff_2ebuild_2edev_2eanswer_lam61_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam62, 2, 3, (V[]){v_e_240, v_t_24400, v_x21_248});
                } else {
                  V v_t_24405 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str114)));
                  V v_t_24406 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24407 = (g_std_2epath_2ejoin(v_t_24405, v_t_24406));
                  V v_t_24408 = ({ V a_0 = v_st_242; V a_1 = v_t_24407; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24407); r_; });
                  V v_s_24414 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam64, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24408, v_x22_249));
                  V v_path_24415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24414; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_t_24416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24415); r_; });
                  V v_t_24418 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24416, ((V)&g_heff_2ebuild_2edev_2eanswer_lam65_clo)})}));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam66, 2, 3, (V[]){v_e_240, v_t_24418, v_x22_249});
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24384);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam68_clo);
              }
            }
            default: return heff_nomatch(v_x222_24353);
            }
          } else {
            heff_drop(v_x222_24353);
            V v_x1_24430 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24430) == NTAG(TAG_True))) {
              heff_drop(v_x1_24430);
              V v_t_24433;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24433 = ((V)&g_heff_2ebuild_2edev_2eanswer_str120);
                break;
              }
              case TAG_Cons: {
                V v_x_24431 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24432 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24433 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str121); V a_1 = v_x_24431; V a_2 = v_xs_24432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24432); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24433, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str122)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24435 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str123)));
                V v_t_24436 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str124)));
                V v_t_24437 = (g_std_2epath_2ejoin(v_t_24435, v_t_24436));
                V v_a_24438 = ({ V a_0 = v_st_242; V a_1 = v_t_24437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24437); r_; });
                V v_t_24439 = (g_std_2epath_2eparse(v_st_242, v_a_24438));
                V v_t_24440 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str125))));
                V v_t_24441 = (g_std_2epath_2ejoin(v_t_24439, v_t_24440));
                V v_s_24442 = ({ V a_0 = v_st_242; V a_1 = v_t_24441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24441); r_; });
                V v_path_24443 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24442; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24444 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24443; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24443); r_; });
                V v_t_24446 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24444, ((V)&g_heff_2ebuild_2edev_2eanswer_lam69_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam70, 2, 3, (V[]){v_e_240, v_t_24446, v_x21_248});
              } else {
                V v_t_24451 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str127)));
                V v_t_24452 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24453 = (g_std_2epath_2ejoin(v_t_24451, v_t_24452));
                V v_t_24454 = ({ V a_0 = v_st_242; V a_1 = v_t_24453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24453); r_; });
                V v_s_24460 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam72, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24454, v_x22_249));
                V v_path_24461 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24460; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24462 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24461; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24461); r_; });
                V v_t_24464 = heff_tr(heff_call(v_disk_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24462, ((V)&g_heff_2ebuild_2edev_2eanswer_lam73_clo)})}));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam74, 2, 3, (V[]){v_e_240, v_t_24464, v_x22_249});
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24430);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam76_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edev_2eanswer(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_str1)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_246, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str2))});
  V f_ = v_k_245;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str4), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str5)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str6), v_t_2413}), NTAG(TAG_Nil)});
  V v_t_2415 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2414, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str7))});
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_str14)}), NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str15), v_kind_2434}), v_t_2435});
  V v_t_2438;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Nothing: {
    v_t_2438 = ((V)&g_heff_2ebuild_2edev_2eanswer_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2437 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    v_t_2438 = v_x_2437;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_t_2439 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2436, heff_bytesFromString(v_t_2438)});
  V f_ = v_k_2432;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2430, v_hd_2431, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam4, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args) {
  V v_t_2457 = args[0];
  return v_t_2457;
}
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2462 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str23)); V a_1 = v_x_2461; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2461); r_; });
  V f_ = v_k_2460;
  args[0] = v_x_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_2458 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2458, v_hd_2459, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam7, 1, 2, (V[]){v_x21_248, v_k_2460})));
}
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args) {
  V v_p_2467 = args[0];
  V v_x_2468 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_std_2epath_2eparse(v_st_242, v_p_2467));
  V v_t_2470 = (g_std_2epath_2eparse(v_st_242, v_x_2468));
  V v_t_2471 = (g_std_2epath_2ejoin(v_t_2469, v_t_2470));
  return ({ V a_0 = v_st_242; V a_1 = v_t_2471; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2471); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args) {
  V v_t_2475 = args[0];
  return v_t_2475;
}
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2482;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_2482 = ((V)&g_heff_2ebuild_2edev_2eanswer_str25);
    break;
  }
  case TAG_Cons: {
    V v_x_2480 = heff_field(v_x22_249, 0);
    V v_xs_2481 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_2482 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str26); V a_1 = v_x_2480; V a_2 = v_xs_2481; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2481); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_2483 = ({ V a_0 = v_t_2482; V a_1 = v_x_2479; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2479); r_; });
  V f_ = v_k_2478;
  args[0] = v_x_2483;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_2476 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2476, v_hd_2477, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam11, 1, 2, (V[]){v_x22_249, v_k_2478})));
}
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  heff_drop(v_hd_2484);
  V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str27), ((V)&g_heff_2ebuild_2edev_2eanswer_str28)}), NTAG(TAG_Nil)});
  V v_t_2487 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2486, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str29))});
  V f_ = v_k_2485;
  args[0] = v_t_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args) {
  V v_t_2499 = args[0];
  return v_t_2499;
}
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args) {
  V v_x_24114 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24103 = heff_env(self)[1];
  V v_k_24102 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24115 = ({ V a_0 = v_x21_248; V a_1 = v_x_24114; V a_2 = v_x_24103; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24114); heff_drop(v_x_24103); r_; });
  V f_ = v_k_24102;
  args[0] = v_x_24115;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args) {
  V v_x_24103 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24101 = heff_env(self)[4];
  V v_k_24102 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24104 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str33)));
  V v_t_24105 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str34)));
  V v_t_24106 = (g_std_2epath_2ejoin(v_t_24104, v_t_24105));
  V v_a_24107 = ({ V a_0 = v_st_242; V a_1 = v_t_24106; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24106); r_; });
  V v_t_24108 = (g_std_2epath_2eparse(v_st_242, v_a_24107));
  V v_t_24109 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str35))));
  V v_t_24110 = (g_std_2epath_2ejoin(v_t_24108, v_t_24109));
  V v_s_24111 = ({ V a_0 = v_st_242; V a_1 = v_t_24110; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24110); r_; });
  V v_t_24112 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24111; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24113 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24112; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24112); r_; });
  V f_ = v_c_24113;
  heff_room[0] = v_hd_24101;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam16, 1, 3, (V[]){v_x21_248, v_x_24103, v_k_24102});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args) {
  V v_hd_24101 = args[0];
  V v_k_24102 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24100 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x21_248 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_24100, heff_dup(v_hd_24101), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam15, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24101, v_k_24102})));
}
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args) {
  V v_t_24133 = args[0];
  return v_t_24133;
}
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args) {
  V v_x_24137 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24138 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str42)); V a_1 = v_x_24137; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24137); r_; });
  V f_ = v_k_24136;
  args[0] = v_x_24138;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args) {
  V v_hd_24135 = args[0];
  V v_k_24136 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24134 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24134, v_hd_24135, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam19, 1, 2, (V[]){v_x21_248, v_k_24136})));
}
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args) {
  V v_p_24143 = args[0];
  V v_x_24144 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24145 = (g_std_2epath_2eparse(v_st_242, v_p_24143));
  V v_t_24146 = (g_std_2epath_2eparse(v_st_242, v_x_24144));
  V v_t_24147 = (g_std_2epath_2ejoin(v_t_24145, v_t_24146));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24147; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24147); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args) {
  V v_t_24151 = args[0];
  return v_t_24151;
}
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args) {
  V v_x_24155 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24158;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24158 = ((V)&g_heff_2ebuild_2edev_2eanswer_str44);
    break;
  }
  case TAG_Cons: {
    V v_x_24156 = heff_field(v_x22_249, 0);
    V v_xs_24157 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24158 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str45); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24159 = ({ V a_0 = v_t_24158; V a_1 = v_x_24155; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24155); r_; });
  V f_ = v_k_24154;
  args[0] = v_x_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args) {
  V v_hd_24153 = args[0];
  V v_k_24154 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24152 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24152, v_hd_24153, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam23, 1, 2, (V[]){v_x22_249, v_k_24154})));
}
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args) {
  V v_hd_24160 = args[0];
  V v_k_24161 = args[1];
  heff_drop(v_hd_24160);
  V v_t_24162 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str46), ((V)&g_heff_2ebuild_2edev_2eanswer_str47)}), NTAG(TAG_Nil)});
  V v_t_24163 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24162, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str48))});
  V f_ = v_k_24161;
  args[0] = v_t_24163;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args) {
  V v_t_24179 = args[0];
  return v_t_24179;
}
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args) {
  V v_x_24183 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24184 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str55)); V a_1 = v_x_24183; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24183); r_; });
  V f_ = v_k_24182;
  args[0] = v_x_24184;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k_24182 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24180 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24180, v_hd_24181, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam27, 1, 2, (V[]){v_x21_248, v_k_24182})));
}
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args) {
  V v_p_24189 = args[0];
  V v_x_24190 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24191 = (g_std_2epath_2eparse(v_st_242, v_p_24189));
  V v_t_24192 = (g_std_2epath_2eparse(v_st_242, v_x_24190));
  V v_t_24193 = (g_std_2epath_2ejoin(v_t_24191, v_t_24192));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24193; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24193); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args) {
  V v_t_24197 = args[0];
  return v_t_24197;
}
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args) {
  V v_x_24201 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24200 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24204;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24204 = ((V)&g_heff_2ebuild_2edev_2eanswer_str57);
    break;
  }
  case TAG_Cons: {
    V v_x_24202 = heff_field(v_x22_249, 0);
    V v_xs_24203 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24204 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str58); V a_1 = v_x_24202; V a_2 = v_xs_24203; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24203); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24205 = ({ V a_0 = v_t_24204; V a_1 = v_x_24201; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24201); r_; });
  V f_ = v_k_24200;
  args[0] = v_x_24205;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args) {
  V v_hd_24199 = args[0];
  V v_k_24200 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24198 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24198, v_hd_24199, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam31, 1, 2, (V[]){v_x22_249, v_k_24200})));
}
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args) {
  V v_hd_24206 = args[0];
  V v_k_24207 = args[1];
  heff_drop(v_hd_24206);
  V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str59), ((V)&g_heff_2ebuild_2edev_2eanswer_str60)}), NTAG(TAG_Nil)});
  V v_t_24209 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24208, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str61))});
  V f_ = v_k_24207;
  args[0] = v_t_24209;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args) {
  V v_ns_24217 = args[0];
  return v_ns_24217;
}
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args) {
  V v_x_24221 = args[0];
  V v_k_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24222 = ({ V a_0 = v_x_24221; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24221); r_; });
  V f_ = v_k_24220;
  args[0] = v_x_24222;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args) {
  V v_hd_24219 = args[0];
  V v_k_24220 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24218 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24218, v_hd_24219, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam35, 1, 1, (V[]){v_k_24220})));
}
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args) {
  V v_t_24236 = args[0];
  return v_t_24236;
}
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args) {
  V v_x_24251 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24240 = heff_env(self)[1];
  V v_k_24239 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24252 = ({ V a_0 = v_x21_248; V a_1 = v_x_24251; V a_2 = v_x_24240; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24251); heff_drop(v_x_24240); r_; });
  V f_ = v_k_24239;
  args[0] = v_x_24252;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args) {
  V v_x_24240 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24238 = heff_env(self)[4];
  V v_k_24239 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24241 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str68)));
  V v_t_24242 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str69)));
  V v_t_24243 = (g_std_2epath_2ejoin(v_t_24241, v_t_24242));
  V v_a_24244 = ({ V a_0 = v_st_242; V a_1 = v_t_24243; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24243); r_; });
  V v_t_24245 = (g_std_2epath_2eparse(v_st_242, v_a_24244));
  V v_t_24246 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str70))));
  V v_t_24247 = (g_std_2epath_2ejoin(v_t_24245, v_t_24246));
  V v_s_24248 = ({ V a_0 = v_st_242; V a_1 = v_t_24247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24247); r_; });
  V v_t_24249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24248; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24250 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24249; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24249); r_; });
  V f_ = v_c_24250;
  heff_room[0] = v_hd_24238;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam39, 1, 3, (V[]){v_x21_248, v_x_24240, v_k_24239});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args) {
  V v_hd_24238 = args[0];
  V v_k_24239 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24237 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x21_248 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_24237, heff_dup(v_hd_24238), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam38, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24238, v_k_24239})));
}
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args) {
  V v_t_24270 = args[0];
  return v_t_24270;
}
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args) {
  V v_x_24274 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24273 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24275 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str77)); V a_1 = v_x_24274; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24274); r_; });
  V f_ = v_k_24273;
  args[0] = v_x_24275;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args) {
  V v_hd_24272 = args[0];
  V v_k_24273 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24271 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24271, v_hd_24272, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam42, 1, 2, (V[]){v_x21_248, v_k_24273})));
}
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args) {
  V v_p_24280 = args[0];
  V v_x_24281 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24282 = (g_std_2epath_2eparse(v_st_242, v_p_24280));
  V v_t_24283 = (g_std_2epath_2eparse(v_st_242, v_x_24281));
  V v_t_24284 = (g_std_2epath_2ejoin(v_t_24282, v_t_24283));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24284; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24284); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args) {
  V v_t_24288 = args[0];
  return v_t_24288;
}
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args) {
  V v_x_24292 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24291 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24295;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24295 = ((V)&g_heff_2ebuild_2edev_2eanswer_str79);
    break;
  }
  case TAG_Cons: {
    V v_x_24293 = heff_field(v_x22_249, 0);
    V v_xs_24294 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24295 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str80); V a_1 = v_x_24293; V a_2 = v_xs_24294; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24294); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24296 = ({ V a_0 = v_t_24295; V a_1 = v_x_24292; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24292); r_; });
  V f_ = v_k_24291;
  args[0] = v_x_24296;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args) {
  V v_hd_24290 = args[0];
  V v_k_24291 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24289 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24289, v_hd_24290, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam46, 1, 2, (V[]){v_x22_249, v_k_24291})));
}
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args) {
  V v_hd_24297 = args[0];
  V v_k_24298 = args[1];
  heff_drop(v_hd_24297);
  V v_t_24299 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str81), ((V)&g_heff_2ebuild_2edev_2eanswer_str82)}), NTAG(TAG_Nil)});
  V v_t_24300 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24299, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str83))});
  V f_ = v_k_24298;
  args[0] = v_t_24300;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args) {
  V v_t_24316 = args[0];
  return v_t_24316;
}
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args) {
  V v_x_24320 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24319 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24321 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str90)); V a_1 = v_x_24320; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24320); r_; });
  V f_ = v_k_24319;
  args[0] = v_x_24321;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args) {
  V v_hd_24318 = args[0];
  V v_k_24319 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24317 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24317, v_hd_24318, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam50, 1, 2, (V[]){v_x21_248, v_k_24319})));
}
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args) {
  V v_p_24326 = args[0];
  V v_x_24327 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24328 = (g_std_2epath_2eparse(v_st_242, v_p_24326));
  V v_t_24329 = (g_std_2epath_2eparse(v_st_242, v_x_24327));
  V v_t_24330 = (g_std_2epath_2ejoin(v_t_24328, v_t_24329));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24330; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24330); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args) {
  V v_t_24334 = args[0];
  return v_t_24334;
}
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args) {
  V v_x_24338 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24337 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24341;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24341 = ((V)&g_heff_2ebuild_2edev_2eanswer_str92);
    break;
  }
  case TAG_Cons: {
    V v_x_24339 = heff_field(v_x22_249, 0);
    V v_xs_24340 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24341 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str93); V a_1 = v_x_24339; V a_2 = v_xs_24340; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24340); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24342 = ({ V a_0 = v_t_24341; V a_1 = v_x_24338; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24338); r_; });
  V f_ = v_k_24337;
  args[0] = v_x_24342;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args) {
  V v_hd_24336 = args[0];
  V v_k_24337 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24335 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24335, v_hd_24336, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam54, 1, 2, (V[]){v_x22_249, v_k_24337})));
}
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args) {
  V v_hd_24343 = args[0];
  V v_k_24344 = args[1];
  heff_drop(v_hd_24343);
  V v_t_24345 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str94), ((V)&g_heff_2ebuild_2edev_2eanswer_str95)}), NTAG(TAG_Nil)});
  V v_t_24346 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24345, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str96))});
  V f_ = v_k_24344;
  args[0] = v_t_24346;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args) {
  V v_hd_24347 = args[0];
  V v_k_24348 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24347);
  V v_t_24349 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str97), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str98)));
  V v_t_24350 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str99), v_t_24349}), NTAG(TAG_Nil)});
  V v_t_24351 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24350, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str100))});
  V f_ = v_k_24348;
  args[0] = v_t_24351;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args) {
  V v_t_24365 = args[0];
  return v_t_24365;
}
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args) {
  V v_x_24380 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24369 = heff_env(self)[1];
  V v_k_24368 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24381 = ({ V a_0 = v_x21_248; V a_1 = v_x_24380; V a_2 = v_x_24369; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24380); heff_drop(v_x_24369); r_; });
  V f_ = v_k_24368;
  args[0] = v_x_24381;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args) {
  V v_x_24369 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24367 = heff_env(self)[4];
  V v_k_24368 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24370 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str104)));
  V v_t_24371 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str105)));
  V v_t_24372 = (g_std_2epath_2ejoin(v_t_24370, v_t_24371));
  V v_a_24373 = ({ V a_0 = v_st_242; V a_1 = v_t_24372; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24372); r_; });
  V v_t_24374 = (g_std_2epath_2eparse(v_st_242, v_a_24373));
  V v_t_24375 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str106))));
  V v_t_24376 = (g_std_2epath_2ejoin(v_t_24374, v_t_24375));
  V v_s_24377 = ({ V a_0 = v_st_242; V a_1 = v_t_24376; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24376); r_; });
  V v_t_24378 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24377; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24379 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24378; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24378); r_; });
  V f_ = v_c_24379;
  heff_room[0] = v_hd_24367;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam60, 1, 3, (V[]){v_x21_248, v_x_24369, v_k_24368});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args) {
  V v_hd_24367 = args[0];
  V v_k_24368 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24366 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x21_248 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_24366, heff_dup(v_hd_24367), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam59, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24367, v_k_24368})));
}
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args) {
  V v_t_24399 = args[0];
  return v_t_24399;
}
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args) {
  V v_x_24403 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24402 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24404 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str113)); V a_1 = v_x_24403; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24403); r_; });
  V f_ = v_k_24402;
  args[0] = v_x_24404;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args) {
  V v_hd_24401 = args[0];
  V v_k_24402 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24400 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24400, v_hd_24401, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam63, 1, 2, (V[]){v_x21_248, v_k_24402})));
}
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args) {
  V v_p_24409 = args[0];
  V v_x_24410 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24411 = (g_std_2epath_2eparse(v_st_242, v_p_24409));
  V v_t_24412 = (g_std_2epath_2eparse(v_st_242, v_x_24410));
  V v_t_24413 = (g_std_2epath_2ejoin(v_t_24411, v_t_24412));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24413); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam65(V self, V *args) {
  V v_t_24417 = args[0];
  return v_t_24417;
}
V g_heff_2ebuild_2edev_2eanswer_lam67(V self, V *args) {
  V v_x_24421 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24424;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24424 = ((V)&g_heff_2ebuild_2edev_2eanswer_str115);
    break;
  }
  case TAG_Cons: {
    V v_x_24422 = heff_field(v_x22_249, 0);
    V v_xs_24423 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24424 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str116); V a_1 = v_x_24422; V a_2 = v_xs_24423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24423); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24425 = ({ V a_0 = v_t_24424; V a_1 = v_x_24421; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24421); r_; });
  V f_ = v_k_24420;
  args[0] = v_x_24425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam66(V self, V *args) {
  V v_hd_24419 = args[0];
  V v_k_24420 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24418 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24418, v_hd_24419, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam67, 1, 2, (V[]){v_x22_249, v_k_24420})));
}
V g_heff_2ebuild_2edev_2eanswer_lam68(V self, V *args) {
  V v_hd_24426 = args[0];
  V v_k_24427 = args[1];
  heff_drop(v_hd_24426);
  V v_t_24428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str117), ((V)&g_heff_2ebuild_2edev_2eanswer_str118)}), NTAG(TAG_Nil)});
  V v_t_24429 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24428, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str119))});
  V f_ = v_k_24427;
  args[0] = v_t_24429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam69(V self, V *args) {
  V v_t_24445 = args[0];
  return v_t_24445;
}
V g_heff_2ebuild_2edev_2eanswer_lam71(V self, V *args) {
  V v_x_24449 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24450 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str126)); V a_1 = v_x_24449; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24449); r_; });
  V f_ = v_k_24448;
  args[0] = v_x_24450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam70(V self, V *args) {
  V v_hd_24447 = args[0];
  V v_k_24448 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24446 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24446, v_hd_24447, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam71, 1, 2, (V[]){v_x21_248, v_k_24448})));
}
V g_heff_2ebuild_2edev_2eanswer_lam72(V self, V *args) {
  V v_p_24455 = args[0];
  V v_x_24456 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24457 = (g_std_2epath_2eparse(v_st_242, v_p_24455));
  V v_t_24458 = (g_std_2epath_2eparse(v_st_242, v_x_24456));
  V v_t_24459 = (g_std_2epath_2ejoin(v_t_24457, v_t_24458));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24459); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam73(V self, V *args) {
  V v_t_24463 = args[0];
  return v_t_24463;
}
V g_heff_2ebuild_2edev_2eanswer_lam75(V self, V *args) {
  V v_x_24467 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24470;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24470 = ((V)&g_heff_2ebuild_2edev_2eanswer_str128);
    break;
  }
  case TAG_Cons: {
    V v_x_24468 = heff_field(v_x22_249, 0);
    V v_xs_24469 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24470 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str129); V a_1 = v_x_24468; V a_2 = v_xs_24469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24469); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24471 = ({ V a_0 = v_t_24470; V a_1 = v_x_24467; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24467); r_; });
  V f_ = v_k_24466;
  args[0] = v_x_24471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam74(V self, V *args) {
  V v_hd_24465 = args[0];
  V v_k_24466 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_24464 = heff_env(self)[1];
  V v_x22_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24464, v_hd_24465, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam75, 1, 2, (V[]){v_x22_249, v_k_24466})));
}
V g_heff_2ebuild_2edev_2eanswer_lam76(V self, V *args) {
  V v_hd_24472 = args[0];
  V v_k_24473 = args[1];
  heff_drop(v_hd_24472);
  V v_t_24474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str130), ((V)&g_heff_2ebuild_2edev_2eanswer_str131)}), NTAG(TAG_Nil)});
  V v_t_24475 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24474, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str132))});
  V f_ = v_k_24473;
  args[0] = v_t_24475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_244 = heff_field(v_ps2_242, 0);
        V v_ps22_245 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_244, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_245)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_245);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Write, 2, (V[]){heff_dup(heff_rfield(v_r_240, 1)), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0, 1, 3, (V[]){v_r_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_str0), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_r_240, 2, 3), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry, 4, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_dup(heff_rfield(v_x_2411, 0));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_intEq_c(v_n_2416, MK_INT(0LL))) {
      heff_drop_rec(v_x_2411, 3);
      V v_c_2418 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V r_ = (g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(a_0, a_1)); heff_drop(v_st_241); r_; });
      V f_ = v_c_2418;
      heff_room[0] = v_hd_242;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6, 1, 1, (V[]){v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7, 1, 1, (V[]){v_k_243})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8, 1, 1, (V[]){v_k_243})));
  }
  case TAG_TimedOut: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9, 1, 1, (V[]){v_k_243})));
  }
  case TAG_NotRun: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10, 1, 1, (V[]){v_k_243})));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5, 1, 5, (V[]){v_x_2411, v_prog_240, v_st_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str1), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_247), v_x_244, v_t_248, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2, 1, 5, (V[]){v_prog_240, v_x_244, v_hd_242, v_st_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Exited: {
      V v_n_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str0), heff_intShow(v_n_2411));
      break;
    }
    case TAG_Signalled: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str1), heff_intShow(v_n_2412));
      break;
    }
    case TAG_TimedOut: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str3);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str5)));
    V v_t_2415 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2414);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str6), v_t_2415), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str7));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s1938432363x1897732959(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242));
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_clock_241), 1, (V[]){v_t_246}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0, 2, 7, (V[]){v_t_247, v_running_245, heff_dup(v_st_242), heff_dup(v_stamp_244), v_prog_240, v_clock_241, v_d_243});
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    V v_t_2420 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_x_2416; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_x_2416); r_; });
    V f_ = v_t_2420;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_argv_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_x_2411);
    heff_drop(v_hd_248);
    V v_t_2422 = heff_intAdd(heff_take_field(v_d_243, 0), MK_INT(1LL));
    V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_d_243, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_249;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2423, v_argv_2421, v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nil: {
    v_x_2416 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_xs_2415 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    v_x_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  if (heff_strEq_c_lent(v_x_2416, v_stamp_244, 0)) {
    heff_drop(v_x_2416);
    V v_t_2418 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_t_2418;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_stamp_244);
    return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_242; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2416, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_stamp_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = (g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(v_st_242, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3, 1, 8, (V[]){v_stamp_244, v_prog_240, v_clock_241, v_st_242, v_d_243, v_x_2411, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_running_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(NTAG(TAG_Nil), v_running_245, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2, 1, 7, (V[]){v_st_242, v_hd_248, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_running_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1, 1, 8, (V[]){v_running_245, v_hd_248, v_st_242, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str5, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str6, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str9, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str10, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry, 3, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V v_st_240, V v_d_241, V v_apps_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_s_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1, 2, 4, (V[]){v_a_2410, heff_dup(v_st_240), v_d_241, v_apps_242});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5(V self, V *args) {
  V v_a_2442 = args[0];
  V v_wanted_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_a_2442, 1)), 0, 3);
  if (heff_strEq_c(v_t_2443, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str5))) {
    switch (heff_tag_of(v_wanted_2441)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2442, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2447 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2442, 0, 2)}));
      return ({ V a_0 = v_t_2447; V a_1 = v_wanted_2441; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2441, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2441);
    }
  } else {
    heff_drop_rec(v_a_2442, 2);
    heff_drop(v_wanted_2441);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_apps_242 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_intShow(heff_take_field(v_d_241, 0));
  V v_wanted_2441 = heff_get_n(v_d_241, 1, 5);
  V v_argv_2448 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5, 1, 1, (V[]){v_wanted_2441}), v_apps_242));
  V v_t_2454;
  switch (heff_tag_of(v_argv_2448)) {
  case TAG_Nil: {
    v_t_2454 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str6);
    break;
  }
  case TAG_Cons: {
    V v_x2_2451 = (g_list_2emap_24s2104774589x596860835(v_argv_2448));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str8); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    break;
  }
  default: heff_nomatch(v_argv_2448);
  }
  V v_t_2455 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str9), v_t_2454));
  V v_str_2456 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str10), v_t_2455);
  V v_t_2457 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2456, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str11)), NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), v_hd_2411, v_k_2412));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str2)));
  V v_t_2421 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str3)));
  V v_t_2422 = (g_std_2epath_2ejoin(v_t_2420, v_t_2421));
  V v_a_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2424 = (g_std_2epath_2eparse(v_st_240, v_a_2423));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str4)));
  V v_t_2426 = (g_std_2epath_2ejoin(v_t_2424, v_t_2425));
  V v_s_2427 = ({ V a_0 = v_st_240; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2426); r_; });
  V v_path_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2427; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2429 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2428; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2428); r_; });
  V v_t_2430 = heff_intShow(heff_dup(heff_rfield(v_d_241, 0)));
  V v_a_2432 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2429, v_t_2430, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3_clo)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s495635622x733177935(v_t_2438, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4, 1, 4, (V[]){v_d_241, v_apps_242, v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2, 1, 5, (V[]){v_st_240, v_d_241, v_hd_2411, v_apps_242, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str3, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str4, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam12(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry, 8, 0};

V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_running_246, V v_x5_247) {
top: ;
  switch (heff_tag_of(v_x5_247)) {
  case TAG_Nil: {
    heff_drop(v_ex_242);
    return (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(v_prog_240, v_clock_241, v_st_243, v_d_244, v_stamp_245, v_running_246));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x5_247, 0);
    V v_rest_249 = heff_field(v_x5_247, 1);
    heff_take_n(v_x5_247, 3ULL, 2);
    V v_t_2410 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str0)));
    V v_t_2411 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str1)));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_a_2413 = ({ V a_0 = v_st_243; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_n_2414 = heff_dup(heff_rfield(v_a_248, 0));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_243, v_a_2413));
    V v_t_2416;
    switch (heff_tag_of(v_st_243)) {
    case TAG_Posix: {
      v_t_2416 = v_n_2414;
      break;
    }
    case TAG_Windows: {
      v_t_2416 = heff_strAppend(v_n_2414, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str2));
      break;
    }
    default: heff_nomatch(v_st_243);
    }
    V v_t_2417 = (g_std_2epath_2eparse(v_st_243, v_t_2416));
    V v_t_2418 = (g_std_2epath_2ejoin(v_t_2415, v_t_2417));
    V v_program_2419 = ({ V a_0 = v_st_243; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2419, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_c_2446 = (g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(heff_dup(v_ex_242), v_t_2420, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0, 1, 9, (V[]){heff_dup(v_a_248), heff_dup(v_running_246), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_d_244), heff_dup(v_stamp_245), heff_dup(v_rest_249)})));
    V v_t_2467 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6, 2, 1, (V[]){v_c_2446}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8, 3, 9, (V[]){v_a_248, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), v_d_244, heff_dup(v_stamp_245), v_running_246, v_rest_249})})}));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam12, 2, 1, (V[]){v_t_2467});
  }
  default: return heff_nomatch(v_x5_247);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a[0], a[1], a[2], a3, a[4], a5, a[6], a[7]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2440);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2438;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2436;
  args[0] = v_hd_2437;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3, 1, 1, (V[]){v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0(V self, V *args) {
  V v_p_2421 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_running_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_d_244 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2423;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkWith: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2431}));
  V v_t_2433 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_248, 0, 2), v_t_2432});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_running_246, v_t_2434));
  V v_c_2436 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_t_2435; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2, 2, 1, (V[]){v_c_2436});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2447;
  heff_room[2] = v_k_2448;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7, 1, 2, (V[]){v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2465 = args[1];
  V v_k_2466 = args[2];
  V v_x_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2464);
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = v_x_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2452;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam11, 3, 1, (V[]){v_x_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2451 = heff_env(self)[8];
  V v_k_2452 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2461);
  V v_c_2462 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_running_246; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2462;
  heff_room[0] = v_hd_2451;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8(V self, V *args) {
  V v_err_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_a_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_d_244 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_running_246 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_err_2450);
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str3), heff_get_n(v_a_248, 0, 2));
  V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str4)), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_2451), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9, 1, 10, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_d_244, v_stamp_245, v_running_246, v_rest_249, v_hd_2451, v_k_2452})));
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam13(V self, V *args) {
  V v_x_2470 = args[0];
  V v_hd_2468 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2470;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2468;
  heff_room[2] = v_k_2469;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam12(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_t_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s495635622x733177935(v_t_2467, heff_dup(v_hd_2468), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam13, 1, 2, (V[]){v_hd_2468, v_k_2469})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry, 6, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(V v_prog_240, V v_clock_241, V v_ex_242, V v_wanted_243, V v_port_244, V v_proxy_245) {
top: ;
  V v_path_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1, 2, 7, (V[]){v_a_249, heff_dup(v_port_244), v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3(V self, V *args) {
  V v_s_2419 = args[0];
  return v_s_2419;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2410, v_k_2411));
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_2429 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2457 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2429; V a_4 = heff_take_field(v_x_2456, 0); V b_5 = heff_take_field(v_x_2456, 2); V a_6 = heff_get_n(v_x_2456, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_2429); heff_drop(b_5); r_; });
  V f_ = v_t_2457;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7(V self, V *args) {
  V v_x_2454 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_2429 = heff_env(self)[2];
  V v_d_2453 = heff_env(self)[3];
  V v_x_2450 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    V v_c_2455 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = v_st_2429; V a_3 = v_d_2453; V a_4 = v_x_2450; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2450); r_; });
    V f_ = v_c_2455;
    heff_room[0] = heff_dup(v_hd_2410);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam8, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_2429, v_hd_2410, v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_apps_2458 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    V v_t_2459 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2453, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2460 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2429; V a_4 = v_t_2459; V a_5 = v_x_2450; V a_6 = v_apps_2458; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2429); heff_drop(v_x_2450); r_; });
    V f_ = v_t_2460;
    heff_room[0] = v_hd_2410;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_wanted_243 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2429 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Nil: {
    v_x_2450 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2448 = heff_field(v_x_2447, 0);
    V v_xs_2449 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 3ULL, 2);
    v_x_2450 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str4); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2452;
  switch (heff_tag_of(v_port_244)) {
  case TAG_Nothing: {
    v_t_2452 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2451 = heff_field(v_port_244, 0);
    heff_take_n(v_port_244, 1ULL, 1);
    v_t_2452 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_port_244);
  }
  V v_d_2453 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_243, v_t_2452, v_proxy_245, NTAG(TAG_False)});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2429; V a_2 = heff_dup(v_hd_2410); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_2429), v_d_2453, v_x_2450, v_hd_2410, v_ex_242, v_k_2411}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a_0, a_1, a_2, a_3)); heff_drop(v_st_2429); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  V v_port_244 = heff_env(self)[3];
  V v_wanted_243 = heff_env(self)[4];
  V v_proxy_245 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  V v_ex_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_st_2429;
  if (heff_strEq_c(v_x_2427, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str1))) {
    v_st_2429 = NTAG(TAG_Windows);
  } else {
    v_st_2429 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_port_244);
    heff_drop(v_wanted_243);
    heff_drop(v_proxy_245);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_ex_242);
    heff_drop(v_st_2429);
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str2), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5, 1, 2, (V[]){v_hd_2410, v_k_2411})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2418, 0ULL, 1);
    V v_c_2446 = (g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(v_st_2429, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    V f_ = v_c_2446;
    heff_room[0] = heff_dup(v_hd_2410);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6, 1, 9, (V[]){v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_st_2429, v_hd_2410, v_clock_241, v_ex_242, v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  V v_port_244 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s495635622x733177935(v_t_2426, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4, 1, 9, (V[]){v_x_2418, v_hd_2410, v_k_2411, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_a_249 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_wanted_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2, 1, 8, (V[]){v_hd_2410, v_k_2411, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str6, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str14, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str16, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_247 = v_target_244;
    } else {
      v_path_247 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str1); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    HEFF_LAST return g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2eplus_24s638448470x237911921_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0_clo), v_st_241, v_t_249);
  }
  case TAG_Just: {
    V v_to_2417 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2418 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2419 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str3), v_target_2418, MK_INT(0LL), 5);
    V v_path_2421;
    if (heff_intLt_c_lent(v_j_2419, MK_INT(0LL), 2)) {
      heff_drop(v_j_2419);
      v_path_2421 = v_target_2418;
    } else {
      v_path_2421 = heff_strSlice(v_target_2418, MK_INT(0LL), v_j_2419);
    }
    V v_s_2422 = heff_strSlice(heff_dup(v_path_2421), MK_INT(1LL), heff_strLength(v_path_2421));
    V v_x1_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str4); V a_1 = v_s_2422; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str5), v_s_2422, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2422); r_; });
    V v_t_2424 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str6)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 2);
      v_t_2427 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    V v_t_2428 = (g_std_2epath_2eparse(v_st_241, v_t_2427));
    V v_t_2429 = (g_std_2epath_2ejoin(v_t_2424, v_t_2428));
    V v_s_2430 = ({ V a_0 = v_st_241; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2430; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2432 = ({ V a_0 = v_t_2431; V r_ = (g_std_2efilesystem_2eisDirectory_24s2052326249x1177764416(a_0)); heff_drop(v_t_2431); r_; });
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1, 2, 5, (V[]){v_c_2432, v_req_243, heff_dup(v_st_241), v_web_240, v_to_2417});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2448});
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam4(V self, V *args) {
  V v_a_2463 = args[0];
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2469});
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2435) == NTAG(TAG_True))) {
    heff_drop(v_x_2435);
    heff_drop(v_web_240);
    heff_drop(v_to_2417);
    V v_target_2436 = heff_get_n(v_req_243, 1, 6);
    V v_j_2437 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str8), v_target_2436, MK_INT(0LL), 5);
    V v_path_2439;
    if (heff_intLt_c_lent(v_j_2437, MK_INT(0LL), 2)) {
      heff_drop(v_j_2437);
      v_path_2439 = v_target_2436;
    } else {
      v_path_2439 = heff_strSlice(v_target_2436, MK_INT(0LL), v_j_2437);
    }
    V v_s_2440 = heff_strSlice(heff_dup(v_path_2439), MK_INT(1LL), heff_strLength(v_path_2439));
    V v_t_2441 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str9); V a_1 = v_s_2440; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str10), v_s_2440, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2440); r_; });
    V v_t_2449 = ({ V a_0 = heff_dup(g_co_2eplus_24s638448470x237911921_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3_clo); V a_2 = v_st_241; V a_3 = v_t_2441; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2449;
    heff_room[0] = v_hd_2433;
    heff_room[1] = v_k_2434;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2435);
    V v_target_2450 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2451 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str11), v_target_2450, MK_INT(0LL), 5);
    V v_path_2453;
    if (heff_intLt_c_lent(v_j_2451, MK_INT(0LL), 2)) {
      heff_drop(v_j_2451);
      v_path_2453 = v_target_2450;
    } else {
      v_path_2453 = heff_strSlice(v_target_2450, MK_INT(0LL), v_j_2451);
    }
    V v_s_2454 = heff_strSlice(heff_dup(v_path_2453), MK_INT(1LL), heff_strLength(v_path_2453));
    V v_t_2455 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str12); V a_1 = v_s_2454; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str13), v_s_2454, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2454); r_; });
    V v_t_2456 = ({ V a_0 = v_t_2455; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2455); r_; });
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_web_240);
      heff_drop(v_to_2417);
      heff_drop(v_t_2456);
      V v_target_2457 = heff_get_n(v_req_243, 1, 6);
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str14), v_target_2457, MK_INT(0LL), 5);
      V v_path_2460;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_path_2460 = v_target_2457;
      } else {
        v_path_2460 = heff_strSlice(v_target_2457, MK_INT(0LL), v_j_2458);
      }
      V v_s_2461 = heff_strSlice(heff_dup(v_path_2460), MK_INT(1LL), heff_strLength(v_path_2460));
      V v_t_2462 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str15); V a_1 = v_s_2461; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str16), v_s_2461, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2461); r_; });
      V v_t_2470 = ({ V a_0 = heff_dup(g_co_2eplus_24s638448470x237911921_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam4_clo); V a_2 = v_st_241; V a_3 = v_t_2462; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
      V f_ = v_t_2470;
      heff_room[0] = v_hd_2433;
      heff_room[1] = v_k_2434;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2456);
      return (g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(v_web_240, v_to_2417, v_req_243, v_hd_2433, v_k_2434));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_req_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_web_240 = heff_env(self)[3];
  V v_to_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2, 1, 6, (V[]){v_req_243, v_st_241, v_hd_2433, v_k_2434, v_web_240, v_to_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}