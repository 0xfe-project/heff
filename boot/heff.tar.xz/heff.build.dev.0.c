// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_body 9524841
#define LBL_builds 569118448
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_stamp 311115741
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_url 325609
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
V g_co_2eop_24s1179717641x1895974648(V, V, V, V, V, V);
V g_co_2eop_24s1179717641x1895974648_entry(V self, V *a);
extern Clo g_co_2eop_24s1179717641x1895974648_clo;
V g_co_2eop_24s1466765692x81178704(V, V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1466765692x81178704_entry(V self, V *a);
extern Clo g_co_2eop_24s1466765692x81178704_clo;
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo;
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s949882396x1184374908(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s949882396x1184374908_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s949882396x1184374908_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo;
V g_list_2efilter_24s514881809x1990693194(V, V, V, V, V, V);
V g_list_2efilter_24s514881809x1990693194_entry(V self, V *a);
extern Clo g_list_2efilter_24s514881809x1990693194_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str22, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_244), heff_strLength_lent(v_p_240, 0));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2))) {
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str3);
    } else {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2edev_2etypeOf_str4))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str5);
      } else {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
        V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str6))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str7);
        } else {
          int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
          V v_t_2414 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2413), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edev_2etypeOf_str8))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str9);
          } else {
            int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2417 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2edev_2etypeOf_str10))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str11);
            } else {
              int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
              if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str12))) {
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str13);
              } else {
                int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                V v_t_2423 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2422), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
                } else {
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                  V v_t_2426 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2425), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                  } else {
                    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                    V v_t_2429 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2428), heff_strLength_lent(v_p_240, 0));
                    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                    } else {
                      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                      V v_t_2432 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2431), heff_strLength_lent(v_p_240, 0));
                      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2edev_2etypeOf_str20))) {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str21);
                      } else {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str22);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_244 = heff_field(v_ps2_242, 0);
        V v_ps22_245 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_244, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_245)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_245);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str3, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str6, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str7, 3, "-O1");
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry, 4, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str0), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2429;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2424, 1)))) {
    heff_drop_rec(v_x_2424, 2);
    v_t_2429 = NTAG(TAG_Nil);
  } else {
    v_t_2429 = heff_get_n(v_x_2424, 0, 2);
  }
  V f_ = v_k_243;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2425}));
  return (g_co_2eop_24s94900133x232571340(v_t_2426, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam5, 1, 2, (V[]){v_x_2424, v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str2), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str3)));
  V v_t_2418 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str4), v_t_2417));
  V v_t_2419 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str5), v_t_2418, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str6), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str7)});
  V v_t_2420 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2422;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_c_2423 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2419; V a_3 = heff_dup(v_x_2416); V a_4 = v_t_2420; V a_5 = v_t_2422; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam4, 1, 4, (V[]){v_x_2416, v_prog_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_total_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_str1), v_total_2413, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2415, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1187798449x1786315775_lam3, 1, 5, (V[]){v_st_241, v_x_2410, v_prog_240, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Exited: {
      V v_n_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str0), heff_intShow(v_n_2411));
      break;
    }
    case TAG_Signalled: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str1), heff_intShow(v_n_2412));
      break;
    }
    case TAG_TimedOut: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str3);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str5)));
    V v_t_2415 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2414);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str6), v_t_2415), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_str7));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s1179717641x1895974648(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_p_242));
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_clock_241), 1, (V[]){v_t_246}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam0, 2, 7, (V[]){v_t_247, v_running_245, heff_dup(v_st_242), heff_dup(v_stamp_244), v_prog_240, v_clock_241, v_d_243});
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    V v_t_2419 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_x_2415; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_x_2415); r_; });
    V f_ = v_t_2419;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_as_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_x_2411);
    heff_drop(v_hd_248);
    V v_t_2421 = heff_intAdd(heff_take_field(v_d_243, 0), MK_INT(1LL));
    V v_t_2422 = ({ V rv_0 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_d_243, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_249;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2422, v_as_2420, v_x_2415});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nil: {
    v_x_2415 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_xs_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    v_x_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  if (heff_strEq_c_lent(v_x_2415, v_stamp_244, 0)) {
    heff_drop(v_x_2415);
    V v_t_2417 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_t_2417;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_stamp_244);
    return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_242; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam4, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2415, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s949882396x1184374908(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_stamp_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_242; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_248); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam3, 1, 8, (V[]){v_stamp_244, v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_242); r_; });
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_running_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(NTAG(TAG_Nil), v_running_245, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam2, 1, 7, (V[]){v_st_242, v_hd_248, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
V g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_running_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828_lam1, 1, 8, (V[]){v_running_245, v_hd_248, v_st_242, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str3, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str5, 0, "");
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam6, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam8, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam3(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_entry, 7, 0};

V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245, V v_x5_246) {
top: ;
  switch (heff_tag_of(v_x5_246)) {
  case TAG_Nil: {
    return (g_heff_2ebuild_2edev_2ewatched_24s2061049793x130154828(v_prog_240, v_clock_241, v_st_242, v_d_243, v_stamp_244, v_running_245));
  }
  case TAG_Cons: {
    V v_a_247 = heff_field(v_x5_246, 0);
    V v_rest_248 = heff_field(v_x5_246, 1);
    heff_take_n(v_x5_246, 3ULL, 2);
    V v_t_249 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str0), ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str1)));
    V v_n_2410 = heff_dup(heff_rfield(v_a_247, 0));
    V v_t_2411;
    switch (heff_tag_of(v_st_242)) {
    case TAG_Posix: {
      v_t_2411 = v_n_2410;
      break;
    }
    case TAG_Windows: {
      v_t_2411 = heff_strAppend(v_n_2410, ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str2));
      break;
    }
    default: heff_nomatch(v_st_242);
    }
    V v_cmd_2412 = (g_std_2epath_2ejoin(v_st_242, v_t_249, v_t_2411));
    V v_f_2427 = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam0, 1, 8, (V[]){heff_dup(v_a_247), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_st_242), heff_dup(v_d_243), heff_dup(v_stamp_244), heff_dup(v_running_245), heff_dup(v_rest_248)});
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam3, 2, 10, (V[]){v_cmd_2412, v_f_2427, v_a_247, v_running_245, v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, heff_dup(v_stamp_244), v_rest_248});
  }
  default: return heff_nomatch(v_x5_246);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213(a[0], a[1], a2, a[3], a4, a[5], a[6]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_stamp_244 = heff_env(self)[5];
  V v_running_245 = heff_env(self)[6];
  V v_rest_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str3), heff_get_n(v_a_247, 0, 2));
  V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str4)), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_running_245; V a_6 = v_rest_248; V a_7 = heff_dup(v_hd_2415); V a_8 = v_k_2416; V a_9 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}); V a_10 = v_hd_2415; V r_ = (g_co_2eop_24s1466765692x81178704(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_next_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = v_next_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_stamp_244 = heff_env(self)[5];
  V v_running_245 = heff_env(self)[6];
  V v_rest_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_r_2413)) {
  case TAG_Left: {
    heff_take_n(v_r_2413, 0ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam1, 2, 8, (V[]){v_a_247, v_prog_240, v_clock_241, v_st_242, v_d_243, v_stamp_244, v_running_245, v_rest_248});
  }
  case TAG_Right: {
    V v_next_2424 = heff_field(v_r_2413, 0);
    heff_take_n(v_r_2413, 1ULL, 1);
    heff_drop_rec(v_a_247, 2);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_d_243);
    heff_drop(v_stamp_244);
    heff_drop(v_running_245);
    heff_drop(v_rest_248);
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam2, 2, 1, (V[]){v_next_2424});
  }
  default: return heff_nomatch(v_r_2413);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  return v_s_2431;
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam6(V self, V *args) {
  V v_r_2441 = args[0];
  return v_r_2441;
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam8(V self, V *args) {
  V v_r_2454 = args[0];
  return v_r_2454;
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  V v_hd_2428 = heff_env(self)[2];
  V v_k_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2464;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Left: {
    V v_err_2462 = heff_field(v_x_2461, 0);
    V v_ru_24x_2461_24Left = heff_take_reuse_n(v_x_2461, 1ULL, 1);
    heff_drop(v_x_2453);
    v_t_2464 = heff_tag_at_n(v_ru_24x_2461_24Left, TAG_Left, 1, (V[]){v_err_2462});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2461_24Right = heff_take_reuse_n(v_x_2461, 0ULL, 1);
    v_t_2464 = heff_tag_at_n(v_ru_24x_2461_24Right, TAG_Right, 1, (V[]){v_x_2453});
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V f_ = v_f_2427;
  heff_room[0] = v_t_2464;
  heff_room[1] = v_hd_2428;
  heff_room[2] = v_k_2429;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2440 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_f_2427 = heff_env(self)[2];
  V v_k_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2440, ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam8_clo)})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s94900133x232571340(v_t_2460, heff_dup(v_hd_2428), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam9, 1, 4, (V[]){v_x_2453, v_f_2427, v_hd_2428, v_k_2429})));
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_f_2427 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  V v_running_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_st_242 = heff_env(self)[7];
  V v_d_243 = heff_env(self)[8];
  V v_stamp_244 = heff_env(self)[9];
  V v_rest_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    V v_err_2439 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    heff_drop_rec(v_a_247, 2);
    heff_drop(v_running_245);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_d_243);
    heff_drop(v_stamp_244);
    heff_drop(v_rest_248);
    V f_ = v_f_2427;
    heff_room[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2439});
    heff_room[1] = v_hd_2428;
    heff_room[2] = v_k_2429;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_x_2440 = heff_field(v_x_2438, 0);
    V v_ru_24x_2438_24Right = heff_take_reuse_n(v_x_2438, 1ULL, 1);
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2438_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){heff_dup(v_x_2440), ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam6_clo)})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_2447}));
    V v_t_2449 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_247, 0, 2), v_t_2448});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    V v_t_2451 = (g_prelude_2e_2b_2b(v_running_245, v_t_2450));
    V v_c_2452 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_t_2451; V a_6 = v_rest_248; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_c_2452;
    heff_room[0] = heff_dup(v_hd_2428);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam7, 1, 4, (V[]){v_x_2440, v_hd_2428, v_f_2427, v_k_2429});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_cmd_2412 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  V v_running_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_d_243 = heff_env(self)[7];
  V v_stamp_244 = heff_env(self)[8];
  V v_rest_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2430 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_cmd_2412, NTAG(TAG_Nil), ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_str5), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam4_clo)})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s94900133x232571340(v_t_2437, heff_dup(v_hd_2428), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1940043067x773807213_lam5, 1, 11, (V[]){v_f_2427, v_hd_2428, v_k_2429, v_a_247, v_running_245, v_prog_240, v_clock_241, v_st_242, v_d_243, v_stamp_244, v_rest_248})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_dup(v_to_241), heff_take_field(v_req_242, 1));
  V v_t_246 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_str4), heff_take_field(v_req_242, 3)));
  V v_rq_247 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){v_t_245, heff_take_field(v_req_242, 0), v_t_246, heff_get_n(v_req_242, 4, 6), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_249 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_247, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0_clo)})}));
  return (g_co_2eop_24s162716155x1210144019(v_t_249, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_to_241; V a_1 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}