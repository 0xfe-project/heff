// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Main 39920
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_chans 295981947
#define LBL_ended 298010324
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_host 9704047
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_ready 309745085
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_url 325609
#define LBL_waiting 1348170899
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s2088512805x623284879(V, V, V, V, V, V);
V g_co_2eop_24s2088512805x623284879_entry(V self, V *a);
extern Clo g_co_2eop_24s2088512805x623284879_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s633950905x694375709(V, V, V, V);
V g_green_2ego_24s633950905x694375709_entry(V self, V *a);
extern Clo g_green_2ego_24s633950905x694375709_clo;
V g_green_2eview_24s1017855520x282345245(V);
V g_green_2eview_24s1017855520x282345245_entry(V self, V *a);
extern Clo g_green_2eview_24s1017855520x282345245_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2ekeepIf_24s1992606061x1037009925(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1992606061x1037009925_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1992606061x1037009925_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(V);
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_clo;
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1709486662x470486017(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1709486662x470486017_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1709486662x470486017_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2ewithListener_24s1426613277x1843796189(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s1426613277x1843796189_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s1426613277x1843796189_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2ereactor_2eoutside_24s1108339440x749645818(V);
V g_std_2ereactor_2eoutside_24s1108339440x749645818_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s1108339440x749645818_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_243), heff_strLength_lent(v_p_240, 0));
    if ((heff_strEq_c_lent(v_t_244, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2), 2) || ({ int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL)); int c_ = ({ V v_t_2421 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_245), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2ebuild_2edev_2etypeOf_str3), 2); heff_drop(v_t_2421); c_; }); c_; }))) {
      heff_drop(v_t_244);
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str4);
    } else {
      heff_drop(v_t_244);
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_246), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edev_2etypeOf_str5))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str6);
      } else {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
        V v_t_249 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_248), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edev_2etypeOf_str7))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str8);
        } else {
          int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
          V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str9))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str10);
          } else {
            int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2413 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2412), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2edev_2etypeOf_str11))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str12);
            } else {
              int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2415 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2414), heff_strLength_lent(v_p_240, 0));
              if ((heff_strEq_c_lent(v_t_2415, ((V)&g_heff_2ebuild_2edev_2etypeOf_str13), 2) || ({ int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2422 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2422, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14), 2); heff_drop(v_t_2422); c_; }); c_; }))) {
                heff_drop(v_t_2415);
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
              } else {
                heff_drop(v_t_2415);
                int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                V v_t_2418 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2417), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                } else {
                  int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                  V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                  } else {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str20);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str17, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str18, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str19, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str21, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str23, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str24, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str25, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str26, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str27, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str29, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str36, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str37, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str38, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str40, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str42, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str43, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str44, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str45, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str46, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str48, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str49, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str50, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str51, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str52, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str53, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str55, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str56, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str57, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str58, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str59, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str60, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str61, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str71, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str72, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str73, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str74, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str75, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str77, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str78, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str79, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str80, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str81, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str82, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str83, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str84, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str85, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str86, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str87, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str88, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str90, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str91, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str92, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str93, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str94, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str95, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str96, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str107, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str108, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str109, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str110, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str111, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str113, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str114, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str115, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str116, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str117, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str118, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str119, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str120, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str121, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str122, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str123, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str124, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str126, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str127, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str128, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str129, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str130, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str131, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str132, 1, "/");
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam4, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam13, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam19, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam30, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam36, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam46, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam52, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args);
Clo g_heff_2ebuild_2edev_2eanswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_entry, 4, 0};

V g_heff_2ebuild_2edev_2eanswer(V v_e_240, V v_disk_241, V v_st_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_disk_241);
    return ((V)&g_heff_2ebuild_2edev_2eanswer_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_243, 0);
    V v_x22_249 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str3), 2)) {
      switch (heff_tag_of(v_x22_249)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_disk_241);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam1, 2, 1, (V[]){v_x21_248});
      }
      case TAG_Cons: {
        V v_x221_2415 = heff_dup(heff_field(v_x22_249, 0));
        V v_x222_2416 = heff_dup(heff_field(v_x22_249, 1));
        if (heff_strEq_c_lent(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str8), 2)) {
          heff_drop(v_x221_2415);
          switch (heff_tag_of(v_x222_2416)) {
          case TAG_Nil: {
            heff_drop(v_x21_248);
            heff_drop_tag(v_x22_249, 2);
            heff_drop_cell(v_ru_24x2_243_24Cons, 2);
            V v_t_2417 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str9)));
            V v_t_2418 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str10)));
            V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
            V v_a_2420 = ({ V a_0 = v_st_242; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
            V v_t_2421 = (g_std_2epath_2eparse(v_st_242, v_a_2420));
            V v_t_2422 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str11)));
            V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
            V v_s_2424 = ({ V a_0 = v_st_242; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2423); r_; });
            V v_t_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2424; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
            V v_c_2426 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2425; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam2, 2, 1, (V[]){v_c_2426});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2416, 0ULL, 2);
            V v_x1_2438 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if (!(heff_dup(v_x1_2438) == NTAG(TAG_True))) {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_2438);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam4_clo);
            } else {
              heff_drop(v_x1_2438);
              V v_t_2445;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_2445 = ((V)&g_heff_2ebuild_2edev_2eanswer_str20);
                break;
              }
              case TAG_Cons: {
                V v_x_2443 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_2444 = heff_dup(heff_field(v_x22_249, 1));
                v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str21); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_2445, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str22)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_2446 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str23)));
                V v_t_2447 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str24)));
                V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
                V v_a_2449 = ({ V a_0 = v_st_242; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
                V v_t_2450 = (g_std_2epath_2eparse(v_st_242, v_a_2449));
                V v_t_2451 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str25))));
                V v_t_2452 = (g_std_2epath_2ejoin(v_t_2450, v_t_2451));
                V v_s_2453 = ({ V a_0 = v_st_242; V a_1 = v_t_2452; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2452); r_; });
                V v_t_2454 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2453; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_2455 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2454; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam5, 2, 2, (V[]){v_c_2455, v_x21_248});
              } else {
                V v_t_2460 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str27)));
                V v_t_2461 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_2462 = (g_std_2epath_2ejoin(v_t_2460, v_t_2461));
                V v_t_2463 = ({ V a_0 = v_st_242; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2462); r_; });
                V v_s_2469 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam7, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_2463, v_x22_249));
                V v_t_2470 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2469; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_2471 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_2470; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam8, 2, 2, (V[]){v_c_2471, v_x22_249});
              }
            }
          }
          default: return heff_nomatch(v_x222_2416);
          }
        } else {
          if (heff_strEq_c(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str30))) {
            switch (heff_tag_of(v_x222_2416)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_2479 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str31)));
              V v_t_2480 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_2481 = (g_std_2epath_2ejoin(v_t_2479, v_t_2480));
              V v_a_2482 = ({ V a_0 = v_st_242; V a_1 = v_t_2481; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2481); r_; });
              V v_t_2483 = (g_std_2epath_2eparse(v_st_242, v_a_2482));
              V v_t_2484 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str32)));
              V v_t_2485 = (g_std_2epath_2ejoin(v_t_2483, v_t_2484));
              V v_s_2486 = ({ V a_0 = v_st_242; V a_1 = v_t_2485; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2485); r_; });
              V v_t_2487 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2486; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_2488 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_2487; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_2487); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam10, 2, 5, (V[]){v_c_2488, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2416, 0ULL, 2);
              V v_x1_24106 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if (!(heff_dup(v_x1_24106) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24106);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam13_clo);
              } else {
                heff_drop(v_x1_24106);
                V v_t_24113;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24113 = ((V)&g_heff_2ebuild_2edev_2eanswer_str39);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24111 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24112 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24113 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str40); V a_1 = v_x_24111; V a_2 = v_xs_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24112); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24113, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str41)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24114 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str42)));
                  V v_t_24115 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str43)));
                  V v_t_24116 = (g_std_2epath_2ejoin(v_t_24114, v_t_24115));
                  V v_a_24117 = ({ V a_0 = v_st_242; V a_1 = v_t_24116; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24116); r_; });
                  V v_t_24118 = (g_std_2epath_2eparse(v_st_242, v_a_24117));
                  V v_t_24119 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str44))));
                  V v_t_24120 = (g_std_2epath_2ejoin(v_t_24118, v_t_24119));
                  V v_s_24121 = ({ V a_0 = v_st_242; V a_1 = v_t_24120; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24120); r_; });
                  V v_t_24122 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24121; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24123 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24122; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24122); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam14, 2, 2, (V[]){v_c_24123, v_x21_248});
                } else {
                  V v_t_24128 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str46)));
                  V v_t_24129 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24130 = (g_std_2epath_2ejoin(v_t_24128, v_t_24129));
                  V v_t_24131 = ({ V a_0 = v_st_242; V a_1 = v_t_24130; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24130); r_; });
                  V v_s_24137 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam16, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24131, v_x22_249));
                  V v_t_24138 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24137; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24139 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24138; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24138); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam17, 2, 2, (V[]){v_c_24139, v_x22_249});
                }
              }
            }
            default: return heff_nomatch(v_x222_2416);
            }
          } else {
            heff_drop(v_x222_2416);
            V v_x1_24147 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if (!(heff_dup(v_x1_24147) == NTAG(TAG_True))) {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24147);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam19_clo);
            } else {
              heff_drop(v_x1_24147);
              V v_t_24154;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24154 = ((V)&g_heff_2ebuild_2edev_2eanswer_str52);
                break;
              }
              case TAG_Cons: {
                V v_x_24152 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24153 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24154 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str53); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24154, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str54)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24155 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str55)));
                V v_t_24156 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str56)));
                V v_t_24157 = (g_std_2epath_2ejoin(v_t_24155, v_t_24156));
                V v_a_24158 = ({ V a_0 = v_st_242; V a_1 = v_t_24157; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24157); r_; });
                V v_t_24159 = (g_std_2epath_2eparse(v_st_242, v_a_24158));
                V v_t_24160 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str57))));
                V v_t_24161 = (g_std_2epath_2ejoin(v_t_24159, v_t_24160));
                V v_s_24162 = ({ V a_0 = v_st_242; V a_1 = v_t_24161; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24161); r_; });
                V v_t_24163 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24162; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24164 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24163; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24163); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam20, 2, 2, (V[]){v_c_24164, v_x21_248});
              } else {
                V v_t_24169 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str59)));
                V v_t_24170 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24171 = (g_std_2epath_2ejoin(v_t_24169, v_t_24170));
                V v_t_24172 = ({ V a_0 = v_st_242; V a_1 = v_t_24171; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24171); r_; });
                V v_s_24178 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam22, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24172, v_x22_249));
                V v_t_24179 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24178; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24180 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24179; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24179); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam23, 2, 2, (V[]){v_c_24180, v_x22_249});
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_249);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str62), 2)) {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_x21_248);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          V v_t_24188 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str63)));
          V v_t_24189 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str64)));
          V v_t_24190 = (g_std_2epath_2ejoin(v_t_24188, v_t_24189));
          V v_s_24191 = ({ V a_0 = v_st_242; V a_1 = v_t_24190; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24190); r_; });
          V v_t_24192 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24191; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_c_24193 = (g_heff_2eutil_2efiles_2ereadDirectory(v_e_240, v_disk_241, v_t_24192));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam25, 2, 1, (V[]){v_c_24193});
        }
        case TAG_Cons: {
          V v_x221_24198 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24199 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24198, ((V)&g_heff_2ebuild_2edev_2eanswer_str65))) {
            switch (heff_tag_of(v_x222_24199)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24200 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str66)));
              V v_t_24201 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24202 = (g_std_2epath_2ejoin(v_t_24200, v_t_24201));
              V v_a_24203 = ({ V a_0 = v_st_242; V a_1 = v_t_24202; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24202); r_; });
              V v_t_24204 = (g_std_2epath_2eparse(v_st_242, v_a_24203));
              V v_t_24205 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str67)));
              V v_t_24206 = (g_std_2epath_2ejoin(v_t_24204, v_t_24205));
              V v_s_24207 = ({ V a_0 = v_st_242; V a_1 = v_t_24206; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24206); r_; });
              V v_t_24208 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24207; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_24209 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_24208; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24208); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam27, 2, 5, (V[]){v_c_24209, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24199, 0ULL, 2);
              V v_x1_24227 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if (!(heff_dup(v_x1_24227) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24227);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam30_clo);
              } else {
                heff_drop(v_x1_24227);
                V v_t_24234;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24234 = ((V)&g_heff_2ebuild_2edev_2eanswer_str74);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24232 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24233 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24234 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str75); V a_1 = v_x_24232; V a_2 = v_xs_24233; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24233); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24234, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str76)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24235 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str77)));
                  V v_t_24236 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str78)));
                  V v_t_24237 = (g_std_2epath_2ejoin(v_t_24235, v_t_24236));
                  V v_a_24238 = ({ V a_0 = v_st_242; V a_1 = v_t_24237; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24237); r_; });
                  V v_t_24239 = (g_std_2epath_2eparse(v_st_242, v_a_24238));
                  V v_t_24240 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str79))));
                  V v_t_24241 = (g_std_2epath_2ejoin(v_t_24239, v_t_24240));
                  V v_s_24242 = ({ V a_0 = v_st_242; V a_1 = v_t_24241; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24241); r_; });
                  V v_t_24243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24242; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24244 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24243; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24243); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam31, 2, 2, (V[]){v_c_24244, v_x21_248});
                } else {
                  V v_t_24249 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str81)));
                  V v_t_24250 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24251 = (g_std_2epath_2ejoin(v_t_24249, v_t_24250));
                  V v_t_24252 = ({ V a_0 = v_st_242; V a_1 = v_t_24251; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24251); r_; });
                  V v_s_24258 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam33, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24252, v_x22_249));
                  V v_t_24259 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24258; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24260 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24259; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24259); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam34, 2, 2, (V[]){v_c_24260, v_x22_249});
                }
              }
            }
            default: return heff_nomatch(v_x222_24199);
            }
          } else {
            heff_drop(v_x222_24199);
            V v_x1_24268 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if (!(heff_dup(v_x1_24268) == NTAG(TAG_True))) {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24268);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam36_clo);
            } else {
              heff_drop(v_x1_24268);
              V v_t_24275;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24275 = ((V)&g_heff_2ebuild_2edev_2eanswer_str87);
                break;
              }
              case TAG_Cons: {
                V v_x_24273 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24274 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24275 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str88); V a_1 = v_x_24273; V a_2 = v_xs_24274; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24274); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24275, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str89)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24276 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str90)));
                V v_t_24277 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str91)));
                V v_t_24278 = (g_std_2epath_2ejoin(v_t_24276, v_t_24277));
                V v_a_24279 = ({ V a_0 = v_st_242; V a_1 = v_t_24278; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24278); r_; });
                V v_t_24280 = (g_std_2epath_2eparse(v_st_242, v_a_24279));
                V v_t_24281 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str92))));
                V v_t_24282 = (g_std_2epath_2ejoin(v_t_24280, v_t_24281));
                V v_s_24283 = ({ V a_0 = v_st_242; V a_1 = v_t_24282; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24282); r_; });
                V v_t_24284 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24283; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24285 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24284; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24284); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam37, 2, 2, (V[]){v_c_24285, v_x21_248});
              } else {
                V v_t_24290 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str94)));
                V v_t_24291 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24292 = (g_std_2epath_2ejoin(v_t_24290, v_t_24291));
                V v_t_24293 = ({ V a_0 = v_st_242; V a_1 = v_t_24292; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24292); r_; });
                V v_s_24299 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam39, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24293, v_x22_249));
                V v_t_24300 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24299; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24301 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24300; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24300); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam40, 2, 2, (V[]){v_c_24301, v_x22_249});
              }
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      } else {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_e_240);
          heff_drop(v_disk_241);
          heff_drop_cell(v_ru_24x2_243_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam42, 2, 1, (V[]){v_x21_248});
        }
        case TAG_Cons: {
          V v_x221_24314 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24315 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24314, ((V)&g_heff_2ebuild_2edev_2eanswer_str101))) {
            switch (heff_tag_of(v_x222_24315)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              heff_drop_cell(v_ru_24x2_243_24Cons, 2);
              V v_t_24316 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str102)));
              V v_t_24317 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_x21_248)));
              V v_t_24318 = (g_std_2epath_2ejoin(v_t_24316, v_t_24317));
              V v_a_24319 = ({ V a_0 = v_st_242; V a_1 = v_t_24318; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24318); r_; });
              V v_t_24320 = (g_std_2epath_2eparse(v_st_242, v_a_24319));
              V v_t_24321 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str103)));
              V v_t_24322 = (g_std_2epath_2ejoin(v_t_24320, v_t_24321));
              V v_s_24323 = ({ V a_0 = v_st_242; V a_1 = v_t_24322; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24322); r_; });
              V v_t_24324 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24323; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
              V v_c_24325 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_disk_241); V a_2 = v_t_24324; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24324); r_; });
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam43, 2, 5, (V[]){v_c_24325, heff_dup(v_st_242), v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24315, 0ULL, 2);
              V v_x1_24343 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if (!(heff_dup(v_x1_24343) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24343);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam46_clo);
              } else {
                heff_drop(v_x1_24343);
                V v_t_24350;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24350 = ((V)&g_heff_2ebuild_2edev_2eanswer_str110);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24348 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24349 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24350 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str111); V a_1 = v_x_24348; V a_2 = v_xs_24349; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24349); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24350, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str112)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24351 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str113)));
                  V v_t_24352 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str114)));
                  V v_t_24353 = (g_std_2epath_2ejoin(v_t_24351, v_t_24352));
                  V v_a_24354 = ({ V a_0 = v_st_242; V a_1 = v_t_24353; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24353); r_; });
                  V v_t_24355 = (g_std_2epath_2eparse(v_st_242, v_a_24354));
                  V v_t_24356 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str115))));
                  V v_t_24357 = (g_std_2epath_2ejoin(v_t_24355, v_t_24356));
                  V v_s_24358 = ({ V a_0 = v_st_242; V a_1 = v_t_24357; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24357); r_; });
                  V v_t_24359 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24358; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24360 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24359; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24359); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam47, 2, 2, (V[]){v_c_24360, v_x21_248});
                } else {
                  V v_t_24365 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str117)));
                  V v_t_24366 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                  V v_t_24367 = (g_std_2epath_2ejoin(v_t_24365, v_t_24366));
                  V v_t_24368 = ({ V a_0 = v_st_242; V a_1 = v_t_24367; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24367); r_; });
                  V v_s_24374 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam49, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24368, v_x22_249));
                  V v_t_24375 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24374; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                  V v_c_24376 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24375; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24375); r_; });
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam50, 2, 2, (V[]){v_c_24376, v_x22_249});
                }
              }
            }
            default: return heff_nomatch(v_x222_24315);
            }
          } else {
            heff_drop(v_x222_24315);
            V v_x1_24384 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_248), heff_dup(v_x22_249)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if (!(heff_dup(v_x1_24384) == NTAG(TAG_True))) {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              heff_drop(v_x1_24384);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam52_clo);
            } else {
              heff_drop(v_x1_24384);
              V v_t_24391;
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                v_t_24391 = ((V)&g_heff_2ebuild_2edev_2eanswer_str123);
                break;
              }
              case TAG_Cons: {
                V v_x_24389 = heff_dup(heff_field(v_x22_249, 0));
                V v_xs_24390 = heff_dup(heff_field(v_x22_249, 1));
                v_t_24391 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str124); V a_1 = v_x_24389; V a_2 = v_xs_24390; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24390); r_; });
                break;
              }
              default: heff_nomatch(v_x22_249);
              }
              if (heff_strEq_c(v_t_24391, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str125)))) {
                heff_drop_tag(v_x22_249, 2);
                V v_t_24392 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str126)));
                V v_t_24393 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str127)));
                V v_t_24394 = (g_std_2epath_2ejoin(v_t_24392, v_t_24393));
                V v_a_24395 = ({ V a_0 = v_st_242; V a_1 = v_t_24394; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24394); r_; });
                V v_t_24396 = (g_std_2epath_2eparse(v_st_242, v_a_24395));
                V v_t_24397 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str128))));
                V v_t_24398 = (g_std_2epath_2ejoin(v_t_24396, v_t_24397));
                V v_s_24399 = ({ V a_0 = v_st_242; V a_1 = v_t_24398; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24398); r_; });
                V v_t_24400 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24399; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24401 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24400; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24400); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam53, 2, 2, (V[]){v_c_24401, v_x21_248});
              } else {
                V v_t_24406 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str130)));
                V v_t_24407 = (g_std_2epath_2eparse(v_st_242, v_x21_248));
                V v_t_24408 = (g_std_2epath_2ejoin(v_t_24406, v_t_24407));
                V v_t_24409 = ({ V a_0 = v_st_242; V a_1 = v_t_24408; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24408); r_; });
                V v_s_24415 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam55, 2, 1, (V[]){heff_dup(v_st_242)}), v_t_24409, v_x22_249));
                V v_t_24416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24415; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
                V v_c_24417 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24416; V r_ = (g_heff_2eutil_2efiles_2ereadFile(a_0, a_1, a_2)); heff_drop(v_t_24416); r_; });
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam56, 2, 2, (V[]){v_c_24417, v_x22_249});
              }
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edev_2eanswer(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_str1)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_246, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str2))});
  V f_ = v_k_245;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str4), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str5)));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str6), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2413, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str7))});
  V f_ = v_k_2411;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_str14)}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str15), v_kind_2430}), v_t_2431});
  V v_t_2434;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edev_2eanswer_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2435 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2432, heff_bytesFromString(v_t_2434)});
  V f_ = v_k_2428;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam3, 1, 1, (V[]){v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str17), ((V)&g_heff_2ebuild_2edev_2eanswer_str18)}), NTAG(TAG_Nil)});
  V v_t_2442 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2441, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str19))});
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str26)); V a_1 = v_x_2458; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam6, 1, 2, (V[]){v_x21_248, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args) {
  V v_p_2464 = args[0];
  V v_x_2465 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_std_2epath_2eparse(v_st_242, v_p_2464));
  V v_t_2467 = (g_std_2epath_2eparse(v_st_242, v_x_2465));
  V v_t_2468 = (g_std_2epath_2ejoin(v_t_2466, v_t_2467));
  return ({ V a_0 = v_st_242; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2468); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_2477 = ((V)&g_heff_2ebuild_2edev_2eanswer_str28);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_x22_249, 0);
    V v_xs_2476 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_2477 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str29); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_2478 = ({ V a_0 = v_t_2477; V a_1 = v_x_2474; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2474); r_; });
  V f_ = v_k_2473;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam9, 1, 2, (V[]){v_x22_249, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_2491 = heff_env(self)[1];
  V v_k_2490 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24103 = ({ V a_0 = v_x21_248; V a_1 = v_x_24102; V a_2 = v_x_2491; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24102); heff_drop(v_x_2491); r_; });
  V f_ = v_k_2490;
  args[0] = v_x_24103;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args) {
  V v_x_2491 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_2489 = heff_env(self)[4];
  V v_k_2490 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2492 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str33)));
  V v_t_2493 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str34)));
  V v_t_2494 = (g_std_2epath_2ejoin(v_t_2492, v_t_2493));
  V v_a_2495 = ({ V a_0 = v_st_242; V a_1 = v_t_2494; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2494); r_; });
  V v_t_2496 = (g_std_2epath_2eparse(v_st_242, v_a_2495));
  V v_t_2497 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str35))));
  V v_t_2498 = (g_std_2epath_2ejoin(v_t_2496, v_t_2497));
  V v_s_2499 = ({ V a_0 = v_st_242; V a_1 = v_t_2498; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2498); r_; });
  V v_t_24100 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2499; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24101 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24100; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24100); r_; });
  V f_ = v_c_24101;
  heff_room[0] = v_hd_2489;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam12, 1, 3, (V[]){v_x21_248, v_x_2491, v_k_2490});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_c_2488 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2488;
  args[0] = heff_dup(v_hd_2489);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam11, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_2489, v_k_2490});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  heff_drop(v_hd_24107);
  V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str36), ((V)&g_heff_2ebuild_2edev_2eanswer_str37)}), NTAG(TAG_Nil)});
  V v_t_24110 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24109, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str38))});
  V f_ = v_k_24108;
  args[0] = v_t_24110;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24125 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24127 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str45)); V a_1 = v_x_24126; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24126); r_; });
  V f_ = v_k_24125;
  args[0] = v_x_24127;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24123;
  args[0] = v_hd_24124;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam15, 1, 2, (V[]){v_x21_248, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args) {
  V v_p_24132 = args[0];
  V v_x_24133 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24134 = (g_std_2epath_2eparse(v_st_242, v_p_24132));
  V v_t_24135 = (g_std_2epath_2eparse(v_st_242, v_x_24133));
  V v_t_24136 = (g_std_2epath_2ejoin(v_t_24134, v_t_24135));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24136; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24136); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args) {
  V v_x_24142 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24141 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24145;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24145 = ((V)&g_heff_2ebuild_2edev_2eanswer_str47);
    break;
  }
  case TAG_Cons: {
    V v_x_24143 = heff_field(v_x22_249, 0);
    V v_xs_24144 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24145 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str48); V a_1 = v_x_24143; V a_2 = v_xs_24144; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24144); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24146 = ({ V a_0 = v_t_24145; V a_1 = v_x_24142; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24142); r_; });
  V f_ = v_k_24141;
  args[0] = v_x_24146;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args) {
  V v_hd_24140 = args[0];
  V v_k_24141 = args[1];
  V v_c_24139 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24139;
  args[0] = v_hd_24140;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam18, 1, 2, (V[]){v_x22_249, v_k_24141});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args) {
  V v_hd_24148 = args[0];
  V v_k_24149 = args[1];
  heff_drop(v_hd_24148);
  V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str49), ((V)&g_heff_2ebuild_2edev_2eanswer_str50)}), NTAG(TAG_Nil)});
  V v_t_24151 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24150, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str51))});
  V f_ = v_k_24149;
  args[0] = v_t_24151;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args) {
  V v_x_24167 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24166 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24168 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str58)); V a_1 = v_x_24167; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24167); r_; });
  V f_ = v_k_24166;
  args[0] = v_x_24168;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args) {
  V v_hd_24165 = args[0];
  V v_k_24166 = args[1];
  V v_c_24164 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24164;
  args[0] = v_hd_24165;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam21, 1, 2, (V[]){v_x21_248, v_k_24166});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args) {
  V v_p_24173 = args[0];
  V v_x_24174 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24175 = (g_std_2epath_2eparse(v_st_242, v_p_24173));
  V v_t_24176 = (g_std_2epath_2eparse(v_st_242, v_x_24174));
  V v_t_24177 = (g_std_2epath_2ejoin(v_t_24175, v_t_24176));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24177; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24177); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args) {
  V v_x_24183 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24186;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24186 = ((V)&g_heff_2ebuild_2edev_2eanswer_str60);
    break;
  }
  case TAG_Cons: {
    V v_x_24184 = heff_field(v_x22_249, 0);
    V v_xs_24185 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24186 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str61); V a_1 = v_x_24184; V a_2 = v_xs_24185; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24185); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24187 = ({ V a_0 = v_t_24186; V a_1 = v_x_24183; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24183); r_; });
  V f_ = v_k_24182;
  args[0] = v_x_24187;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k_24182 = args[1];
  V v_c_24180 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24180;
  args[0] = v_hd_24181;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam24, 1, 2, (V[]){v_x22_249, v_k_24182});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args) {
  V v_x_24196 = args[0];
  V v_k_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24197 = ({ V a_0 = v_x_24196; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24196); r_; });
  V f_ = v_k_24195;
  args[0] = v_x_24197;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args) {
  V v_hd_24194 = args[0];
  V v_k_24195 = args[1];
  V v_c_24193 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24193;
  args[0] = v_hd_24194;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam26, 1, 1, (V[]){v_k_24195});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args) {
  V v_x_24223 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24212 = heff_env(self)[1];
  V v_k_24211 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24224 = ({ V a_0 = v_x21_248; V a_1 = v_x_24223; V a_2 = v_x_24212; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24223); heff_drop(v_x_24212); r_; });
  V f_ = v_k_24211;
  args[0] = v_x_24224;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args) {
  V v_x_24212 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24210 = heff_env(self)[4];
  V v_k_24211 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24213 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str68)));
  V v_t_24214 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str69)));
  V v_t_24215 = (g_std_2epath_2ejoin(v_t_24213, v_t_24214));
  V v_a_24216 = ({ V a_0 = v_st_242; V a_1 = v_t_24215; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24215); r_; });
  V v_t_24217 = (g_std_2epath_2eparse(v_st_242, v_a_24216));
  V v_t_24218 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str70))));
  V v_t_24219 = (g_std_2epath_2ejoin(v_t_24217, v_t_24218));
  V v_s_24220 = ({ V a_0 = v_st_242; V a_1 = v_t_24219; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24219); r_; });
  V v_t_24221 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24220; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24222 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24221; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24221); r_; });
  V f_ = v_c_24222;
  heff_room[0] = v_hd_24210;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam29, 1, 3, (V[]){v_x21_248, v_x_24212, v_k_24211});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_c_24209 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24209;
  args[0] = heff_dup(v_hd_24210);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam28, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24210, v_k_24211});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args) {
  V v_hd_24228 = args[0];
  V v_k_24229 = args[1];
  heff_drop(v_hd_24228);
  V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str71), ((V)&g_heff_2ebuild_2edev_2eanswer_str72)}), NTAG(TAG_Nil)});
  V v_t_24231 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24230, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str73))});
  V f_ = v_k_24229;
  args[0] = v_t_24231;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args) {
  V v_x_24247 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24248 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str80)); V a_1 = v_x_24247; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24247); r_; });
  V f_ = v_k_24246;
  args[0] = v_x_24248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args) {
  V v_hd_24245 = args[0];
  V v_k_24246 = args[1];
  V v_c_24244 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24244;
  args[0] = v_hd_24245;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam32, 1, 2, (V[]){v_x21_248, v_k_24246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args) {
  V v_p_24253 = args[0];
  V v_x_24254 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24255 = (g_std_2epath_2eparse(v_st_242, v_p_24253));
  V v_t_24256 = (g_std_2epath_2eparse(v_st_242, v_x_24254));
  V v_t_24257 = (g_std_2epath_2ejoin(v_t_24255, v_t_24256));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24257; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24257); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args) {
  V v_x_24263 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24262 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24266;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24266 = ((V)&g_heff_2ebuild_2edev_2eanswer_str82);
    break;
  }
  case TAG_Cons: {
    V v_x_24264 = heff_field(v_x22_249, 0);
    V v_xs_24265 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24266 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str83); V a_1 = v_x_24264; V a_2 = v_xs_24265; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24265); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24267 = ({ V a_0 = v_t_24266; V a_1 = v_x_24263; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24263); r_; });
  V f_ = v_k_24262;
  args[0] = v_x_24267;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args) {
  V v_hd_24261 = args[0];
  V v_k_24262 = args[1];
  V v_c_24260 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24260;
  args[0] = v_hd_24261;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam35, 1, 2, (V[]){v_x22_249, v_k_24262});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args) {
  V v_hd_24269 = args[0];
  V v_k_24270 = args[1];
  heff_drop(v_hd_24269);
  V v_t_24271 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str84), ((V)&g_heff_2ebuild_2edev_2eanswer_str85)}), NTAG(TAG_Nil)});
  V v_t_24272 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24271, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str86))});
  V f_ = v_k_24270;
  args[0] = v_t_24272;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args) {
  V v_x_24288 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24287 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24289 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str93)); V a_1 = v_x_24288; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24288); r_; });
  V f_ = v_k_24287;
  args[0] = v_x_24289;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args) {
  V v_hd_24286 = args[0];
  V v_k_24287 = args[1];
  V v_c_24285 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24285;
  args[0] = v_hd_24286;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam38, 1, 2, (V[]){v_x21_248, v_k_24287});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args) {
  V v_p_24294 = args[0];
  V v_x_24295 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24296 = (g_std_2epath_2eparse(v_st_242, v_p_24294));
  V v_t_24297 = (g_std_2epath_2eparse(v_st_242, v_x_24295));
  V v_t_24298 = (g_std_2epath_2ejoin(v_t_24296, v_t_24297));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24298; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24298); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args) {
  V v_x_24304 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24303 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24307;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24307 = ((V)&g_heff_2ebuild_2edev_2eanswer_str95);
    break;
  }
  case TAG_Cons: {
    V v_x_24305 = heff_field(v_x22_249, 0);
    V v_xs_24306 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24307 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str96); V a_1 = v_x_24305; V a_2 = v_xs_24306; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24306); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24308 = ({ V a_0 = v_t_24307; V a_1 = v_x_24304; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24304); r_; });
  V f_ = v_k_24303;
  args[0] = v_x_24308;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args) {
  V v_hd_24302 = args[0];
  V v_k_24303 = args[1];
  V v_c_24301 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24301;
  args[0] = v_hd_24302;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam41, 1, 2, (V[]){v_x22_249, v_k_24303});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args) {
  V v_hd_24309 = args[0];
  V v_k_24310 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24309);
  V v_t_24311 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str97), heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str98)));
  V v_t_24312 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str99), v_t_24311}), NTAG(TAG_Nil)});
  V v_t_24313 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24312, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str100))});
  V f_ = v_k_24310;
  args[0] = v_t_24313;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args) {
  V v_x_24339 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24328 = heff_env(self)[1];
  V v_k_24327 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24340 = ({ V a_0 = v_x21_248; V a_1 = v_x_24339; V a_2 = v_x_24328; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24339); heff_drop(v_x_24328); r_; });
  V f_ = v_k_24327;
  args[0] = v_x_24340;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args) {
  V v_x_24328 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24326 = heff_env(self)[4];
  V v_k_24327 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24329 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str104)));
  V v_t_24330 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2edev_2eanswer_str105)));
  V v_t_24331 = (g_std_2epath_2ejoin(v_t_24329, v_t_24330));
  V v_a_24332 = ({ V a_0 = v_st_242; V a_1 = v_t_24331; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24331); r_; });
  V v_t_24333 = (g_std_2epath_2eparse(v_st_242, v_a_24332));
  V v_t_24334 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str106))));
  V v_t_24335 = (g_std_2epath_2ejoin(v_t_24333, v_t_24334));
  V v_s_24336 = ({ V a_0 = v_st_242; V a_1 = v_t_24335; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24335); r_; });
  V v_t_24337 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_24336; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24338 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24337; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24337); r_; });
  V f_ = v_c_24338;
  heff_room[0] = v_hd_24326;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam45, 1, 3, (V[]){v_x21_248, v_x_24328, v_k_24327});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args) {
  V v_hd_24326 = args[0];
  V v_k_24327 = args[1];
  V v_c_24325 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24325;
  args[0] = heff_dup(v_hd_24326);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam44, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24326, v_k_24327});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args) {
  V v_hd_24344 = args[0];
  V v_k_24345 = args[1];
  heff_drop(v_hd_24344);
  V v_t_24346 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str107), ((V)&g_heff_2ebuild_2edev_2eanswer_str108)}), NTAG(TAG_Nil)});
  V v_t_24347 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24346, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str109))});
  V f_ = v_k_24345;
  args[0] = v_t_24347;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args) {
  V v_x_24363 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24362 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24364 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str116)); V a_1 = v_x_24363; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24363); r_; });
  V f_ = v_k_24362;
  args[0] = v_x_24364;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args) {
  V v_hd_24361 = args[0];
  V v_k_24362 = args[1];
  V v_c_24360 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24360;
  args[0] = v_hd_24361;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam48, 1, 2, (V[]){v_x21_248, v_k_24362});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args) {
  V v_p_24369 = args[0];
  V v_x_24370 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24371 = (g_std_2epath_2eparse(v_st_242, v_p_24369));
  V v_t_24372 = (g_std_2epath_2eparse(v_st_242, v_x_24370));
  V v_t_24373 = (g_std_2epath_2ejoin(v_t_24371, v_t_24372));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24373; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24373); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args) {
  V v_x_24379 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24378 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24382;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24382 = ((V)&g_heff_2ebuild_2edev_2eanswer_str118);
    break;
  }
  case TAG_Cons: {
    V v_x_24380 = heff_field(v_x22_249, 0);
    V v_xs_24381 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24382 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str119); V a_1 = v_x_24380; V a_2 = v_xs_24381; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24381); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24383 = ({ V a_0 = v_t_24382; V a_1 = v_x_24379; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24379); r_; });
  V f_ = v_k_24378;
  args[0] = v_x_24383;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args) {
  V v_hd_24377 = args[0];
  V v_k_24378 = args[1];
  V v_c_24376 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24376;
  args[0] = v_hd_24377;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam51, 1, 2, (V[]){v_x22_249, v_k_24378});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args) {
  V v_hd_24385 = args[0];
  V v_k_24386 = args[1];
  heff_drop(v_hd_24385);
  V v_t_24387 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str120), ((V)&g_heff_2ebuild_2edev_2eanswer_str121)}), NTAG(TAG_Nil)});
  V v_t_24388 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24387, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str122))});
  V f_ = v_k_24386;
  args[0] = v_t_24388;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args) {
  V v_x_24404 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24403 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24405 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str129)); V a_1 = v_x_24404; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24404); r_; });
  V f_ = v_k_24403;
  args[0] = v_x_24405;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args) {
  V v_hd_24402 = args[0];
  V v_k_24403 = args[1];
  V v_c_24401 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24401;
  args[0] = v_hd_24402;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam54, 1, 2, (V[]){v_x21_248, v_k_24403});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args) {
  V v_p_24410 = args[0];
  V v_x_24411 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24412 = (g_std_2epath_2eparse(v_st_242, v_p_24410));
  V v_t_24413 = (g_std_2epath_2eparse(v_st_242, v_x_24411));
  V v_t_24414 = (g_std_2epath_2ejoin(v_t_24412, v_t_24413));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24414); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args) {
  V v_x_24420 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24423;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24423 = ((V)&g_heff_2ebuild_2edev_2eanswer_str131);
    break;
  }
  case TAG_Cons: {
    V v_x_24421 = heff_field(v_x22_249, 0);
    V v_xs_24422 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24423 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str132); V a_1 = v_x_24421; V a_2 = v_xs_24422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24422); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24424 = ({ V a_0 = v_t_24423; V a_1 = v_x_24420; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24420); r_; });
  V f_ = v_k_24419;
  args[0] = v_x_24424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args) {
  V v_hd_24418 = args[0];
  V v_k_24419 = args[1];
  V v_c_24417 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24417;
  args[0] = v_hd_24418;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam57, 1, 2, (V[]){v_x22_249, v_k_24419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_243 = heff_field(v_ps2_242, 0);
        V v_ps22_244 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_243, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_244)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_244);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Exited: {
      V v_n_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0), heff_intShow(v_n_2411));
      break;
    }
    case TAG_Signalled: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1), heff_intShow(v_n_2412));
      break;
    }
    case TAG_TimedOut: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5)));
    V v_t_2415 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2414);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6), v_t_2415), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s2088512805x623284879(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242));
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_target_245 = heff_take_field(v_req_242, 1);
  V v_method_246 = heff_take_field(v_req_242, 0);
  V v_headers_247 = heff_take_field(v_req_242, 3);
  V v_body_248 = heff_get_n(v_req_242, 4, 6);
  V v_t_249 = (g_list_2ekeepIf_24s1992606061x1037009925(((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_str4), v_headers_247));
  V v_rq_2410 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){heff_strAppend(heff_dup(v_to_241), v_target_245), v_method_246, v_t_249, v_body_248, MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2412 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_2410, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0_clo)})}));
  return (g_co_2eop_24s1876960293x1282655859(v_t_2412, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2414 = ({ V a_0 = v_to_241; V a_1 = v_x_2413; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2413); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str6, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str14, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str16, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_246;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_246 = v_target_244;
    } else {
      v_path_246 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_247 = heff_strSlice(heff_dup(v_path_246), MK_INT(1LL), heff_strLength(v_path_246));
    V v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str1); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str2), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
    HEFF_LAST return g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam0_clo), v_st_241, v_t_248);
  }
  case TAG_Just: {
    V v_to_2416 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2417 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2418 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str3), v_target_2417, MK_INT(0LL), 5);
    V v_path_2419;
    if (heff_intLt_c_lent(v_j_2418, MK_INT(0LL), 2)) {
      heff_drop(v_j_2418);
      v_path_2419 = v_target_2417;
    } else {
      v_path_2419 = heff_strSlice(v_target_2417, MK_INT(0LL), v_j_2418);
    }
    V v_s_2420 = heff_strSlice(heff_dup(v_path_2419), MK_INT(1LL), heff_strLength(v_path_2419));
    V v_x1_2421 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str4); V a_1 = v_s_2420; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str5), v_s_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2420); r_; });
    V v_t_2422 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str6)));
    V v_t_2425;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_t_2425 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2426 = (g_std_2epath_2eparse(v_st_241, v_t_2425));
    V v_t_2427 = (g_std_2epath_2ejoin(v_t_2422, v_t_2426));
    V v_s_2428 = ({ V a_0 = v_st_241; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2427); r_; });
    V v_t_2429 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2428; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2430 = ({ V a_0 = v_t_2429; V r_ = (g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(a_0)); heff_drop(v_t_2429); r_; });
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam1, 2, 5, (V[]){v_c_2430, v_req_243, heff_dup(v_st_241), v_web_240, v_to_2416});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2415});
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam3(V self, V *args) {
  V v_a_2439 = args[0];
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2445});
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam4(V self, V *args) {
  V v_a_2458 = args[0];
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2464});
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2431 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2433) == NTAG(TAG_True))) {
    heff_drop(v_x_2433);
    heff_drop(v_web_240);
    heff_drop(v_to_2416);
    V v_target_2434 = heff_get_n(v_req_243, 1, 6);
    V v_j_2435 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str8), v_target_2434, MK_INT(0LL), 5);
    V v_path_2436;
    if (heff_intLt_c_lent(v_j_2435, MK_INT(0LL), 2)) {
      heff_drop(v_j_2435);
      v_path_2436 = v_target_2434;
    } else {
      v_path_2436 = heff_strSlice(v_target_2434, MK_INT(0LL), v_j_2435);
    }
    V v_s_2437 = heff_strSlice(heff_dup(v_path_2436), MK_INT(1LL), heff_strLength(v_path_2436));
    V v_t_2438 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str9); V a_1 = v_s_2437; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str10), v_s_2437, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2437); r_; });
    V v_t_2446 = ({ V a_0 = heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam3_clo); V a_2 = v_st_241; V a_3 = v_t_2438; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2446;
    heff_room[0] = v_hd_2431;
    heff_room[1] = v_k_2432;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2433);
    V v_target_2447 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2448 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str11), v_target_2447, MK_INT(0LL), 5);
    V v_path_2449;
    if (heff_intLt_c_lent(v_j_2448, MK_INT(0LL), 2)) {
      heff_drop(v_j_2448);
      v_path_2449 = v_target_2447;
    } else {
      v_path_2449 = heff_strSlice(v_target_2447, MK_INT(0LL), v_j_2448);
    }
    V v_s_2450 = heff_strSlice(heff_dup(v_path_2449), MK_INT(1LL), heff_strLength(v_path_2449));
    V v_t_2451 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str12); V a_1 = v_s_2450; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str13), v_s_2450, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2450); r_; });
    V v_t_2452 = ({ V a_0 = v_t_2451; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2451); r_; });
    if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
      heff_drop(v_web_240);
      heff_drop(v_to_2416);
      heff_drop(v_t_2452);
      V v_target_2453 = heff_get_n(v_req_243, 1, 6);
      V v_j_2454 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str14), v_target_2453, MK_INT(0LL), 5);
      V v_path_2455;
      if (heff_intLt_c_lent(v_j_2454, MK_INT(0LL), 2)) {
        heff_drop(v_j_2454);
        v_path_2455 = v_target_2453;
      } else {
        v_path_2455 = heff_strSlice(v_target_2453, MK_INT(0LL), v_j_2454);
      }
      V v_s_2456 = heff_strSlice(heff_dup(v_path_2455), MK_INT(1LL), heff_strLength(v_path_2455));
      V v_t_2457 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str15); V a_1 = v_s_2456; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_str16), v_s_2456, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2456); r_; });
      V v_t_2465 = ({ V a_0 = heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam4_clo); V a_2 = v_st_241; V a_3 = v_t_2457; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
      V f_ = v_t_2465;
      heff_room[0] = v_hd_2431;
      heff_room[1] = v_k_2432;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2452);
      return (g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(v_web_240, v_to_2416, v_req_243, v_hd_2431, v_k_2432));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam1(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_req_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_web_240 = heff_env(self)[3];
  V v_to_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_lam2, 1, 6, (V[]){v_req_243, v_st_241, v_hd_2431, v_k_2432, v_web_240, v_to_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str2, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str4, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str9, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry, 8, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(V v_nt_240, V v_rx_241, V v_web_242, V v_nx_243, V v_port_244, V v_proxy_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2415}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1, 1, 8, (V[]){v_port_244, v_nt_240, v_nx_243, v_proxy_245, v_rx_241, v_web_242, v_hd_246, v_k_247})});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5(V self, V *args) {
  V v_p_2320307_2442 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2320307_2442}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2443});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6(V self, V *args) {
  V v_p_2320210_2445 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2320210_2445}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2446});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  heff_drop(v_x_2454);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  heff_drop(v_x_2451);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam9_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2425;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam8_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2423 = heff_env(self)[4];
  V v_o_2439 = heff_env(self)[5];
  V v_hd_2424 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str6))) {
    v_t_2441 = NTAG(TAG_Windows);
  } else {
    v_t_2441 = NTAG(TAG_Posix);
  }
  V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s1263695797x442991591_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam5, 1, 1, (V[]){v_web_242}), v_t_2441, v_proxy_245}));
  V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam6, 1, 1, (V[]){v_nt_240}); V a_1 = v_listener_2423; V a_2 = v_t_2444; V r_ = heff_tr(g_std_2ehttp_2eserver_2eserveConcurrently_24s1709486662x470486017(a_0, a_1, a_2)); heff_drop(v_listener_2423); r_; });
  V v_t_2448 = (g_green_2eview_24s1017855520x282345245(heff_tag_n(TAG_Main, 1, (V[]){v_t_2447})));
  V v_t_2449 = (g_green_2ego_24s633950905x694375709(v_o_2439, v_x_2440, heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}), v_t_2448));
  V f_ = v_t_2449;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam7, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_web_242 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  V v_listener_2423 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2438);
  V v_o_2439 = (g_std_2ereactor_2eoutside_24s1108339440x749645818(v_rx_241));
  V f_ = heff_dup(heff_rfield(v_o_2439, 0));
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam4, 1, 8, (V[]){v_x_2417, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_o_2439, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2(V self, V *args) {
  V v_listener_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V v_proxy_245 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_web_242 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427;
  switch (heff_tag_of(v_proxy_245)) {
  case TAG_Nothing: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_dup(heff_field(v_proxy_245, 0));
    v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str2), v_x_2426);
    break;
  }
  default: heff_nomatch(v_proxy_245);
  }
  V v_t_2428 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str3), v_t_2427));
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str4), v_t_2428), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str5));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2424, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = heff_dup(heff_rfield(v_hd_2424, 1));
  args[0] = v_t_2437;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam3, 1, 8, (V[]){v_rx_241, v_hd_2424, v_x_2417, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2458 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2460;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2458;
  heff_room[2] = v_k_2459;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam11, 1, 2, (V[]){v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_2490 = args[1];
  V v_k_2491 = args[2];
  V v_x_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2489);
  heff_drop(v_hd_2490);
  V f_ = v_k_2491;
  args[0] = v_x_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14(V self, V *args) {
  V v_x_2488 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam15, 3, 1, (V[]){v_x_2488});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13(V self, V *args) {
  V v_x_2479 = args[0];
  V v_malg_2465 = heff_env(self)[0];
  V v_bind_2464 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(v_malg_2465, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})}));
  V f_ = v_bind_2464;
  heff_room[0] = v_t_2487;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam14, 1, 1, (V[]){v_k_2463});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12(V self, V *args) {
  V v_err_2461 = args[0];
  V v_hd_2462 = args[1];
  V v_k_2463 = args[2];
  V v_port_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2464 = heff_take_field(v_hd_2462, 1);
  V v_malg_2465 = heff_get_n(v_hd_2462, 2, 3);
  V v_name_2466 = heff_take_field(v_err_2461, 1);
  V v_message_2467 = heff_get_n(v_err_2461, 2, 3);
  V v_t_2468 = heff_strAppend(v_name_2466, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str7), v_message_2467));
  V v_t_2469 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str8), v_t_2468));
  V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str9), v_t_2469), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str10));
  V v_t_2471 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2470, NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_malg_2465), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_dup(v_bind_2464);
  args[0] = v_t_2478;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam13, 1, 3, (V[]){v_malg_2465, v_bind_2464, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16(V self, V *args) {
  V v_x_2493 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2493;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_246;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_nx_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2418 = (g_prelude_2eparseInt_24cpr(v_port_244));
  V v_t_2422;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2420;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2420);
      v_t_2422 = MK_INT(8000LL);
    }
  }
  V v_c_2457 = (g_std_2enet_2ewithListener_24s1426613277x1843796189(heff_dup(v_nt_240), heff_dup(v_nx_243), heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_str0), v_t_2422}), MK_INT(64LL), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam2, 3, 6, (V[]){v_proxy_245, heff_dup(v_port_244), v_rx_241, v_x_2417, v_web_242, v_nt_240})));
  V v_t_2492 = heff_tr(heff_call(v_nx_243, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam10, 2, 1, (V[]){v_c_2457}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam12, 3, 1, (V[]){v_port_244})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2492, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1427641292x896087077_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}