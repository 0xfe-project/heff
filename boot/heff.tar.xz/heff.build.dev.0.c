// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Directory 35277
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Main 39920
#define TAG_MkGroup 19195
#define TAG_NotRun 12703
#define TAG_Open 48267
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_RDone 16778
#define TAG_ReadDirectory 46629
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_chans 295981947
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_hmap 9701563
#define LBL_host 9704047
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ready 309745085
#define LBL_ret 322331
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_waiting 1348170899
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s1072496561x430638721(V, V, V);
V g_green_2ego_24s1072496561x430638721_entry(V self, V *a);
extern Clo g_green_2ego_24s1072496561x430638721_clo;
V g_green_2egreenAlg_24s854873557x32656427(V);
V g_green_2egreenAlg_24s854873557x32656427_entry(V self, V *a);
extern Clo g_green_2egreenAlg_24s854873557x32656427_clo;
V g_green_2ethenRes_24s2092633126x465472411(V, V);
V g_green_2ethenRes_24s2092633126x465472411_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s2092633126x465472411_clo;
V g_green_2eview_24s1017855520x282345245(V);
V g_green_2eview_24s1017855520x282345245_entry(V self, V *a);
extern Clo g_green_2eview_24s1017855520x282345245_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825(V);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320(V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_clo;
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814(V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613(V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f577516032x134284914(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f577516032x134284914_entry(V self, V *a);
extern Clo g_list_2emap_24f577516032x134284914_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023(V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_clo;
V g_std_2enet_2ewithListener_24s515529705x1495267221(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s515529705x1495267221_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s515529705x1495267221_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1730600117x1705054924(V, V);
V g_std_2eprocess_2ewithProcess_24s1730600117x1705054924_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1730600117x1705054924_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_243), heff_strLength_lent(v_p_240, 0));
    if ((heff_strEq_c_lent(v_t_244, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2), 2) || ({ int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL)); int c_ = ({ V v_t_2421 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_245), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2ebuild_2edev_2etypeOf_str3), 2); heff_drop(v_t_2421); c_; }); c_; }))) {
      heff_drop(v_t_244);
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str4);
    } else {
      heff_drop(v_t_244);
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_246), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edev_2etypeOf_str5))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str6);
      } else {
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
        V v_t_249 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_248), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edev_2etypeOf_str7))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str8);
        } else {
          int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
          V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str9))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str10);
          } else {
            int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2413 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2412), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2edev_2etypeOf_str11))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str12);
            } else {
              int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2415 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2414), heff_strLength_lent(v_p_240, 0));
              if ((heff_strEq_c_lent(v_t_2415, ((V)&g_heff_2ebuild_2edev_2etypeOf_str13), 2) || ({ int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2422 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0)); int c_ = heff_strEq_c_lent(v_t_2422, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14), 2); heff_drop(v_t_2422); c_; }); c_; }))) {
                heff_drop(v_t_2415);
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
              } else {
                heff_drop(v_t_2415);
                int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                V v_t_2418 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2417), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                } else {
                  int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                  V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                  } else {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str20);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str17, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str19, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str20, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str22, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str24, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str25, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str26, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str27, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str28, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str29, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str30, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str32, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str33, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str34, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str35, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str37, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str38, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str42, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str44, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str45, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str46, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str47, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str49, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str50, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str51, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str52, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str53, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str55, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str56, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str57, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str58, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str59, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str60, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str61, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str63, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str64, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str65, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str66, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str67, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str68, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str69, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str70, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str71, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str72, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str74, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str75, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str76, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str77, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str78, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str79, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str80, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str81, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str82, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str83, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str84, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str85, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str86, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str87, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str88, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str89, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str90, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str91, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str92, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str93, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str94, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str95, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str96, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str97, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str98, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str99, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str100, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str101, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str102, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str103, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str104, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str105, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str106, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str107, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str108, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str109, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str110, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str111, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str112, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str114, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str115, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str116, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str117, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str118, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str119, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str120, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str121, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str122, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str123, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str124, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str125, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str126, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str127, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str128, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str129, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str130, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str131, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str132, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str133, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str134, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str135, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str136, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str137, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str138, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str139, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str140, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str141, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str142, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str143, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str144, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str145, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str146, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str147, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str148, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str149, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str150, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str151, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str152, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str153, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str154, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str155, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str156, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str157, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str158, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str159, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str160, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str161, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str162, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str163, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str164, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str165, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str166, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str167, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str168, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str169, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str170, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str171, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str172, 2, "..");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str173, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str174, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str175, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str176, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str177, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str178, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str179, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str180, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str181, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str182, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str183, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str184, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str185, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str186, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str187, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str188, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str189, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_str190, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam4, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam10, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam14, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam20, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam21, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam27, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam33, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam39, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam40, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam46, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam51, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam57, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam58, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_lam64, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_entry, 4, 0};

V g_heff_2ebuild_2edev_2eanswer(V v_e_240, V v_disk_241, V v_st_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_disk_241);
    heff_drop(v_st_242);
    return ((V)&g_heff_2ebuild_2edev_2eanswer_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_243, 0);
    V v_x22_249 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str3), 2)) {
      switch (heff_tag_of(v_x22_249)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_disk_241);
        heff_drop(v_st_242);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam1, 2, 1, (V[]){v_x21_248});
      }
      case TAG_Cons: {
        V v_x221_2415 = heff_dup(heff_field(v_x22_249, 0));
        V v_x222_2416 = heff_dup(heff_field(v_x22_249, 1));
        if (heff_strEq_c_lent(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str8), 2)) {
          heff_drop(v_x221_2415);
          switch (heff_tag_of(v_x222_2416)) {
          case TAG_Nil: {
            heff_drop(v_x21_248);
            heff_drop_tag(v_x22_249, 2);
            V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str9)));
            V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str10)));
            V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
            V v_a_2420 = ({ V a_0 = v_st_242; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
            V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2420));
            V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str11)));
            V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
            V v_s_2424 = ({ V a_0 = v_st_242; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2423); r_; });
            V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
            V v_c_2426 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2425));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam2, 2, 1, (V[]){v_c_2426});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2416, 0ULL, 2);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str17), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str18), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str19), 2)))) {
              V v_x1_2438 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_2438) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_2438);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam4_clo);
              } else {
                heff_drop(v_x1_2438);
                V v_t_2445;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_2445 = ((V)&g_heff_2ebuild_2edev_2eanswer_str23);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2443 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_2444 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str24); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_2445, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str25)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str26)));
                  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str27)));
                  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
                  V v_a_2449 = ({ V a_0 = v_st_242; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
                  V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2449));
                  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str28))));
                  V v_t_2452 = (g_std_2epath_2ejoin(v_t_2450, v_t_2451));
                  V v_s_2453 = ({ V a_0 = v_st_242; V a_1 = v_t_2452; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2452); r_; });
                  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2453));
                  V v_c_2455 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2454));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam5, 2, 2, (V[]){v_c_2455, v_x21_248});
                } else {
                  V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str30)));
                  V v_t_2461 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_2462 = (g_std_2epath_2ejoin(v_t_2460, v_t_2461));
                  V v_t_2463 = ({ V a_0 = v_st_242; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2462); r_; });
                  V v_s_2469 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam7, 2, 1, (V[]){v_st_242}), v_t_2463, v_x22_249));
                  V v_t_2470 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2469));
                  V v_c_2471 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_2470));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam8, 2, 2, (V[]){v_c_2471, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam10_clo);
            }
          }
          default: return heff_nomatch(v_x222_2416);
          }
        } else {
          if (heff_strEq_c(v_x221_2415, ((V)&g_heff_2ebuild_2edev_2eanswer_str36))) {
            switch (heff_tag_of(v_x222_2416)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_2483 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str37)));
              V v_t_2484 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_2485 = (g_std_2epath_2ejoin(v_t_2483, v_t_2484));
              V v_a_2486 = ({ V a_0 = v_st_242; V a_1 = v_t_2485; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2485); r_; });
              V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2486));
              V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str38)));
              V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
              V v_s_2490 = ({ V a_0 = v_st_242; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2489); r_; });
              V v_t_2491 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2490));
              V v_c_2492 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_2491));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam11, 2, 5, (V[]){v_c_2492, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2416, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str42), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str43), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str44), 2)))) {
                V v_x1_24110 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24110) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24110);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam14_clo);
                } else {
                  heff_drop(v_x1_24110);
                  V v_t_24117;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24117 = ((V)&g_heff_2ebuild_2edev_2eanswer_str48);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24115 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24116 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24117 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str49); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24117, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str50)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24118 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str51)));
                    V v_t_24119 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str52)));
                    V v_t_24120 = (g_std_2epath_2ejoin(v_t_24118, v_t_24119));
                    V v_a_24121 = ({ V a_0 = v_st_242; V a_1 = v_t_24120; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24120); r_; });
                    V v_t_24122 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24121));
                    V v_t_24123 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str53))));
                    V v_t_24124 = (g_std_2epath_2ejoin(v_t_24122, v_t_24123));
                    V v_s_24125 = ({ V a_0 = v_st_242; V a_1 = v_t_24124; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24124); r_; });
                    V v_t_24126 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24125));
                    V v_c_24127 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24126));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam15, 2, 2, (V[]){v_c_24127, v_x21_248});
                  } else {
                    V v_t_24132 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str55)));
                    V v_t_24133 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24134 = (g_std_2epath_2ejoin(v_t_24132, v_t_24133));
                    V v_t_24135 = ({ V a_0 = v_st_242; V a_1 = v_t_24134; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24134); r_; });
                    V v_s_24141 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam17, 2, 1, (V[]){v_st_242}), v_t_24135, v_x22_249));
                    V v_t_24142 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24141));
                    V v_c_24143 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24142));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam18, 2, 2, (V[]){v_c_24143, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam20_clo);
              }
            }
            default: return heff_nomatch(v_x222_2416);
            }
          } else {
            heff_drop(v_x222_2416);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str61), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str62), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str63), 2)))) {
              V v_x1_24155 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24155) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24155);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam21_clo);
              } else {
                heff_drop(v_x1_24155);
                V v_t_24162;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24162 = ((V)&g_heff_2ebuild_2edev_2eanswer_str67);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24160 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24161 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24162 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str68); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24162, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str69)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24163 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str70)));
                  V v_t_24164 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str71)));
                  V v_t_24165 = (g_std_2epath_2ejoin(v_t_24163, v_t_24164));
                  V v_a_24166 = ({ V a_0 = v_st_242; V a_1 = v_t_24165; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24165); r_; });
                  V v_t_24167 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24166));
                  V v_t_24168 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str72))));
                  V v_t_24169 = (g_std_2epath_2ejoin(v_t_24167, v_t_24168));
                  V v_s_24170 = ({ V a_0 = v_st_242; V a_1 = v_t_24169; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24169); r_; });
                  V v_t_24171 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24170));
                  V v_c_24172 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24171));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam22, 2, 2, (V[]){v_c_24172, v_x21_248});
                } else {
                  V v_t_24177 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str74)));
                  V v_t_24178 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24179 = (g_std_2epath_2ejoin(v_t_24177, v_t_24178));
                  V v_t_24180 = ({ V a_0 = v_st_242; V a_1 = v_t_24179; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24179); r_; });
                  V v_s_24186 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam24, 2, 1, (V[]){v_st_242}), v_t_24180, v_x22_249));
                  V v_t_24187 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24186));
                  V v_c_24188 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24187));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam25, 2, 2, (V[]){v_c_24188, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam27_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_249);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str80), 2)) {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_x21_248);
          V v_t_24200 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str81)));
          V v_t_24201 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str82)));
          V v_t_24202 = (g_std_2epath_2ejoin(v_t_24200, v_t_24201));
          V v_s_24203 = ({ V a_0 = v_st_242; V a_1 = v_t_24202; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24202); r_; });
          V v_t_24204 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24203));
          V v_c_24205 = (g_heff_2eutil_2efiles_2ereadDirectory(v_e_240, v_disk_241, v_t_24204));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam28, 2, 1, (V[]){v_c_24205});
        }
        case TAG_Cons: {
          V v_x221_24221 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24222 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24221, ((V)&g_heff_2ebuild_2edev_2eanswer_str99))) {
            switch (heff_tag_of(v_x222_24222)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_24223 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str100)));
              V v_t_24224 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_24225 = (g_std_2epath_2ejoin(v_t_24223, v_t_24224));
              V v_a_24226 = ({ V a_0 = v_st_242; V a_1 = v_t_24225; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24225); r_; });
              V v_t_24227 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24226));
              V v_t_24228 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str101)));
              V v_t_24229 = (g_std_2epath_2ejoin(v_t_24227, v_t_24228));
              V v_s_24230 = ({ V a_0 = v_st_242; V a_1 = v_t_24229; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24229); r_; });
              V v_t_24231 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24230));
              V v_c_24232 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_24231));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam30, 2, 5, (V[]){v_c_24232, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24222, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str105), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str106), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str107), 2)))) {
                V v_x1_24250 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24250) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24250);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam33_clo);
                } else {
                  heff_drop(v_x1_24250);
                  V v_t_24257;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24257 = ((V)&g_heff_2ebuild_2edev_2eanswer_str111);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24255 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24256 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24257 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str112); V a_1 = v_x_24255; V a_2 = v_xs_24256; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24256); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24257, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str113)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24258 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str114)));
                    V v_t_24259 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str115)));
                    V v_t_24260 = (g_std_2epath_2ejoin(v_t_24258, v_t_24259));
                    V v_a_24261 = ({ V a_0 = v_st_242; V a_1 = v_t_24260; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24260); r_; });
                    V v_t_24262 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24261));
                    V v_t_24263 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str116))));
                    V v_t_24264 = (g_std_2epath_2ejoin(v_t_24262, v_t_24263));
                    V v_s_24265 = ({ V a_0 = v_st_242; V a_1 = v_t_24264; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24264); r_; });
                    V v_t_24266 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24265));
                    V v_c_24267 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24266));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam34, 2, 2, (V[]){v_c_24267, v_x21_248});
                  } else {
                    V v_t_24272 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str118)));
                    V v_t_24273 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24274 = (g_std_2epath_2ejoin(v_t_24272, v_t_24273));
                    V v_t_24275 = ({ V a_0 = v_st_242; V a_1 = v_t_24274; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24274); r_; });
                    V v_s_24281 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam36, 2, 1, (V[]){v_st_242}), v_t_24275, v_x22_249));
                    V v_t_24282 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24281));
                    V v_c_24283 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24282));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam37, 2, 2, (V[]){v_c_24283, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam39_clo);
              }
            }
            default: return heff_nomatch(v_x222_24222);
            }
          } else {
            heff_drop(v_x222_24222);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str124), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str125), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str126), 2)))) {
              V v_x1_24295 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24295) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24295);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam40_clo);
              } else {
                heff_drop(v_x1_24295);
                V v_t_24302;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24302 = ((V)&g_heff_2ebuild_2edev_2eanswer_str130);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24300 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24301 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24302 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str131); V a_1 = v_x_24300; V a_2 = v_xs_24301; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24301); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24302, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str132)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24303 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str133)));
                  V v_t_24304 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str134)));
                  V v_t_24305 = (g_std_2epath_2ejoin(v_t_24303, v_t_24304));
                  V v_a_24306 = ({ V a_0 = v_st_242; V a_1 = v_t_24305; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24305); r_; });
                  V v_t_24307 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24306));
                  V v_t_24308 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str135))));
                  V v_t_24309 = (g_std_2epath_2ejoin(v_t_24307, v_t_24308));
                  V v_s_24310 = ({ V a_0 = v_st_242; V a_1 = v_t_24309; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24309); r_; });
                  V v_t_24311 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24310));
                  V v_c_24312 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24311));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam41, 2, 2, (V[]){v_c_24312, v_x21_248});
                } else {
                  V v_t_24317 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str137)));
                  V v_t_24318 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24319 = (g_std_2epath_2ejoin(v_t_24317, v_t_24318));
                  V v_t_24320 = ({ V a_0 = v_st_242; V a_1 = v_t_24319; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24319); r_; });
                  V v_s_24326 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam43, 2, 1, (V[]){v_st_242}), v_t_24320, v_x22_249));
                  V v_t_24327 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24326));
                  V v_c_24328 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24327));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam44, 2, 2, (V[]){v_c_24328, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam46_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      } else {
        switch (heff_tag_of(v_x22_249)) {
        case TAG_Nil: {
          heff_drop(v_e_240);
          heff_drop(v_disk_241);
          heff_drop(v_st_242);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam47, 2, 1, (V[]){v_x21_248});
        }
        case TAG_Cons: {
          V v_x221_24345 = heff_dup(heff_field(v_x22_249, 0));
          V v_x222_24346 = heff_dup(heff_field(v_x22_249, 1));
          if (heff_strEq_c(v_x221_24345, ((V)&g_heff_2ebuild_2edev_2eanswer_str147))) {
            switch (heff_tag_of(v_x222_24346)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_249, 2);
              V v_t_24347 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str148)));
              V v_t_24348 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_x21_248)));
              V v_t_24349 = (g_std_2epath_2ejoin(v_t_24347, v_t_24348));
              V v_a_24350 = ({ V a_0 = v_st_242; V a_1 = v_t_24349; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24349); r_; });
              V v_t_24351 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24350));
              V v_t_24352 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str149)));
              V v_t_24353 = (g_std_2epath_2ejoin(v_t_24351, v_t_24352));
              V v_s_24354 = ({ V a_0 = v_st_242; V a_1 = v_t_24353; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24353); r_; });
              V v_t_24355 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24354));
              V v_c_24356 = (g_heff_2eutil_2efiles_2ereadFile(heff_dup(v_e_240), heff_dup(v_disk_241), v_t_24355));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam48, 2, 5, (V[]){v_c_24356, v_st_242, v_x21_248, v_e_240, v_disk_241});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24346, 0ULL, 2);
              if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str153), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str154), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str155), 2)))) {
                V v_x1_24374 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
                if (!(heff_dup(v_x1_24374) == NTAG(TAG_True))) {
                  heff_drop(v_e_240);
                  heff_drop(v_disk_241);
                  heff_drop(v_st_242);
                  heff_drop(v_x21_248);
                  heff_drop_tag(v_x22_249, 2);
                  heff_drop(v_x1_24374);
                  return ((V)&g_heff_2ebuild_2edev_2eanswer_lam51_clo);
                } else {
                  heff_drop(v_x1_24374);
                  V v_t_24381;
                  switch (heff_tag_of(v_x22_249)) {
                  case TAG_Nil: {
                    v_t_24381 = ((V)&g_heff_2ebuild_2edev_2eanswer_str159);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_24379 = heff_dup(heff_field(v_x22_249, 0));
                    V v_xs_24380 = heff_dup(heff_field(v_x22_249, 1));
                    v_t_24381 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str160); V a_1 = v_x_24379; V a_2 = v_xs_24380; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24380); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x22_249);
                  }
                  if (heff_strEq_c(v_t_24381, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str161)))) {
                    heff_drop_tag(v_x22_249, 2);
                    V v_t_24382 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str162)));
                    V v_t_24383 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str163)));
                    V v_t_24384 = (g_std_2epath_2ejoin(v_t_24382, v_t_24383));
                    V v_a_24385 = ({ V a_0 = v_st_242; V a_1 = v_t_24384; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24384); r_; });
                    V v_t_24386 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24385));
                    V v_t_24387 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str164))));
                    V v_t_24388 = (g_std_2epath_2ejoin(v_t_24386, v_t_24387));
                    V v_s_24389 = ({ V a_0 = v_st_242; V a_1 = v_t_24388; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24388); r_; });
                    V v_t_24390 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24389));
                    V v_c_24391 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24390));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam52, 2, 2, (V[]){v_c_24391, v_x21_248});
                  } else {
                    V v_t_24396 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str166)));
                    V v_t_24397 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                    V v_t_24398 = (g_std_2epath_2ejoin(v_t_24396, v_t_24397));
                    V v_t_24399 = ({ V a_0 = v_st_242; V a_1 = v_t_24398; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24398); r_; });
                    V v_s_24405 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam54, 2, 1, (V[]){v_st_242}), v_t_24399, v_x22_249));
                    V v_t_24406 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24405));
                    V v_c_24407 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24406));
                    return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam55, 2, 2, (V[]){v_c_24407, v_x22_249});
                  }
                }
              } else {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam57_clo);
              }
            }
            default: return heff_nomatch(v_x222_24346);
            }
          } else {
            heff_drop(v_x222_24346);
            if ((heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str172), 2) ? 0 : (heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str173), 2) ? 0 : !heff_strEq_c_lent(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str174), 2)))) {
              V v_x1_24419 = (g_list_2eall_24s1579400704x1789597964(v_x22_249));
              if (!(heff_dup(v_x1_24419) == NTAG(TAG_True))) {
                heff_drop(v_e_240);
                heff_drop(v_disk_241);
                heff_drop(v_st_242);
                heff_drop(v_x21_248);
                heff_drop_tag(v_x22_249, 2);
                heff_drop(v_x1_24419);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_lam58_clo);
              } else {
                heff_drop(v_x1_24419);
                V v_t_24426;
                switch (heff_tag_of(v_x22_249)) {
                case TAG_Nil: {
                  v_t_24426 = ((V)&g_heff_2ebuild_2edev_2eanswer_str178);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24424 = heff_dup(heff_field(v_x22_249, 0));
                  V v_xs_24425 = heff_dup(heff_field(v_x22_249, 1));
                  v_t_24426 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str179); V a_1 = v_x_24424; V a_2 = v_xs_24425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24425); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_249);
                }
                if (heff_strEq_c(v_t_24426, heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str180)))) {
                  heff_drop_tag(v_x22_249, 2);
                  V v_t_24427 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str181)));
                  V v_t_24428 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str182)));
                  V v_t_24429 = (g_std_2epath_2ejoin(v_t_24427, v_t_24428));
                  V v_a_24430 = ({ V a_0 = v_st_242; V a_1 = v_t_24429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24429); r_; });
                  V v_t_24431 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24430));
                  V v_t_24432 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str183))));
                  V v_t_24433 = (g_std_2epath_2ejoin(v_t_24431, v_t_24432));
                  V v_s_24434 = ({ V a_0 = v_st_242; V a_1 = v_t_24433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24433); r_; });
                  V v_t_24435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24434));
                  V v_c_24436 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24435));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam59, 2, 2, (V[]){v_c_24436, v_x21_248});
                } else {
                  V v_t_24441 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str185)));
                  V v_t_24442 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x21_248));
                  V v_t_24443 = (g_std_2epath_2ejoin(v_t_24441, v_t_24442));
                  V v_t_24444 = ({ V a_0 = v_st_242; V a_1 = v_t_24443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24443); r_; });
                  V v_s_24450 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam61, 2, 1, (V[]){v_st_242}), v_t_24444, v_x22_249));
                  V v_t_24451 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24450));
                  V v_c_24452 = (g_heff_2eutil_2efiles_2ereadFile(v_e_240, v_disk_241, v_t_24451));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam62, 2, 2, (V[]){v_c_24452, v_x22_249});
                }
              }
            } else {
              heff_drop(v_e_240);
              heff_drop(v_disk_241);
              heff_drop(v_st_242);
              heff_drop(v_x21_248);
              heff_drop_tag(v_x22_249, 2);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_lam64_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_249);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eanswer(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eanswer_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_str1)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_246, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str2))});
  V f_ = v_k_245;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str4), v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str5));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str6), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2413, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str7))});
  V f_ = v_k_2411;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_str14)}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str15), v_kind_2430}), v_t_2431});
  V v_t_2434;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edev_2eanswer_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2435 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2432, heff_bytesFromString(v_t_2434)});
  V f_ = v_k_2428;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam3, 1, 1, (V[]){v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str20), ((V)&g_heff_2ebuild_2edev_2eanswer_str21)}), NTAG(TAG_Nil)});
  V v_t_2442 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2441, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str22))});
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str29)); V a_1 = v_x_2458; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam6, 1, 2, (V[]){v_x21_248, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam7(V self, V *args) {
  V v_p_2464 = args[0];
  V v_x_2465 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_2464));
  V v_t_2467 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_2465));
  V v_t_2468 = (g_std_2epath_2ejoin(v_t_2466, v_t_2467));
  return ({ V a_0 = v_st_242; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2468); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_2477 = ((V)&g_heff_2ebuild_2edev_2eanswer_str31);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_x22_249, 0);
    V v_xs_2476 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_2477 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str32); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_2478 = ({ V a_0 = v_t_2477; V a_1 = v_x_2474; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2474); r_; });
  V f_ = v_k_2473;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam8(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam9, 1, 2, (V[]){v_x22_249, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam10(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  heff_drop(v_hd_2479);
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str33), ((V)&g_heff_2ebuild_2edev_2eanswer_str34)}), NTAG(TAG_Nil)});
  V v_t_2482 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2481, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str35))});
  V f_ = v_k_2480;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam13(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  V v_k_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24107 = ({ V a_0 = v_x21_248; V a_1 = v_x_24106; V a_2 = v_x_2495; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24106); heff_drop(v_x_2495); r_; });
  V f_ = v_k_2494;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam12(V self, V *args) {
  V v_x_2495 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_2493 = heff_env(self)[4];
  V v_k_2494 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2496 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str39)));
  V v_t_2497 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str40)));
  V v_t_2498 = (g_std_2epath_2ejoin(v_t_2496, v_t_2497));
  V v_a_2499 = ({ V a_0 = v_st_242; V a_1 = v_t_2498; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2498); r_; });
  V v_t_24100 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2499));
  V v_t_24101 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str41))));
  V v_t_24102 = (g_std_2epath_2ejoin(v_t_24100, v_t_24101));
  V v_s_24103 = ({ V a_0 = v_st_242; V a_1 = v_t_24102; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24102); r_; });
  V v_t_24104 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24103));
  V v_c_24105 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24104; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24104); r_; });
  V f_ = v_c_24105;
  heff_room[0] = v_hd_2493;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam13, 1, 3, (V[]){v_x21_248, v_x_2495, v_k_2494});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam11(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  V v_c_2492 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2492;
  args[0] = heff_dup(v_hd_2493);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam12, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_2493, v_k_2494});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam14(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  heff_drop(v_hd_24111);
  V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str45), ((V)&g_heff_2ebuild_2edev_2eanswer_str46)}), NTAG(TAG_Nil)});
  V v_t_24114 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24113, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str47))});
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam16(V self, V *args) {
  V v_x_24130 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24129 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24131 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str54)); V a_1 = v_x_24130; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24130); r_; });
  V f_ = v_k_24129;
  args[0] = v_x_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam15(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_c_24127 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24127;
  args[0] = v_hd_24128;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam16, 1, 2, (V[]){v_x21_248, v_k_24129});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam17(V self, V *args) {
  V v_p_24136 = args[0];
  V v_x_24137 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24138 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24136));
  V v_t_24139 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24137));
  V v_t_24140 = (g_std_2epath_2ejoin(v_t_24138, v_t_24139));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24140; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24140); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam19(V self, V *args) {
  V v_x_24146 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24149;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24149 = ((V)&g_heff_2ebuild_2edev_2eanswer_str56);
    break;
  }
  case TAG_Cons: {
    V v_x_24147 = heff_field(v_x22_249, 0);
    V v_xs_24148 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24149 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str57); V a_1 = v_x_24147; V a_2 = v_xs_24148; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24148); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24150 = ({ V a_0 = v_t_24149; V a_1 = v_x_24146; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24146); r_; });
  V f_ = v_k_24145;
  args[0] = v_x_24150;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam18(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24143;
  args[0] = v_hd_24144;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam19, 1, 2, (V[]){v_x22_249, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam20(V self, V *args) {
  V v_hd_24151 = args[0];
  V v_k_24152 = args[1];
  heff_drop(v_hd_24151);
  V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str58), ((V)&g_heff_2ebuild_2edev_2eanswer_str59)}), NTAG(TAG_Nil)});
  V v_t_24154 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24153, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str60))});
  V f_ = v_k_24152;
  args[0] = v_t_24154;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam21(V self, V *args) {
  V v_hd_24156 = args[0];
  V v_k_24157 = args[1];
  heff_drop(v_hd_24156);
  V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str64), ((V)&g_heff_2ebuild_2edev_2eanswer_str65)}), NTAG(TAG_Nil)});
  V v_t_24159 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24158, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str66))});
  V f_ = v_k_24157;
  args[0] = v_t_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam23(V self, V *args) {
  V v_x_24175 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24174 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24176 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str73)); V a_1 = v_x_24175; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24175); r_; });
  V f_ = v_k_24174;
  args[0] = v_x_24176;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam22(V self, V *args) {
  V v_hd_24173 = args[0];
  V v_k_24174 = args[1];
  V v_c_24172 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24172;
  args[0] = v_hd_24173;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam23, 1, 2, (V[]){v_x21_248, v_k_24174});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam24(V self, V *args) {
  V v_p_24181 = args[0];
  V v_x_24182 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24183 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24181));
  V v_t_24184 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24182));
  V v_t_24185 = (g_std_2epath_2ejoin(v_t_24183, v_t_24184));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24185; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24185); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam26(V self, V *args) {
  V v_x_24191 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24190 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24194;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24194 = ((V)&g_heff_2ebuild_2edev_2eanswer_str75);
    break;
  }
  case TAG_Cons: {
    V v_x_24192 = heff_field(v_x22_249, 0);
    V v_xs_24193 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24194 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str76); V a_1 = v_x_24192; V a_2 = v_xs_24193; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24193); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24195 = ({ V a_0 = v_t_24194; V a_1 = v_x_24191; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24191); r_; });
  V f_ = v_k_24190;
  args[0] = v_x_24195;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam25(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k_24190 = args[1];
  V v_c_24188 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24188;
  args[0] = v_hd_24189;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam26, 1, 2, (V[]){v_x22_249, v_k_24190});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam27(V self, V *args) {
  V v_hd_24196 = args[0];
  V v_k_24197 = args[1];
  heff_drop(v_hd_24196);
  V v_t_24198 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str77), ((V)&g_heff_2ebuild_2edev_2eanswer_str78)}), NTAG(TAG_Nil)});
  V v_t_24199 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24198, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str79))});
  V f_ = v_k_24197;
  args[0] = v_t_24199;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam29(V self, V *args) {
  V v_x_24208 = args[0];
  V v_k_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_found_24209 = v_x_24208;
  V v_kind_24210 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str83); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_24212;
  switch (heff_tag_of(v_found_24209)) {
  case TAG_Nothing: {
    v_t_24212 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_24211 = heff_field(v_found_24209, 0);
    heff_take_n(v_found_24209, 1ULL, 1);
    v_t_24212 = v_x_24211;
    break;
  }
  default: heff_nomatch(v_found_24209);
  }
  V v_t_24213 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str84); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eanswer_str85); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eanswer_str86); V b_7 = ((V)&g_heff_2ebuild_2edev_2eanswer_str87); V b_8 = ((V)&g_heff_2ebuild_2edev_2eanswer_str88); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eanswer_str89); V a_12 = v_t_24212; V r_ = (g_list_2emap_24f577516032x134284914(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_24214 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_ys_24215 = (g_prelude_2e_2b_2b(v_t_24213, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str90), v_t_24214})));
  V v_t_24216 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str91), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str92), v_ys_24215})});
  V v_text_24217 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str93); V a_1 = ((V)&g_heff_2ebuild_2edev_2eanswer_str94); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str95), v_t_24216}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_24218 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str96), ((V)&g_heff_2ebuild_2edev_2eanswer_str97)}), NTAG(TAG_Nil)});
  V v_t_24219 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str98), v_kind_24210}), v_t_24218});
  V v_x_24220 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_24219, heff_bytesFromString(v_text_24217)});
  V f_ = v_k_24207;
  args[0] = v_x_24220;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam28(V self, V *args) {
  V v_hd_24206 = args[0];
  V v_k_24207 = args[1];
  V v_c_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24205;
  args[0] = v_hd_24206;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam29, 1, 1, (V[]){v_k_24207});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam32(V self, V *args) {
  V v_x_24246 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24235 = heff_env(self)[1];
  V v_k_24234 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24247 = ({ V a_0 = v_x21_248; V a_1 = v_x_24246; V a_2 = v_x_24235; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24246); heff_drop(v_x_24235); r_; });
  V f_ = v_k_24234;
  args[0] = v_x_24247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam31(V self, V *args) {
  V v_x_24235 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24233 = heff_env(self)[4];
  V v_k_24234 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24236 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str102)));
  V v_t_24237 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str103)));
  V v_t_24238 = (g_std_2epath_2ejoin(v_t_24236, v_t_24237));
  V v_a_24239 = ({ V a_0 = v_st_242; V a_1 = v_t_24238; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24238); r_; });
  V v_t_24240 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24239));
  V v_t_24241 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str104))));
  V v_t_24242 = (g_std_2epath_2ejoin(v_t_24240, v_t_24241));
  V v_s_24243 = ({ V a_0 = v_st_242; V a_1 = v_t_24242; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24242); r_; });
  V v_t_24244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24243));
  V v_c_24245 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24244; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24244); r_; });
  V f_ = v_c_24245;
  heff_room[0] = v_hd_24233;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam32, 1, 3, (V[]){v_x21_248, v_x_24235, v_k_24234});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam30(V self, V *args) {
  V v_hd_24233 = args[0];
  V v_k_24234 = args[1];
  V v_c_24232 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24232;
  args[0] = heff_dup(v_hd_24233);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam31, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24233, v_k_24234});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam33(V self, V *args) {
  V v_hd_24251 = args[0];
  V v_k_24252 = args[1];
  heff_drop(v_hd_24251);
  V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str108), ((V)&g_heff_2ebuild_2edev_2eanswer_str109)}), NTAG(TAG_Nil)});
  V v_t_24254 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24253, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str110))});
  V f_ = v_k_24252;
  args[0] = v_t_24254;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam35(V self, V *args) {
  V v_x_24270 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24269 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24271 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str117)); V a_1 = v_x_24270; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24270); r_; });
  V f_ = v_k_24269;
  args[0] = v_x_24271;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam34(V self, V *args) {
  V v_hd_24268 = args[0];
  V v_k_24269 = args[1];
  V v_c_24267 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24267;
  args[0] = v_hd_24268;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam35, 1, 2, (V[]){v_x21_248, v_k_24269});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam36(V self, V *args) {
  V v_p_24276 = args[0];
  V v_x_24277 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24278 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24276));
  V v_t_24279 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24277));
  V v_t_24280 = (g_std_2epath_2ejoin(v_t_24278, v_t_24279));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24280; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24280); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam38(V self, V *args) {
  V v_x_24286 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24285 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24289;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24289 = ((V)&g_heff_2ebuild_2edev_2eanswer_str119);
    break;
  }
  case TAG_Cons: {
    V v_x_24287 = heff_field(v_x22_249, 0);
    V v_xs_24288 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24289 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str120); V a_1 = v_x_24287; V a_2 = v_xs_24288; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24288); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24290 = ({ V a_0 = v_t_24289; V a_1 = v_x_24286; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24286); r_; });
  V f_ = v_k_24285;
  args[0] = v_x_24290;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam37(V self, V *args) {
  V v_hd_24284 = args[0];
  V v_k_24285 = args[1];
  V v_c_24283 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24283;
  args[0] = v_hd_24284;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam38, 1, 2, (V[]){v_x22_249, v_k_24285});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam39(V self, V *args) {
  V v_hd_24291 = args[0];
  V v_k_24292 = args[1];
  heff_drop(v_hd_24291);
  V v_t_24293 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str121), ((V)&g_heff_2ebuild_2edev_2eanswer_str122)}), NTAG(TAG_Nil)});
  V v_t_24294 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24293, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str123))});
  V f_ = v_k_24292;
  args[0] = v_t_24294;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam40(V self, V *args) {
  V v_hd_24296 = args[0];
  V v_k_24297 = args[1];
  heff_drop(v_hd_24296);
  V v_t_24298 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str127), ((V)&g_heff_2ebuild_2edev_2eanswer_str128)}), NTAG(TAG_Nil)});
  V v_t_24299 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24298, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str129))});
  V f_ = v_k_24297;
  args[0] = v_t_24299;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam42(V self, V *args) {
  V v_x_24315 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24314 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24316 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str136)); V a_1 = v_x_24315; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24315); r_; });
  V f_ = v_k_24314;
  args[0] = v_x_24316;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam41(V self, V *args) {
  V v_hd_24313 = args[0];
  V v_k_24314 = args[1];
  V v_c_24312 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24312;
  args[0] = v_hd_24313;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam42, 1, 2, (V[]){v_x21_248, v_k_24314});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam43(V self, V *args) {
  V v_p_24321 = args[0];
  V v_x_24322 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24323 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24321));
  V v_t_24324 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24322));
  V v_t_24325 = (g_std_2epath_2ejoin(v_t_24323, v_t_24324));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24325; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24325); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam45(V self, V *args) {
  V v_x_24331 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24330 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24334;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24334 = ((V)&g_heff_2ebuild_2edev_2eanswer_str138);
    break;
  }
  case TAG_Cons: {
    V v_x_24332 = heff_field(v_x22_249, 0);
    V v_xs_24333 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24334 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str139); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24335 = ({ V a_0 = v_t_24334; V a_1 = v_x_24331; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24331); r_; });
  V f_ = v_k_24330;
  args[0] = v_x_24335;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam44(V self, V *args) {
  V v_hd_24329 = args[0];
  V v_k_24330 = args[1];
  V v_c_24328 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24328;
  args[0] = v_hd_24329;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam45, 1, 2, (V[]){v_x22_249, v_k_24330});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam46(V self, V *args) {
  V v_hd_24336 = args[0];
  V v_k_24337 = args[1];
  heff_drop(v_hd_24336);
  V v_t_24338 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str140), ((V)&g_heff_2ebuild_2edev_2eanswer_str141)}), NTAG(TAG_Nil)});
  V v_t_24339 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24338, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str142))});
  V f_ = v_k_24337;
  args[0] = v_t_24339;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam47(V self, V *args) {
  V v_hd_24340 = args[0];
  V v_k_24341 = args[1];
  V v_x21_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24340);
  V v_t_24342 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_str143), v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str144));
  V v_t_24343 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str145), v_t_24342}), NTAG(TAG_Nil)});
  V v_t_24344 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24343, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str146))});
  V f_ = v_k_24341;
  args[0] = v_t_24344;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam50(V self, V *args) {
  V v_x_24370 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_x_24359 = heff_env(self)[1];
  V v_k_24358 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24371 = ({ V a_0 = v_x21_248; V a_1 = v_x_24370; V a_2 = v_x_24359; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_x_24370); heff_drop(v_x_24359); r_; });
  V f_ = v_k_24358;
  args[0] = v_x_24371;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam49(V self, V *args) {
  V v_x_24359 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_disk_241 = heff_env(self)[3];
  V v_hd_24357 = heff_env(self)[4];
  V v_k_24358 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24360 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str150)));
  V v_t_24361 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2edev_2eanswer_str151)));
  V v_t_24362 = (g_std_2epath_2ejoin(v_t_24360, v_t_24361));
  V v_a_24363 = ({ V a_0 = v_st_242; V a_1 = v_t_24362; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24362); r_; });
  V v_t_24364 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_24363));
  V v_t_24365 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_strAppend(heff_dup(v_x21_248), ((V)&g_heff_2ebuild_2edev_2eanswer_str152))));
  V v_t_24366 = (g_std_2epath_2ejoin(v_t_24364, v_t_24365));
  V v_s_24367 = ({ V a_0 = v_st_242; V a_1 = v_t_24366; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24366); r_; });
  V v_t_24368 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24367));
  V v_c_24369 = ({ V a_0 = v_e_240; V a_1 = v_disk_241; V a_2 = v_t_24368; V r_ = (g_std_2efilesystem_2eisFile(a_0, a_1, a_2)); heff_drop(v_t_24368); r_; });
  V f_ = v_c_24369;
  heff_room[0] = v_hd_24357;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam50, 1, 3, (V[]){v_x21_248, v_x_24359, v_k_24358});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eanswer_lam48(V self, V *args) {
  V v_hd_24357 = args[0];
  V v_k_24358 = args[1];
  V v_c_24356 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x21_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_disk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24356;
  args[0] = heff_dup(v_hd_24357);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam49, 1, 6, (V[]){v_st_242, v_x21_248, v_e_240, v_disk_241, v_hd_24357, v_k_24358});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam51(V self, V *args) {
  V v_hd_24375 = args[0];
  V v_k_24376 = args[1];
  heff_drop(v_hd_24375);
  V v_t_24377 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str156), ((V)&g_heff_2ebuild_2edev_2eanswer_str157)}), NTAG(TAG_Nil)});
  V v_t_24378 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24377, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str158))});
  V f_ = v_k_24376;
  args[0] = v_t_24378;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam53(V self, V *args) {
  V v_x_24394 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24393 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24395 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str165)); V a_1 = v_x_24394; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24394); r_; });
  V f_ = v_k_24393;
  args[0] = v_x_24395;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam52(V self, V *args) {
  V v_hd_24392 = args[0];
  V v_k_24393 = args[1];
  V v_c_24391 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24391;
  args[0] = v_hd_24392;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam53, 1, 2, (V[]){v_x21_248, v_k_24393});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam54(V self, V *args) {
  V v_p_24400 = args[0];
  V v_x_24401 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24402 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24400));
  V v_t_24403 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24401));
  V v_t_24404 = (g_std_2epath_2ejoin(v_t_24402, v_t_24403));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24404; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24404); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam56(V self, V *args) {
  V v_x_24410 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24409 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24413;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24413 = ((V)&g_heff_2ebuild_2edev_2eanswer_str167);
    break;
  }
  case TAG_Cons: {
    V v_x_24411 = heff_field(v_x22_249, 0);
    V v_xs_24412 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24413 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str168); V a_1 = v_x_24411; V a_2 = v_xs_24412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24412); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24414 = ({ V a_0 = v_t_24413; V a_1 = v_x_24410; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24410); r_; });
  V f_ = v_k_24409;
  args[0] = v_x_24414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam55(V self, V *args) {
  V v_hd_24408 = args[0];
  V v_k_24409 = args[1];
  V v_c_24407 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24407;
  args[0] = v_hd_24408;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam56, 1, 2, (V[]){v_x22_249, v_k_24409});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam57(V self, V *args) {
  V v_hd_24415 = args[0];
  V v_k_24416 = args[1];
  heff_drop(v_hd_24415);
  V v_t_24417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str169), ((V)&g_heff_2ebuild_2edev_2eanswer_str170)}), NTAG(TAG_Nil)});
  V v_t_24418 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24417, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str171))});
  V f_ = v_k_24416;
  args[0] = v_t_24418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam58(V self, V *args) {
  V v_hd_24420 = args[0];
  V v_k_24421 = args[1];
  heff_drop(v_hd_24420);
  V v_t_24422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str175), ((V)&g_heff_2ebuild_2edev_2eanswer_str176)}), NTAG(TAG_Nil)});
  V v_t_24423 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24422, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str177))});
  V f_ = v_k_24421;
  args[0] = v_t_24423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam60(V self, V *args) {
  V v_x_24439 = args[0];
  V v_x21_248 = heff_env(self)[0];
  V v_k_24438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24440 = ({ V a_0 = heff_strAppend(v_x21_248, ((V)&g_heff_2ebuild_2edev_2eanswer_str184)); V a_1 = v_x_24439; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24439); r_; });
  V f_ = v_k_24438;
  args[0] = v_x_24440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam59(V self, V *args) {
  V v_hd_24437 = args[0];
  V v_k_24438 = args[1];
  V v_c_24436 = heff_env(self)[0];
  V v_x21_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24436;
  args[0] = v_hd_24437;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam60, 1, 2, (V[]){v_x21_248, v_k_24438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam61(V self, V *args) {
  V v_p_24445 = args[0];
  V v_x_24446 = args[1];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24447 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_p_24445));
  V v_t_24448 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_x_24446));
  V v_t_24449 = (g_std_2epath_2ejoin(v_t_24447, v_t_24448));
  return ({ V a_0 = v_st_242; V a_1 = v_t_24449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_24449); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_lam63(V self, V *args) {
  V v_x_24455 = args[0];
  V v_x22_249 = heff_env(self)[0];
  V v_k_24454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24458;
  switch (heff_tag_of(v_x22_249)) {
  case TAG_Nil: {
    v_t_24458 = ((V)&g_heff_2ebuild_2edev_2eanswer_str186);
    break;
  }
  case TAG_Cons: {
    V v_x_24456 = heff_field(v_x22_249, 0);
    V v_xs_24457 = heff_field(v_x22_249, 1);
    heff_take_n(v_x22_249, 3ULL, 2);
    v_t_24458 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_str187); V a_1 = v_x_24456; V a_2 = v_xs_24457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24457); r_; });
    break;
  }
  default: heff_nomatch(v_x22_249);
  }
  V v_x_24459 = ({ V a_0 = v_t_24458; V a_1 = v_x_24455; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24455); r_; });
  V f_ = v_k_24454;
  args[0] = v_x_24459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam62(V self, V *args) {
  V v_hd_24453 = args[0];
  V v_k_24454 = args[1];
  V v_c_24452 = heff_env(self)[0];
  V v_x22_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24452;
  args[0] = v_hd_24453;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eanswer_lam63, 1, 2, (V[]){v_x22_249, v_k_24454});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eanswer_lam64(V self, V *args) {
  V v_hd_24460 = args[0];
  V v_k_24461 = args[1];
  heff_drop(v_hd_24460);
  V v_t_24462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_str188), ((V)&g_heff_2ebuild_2edev_2eanswer_str189)}), NTAG(TAG_Nil)});
  V v_t_24463 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24462, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_str190))});
  V f_ = v_k_24461;
  args[0] = v_t_24463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str3, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str4, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam7, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam10, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam5(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_entry, 1, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825(V v_st_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str0)));
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam0_clo)});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2428 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam1, 3, 1, (V[]){v_path_241})));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam5, 2, 2, (V[]){v_c_2428, v_st_240});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825(a[0]);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam3(V self, V *args) {
  V v_n_2419 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2419));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2420));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_2417 = args[1];
  V v_z_2418 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2417);
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam3, 1, 1, (V[]){v_path_241}), v_x_2416));
  V v_x_2422 = (g_list_2emap_24s219049803x1458391381(v_x_2421));
  V f_ = v_z_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2425));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2415, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam2, 3, 1, (V[]){v_path_241}), v_z_2412, v_z_2413));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_z_2412);
    V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam4, 1, 1, (V[]){v_path_241}), v_x_2423));
    V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
    V f_ = v_z_2413;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam7(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2439);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2438 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_240, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str2)));
  heff_drop(v_t_2438);
  return (g_co_2eop_24s1531911654x724325922(v_x_2437, v_hd_2429, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam9, 1, 1, (V[]){v_k_2430})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam10(V self, V *args) {
  V v_t_2442 = args[0];
  return v_t_2442;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam13(V self, V *args) {
  V v_x_2453 = args[0];
  V v_bad_2451 = heff_env(self)[0];
  V v_apps_2452 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2453);
  V v_t_2454;
  if (heff_intLt_c(MK_INT(0LL), v_bad_2451)) {
    heff_drop(v_apps_2452);
    v_t_2454 = NTAG(TAG_Nil);
  } else {
    v_t_2454 = v_apps_2452;
  }
  V f_ = v_k_2430;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam12(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bad_2451 = heff_take_field(v_x_2450, 1);
  V v_apps_2452 = heff_get_n(v_x_2450, 0, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2446, v_hd_2429, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam13, 1, 3, (V[]){v_bad_2451, v_apps_2452, v_k_2430})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam11(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_y_2440 = heff_env(self)[1];
  V v_hd_2429 = heff_env(self)[2];
  V v_k_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2447 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str4)));
  V v_t_2448 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2449 = (g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(v_st_240, v_t_2447, heff_dup(v_x_2446), v_t_2448, v_y_2440));
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam12, 1, 3, (V[]){v_x_2446, v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 0ULL, 1);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam7_clo)})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2429, 2)), 1, (V[]){v_t_2435}));
    V f_ = heff_dup(heff_rfield(v_hd_2429, 1));
    heff_room[0] = v_t_2436;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam8, 1, 3, (V[]){v_st_240, v_hd_2429, v_k_2430});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    V v_total_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_y_2440));
    V v_t_2443 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_str3), v_total_2441, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam10_clo)})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2429, 2)), 1, (V[]){v_t_2444}));
    V f_ = heff_dup(heff_rfield(v_hd_2429, 1));
    heff_room[0] = v_t_2445;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam11, 1, 4, (V[]){v_st_240, v_y_2440, v_hd_2429, v_k_2430});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_lam6, 1, 3, (V[]){v_hd_2429, v_st_240, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam2, 4, 0};
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam1(V self, V *args) {
  V v_s_2435 = args[0];
  V v_h_2433 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2436 = heff_tr(heff_call(v_h_2433, 1, (V[]){v_s_2435}));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_get_n(v_hd_2429, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_2439 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2444 = heff_tr(heff_call(v_g_2439, 1, (V[]){v_x_2443}));
  V f_ = v_k_2442;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam2(V self, V *args) {
  V v_g_2439 = args[0];
  V v_c_2440 = args[1];
  V v_hd_2441 = args[2];
  V v_k_2442 = args[3];
  V f_ = v_c_2440;
  args[0] = v_hd_2441;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam3, 1, 2, (V[]){v_g_2439, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam5(V self, V *args) {
  V v_x_2447 = args[0];
  V v_g_2445 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tr(heff_call(v_g_2445, 1, (V[]){v_x_2447}));
  V f_ = heff_get_n(v_hd_2429, 0, 3);
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam4(V self, V *args) {
  V v_g_2445 = args[0];
  V v_m_2446 = args[1];
  V v_hd_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2429, 1));
  args[0] = v_m_2446;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam5, 1, 2, (V[]){v_g_2445, v_hd_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam6(V self, V *args) {
  V v_c_2449 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_get_n(v_hd_2429, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam7(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_2410 = heff_env(self)[0];
  V v_lit_2411 = heff_env(self)[1];
  V v_lit_2412 = heff_env(self)[2];
  V v_lit_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2453);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(v_lit_2410, v_lit_2411, v_lit_2412, v_lit_2413));
}
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_lit_2410 = v_acc_240;
    V v_lit_2411 = v_rest_245;
    V v_lit_2412 = heff_dup(v_p_242);
    V v_lit_2413 = v_p_243;
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str0), heff_get_n(v_r_244, 0, 2));
    V v_t_2415 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2418;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Exited: {
      V v_n_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str1), heff_intShow(v_n_2416));
      break;
    }
    case TAG_Signalled: {
      V v_n_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str2), heff_intShow(v_n_2417));
      break;
    }
    case TAG_TimedOut: {
      v_t_2418 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str3);
      break;
    }
    case TAG_NotRun: {
      v_t_2418 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str4);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str5)), v_t_2418);
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str6)), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_str7));
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_p_2428 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2427});
    V v_hd_2429 = v_p_242;
    V v_t_2451;
    switch (heff_tag_of(v_p_2428)) {
    case TAG_InL: {
      V v_x_2430 = heff_field(v_p_2428, 0);
      V v_ru_24p_2428_24InL = heff_take_reuse_n(v_p_2428, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2430)) {
      case TAG_Throw: {
        V v_s_2431 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24Throw = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24x_2430_24Throw, TAG_Throw, 1, (V[]){v_s_2431});
        break;
      }
      case TAG_Catch: {
        V v_c_2432 = heff_field(v_x_2430, 0);
        V v_h_2433 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Catch = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        V v_t_2434 = heff_tr(heff_call(v_c_2432, 2, (V[]){heff_dup(v_hd_2429), heff_dup(heff_rfield(v_hd_2429, 0))}));
        v_t_2437 = heff_tag_at_n(v_ru_24x_2430_24Catch, TAG_Catch, 2, (V[]){v_t_2434, heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam1, 1, 2, (V[]){v_h_2433, heff_dup(v_hd_2429)})});
        break;
      }
      default: heff_nomatch(v_x_2430);
      }
      v_t_2451 = heff_tag_at_n(v_ru_24p_2428_24InL, TAG_InL, 1, (V[]){v_t_2437});
      break;
    }
    case TAG_InR: {
      V v_y_2438 = heff_field(v_p_2428, 0);
      V v_ru_24p_2428_24InR = heff_take_reuse_n(v_p_2428, 1ULL, 1);
      V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam2_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam4, 2, 1, (V[]){heff_dup(v_hd_2429)})}), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam6, 1, 1, (V[]){heff_dup(v_hd_2429)}), v_y_2438}));
      v_t_2451 = heff_tag_at_n(v_ru_24p_2428_24InR, TAG_InR, 1, (V[]){v_t_2450});
      break;
    }
    default: heff_nomatch(v_p_2428);
    }
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_hd_2429, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_lam7, 1, 4, (V[]){v_lit_2410, v_lit_2411, v_lit_2412, v_lit_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str1, 33, "heff dev: cannot serve the pages\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str2, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam13(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_entry, 4, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(V v_st_240, V v_d_241, V v_stamp_242, V v_apps_243) {
top: ;
  V v_t_244 = (g_list_2eany_24s105899861x584770213(v_apps_243));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && !(heff_dup(heff_rfield(v_d_241, 4)) == NTAG(TAG_True)))) {
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam0, 2, 4, (V[]){v_d_241, v_st_240, v_stamp_242, v_apps_243});
  } else {
    heff_drop(v_t_244);
    V v_c_2449 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(heff_dup(v_st_240), heff_dup(v_d_241), heff_dup(v_apps_243)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam13, 2, 5, (V[]){v_c_2449, v_d_241, v_apps_243, v_st_240, v_stamp_242});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2419);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam6, 3, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2417;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam5, 3, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam4, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam2(V self, V *args) {
  V v_pg_2413 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_apps_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_pg_2413);
  V v_t_2414 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_241, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2415 = (g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(v_st_240, v_t_2414, v_stamp_242, v_apps_243));
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam3, 2, 1, (V[]){v_c_2415});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2427;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_245;
  heff_room[2] = v_k_2426;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam11(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_x_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam10(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2430;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam11, 3, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_apps_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_2430 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2439);
  V v_t_2440 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_241, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2441 = (g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(v_st_240, v_t_2440, v_stamp_242, v_apps_243));
  V f_ = v_c_2441;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam10, 1, 1, (V[]){v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam8(V self, V *args) {
  V v_s_2429 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_stamp_242 = heff_env(self)[3];
  V v_apps_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_s_2429);
  V v_k_2430 = heff_dup(heff_rfield(v_hd_245, 0));
  V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str1), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam9, 1, 6, (V[]){v_d_241, v_st_240, v_stamp_242, v_apps_243, v_hd_245, v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2448;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_245;
  heff_room[2] = v_k_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_apps_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = heff_dup(heff_rfield(v_d_241, 3));
  V v_t_2410;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_241, 2)), v_t_2410});
  V v_t_2412 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_247, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str0), v_t_2411}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2425 = (g_std_2eprocess_2ewithProcess_24s1730600117x1705054924(v_t_2412, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam2, 1, 4, (V[]){heff_dup(v_d_241), heff_dup(v_st_240), heff_dup(v_stamp_242), heff_dup(v_apps_243)})));
  V v_k_2426 = heff_dup(heff_rfield(v_hd_245, 0));
  V v_t_2428 = heff_tr(heff_call(v_c_2425, 2, (V[]){heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam7, 1, 2, (V[]){heff_dup(v_hd_245), v_k_2426})}));
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2428, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam8, 1, 5, (V[]){heff_dup(v_hd_245), v_d_241, v_st_240, v_stamp_242, v_apps_243})})});
  V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2447;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam12, 1, 2, (V[]){v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_d_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_apps_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam1, 1, 6, (V[]){v_d_241, v_st_240, v_stamp_242, v_apps_243, v_hd_245, v_k_246})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam15(V self, V *args) {
  V v_a_2454 = args[0];
  V v_wanted_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_build_2455 = heff_take_field(v_a_2454, 1);
  V v_name_2456 = heff_get_n(v_a_2454, 0, 2);
  if (heff_strEq_c(heff_get_n(v_build_2455, 0, 3), ((V)&g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_str2))) {
    switch (heff_tag_of(v_wanted_2453)) {
    case TAG_Nil: {
      heff_drop(v_name_2456);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2459 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_name_2456}));
      return ({ V a_0 = v_t_2459; V a_1 = v_wanted_2453; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2453, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2453);
    }
  } else {
    heff_drop(v_wanted_2453);
    heff_drop(v_name_2456);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam16(V self, V *args) {
  V v_x_2462 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_dev_2463 = heff_take_field(v_x_2462, 0);
  V v_stamp_2464 = heff_take_field(v_x_2462, 2);
  V v_apps_2465 = heff_get_n(v_x_2462, 1, 3);
  V v_t_2466 = (g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(v_st_240, v_dev_2463, v_stamp_2464, v_apps_2465));
  V f_ = v_t_2466;
  heff_room[0] = v_hd_2450;
  heff_room[1] = v_k_2451;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam14(V self, V *args) {
  V v_x_2452 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_apps_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_stamp_242 = heff_env(self)[3];
  V v_hd_2450 = heff_env(self)[4];
  V v_k_2451 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2452);
  V v_wanted_2453 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_2460 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam15, 1, 1, (V[]){v_wanted_2453}), v_apps_243));
  V v_c_2461 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(heff_dup(v_st_240), v_d_241, v_stamp_242, NTAG(TAG_Nil), v_t_2460));
  V f_ = v_c_2461;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam16, 1, 3, (V[]){v_st_240, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam13(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_apps_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_stamp_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2449;
  args[0] = heff_dup(v_hd_2450);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_lam14, 1, 6, (V[]){v_d_241, v_apps_243, v_st_240, v_stamp_242, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str6, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str14, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str15, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str17, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str19, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam6, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam7, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam4(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_entry, 3, 0};

V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613(V v_st_240, V v_x2_241, V v_req_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_target_243 = heff_get_n(v_req_242, 1, 6);
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str0), v_target_243, MK_INT(0LL), 5);
    V v_path_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_path_245 = v_target_243;
    } else {
      v_path_245 = heff_strSlice(v_target_243, MK_INT(0LL), v_j_244);
    }
    V v_s_246 = heff_strSlice(heff_dup(v_path_245), MK_INT(1LL), heff_strLength(v_path_245));
    V v_t_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str1); V a_1 = v_s_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str2), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_246); r_; });
    return (g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam0_clo), v_st_240, v_t_247));
  }
  case TAG_Just: {
    V v_to_2415 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_target_2416 = heff_dup(heff_rfield(v_req_242, 1));
    V v_j_2417 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str3), v_target_2416, MK_INT(0LL), 5);
    V v_path_2418;
    if (heff_intLt_c_lent(v_j_2417, MK_INT(0LL), 2)) {
      heff_drop(v_j_2417);
      v_path_2418 = v_target_2416;
    } else {
      v_path_2418 = heff_strSlice(v_target_2416, MK_INT(0LL), v_j_2417);
    }
    V v_s_2419 = heff_strSlice(heff_dup(v_path_2418), MK_INT(1LL), heff_strLength(v_path_2418));
    V v_x1_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str4); V a_1 = v_s_2419; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str5), v_s_2419, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2419); r_; });
    V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str6)));
    V v_t_2424;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2424));
    V v_t_2426 = (g_std_2epath_2ejoin(v_t_2421, v_t_2425));
    V v_s_2427 = ({ V a_0 = v_st_240; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2426); r_; });
    V v_path_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2427));
    V v_t_2429 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2428; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2428); r_; });
    V v_a_2431 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_2429, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam1_clo)});
    V v_c_2445 = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam2, 2, 1, (V[]){v_a_2431});
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam4, 2, 4, (V[]){v_c_2445, v_req_242, v_st_240, v_to_2415});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2414});
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam1(V self, V *args) {
  V v_r_2430 = args[0];
  return v_r_2430;
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    V f_ = v_k_2433;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2442 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    V v_t_2443 = heff_get_n(v_s_2442, 0, 4);
    V v_t_2444;
    switch (heff_tag_of(v_t_2443)) {
    case TAG_Regular: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2443);
    }
    V f_ = v_k_2433;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_a_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2431})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s1876960293x1282655859(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam3, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam6(V self, V *args) {
  V v_a_2454 = args[0];
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2460});
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam7(V self, V *args) {
  V v_a_2481 = args[0];
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2487});
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_req_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_2446 = heff_env(self)[2];
  V v_k_2447 = heff_env(self)[3];
  V v_to_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2448) == NTAG(TAG_True))) {
    heff_drop(v_x_2448);
    heff_drop(v_to_2415);
    V v_target_2449 = heff_get_n(v_req_242, 1, 6);
    V v_j_2450 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str8), v_target_2449, MK_INT(0LL), 5);
    V v_path_2451;
    if (heff_intLt_c_lent(v_j_2450, MK_INT(0LL), 2)) {
      heff_drop(v_j_2450);
      v_path_2451 = v_target_2449;
    } else {
      v_path_2451 = heff_strSlice(v_target_2449, MK_INT(0LL), v_j_2450);
    }
    V v_s_2452 = heff_strSlice(heff_dup(v_path_2451), MK_INT(1LL), heff_strLength(v_path_2451));
    V v_t_2453 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str9); V a_1 = v_s_2452; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str10), v_s_2452, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2452); r_; });
    V v_t_2461 = (g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam6_clo), v_st_240, v_t_2453));
    V f_ = v_t_2461;
    heff_room[0] = v_hd_2446;
    heff_room[1] = v_k_2447;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2448);
    V v_target_2462 = heff_dup(heff_rfield(v_req_242, 1));
    V v_j_2463 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str11), v_target_2462, MK_INT(0LL), 5);
    V v_path_2464;
    if (heff_intLt_c_lent(v_j_2463, MK_INT(0LL), 2)) {
      heff_drop(v_j_2463);
      v_path_2464 = v_target_2462;
    } else {
      v_path_2464 = heff_strSlice(v_target_2462, MK_INT(0LL), v_j_2463);
    }
    V v_s_2465 = heff_strSlice(heff_dup(v_path_2464), MK_INT(1LL), heff_strLength(v_path_2464));
    V v_ps_2466 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str12); V a_1 = v_s_2465; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str13), v_s_2465, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2465); r_; });
    V v_t_2475;
    switch (heff_tag_of(v_ps_2466)) {
    case TAG_Nil: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_ps1_2467 = heff_field(v_ps_2466, 0);
      V v_ps2_2468 = heff_field(v_ps_2466, 1);
      heff_take_n(v_ps_2466, 3ULL, 2);
      if (heff_strEq_c_lent(v_ps1_2467, ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str14), 2)) {
        heff_drop(v_ps1_2467);
        switch (heff_tag_of(v_ps2_2468)) {
        case TAG_Nil: {
          v_t_2475 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          V v_ps21_2469 = heff_field(v_ps2_2468, 0);
          V v_ps22_2470 = heff_field(v_ps2_2468, 1);
          heff_take_n(v_ps2_2468, 3ULL, 2);
          if (heff_strEq_c(v_ps21_2469, ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str15))) {
            switch (heff_tag_of(v_ps22_2470)) {
            case TAG_Nil: {
              v_t_2475 = NTAG(TAG_True);
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_ps22_2470, 0ULL, 2);
              v_t_2475 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_ps22_2470);
            }
          } else {
            heff_drop(v_ps22_2470);
            v_t_2475 = NTAG(TAG_False);
          }
          break;
        }
        default: heff_nomatch(v_ps2_2468);
        }
      } else {
        if (heff_strEq_c(v_ps1_2467, ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str16))) {
          switch (heff_tag_of(v_ps2_2468)) {
          case TAG_Nil: {
            v_t_2475 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_ps2_2468, 0ULL, 2);
            v_t_2475 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_ps2_2468);
          }
        } else {
          heff_drop(v_ps2_2468);
          v_t_2475 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_ps_2466);
    }
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_to_2415);
      heff_drop(v_t_2475);
      V v_target_2476 = heff_get_n(v_req_242, 1, 6);
      V v_j_2477 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str17), v_target_2476, MK_INT(0LL), 5);
      V v_path_2478;
      if (heff_intLt_c_lent(v_j_2477, MK_INT(0LL), 2)) {
        heff_drop(v_j_2477);
        v_path_2478 = v_target_2476;
      } else {
        v_path_2478 = heff_strSlice(v_target_2476, MK_INT(0LL), v_j_2477);
      }
      V v_s_2479 = heff_strSlice(heff_dup(v_path_2478), MK_INT(1LL), heff_strLength(v_path_2478));
      V v_t_2480 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str18); V a_1 = v_s_2479; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_str19), v_s_2479, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2479); r_; });
      V v_t_2488 = (g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam7_clo), v_st_240, v_t_2480));
      V f_ = v_t_2488;
      heff_room[0] = v_hd_2446;
      heff_room[1] = v_k_2447;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_240);
      heff_drop(v_t_2475);
      return (g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320(v_to_2415, v_req_242, v_hd_2446, v_k_2447));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_req_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_to_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2445;
  args[0] = heff_dup(v_hd_2446);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_lam5, 1, 5, (V[]){v_req_242, v_st_240, v_hd_2446, v_k_2447, v_to_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str1, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str4, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str7, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam7, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam6, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam8, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam10, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam11(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam11, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_entry, 4, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814(V v_port_240, V v_proxy_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam1, 1, 4, (V[]){v_port_240, v_hd_242, v_proxy_241, v_k_243})});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2446 = args[1];
  V v_k_2447 = args[2];
  heff_drop(v_x_2445);
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  heff_drop(v_x_2442);
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam7_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2441);
  V f_ = v_k_2427;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam6_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam8(V self, V *args) {
  V v_i_2449 = args[0];
  return v_i_2449;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2455});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2456});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_c_2439 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2457 = heff_tr(heff_call(v_c_2439, 2, (V[]){heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam10_clo), ((V)&g_green_2ethenRes_24s2092633126x465472411_clo), ((V)&g_green_2egreenAlg_24s854873557x32656427_clo)}), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam11_clo)}));
  V v_t_2458 = (g_green_2eview_24s1017855520x282345245(heff_tag_n(TAG_Main, 1, (V[]){v_t_2457})));
  V v_t_2459 = (g_green_2ego_24s1072496561x430638721(heff_tag_n(TAG_MkGroup, 1, (V[]){v_x_2454}), heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}), v_t_2458));
  V f_ = v_t_2459;
  heff_room[0] = v_hd_2440;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_proxy_241 = heff_env(self)[1];
  V v_listener_2421 = heff_env(self)[2];
  V v_hd_2426 = heff_env(self)[3];
  V v_k_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2436);
  V v_t_2437;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str6))) {
    v_t_2437 = NTAG(TAG_Windows);
  } else {
    v_t_2437 = NTAG(TAG_Posix);
  }
  V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s1012974440x1657285613_clo), 2, (V[]){v_t_2437, v_proxy_241}));
  V v_c_2439 = heff_tr(heff_call(((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_clo), 2, (V[]){v_listener_2421, v_t_2438}));
  V v_hd_2440 = v_hd_2426;
  V v_k_2448 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam5, 1, 1, (V[]){v_k_2427});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam8_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2440, 2)), 1, (V[]){v_t_2452}));
  V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
  heff_room[0] = v_t_2453;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam9, 1, 3, (V[]){v_c_2439, v_hd_2440, v_k_2448});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_t_2425 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_proxy_241 = heff_env(self)[2];
  V v_listener_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2426, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
  V f_ = heff_dup(heff_rfield(v_hd_2426, 1));
  args[0] = v_t_2435;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam4, 1, 5, (V[]){v_x_2413, v_proxy_241, v_listener_2421, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam2(V self, V *args) {
  V v_listener_2421 = args[0];
  V v_port_240 = heff_env(self)[0];
  V v_proxy_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str1), v_port_240), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str2));
  V v_t_2424;
  switch (heff_tag_of(v_proxy_241)) {
  case TAG_Nothing: {
    v_t_2424 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str3);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_dup(heff_field(v_proxy_241, 0));
    v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str4), v_x_2423);
    break;
  }
  default: heff_nomatch(v_proxy_241);
  }
  V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2422, v_t_2424), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str5));
  return heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam3, 2, 4, (V[]){v_t_2425, v_x_2413, v_proxy_241, v_listener_2421});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam12(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2460;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_2420;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam16(V self, V *args) {
  V v_x_2487 = args[0];
  V v_hd_2488 = args[1];
  V v_k_2489 = args[2];
  V v_x_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2487);
  heff_drop(v_hd_2488);
  V f_ = v_k_2489;
  args[0] = v_x_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam15(V self, V *args) {
  V v_x_2486 = args[0];
  V v_k_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2465;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam16, 3, 1, (V[]){v_x_2486});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam14(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_2485;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam15, 1, 1, (V[]){v_k_2465});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam13(V self, V *args) {
  V v_s_2462 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_port_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_2463 = heff_take_field(v_s_2462, 1);
  V v_message_2464 = heff_get_n(v_s_2462, 2, 3);
  V v_k_2465 = heff_dup(heff_rfield(v_hd_242, 0));
  V v_t_2466 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str7), v_port_240), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str8));
  V v_t_2467 = heff_strAppend(heff_strAppend(v_name_2463, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str9)), v_message_2464);
  V v_t_2468 = heff_strAppend(heff_strAppend(v_t_2466, v_t_2467), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str10));
  V v_t_2469 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2468, NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2476;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam14, 1, 2, (V[]){v_hd_242, v_k_2465});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam17(V self, V *args) {
  V v_x_2492 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2492;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_port_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_proxy_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2414 = (g_prelude_2eparseInt_24cpr(v_port_240));
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = MK_INT(8000LL);
    }
  }
  V v_t_2419 = heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_str0), v_t_2418});
  V v_k_2420 = heff_dup(heff_rfield(v_hd_242, 0));
  V v_t_2461 = heff_tr(g_std_2enet_2ewithListener_24s515529705x1495267221(v_t_2419, MK_INT(64LL), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam2, 1, 3, (V[]){heff_dup(v_port_240), v_proxy_241, v_x_2413}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam12, 1, 2, (V[]){heff_dup(v_hd_242), v_k_2420})));
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2461, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam13, 1, 2, (V[]){heff_dup(v_hd_242), v_port_240})})});
  V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2490}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2491;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s882004788x673629814_lam17, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}