// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Directory 35277
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_MakeDirectory 16793
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_kind 9787483
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_stamp 311115741
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1938432363x1897732959(V, V, V, V, V, V);
V g_co_2eop_24s1938432363x1897732959_entry(V self, V *a);
extern Clo g_co_2eop_24s1938432363x1897732959_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s310418905x1614124229(V, V, V);
V g_co_2eop_24s310418905x1614124229_entry(V self, V *a);
extern Clo g_co_2eop_24s310418905x1614124229_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(V, V);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo;
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_clo;
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(V, V, V, V, V);
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str0, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str1, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str2, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str3, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str4, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str5, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str6, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str7, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str8, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str9, 16, "<html lang=\"en\">");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2emadePage_str11, 15, "<!doctype html>");
Clo g_heff_2ebuild_2edev_2emadePage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2emadePage_entry, 1, 0};

V g_heff_2ebuild_2edev_2emadePage(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2edev_2emadePage_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2emadePage_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2emadePage_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2emadePage_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2emadePage_str10); V a_1 = ((V)&g_heff_2ebuild_2edev_2emadePage_str11); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2emadePage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str1, 24, "text/html; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str2, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str3, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str4, 4, ".mjs");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str5, 30, "text/javascript; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str6, 4, ".css");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str7, 23, "text/css; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str8, 5, ".json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str9, 16, "application/json");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str10, 4, ".svg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str11, 13, "image/svg+xml");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str12, 4, ".png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str13, 9, "image/png");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str14, 4, ".jpg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str15, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str16, 5, ".jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str17, 10, "image/jpeg");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str18, 5, ".wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str19, 16, "application/wasm");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str20, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2etypeOf_str22, 24, "application/octet-stream");
Clo g_heff_2ebuild_2edev_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2etypeOf_entry, 1, 0};

V g_heff_2ebuild_2edev_2etypeOf(V v_p_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_241), heff_strLength_lent(v_p_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2edev_2etypeOf_str0))) {
    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str1);
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_244), heff_strLength_lent(v_p_240, 0));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edev_2etypeOf_str2))) {
      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str3);
    } else {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
      V v_t_248 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2edev_2etypeOf_str4))) {
        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str5);
      } else {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
        V v_t_2411 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2410), heff_strLength_lent(v_p_240, 0));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edev_2etypeOf_str6))) {
          return ((V)&g_heff_2ebuild_2edev_2etypeOf_str7);
        } else {
          int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
          V v_t_2414 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2413), heff_strLength_lent(v_p_240, 0));
          if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edev_2etypeOf_str8))) {
            return ((V)&g_heff_2ebuild_2edev_2etypeOf_str9);
          } else {
            int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
            V v_t_2417 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2416), heff_strLength_lent(v_p_240, 0));
            if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2edev_2etypeOf_str10))) {
              return ((V)&g_heff_2ebuild_2edev_2etypeOf_str11);
            } else {
              int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
              V v_t_2420 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2419), heff_strLength_lent(v_p_240, 0));
              if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2edev_2etypeOf_str12))) {
                return ((V)&g_heff_2ebuild_2edev_2etypeOf_str13);
              } else {
                int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                V v_t_2423 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2422), heff_strLength_lent(v_p_240, 0));
                if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2edev_2etypeOf_str14))) {
                  return ((V)&g_heff_2ebuild_2edev_2etypeOf_str15);
                } else {
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                  V v_t_2426 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2425), heff_strLength_lent(v_p_240, 0));
                  if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2edev_2etypeOf_str16))) {
                    return ((V)&g_heff_2ebuild_2edev_2etypeOf_str17);
                  } else {
                    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)5ULL));
                    V v_t_2429 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2428), heff_strLength_lent(v_p_240, 0));
                    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2edev_2etypeOf_str18))) {
                      return ((V)&g_heff_2ebuild_2edev_2etypeOf_str19);
                    } else {
                      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)4ULL));
                      V v_t_2432 = heff_strSlice(heff_dup(v_p_240), heff_box_word(v_t_2431), heff_strLength_lent(v_p_240, 0));
                      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2edev_2etypeOf_str20))) {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str21);
                      } else {
                        return ((V)&g_heff_2ebuild_2edev_2etypeOf_str22);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2etypeOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str1, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eownPath_str2, 0, "");
Clo g_heff_2ebuild_2edev_2eownPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eownPath_entry, 1, 0};

V g_heff_2ebuild_2edev_2eownPath(V v_ps_240) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_ps1_241 = heff_field(v_ps_240, 0);
    V v_ps2_242 = heff_field(v_ps_240, 1);
    if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str0), 2)) {
      switch (heff_tag_of(v_ps2_242)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_ps21_244 = heff_field(v_ps2_242, 0);
        V v_ps22_245 = heff_field(v_ps2_242, 1);
        if (heff_strEq_c_lent(v_ps21_244, ((V)&g_heff_2ebuild_2edev_2eownPath_str1), 2)) {
          switch (heff_tag_of(v_ps22_245)) {
          case TAG_Nil: {
            return NTAG(TAG_True);
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_ps22_245);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_ps2_242);
      }
    } else {
      if (heff_strEq_c_lent(v_ps1_241, ((V)&g_heff_2ebuild_2edev_2eownPath_str2), 2)) {
        switch (heff_tag_of(v_ps2_242)) {
        case TAG_Nil: {
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_ps2_242);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eownPath(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Write, 2, (V[]){heff_dup(heff_rfield(v_r_240, 1)), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0, 1, 3, (V[]){v_r_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_str0), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_r_240, 2, 3), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry, 4, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s495635622x733177935(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam11(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_dup(heff_rfield(v_x_2419, 0));
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    if (heff_intEq_c(v_n_2424, MK_INT(0LL))) {
      heff_drop_rec(v_x_2419, 3);
      return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_hd_242; V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam7, 1, 1, (V[]){v_k_243}); V r_ = (g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2419, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam8, 1, 1, (V[]){v_k_243})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2419, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam9, 1, 1, (V[]){v_k_243})));
  }
  case TAG_TimedOut: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2419, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam10, 1, 1, (V[]){v_k_243})));
  }
  case TAG_NotRun: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s947307867x666243766(v_x_2419, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam11, 1, 1, (V[]){v_k_243})));
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2420}));
  return (g_co_2eop_24s495635622x733177935(v_t_2421, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam6, 1, 5, (V[]){v_x_2419, v_prog_240, v_st_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str1), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2415), v_x_2412, v_t_2416, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam5, 1, 5, (V[]){v_x_2415, v_prog_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980_lam3, 1, 5, (V[]){v_prog_240, v_x_2412, v_hd_242, v_st_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str0, 7, "status ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str1, 7, "signal ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str2, 9, "timed out");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str4, 8, " ended (");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str6, 10, "heff dev: ");
HEFF_LIT(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str7, 1, "\012");
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry, 4, 0};

V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(V v_acc_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_240});
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(v_r_244, 1)), 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0, 1, 5, (V[]){v_r_244, v_acc_240, v_rest_245, v_p_242, v_p_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_244, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_acc_240, v_t_247));
    return (g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(v_t_248, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Just: {
    V v_ran_249 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_ran_249, 0, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Exited: {
      V v_n_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str0), heff_intShow(v_n_2411));
      break;
    }
    case TAG_Signalled: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str1), heff_intShow(v_n_2412));
      break;
    }
    case TAG_TimedOut: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str2);
      break;
    }
    case TAG_NotRun: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str3);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str5)));
    V v_t_2415 = heff_strAppend(heff_get_n(v_r_244, 0, 2), v_t_2414);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str6), v_t_2415), ((V)&g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_str7));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s1938432363x1897732959(v_acc_240, v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242));
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_clock_241), 1, (V[]){v_t_246}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0, 2, 7, (V[]){v_t_247, v_running_245, heff_dup(v_st_242), heff_dup(v_stamp_244), v_prog_240, v_clock_241, v_d_243});
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    V v_t_2419 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_x_2415; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_x_2415); r_; });
    V f_ = v_t_2419;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_as_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_x_2411);
    heff_drop(v_hd_248);
    V v_t_2421 = heff_intAdd(heff_take_field(v_d_243, 0), MK_INT(1LL));
    V v_t_2422 = ({ V rv_0 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_d_243, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_249;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2422, v_as_2420, v_x_2415});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nil: {
    v_x_2415 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_xs_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    v_x_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  if (heff_strEq_c_lent(v_x_2415, v_stamp_244, 0)) {
    heff_drop(v_x_2415);
    V v_t_2417 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_t_2417;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_stamp_244);
    return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_242; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam4, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2415, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_stamp_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_242; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_248); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam3, 1, 8, (V[]){v_stamp_244, v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_242); r_; });
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_running_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(NTAG(TAG_Nil), v_running_245, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam2, 1, 7, (V[]){v_st_242, v_hd_248, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
V g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_running_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270_lam1, 1, 8, (V[]){v_running_245, v_hd_248, v_st_242, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str5, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str6, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str9, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str10, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry, 3, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V v_st_240, V v_d_241, V v_apps_242) {
top: ;
  V v_path_243 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str0), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str1)));
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0, 2, 4, (V[]){v_path_243, heff_dup(v_st_240), v_d_241, v_apps_242});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3(V self, V *args) {
  V v_ok_2417 = args[0];
  return v_ok_2417;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5(V self, V *args) {
  V v_a_2427 = args[0];
  V v_wanted_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_a_2427, 1)), 0, 3);
  if (heff_strEq_c(v_t_2428, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str5))) {
    switch (heff_tag_of(v_wanted_2426)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2427, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2427, 0, 2)}));
      return ({ V a_0 = v_t_2432; V a_1 = v_wanted_2426; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2426, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2426);
    }
  } else {
    heff_drop_rec(v_a_2427, 2);
    heff_drop(v_wanted_2426);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_apps_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_intShow(heff_take_field(v_d_241, 0));
  V v_wanted_2426 = heff_get_n(v_d_241, 1, 5);
  V v_as_2433 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam5, 1, 1, (V[]){v_wanted_2426}), v_apps_242));
  V v_t_2439;
  switch (heff_tag_of(v_as_2433)) {
  case TAG_Nil: {
    v_t_2439 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str6);
    break;
  }
  case TAG_Cons: {
    V v_x2_2436 = (g_list_2emap_24s2104774589x596860835(v_as_2433));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str8); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    break;
  }
  default: heff_nomatch(v_as_2433);
  }
  V v_t_2440 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str9), v_t_2439));
  V v_str_2441 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str10), v_t_2440);
  V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2441, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str11)), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_t_2414 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str2), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str3)));
  V v_path_2415 = ({ V a_0 = v_st_240; V a_1 = v_t_2414; V a_2 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_str4); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2416 = heff_intShow(heff_dup(heff_rfield(v_d_241, 0)));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2415, v_t_2416, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam3_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam4, 1, 4, (V[]){v_d_241, v_apps_242, v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_lam2, 1, 5, (V[]){v_st_240, v_d_241, v_hd_244, v_apps_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str4, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str5, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry, 8, 0};

V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_running_246, V v_x5_247) {
top: ;
  switch (heff_tag_of(v_x5_247)) {
  case TAG_Nil: {
    heff_drop(v_ex_242);
    return (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(v_prog_240, v_clock_241, v_st_243, v_d_244, v_stamp_245, v_running_246));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x5_247, 0);
    V v_rest_249 = heff_field(v_x5_247, 1);
    heff_take_n(v_x5_247, 3ULL, 2);
    V v_t_2410 = (g_std_2epath_2ejoin(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str0), ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str1)));
    V v_n_2411 = heff_dup(heff_rfield(v_a_248, 0));
    V v_t_2412;
    switch (heff_tag_of(v_st_243)) {
    case TAG_Posix: {
      v_t_2412 = v_n_2411;
      break;
    }
    case TAG_Windows: {
      v_t_2412 = heff_strAppend(v_n_2411, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str2));
      break;
    }
    default: heff_nomatch(v_st_243);
    }
    V v_cmd_2413 = (g_std_2epath_2ejoin(v_st_243, v_t_2410, v_t_2412));
    V v_t_2453 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0, 2, 10, (V[]){v_cmd_2413, heff_dup(v_ex_242), heff_dup(v_a_248), heff_dup(v_running_246), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_st_243), heff_dup(v_d_244), heff_dup(v_stamp_245), heff_dup(v_rest_249)}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5, 3, 9, (V[]){v_a_248, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), v_d_244, heff_dup(v_stamp_245), v_running_246, v_rest_249})})}));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9, 2, 1, (V[]){v_t_2453});
  }
  default: return heff_nomatch(v_x5_247);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a[0], a[1], a[2], a3, a[4], a5, a[6], a[7]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_running_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_d_244 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2419;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkWith: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam2_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2427}));
  V v_t_2429 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_248, 0, 2), v_t_2428});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_t_2431 = (g_prelude_2e_2b_2b(v_running_246, v_t_2430));
  return ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_t_2431; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2434 = args[1];
  V v_k_2435 = args[2];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam4, 3, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_cmd_2413 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_running_246 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_st_243 = heff_env(self)[6];
  V v_d_244 = heff_env(self)[7];
  V v_stamp_245 = heff_env(self)[8];
  V v_rest_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_cmd_2413, NTAG(TAG_Nil), ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str3), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  return (g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(heff_dup(v_ex_242), v_t_2416, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam1, 1, 9, (V[]){v_a_248, v_running_246, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_d_244, v_stamp_245, v_rest_249}), v_hd_2414, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam3, 1, 1, (V[]){v_k_2415})));
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2438;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam8, 3, 1, (V[]){v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2437 = heff_env(self)[8];
  V v_k_2438 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2447);
  V v_c_2448 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_running_246; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2448;
  heff_room[0] = v_hd_2437;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam7, 1, 1, (V[]){v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam5(V self, V *args) {
  V v_err_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k_2438 = args[2];
  V v_a_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_d_244 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_running_246 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_err_2436);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str4), heff_get_n(v_a_248, 0, 2));
  V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_str5)), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_2437), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam6, 1, 10, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_d_244, v_stamp_245, v_running_246, v_rest_249, v_hd_2437, v_k_2438})));
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2454 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2456;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2454;
  heff_room[2] = v_k_2455;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam9(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_t_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s495635622x733177935(v_t_2453, heff_dup(v_hd_2454), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_lam10, 1, 2, (V[]){v_hd_2454, v_k_2455})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry, 8, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(V v_prog_240, V v_clock_241, V v_ex_242, V v_wanted_243, V v_port_244, V v_proxy_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str0), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1, 1, 8, (V[]){v_hd_246, v_k_247, heff_dup(v_port_244), v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_2426 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2453 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2426; V a_4 = heff_take_field(v_x_2452, 0); V b_5 = heff_take_field(v_x_2452, 2); V a_6 = heff_get_n(v_x_2452, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_2426); heff_drop(b_5); r_; });
  V f_ = v_t_2453;
  heff_room[0] = v_hd_246;
  heff_room[1] = v_k_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_2426 = heff_env(self)[2];
  V v_d_2449 = heff_env(self)[3];
  V v_x_2446 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Nothing: {
    V v_c_2451 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = v_st_2426; V a_3 = v_d_2449; V a_4 = v_x_2446; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s627455401x1486150270(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2446); r_; });
    V f_ = v_c_2451;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam7, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_2426, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_apps_2454 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V v_t_2455 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2449, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2456 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2426; V a_4 = v_t_2455; V a_5 = v_x_2446; V a_6 = v_apps_2454; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2426); heff_drop(v_x_2446); r_; });
    V f_ = v_t_2456;
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_wanted_243 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2426 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2446;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Nil: {
    v_x_2446 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2444 = heff_field(v_x_2443, 0);
    V v_xs_2445 = heff_field(v_x_2443, 1);
    heff_take_n(v_x_2443, 3ULL, 2);
    v_x_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str4); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  V v_t_2448;
  switch (heff_tag_of(v_port_244)) {
  case TAG_Nothing: {
    v_t_2448 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2447 = heff_field(v_port_244, 0);
    heff_take_n(v_port_244, 1ULL, 1);
    v_t_2448 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_port_244);
  }
  V v_d_2449 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_243, v_t_2448, v_proxy_245, NTAG(TAG_False)});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2426; V a_2 = heff_dup(v_hd_246); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam6, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_2426), v_d_2449, v_x_2446, v_hd_246, v_ex_242, v_k_247}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s1859546621x1711181980(a_0, a_1, a_2, a_3)); heff_drop(v_st_2426); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_port_244 = heff_env(self)[3];
  V v_wanted_243 = heff_env(self)[4];
  V v_proxy_245 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  V v_ex_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_st_2426;
  if (heff_strEq_c(v_x_2424, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str1))) {
    v_st_2426 = NTAG(TAG_Windows);
  } else {
    v_st_2426 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_port_244);
    heff_drop(v_wanted_243);
    heff_drop(v_proxy_245);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_ex_242);
    heff_drop(v_st_2426);
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_str2), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam4, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2415, 0ULL, 1);
    return ({ V a_0 = v_st_2426; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_246); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam5, 1, 9, (V[]){v_port_244, v_wanted_243, v_proxy_245, v_prog_240, heff_dup(v_st_2426), v_hd_246, v_clock_241, v_ex_242, v_k_247}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1068076608x1567105128(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2426); r_; });
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_port_244 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(v_t_2423, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s886021933x1825688465_lam3, 1, 9, (V[]){v_x_2415, v_hd_246, v_k_247, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str14, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str16, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_247 = v_target_244;
    } else {
      v_path_247 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str1); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    return (g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(v_st_241, v_t_249));
  }
  case TAG_Just: {
    V v_to_2410 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2411 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str3), v_target_2411, MK_INT(0LL), 5);
    V v_path_2414;
    if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
      heff_drop(v_j_2412);
      v_path_2414 = v_target_2411;
    } else {
      v_path_2414 = heff_strSlice(v_target_2411, MK_INT(0LL), v_j_2412);
    }
    V v_s_2415 = heff_strSlice(heff_dup(v_path_2414), MK_INT(1LL), heff_strLength(v_path_2414));
    V v_x1_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str4); V a_1 = v_s_2415; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str5), v_s_2415, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2415); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 2);
      v_t_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    V v_path_2420 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str7), v_t_2419));
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0, 2, 5, (V[]){v_req_243, heff_dup(v_st_241), v_web_240, v_to_2410, v_path_2420});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2423);
    heff_drop(v_web_240);
    heff_drop(v_to_2410);
    V v_target_2424 = heff_get_n(v_req_243, 1, 6);
    V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str8), v_target_2424, MK_INT(0LL), 5);
    V v_path_2427;
    if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
      heff_drop(v_j_2425);
      v_path_2427 = v_target_2424;
    } else {
      v_path_2427 = heff_strSlice(v_target_2424, MK_INT(0LL), v_j_2425);
    }
    V v_s_2428 = heff_strSlice(heff_dup(v_path_2427), MK_INT(1LL), heff_strLength(v_path_2427));
    V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str9); V a_1 = v_s_2428; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str10), v_s_2428, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2428); r_; });
    V v_t_2430 = ({ V a_0 = v_st_241; V a_1 = v_t_2429; V r_ = (g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(a_0, a_1)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2421;
    heff_room[1] = v_k_2422;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2423);
    V v_target_2431 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str11), v_target_2431, MK_INT(0LL), 5);
    V v_path_2434;
    if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
      heff_drop(v_j_2432);
      v_path_2434 = v_target_2431;
    } else {
      v_path_2434 = heff_strSlice(v_target_2431, MK_INT(0LL), v_j_2432);
    }
    V v_s_2435 = heff_strSlice(heff_dup(v_path_2434), MK_INT(1LL), heff_strLength(v_path_2434));
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str12); V a_1 = v_s_2435; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str13), v_s_2435, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2435); r_; });
    V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2436); r_; });
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_web_240);
      heff_drop(v_to_2410);
      heff_drop(v_t_2437);
      V v_target_2438 = heff_get_n(v_req_243, 1, 6);
      V v_j_2439 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str14), v_target_2438, MK_INT(0LL), 5);
      V v_path_2441;
      if (heff_intLt_c_lent(v_j_2439, MK_INT(0LL), 2)) {
        heff_drop(v_j_2439);
        v_path_2441 = v_target_2438;
      } else {
        v_path_2441 = heff_strSlice(v_target_2438, MK_INT(0LL), v_j_2439);
      }
      V v_s_2442 = heff_strSlice(heff_dup(v_path_2441), MK_INT(1LL), heff_strLength(v_path_2441));
      V v_t_2443 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str15); V a_1 = v_s_2442; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_str16), v_s_2442, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2442); r_; });
      V v_t_2444 = ({ V a_0 = v_st_241; V a_1 = v_t_2443; V r_ = (g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(a_0, a_1)); heff_drop(v_st_241); r_; });
      V f_ = v_t_2444;
      heff_room[0] = v_hd_2421;
      heff_room[1] = v_k_2422;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2437);
      return (g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(v_web_240, v_to_2410, v_req_243, v_hd_2421, v_k_2422));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2(V self, V *args) {
  V v_r_2446 = args[0];
  return v_r_2446;
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Left: {
    heff_take_n(v_x_2454, 0ULL, 1);
    V f_ = v_k_2445;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2456 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    V v_t_2457 = heff_get_n(v_s_2456, 0, 4);
    V v_t_2458;
    switch (heff_tag_of(v_t_2457)) {
    case TAG_Regular: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2458 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2457);
    }
    V f_ = v_k_2445;
    args[0] = v_t_2458;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_web_240 = heff_env(self)[2];
  V v_to_2410 = heff_env(self)[3];
  V v_path_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_2445 = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam1, 1, 6, (V[]){v_req_243, v_st_241, heff_dup(v_hd_2421), v_k_2422, v_web_240, v_to_2410});
  V v_t_2447 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2420, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam2_clo)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s310418905x1614124229(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_hd_2421, heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_lam3, 1, 1, (V[]){v_k_2445})));
}