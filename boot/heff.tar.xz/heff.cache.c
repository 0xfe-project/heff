// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define LBL_above 293969847
#define LBL_aliases 1464806715
#define LBL_assoc 294479919
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_looser 850054335
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_own 320000
#define LBL_renames 1324191545
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_tighter 1059982480
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
static uint32_t shape_fixities__defs__hashes[] = {LBL_fixities, LBL_defs, LBL_hashes};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops[] = {LBL_id, LBL_assoc, LBL_ops};
static uint32_t shape_name__key__span__ty__body[] = {LBL_name, LBL_key, LBL_span, LBL_ty, LBL_body};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecache_2eallJust(V);
V g_heff_2ecache_2eallJust_entry(V self, V *a);
extern Clo g_heff_2ecache_2eallJust_clo;
V g_heff_2ecache_2edefHashOne(V, V, V);
V g_heff_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ecache_2edefHashOne_clo;
V g_heff_2ecache_2efixSig(V);
V g_heff_2ecache_2efixSig_entry(V self, V *a);
extern Clo g_heff_2ecache_2efixSig_clo;
V g_heff_2ecache_2efreeze(V, V, V, V);
V g_heff_2ecache_2efreeze_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreeze_clo;
V g_heff_2ecache_2efreezeDef(V, V, V);
V g_heff_2ecache_2efreezeDef_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreezeDef_clo;
V g_heff_2ecache_2efreezeFix(V);
V g_heff_2ecache_2efreezeFix_entry(V self, V *a);
extern Clo g_heff_2ecache_2efreezeFix_clo;
V g_heff_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecache_2ehashGo_clo;
V g_heff_2ecache_2emelt(V, V, V, V);
V g_heff_2ecache_2emelt_entry(V self, V *a);
extern Clo g_heff_2ecache_2emelt_clo;
V g_heff_2ecache_2emeltDef(V, V);
V g_heff_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltDef_clo;
V g_heff_2ecache_2emeltFix(V, V);
V g_heff_2ecache_2emeltFix_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltFix_clo;
V g_heff_2ecache_2emeltFixGroup(V, V);
V g_heff_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ecache_2emeltFixGroup_clo;
V g_heff_2ecache_2eneedsOf(V);
V g_heff_2ecache_2eneedsOf_entry(V self, V *a);
extern Clo g_heff_2ecache_2eneedsOf_clo;
V g_heff_2ecache_2ensOf(V, V);
V g_heff_2ecache_2ensOf_entry(V self, V *a);
extern Clo g_heff_2ecache_2ensOf_clo;
V g_heff_2ecache_2enubCa(V);
V g_heff_2ecache_2enubCa_entry(V self, V *a);
extern Clo g_heff_2ecache_2enubCa_clo;
V g_heff_2ecache_2epairsHold(V, V);
V g_heff_2ecache_2epairsHold_entry(V self, V *a);
extern Clo g_heff_2ecache_2epairsHold_clo;
V g_heff_2ecache_2eversion_get(void);
V g_heff_2ecache_2eversionDir_get(void);
V g_heff_2ecache_2ewholeHash(V, V);
V g_heff_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ecache_2ewholeHash_clo;
V g_heff_2ecache_2ezipCa(V, V);
V g_heff_2ecache_2ezipCa_entry(V self, V *a);
extern Clo g_heff_2ecache_2ezipCa_clo;
V g_heff_2edriver_2enubStrD(V);
V g_heff_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubStrD_clo;
V g_heff_2eimport_2eimportsOf(V, V);
V g_heff_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsOf_clo;
V g_heff_2eimport_2erenamed(V, V);
V g_heff_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2eimport_2erenamed_clo;
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(V);
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_clo;
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(V);
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_clo;
V g_heff_2erename_2enubFirst(V);
V g_heff_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2erename_2enubFirst_clo;
V g_heff_2eserial_2edkOf(V);
V g_heff_2eserial_2edkOf_entry(V self, V *a);
extern Clo g_heff_2eserial_2edkOf_clo;
V g_heff_2eserial_2eencodeTermF_24s1949627523x1369233217(V, V);
V g_heff_2eserial_2eencodeTermF_24s1949627523x1369233217_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeTermF_24s1949627523x1369233217_clo;
V g_heff_2eserial_2eencodeTypeF_24s905585727x233380302(V, V);
V g_heff_2eserial_2eencodeTypeF_24s905585727x233380302_entry(V self, V *a);
extern Clo g_heff_2eserial_2eencodeTypeF_24s905585727x233380302_clo;
V g_heff_2eserial_2etakeManyG(V, V, V);
V g_heff_2eserial_2etakeManyG_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeManyG_clo;
V g_heff_2eserial_2etakeStr(V, V);
V g_heff_2eserial_2etakeStr_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeStr_clo;
V g_heff_2eserial_2etakeWord(V, V);
V g_heff_2eserial_2etakeWord_entry(V self, V *a);
extern Clo g_heff_2eserial_2etakeWord_clo;
V g_heff_2esurface_2eintOfText(V);
V g_heff_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esurface_2eintOfText_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1801866615x1952232028(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1801866615x1952232028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1801866615x1952232028_clo;
V g_list_2efoldl_24s647105187x1503385827(V, V, V, V);
V g_list_2efoldl_24s647105187x1503385827_entry(V self, V *a);
extern Clo g_list_2efoldl_24s647105187x1503385827_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1176007509x671449441(V, V, V, V, V);
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a);
extern Clo g_list_2emap_24s1176007509x671449441_clo;
V g_list_2emap_24s1405724801x1371482992(V, V);
V g_list_2emap_24s1405724801x1371482992_entry(V self, V *a);
extern Clo g_list_2emap_24s1405724801x1371482992_clo;
V g_list_2emap_24s1750409203x420789256(V);
V g_list_2emap_24s1750409203x420789256_entry(V self, V *a);
extern Clo g_list_2emap_24s1750409203x420789256_clo;
V g_list_2emap_24s1751623379x2107197849(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1751623379x2107197849_entry(V self, V *a);
extern Clo g_list_2emap_24s1751623379x2107197849_clo;
V g_list_2emap_24s1821466936x1723477761(V);
V g_list_2emap_24s1821466936x1723477761_entry(V self, V *a);
extern Clo g_list_2emap_24s1821466936x1723477761_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strLt_get(void);
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecache_2eversion_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 45, 99, 97, 99, 104, 101, 45, 112, 111, 114, 116, 47, 50, 52}};

static V g_heff_2ecache_2eversion_val;
static int g_heff_2ecache_2eversion_st;
static V g_heff_2ecache_2eversion_init(void) {
  return ((V)&g_heff_2ecache_2eversion_str0);
}
V g_heff_2ecache_2eversion_get(void) {
  if (g_heff_2ecache_2eversion_st == 2) return g_heff_2ecache_2eversion_val;
  if (g_heff_2ecache_2eversion_st == 1) heff_fail("defined by itself");
  g_heff_2ecache_2eversion_st = 1;
  g_heff_2ecache_2eversion_val = heff_tr(g_heff_2ecache_2eversion_init());
  g_heff_2ecache_2eversion_st = 2;
  return g_heff_2ecache_2eversion_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecache_2eversionDir_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 50, 52}};

static V g_heff_2ecache_2eversionDir_val;
static int g_heff_2ecache_2eversionDir_st;
static V g_heff_2ecache_2eversionDir_init(void) {
  return ((V)&g_heff_2ecache_2eversionDir_str0);
}
V g_heff_2ecache_2eversionDir_get(void) {
  if (g_heff_2ecache_2eversionDir_st == 2) return g_heff_2ecache_2eversionDir_val;
  if (g_heff_2ecache_2eversionDir_st == 1) heff_fail("defined by itself");
  g_heff_2ecache_2eversionDir_st = 1;
  g_heff_2ecache_2eversionDir_val = heff_tr(g_heff_2ecache_2eversionDir_init());
  g_heff_2ecache_2eversionDir_st = 2;
  return g_heff_2ecache_2eversionDir_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ehashGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
Clo g_heff_2ecache_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2ehashGo_entry, 4, 0};

V g_heff_2ecache_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_strAppend(heff_intShow(v_a_242), heff_strAppend(((V)&g_heff_2ecache_2ehashGo_str0), heff_intShow(v_b_243)));
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_246;
    V t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecache_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2ehashGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecache_2enubCa_lam0(V self, V *args);
Clo g_heff_2ecache_2enubCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2enubCa_entry, 1, 0};

V g_heff_2ecache_2enubCa(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo(g_heff_2ecache_2enubCa_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2ecache_2enubCa(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecache_2enubCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2enubCa(a[0]);
}
V g_heff_2ecache_2enubCa_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2edefHashOne_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecache_2edefHashOne_lam0(V self, V *args);
Clo g_heff_2ecache_2edefHashOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2edefHashOne_entry, 3, 0};

V g_heff_2ecache_2edefHashOne(V v_m_240, V v_c_241, V v_o_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_get(heff_dup(v_o_242), LBL_key), v_m_240));
  V v_t_245;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_c_241);
    heff_drop(v_o_242);
    return v_m_240;
  }
  case TAG_False: {
    V v_g_246 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
    V v_k_247 = heff_get(heff_dup(v_o_242), LBL_key);
    V v_t_248 = ({ V a_0 = heff_dup(v_k_247); V b_1 = heff_get(heff_dup(v_g_246), LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = ({ V a_0 = v_k_247; V b_1 = heff_get(heff_dup(v_g_246), LBL_aliases); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_g_246);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_k2_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2412 = ({ V a_0 = v_k2_2410; V b_1 = heff_get(v_g_246, LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    case TAG_Just: {
      V v_e_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop(v_g_246);
      heff_drop(v_k_247);
      v_t_2412 = heff_tag_at(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_e_2411});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop(v_o_242);
      return v_m_240;
    }
    case TAG_Just: {
      V v_e_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_x2_2414 = ({ V b_0 = heff_get(heff_dup(v_e_2413), LBL_tySyntax); V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2eserial_2eencodeTypeF_24s905585727x233380302(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ecache_2edefHashOne_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecache_2edefHashOne_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_x2_2418 = (g_heff_2eserial_2eencodeTermF_24s1949627523x1369233217(heff_get(heff_dup(v_e_2413), LBL_syntax), NTAG(TAG_Nil)));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ecache_2edefHashOne_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecache_2edefHashOne_str3); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      V v_t_2422 = ({ V b_0 = heff_get(heff_dup(v_e_2413), LBL_tySyntax); V r_ = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(b_0)); heff_drop(b_0); r_; });
      V v_t_2423 = (g_heff_2erename_2enubFirst(v_t_2422));
      V v_t_2424 = ({ V b_0 = heff_get(v_e_2413, LBL_syntax); V r_ = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(b_0)); heff_drop(b_0); r_; });
      V v_t_2425 = (g_heff_2erename_2enubFirst(v_t_2424));
      V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2425));
      V v_t_2427 = (g_heff_2ecache_2enubCa(v_t_2426));
      V v_t_2428 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
      V v_x2_2433 = (g_list_2emap(heff_clo(g_heff_2ecache_2edefHashOne_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_2428));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2ecache_2edefHashOne_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecache_2edefHashOne_str7); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      V v_s_2437 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecache_2edefHashOne_str8), heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecache_2edefHashOne_str9), v_t_2436))));
      V v_t_2438 = (g_heff_2ecache_2ehashGo(v_s_2437, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_map_2einsert_24s1341440536x470972936(heff_get(v_o_242, LBL_key), v_t_2438, v_m_240);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecache_2edefHashOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2edefHashOne(a[0], a[1], a[2]);
}
V g_heff_2ecache_2edefHashOne_lam0(V self, V *args) {
  V v_k_2429 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2430 = ({ V a_0 = heff_dup(v_k_2429); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2432;
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_Nothing: {
    v_t_2432 = ((V)&g_heff_2ecache_2edefHashOne_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    heff_take_n(v_x2_2430, 1ULL, 1);
    v_t_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x2_2430);
  }
  return heff_strAppend(v_k_2429, heff_strAppend(((V)&g_heff_2ecache_2edefHashOne_str5), v_t_2432));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {35}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecache_2ewholeHash_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ewholeHash_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
V g_heff_2ecache_2ewholeHash_lam0(V self, V *args);
V g_heff_2ecache_2ewholeHash_lam1(V self, V *args);
Clo g_heff_2ecache_2ewholeHash_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2ewholeHash_entry, 2, 0};

V g_heff_2ecache_2ewholeHash(V v_m_240, V v_c_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_get(heff_dup(v_c_241), LBL_module), ((V)&g_heff_2ecache_2ewholeHash_str0));
  V v_x2_247 = (g_list_2emap(heff_clo(g_heff_2ecache_2ewholeHash_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), heff_get(heff_dup(v_c_241), LBL_own)));
  V v_s_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_s_2410 = ((V)&g_heff_2ecache_2ewholeHash_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_s_2410 = ({ V a_0 = ((V)&g_heff_2ecache_2ewholeHash_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2ecache_2ehashGo(v_s_2410, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2412 = heff_strAppend(heff_get(heff_dup(v_c_241), LBL_module), ((V)&g_heff_2ecache_2ewholeHash_str5));
  V v_x2_2417 = (g_list_2emap(heff_clo(g_heff_2ecache_2ewholeHash_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), heff_get(v_c_241, LBL_own)));
  V v_s_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_s_2420 = ((V)&g_heff_2ecache_2ewholeHash_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_s_2420 = ({ V a_0 = ((V)&g_heff_2ecache_2ewholeHash_str9); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = (g_heff_2ecache_2ehashGo(v_s_2420, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2422 = (g_map_2einsert_24s1341440536x470972936(v_t_2412, v_t_2421, v_m_240));
  return (g_map_2einsert_24s1341440536x470972936(v_t_242, v_t_2411, v_t_2422));
}
V g_heff_2ecache_2ewholeHash_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2ewholeHash(a[0], a[1]);
}
V g_heff_2ecache_2ewholeHash_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_o_243), LBL_key); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ecache_2ewholeHash_str1);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return heff_strAppend(heff_get(v_o_243, LBL_key), heff_strAppend(((V)&g_heff_2ecache_2ewholeHash_str2), v_t_246));
}
V g_heff_2ecache_2ewholeHash_lam1(V self, V *args) {
  V v_o_2413 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2414 = ({ V a_0 = heff_get(heff_dup(v_o_2413), LBL_key); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ecache_2ewholeHash_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  return heff_strAppend(heff_get(v_o_2413, LBL_key), heff_strAppend(((V)&g_heff_2ecache_2ewholeHash_str7), v_t_2416));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efixSig_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
Clo g_heff_2ecache_2efixSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2efixSig_entry, 1, 0};

V g_heff_2ecache_2efixSig(V v_f_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s1751623379x2107197849(((V)&g_heff_2ecache_2efixSig_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ecache_2efixSig_str1), ((V)&g_heff_2ecache_2efixSig_str2), ((V)&g_heff_2ecache_2efixSig_str3), heff_get(heff_dup(v_f_240), LBL_groups)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ecache_2efixSig_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ecache_2efixSig_str5); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_list_2emap_24s1405724801x1371482992(((V)&g_heff_2ecache_2efixSig_str6), heff_get(v_f_240, LBL_above)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecache_2efixSig_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecache_2efixSig_str8); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecache_2efixSig_str9), v_t_248));
}
V g_heff_2ecache_2efixSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2efixSig(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeFix_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeFix_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeFix_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeFix_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2ecache_2efreezeFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2efreezeFix_entry, 1, 0};

V g_heff_2ecache_2efreezeFix(V v_f_240) {
top: ;
  V v_xs_241 = heff_get(heff_dup(v_f_240), LBL_groups);
  V v_t_242 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_242), (g_list_2efoldl_24s1801866615x1952232028(((V)&g_heff_2ecache_2efreezeFix_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecache_2efreezeFix_str1), NTAG(TAG_Nil), v_t_243))});
  V v_xs_245 = heff_get(v_f_240, LBL_above);
  V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_246), (g_list_2efoldl_24s647105187x1503385827(((V)&g_heff_2ecache_2efreezeFix_str2), ((V)&g_heff_2ecache_2efreezeFix_str3), NTAG(TAG_Nil), v_t_247))});
  return (g_prelude_2e_2b_2b(v_t_244, v_t_248));
}
V g_heff_2ecache_2efreezeFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2efreezeFix(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ensOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ensOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ensOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2ensOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
V g_heff_2ecache_2ensOf_lam0(V self, V *args);
Clo g_heff_2ecache_2ensOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2ensOf_entry, 2, 0};

V g_heff_2ecache_2ensOf(V v_done_240, V v_m_241) {
top: ;
  V v_t_243 = (g_list_2efind(heff_clo(g_heff_2ecache_2ensOf_lam0, 1, 1, (V[]){v_m_241}), v_done_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ecache_2ensOf_str0);
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_245 = (g_list_2emap_24s1821466936x1723477761(heff_get(heff_dup(v_d_244), LBL_own)));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecache_2ensOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecache_2ensOf_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_s_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecache_2ensOf_str3), (g_heff_2ecache_2efixSig(heff_get(v_d_244, LBL_fixities)))));
    return (g_heff_2ecache_2ehashGo(v_s_249, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecache_2ensOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecache_2ensOf(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecache_2ensOf_lam0(V self, V *args) {
  V v_d_242 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_242, LBL_module), v_m_241);
}
V g_heff_2ecache_2eneedsOf_lam0(V self, V *args);
V g_heff_2ecache_2eneedsOf_lam1(V self, V *args);
Clo g_heff_2ecache_2eneedsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2eneedsOf_entry, 1, 0};

V g_heff_2ecache_2eneedsOf(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_c_240), LBL_own)));
  V v_t_2421 = ({ V a_0 = heff_clo(g_heff_2ecache_2eneedsOf_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_2422 = (g_heff_2ecache_2enubCa(v_t_2421));
  V v_t_2427 = (g_list_2efilter(heff_clo(g_heff_2ecache_2eneedsOf_lam1, 1, 1, (V[]){v_c_240}), v_t_2422));
  return (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
}
V g_heff_2ecache_2eneedsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2eneedsOf(a[0]);
}
V g_heff_2ecache_2eneedsOf_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_244 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_k_245 = heff_get(v_x_243, LBL_key);
  V v_t_246 = ({ V a_0 = heff_dup(v_k_245); V b_1 = heff_get(heff_dup(v_g_244), LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = ({ V a_0 = v_k_245; V b_1 = heff_get(heff_dup(v_g_244), LBL_aliases); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_g_244);
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_k2_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = v_k2_248; V b_1 = heff_get(v_g_244, LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_e_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = ({ V b_0 = heff_get(heff_dup(v_e_2410), LBL_tySyntax); V r_ = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(b_0)); heff_drop(b_0); r_; });
        V v_t_2412 = (g_heff_2erename_2enubFirst(v_t_2411));
        V v_t_2413 = ({ V b_0 = heff_get(v_e_2410, LBL_syntax); V r_ = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(b_0)); heff_drop(b_0); r_; });
        V v_t_2414 = (g_heff_2erename_2enubFirst(v_t_2413));
        v_t_2420 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop(v_g_244);
    heff_drop(v_k_245);
    V v_t_2416 = ({ V b_0 = heff_get(heff_dup(v_e_2415), LBL_tySyntax); V r_ = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(b_0)); heff_drop(b_0); r_; });
    V v_t_2417 = (g_heff_2erename_2enubFirst(v_t_2416));
    V v_t_2418 = ({ V b_0 = heff_get(v_e_2415, LBL_syntax); V r_ = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(b_0)); heff_drop(b_0); r_; });
    V v_t_2419 = (g_heff_2erename_2enubFirst(v_t_2418));
    v_t_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_242));
}
V g_heff_2ecache_2eneedsOf_lam1(V self, V *args) {
  V v_k_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2424 = (g_list_2emap_24s1750409203x420789256(heff_get(v_c_240, LBL_own)));
  V v_t_2425 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_k_2423}));
  V v_x1_2426 = ({ V a_0 = v_t_2425; V a_1 = v_xs_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2424); r_; });
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreezeDef_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2ecache_2efreezeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2efreezeDef_entry, 3, 0};

V g_heff_2ecache_2efreezeDef(V v_hashes_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_MkPair: {
      V v_sp_246 = heff_field(v_x32_244, 1);
      V v_ru_24x32_244_24MkPair = heff_take_reuse_n(v_x32_244, 2ULL, 2);
      V v_g_247 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
      V v_k_248 = heff_get(heff_dup(v_o_243), LBL_key);
      V v_t_249 = ({ V a_0 = heff_dup(v_k_248); V b_1 = heff_get(heff_dup(v_g_247), LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2413;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_t_2410 = ({ V a_0 = v_k_248; V b_1 = heff_get(heff_dup(v_g_247), LBL_aliases); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nothing: {
          heff_drop(v_g_247);
          v_t_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_k2_2411 = heff_field(v_t_2410, 0);
          heff_take_n(v_t_2410, 1ULL, 1);
          v_t_2413 = ({ V a_0 = v_k2_2411; V b_1 = heff_get(v_g_247, LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        break;
      }
      case TAG_Just: {
        V v_e_2412 = heff_field(v_t_249, 0);
        V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
        heff_drop(v_g_247);
        heff_drop(v_k_248);
        v_t_2413 = heff_tag_at(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_e_2412});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop(v_o_243);
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop(v_sp_246);
        heff_drop_cell(v_ru_24x32_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_2414 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        V v_s_2415 = heff_get(heff_dup(v_o_243), LBL_name);
        V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
        V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecache_2efreezeDef_str0), v_s_2415));
        V v_s_2418 = heff_get(heff_dup(v_o_243), LBL_key);
        V v_t_2419 = heff_intShow(heff_strLength(heff_dup(v_s_2418)));
        V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecache_2efreezeDef_str1), v_s_2418));
        V v_x2_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_get(v_o_243, LBL_key), v_hashes_240));
        V v_s_2423;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nothing: {
          v_s_2423 = ((V)&g_heff_2ecache_2efreezeDef_str2);
          break;
        }
        case TAG_Just: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          heff_take_n(v_x2_2421, 1ULL, 1);
          v_s_2423 = v_x_2422;
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        V v_t_2424 = heff_intShow(heff_strLength(heff_dup(v_s_2423)));
        V v_t_2425 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ecache_2efreezeDef_str3), v_s_2423));
        V v_t_2426 = heff_intShow(heff_get(heff_dup(v_sp_246), LBL_start));
        V v_t_2427 = heff_intShow(heff_get(v_sp_246, LBL_end));
        V v_x2_2428 = ({ V b_0 = heff_get(heff_dup(v_e_2414), LBL_tySyntax); V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2eserial_2eencodeTypeF_24s905585727x233380302(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2431;
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_Nil: {
          v_t_2431 = ((V)&g_heff_2ecache_2efreezeDef_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2429 = heff_field(v_x2_2428, 0);
          V v_xs_2430 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 3ULL, 2);
          v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecache_2efreezeDef_str5); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2428);
        }
        V v_x2_2432 = (g_heff_2eserial_2eencodeTermF_24s1949627523x1369233217(heff_get(v_e_2414, LBL_syntax), NTAG(TAG_Nil)));
        V v_t_2435;
        switch (heff_tag_of(v_x2_2432)) {
        case TAG_Nil: {
          v_t_2435 = ((V)&g_heff_2ecache_2efreezeDef_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2433 = heff_field(v_x2_2432, 0);
          V v_xs_2434 = heff_field(v_x2_2432, 1);
          heff_take_n(v_x2_2432, 3ULL, 2);
          v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecache_2efreezeDef_str7); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2432);
        }
        V v_t_2436 = heff_tag_at(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
        V v_t_2437 = heff_tag_at(v_ru_24x32_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2427, heff_tag(TAG_Cons, 2, (V[]){v_t_2431, v_t_2436})});
        V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_tag(TAG_Cons, 2, (V[]){v_t_2426, v_t_2437})});
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, heff_tag(TAG_Cons, 2, (V[]){v_t_2420, v_t_2438})});
        return heff_tag_at(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){v_t_2439});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecache_2efreezeDef_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecache_2efreezeDef(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecache_2ezipCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2ezipCa_entry, 2, 0};

V g_heff_2ecache_2ezipCa(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2ecache_2ezipCa(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecache_2ezipCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2ezipCa(a[0], a[1]);
}
Clo g_heff_2ecache_2eallJust_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2eallJust_entry, 1, 0};

V g_heff_2ecache_2eallJust(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_x2_244 = (g_heff_2ecache_2eallJust(v_x12_242));
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ys_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_ys_245})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecache_2eallJust_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2eallJust(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2efreeze_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2ecache_2efreeze_lam0(V self, V *args);
V g_heff_2ecache_2efreeze_lam1(V self, V *args);
V g_heff_2ecache_2efreeze_lam2(V self, V *args);
Clo g_heff_2ecache_2efreeze_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2efreeze_entry, 4, 0};

V g_heff_2ecache_2efreeze(V v_hashes_240, V v_done_241, V v_s_242, V v_c_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_243), LBL_top), LBL_spans);
  V v_t_245 = (g_heff_2ecache_2ezipCa(heff_get(heff_dup(v_c_243), LBL_own), v_t_244));
  V v_t_247 = (g_list_2emap(heff_clo(g_heff_2ecache_2efreeze_lam0, 1, 2, (V[]){heff_dup(v_hashes_240), heff_dup(v_c_243)}), v_t_245));
  V v_t_248 = (g_heff_2ecache_2eallJust(v_t_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_s_242);
    heff_drop(v_c_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_defs_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(g_heff_2ecache_2eversion_get())));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str0), heff_dup(g_heff_2ecache_2eversion_get())));
    V v_s_2412 = heff_get(heff_dup(v_s_242), LBL_module);
    V v_t_2413 = heff_intShow(heff_strLength(heff_dup(v_s_2412)));
    V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str1), v_s_2412));
    V v_s_2415 = (g_heff_2ecache_2ehashGo(heff_get(heff_dup(v_c_243), LBL_source), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
    V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str2), v_s_2415));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, (g_heff_2ecache_2efreezeFix(heff_get(heff_dup(v_c_243), LBL_fixities)))});
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})});
    V v_t_2420 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_s_242), LBL_implicit), heff_get(heff_dup(v_s_242), LBL_source)));
    V v_t_2421 = ({ V b_0 = heff_get(v_s_242, LBL_renames); V a_1 = v_t_2420; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_imps_2422 = heff_get(v_t_2421, LBL_imports);
    V v_t_2423 = (g_list_2emap_24s1821466936x1723477761(v_imps_2422));
    V v_xs_2424 = (g_heff_2edriver_2enubStrD(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), ({ V a_0 = heff_clo(g_heff_2ecache_2efreeze_lam1, 2, 1, (V[]){heff_dup(v_done_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; })});
    V v_xs_2439 = (g_heff_2ecache_2eneedsOf(v_c_243));
    V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2439));
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
    V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_2440), ({ V a_0 = heff_clo(g_heff_2ecache_2efreeze_lam2, 2, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2441; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; })});
    V v_t_2457 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_defs_249));
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_249));
    V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_2457), ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2458; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2458); r_; })});
    V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2459));
    V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2460));
    V v_x2_2462 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2461));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2ecache_2efreeze_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2ecache_2efreeze_str9); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_tag_at(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2465});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecache_2efreeze_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecache_2efreeze(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecache_2efreeze_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_243; V a_2 = v_p_246; V r_ = (g_heff_2ecache_2efreezeDef(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
V g_heff_2ecache_2efreeze_lam1(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_done_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_x_2428), ({ V a_0 = v_done_241; V a_1 = v_x_2428; V r_ = (g_heff_2ecache_2ensOf(a_0, a_1)); heff_drop(v_done_241); r_; })});
  V v_t_2437;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_a_2430 = heff_field(v_x1_2429, 0);
    V v_b_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    V v_t_2432 = heff_intShow(heff_strLength(heff_dup(v_a_2430)));
    V v_t_2433 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str3), v_a_2430));
    V v_t_2434 = heff_intShow(heff_strLength(heff_dup(v_b_2431)));
    V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str4), v_b_2431));
    V v_t_2436 = heff_tag_at(v_ru_24x1_2429_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){v_t_2433, v_t_2436});
    break;
  }
  default: heff_nomatch(v_x1_2429);
  }
  return (g_prelude_2e_2b_2b(v_t_2437, v_acc_2427));
}
V g_heff_2ecache_2efreeze_lam2(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_x_2443 = args[1];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2444 = ({ V a_0 = heff_dup(v_x_2443); V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2446;
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_Nothing: {
    v_t_2446 = ((V)&g_heff_2ecache_2efreeze_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    heff_take_n(v_x2_2444, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x2_2444);
  }
  V v_x1_2447 = heff_tag(TAG_MkPair, 2, (V[]){v_x_2443, v_t_2446});
  V v_t_2455;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_MkPair: {
    V v_a_2448 = heff_field(v_x1_2447, 0);
    V v_b_2449 = heff_field(v_x1_2447, 1);
    V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
    V v_t_2450 = heff_intShow(heff_strLength(heff_dup(v_a_2448)));
    V v_t_2451 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str6), v_a_2448));
    V v_t_2452 = heff_intShow(heff_strLength(heff_dup(v_b_2449)));
    V v_t_2453 = heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2ecache_2efreeze_str7), v_b_2449));
    V v_t_2454 = heff_tag_at(v_ru_24x1_2447_24MkPair, TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){v_t_2451, v_t_2454});
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  return (g_prelude_2e_2b_2b(v_t_2455, v_acc_2442));
}
V g_heff_2ecache_2emeltFixGroup_lam0(V self, V *args);
Clo g_heff_2ecache_2emeltFixGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2emeltFixGroup_entry, 2, 0};

V g_heff_2ecache_2emeltFixGroup(V v_s_240, V v_i_241) {
top: ;
  V v_x1_242 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_243, 0);
      V v_i_245 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_x1_246 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_245));
      V v_x1_2411;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_242_24Just, 1);
        v_x1_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x11_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        switch (heff_tag_of(v_x11_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x11_247, 0);
          V v_i_249 = heff_field(v_x11_247, 1);
          heff_take_n(v_x11_247, 3ULL, 2);
          V v_x_2410 = (g_heff_2esurface_2eintOfText(v_x_248));
          v_x1_2411 = heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_i_249})});
          break;
        }
        default: heff_nomatch(v_x11_247);
        }
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2412 = heff_field(v_x1_2411, 0);
        V v_ru_24x1_2411_24Just = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x11_2412, 0);
          V v_i_2414 = heff_field(v_x11_2412, 1);
          V v_ru_24x11_2412_24MkPair = heff_take_reuse_n(v_x11_2412, 3ULL, 2);
          V v_x1_2415 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_2414));
          V v_x1_2420;
          switch (heff_tag_of(v_x1_2415)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
            heff_drop_cell(v_ru_24x1_2411_24Just, 1);
            v_x1_2420 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_x1_2415, 0);
            heff_take_n(v_x1_2415, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_x_2417 = heff_field(v_x11_2416, 0);
              V v_i_2418 = heff_field(v_x11_2416, 1);
              heff_take_n(v_x11_2416, 3ULL, 2);
              V v_x_2419 = (g_heff_2esurface_2eintOfText(v_x_2417));
              v_x1_2420 = heff_tag_at(v_ru_24x1_2411_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_i_2418})});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_x1_2415);
          }
          V v_x1_2425;
          switch (heff_tag_of(v_x1_2420)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            v_x1_2425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x11_2421 = heff_field(v_x1_2420, 0);
            heff_take_n(v_x1_2420, 1ULL, 1);
            switch (heff_tag_of(v_x11_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x11_2421, 0);
              V v_i_2423 = heff_field(v_x11_2421, 1);
              heff_take_n(v_x11_2421, 3ULL, 2);
              v_x1_2425 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emeltFixGroup_lam0, 1, 1, (V[]){v_s_240}), v_x_2422, v_i_2423));
              break;
            }
            default: heff_nomatch(v_x11_2421);
            }
            break;
          }
          default: heff_nomatch(v_x1_2420);
          }
          switch (heff_tag_of(v_x1_2425)) {
          case TAG_Nothing: {
            heff_drop(v_x_244);
            heff_drop(v_x_2413);
            heff_drop_cell(v_ru_24x11_2412_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x11_2426 = heff_field(v_x1_2425, 0);
            V v_ru_24x1_2425_24Just = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
            switch (heff_tag_of(v_x11_2426)) {
            case TAG_MkPair: {
              V v_x_2427 = heff_field(v_x11_2426, 0);
              V v_i_2428 = heff_field(v_x11_2426, 1);
              heff_take_n(v_x11_2426, 3ULL, 2);
              if (heff_intEq_c(heff_dup(v_x_2413), MK_INT(0LL))) {
                heff_drop(v_x_2413);
                V v_t_2430 = heff_rec(3, shape_id__assoc__ops, (V[]){v_x_244, NTAG(TAG_AssocLeft), v_x_2427});
                return heff_tag_at(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_i_2428})});
              } else {
                if (heff_intEq_c(heff_dup(v_x_2413), MK_INT(1LL))) {
                  heff_drop(v_x_2413);
                  V v_t_2432 = heff_rec(3, shape_id__assoc__ops, (V[]){v_x_244, NTAG(TAG_AssocRight), v_x_2427});
                  return heff_tag_at(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_i_2428})});
                } else {
                  if (heff_intEq_c(v_x_2413, MK_INT(2LL))) {
                    V v_t_2434 = heff_rec(3, shape_id__assoc__ops, (V[]){v_x_244, NTAG(TAG_AssocNone), v_x_2427});
                    return heff_tag_at(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2434, v_i_2428})});
                  } else {
                    heff_drop(v_x_244);
                    heff_drop_cell(v_ru_24x11_2412_24MkPair, 2);
                    heff_drop_cell(v_ru_24x1_2425_24Just, 1);
                    heff_drop(v_x_2427);
                    heff_drop(v_i_2428);
                    return NTAG(TAG_Nothing);
                  }
                }
              }
            }
            default: return heff_nomatch(v_x11_2426);
            }
          }
          default: return heff_nomatch(v_x1_2425);
          }
        }
        default: return heff_nomatch(v_x11_2412);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ecache_2emeltFixGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2emeltFixGroup(a[0], a[1]);
}
V g_heff_2ecache_2emeltFixGroup_lam0(V self, V *args) {
  V v_j3_2424 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eserial_2etakeStr(v_s_240, v_j3_2424));
}
V g_heff_2ecache_2emeltFix_lam0(V self, V *args);
V g_heff_2ecache_2emeltFix_lam1(V self, V *args);
Clo g_heff_2ecache_2emeltFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2emeltFix_entry, 2, 0};

V g_heff_2ecache_2emeltFix(V v_s_240, V v_i_241) {
top: ;
  V v_x1_242 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_241));
  V v_x1_247;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nothing: {
    v_x1_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_243, 0);
      V v_i_245 = heff_field(v_x11_243, 1);
      heff_take_n(v_x11_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esurface_2eintOfText(v_x_244));
      v_x1_247 = heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_i_245})});
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_x1_2412;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nothing: {
    v_x1_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x11_248, 0);
      V v_i_2410 = heff_field(v_x11_248, 1);
      heff_take_n(v_x11_248, 3ULL, 2);
      v_x1_2412 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emeltFix_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), v_x_249, v_i_2410));
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_x1_2412, 0);
    V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x11_2413, 0);
      V v_i_2415 = heff_field(v_x11_2413, 1);
      V v_ru_24x11_2413_24MkPair = heff_take_reuse_n(v_x11_2413, 3ULL, 2);
      V v_x1_2416 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_2415));
      V v_x1_2421;
      switch (heff_tag_of(v_x1_2416)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2412_24Just, 1);
        v_x1_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x11_2417 = heff_field(v_x1_2416, 0);
        heff_take_n(v_x1_2416, 1ULL, 1);
        switch (heff_tag_of(v_x11_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x11_2417, 0);
          V v_i_2419 = heff_field(v_x11_2417, 1);
          heff_take_n(v_x11_2417, 3ULL, 2);
          V v_x_2420 = (g_heff_2esurface_2eintOfText(v_x_2418));
          v_x1_2421 = heff_tag_at(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2420, v_i_2419})});
          break;
        }
        default: heff_nomatch(v_x11_2417);
        }
        break;
      }
      default: heff_nomatch(v_x1_2416);
      }
      V v_x1_2435;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x11_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        switch (heff_tag_of(v_x11_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x11_2422, 0);
          V v_i_2424 = heff_field(v_x11_2422, 1);
          heff_take_n(v_x11_2422, 3ULL, 2);
          v_x1_2435 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emeltFix_lam1, 1, 1, (V[]){v_s_240}), v_x_2423, v_i_2424));
          break;
        }
        default: heff_nomatch(v_x11_2422);
        }
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nothing: {
        heff_drop(v_x_2414);
        heff_drop_cell(v_ru_24x11_2413_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2436 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24Just = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        switch (heff_tag_of(v_x11_2436)) {
        case TAG_MkPair: {
          V v_x_2437 = heff_field(v_x11_2436, 0);
          V v_i_2438 = heff_field(v_x11_2436, 1);
          heff_take_n(v_x11_2436, 3ULL, 2);
          V v_t_2439 = heff_tag_at(v_ru_24x11_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_rec(2, shape_groups__above, (V[]){v_x_2414, v_x_2437}), v_i_2438});
          return heff_tag_at(v_ru_24x1_2435_24Just, TAG_Just, 1, (V[]){v_t_2439});
        }
        default: return heff_nomatch(v_x11_2436);
        }
      }
      default: return heff_nomatch(v_x1_2435);
      }
    }
    default: return heff_nomatch(v_x11_2413);
    }
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2ecache_2emeltFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2emeltFix(a[0], a[1]);
}
V g_heff_2ecache_2emeltFix_lam0(V self, V *args) {
  V v_j_2411 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecache_2emeltFixGroup(v_s_240, v_j_2411));
}
V g_heff_2ecache_2emeltFix_lam1(V self, V *args) {
  V v_j2_2425 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2426 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_240), v_j2_2425));
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2427 = heff_field(v_x1_2426, 0);
    V v_ru_24x1_2426_24Just = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_MkPair: {
      V v_x_2428 = heff_field(v_x11_2427, 0);
      V v_i_2429 = heff_field(v_x11_2427, 1);
      V v_ru_24x11_2427_24MkPair = heff_take_reuse_n(v_x11_2427, 3ULL, 2);
      V v_x1_2430 = (g_heff_2eserial_2etakeStr(v_s_240, v_i_2429));
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2426_24Just, 1);
        heff_drop(v_x_2428);
        heff_drop_cell(v_ru_24x11_2427_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        switch (heff_tag_of(v_x11_2431)) {
        case TAG_MkPair: {
          V v_x_2432 = heff_field(v_x11_2431, 0);
          V v_i_2433 = heff_field(v_x11_2431, 1);
          heff_take_n(v_x11_2431, 3ULL, 2);
          V v_t_2434 = heff_tag_at(v_ru_24x11_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_rec(2, shape_tighter__looser, (V[]){v_x_2428, v_x_2432}), v_i_2433});
          return heff_tag_at(v_ru_24x1_2426_24Just, TAG_Just, 1, (V[]){v_t_2434});
        }
        default: return heff_nomatch(v_x11_2431);
        }
      }
      default: return heff_nomatch(v_x1_2430);
      }
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2emeltDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2ecache_2emeltDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2emeltDef_entry, 2, 0};

V g_heff_2ecache_2emeltDef(V v_s_240, V v_i_241) {
top: ;
  V v_x1_242 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_243, 0);
      V v_i_245 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_x1_246 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_240), v_i_245));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop_cell(v_ru_24x1_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24Just = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        switch (heff_tag_of(v_x11_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x11_247, 0);
          V v_i_249 = heff_field(v_x11_247, 1);
          V v_ru_24x11_247_24MkPair = heff_take_reuse_n(v_x11_247, 3ULL, 2);
          V v_x1_2410 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_240), v_i_249));
          switch (heff_tag_of(v_x1_2410)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x1_242_24Just, 1);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
            heff_drop_cell(v_ru_24x1_246_24Just, 1);
            heff_drop(v_x_248);
            heff_drop_cell(v_ru_24x11_247_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x11_2411 = heff_field(v_x1_2410, 0);
            V v_ru_24x1_2410_24Just = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
            switch (heff_tag_of(v_x11_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x11_2411, 0);
              V v_i_2413 = heff_field(v_x11_2411, 1);
              heff_take_n(v_x11_2411, 3ULL, 2);
              V v_x1_2414 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_2413));
              V v_x1_2419;
              switch (heff_tag_of(v_x1_2414)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x1_242_24Just, 1);
                v_x1_2419 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x11_2415 = heff_field(v_x1_2414, 0);
                heff_take_n(v_x1_2414, 1ULL, 1);
                switch (heff_tag_of(v_x11_2415)) {
                case TAG_MkPair: {
                  V v_x_2416 = heff_field(v_x11_2415, 0);
                  V v_i_2417 = heff_field(v_x11_2415, 1);
                  heff_take_n(v_x11_2415, 3ULL, 2);
                  V v_x_2418 = (g_heff_2esurface_2eintOfText(v_x_2416));
                  v_x1_2419 = heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2418, v_i_2417})});
                  break;
                }
                default: heff_nomatch(v_x11_2415);
                }
                break;
              }
              default: heff_nomatch(v_x1_2414);
              }
              switch (heff_tag_of(v_x1_2419)) {
              case TAG_Nothing: {
                heff_drop(v_s_240);
                heff_drop(v_x_244);
                heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
                heff_drop_cell(v_ru_24x1_246_24Just, 1);
                heff_drop(v_x_248);
                heff_drop_cell(v_ru_24x11_247_24MkPair, 2);
                heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                heff_drop(v_x_2412);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x11_2420 = heff_field(v_x1_2419, 0);
                heff_take_n(v_x1_2419, 1ULL, 1);
                switch (heff_tag_of(v_x11_2420)) {
                case TAG_MkPair: {
                  V v_x_2421 = heff_field(v_x11_2420, 0);
                  V v_i_2422 = heff_field(v_x11_2420, 1);
                  heff_take_n(v_x11_2420, 3ULL, 2);
                  V v_x1_2423 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_2422));
                  V v_x1_2428;
                  switch (heff_tag_of(v_x1_2423)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
                    heff_drop_cell(v_ru_24x1_246_24Just, 1);
                    v_x1_2428 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x11_2424 = heff_field(v_x1_2423, 0);
                    heff_take_n(v_x1_2423, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2424)) {
                    case TAG_MkPair: {
                      V v_x_2425 = heff_field(v_x11_2424, 0);
                      V v_i_2426 = heff_field(v_x11_2424, 1);
                      heff_take_n(v_x11_2424, 3ULL, 2);
                      V v_x_2427 = (g_heff_2esurface_2eintOfText(v_x_2425));
                      v_x1_2428 = heff_tag_at(v_ru_24x1_246_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_i_2426})});
                      break;
                    }
                    default: heff_nomatch(v_x11_2424);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x1_2423);
                  }
                  switch (heff_tag_of(v_x1_2428)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_240);
                    heff_drop(v_x_244);
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x11_247_24MkPair, 2);
                    heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                    heff_drop(v_x_2412);
                    heff_drop(v_x_2421);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x11_2429 = heff_field(v_x1_2428, 0);
                    heff_take_n(v_x1_2428, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2429)) {
                    case TAG_MkPair: {
                      V v_x_2430 = heff_field(v_x11_2429, 0);
                      V v_i_2431 = heff_field(v_x11_2429, 1);
                      heff_take_n(v_x11_2429, 3ULL, 2);
                      V v_t_2432 = (g_heff_2eserial_2edkOf(heff_dup(v_s_240)));
                      V v_x1_2433 = heff_tr(heff_apply(heff_get(v_t_2432, LBL_ty), 1, (V[]){v_i_2431}));
                      switch (heff_tag_of(v_x1_2433)) {
                      case TAG_Nothing: {
                        heff_drop(v_s_240);
                        heff_drop(v_x_244);
                        heff_drop(v_x_248);
                        heff_drop_cell(v_ru_24x11_247_24MkPair, 2);
                        heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                        heff_drop(v_x_2412);
                        heff_drop(v_x_2421);
                        heff_drop(v_x_2430);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x11_2434 = heff_field(v_x1_2433, 0);
                        heff_take_n(v_x1_2433, 1ULL, 1);
                        switch (heff_tag_of(v_x11_2434)) {
                        case TAG_MkPair: {
                          V v_x_2435 = heff_field(v_x11_2434, 0);
                          V v_i_2436 = heff_field(v_x11_2434, 1);
                          heff_take_n(v_x11_2434, 3ULL, 2);
                          V v_t_2437 = (g_heff_2eserial_2edkOf(v_s_240));
                          V v_x1_2438 = heff_tr(heff_apply(heff_get(v_t_2437, LBL_el), 1, (V[]){v_i_2436}));
                          switch (heff_tag_of(v_x1_2438)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_244);
                            heff_drop(v_x_248);
                            heff_drop_cell(v_ru_24x11_247_24MkPair, 2);
                            heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                            heff_drop(v_x_2412);
                            heff_drop(v_x_2421);
                            heff_drop(v_x_2430);
                            heff_drop(v_x_2435);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x11_2439 = heff_field(v_x1_2438, 0);
                            heff_take_n(v_x1_2438, 1ULL, 1);
                            switch (heff_tag_of(v_x11_2439)) {
                            case TAG_MkPair: {
                              V v_x_2440 = heff_field(v_x11_2439, 0);
                              V v_i_2441 = heff_field(v_x11_2439, 1);
                              heff_take_n(v_x11_2439, 3ULL, 2);
                              V v_t_2442 = heff_rec(5, shape_name__key__span__ty__body, (V[]){v_x_244, heff_dup(v_x_248), heff_rec(2, shape_start__end, (V[]){v_x_2421, v_x_2430}), v_x_2435, v_x_2440});
                              V v_t_2443 = heff_strAppend(v_x_248, heff_strAppend(((V)&g_heff_2ecache_2emeltDef_str0), v_x_2412));
                              V v_t_2444 = heff_tag_at(v_ru_24x11_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2442, v_t_2443}), v_i_2441});
                              return heff_tag_at(v_ru_24x1_2410_24Just, TAG_Just, 1, (V[]){v_t_2444});
                            }
                            default: return heff_nomatch(v_x11_2439);
                            }
                          }
                          default: return heff_nomatch(v_x1_2438);
                          }
                        }
                        default: return heff_nomatch(v_x11_2434);
                        }
                      }
                      default: return heff_nomatch(v_x1_2433);
                      }
                    }
                    default: return heff_nomatch(v_x11_2429);
                    }
                  }
                  default: return heff_nomatch(v_x1_2428);
                  }
                }
                default: return heff_nomatch(v_x11_2420);
                }
              }
              default: return heff_nomatch(v_x1_2419);
              }
            }
            default: return heff_nomatch(v_x11_2411);
            }
          }
          default: return heff_nomatch(v_x1_2410);
          }
        }
        default: return heff_nomatch(v_x11_247);
        }
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ecache_2emeltDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecache_2emeltDef(a[0], a[1]);
}
Clo g_heff_2ecache_2epairsHold_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2epairsHold_entry, 2, 0};

V g_heff_2ecache_2epairsHold(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecache_2epairsHold_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecache_2epairsHold(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2emelt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2emelt_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2emelt_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecache_2emelt_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
V g_heff_2ecache_2emelt_lam0(V self, V *args);
V g_heff_2ecache_2emelt_lam1(V self, V *args);
V g_heff_2ecache_2emelt_lam2(V self, V *args);
V g_heff_2ecache_2emelt_lam3(V self, V *args);
V g_heff_2ecache_2emelt_lam4(V self, V *args);
Clo g_heff_2ecache_2emelt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecache_2emelt_entry, 4, 0};

V g_heff_2ecache_2emelt(V v_hashes_240, V v_done_241, V v_s_242, V v_text_243) {
top: ;
  V v_x1_244 = (g_heff_2eserial_2etakeStr(heff_dup(v_text_243), MK_INT(0LL)));
  V v_x1_24112;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nothing: {
    heff_drop(v_s_242);
    heff_drop(v_text_243);
    v_x1_24112 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Just = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x11_245, 0);
      V v_i_247 = heff_field(v_x11_245, 1);
      V v_ru_24x11_245_24MkPair = heff_take_reuse_n(v_x11_245, 3ULL, 2);
      V v_t_249;
      if (heff_strEq_c(v_x_246, heff_dup(g_heff_2ecache_2eversion_get()))) {
        v_t_249 = NTAG(TAG_False);
      } else {
        v_t_249 = NTAG(TAG_True);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_s_242);
        heff_drop(v_text_243);
        heff_drop_cell(v_ru_24x1_244_24Just, 1);
        heff_drop(v_i_247);
        heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
        v_x1_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_False: {
        V v_x1_2410 = (g_heff_2eserial_2etakeStr(heff_dup(v_text_243), v_i_247));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_Nothing: {
          heff_drop(v_s_242);
          heff_drop(v_text_243);
          heff_drop_cell(v_ru_24x1_244_24Just, 1);
          heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
          v_x1_24112 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x11_2411 = heff_field(v_x1_2410, 0);
          V v_ru_24x1_2410_24Just = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
          switch (heff_tag_of(v_x11_2411)) {
          case TAG_MkPair: {
            V v_x_2412 = heff_field(v_x11_2411, 0);
            V v_i_2413 = heff_field(v_x11_2411, 1);
            V v_ru_24x11_2411_24MkPair = heff_take_reuse_n(v_x11_2411, 3ULL, 2);
            V v_t_2415;
            if (heff_strEq_c(v_x_2412, heff_get(heff_dup(v_s_242), LBL_module))) {
              v_t_2415 = NTAG(TAG_False);
            } else {
              v_t_2415 = NTAG(TAG_True);
            }
            switch (heff_tag_of(v_t_2415)) {
            case TAG_True: {
              heff_drop(v_s_242);
              heff_drop(v_text_243);
              heff_drop_cell(v_ru_24x1_244_24Just, 1);
              heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
              heff_drop_cell(v_ru_24x1_2410_24Just, 1);
              heff_drop(v_i_2413);
              heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
              v_x1_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_False: {
              V v_x1_2416 = (g_heff_2eserial_2etakeStr(heff_dup(v_text_243), v_i_2413));
              switch (heff_tag_of(v_x1_2416)) {
              case TAG_Nothing: {
                heff_drop(v_s_242);
                heff_drop(v_text_243);
                heff_drop_cell(v_ru_24x1_244_24Just, 1);
                heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                v_x1_24112 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x11_2417 = heff_field(v_x1_2416, 0);
                V v_ru_24x1_2416_24Just = heff_take_reuse_n(v_x1_2416, 1ULL, 1);
                switch (heff_tag_of(v_x11_2417)) {
                case TAG_MkPair: {
                  V v_x_2418 = heff_field(v_x11_2417, 0);
                  V v_i_2419 = heff_field(v_x11_2417, 1);
                  V v_ru_24x11_2417_24MkPair = heff_take_reuse_n(v_x11_2417, 3ULL, 2);
                  V v_t_2420 = (g_heff_2ecache_2ehashGo(heff_get(heff_dup(v_s_242), LBL_source), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
                  V v_t_2422;
                  if (heff_strEq_c(v_x_2418, v_t_2420)) {
                    v_t_2422 = NTAG(TAG_False);
                  } else {
                    v_t_2422 = NTAG(TAG_True);
                  }
                  switch (heff_tag_of(v_t_2422)) {
                  case TAG_True: {
                    heff_drop(v_s_242);
                    heff_drop(v_text_243);
                    heff_drop_cell(v_ru_24x1_244_24Just, 1);
                    heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                    heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                    heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                    heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                    heff_drop(v_i_2419);
                    heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                    v_x1_24112 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_False: {
                    V v_x1_2423 = (g_heff_2ecache_2emeltFix(heff_dup(v_text_243), v_i_2419));
                    switch (heff_tag_of(v_x1_2423)) {
                    case TAG_Nothing: {
                      heff_drop(v_s_242);
                      heff_drop(v_text_243);
                      heff_drop_cell(v_ru_24x1_244_24Just, 1);
                      heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                      heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                      heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                      heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                      heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                      v_x1_24112 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_x11_2424 = heff_field(v_x1_2423, 0);
                      V v_ru_24x1_2423_24Just = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
                      switch (heff_tag_of(v_x11_2424)) {
                      case TAG_MkPair: {
                        V v_x_2425 = heff_field(v_x11_2424, 0);
                        V v_i_2426 = heff_field(v_x11_2424, 1);
                        heff_take_n(v_x11_2424, 3ULL, 2);
                        V v_x1_2427 = (g_heff_2eserial_2etakeWord(heff_dup(v_text_243), v_i_2426));
                        V v_x1_2432;
                        switch (heff_tag_of(v_x1_2427)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x1_244_24Just, 1);
                          v_x1_2432 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x11_2428 = heff_field(v_x1_2427, 0);
                          heff_take_n(v_x1_2427, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2428)) {
                          case TAG_MkPair: {
                            V v_x_2429 = heff_field(v_x11_2428, 0);
                            V v_i_2430 = heff_field(v_x11_2428, 1);
                            heff_take_n(v_x11_2428, 3ULL, 2);
                            V v_x_2431 = (g_heff_2esurface_2eintOfText(v_x_2429));
                            v_x1_2432 = heff_tag_at(v_ru_24x1_244_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2431, v_i_2430})});
                            break;
                          }
                          default: heff_nomatch(v_x11_2428);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x1_2427);
                        }
                        V v_x1_2446;
                        switch (heff_tag_of(v_x1_2432)) {
                        case TAG_Nothing: {
                          v_x1_2446 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x11_2433 = heff_field(v_x1_2432, 0);
                          heff_take_n(v_x1_2432, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2433)) {
                          case TAG_MkPair: {
                            V v_x_2434 = heff_field(v_x11_2433, 0);
                            V v_i_2435 = heff_field(v_x11_2433, 1);
                            heff_take_n(v_x11_2433, 3ULL, 2);
                            v_x1_2446 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emelt_lam0, 1, 1, (V[]){heff_dup(v_text_243)}), v_x_2434, v_i_2435));
                            break;
                          }
                          default: heff_nomatch(v_x11_2433);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x1_2432);
                        }
                        switch (heff_tag_of(v_x1_2446)) {
                        case TAG_Nothing: {
                          heff_drop(v_s_242);
                          heff_drop(v_text_243);
                          heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                          heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                          heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                          heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                          heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                          heff_drop_cell(v_ru_24x1_2423_24Just, 1);
                          heff_drop(v_x_2425);
                          v_x1_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x11_2447 = heff_field(v_x1_2446, 0);
                          heff_take_n(v_x1_2446, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2447)) {
                          case TAG_MkPair: {
                            V v_x_2448 = heff_field(v_x11_2447, 0);
                            V v_i_2449 = heff_field(v_x11_2447, 1);
                            heff_take_n(v_x11_2447, 3ULL, 2);
                            V v_t_2454 = (g_heff_2ecache_2epairsHold(heff_clo(g_heff_2ecache_2emelt_lam1, 1, 1, (V[]){heff_dup(v_done_241)}), v_x_2448));
                            V v_x1_2462;
                            switch (heff_tag_of(v_t_2454)) {
                            case TAG_True: {
                              V v_t_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2448; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_2448); r_; });
                              V v_t_2456 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_s_242), LBL_implicit), heff_get(heff_dup(v_s_242), LBL_source)));
                              V v_t_2457 = ({ V b_0 = heff_get(v_s_242, LBL_renames); V a_1 = v_t_2456; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
                              V v_imps_2458 = heff_get(v_t_2457, LBL_imports);
                              V v_t_2459 = (g_list_2emap_24s1821466936x1723477761(v_imps_2458));
                              V v_xs_2460 = (g_heff_2edriver_2enubStrD(v_t_2459));
                              V v_t_2461 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2460; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
                              v_x1_2462 = heff_intEq(v_t_2455, v_t_2461);
                              break;
                            }
                            case TAG_False: {
                              heff_drop(v_s_242);
                              heff_drop(v_x_2448);
                              v_x1_2462 = NTAG(TAG_False);
                              break;
                            }
                            default: heff_nomatch(v_t_2454);
                            }
                            V v_t_2463;
                            switch (heff_tag_of(v_x1_2462)) {
                            case TAG_True: {
                              v_t_2463 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_False: {
                              v_t_2463 = NTAG(TAG_True);
                              break;
                            }
                            default: heff_nomatch(v_x1_2462);
                            }
                            switch (heff_tag_of(v_t_2463)) {
                            case TAG_True: {
                              heff_drop(v_text_243);
                              heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                              heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                              heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                              heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                              heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                              heff_drop_cell(v_ru_24x1_2423_24Just, 1);
                              heff_drop(v_x_2425);
                              heff_drop(v_i_2449);
                              v_x1_24112 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_False: {
                              V v_x1_2464 = (g_heff_2eserial_2etakeWord(heff_dup(v_text_243), v_i_2449));
                              V v_x1_2469;
                              switch (heff_tag_of(v_x1_2464)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x11_245_24MkPair, 2);
                                heff_drop_cell(v_ru_24x1_2410_24Just, 1);
                                v_x1_2469 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x11_2465 = heff_field(v_x1_2464, 0);
                                heff_take_n(v_x1_2464, 1ULL, 1);
                                switch (heff_tag_of(v_x11_2465)) {
                                case TAG_MkPair: {
                                  V v_x_2466 = heff_field(v_x11_2465, 0);
                                  V v_i_2467 = heff_field(v_x11_2465, 1);
                                  heff_take_n(v_x11_2465, 3ULL, 2);
                                  V v_x_2468 = (g_heff_2esurface_2eintOfText(v_x_2466));
                                  v_x1_2469 = heff_tag_at(v_ru_24x1_2410_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2468, v_i_2467})});
                                  break;
                                }
                                default: heff_nomatch(v_x11_2465);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x1_2464);
                              }
                              V v_x1_2483;
                              switch (heff_tag_of(v_x1_2469)) {
                              case TAG_Nothing: {
                                v_x1_2483 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x11_2470 = heff_field(v_x1_2469, 0);
                                heff_take_n(v_x1_2469, 1ULL, 1);
                                switch (heff_tag_of(v_x11_2470)) {
                                case TAG_MkPair: {
                                  V v_x_2471 = heff_field(v_x11_2470, 0);
                                  V v_i_2472 = heff_field(v_x11_2470, 1);
                                  heff_take_n(v_x11_2470, 3ULL, 2);
                                  v_x1_2483 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emelt_lam2, 1, 1, (V[]){heff_dup(v_text_243)}), v_x_2471, v_i_2472));
                                  break;
                                }
                                default: heff_nomatch(v_x11_2470);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x1_2469);
                              }
                              switch (heff_tag_of(v_x1_2483)) {
                              case TAG_Nothing: {
                                heff_drop(v_text_243);
                                heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                                heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                                heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                                heff_drop_cell(v_ru_24x1_2423_24Just, 1);
                                heff_drop(v_x_2425);
                                v_x1_24112 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x11_2484 = heff_field(v_x1_2483, 0);
                                heff_take_n(v_x1_2483, 1ULL, 1);
                                switch (heff_tag_of(v_x11_2484)) {
                                case TAG_MkPair: {
                                  V v_x_2485 = heff_field(v_x11_2484, 0);
                                  V v_i_2486 = heff_field(v_x11_2484, 1);
                                  heff_take_n(v_x11_2484, 3ULL, 2);
                                  V v_x1_2493 = ({ V a_0 = heff_clo(g_heff_2ecache_2emelt_lam3, 1, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = v_x_2485; V r_ = (g_heff_2ecache_2epairsHold(a_0, a_1)); heff_drop(v_x_2485); r_; });
                                  V v_t_2494;
                                  switch (heff_tag_of(v_x1_2493)) {
                                  case TAG_True: {
                                    v_t_2494 = NTAG(TAG_False);
                                    break;
                                  }
                                  case TAG_False: {
                                    v_t_2494 = NTAG(TAG_True);
                                    break;
                                  }
                                  default: heff_nomatch(v_x1_2493);
                                  }
                                  switch (heff_tag_of(v_t_2494)) {
                                  case TAG_True: {
                                    heff_drop(v_text_243);
                                    heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                                    heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                                    heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                                    heff_drop_cell(v_ru_24x1_2423_24Just, 1);
                                    heff_drop(v_x_2425);
                                    heff_drop(v_i_2486);
                                    v_x1_24112 = NTAG(TAG_Nothing);
                                    break;
                                  }
                                  case TAG_False: {
                                    V v_x1_2495 = (g_heff_2eserial_2etakeWord(heff_dup(v_text_243), v_i_2486));
                                    V v_x1_24100;
                                    switch (heff_tag_of(v_x1_2495)) {
                                    case TAG_Nothing: {
                                      heff_drop_cell(v_ru_24x11_2411_24MkPair, 2);
                                      heff_drop_cell(v_ru_24x1_2416_24Just, 1);
                                      v_x1_24100 = NTAG(TAG_Nothing);
                                      break;
                                    }
                                    case TAG_Just: {
                                      V v_x11_2496 = heff_field(v_x1_2495, 0);
                                      heff_take_n(v_x1_2495, 1ULL, 1);
                                      switch (heff_tag_of(v_x11_2496)) {
                                      case TAG_MkPair: {
                                        V v_x_2497 = heff_field(v_x11_2496, 0);
                                        V v_i_2498 = heff_field(v_x11_2496, 1);
                                        heff_take_n(v_x11_2496, 3ULL, 2);
                                        V v_x_2499 = (g_heff_2esurface_2eintOfText(v_x_2497));
                                        v_x1_24100 = heff_tag_at(v_ru_24x1_2416_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2499, v_i_2498})});
                                        break;
                                      }
                                      default: heff_nomatch(v_x11_2496);
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x1_2495);
                                    }
                                    V v_x1_24105;
                                    switch (heff_tag_of(v_x1_24100)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_text_243);
                                      v_x1_24105 = NTAG(TAG_Nothing);
                                      break;
                                    }
                                    case TAG_Just: {
                                      V v_x11_24101 = heff_field(v_x1_24100, 0);
                                      heff_take_n(v_x1_24100, 1ULL, 1);
                                      switch (heff_tag_of(v_x11_24101)) {
                                      case TAG_MkPair: {
                                        V v_x_24102 = heff_field(v_x11_24101, 0);
                                        V v_i_24103 = heff_field(v_x11_24101, 1);
                                        heff_take_n(v_x11_24101, 3ULL, 2);
                                        v_x1_24105 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2ecache_2emelt_lam4, 1, 1, (V[]){v_text_243}), v_x_24102, v_i_24103));
                                        break;
                                      }
                                      default: heff_nomatch(v_x11_24101);
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x1_24100);
                                    }
                                    switch (heff_tag_of(v_x1_24105)) {
                                    case TAG_Nothing: {
                                      heff_drop_cell(v_ru_24x11_2417_24MkPair, 2);
                                      heff_drop_cell(v_ru_24x1_2423_24Just, 1);
                                      heff_drop(v_x_2425);
                                      v_x1_24112 = NTAG(TAG_Nothing);
                                      break;
                                    }
                                    case TAG_Just: {
                                      V v_x11_24106 = heff_field(v_x1_24105, 0);
                                      heff_take_n(v_x1_24105, 1ULL, 1);
                                      switch (heff_tag_of(v_x11_24106)) {
                                      case TAG_MkPair: {
                                        V v_x_24107 = heff_field(v_x11_24106, 0);
                                        V v_i_24108 = heff_field(v_x11_24106, 1);
                                        heff_take_n(v_x11_24106, 3ULL, 2);
                                        V v_t_24109 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_24107)));
                                        V v_t_24110 = (g_list_2emap_24s1176007509x671449441(((V)&g_heff_2ecache_2emelt_str1), MK_INT(0LL), ((V)&g_heff_2ecache_2emelt_str2), ((V)&g_heff_2ecache_2emelt_str3), v_x_24107));
                                        V v_x_24111 = heff_rec(3, shape_fixities__defs__hashes, (V[]){v_x_2425, v_t_24109, v_t_24110});
                                        v_x1_24112 = heff_tag_at(v_ru_24x1_2423_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_24111, v_i_24108})});
                                        break;
                                      }
                                      default: heff_nomatch(v_x11_24106);
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x1_24105);
                                    }
                                    break;
                                  }
                                  default: heff_nomatch(v_t_2494);
                                  }
                                  break;
                                }
                                default: heff_nomatch(v_x11_2484);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x1_2483);
                              }
                              break;
                            }
                            default: heff_nomatch(v_t_2463);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x11_2447);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x1_2446);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x11_2424);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x1_2423);
                    }
                    break;
                  }
                  default: heff_nomatch(v_t_2422);
                  }
                  break;
                }
                default: heff_nomatch(v_x11_2417);
                }
                break;
              }
              default: heff_nomatch(v_x1_2416);
              }
              break;
            }
            default: heff_nomatch(v_t_2415);
            }
            break;
          }
          default: heff_nomatch(v_x11_2411);
          }
          break;
        }
        default: heff_nomatch(v_x1_2410);
        }
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x11_245);
    }
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_ru_24x1_24112_24Just = heff_take_reuse_n(v_x1_24112, 1ULL, 1);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_MkPair: {
      V v_th_24114 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 2);
      return heff_tag_at(v_ru_24x1_24112_24Just, TAG_Just, 1, (V[]){v_th_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2ecache_2emelt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecache_2emelt(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecache_2emelt_lam0(V self, V *args) {
  V v_j_2436 = args[0];
  V v_text_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2437 = (g_heff_2eserial_2etakeStr(heff_dup(v_text_243), v_j_2436));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nothing: {
    heff_drop(v_text_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2438 = heff_field(v_x1_2437, 0);
    V v_ru_24x1_2437_24Just = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_MkPair: {
      V v_x_2439 = heff_field(v_x11_2438, 0);
      V v_i_2440 = heff_field(v_x11_2438, 1);
      V v_ru_24x11_2438_24MkPair = heff_take_reuse_n(v_x11_2438, 3ULL, 2);
      V v_x1_2441 = (g_heff_2eserial_2etakeStr(v_text_243, v_i_2440));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2437_24Just, 1);
        heff_drop(v_x_2439);
        heff_drop_cell(v_ru_24x11_2438_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2442 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        switch (heff_tag_of(v_x11_2442)) {
        case TAG_MkPair: {
          V v_x_2443 = heff_field(v_x11_2442, 0);
          V v_i_2444 = heff_field(v_x11_2442, 1);
          heff_take_n(v_x11_2442, 3ULL, 2);
          V v_t_2445 = heff_tag_at(v_ru_24x11_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2439, v_x_2443}), v_i_2444});
          return heff_tag_at(v_ru_24x1_2437_24Just, TAG_Just, 1, (V[]){v_t_2445});
        }
        default: return heff_nomatch(v_x11_2442);
        }
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    default: return heff_nomatch(v_x11_2438);
    }
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2ecache_2emelt_lam1(V self, V *args) {
  V v_p_2450 = args[0];
  V v_done_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2450)) {
  case TAG_MkPair: {
    V v_m_2451 = heff_field(v_p_2450, 0);
    V v_h_2452 = heff_field(v_p_2450, 1);
    heff_take_n(v_p_2450, 3ULL, 2);
    V v_t_2453 = ({ V a_0 = v_done_241; V a_1 = v_m_2451; V r_ = (g_heff_2ecache_2ensOf(a_0, a_1)); heff_drop(v_done_241); r_; });
    return heff_strEq(v_t_2453, v_h_2452);
  }
  default: return heff_nomatch(v_p_2450);
  }
}
V g_heff_2ecache_2emelt_lam2(V self, V *args) {
  V v_j_2473 = args[0];
  V v_text_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2474 = (g_heff_2eserial_2etakeStr(heff_dup(v_text_243), v_j_2473));
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_Nothing: {
    heff_drop(v_text_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2475 = heff_field(v_x1_2474, 0);
    V v_ru_24x1_2474_24Just = heff_take_reuse_n(v_x1_2474, 1ULL, 1);
    switch (heff_tag_of(v_x11_2475)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x11_2475, 0);
      V v_i_2477 = heff_field(v_x11_2475, 1);
      V v_ru_24x11_2475_24MkPair = heff_take_reuse_n(v_x11_2475, 3ULL, 2);
      V v_x1_2478 = (g_heff_2eserial_2etakeStr(v_text_243, v_i_2477));
      switch (heff_tag_of(v_x1_2478)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2474_24Just, 1);
        heff_drop(v_x_2476);
        heff_drop_cell(v_ru_24x11_2475_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2479 = heff_field(v_x1_2478, 0);
        heff_take_n(v_x1_2478, 1ULL, 1);
        switch (heff_tag_of(v_x11_2479)) {
        case TAG_MkPair: {
          V v_x_2480 = heff_field(v_x11_2479, 0);
          V v_i_2481 = heff_field(v_x11_2479, 1);
          heff_take_n(v_x11_2479, 3ULL, 2);
          V v_t_2482 = heff_tag_at(v_ru_24x11_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2476, v_x_2480}), v_i_2481});
          return heff_tag_at(v_ru_24x1_2474_24Just, TAG_Just, 1, (V[]){v_t_2482});
        }
        default: return heff_nomatch(v_x11_2479);
        }
      }
      default: return heff_nomatch(v_x1_2478);
      }
    }
    default: return heff_nomatch(v_x11_2475);
    }
  }
  default: return heff_nomatch(v_x1_2474);
  }
}
V g_heff_2ecache_2emelt_lam3(V self, V *args) {
  V v_p_2487 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2487)) {
  case TAG_MkPair: {
    V v_k_2488 = heff_field(v_p_2487, 0);
    V v_h_2489 = heff_field(v_p_2487, 1);
    heff_take_n(v_p_2487, 3ULL, 2);
    V v_x2_2490 = ({ V a_0 = v_k_2488; V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
    V v_t_2492;
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_Nothing: {
      v_t_2492 = ((V)&g_heff_2ecache_2emelt_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      heff_take_n(v_x2_2490, 1ULL, 1);
      v_t_2492 = v_x_2491;
      break;
    }
    default: heff_nomatch(v_x2_2490);
    }
    return heff_strEq(v_t_2492, v_h_2489);
  }
  default: return heff_nomatch(v_p_2487);
  }
}
V g_heff_2ecache_2emelt_lam4(V self, V *args) {
  V v_j_24104 = args[0];
  V v_text_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecache_2emeltDef(v_text_243, v_j_24104));
}