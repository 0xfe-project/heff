// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondTrue 53113
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define LBL_array 294448755
#define LBL_arrays 537976933
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_flat 9641024
#define LBL_index 301704428
#define LBL_indices 27765224
#define LBL_read 9991773
#define LBL_tested 1069972444
static uint32_t shape_index__array[] = {LBL_index, LBL_array};
static uint32_t shape_index__tested__read__flat[] = {LBL_index, LBL_tested, LBL_read, LBL_flat};
static uint32_t shape_indices__arrays__defs[] = {LBL_indices, LBL_arrays, LBL_defs};
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(V, V);
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_clo;
V g_heff_2ecompile_2ebounds_2eallOf(V);
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eallOf_clo;
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2ebounds_2echeckedWith(V, V, V);
V g_heff_2ecompile_2ebounds_2echeckedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckedWith_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2ebounds_2efixSt(V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixSt_clo;
HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eindexOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2eindices(V, V, V);
V g_heff_2ecompile_2ebounds_2eindices_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eindices_clo;
V g_heff_2ecompile_2ebounds_2ekept(V, V, V);
V g_heff_2ecompile_2ebounds_2ekept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2ekept_clo;
V g_heff_2ecompile_2ebounds_2elabel_get(void);
HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V);
V g_heff_2ecompile_2ebounds_2elengthOf(V);
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elengthOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn(V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eownNeed_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erelTest_24cpr(V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs(V, V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2esameAs_clo;
V g_heff_2ecompile_2ebounds_2escoped(V, V, V);
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escoped_clo;
V g_heff_2ecompile_2ebounds_2estepOf(V, V);
V g_heff_2ecompile_2ebounds_2estepOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepOf_clo;
V g_heff_2ecompile_2ebounds_2estepSum(V, V);
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepSum_clo;
V g_heff_2ecompile_2ebounds_2eunchecked(V, V, V);
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eunchecked_clo;
V g_heff_2ecompile_2ebounds_2evarOf(V);
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V);
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513567688x204074300(V, V);
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513567688x204074300_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1366776885x1474218589(V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2ecompile_2ebounds_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(V v_acc_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_CDrop: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CLet: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CDecl: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CSet: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CAbandon: {
    return v_acc_240;
  }
  case TAG_CIf: {
    V v_a_249 = heff_field(v_s_241, 1);
    V v_b_2410 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 6ULL, 3);
    V v_t_2411 = ({ V a_0 = v_acc_240; V a_1 = v_a_249; V r_ = (g_list_2efoldl_24s2015232937x23400545(a_0, a_1)); heff_drop(v_a_249); r_; });
    return ({ V a_0 = v_t_2411; V a_1 = v_b_2410; V r_ = (g_list_2efoldl_24s2015232937x23400545(a_0, a_1)); heff_drop(v_b_2410); r_; });
  }
  case TAG_CSwitch: {
    V v_arms_2413 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 2ULL, 3);
    return ({ V a_0 = v_acc_240; V a_1 = v_arms_2413; V r_ = (g_list_2efoldl_24s1513567688x204074300(a_0, a_1)); heff_drop(v_arms_2413); r_; });
  }
  case TAG_CReturn: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CInPlace: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CRoomed: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CTail: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CLoop: {
    V v_ps_2422 = heff_field(v_s_241, 0);
    V v_es_2423 = heff_field(v_s_241, 1);
    V v_ru_24s_241_24CLoop = heff_take_reuse_n(v_s_241, 3ULL, 2);
    V v_t_2424 = (g_list_2ezipWith_24s1876717925x1404326288(v_ps_2422, v_es_2423));
    return heff_tag_at_n(v_ru_24s_241_24CLoop, TAG_Cons, 2, (V[]){v_t_2424, v_acc_240});
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  case TAG_CLabel: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CJump: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
      } else {
        heff_drop(v_e_245);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2evarOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2evarOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2evarOf(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2evarOf(a[0]);
}
Clo g_heff_2ecompile_2ebounds_2estepSum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2estepSum_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2estepSum(V v_x_240, V v_es_241) {
top: ;
  switch (heff_tag_of(v_es_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_es1_242 = heff_field(v_es_241, 0);
    V v_es2_243 = heff_field(v_es_241, 1);
    switch (heff_tag_of(v_es1_242)) {
    case TAG_RLocal: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_245 = heff_field(v_es2_243, 0);
        V v_es22_246 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_245)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_2487 = heff_field(v_es21_245, 1);
          switch (heff_tag_of(v_es22_246)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_2487, 1)) {
              HeffT2 v_t_2488 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_2490 = v_t_2488.f[1];
                int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
                if ((v_tag_2489 == ((int64_t)0ULL))) {
                  V v_y_2491 = v_field_2490;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2491, 0));
                  heff_drop(v_y_2491);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_2490);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_246);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_245);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RDup: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_2497 = heff_field(v_es2_243, 0);
        V v_es22_2498 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_2497)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24179 = heff_field(v_es21_2497, 1);
          switch (heff_tag_of(v_es22_2498)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24179, 1)) {
              HeffT2 v_t_24180 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24182 = v_t_24180.f[1];
                int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
                if ((v_tag_24181 == ((int64_t)0ULL))) {
                  V v_y_24183 = v_field_24182;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24183, 0));
                  heff_drop(v_y_24183);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24182);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_2498);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_2497);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RClo: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24189 = heff_field(v_es2_243, 0);
        V v_es22_24190 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24189)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24271 = heff_field(v_es21_24189, 1);
          switch (heff_tag_of(v_es22_24190)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24271, 1)) {
              HeffT2 v_t_24272 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24274 = v_t_24272.f[1];
                int64_t v_tag_24273 = ((int64_t)v_t_24272.f[0]);
                if ((v_tag_24273 == ((int64_t)0ULL))) {
                  V v_y_24275 = v_field_24274;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24275, 0));
                  heff_drop(v_y_24275);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24274);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24190);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24189);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGet: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24281 = heff_field(v_es2_243, 0);
        V v_es22_24282 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24281)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24363 = heff_field(v_es21_24281, 1);
          switch (heff_tag_of(v_es22_24282)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24363, 1)) {
              HeffT2 v_t_24364 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24366 = v_t_24364.f[1];
                int64_t v_tag_24365 = ((int64_t)v_t_24364.f[0]);
                if ((v_tag_24365 == ((int64_t)0ULL))) {
                  V v_y_24367 = v_field_24366;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24367, 0));
                  heff_drop(v_y_24367);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24366);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24282);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24281);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetRaw: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24373 = heff_field(v_es2_243, 0);
        V v_es22_24374 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24373)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24455 = heff_field(v_es21_24373, 1);
          switch (heff_tag_of(v_es22_24374)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24455, 1)) {
              HeffT2 v_t_24456 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24458 = v_t_24456.f[1];
                int64_t v_tag_24457 = ((int64_t)v_t_24456.f[0]);
                if ((v_tag_24457 == ((int64_t)0ULL))) {
                  V v_y_24459 = v_field_24458;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24459, 0));
                  heff_drop(v_y_24459);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24458);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24374);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24373);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RInt: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24465 = heff_field(v_es2_243, 0);
        V v_es22_24466 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24465)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24547 = heff_field(v_es21_24465, 1);
          switch (heff_tag_of(v_es22_24466)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24547, 1)) {
              HeffT2 v_t_24548 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24550 = v_t_24548.f[1];
                int64_t v_tag_24549 = ((int64_t)v_t_24548.f[0]);
                if ((v_tag_24549 == ((int64_t)0ULL))) {
                  V v_y_24551 = v_field_24550;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24551, 0));
                  heff_drop(v_y_24551);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24550);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24466);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24465);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFloat: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24557 = heff_field(v_es2_243, 0);
        V v_es22_24558 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24557)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24639 = heff_field(v_es21_24557, 1);
          switch (heff_tag_of(v_es22_24558)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24639, 1)) {
              HeffT2 v_t_24640 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24642 = v_t_24640.f[1];
                int64_t v_tag_24641 = ((int64_t)v_t_24640.f[0]);
                if ((v_tag_24641 == ((int64_t)0ULL))) {
                  V v_y_24643 = v_field_24642;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24643, 0));
                  heff_drop(v_y_24643);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24642);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24558);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24557);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RStr: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24649 = heff_field(v_es2_243, 0);
        V v_es22_24650 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24649)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24731 = heff_field(v_es21_24649, 1);
          switch (heff_tag_of(v_es22_24650)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24731, 1)) {
              HeffT2 v_t_24732 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24734 = v_t_24732.f[1];
                int64_t v_tag_24733 = ((int64_t)v_t_24732.f[0]);
                if ((v_tag_24733 == ((int64_t)0ULL))) {
                  V v_y_24735 = v_field_24734;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24735, 0));
                  heff_drop(v_y_24735);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24734);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24650);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24649);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBytes: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24741 = heff_field(v_es2_243, 0);
        V v_es22_24742 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24741)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24823 = heff_field(v_es21_24741, 1);
          switch (heff_tag_of(v_es22_24742)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24823, 1)) {
              HeffT2 v_t_24824 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24826 = v_t_24824.f[1];
                int64_t v_tag_24825 = ((int64_t)v_t_24824.f[0]);
                if ((v_tag_24825 == ((int64_t)0ULL))) {
                  V v_y_24827 = v_field_24826;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24827, 0));
                  heff_drop(v_y_24827);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24826);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24742);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24741);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFixed: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24834 = heff_field(v_es2_243, 0);
        V v_es22_24835 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24834)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24916 = heff_field(v_es21_24834, 1);
          switch (heff_tag_of(v_es22_24835)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24916, 1)) {
              HeffT2 v_t_24917 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24919 = v_t_24917.f[1];
                int64_t v_tag_24918 = ((int64_t)v_t_24917.f[0]);
                if ((v_tag_24918 == ((int64_t)0ULL))) {
                  V v_y_24920 = v_field_24919;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24920, 0));
                  heff_drop(v_y_24920);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24919);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24835);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24834);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF32: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24926 = heff_field(v_es2_243, 0);
        V v_es22_24927 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24926)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241008 = heff_field(v_es21_24926, 1);
          switch (heff_tag_of(v_es22_24927)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241008, 1)) {
              HeffT2 v_t_241009 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241011 = v_t_241009.f[1];
                int64_t v_tag_241010 = ((int64_t)v_t_241009.f[0]);
                if ((v_tag_241010 == ((int64_t)0ULL))) {
                  V v_y_241012 = v_field_241011;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241012, 0));
                  heff_drop(v_y_241012);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241011);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24927);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24926);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RNTag: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241018 = heff_field(v_es2_243, 0);
        V v_es22_241019 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241018)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241100 = heff_field(v_es21_241018, 1);
          switch (heff_tag_of(v_es22_241019)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241100, 1)) {
              HeffT2 v_t_241101 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241103 = v_t_241101.f[1];
                int64_t v_tag_241102 = ((int64_t)v_t_241101.f[0]);
                if ((v_tag_241102 == ((int64_t)0ULL))) {
                  V v_y_241104 = v_field_241103;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241104, 0));
                  heff_drop(v_y_241104);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241103);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241019);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241018);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTag: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241112 = heff_field(v_es2_243, 0);
        V v_es22_241113 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241112)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241194 = heff_field(v_es21_241112, 1);
          switch (heff_tag_of(v_es22_241113)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241194, 1)) {
              HeffT2 v_t_241195 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241197 = v_t_241195.f[1];
                int64_t v_tag_241196 = ((int64_t)v_t_241195.f[0]);
                if ((v_tag_241196 == ((int64_t)0ULL))) {
                  V v_y_241198 = v_field_241197;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241198, 0));
                  heff_drop(v_y_241198);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241197);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241113);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241112);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTagIn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241207 = heff_field(v_es2_243, 0);
        V v_es22_241208 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241207)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241289 = heff_field(v_es21_241207, 1);
          switch (heff_tag_of(v_es22_241208)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241289, 1)) {
              HeffT2 v_t_241290 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241292 = v_t_241290.f[1];
                int64_t v_tag_241291 = ((int64_t)v_t_241290.f[0]);
                if ((v_tag_241291 == ((int64_t)0ULL))) {
                  V v_y_241293 = v_field_241292;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241293, 0));
                  heff_drop(v_y_241293);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241292);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241208);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241207);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RRec: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241301 = heff_field(v_es2_243, 0);
        V v_es22_241302 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241301)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241383 = heff_field(v_es21_241301, 1);
          switch (heff_tag_of(v_es22_241302)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241383, 1)) {
              HeffT2 v_t_241384 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241386 = v_t_241384.f[1];
                int64_t v_tag_241385 = ((int64_t)v_t_241384.f[0]);
                if ((v_tag_241385 == ((int64_t)0ULL))) {
                  V v_y_241387 = v_field_241386;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241387, 0));
                  heff_drop(v_y_241387);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241386);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241302);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241301);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RRecIn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241400 = heff_field(v_es2_243, 0);
        V v_es22_241401 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241400)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241482 = heff_field(v_es21_241400, 1);
          switch (heff_tag_of(v_es22_241401)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241482, 1)) {
              HeffT2 v_t_241483 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241485 = v_t_241483.f[1];
                int64_t v_tag_241484 = ((int64_t)v_t_241483.f[0]);
                if ((v_tag_241484 == ((int64_t)0ULL))) {
                  V v_y_241486 = v_field_241485;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241486, 0));
                  heff_drop(v_y_241486);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241485);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241401);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241400);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RField: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241493 = heff_field(v_es2_243, 0);
        V v_es22_241494 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241493)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241575 = heff_field(v_es21_241493, 1);
          switch (heff_tag_of(v_es22_241494)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241575, 1)) {
              HeffT2 v_t_241576 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241578 = v_t_241576.f[1];
                int64_t v_tag_241577 = ((int64_t)v_t_241576.f[0]);
                if ((v_tag_241577 == ((int64_t)0ULL))) {
                  V v_y_241579 = v_field_241578;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241579, 0));
                  heff_drop(v_y_241579);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241578);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241494);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241493);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RDupE: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241585 = heff_field(v_es2_243, 0);
        V v_es22_241586 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241585)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241667 = heff_field(v_es21_241585, 1);
          switch (heff_tag_of(v_es22_241586)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241667, 1)) {
              HeffT2 v_t_241668 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241670 = v_t_241668.f[1];
                int64_t v_tag_241669 = ((int64_t)v_t_241668.f[0]);
                if ((v_tag_241669 == ((int64_t)0ULL))) {
                  V v_y_241671 = v_field_241670;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241671, 0));
                  heff_drop(v_y_241671);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241670);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241586);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241585);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFieldV: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241678 = heff_field(v_es2_243, 0);
        V v_es22_241679 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241678)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241760 = heff_field(v_es21_241678, 1);
          switch (heff_tag_of(v_es22_241679)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241760, 1)) {
              HeffT2 v_t_241761 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241763 = v_t_241761.f[1];
                int64_t v_tag_241762 = ((int64_t)v_t_241761.f[0]);
                if ((v_tag_241762 == ((int64_t)0ULL))) {
                  V v_y_241764 = v_field_241763;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241764, 0));
                  heff_drop(v_y_241764);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241763);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241679);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241678);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetN: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241772 = heff_field(v_es2_243, 0);
        V v_es22_241773 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241772)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241854 = heff_field(v_es21_241772, 1);
          switch (heff_tag_of(v_es22_241773)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241854, 1)) {
              HeffT2 v_t_241855 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241857 = v_t_241855.f[1];
                int64_t v_tag_241856 = ((int64_t)v_t_241855.f[0]);
                if ((v_tag_241856 == ((int64_t)0ULL))) {
                  V v_y_241858 = v_field_241857;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241858, 0));
                  heff_drop(v_y_241858);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241857);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241773);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241772);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFieldU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241867 = heff_field(v_es2_243, 0);
        V v_es22_241868 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241867)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241949 = heff_field(v_es21_241867, 1);
          switch (heff_tag_of(v_es22_241868)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241949, 1)) {
              HeffT2 v_t_241950 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241952 = v_t_241950.f[1];
                int64_t v_tag_241951 = ((int64_t)v_t_241950.f[0]);
                if ((v_tag_241951 == ((int64_t)0ULL))) {
                  V v_y_241953 = v_field_241952;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_241953, 0));
                  heff_drop(v_y_241953);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_241952);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241868);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241867);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetNU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241963 = heff_field(v_es2_243, 0);
        V v_es22_241964 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241963)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242045 = heff_field(v_es21_241963, 1);
          switch (heff_tag_of(v_es22_241964)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242045, 1)) {
              HeffT2 v_t_242046 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242048 = v_t_242046.f[1];
                int64_t v_tag_242047 = ((int64_t)v_t_242046.f[0]);
                if ((v_tag_242047 == ((int64_t)0ULL))) {
                  V v_y_242049 = v_field_242048;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242049, 0));
                  heff_drop(v_y_242049);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242048);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241964);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241963);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RWord: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242056 = heff_field(v_es2_243, 0);
        V v_es22_242057 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242056)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242138 = heff_field(v_es21_242056, 1);
          switch (heff_tag_of(v_es22_242057)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242138, 1)) {
              HeffT2 v_t_242139 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242141 = v_t_242139.f[1];
                int64_t v_tag_242140 = ((int64_t)v_t_242139.f[0]);
                if ((v_tag_242140 == ((int64_t)0ULL))) {
                  V v_y_242142 = v_field_242141;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242142, 0));
                  heff_drop(v_y_242142);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242141);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242057);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242056);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTakeField: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242149 = heff_field(v_es2_243, 0);
        V v_es22_242150 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242149)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242231 = heff_field(v_es21_242149, 1);
          switch (heff_tag_of(v_es22_242150)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242231, 1)) {
              HeffT2 v_t_242232 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242234 = v_t_242232.f[1];
                int64_t v_tag_242233 = ((int64_t)v_t_242232.f[0]);
                if ((v_tag_242233 == ((int64_t)0ULL))) {
                  V v_y_242235 = v_field_242234;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242235, 0));
                  heff_drop(v_y_242235);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242234);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242150);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242149);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetLabel: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242242 = heff_field(v_es2_243, 0);
        V v_es22_242243 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242242)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242324 = heff_field(v_es21_242242, 1);
          switch (heff_tag_of(v_es22_242243)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242324, 1)) {
              HeffT2 v_t_242325 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242327 = v_t_242325.f[1];
                int64_t v_tag_242326 = ((int64_t)v_t_242325.f[0]);
                if ((v_tag_242326 == ((int64_t)0ULL))) {
                  V v_y_242328 = v_field_242327;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242328, 0));
                  heff_drop(v_y_242328);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242327);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242243);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242242);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimFn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242334 = heff_field(v_es2_243, 0);
        V v_es22_242335 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242334)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242416 = heff_field(v_es21_242334, 1);
          switch (heff_tag_of(v_es22_242335)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242416, 1)) {
              HeffT2 v_t_242417 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242419 = v_t_242417.f[1];
                int64_t v_tag_242418 = ((int64_t)v_t_242417.f[0]);
                if ((v_tag_242418 == ((int64_t)0ULL))) {
                  V v_y_242420 = v_field_242419;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242420, 0));
                  heff_drop(v_y_242420);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242419);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242335);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242334);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrim: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242427 = heff_field(v_es2_243, 0);
        V v_es22_242428 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242427)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242509 = heff_field(v_es21_242427, 1);
          switch (heff_tag_of(v_es22_242428)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242509, 1)) {
              HeffT2 v_t_242510 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242512 = v_t_242510.f[1];
                int64_t v_tag_242511 = ((int64_t)v_t_242510.f[0]);
                if ((v_tag_242511 == ((int64_t)0ULL))) {
                  V v_y_242513 = v_field_242512;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242513, 0));
                  heff_drop(v_y_242513);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242512);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242428);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242427);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RLam: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242522 = heff_field(v_es2_243, 0);
        V v_es22_242523 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242522)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242604 = heff_field(v_es21_242522, 1);
          switch (heff_tag_of(v_es22_242523)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242604, 1)) {
              HeffT2 v_t_242605 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242607 = v_t_242605.f[1];
                int64_t v_tag_242606 = ((int64_t)v_t_242605.f[0]);
                if ((v_tag_242606 == ((int64_t)0ULL))) {
                  V v_y_242608 = v_field_242607;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242608, 0));
                  heff_drop(v_y_242608);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242607);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242523);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242522);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RCall: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242617 = heff_field(v_es2_243, 0);
        V v_es22_242618 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242617)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242699 = heff_field(v_es21_242617, 1);
          switch (heff_tag_of(v_es22_242618)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242699, 1)) {
              HeffT2 v_t_242700 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242702 = v_t_242700.f[1];
                int64_t v_tag_242701 = ((int64_t)v_t_242700.f[0]);
                if ((v_tag_242701 == ((int64_t)0ULL))) {
                  V v_y_242703 = v_field_242702;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242703, 0));
                  heff_drop(v_y_242703);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242702);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242618);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242617);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RApply: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242710 = heff_field(v_es2_243, 0);
        V v_es22_242711 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242710)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242792 = heff_field(v_es21_242710, 1);
          switch (heff_tag_of(v_es22_242711)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242792, 1)) {
              HeffT2 v_t_242793 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242795 = v_t_242793.f[1];
                int64_t v_tag_242794 = ((int64_t)v_t_242793.f[0]);
                if ((v_tag_242794 == ((int64_t)0ULL))) {
                  V v_y_242796 = v_field_242795;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242796, 0));
                  heff_drop(v_y_242796);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242795);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242711);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242710);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBool: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242802 = heff_field(v_es2_243, 0);
        V v_es22_242803 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242802)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242884 = heff_field(v_es21_242802, 1);
          switch (heff_tag_of(v_es22_242803)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242884, 1)) {
              HeffT2 v_t_242885 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242887 = v_t_242885.f[1];
                int64_t v_tag_242886 = ((int64_t)v_t_242885.f[0]);
                if ((v_tag_242886 == ((int64_t)0ULL))) {
                  V v_y_242888 = v_field_242887;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242888, 0));
                  heff_drop(v_y_242888);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242887);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242803);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242802);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RAbandon: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242893 = heff_field(v_es2_243, 0);
        V v_es22_242894 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242893)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242975 = heff_field(v_es21_242893, 1);
          switch (heff_tag_of(v_es22_242894)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242975, 1)) {
              HeffT2 v_t_242976 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242978 = v_t_242976.f[1];
                int64_t v_tag_242977 = ((int64_t)v_t_242976.f[0]);
                if ((v_tag_242977 == ((int64_t)0ULL))) {
                  V v_y_242979 = v_field_242978;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242979, 0));
                  heff_drop(v_y_242979);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_242978);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242894);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242893);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBox: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242986 = heff_field(v_es2_243, 0);
        V v_es22_242987 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242986)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243068 = heff_field(v_es21_242986, 1);
          switch (heff_tag_of(v_es22_242987)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243068, 1)) {
              HeffT2 v_t_243069 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243071 = v_t_243069.f[1];
                int64_t v_tag_243070 = ((int64_t)v_t_243069.f[0]);
                if ((v_tag_243070 == ((int64_t)0ULL))) {
                  V v_y_243072 = v_field_243071;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243072, 0));
                  heff_drop(v_y_243072);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243071);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242987);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242986);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RUnbox: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243079 = heff_field(v_es2_243, 0);
        V v_es22_243080 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243079)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243161 = heff_field(v_es21_243079, 1);
          switch (heff_tag_of(v_es22_243080)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243161, 1)) {
              HeffT2 v_t_243162 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243164 = v_t_243162.f[1];
                int64_t v_tag_243163 = ((int64_t)v_t_243162.f[0]);
                if ((v_tag_243163 == ((int64_t)0ULL))) {
                  V v_y_243165 = v_field_243164;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243165, 0));
                  heff_drop(v_y_243165);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243164);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243080);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243079);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPeek: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243172 = heff_field(v_es2_243, 0);
        V v_es22_243173 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243172)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243254 = heff_field(v_es21_243172, 1);
          switch (heff_tag_of(v_es22_243173)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243254, 1)) {
              HeffT2 v_t_243255 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243257 = v_t_243255.f[1];
                int64_t v_tag_243256 = ((int64_t)v_t_243255.f[0]);
                if ((v_tag_243256 == ((int64_t)0ULL))) {
                  V v_y_243258 = v_field_243257;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243258, 0));
                  heff_drop(v_y_243258);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243257);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243173);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243172);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243265 = heff_field(v_es2_243, 0);
        V v_es22_243266 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243265)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243347 = heff_field(v_es21_243265, 1);
          switch (heff_tag_of(v_es22_243266)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243347, 1)) {
              HeffT2 v_t_243348 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243350 = v_t_243348.f[1];
                int64_t v_tag_243349 = ((int64_t)v_t_243348.f[0]);
                if ((v_tag_243349 == ((int64_t)0ULL))) {
                  V v_y_243351 = v_field_243350;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243351, 0));
                  heff_drop(v_y_243351);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243350);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243266);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243265);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimAt: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243359 = heff_field(v_es2_243, 0);
        V v_es22_243360 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243359)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243441 = heff_field(v_es21_243359, 1);
          switch (heff_tag_of(v_es22_243360)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243441, 1)) {
              HeffT2 v_t_243442 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243444 = v_t_243442.f[1];
                int64_t v_tag_243443 = ((int64_t)v_t_243442.f[0]);
                if ((v_tag_243443 == ((int64_t)0ULL))) {
                  V v_y_243445 = v_field_243444;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243445, 0));
                  heff_drop(v_y_243445);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243444);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243360);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243359);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFixU: {
      V v_es12_243451 = heff_field(v_es1_242, 1);
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e_243452 = heff_field(v_es2_243, 0);
        V v_es22_243453 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es22_243453)) {
        case TAG_Nil: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_es12_243451, 1)) {
            HeffT2 v_t_243454 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_e_243452)));
            {
              V v_field_243456 = v_t_243454.f[1];
              int64_t v_tag_243455 = ((int64_t)v_t_243454.f[0]);
              if ((v_tag_243455 == ((int64_t)0ULL))) {
                V v_y_243457 = v_field_243456;
                V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243457, 0));
                heff_drop(v_y_243457);
                return v_ret_24bool;
              } else {
                heff_drop(v_field_243456);
                return NTAG(TAG_False);
              }
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es22_243453);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF32U: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243461 = heff_field(v_es2_243, 0);
        V v_es22_243462 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243461)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243543 = heff_field(v_es21_243461, 1);
          switch (heff_tag_of(v_es22_243462)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243543, 1)) {
              HeffT2 v_t_243544 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243546 = v_t_243544.f[1];
                int64_t v_tag_243545 = ((int64_t)v_t_243544.f[0]);
                if ((v_tag_243545 == ((int64_t)0ULL))) {
                  V v_y_243547 = v_field_243546;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243547, 0));
                  heff_drop(v_y_243547);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243546);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243462);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243461);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF64U: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243553 = heff_field(v_es2_243, 0);
        V v_es22_243554 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243553)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243635 = heff_field(v_es21_243553, 1);
          switch (heff_tag_of(v_es22_243554)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243635, 1)) {
              HeffT2 v_t_243636 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243638 = v_t_243636.f[1];
                int64_t v_tag_243637 = ((int64_t)v_t_243636.f[0]);
                if ((v_tag_243637 == ((int64_t)0ULL))) {
                  V v_y_243639 = v_field_243638;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243639, 0));
                  heff_drop(v_y_243639);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_243638);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243554);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243553);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    default: return heff_nomatch(v_es1_242);
    }
  }
  default: return heff_nomatch(v_es_241);
  }
}
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2estepSum(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2estepOf_str0, 7, "wordAdd");
Clo g_heff_2ecompile_2ebounds_2estepOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2estepOf_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2estepOf(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    HeffT2 v_t_243 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_y_246 = v_field_245;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_246, 0));
        heff_drop(v_y_246);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_245);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RDup: {
    HeffT2 v_t_248 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_y_2411 = v_field_2410;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2411, 0));
        heff_drop(v_y_2411);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2410);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RClo: {
    HeffT2 v_t_2413 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_y_2416 = v_field_2415;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2416, 0));
        heff_drop(v_y_2416);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2415);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RGet: {
    HeffT2 v_t_2418 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_y_2421 = v_field_2420;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2421, 0));
        heff_drop(v_y_2421);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2420);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RGetRaw: {
    HeffT2 v_t_2423 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_y_2426 = v_field_2425;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2426, 0));
        heff_drop(v_y_2426);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2425);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RInt: {
    HeffT2 v_t_2428 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_y_2431 = v_field_2430;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2431, 0));
        heff_drop(v_y_2431);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2430);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFloat: {
    HeffT2 v_t_2433 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        V v_y_2436 = v_field_2435;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2436, 0));
        heff_drop(v_y_2436);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2435);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RStr: {
    HeffT2 v_t_2438 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2440 = v_t_2438.f[1];
      int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
      if ((v_tag_2439 == ((int64_t)0ULL))) {
        V v_y_2441 = v_field_2440;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2441, 0));
        heff_drop(v_y_2441);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2440);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RBytes: {
    HeffT2 v_t_2443 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2445 = v_t_2443.f[1];
      int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
      if ((v_tag_2444 == ((int64_t)0ULL))) {
        V v_y_2446 = v_field_2445;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2446, 0));
        heff_drop(v_y_2446);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2445);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFixed: {
    HeffT2 v_t_2449 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_y_2452 = v_field_2451;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2452, 0));
        heff_drop(v_y_2452);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2451);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RF32: {
    HeffT2 v_t_2454 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_y_2457 = v_field_2456;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2457, 0));
        heff_drop(v_y_2457);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2456);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RNTag: {
    HeffT2 v_t_2459 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2461 = v_t_2459.f[1];
      int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
      if ((v_tag_2460 == ((int64_t)0ULL))) {
        V v_y_2462 = v_field_2461;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2462, 0));
        heff_drop(v_y_2462);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2461);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RTag: {
    HeffT2 v_t_2466 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2468 = v_t_2466.f[1];
      int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
      if ((v_tag_2467 == ((int64_t)0ULL))) {
        V v_y_2469 = v_field_2468;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2469, 0));
        heff_drop(v_y_2469);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2468);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RTagIn: {
    HeffT2 v_t_2474 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2476 = v_t_2474.f[1];
      int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
      if ((v_tag_2475 == ((int64_t)0ULL))) {
        V v_y_2477 = v_field_2476;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2477, 0));
        heff_drop(v_y_2477);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2476);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RRec: {
    HeffT2 v_t_2481 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_y_2484 = v_field_2483;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2484, 0));
        heff_drop(v_y_2484);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2483);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RRecIn: {
    HeffT2 v_t_2493 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2495 = v_t_2493.f[1];
      int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
      if ((v_tag_2494 == ((int64_t)0ULL))) {
        V v_y_2496 = v_field_2495;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2496, 0));
        heff_drop(v_y_2496);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2495);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RField: {
    HeffT2 v_t_2499 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24101 = v_t_2499.f[1];
      int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
      if ((v_tag_24100 == ((int64_t)0ULL))) {
        V v_y_24102 = v_field_24101;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24102, 0));
        heff_drop(v_y_24102);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24101);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RDupE: {
    HeffT2 v_t_24104 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24106 = v_t_24104.f[1];
      int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
      if ((v_tag_24105 == ((int64_t)0ULL))) {
        V v_y_24107 = v_field_24106;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24107, 0));
        heff_drop(v_y_24107);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24106);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFieldV: {
    HeffT2 v_t_24110 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24112 = v_t_24110.f[1];
      int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
      if ((v_tag_24111 == ((int64_t)0ULL))) {
        V v_y_24113 = v_field_24112;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24113, 0));
        heff_drop(v_y_24113);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24112);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RGetN: {
    HeffT2 v_t_24117 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24119 = v_t_24117.f[1];
      int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
      if ((v_tag_24118 == ((int64_t)0ULL))) {
        V v_y_24120 = v_field_24119;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24120, 0));
        heff_drop(v_y_24120);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24119);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFieldU: {
    HeffT2 v_t_24125 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24127 = v_t_24125.f[1];
      int64_t v_tag_24126 = ((int64_t)v_t_24125.f[0]);
      if ((v_tag_24126 == ((int64_t)0ULL))) {
        V v_y_24128 = v_field_24127;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24128, 0));
        heff_drop(v_y_24128);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24127);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RGetNU: {
    HeffT2 v_t_24134 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24136 = v_t_24134.f[1];
      int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
      if ((v_tag_24135 == ((int64_t)0ULL))) {
        V v_y_24137 = v_field_24136;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24137, 0));
        heff_drop(v_y_24137);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24136);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RWord: {
    HeffT2 v_t_24140 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24142 = v_t_24140.f[1];
      int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
      if ((v_tag_24141 == ((int64_t)0ULL))) {
        V v_y_24143 = v_field_24142;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24143, 0));
        heff_drop(v_y_24143);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24142);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RTakeField: {
    HeffT2 v_t_24146 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24148 = v_t_24146.f[1];
      int64_t v_tag_24147 = ((int64_t)v_t_24146.f[0]);
      if ((v_tag_24147 == ((int64_t)0ULL))) {
        V v_y_24149 = v_field_24148;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24149, 0));
        heff_drop(v_y_24149);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24148);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RGetLabel: {
    HeffT2 v_t_24152 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24154 = v_t_24152.f[1];
      int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
      if ((v_tag_24153 == ((int64_t)0ULL))) {
        V v_y_24155 = v_field_24154;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24155, 0));
        heff_drop(v_y_24155);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24154);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RPrimFn: {
    HeffT2 v_t_24157 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24159 = v_t_24157.f[1];
      int64_t v_tag_24158 = ((int64_t)v_t_24157.f[0]);
      if ((v_tag_24158 == ((int64_t)0ULL))) {
        V v_y_24160 = v_field_24159;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24160, 0));
        heff_drop(v_y_24160);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24159);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RPrim: {
    HeffT2 v_t_24163 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24165 = v_t_24163.f[1];
      int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
      if ((v_tag_24164 == ((int64_t)0ULL))) {
        V v_y_24166 = v_field_24165;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24166, 0));
        heff_drop(v_y_24166);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24165);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RLam: {
    HeffT2 v_t_24171 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24173 = v_t_24171.f[1];
      int64_t v_tag_24172 = ((int64_t)v_t_24171.f[0]);
      if ((v_tag_24172 == ((int64_t)0ULL))) {
        V v_y_24174 = v_field_24173;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24174, 0));
        heff_drop(v_y_24174);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24173);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RCall: {
    HeffT2 v_t_24179 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24181 = v_t_24179.f[1];
      int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
      if ((v_tag_24180 == ((int64_t)0ULL))) {
        V v_y_24182 = v_field_24181;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24182, 0));
        heff_drop(v_y_24182);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24181);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RApply: {
    HeffT2 v_t_24185 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24187 = v_t_24185.f[1];
      int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
      if ((v_tag_24186 == ((int64_t)0ULL))) {
        V v_y_24188 = v_field_24187;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24188, 0));
        heff_drop(v_y_24188);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24187);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RBool: {
    HeffT2 v_t_24190 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24192 = v_t_24190.f[1];
      int64_t v_tag_24191 = ((int64_t)v_t_24190.f[0]);
      if ((v_tag_24191 == ((int64_t)0ULL))) {
        V v_y_24193 = v_field_24192;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24193, 0));
        heff_drop(v_y_24193);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24192);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RAbandon: {
    HeffT2 v_t_24194 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24196 = v_t_24194.f[1];
      int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
      if ((v_tag_24195 == ((int64_t)0ULL))) {
        V v_y_24197 = v_field_24196;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24197, 0));
        heff_drop(v_y_24197);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24196);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RBox: {
    HeffT2 v_t_24200 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24202 = v_t_24200.f[1];
      int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
      if ((v_tag_24201 == ((int64_t)0ULL))) {
        V v_y_24203 = v_field_24202;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24203, 0));
        heff_drop(v_y_24203);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24202);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RUnbox: {
    HeffT2 v_t_24206 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24208 = v_t_24206.f[1];
      int64_t v_tag_24207 = ((int64_t)v_t_24206.f[0]);
      if ((v_tag_24207 == ((int64_t)0ULL))) {
        V v_y_24209 = v_field_24208;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24209, 0));
        heff_drop(v_y_24209);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24208);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RPeek: {
    HeffT2 v_t_24212 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24214 = v_t_24212.f[1];
      int64_t v_tag_24213 = ((int64_t)v_t_24212.f[0]);
      if ((v_tag_24213 == ((int64_t)0ULL))) {
        V v_y_24215 = v_field_24214;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24215, 0));
        heff_drop(v_y_24215);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24214);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RPrimU: {
    V v_p_24216 = heff_field(v_e_241, 0);
    V v_es_24217 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    if (heff_strEq_c(v_p_24216, ((V)&g_heff_2ecompile_2ebounds_2estepOf_str0))) {
      return ({ V a_0 = v_x_240; V a_1 = v_es_24217; V r_ = (g_heff_2ecompile_2ebounds_2estepSum(a_0, a_1)); heff_drop(v_es_24217); r_; });
    } else {
      heff_drop(v_es_24217);
      return NTAG(TAG_False);
    }
  }
  case TAG_RPrimAt: {
    HeffT2 v_t_24221 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24223 = v_t_24221.f[1];
      int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
      if ((v_tag_24222 == ((int64_t)0ULL))) {
        V v_y_24224 = v_field_24223;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24224, 0));
        heff_drop(v_y_24224);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24223);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFixU: {
    HeffT2 v_t_24227 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24229 = v_t_24227.f[1];
      int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
      if ((v_tag_24228 == ((int64_t)0ULL))) {
        V v_y_24230 = v_field_24229;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24230, 0));
        heff_drop(v_y_24230);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24229);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RF32U: {
    HeffT2 v_t_24232 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24234 = v_t_24232.f[1];
      int64_t v_tag_24233 = ((int64_t)v_t_24232.f[0]);
      if ((v_tag_24233 == ((int64_t)0ULL))) {
        V v_y_24235 = v_field_24234;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24235, 0));
        heff_drop(v_y_24235);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24234);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RF64U: {
    HeffT2 v_t_24237 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24239 = v_t_24237.f[1];
      int64_t v_tag_24238 = ((int64_t)v_t_24237.f[0]);
      if ((v_tag_24238 == ((int64_t)0ULL))) {
        V v_y_24240 = v_field_24239;
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24240, 0));
        heff_drop(v_y_24240);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_24239);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ebounds_2estepOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2estepOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elengthArray_24cpr_str0, 11, "arrayLength");

HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_x1_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    V v_p_2456 = heff_field(v_x1_240, 0);
    V v_x12_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_2457)) {
    case TAG_Nil: {
      heff_drop(v_p_2456);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_2458 = heff_field(v_x12_2457, 0);
      V v_x122_2459 = heff_field(v_x12_2457, 1);
      heff_take_n(v_x12_2457, 3ULL, 2);
      switch (heff_tag_of(v_x122_2459)) {
      case TAG_Nil: {
        if (heff_strEq_c(v_p_2456, ((V)&g_heff_2ecompile_2ebounds_2elengthArray_24cpr_str0))) {
          HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_2458);
        } else {
          heff_drop(v_e_2458);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x122_2459, 0ULL, 2);
        heff_drop(v_p_2456);
        heff_drop(v_e_2458);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2459)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2457)}});
    }
  }
  case TAG_RLam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2elengthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elengthOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2elengthOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2elengthOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2elengthOf(a[0]);
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V v_info_240, V v_x2_241, V v_x3_242) {
top: ;
  V v_indices_243 = heff_take_field(v_info_240, 0);
  V v_defs_244 = heff_take_field(v_info_240, 2);
  V v_arrays_245 = heff_get_n(v_info_240, 1, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x3_242);
    heff_drop(v_indices_243);
    heff_drop(v_defs_244);
    heff_drop(v_arrays_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_i_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_indices_243);
      heff_drop(v_defs_244);
      heff_drop(v_arrays_245);
      heff_drop(v_i_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_a_247 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_i_246; V a_1 = v_indices_243; V r_ = (g_heff_2ecompile_2ebounds_2eelemS(a_0, a_1)); heff_drop(v_indices_243); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_x1_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0, 1, 2, (V[]){v_defs_244, v_a_247}), v_arrays_245));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_Nil: {
          heff_drop(v_i_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x1_2410, 0);
          heff_take_n(v_x1_2410, 1ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_index__array, (V[]){v_i_246, v_x_2411})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2410)}});
        }
      } else {
        heff_drop(v_defs_244);
        heff_drop(v_arrays_245);
        heff_drop(v_i_246);
        heff_drop(v_a_247);
        heff_drop(v_t_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args) {
  V v_b_249 = args[0];
  V v_defs_244 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2ebounds_2esameAs(v_defs_244, NTAG(TAG_Nil), v_b_249, heff_tag_n(TAG_RLocal, 1, (V[]){v_a_247})));
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2erelTest_24cpr_str0, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2ebounds_2erelTest_24cpr_str1, 6, "wordLe");

HeffT2 g_heff_2ecompile_2ebounds_2erelTest_24cpr(V v_info_240, V v_p_241, V v_es_242) {
top: ;
  switch (heff_tag_of(v_es_242)) {
  case TAG_Nil: {
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_es_242, 0);
    V v_es2_244 = heff_field(v_es_242, 1);
    V v_ru_24es_242_24Cons = heff_take_reuse_n(v_es_242, 3ULL, 2);
    switch (heff_tag_of(v_es2_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_a_243);
      heff_drop_cell(v_ru_24es_242_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_245 = heff_field(v_es2_244, 0);
      V v_es22_246 = heff_field(v_es2_244, 1);
      heff_take_n(v_es2_244, 3ULL, 2);
      switch (heff_tag_of(v_es22_246)) {
      case TAG_Nil: {
        if (heff_strEq_c_lent(v_p_241, ((V)&g_heff_2ecompile_2ebounds_2erelTest_24cpr_str0), 2)) {
          V v_t_247 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_243));
          V v_t_248 = (g_heff_2ecompile_2ebounds_2elengthOf(v_b_245));
          HeffT2 v_t_249 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_240, v_t_247, v_t_248));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_r_2412 = v_field_2411;
              V v_t_2413 = heff_tag_at_n(v_ru_24es_242_24Cons, TAG_MkPair, 2, (V[]){v_r_2412, NTAG(TAG_True)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
            } else {
              heff_drop_cell(v_ru_24es_242_24Cons, 2);
              heff_drop(v_field_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_p_241, ((V)&g_heff_2ecompile_2ebounds_2erelTest_24cpr_str1), 2)) {
            V v_t_2414 = (g_heff_2ecompile_2ebounds_2evarOf(v_b_245));
            V v_t_2415 = (g_heff_2ecompile_2ebounds_2elengthOf(v_a_243));
            HeffT2 v_t_2416 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_240, v_t_2414, v_t_2415));
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_r_2419 = v_field_2418;
                V v_t_2420 = heff_tag_at_n(v_ru_24es_242_24Cons, TAG_MkPair, 2, (V[]){v_r_2419, NTAG(TAG_False)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              } else {
                heff_drop_cell(v_ru_24es_242_24Cons, 2);
                heff_drop(v_field_2418);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_info_240);
            heff_drop(v_a_243);
            heff_drop_cell(v_ru_24es_242_24Cons, 2);
            heff_drop(v_b_245);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_es22_246, 0ULL, 2);
        heff_drop(v_info_240);
        heff_drop(v_a_243);
        heff_drop_cell(v_ru_24es_242_24Cons, 2);
        heff_drop(v_b_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_es22_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_es_242)}});
  }
}

HeffT2 g_heff_2ecompile_2ebounds_2eindexOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTagIn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RRec: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RRecIn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RDupE: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFieldV: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetN: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFieldU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetNU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RWord: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetLabel: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrim: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RLam: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RCall: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RApply: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBool: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBox: {
    V v_e_2470 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_2470);
  }
  case TAG_RUnbox: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPeek: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimAt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V v_info_240, V v_env_241, V v_fl_242, V v_x4_243, V v_x5_244) {
top: ;
  V v_defs_245 = heff_take_field(v_info_240, 2);
  V v_arrays_246 = heff_get_n(v_info_240, 1, 3);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_env_241);
    heff_drop(v_fl_242);
    heff_drop(v_x5_244);
    heff_drop(v_defs_245);
    heff_drop(v_arrays_246);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_y_247 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_env_241);
      heff_drop(v_fl_242);
      heff_drop(v_defs_245);
      heff_drop(v_arrays_246);
      heff_drop(v_y_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_i_248 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_x1_249 = (g_list_2ekeepIf_24s1366776885x1474218589(v_i_248, v_env_241));
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_fl_242);
        heff_drop(v_defs_245);
        heff_drop(v_arrays_246);
        heff_drop(v_y_247);
        heff_drop(v_i_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        V v_x1_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0, 1, 2, (V[]){v_defs_245, v_y_247}), v_arrays_246));
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_Nil: {
          heff_drop(v_fl_242);
          heff_drop(v_i_248);
          heff_drop_rec(v_x_2410, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 2);
          V v_f_2416 = heff_rec_n(4, shape_index__tested__read__flat, (V[]){v_i_248, heff_get_n(v_x_2410, 1, 2), v_x_2414, v_fl_242});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args) {
  V v_b_2412 = args[0];
  V v_defs_245 = heff_env(self)[0];
  V v_y_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2ebounds_2esameAs(v_defs_245, NTAG(TAG_Nil), v_b_2412, heff_tag_n(TAG_RLocal, 1, (V[]){v_y_247})));
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eneedsIn_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eneedsIn(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2ebounds_2eownNeed_24cpr(heff_dup(v_info_240), heff_dup(v_env_241), heff_dup(v_e_242)));
  V v_t_247;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_field_245);
      v_t_247 = NTAG(TAG_Nil);
    }
  }
  V v_f_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2eneedsIn_clo), 2, (V[]){v_info_240, v_env_241}));
  V v_xs_249 = (g_heff_2ecompile_2eowned_2ekids(v_e_242));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eneedsIn_lam0, 2, 1, (V[]){v_f_248}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2414));
}
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eneedsIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_f_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_call(v_f_248, 1, (V[]){v_x_2412}));
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2411));
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str1, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str2, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str3, 15, "arraySetOwnedIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str4, 9, "arrayPeek");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str5, 11, "arrayPeekIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str6, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str7, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str8, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str9, 15, "arraySetOwnedIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str10, 9, "arrayPeek");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str11, 11, "arrayPeekIn");
Clo g_heff_2ecompile_2ebounds_2eunchecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eunchecked_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eunchecked(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_RLocal: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RDup: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RClo: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGet: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetRaw: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RInt: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFloat: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RStr: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBytes: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFixed: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF32: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RNTag: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTag: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTagIn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RRec: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RRecIn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RField: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RDupE: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFieldV: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetN: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFieldU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetNU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RWord: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTakeField: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetLabel: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimFn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrim: {
    V v_p_2458 = heff_field(v_e_242, 0);
    V v_es_2459 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24RPrim = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2460 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_241, v_p_2458, NTAG(TAG_Nothing), heff_dup(v_es_2459)));
    V v_t_2464;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2463 = v_field_2462;
        heff_drop(v_x_2463);
        if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str0), 2)) {
          heff_drop(v_p_2458);
          v_t_2464 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str1);
        } else {
          if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str2), 2)) {
            heff_drop(v_p_2458);
            v_t_2464 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str3);
          } else {
            if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str4), 2)) {
              heff_drop(v_p_2458);
              v_t_2464 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str5);
            } else {
              v_t_2464 = v_p_2458;
            }
          }
        }
      } else {
        heff_drop(v_field_2462);
        v_t_2464 = v_p_2458;
      }
    }
    return heff_tag_at_n(v_ru_24e_242_24RPrim, TAG_RPrim, 2, (V[]){v_t_2464, v_es_2459});
  }
  case TAG_RLam: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RCall: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RApply: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBool: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RAbandon: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBox: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RUnbox: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPeek: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimAt: {
    V v_p_2484 = heff_field(v_e_242, 0);
    V v_r_2485 = heff_field(v_e_242, 1);
    V v_es_2486 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24RPrimAt = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2487 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_241, v_p_2484, NTAG(TAG_Nothing), heff_dup(v_es_2486)));
    V v_t_2491;
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        V v_x_2490 = v_field_2489;
        heff_drop(v_x_2490);
        if (heff_strEq_c_lent(v_p_2484, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str6), 2)) {
          heff_drop(v_p_2484);
          v_t_2491 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str7);
        } else {
          if (heff_strEq_c_lent(v_p_2484, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str8), 2)) {
            heff_drop(v_p_2484);
            v_t_2491 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str9);
          } else {
            if (heff_strEq_c_lent(v_p_2484, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str10), 2)) {
              heff_drop(v_p_2484);
              v_t_2491 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str11);
            } else {
              v_t_2491 = v_p_2484;
            }
          }
        }
      } else {
        heff_drop(v_field_2489);
        v_t_2491 = v_p_2484;
      }
    }
    return heff_tag_at_n(v_ru_24e_242_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_t_2491, v_r_2485, v_es_2486});
  }
  case TAG_RFixU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF32U: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF64U: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eunchecked(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elabel_str0, 7, "InRange");

static V g_heff_2ecompile_2ebounds_2elabel_val;
static HEFF_ONCE g_heff_2ecompile_2ebounds_2elabel_st;
static V g_heff_2ecompile_2ebounds_2elabel_init(void) {
  return ((V)&g_heff_2ecompile_2ebounds_2elabel_str0);
}
V g_heff_2ecompile_2ebounds_2elabel_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ebounds_2elabel_st)) return g_heff_2ecompile_2ebounds_2elabel_val;
  return heff_global(&g_heff_2ecompile_2ebounds_2elabel_val, &g_heff_2ecompile_2ebounds_2elabel_st, g_heff_2ecompile_2ebounds_2elabel_init);
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2efixSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2efixSt_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2efixSt(V v_go_240, V v_info_241, V v_env_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CLet: {
    V v_x_245 = heff_field(v_s_243, 0);
    V v_e_246 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLet = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_247 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_246));
    return heff_tag_at_n(v_ru_24s_243_24CLet, TAG_CLet, 2, (V[]){v_x_245, v_t_247});
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CSet: {
    V v_x_249 = heff_field(v_s_243, 0);
    V v_e_2410 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CSet = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2411 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_2410));
    return heff_tag_at_n(v_ru_24s_243_24CSet, TAG_CSet, 2, (V[]){v_x_249, v_t_2411});
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CIf: {
    V v_c_2412 = heff_field(v_s_243, 0);
    V v_a_2413 = heff_field(v_s_243, 1);
    V v_b_2414 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CIf = heff_take_reuse_n(v_s_243, 7ULL, 3);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_info_241), heff_dup(v_env_242)}));
    V v_t_2416 = (g_heff_2ecompile_2eowned_2emapCond(v_t_2415, heff_dup(v_c_2412)));
    HeffT2 v_t_2417 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(heff_dup(v_info_241), heff_dup(v_c_2412)));
    V v_t_2423;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x21_2420 = v_field_2419;
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_MkPair: {
          V v_r_2421 = heff_field(v_x21_2420, 0);
          V v_x212_2422 = heff_field(v_x21_2420, 1);
          V v_ru_24x21_2420_24MkPair = heff_take_reuse_n(v_x21_2420, 3ULL, 2);
          if ((heff_dup(v_x212_2422) == NTAG(TAG_True))) {
            heff_drop(v_x212_2422);
            v_t_2423 = heff_tag_at_n(v_ru_24x21_2420_24MkPair, TAG_Cons, 2, (V[]){v_r_2421, heff_dup(v_env_242)});
          } else {
            heff_drop(v_r_2421);
            heff_drop(v_x212_2422);
            heff_drop_cell(v_ru_24x21_2420_24MkPair, 2);
            v_t_2423 = heff_dup(v_env_242);
          }
          break;
        }
        default: heff_nomatch(v_x21_2420);
        }
      } else {
        heff_drop(v_field_2419);
        v_t_2423 = heff_dup(v_env_242);
      }
    }
    V v_t_2424 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_t_2423, v_a_2413}));
    HeffT2 v_t_2425 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_241, v_c_2412));
    V v_t_2431;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x21_2428 = v_field_2427;
        switch (heff_tag_of(v_x21_2428)) {
        case TAG_MkPair: {
          V v_r_2429 = heff_field(v_x21_2428, 0);
          V v_x212_2430 = heff_field(v_x21_2428, 1);
          V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
          if ((heff_dup(v_x212_2430) == NTAG(TAG_True))) {
            heff_drop(v_r_2429);
            heff_drop(v_x212_2430);
            heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
            v_t_2431 = v_env_242;
          } else {
            heff_drop(v_x212_2430);
            v_t_2431 = heff_tag_at_n(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_r_2429, v_env_242});
          }
          break;
        }
        default: heff_nomatch(v_x21_2428);
        }
      } else {
        heff_drop(v_field_2427);
        v_t_2431 = v_env_242;
      }
    }
    V v_t_2432 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2431, v_b_2414}));
    return heff_tag_at_n(v_ru_24s_243_24CIf, TAG_CIf, 3, (V[]){v_t_2416, v_t_2424, v_t_2432});
  }
  case TAG_CSwitch: {
    V v_e_2433 = heff_field(v_s_243, 0);
    V v_arms_2434 = heff_field(v_s_243, 1);
    V v_r_2435 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CSwitch = heff_take_reuse_n(v_s_243, 7ULL, 3);
    V v_t_2436 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, heff_dup(v_env_242), v_e_2433));
    V v_go_2437 = heff_tr(heff_call(v_go_240, 1, (V[]){v_env_242}));
    V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2efixSt_lam0, 1, 1, (V[]){v_go_2437}), v_arms_2434));
    return heff_tag_at_n(v_ru_24s_243_24CSwitch, TAG_CSwitch, 3, (V[]){v_t_2436, v_t_2448, v_r_2435});
  }
  case TAG_CReturn: {
    V v_e_2449 = heff_field(v_s_243, 0);
    V v_ru_24s_243_24CReturn = heff_take_reuse_n(v_s_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_2450 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_2449));
    return heff_tag_at_n(v_ru_24s_243_24CReturn, TAG_CReturn, 1, (V[]){v_t_2450});
  }
  case TAG_CInPlace: {
    V v_f_2451 = heff_field(v_s_243, 0);
    V v_es_2452 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CInPlace = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2453 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2451));
    V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2455 = (g_list_2emap(v_t_2454, v_es_2452));
    return heff_tag_at_n(v_ru_24s_243_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2453, v_t_2455});
  }
  case TAG_CRoomed: {
    V v_f_2456 = heff_field(v_s_243, 0);
    V v_es_2457 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CRoomed = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2458 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2456));
    V v_t_2459 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2460 = (g_list_2emap(v_t_2459, v_es_2457));
    return heff_tag_at_n(v_ru_24s_243_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2458, v_t_2460});
  }
  case TAG_CTail: {
    V v_f_2461 = heff_field(v_s_243, 0);
    V v_es_2462 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CTail = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2463 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2461));
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2465 = (g_list_2emap(v_t_2464, v_es_2462));
    return heff_tag_at_n(v_ru_24s_243_24CTail, TAG_CTail, 2, (V[]){v_t_2463, v_t_2465});
  }
  case TAG_CLoop: {
    V v_ps_2466 = heff_field(v_s_243, 0);
    V v_es_2467 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLoop = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2469 = (g_list_2emap_24tok2(v_ru_24s_243_24CLoop, v_t_2468, v_es_2467));
    return heff_tag_n(TAG_CLoopTo, 3, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get()), v_ps_2466, v_t_2469});
  }
  case TAG_CLoopTo: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CJump: {
    V v_g_2474 = heff_field(v_s_243, 0);
    V v_w_2475 = heff_field(v_s_243, 1);
    V v_es_2476 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CJump = heff_take_reuse_n(v_s_243, 7ULL, 3);
    heff_drop(v_go_240);
    V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2478 = (g_list_2emap(v_t_2477, v_es_2476));
    return heff_tag_at_n(v_ru_24s_243_24CJump, TAG_CJump, 3, (V[]){v_g_2474, v_w_2475, v_t_2478});
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2efixSt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args) {
  V v_x2_2438 = args[0];
  V v_go_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkCArm: {
    V v_t_2439 = heff_field(v_x2_2438, 0);
    V v_fs_2440 = heff_field(v_x2_2438, 1);
    V v_fl_2441 = heff_field(v_x2_2438, 2);
    V v_su_2442 = heff_field(v_x2_2438, 3);
    V v_pl_2443 = heff_field(v_x2_2438, 4);
    V v_tk_2444 = heff_field(v_x2_2438, 5);
    V v_body_2445 = heff_field(v_x2_2438, 6);
    V v_lv_2446 = heff_field(v_x2_2438, 7);
    V v_ru_24x2_2438_24MkCArm = heff_take_reuse_n(v_x2_2438, 255ULL, 8);
    V v_t_2447 = heff_tr(heff_call(v_go_2437, 1, (V[]){v_body_2445}));
    return heff_tag_at_n(v_ru_24x2_2438_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2439, v_fs_2440, v_fl_2441, v_su_2442, v_pl_2443, v_tk_2444, v_t_2447, v_lv_2446});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
Clo g_heff_2ecompile_2ebounds_2eallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eallOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eallOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_CondTrue);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_c_241);
    }
    case TAG_Cons: {
      V v_t_245 = (g_heff_2ecompile_2ebounds_2eallOf(v_x12_242));
      return heff_tag_n(TAG_CondIf, 3, (V[]){heff_dup(v_c_241), v_t_245, NTAG(TAG_CondFalse)});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2eallOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eboundsWith_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eboundsWith(V v_f_240, V v_ds_241, V v_ags_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2ebounds_2eindices(heff_dup(v_f_240), heff_dup(v_ds_241), v_ags_242));
  V v_t_244 = (g_heff_2ecompile_2ebounds_2ekept(v_f_240, heff_dup(v_ds_241), v_ags_242));
  V v_info_245 = heff_rec_n(3, shape_indices__arrays__defs, (V[]){v_t_243, v_t_244, v_ds_241});
  V v_t_246 = heff_dup(heff_rfield(v_info_245, 0));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_info_245, 3);
    return v_f_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_xs_249 = (g_heff_2ecompile_2ebounds_2escoped(heff_dup(v_info_245), NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_240, 4))));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam0, 2, 1, (V[]){heff_dup(v_info_245)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    HEFF_LAST return g_heff_2ecompile_2ebounds_2echeckedWith(v_f_240, v_info_245, v_t_2420);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2eboundsWith(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_info_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_x_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2419 = (g_heff_2ecompile_2ebounds_2eneedsIn(v_info_245, v_t_2415, v_t_2418));
  return (g_prelude_2e_2b_2b(v_t_2419, v_acc_2411));
}