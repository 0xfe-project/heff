// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondTrue 53113
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define LBL_array 294448755
#define LBL_arrays 537976933
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_flat 9641024
#define LBL_index 301704428
#define LBL_indices 27765224
#define LBL_read 9991773
#define LBL_tested 1069972444
static uint32_t shape_index__array[] = {LBL_index, LBL_array};
static uint32_t shape_index__tested__read__flat[] = {LBL_index, LBL_tested, LBL_read, LBL_flat};
static uint32_t shape_indices__arrays__defs[] = {LBL_indices, LBL_arrays, LBL_defs};
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(V, V);
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_clo;
V g_heff_2ecompile_2ebounds_2eallOf(V);
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eallOf_clo;
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2ebounds_2echeckedWith(V, V, V);
V g_heff_2ecompile_2ebounds_2echeckedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckedWith_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2ebounds_2efixSt(V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixSt_clo;
HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eindexOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2eindices(V, V, V);
V g_heff_2ecompile_2ebounds_2eindices_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eindices_clo;
V g_heff_2ecompile_2ebounds_2ekept(V, V, V);
V g_heff_2ecompile_2ebounds_2ekept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2ekept_clo;
V g_heff_2ecompile_2ebounds_2elabel_get(void);
HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V);
V g_heff_2ecompile_2ebounds_2elengthOf(V);
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elengthOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn(V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eownNeed_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erelTest_24cpr(V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs(V, V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2esameAs_clo;
V g_heff_2ecompile_2ebounds_2escoped(V, V, V);
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escoped_clo;
V g_heff_2ecompile_2ebounds_2estepOf(V, V);
V g_heff_2ecompile_2ebounds_2estepOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepOf_clo;
V g_heff_2ecompile_2ebounds_2estepSum(V, V);
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepSum_clo;
V g_heff_2ecompile_2ebounds_2eunchecked(V, V, V);
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eunchecked_clo;
V g_heff_2ecompile_2ebounds_2evarOf(V);
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V);
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513567688x204074300(V, V);
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513567688x204074300_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1282433449x1943698445(V, V);
V g_list_2ekeepIf_24s1282433449x1943698445_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1282433449x1943698445_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2ebounds_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(V v_acc_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_CDrop: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CLet: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CDecl: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CSet: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CAbandon: {
    return v_acc_240;
  }
  case TAG_CIf: {
    V v_a_249 = heff_field(v_s_241, 1);
    V v_b_2410 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 6ULL, 3);
    V v_t_2411 = ({ V a_0 = v_acc_240; V a_1 = v_a_249; V r_ = (g_list_2efoldl_24s2015232937x23400545(a_0, a_1)); heff_drop(v_a_249); r_; });
    return ({ V a_0 = v_t_2411; V a_1 = v_b_2410; V r_ = (g_list_2efoldl_24s2015232937x23400545(a_0, a_1)); heff_drop(v_b_2410); r_; });
  }
  case TAG_CSwitch: {
    V v_arms_2413 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 2ULL, 3);
    return ({ V a_0 = v_acc_240; V a_1 = v_arms_2413; V r_ = (g_list_2efoldl_24s1513567688x204074300(a_0, a_1)); heff_drop(v_arms_2413); r_; });
  }
  case TAG_CReturn: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CInPlace: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CRoomed: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CTail: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CLoop: {
    V v_ps_2422 = heff_field(v_s_241, 0);
    V v_es_2423 = heff_field(v_s_241, 1);
    V v_ru_24s_241_24CLoop = heff_take_reuse_n(v_s_241, 3ULL, 2);
    V v_t_2424 = (g_list_2ezipWith_24s1876717925x1404326288(v_ps_2422, v_es_2423));
    return heff_tag_at_n(v_ru_24s_241_24CLoop, TAG_Cons, 2, (V[]){v_t_2424, v_acc_240});
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  case TAG_CLabel: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CJump: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eagainSt_24s1252129277x1086874774(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
      } else {
        heff_drop(v_e_245);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2evarOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2evarOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2evarOf(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2evarOf(a[0]);
}
Clo g_heff_2ecompile_2ebounds_2estepSum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2estepSum_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2estepSum(V v_x_240, V v_es_241) {
top: ;
  switch (heff_tag_of(v_es_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_es1_242 = heff_field(v_es_241, 0);
    V v_es2_243 = heff_field(v_es_241, 1);
    switch (heff_tag_of(v_es1_242)) {
    case TAG_RLocal: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_245 = heff_field(v_es2_243, 0);
        V v_es22_246 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_245)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_2487 = heff_field(v_es21_245, 1);
          switch (heff_tag_of(v_es22_246)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_2487, 1)) {
              HeffT2 v_t_2489 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_2491 = v_t_2489.f[1];
                int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_2490 == ((int64_t)0ULL)) && ({ V v_y_2493 = heff_dup(v_field_2491); int c_ = heff_strEq_c_lent(v_x_240, v_y_2493, 0); heff_drop(v_y_2493); c_; })));
                heff_drop(v_field_2491);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_246);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_245);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RDup: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_2499 = heff_field(v_es2_243, 0);
        V v_es22_24100 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_2499)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24181 = heff_field(v_es21_2499, 1);
          switch (heff_tag_of(v_es22_24100)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24181, 1)) {
              HeffT2 v_t_24183 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24185 = v_t_24183.f[1];
                int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24184 == ((int64_t)0ULL)) && ({ V v_y_24187 = heff_dup(v_field_24185); int c_ = heff_strEq_c_lent(v_x_240, v_y_24187, 0); heff_drop(v_y_24187); c_; })));
                heff_drop(v_field_24185);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24100);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_2499);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RClo: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24193 = heff_field(v_es2_243, 0);
        V v_es22_24194 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24193)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24275 = heff_field(v_es21_24193, 1);
          switch (heff_tag_of(v_es22_24194)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24275, 1)) {
              HeffT2 v_t_24277 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24279 = v_t_24277.f[1];
                int64_t v_tag_24278 = ((int64_t)v_t_24277.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24278 == ((int64_t)0ULL)) && ({ V v_y_24281 = heff_dup(v_field_24279); int c_ = heff_strEq_c_lent(v_x_240, v_y_24281, 0); heff_drop(v_y_24281); c_; })));
                heff_drop(v_field_24279);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24194);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24193);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGet: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24287 = heff_field(v_es2_243, 0);
        V v_es22_24288 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24287)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24369 = heff_field(v_es21_24287, 1);
          switch (heff_tag_of(v_es22_24288)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24369, 1)) {
              HeffT2 v_t_24371 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24373 = v_t_24371.f[1];
                int64_t v_tag_24372 = ((int64_t)v_t_24371.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24372 == ((int64_t)0ULL)) && ({ V v_y_24375 = heff_dup(v_field_24373); int c_ = heff_strEq_c_lent(v_x_240, v_y_24375, 0); heff_drop(v_y_24375); c_; })));
                heff_drop(v_field_24373);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24288);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24287);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetRaw: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24381 = heff_field(v_es2_243, 0);
        V v_es22_24382 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24381)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24463 = heff_field(v_es21_24381, 1);
          switch (heff_tag_of(v_es22_24382)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24463, 1)) {
              HeffT2 v_t_24465 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24467 = v_t_24465.f[1];
                int64_t v_tag_24466 = ((int64_t)v_t_24465.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24466 == ((int64_t)0ULL)) && ({ V v_y_24469 = heff_dup(v_field_24467); int c_ = heff_strEq_c_lent(v_x_240, v_y_24469, 0); heff_drop(v_y_24469); c_; })));
                heff_drop(v_field_24467);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24382);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24381);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RInt: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24475 = heff_field(v_es2_243, 0);
        V v_es22_24476 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24475)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24557 = heff_field(v_es21_24475, 1);
          switch (heff_tag_of(v_es22_24476)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24557, 1)) {
              HeffT2 v_t_24559 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24561 = v_t_24559.f[1];
                int64_t v_tag_24560 = ((int64_t)v_t_24559.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24560 == ((int64_t)0ULL)) && ({ V v_y_24563 = heff_dup(v_field_24561); int c_ = heff_strEq_c_lent(v_x_240, v_y_24563, 0); heff_drop(v_y_24563); c_; })));
                heff_drop(v_field_24561);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24476);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24475);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFloat: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24569 = heff_field(v_es2_243, 0);
        V v_es22_24570 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24569)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24651 = heff_field(v_es21_24569, 1);
          switch (heff_tag_of(v_es22_24570)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24651, 1)) {
              HeffT2 v_t_24653 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24655 = v_t_24653.f[1];
                int64_t v_tag_24654 = ((int64_t)v_t_24653.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24654 == ((int64_t)0ULL)) && ({ V v_y_24657 = heff_dup(v_field_24655); int c_ = heff_strEq_c_lent(v_x_240, v_y_24657, 0); heff_drop(v_y_24657); c_; })));
                heff_drop(v_field_24655);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24570);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24569);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RStr: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24663 = heff_field(v_es2_243, 0);
        V v_es22_24664 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24663)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24745 = heff_field(v_es21_24663, 1);
          switch (heff_tag_of(v_es22_24664)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24745, 1)) {
              HeffT2 v_t_24747 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24749 = v_t_24747.f[1];
                int64_t v_tag_24748 = ((int64_t)v_t_24747.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24748 == ((int64_t)0ULL)) && ({ V v_y_24751 = heff_dup(v_field_24749); int c_ = heff_strEq_c_lent(v_x_240, v_y_24751, 0); heff_drop(v_y_24751); c_; })));
                heff_drop(v_field_24749);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24664);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24663);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBytes: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24757 = heff_field(v_es2_243, 0);
        V v_es22_24758 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24757)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24839 = heff_field(v_es21_24757, 1);
          switch (heff_tag_of(v_es22_24758)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24839, 1)) {
              HeffT2 v_t_24841 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24843 = v_t_24841.f[1];
                int64_t v_tag_24842 = ((int64_t)v_t_24841.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24842 == ((int64_t)0ULL)) && ({ V v_y_24845 = heff_dup(v_field_24843); int c_ = heff_strEq_c_lent(v_x_240, v_y_24845, 0); heff_drop(v_y_24845); c_; })));
                heff_drop(v_field_24843);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24758);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24757);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFixed: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24852 = heff_field(v_es2_243, 0);
        V v_es22_24853 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24852)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_24934 = heff_field(v_es21_24852, 1);
          switch (heff_tag_of(v_es22_24853)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_24934, 1)) {
              HeffT2 v_t_24936 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_24938 = v_t_24936.f[1];
                int64_t v_tag_24937 = ((int64_t)v_t_24936.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_24937 == ((int64_t)0ULL)) && ({ V v_y_24940 = heff_dup(v_field_24938); int c_ = heff_strEq_c_lent(v_x_240, v_y_24940, 0); heff_drop(v_y_24940); c_; })));
                heff_drop(v_field_24938);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24853);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24852);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF32: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_24946 = heff_field(v_es2_243, 0);
        V v_es22_24947 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_24946)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241028 = heff_field(v_es21_24946, 1);
          switch (heff_tag_of(v_es22_24947)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241028, 1)) {
              HeffT2 v_t_241030 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241032 = v_t_241030.f[1];
                int64_t v_tag_241031 = ((int64_t)v_t_241030.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241031 == ((int64_t)0ULL)) && ({ V v_y_241034 = heff_dup(v_field_241032); int c_ = heff_strEq_c_lent(v_x_240, v_y_241034, 0); heff_drop(v_y_241034); c_; })));
                heff_drop(v_field_241032);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_24947);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_24946);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RNTag: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241040 = heff_field(v_es2_243, 0);
        V v_es22_241041 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241040)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241122 = heff_field(v_es21_241040, 1);
          switch (heff_tag_of(v_es22_241041)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241122, 1)) {
              HeffT2 v_t_241124 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241126 = v_t_241124.f[1];
                int64_t v_tag_241125 = ((int64_t)v_t_241124.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241125 == ((int64_t)0ULL)) && ({ V v_y_241128 = heff_dup(v_field_241126); int c_ = heff_strEq_c_lent(v_x_240, v_y_241128, 0); heff_drop(v_y_241128); c_; })));
                heff_drop(v_field_241126);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241041);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241040);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTag: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241136 = heff_field(v_es2_243, 0);
        V v_es22_241137 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241136)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241218 = heff_field(v_es21_241136, 1);
          switch (heff_tag_of(v_es22_241137)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241218, 1)) {
              HeffT2 v_t_241220 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241222 = v_t_241220.f[1];
                int64_t v_tag_241221 = ((int64_t)v_t_241220.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241221 == ((int64_t)0ULL)) && ({ V v_y_241224 = heff_dup(v_field_241222); int c_ = heff_strEq_c_lent(v_x_240, v_y_241224, 0); heff_drop(v_y_241224); c_; })));
                heff_drop(v_field_241222);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241137);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241136);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTagIn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241233 = heff_field(v_es2_243, 0);
        V v_es22_241234 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241233)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241315 = heff_field(v_es21_241233, 1);
          switch (heff_tag_of(v_es22_241234)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241315, 1)) {
              HeffT2 v_t_241317 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241319 = v_t_241317.f[1];
                int64_t v_tag_241318 = ((int64_t)v_t_241317.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241318 == ((int64_t)0ULL)) && ({ V v_y_241321 = heff_dup(v_field_241319); int c_ = heff_strEq_c_lent(v_x_240, v_y_241321, 0); heff_drop(v_y_241321); c_; })));
                heff_drop(v_field_241319);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241234);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241233);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RRec: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241329 = heff_field(v_es2_243, 0);
        V v_es22_241330 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241329)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241411 = heff_field(v_es21_241329, 1);
          switch (heff_tag_of(v_es22_241330)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241411, 1)) {
              HeffT2 v_t_241413 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241415 = v_t_241413.f[1];
                int64_t v_tag_241414 = ((int64_t)v_t_241413.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241414 == ((int64_t)0ULL)) && ({ V v_y_241417 = heff_dup(v_field_241415); int c_ = heff_strEq_c_lent(v_x_240, v_y_241417, 0); heff_drop(v_y_241417); c_; })));
                heff_drop(v_field_241415);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241330);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241329);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RRecIn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241430 = heff_field(v_es2_243, 0);
        V v_es22_241431 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241430)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241512 = heff_field(v_es21_241430, 1);
          switch (heff_tag_of(v_es22_241431)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241512, 1)) {
              HeffT2 v_t_241514 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241516 = v_t_241514.f[1];
                int64_t v_tag_241515 = ((int64_t)v_t_241514.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241515 == ((int64_t)0ULL)) && ({ V v_y_241518 = heff_dup(v_field_241516); int c_ = heff_strEq_c_lent(v_x_240, v_y_241518, 0); heff_drop(v_y_241518); c_; })));
                heff_drop(v_field_241516);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241431);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241430);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RField: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241525 = heff_field(v_es2_243, 0);
        V v_es22_241526 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241525)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241607 = heff_field(v_es21_241525, 1);
          switch (heff_tag_of(v_es22_241526)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241607, 1)) {
              HeffT2 v_t_241609 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241611 = v_t_241609.f[1];
                int64_t v_tag_241610 = ((int64_t)v_t_241609.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241610 == ((int64_t)0ULL)) && ({ V v_y_241613 = heff_dup(v_field_241611); int c_ = heff_strEq_c_lent(v_x_240, v_y_241613, 0); heff_drop(v_y_241613); c_; })));
                heff_drop(v_field_241611);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241526);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241525);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RDupE: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241619 = heff_field(v_es2_243, 0);
        V v_es22_241620 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241619)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241701 = heff_field(v_es21_241619, 1);
          switch (heff_tag_of(v_es22_241620)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241701, 1)) {
              HeffT2 v_t_241703 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241705 = v_t_241703.f[1];
                int64_t v_tag_241704 = ((int64_t)v_t_241703.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241704 == ((int64_t)0ULL)) && ({ V v_y_241707 = heff_dup(v_field_241705); int c_ = heff_strEq_c_lent(v_x_240, v_y_241707, 0); heff_drop(v_y_241707); c_; })));
                heff_drop(v_field_241705);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241620);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241619);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFieldV: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241714 = heff_field(v_es2_243, 0);
        V v_es22_241715 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241714)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241796 = heff_field(v_es21_241714, 1);
          switch (heff_tag_of(v_es22_241715)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241796, 1)) {
              HeffT2 v_t_241798 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241800 = v_t_241798.f[1];
                int64_t v_tag_241799 = ((int64_t)v_t_241798.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241799 == ((int64_t)0ULL)) && ({ V v_y_241802 = heff_dup(v_field_241800); int c_ = heff_strEq_c_lent(v_x_240, v_y_241802, 0); heff_drop(v_y_241802); c_; })));
                heff_drop(v_field_241800);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241715);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241714);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetN: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241810 = heff_field(v_es2_243, 0);
        V v_es22_241811 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241810)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241892 = heff_field(v_es21_241810, 1);
          switch (heff_tag_of(v_es22_241811)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241892, 1)) {
              HeffT2 v_t_241894 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241896 = v_t_241894.f[1];
                int64_t v_tag_241895 = ((int64_t)v_t_241894.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241895 == ((int64_t)0ULL)) && ({ V v_y_241898 = heff_dup(v_field_241896); int c_ = heff_strEq_c_lent(v_x_240, v_y_241898, 0); heff_drop(v_y_241898); c_; })));
                heff_drop(v_field_241896);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241811);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241810);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFieldU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_241907 = heff_field(v_es2_243, 0);
        V v_es22_241908 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_241907)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_241989 = heff_field(v_es21_241907, 1);
          switch (heff_tag_of(v_es22_241908)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_241989, 1)) {
              HeffT2 v_t_241991 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_241993 = v_t_241991.f[1];
                int64_t v_tag_241992 = ((int64_t)v_t_241991.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_241992 == ((int64_t)0ULL)) && ({ V v_y_241995 = heff_dup(v_field_241993); int c_ = heff_strEq_c_lent(v_x_240, v_y_241995, 0); heff_drop(v_y_241995); c_; })));
                heff_drop(v_field_241993);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_241908);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_241907);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetNU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242005 = heff_field(v_es2_243, 0);
        V v_es22_242006 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242005)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242087 = heff_field(v_es21_242005, 1);
          switch (heff_tag_of(v_es22_242006)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242087, 1)) {
              HeffT2 v_t_242089 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242091 = v_t_242089.f[1];
                int64_t v_tag_242090 = ((int64_t)v_t_242089.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242090 == ((int64_t)0ULL)) && ({ V v_y_242093 = heff_dup(v_field_242091); int c_ = heff_strEq_c_lent(v_x_240, v_y_242093, 0); heff_drop(v_y_242093); c_; })));
                heff_drop(v_field_242091);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242006);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242005);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RWord: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242100 = heff_field(v_es2_243, 0);
        V v_es22_242101 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242100)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242182 = heff_field(v_es21_242100, 1);
          switch (heff_tag_of(v_es22_242101)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242182, 1)) {
              HeffT2 v_t_242184 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242186 = v_t_242184.f[1];
                int64_t v_tag_242185 = ((int64_t)v_t_242184.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242185 == ((int64_t)0ULL)) && ({ V v_y_242188 = heff_dup(v_field_242186); int c_ = heff_strEq_c_lent(v_x_240, v_y_242188, 0); heff_drop(v_y_242188); c_; })));
                heff_drop(v_field_242186);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242101);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242100);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RTakeField: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242195 = heff_field(v_es2_243, 0);
        V v_es22_242196 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242195)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242277 = heff_field(v_es21_242195, 1);
          switch (heff_tag_of(v_es22_242196)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242277, 1)) {
              HeffT2 v_t_242279 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242281 = v_t_242279.f[1];
                int64_t v_tag_242280 = ((int64_t)v_t_242279.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242280 == ((int64_t)0ULL)) && ({ V v_y_242283 = heff_dup(v_field_242281); int c_ = heff_strEq_c_lent(v_x_240, v_y_242283, 0); heff_drop(v_y_242283); c_; })));
                heff_drop(v_field_242281);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242196);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242195);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RGetLabel: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242290 = heff_field(v_es2_243, 0);
        V v_es22_242291 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242290)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242372 = heff_field(v_es21_242290, 1);
          switch (heff_tag_of(v_es22_242291)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242372, 1)) {
              HeffT2 v_t_242374 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242376 = v_t_242374.f[1];
                int64_t v_tag_242375 = ((int64_t)v_t_242374.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242375 == ((int64_t)0ULL)) && ({ V v_y_242378 = heff_dup(v_field_242376); int c_ = heff_strEq_c_lent(v_x_240, v_y_242378, 0); heff_drop(v_y_242378); c_; })));
                heff_drop(v_field_242376);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242291);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242290);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimFn: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242384 = heff_field(v_es2_243, 0);
        V v_es22_242385 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242384)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242466 = heff_field(v_es21_242384, 1);
          switch (heff_tag_of(v_es22_242385)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242466, 1)) {
              HeffT2 v_t_242468 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242470 = v_t_242468.f[1];
                int64_t v_tag_242469 = ((int64_t)v_t_242468.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242469 == ((int64_t)0ULL)) && ({ V v_y_242472 = heff_dup(v_field_242470); int c_ = heff_strEq_c_lent(v_x_240, v_y_242472, 0); heff_drop(v_y_242472); c_; })));
                heff_drop(v_field_242470);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242385);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242384);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrim: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242479 = heff_field(v_es2_243, 0);
        V v_es22_242480 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242479)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242561 = heff_field(v_es21_242479, 1);
          switch (heff_tag_of(v_es22_242480)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242561, 1)) {
              HeffT2 v_t_242563 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242565 = v_t_242563.f[1];
                int64_t v_tag_242564 = ((int64_t)v_t_242563.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242564 == ((int64_t)0ULL)) && ({ V v_y_242567 = heff_dup(v_field_242565); int c_ = heff_strEq_c_lent(v_x_240, v_y_242567, 0); heff_drop(v_y_242567); c_; })));
                heff_drop(v_field_242565);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242480);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242479);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RLam: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242576 = heff_field(v_es2_243, 0);
        V v_es22_242577 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242576)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242658 = heff_field(v_es21_242576, 1);
          switch (heff_tag_of(v_es22_242577)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242658, 1)) {
              HeffT2 v_t_242660 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242662 = v_t_242660.f[1];
                int64_t v_tag_242661 = ((int64_t)v_t_242660.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242661 == ((int64_t)0ULL)) && ({ V v_y_242664 = heff_dup(v_field_242662); int c_ = heff_strEq_c_lent(v_x_240, v_y_242664, 0); heff_drop(v_y_242664); c_; })));
                heff_drop(v_field_242662);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242577);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242576);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RCall: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242673 = heff_field(v_es2_243, 0);
        V v_es22_242674 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242673)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242755 = heff_field(v_es21_242673, 1);
          switch (heff_tag_of(v_es22_242674)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242755, 1)) {
              HeffT2 v_t_242757 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242759 = v_t_242757.f[1];
                int64_t v_tag_242758 = ((int64_t)v_t_242757.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242758 == ((int64_t)0ULL)) && ({ V v_y_242761 = heff_dup(v_field_242759); int c_ = heff_strEq_c_lent(v_x_240, v_y_242761, 0); heff_drop(v_y_242761); c_; })));
                heff_drop(v_field_242759);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242674);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242673);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RApply: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242768 = heff_field(v_es2_243, 0);
        V v_es22_242769 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242768)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242850 = heff_field(v_es21_242768, 1);
          switch (heff_tag_of(v_es22_242769)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242850, 1)) {
              HeffT2 v_t_242852 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242854 = v_t_242852.f[1];
                int64_t v_tag_242853 = ((int64_t)v_t_242852.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242853 == ((int64_t)0ULL)) && ({ V v_y_242856 = heff_dup(v_field_242854); int c_ = heff_strEq_c_lent(v_x_240, v_y_242856, 0); heff_drop(v_y_242856); c_; })));
                heff_drop(v_field_242854);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242769);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242768);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBool: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242862 = heff_field(v_es2_243, 0);
        V v_es22_242863 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242862)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_242944 = heff_field(v_es21_242862, 1);
          switch (heff_tag_of(v_es22_242863)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_242944, 1)) {
              HeffT2 v_t_242946 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_242948 = v_t_242946.f[1];
                int64_t v_tag_242947 = ((int64_t)v_t_242946.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_242947 == ((int64_t)0ULL)) && ({ V v_y_242950 = heff_dup(v_field_242948); int c_ = heff_strEq_c_lent(v_x_240, v_y_242950, 0); heff_drop(v_y_242950); c_; })));
                heff_drop(v_field_242948);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242863);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242862);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RAbandon: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_242955 = heff_field(v_es2_243, 0);
        V v_es22_242956 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_242955)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243037 = heff_field(v_es21_242955, 1);
          switch (heff_tag_of(v_es22_242956)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243037, 1)) {
              HeffT2 v_t_243039 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243041 = v_t_243039.f[1];
                int64_t v_tag_243040 = ((int64_t)v_t_243039.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243040 == ((int64_t)0ULL)) && ({ V v_y_243043 = heff_dup(v_field_243041); int c_ = heff_strEq_c_lent(v_x_240, v_y_243043, 0); heff_drop(v_y_243043); c_; })));
                heff_drop(v_field_243041);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_242956);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_242955);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RBox: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243050 = heff_field(v_es2_243, 0);
        V v_es22_243051 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243050)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243132 = heff_field(v_es21_243050, 1);
          switch (heff_tag_of(v_es22_243051)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243132, 1)) {
              HeffT2 v_t_243134 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243136 = v_t_243134.f[1];
                int64_t v_tag_243135 = ((int64_t)v_t_243134.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243135 == ((int64_t)0ULL)) && ({ V v_y_243138 = heff_dup(v_field_243136); int c_ = heff_strEq_c_lent(v_x_240, v_y_243138, 0); heff_drop(v_y_243138); c_; })));
                heff_drop(v_field_243136);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243051);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243050);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RUnbox: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243145 = heff_field(v_es2_243, 0);
        V v_es22_243146 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243145)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243227 = heff_field(v_es21_243145, 1);
          switch (heff_tag_of(v_es22_243146)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243227, 1)) {
              HeffT2 v_t_243229 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243231 = v_t_243229.f[1];
                int64_t v_tag_243230 = ((int64_t)v_t_243229.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243230 == ((int64_t)0ULL)) && ({ V v_y_243233 = heff_dup(v_field_243231); int c_ = heff_strEq_c_lent(v_x_240, v_y_243233, 0); heff_drop(v_y_243233); c_; })));
                heff_drop(v_field_243231);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243146);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243145);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPeek: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243240 = heff_field(v_es2_243, 0);
        V v_es22_243241 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243240)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243322 = heff_field(v_es21_243240, 1);
          switch (heff_tag_of(v_es22_243241)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243322, 1)) {
              HeffT2 v_t_243324 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243326 = v_t_243324.f[1];
                int64_t v_tag_243325 = ((int64_t)v_t_243324.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243325 == ((int64_t)0ULL)) && ({ V v_y_243328 = heff_dup(v_field_243326); int c_ = heff_strEq_c_lent(v_x_240, v_y_243328, 0); heff_drop(v_y_243328); c_; })));
                heff_drop(v_field_243326);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243241);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243240);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimU: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243335 = heff_field(v_es2_243, 0);
        V v_es22_243336 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243335)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243417 = heff_field(v_es21_243335, 1);
          switch (heff_tag_of(v_es22_243336)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243417, 1)) {
              HeffT2 v_t_243419 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243421 = v_t_243419.f[1];
                int64_t v_tag_243420 = ((int64_t)v_t_243419.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243420 == ((int64_t)0ULL)) && ({ V v_y_243423 = heff_dup(v_field_243421); int c_ = heff_strEq_c_lent(v_x_240, v_y_243423, 0); heff_drop(v_y_243423); c_; })));
                heff_drop(v_field_243421);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243336);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243335);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RPrimAt: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243431 = heff_field(v_es2_243, 0);
        V v_es22_243432 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243431)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243513 = heff_field(v_es21_243431, 1);
          switch (heff_tag_of(v_es22_243432)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243513, 1)) {
              HeffT2 v_t_243515 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243517 = v_t_243515.f[1];
                int64_t v_tag_243516 = ((int64_t)v_t_243515.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243516 == ((int64_t)0ULL)) && ({ V v_y_243519 = heff_dup(v_field_243517); int c_ = heff_strEq_c_lent(v_x_240, v_y_243519, 0); heff_drop(v_y_243519); c_; })));
                heff_drop(v_field_243517);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243432);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243431);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RFixU: {
      V v_es12_243525 = heff_field(v_es1_242, 1);
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e_243526 = heff_field(v_es2_243, 0);
        V v_es22_243527 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es22_243527)) {
        case TAG_Nil: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_es12_243525, 1)) {
            HeffT2 v_t_243529 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_e_243526)));
            {
              V v_field_243531 = v_t_243529.f[1];
              int64_t v_tag_243530 = ((int64_t)v_t_243529.f[0]);
              V v_ret_24bool = heff_bool(((v_tag_243530 == ((int64_t)0ULL)) && ({ V v_y_243533 = heff_dup(v_field_243531); int c_ = heff_strEq_c_lent(v_x_240, v_y_243533, 0); heff_drop(v_y_243533); c_; })));
              heff_drop(v_field_243531);
              return v_ret_24bool;
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es22_243527);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF32U: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243537 = heff_field(v_es2_243, 0);
        V v_es22_243538 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243537)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243619 = heff_field(v_es21_243537, 1);
          switch (heff_tag_of(v_es22_243538)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243619, 1)) {
              HeffT2 v_t_243621 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243623 = v_t_243621.f[1];
                int64_t v_tag_243622 = ((int64_t)v_t_243621.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243622 == ((int64_t)0ULL)) && ({ V v_y_243625 = heff_dup(v_field_243623); int c_ = heff_strEq_c_lent(v_x_240, v_y_243625, 0); heff_drop(v_y_243625); c_; })));
                heff_drop(v_field_243623);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243538);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243537);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    case TAG_RF64U: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_243631 = heff_field(v_es2_243, 0);
        V v_es22_243632 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_243631)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_243713 = heff_field(v_es21_243631, 1);
          switch (heff_tag_of(v_es22_243632)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_243713, 1)) {
              HeffT2 v_t_243715 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(heff_dup(v_es1_242)));
              {
                V v_field_243717 = v_t_243715.f[1];
                int64_t v_tag_243716 = ((int64_t)v_t_243715.f[0]);
                V v_ret_24bool = heff_bool(((v_tag_243716 == ((int64_t)0ULL)) && ({ V v_y_243719 = heff_dup(v_field_243717); int c_ = heff_strEq_c_lent(v_x_240, v_y_243719, 0); heff_drop(v_y_243719); c_; })));
                heff_drop(v_field_243717);
                return v_ret_24bool;
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_243632);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_243631);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    default: return heff_nomatch(v_es1_242);
    }
  }
  default: return heff_nomatch(v_es_241);
  }
}
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2estepSum(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2estepOf_str0, 7, "wordAdd");
Clo g_heff_2ecompile_2ebounds_2estepOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2estepOf_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2estepOf(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    HeffT2 v_t_243 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_244 == ((int64_t)0ULL)) && ({ V v_y_247 = heff_dup(v_field_245); int c_ = heff_strEq_c_lent(v_x_240, v_y_247, 0); heff_drop(v_y_247); c_; })));
      heff_drop(v_field_245);
      return v_ret_24bool;
    }
  }
  case TAG_RDup: {
    HeffT2 v_t_249 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_y_2413 = heff_dup(v_field_2411); int c_ = heff_strEq_c_lent(v_x_240, v_y_2413, 0); heff_drop(v_y_2413); c_; })));
      heff_drop(v_field_2411);
      return v_ret_24bool;
    }
  }
  case TAG_RClo: {
    HeffT2 v_t_2415 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2416 == ((int64_t)0ULL)) && ({ V v_y_2419 = heff_dup(v_field_2417); int c_ = heff_strEq_c_lent(v_x_240, v_y_2419, 0); heff_drop(v_y_2419); c_; })));
      heff_drop(v_field_2417);
      return v_ret_24bool;
    }
  }
  case TAG_RGet: {
    HeffT2 v_t_2421 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2422 == ((int64_t)0ULL)) && ({ V v_y_2425 = heff_dup(v_field_2423); int c_ = heff_strEq_c_lent(v_x_240, v_y_2425, 0); heff_drop(v_y_2425); c_; })));
      heff_drop(v_field_2423);
      return v_ret_24bool;
    }
  }
  case TAG_RGetRaw: {
    HeffT2 v_t_2427 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2428 == ((int64_t)0ULL)) && ({ V v_y_2431 = heff_dup(v_field_2429); int c_ = heff_strEq_c_lent(v_x_240, v_y_2431, 0); heff_drop(v_y_2431); c_; })));
      heff_drop(v_field_2429);
      return v_ret_24bool;
    }
  }
  case TAG_RInt: {
    HeffT2 v_t_2433 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2434 == ((int64_t)0ULL)) && ({ V v_y_2437 = heff_dup(v_field_2435); int c_ = heff_strEq_c_lent(v_x_240, v_y_2437, 0); heff_drop(v_y_2437); c_; })));
      heff_drop(v_field_2435);
      return v_ret_24bool;
    }
  }
  case TAG_RFloat: {
    HeffT2 v_t_2439 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2441 = v_t_2439.f[1];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2440 == ((int64_t)0ULL)) && ({ V v_y_2443 = heff_dup(v_field_2441); int c_ = heff_strEq_c_lent(v_x_240, v_y_2443, 0); heff_drop(v_y_2443); c_; })));
      heff_drop(v_field_2441);
      return v_ret_24bool;
    }
  }
  case TAG_RStr: {
    HeffT2 v_t_2445 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2447 = v_t_2445.f[1];
      int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2446 == ((int64_t)0ULL)) && ({ V v_y_2449 = heff_dup(v_field_2447); int c_ = heff_strEq_c_lent(v_x_240, v_y_2449, 0); heff_drop(v_y_2449); c_; })));
      heff_drop(v_field_2447);
      return v_ret_24bool;
    }
  }
  case TAG_RBytes: {
    HeffT2 v_t_2451 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2453 = v_t_2451.f[1];
      int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2452 == ((int64_t)0ULL)) && ({ V v_y_2455 = heff_dup(v_field_2453); int c_ = heff_strEq_c_lent(v_x_240, v_y_2455, 0); heff_drop(v_y_2455); c_; })));
      heff_drop(v_field_2453);
      return v_ret_24bool;
    }
  }
  case TAG_RFixed: {
    HeffT2 v_t_2458 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_y_2462 = heff_dup(v_field_2460); int c_ = heff_strEq_c_lent(v_x_240, v_y_2462, 0); heff_drop(v_y_2462); c_; })));
      heff_drop(v_field_2460);
      return v_ret_24bool;
    }
  }
  case TAG_RF32: {
    HeffT2 v_t_2464 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2466 = v_t_2464.f[1];
      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2465 == ((int64_t)0ULL)) && ({ V v_y_2468 = heff_dup(v_field_2466); int c_ = heff_strEq_c_lent(v_x_240, v_y_2468, 0); heff_drop(v_y_2468); c_; })));
      heff_drop(v_field_2466);
      return v_ret_24bool;
    }
  }
  case TAG_RNTag: {
    HeffT2 v_t_2470 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2471 == ((int64_t)0ULL)) && ({ V v_y_2474 = heff_dup(v_field_2472); int c_ = heff_strEq_c_lent(v_x_240, v_y_2474, 0); heff_drop(v_y_2474); c_; })));
      heff_drop(v_field_2472);
      return v_ret_24bool;
    }
  }
  case TAG_RTag: {
    HeffT2 v_t_2478 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2480 = v_t_2478.f[1];
      int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2479 == ((int64_t)0ULL)) && ({ V v_y_2482 = heff_dup(v_field_2480); int c_ = heff_strEq_c_lent(v_x_240, v_y_2482, 0); heff_drop(v_y_2482); c_; })));
      heff_drop(v_field_2480);
      return v_ret_24bool;
    }
  }
  case TAG_RTagIn: {
    HeffT2 v_t_2487 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2488 == ((int64_t)0ULL)) && ({ V v_y_2491 = heff_dup(v_field_2489); int c_ = heff_strEq_c_lent(v_x_240, v_y_2491, 0); heff_drop(v_y_2491); c_; })));
      heff_drop(v_field_2489);
      return v_ret_24bool;
    }
  }
  case TAG_RRec: {
    HeffT2 v_t_2495 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_2497 = v_t_2495.f[1];
      int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2496 == ((int64_t)0ULL)) && ({ V v_y_2499 = heff_dup(v_field_2497); int c_ = heff_strEq_c_lent(v_x_240, v_y_2499, 0); heff_drop(v_y_2499); c_; })));
      heff_drop(v_field_2497);
      return v_ret_24bool;
    }
  }
  case TAG_RRecIn: {
    HeffT2 v_t_24108 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24110 = v_t_24108.f[1];
      int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24109 == ((int64_t)0ULL)) && ({ V v_y_24112 = heff_dup(v_field_24110); int c_ = heff_strEq_c_lent(v_x_240, v_y_24112, 0); heff_drop(v_y_24112); c_; })));
      heff_drop(v_field_24110);
      return v_ret_24bool;
    }
  }
  case TAG_RField: {
    HeffT2 v_t_24115 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24117 = v_t_24115.f[1];
      int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24116 == ((int64_t)0ULL)) && ({ V v_y_24119 = heff_dup(v_field_24117); int c_ = heff_strEq_c_lent(v_x_240, v_y_24119, 0); heff_drop(v_y_24119); c_; })));
      heff_drop(v_field_24117);
      return v_ret_24bool;
    }
  }
  case TAG_RDupE: {
    HeffT2 v_t_24121 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24123 = v_t_24121.f[1];
      int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24122 == ((int64_t)0ULL)) && ({ V v_y_24125 = heff_dup(v_field_24123); int c_ = heff_strEq_c_lent(v_x_240, v_y_24125, 0); heff_drop(v_y_24125); c_; })));
      heff_drop(v_field_24123);
      return v_ret_24bool;
    }
  }
  case TAG_RFieldV: {
    HeffT2 v_t_24128 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24130 = v_t_24128.f[1];
      int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24129 == ((int64_t)0ULL)) && ({ V v_y_24132 = heff_dup(v_field_24130); int c_ = heff_strEq_c_lent(v_x_240, v_y_24132, 0); heff_drop(v_y_24132); c_; })));
      heff_drop(v_field_24130);
      return v_ret_24bool;
    }
  }
  case TAG_RGetN: {
    HeffT2 v_t_24136 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24138 = v_t_24136.f[1];
      int64_t v_tag_24137 = ((int64_t)v_t_24136.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24137 == ((int64_t)0ULL)) && ({ V v_y_24140 = heff_dup(v_field_24138); int c_ = heff_strEq_c_lent(v_x_240, v_y_24140, 0); heff_drop(v_y_24140); c_; })));
      heff_drop(v_field_24138);
      return v_ret_24bool;
    }
  }
  case TAG_RFieldU: {
    HeffT2 v_t_24145 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24147 = v_t_24145.f[1];
      int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24146 == ((int64_t)0ULL)) && ({ V v_y_24149 = heff_dup(v_field_24147); int c_ = heff_strEq_c_lent(v_x_240, v_y_24149, 0); heff_drop(v_y_24149); c_; })));
      heff_drop(v_field_24147);
      return v_ret_24bool;
    }
  }
  case TAG_RGetNU: {
    HeffT2 v_t_24155 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24157 = v_t_24155.f[1];
      int64_t v_tag_24156 = ((int64_t)v_t_24155.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24156 == ((int64_t)0ULL)) && ({ V v_y_24159 = heff_dup(v_field_24157); int c_ = heff_strEq_c_lent(v_x_240, v_y_24159, 0); heff_drop(v_y_24159); c_; })));
      heff_drop(v_field_24157);
      return v_ret_24bool;
    }
  }
  case TAG_RWord: {
    HeffT2 v_t_24162 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24164 = v_t_24162.f[1];
      int64_t v_tag_24163 = ((int64_t)v_t_24162.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24163 == ((int64_t)0ULL)) && ({ V v_y_24166 = heff_dup(v_field_24164); int c_ = heff_strEq_c_lent(v_x_240, v_y_24166, 0); heff_drop(v_y_24166); c_; })));
      heff_drop(v_field_24164);
      return v_ret_24bool;
    }
  }
  case TAG_RTakeField: {
    HeffT2 v_t_24169 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24171 = v_t_24169.f[1];
      int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24170 == ((int64_t)0ULL)) && ({ V v_y_24173 = heff_dup(v_field_24171); int c_ = heff_strEq_c_lent(v_x_240, v_y_24173, 0); heff_drop(v_y_24173); c_; })));
      heff_drop(v_field_24171);
      return v_ret_24bool;
    }
  }
  case TAG_RGetLabel: {
    HeffT2 v_t_24176 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24178 = v_t_24176.f[1];
      int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24177 == ((int64_t)0ULL)) && ({ V v_y_24180 = heff_dup(v_field_24178); int c_ = heff_strEq_c_lent(v_x_240, v_y_24180, 0); heff_drop(v_y_24180); c_; })));
      heff_drop(v_field_24178);
      return v_ret_24bool;
    }
  }
  case TAG_RPrimFn: {
    HeffT2 v_t_24182 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24184 = v_t_24182.f[1];
      int64_t v_tag_24183 = ((int64_t)v_t_24182.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24183 == ((int64_t)0ULL)) && ({ V v_y_24186 = heff_dup(v_field_24184); int c_ = heff_strEq_c_lent(v_x_240, v_y_24186, 0); heff_drop(v_y_24186); c_; })));
      heff_drop(v_field_24184);
      return v_ret_24bool;
    }
  }
  case TAG_RPrim: {
    HeffT2 v_t_24189 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24191 = v_t_24189.f[1];
      int64_t v_tag_24190 = ((int64_t)v_t_24189.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24190 == ((int64_t)0ULL)) && ({ V v_y_24193 = heff_dup(v_field_24191); int c_ = heff_strEq_c_lent(v_x_240, v_y_24193, 0); heff_drop(v_y_24193); c_; })));
      heff_drop(v_field_24191);
      return v_ret_24bool;
    }
  }
  case TAG_RLam: {
    HeffT2 v_t_24198 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24200 = v_t_24198.f[1];
      int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24199 == ((int64_t)0ULL)) && ({ V v_y_24202 = heff_dup(v_field_24200); int c_ = heff_strEq_c_lent(v_x_240, v_y_24202, 0); heff_drop(v_y_24202); c_; })));
      heff_drop(v_field_24200);
      return v_ret_24bool;
    }
  }
  case TAG_RCall: {
    HeffT2 v_t_24207 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24209 = v_t_24207.f[1];
      int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24208 == ((int64_t)0ULL)) && ({ V v_y_24211 = heff_dup(v_field_24209); int c_ = heff_strEq_c_lent(v_x_240, v_y_24211, 0); heff_drop(v_y_24211); c_; })));
      heff_drop(v_field_24209);
      return v_ret_24bool;
    }
  }
  case TAG_RApply: {
    HeffT2 v_t_24214 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24216 = v_t_24214.f[1];
      int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24215 == ((int64_t)0ULL)) && ({ V v_y_24218 = heff_dup(v_field_24216); int c_ = heff_strEq_c_lent(v_x_240, v_y_24218, 0); heff_drop(v_y_24218); c_; })));
      heff_drop(v_field_24216);
      return v_ret_24bool;
    }
  }
  case TAG_RBool: {
    HeffT2 v_t_24220 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24222 = v_t_24220.f[1];
      int64_t v_tag_24221 = ((int64_t)v_t_24220.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24221 == ((int64_t)0ULL)) && ({ V v_y_24224 = heff_dup(v_field_24222); int c_ = heff_strEq_c_lent(v_x_240, v_y_24224, 0); heff_drop(v_y_24224); c_; })));
      heff_drop(v_field_24222);
      return v_ret_24bool;
    }
  }
  case TAG_RAbandon: {
    HeffT2 v_t_24225 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24227 = v_t_24225.f[1];
      int64_t v_tag_24226 = ((int64_t)v_t_24225.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24226 == ((int64_t)0ULL)) && ({ V v_y_24229 = heff_dup(v_field_24227); int c_ = heff_strEq_c_lent(v_x_240, v_y_24229, 0); heff_drop(v_y_24229); c_; })));
      heff_drop(v_field_24227);
      return v_ret_24bool;
    }
  }
  case TAG_RBox: {
    HeffT2 v_t_24232 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24234 = v_t_24232.f[1];
      int64_t v_tag_24233 = ((int64_t)v_t_24232.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24233 == ((int64_t)0ULL)) && ({ V v_y_24236 = heff_dup(v_field_24234); int c_ = heff_strEq_c_lent(v_x_240, v_y_24236, 0); heff_drop(v_y_24236); c_; })));
      heff_drop(v_field_24234);
      return v_ret_24bool;
    }
  }
  case TAG_RUnbox: {
    HeffT2 v_t_24239 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24241 = v_t_24239.f[1];
      int64_t v_tag_24240 = ((int64_t)v_t_24239.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24240 == ((int64_t)0ULL)) && ({ V v_y_24243 = heff_dup(v_field_24241); int c_ = heff_strEq_c_lent(v_x_240, v_y_24243, 0); heff_drop(v_y_24243); c_; })));
      heff_drop(v_field_24241);
      return v_ret_24bool;
    }
  }
  case TAG_RPeek: {
    HeffT2 v_t_24246 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24248 = v_t_24246.f[1];
      int64_t v_tag_24247 = ((int64_t)v_t_24246.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24247 == ((int64_t)0ULL)) && ({ V v_y_24250 = heff_dup(v_field_24248); int c_ = heff_strEq_c_lent(v_x_240, v_y_24250, 0); heff_drop(v_y_24250); c_; })));
      heff_drop(v_field_24248);
      return v_ret_24bool;
    }
  }
  case TAG_RPrimU: {
    V v_p_24251 = heff_field(v_e_241, 0);
    V v_es_24252 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    if (heff_strEq_c(v_p_24251, ((V)&g_heff_2ecompile_2ebounds_2estepOf_str0))) {
      return ({ V a_0 = v_x_240; V a_1 = v_es_24252; V r_ = (g_heff_2ecompile_2ebounds_2estepSum(a_0, a_1)); heff_drop(v_es_24252); r_; });
    } else {
      heff_drop(v_es_24252);
      return NTAG(TAG_False);
    }
  }
  case TAG_RPrimAt: {
    HeffT2 v_t_24257 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24259 = v_t_24257.f[1];
      int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24258 == ((int64_t)0ULL)) && ({ V v_y_24261 = heff_dup(v_field_24259); int c_ = heff_strEq_c_lent(v_x_240, v_y_24261, 0); heff_drop(v_y_24261); c_; })));
      heff_drop(v_field_24259);
      return v_ret_24bool;
    }
  }
  case TAG_RFixU: {
    HeffT2 v_t_24264 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24266 = v_t_24264.f[1];
      int64_t v_tag_24265 = ((int64_t)v_t_24264.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24265 == ((int64_t)0ULL)) && ({ V v_y_24268 = heff_dup(v_field_24266); int c_ = heff_strEq_c_lent(v_x_240, v_y_24268, 0); heff_drop(v_y_24268); c_; })));
      heff_drop(v_field_24266);
      return v_ret_24bool;
    }
  }
  case TAG_RF32U: {
    HeffT2 v_t_24270 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24272 = v_t_24270.f[1];
      int64_t v_tag_24271 = ((int64_t)v_t_24270.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24271 == ((int64_t)0ULL)) && ({ V v_y_24274 = heff_dup(v_field_24272); int c_ = heff_strEq_c_lent(v_x_240, v_y_24274, 0); heff_drop(v_y_24274); c_; })));
      heff_drop(v_field_24272);
      return v_ret_24bool;
    }
  }
  case TAG_RF64U: {
    HeffT2 v_t_24276 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
    {
      V v_field_24278 = v_t_24276.f[1];
      int64_t v_tag_24277 = ((int64_t)v_t_24276.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_24277 == ((int64_t)0ULL)) && ({ V v_y_24280 = heff_dup(v_field_24278); int c_ = heff_strEq_c_lent(v_x_240, v_y_24280, 0); heff_drop(v_y_24280); c_; })));
      heff_drop(v_field_24278);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ebounds_2estepOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2estepOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elengthArray_24cpr_str0, 11, "arrayLength");

HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_x1_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    V v_p_2456 = heff_field(v_x1_240, 0);
    V v_x12_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_2457)) {
    case TAG_Nil: {
      heff_drop(v_p_2456);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_2458 = heff_field(v_x12_2457, 0);
      V v_x122_2459 = heff_field(v_x12_2457, 1);
      heff_take_n(v_x12_2457, 3ULL, 2);
      switch (heff_tag_of(v_x122_2459)) {
      case TAG_Nil: {
        if (heff_strEq_c(v_p_2456, ((V)&g_heff_2ecompile_2ebounds_2elengthArray_24cpr_str0))) {
          HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_2458);
        } else {
          heff_drop(v_e_2458);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x122_2459, 0ULL, 2);
        heff_drop(v_p_2456);
        heff_drop(v_e_2458);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2459)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2457)}});
    }
  }
  case TAG_RLam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2elengthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elengthOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2elengthOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2elengthOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2elengthOf(a[0]);
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V v_info_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_info_240, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_info_240, 3);
      heff_drop(v_i_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_t_245 = (g_heff_2ecompile_2ebounds_2eelemS(v_i_243, heff_rfield(v_info_240, 0)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V v_x1_247 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0, 1, 2, (V[]){heff_dup(v_info_240), v_a_244}), heff_get_n(v_info_240, 1, 3)));
        switch (heff_tag_of(v_x1_247)) {
        case TAG_Nil: {
          heff_drop(v_i_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_248 = heff_field(v_x1_247, 0);
          heff_take_n(v_x1_247, 1ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_index__array, (V[]){v_i_243, v_x_248})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
        }
      } else {
        heff_drop_rec(v_info_240, 3);
        heff_drop(v_i_243);
        heff_drop(v_a_244);
        heff_drop(v_t_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args) {
  V v_b_246 = args[0];
  V v_info_240 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2ebounds_2esameAs(heff_get_n(v_info_240, 2, 3), NTAG(TAG_Nil), v_b_246, heff_tag_n(TAG_RLocal, 1, (V[]){v_a_244})));
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2erelTest_24cpr_str0, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2ebounds_2erelTest_24cpr_str1, 6, "wordLe");

HeffT2 g_heff_2ecompile_2ebounds_2erelTest_24cpr(V v_info_240, V v_p_241, V v_es_242) {
top: ;
  switch (heff_tag_of(v_es_242)) {
  case TAG_Nil: {
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_es_242, 0);
    V v_es2_244 = heff_field(v_es_242, 1);
    V v_ru_24es_242_24Cons = heff_take_reuse_n(v_es_242, 3ULL, 2);
    switch (heff_tag_of(v_es2_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_a_243);
      heff_drop_cell(v_ru_24es_242_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_245 = heff_field(v_es2_244, 0);
      V v_es22_246 = heff_field(v_es2_244, 1);
      heff_take_n(v_es2_244, 3ULL, 2);
      switch (heff_tag_of(v_es22_246)) {
      case TAG_Nil: {
        if (heff_strEq_c_lent(v_p_241, ((V)&g_heff_2ecompile_2ebounds_2erelTest_24cpr_str0), 2)) {
          V v_t_248 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_243));
          V v_t_249 = (g_heff_2ecompile_2ebounds_2elengthOf(v_b_245));
          HeffT2 v_t_2410 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_240, v_t_248, v_t_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_r_2414 = v_field_2412;
              V v_t_2415 = heff_tag_at_n(v_ru_24es_242_24Cons, TAG_MkPair, 2, (V[]){v_r_2414, NTAG(TAG_True)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
            } else {
              heff_drop_cell(v_ru_24es_242_24Cons, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_p_241, ((V)&g_heff_2ecompile_2ebounds_2erelTest_24cpr_str1), 2)) {
            V v_t_2417 = (g_heff_2ecompile_2ebounds_2evarOf(v_b_245));
            V v_t_2418 = (g_heff_2ecompile_2ebounds_2elengthOf(v_a_243));
            HeffT2 v_t_2419 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_240, v_t_2417, v_t_2418));
            {
              V v_field_2421 = v_t_2419.f[1];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                V v_r_2423 = v_field_2421;
                V v_t_2424 = heff_tag_at_n(v_ru_24es_242_24Cons, TAG_MkPair, 2, (V[]){v_r_2423, NTAG(TAG_False)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2424}});
              } else {
                heff_drop_cell(v_ru_24es_242_24Cons, 2);
                heff_drop(v_field_2421);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_info_240);
            heff_drop(v_a_243);
            heff_drop_cell(v_ru_24es_242_24Cons, 2);
            heff_drop(v_b_245);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_es22_246, 0ULL, 2);
        heff_drop(v_info_240);
        heff_drop(v_a_243);
        heff_drop_cell(v_ru_24es_242_24Cons, 2);
        heff_drop(v_b_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_es22_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_es_242)}});
  }
}

HeffT2 g_heff_2ecompile_2ebounds_2eindexOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTagIn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RRec: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RRecIn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RDupE: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFieldV: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetN: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFieldU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetNU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RWord: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RGetLabel: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrim: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RLam: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RCall: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RApply: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBool: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RBox: {
    V v_e_2470 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_2470);
  }
  case TAG_RUnbox: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPeek: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RPrimAt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_x1_240);
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V v_info_240, V v_env_241, V v_fl_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_info_240, 3);
    heff_drop(v_env_241);
    heff_drop(v_fl_242);
    heff_drop(v_x5_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_y_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_info_240, 3);
      heff_drop(v_env_241);
      heff_drop(v_fl_242);
      heff_drop(v_y_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_x1_247 = (g_list_2ekeepIf_24s1282433449x1943698445(v_i_246, v_env_241));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Nil: {
        heff_drop_rec(v_info_240, 3);
        heff_drop(v_fl_242);
        heff_drop(v_y_245);
        heff_drop(v_i_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 2);
        V v_x1_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0, 1, 2, (V[]){heff_dup(v_info_240), v_y_245}), heff_get_n(v_info_240, 1, 3)));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_Nil: {
          heff_drop(v_fl_242);
          heff_drop(v_i_246);
          heff_drop_rec(v_x_248, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x1_2411, 0);
          heff_take_n(v_x1_2411, 1ULL, 2);
          V v_f_2414 = heff_rec_n(4, shape_index__tested__read__flat, (V[]){v_i_246, heff_get_n(v_x_248, 1, 2), v_x_2412, v_fl_242});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args) {
  V v_b_2410 = args[0];
  V v_info_240 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2ebounds_2esameAs(heff_get_n(v_info_240, 2, 3), NTAG(TAG_Nil), v_b_2410, heff_tag_n(TAG_RLocal, 1, (V[]){v_y_245})));
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eneedsIn_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eneedsIn(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2ebounds_2eownNeed_24cpr(heff_dup(v_info_240), heff_dup(v_env_241), heff_dup(v_e_242)));
  V v_t_248;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_field_245);
      v_t_248 = NTAG(TAG_Nil);
    }
  }
  V v_f_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2eneedsIn_clo), 2, (V[]){v_info_240, v_env_241}));
  V v_xs_2410 = (g_heff_2ecompile_2eowned_2ekids(v_e_242));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
  V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eneedsIn_lam0, 2, 1, (V[]){v_f_249}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  return (g_prelude_2e_2b_2b(v_t_248, v_t_2415));
}
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eneedsIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_f_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(v_f_249, 1, (V[]){v_x_2413}));
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str1, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str2, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str3, 15, "arraySetOwnedIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str4, 9, "arrayPeek");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str5, 11, "arrayPeekIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str6, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str7, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str8, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str9, 15, "arraySetOwnedIn");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str10, 9, "arrayPeek");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eunchecked_str11, 11, "arrayPeekIn");
Clo g_heff_2ecompile_2ebounds_2eunchecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eunchecked_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eunchecked(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_RLocal: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RDup: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RClo: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGet: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetRaw: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RInt: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFloat: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RStr: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBytes: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFixed: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF32: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RNTag: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTag: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTagIn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RRec: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RRecIn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RField: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RDupE: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFieldV: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetN: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RFieldU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetNU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RWord: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RTakeField: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RGetLabel: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimFn: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrim: {
    V v_p_2458 = heff_field(v_e_242, 0);
    V v_es_2459 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24RPrim = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2460 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_241, v_p_2458, NTAG(TAG_Nothing), heff_dup(v_es_2459)));
    V v_t_2468;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2464 = v_field_2462;
        heff_drop(v_x_2464);
        if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str0), 2)) {
          heff_drop(v_p_2458);
          v_t_2468 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str1);
        } else {
          if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str2), 2)) {
            heff_drop(v_p_2458);
            v_t_2468 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str3);
          } else {
            if (heff_strEq_c_lent(v_p_2458, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str4), 2)) {
              heff_drop(v_p_2458);
              v_t_2468 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str5);
            } else {
              v_t_2468 = v_p_2458;
            }
          }
        }
      } else {
        heff_drop(v_field_2462);
        v_t_2468 = v_p_2458;
      }
    }
    return heff_tag_at_n(v_ru_24e_242_24RPrim, TAG_RPrim, 2, (V[]){v_t_2468, v_es_2459});
  }
  case TAG_RLam: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RCall: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RApply: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBool: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RAbandon: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RBox: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RUnbox: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPeek: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RPrimAt: {
    V v_p_2488 = heff_field(v_e_242, 0);
    V v_r_2489 = heff_field(v_e_242, 1);
    V v_es_2490 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24RPrimAt = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2491 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_241, v_p_2488, NTAG(TAG_Nothing), heff_dup(v_es_2490)));
    V v_t_2499;
    {
      V v_field_2493 = v_t_2491.f[1];
      int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
      if ((v_tag_2492 == ((int64_t)0ULL))) {
        V v_x_2495 = v_field_2493;
        heff_drop(v_x_2495);
        if (heff_strEq_c_lent(v_p_2488, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str6), 2)) {
          heff_drop(v_p_2488);
          v_t_2499 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str7);
        } else {
          if (heff_strEq_c_lent(v_p_2488, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str8), 2)) {
            heff_drop(v_p_2488);
            v_t_2499 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str9);
          } else {
            if (heff_strEq_c_lent(v_p_2488, ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str10), 2)) {
              heff_drop(v_p_2488);
              v_t_2499 = ((V)&g_heff_2ecompile_2ebounds_2eunchecked_str11);
            } else {
              v_t_2499 = v_p_2488;
            }
          }
        }
      } else {
        heff_drop(v_field_2493);
        v_t_2499 = v_p_2488;
      }
    }
    return heff_tag_at_n(v_ru_24e_242_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_t_2499, v_r_2489, v_es_2490});
  }
  case TAG_RFixU: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF32U: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  case TAG_RF64U: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eunchecked(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elabel_str0, 7, "InRange");

static V g_heff_2ecompile_2ebounds_2elabel_val;
static HEFF_ONCE g_heff_2ecompile_2ebounds_2elabel_st;
static V g_heff_2ecompile_2ebounds_2elabel_init(void) {
  return ((V)&g_heff_2ecompile_2ebounds_2elabel_str0);
}
V g_heff_2ecompile_2ebounds_2elabel_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ebounds_2elabel_st)) return g_heff_2ecompile_2ebounds_2elabel_val;
  return heff_global(&g_heff_2ecompile_2ebounds_2elabel_val, &g_heff_2ecompile_2ebounds_2elabel_st, g_heff_2ecompile_2ebounds_2elabel_init);
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2efixSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2efixSt_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2efixSt(V v_go_240, V v_info_241, V v_env_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CLet: {
    V v_x_245 = heff_field(v_s_243, 0);
    V v_e_246 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLet = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_247 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_246));
    return heff_tag_at_n(v_ru_24s_243_24CLet, TAG_CLet, 2, (V[]){v_x_245, v_t_247});
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CSet: {
    V v_x_249 = heff_field(v_s_243, 0);
    V v_e_2410 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CSet = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2411 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_2410));
    return heff_tag_at_n(v_ru_24s_243_24CSet, TAG_CSet, 2, (V[]){v_x_249, v_t_2411});
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CIf: {
    V v_c_2412 = heff_field(v_s_243, 0);
    V v_a_2413 = heff_field(v_s_243, 1);
    V v_b_2414 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CIf = heff_take_reuse_n(v_s_243, 7ULL, 3);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_info_241), heff_dup(v_env_242)}));
    V v_t_2416 = (g_heff_2ecompile_2eowned_2emapCond(v_t_2415, heff_dup(v_c_2412)));
    HeffT2 v_t_2417 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(heff_dup(v_info_241), heff_dup(v_c_2412)));
    V v_t_2424;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x21_2421 = v_field_2419;
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_r_2422 = heff_field(v_x21_2421, 0);
          V v_x212_2423 = heff_field(v_x21_2421, 1);
          V v_ru_24x21_2421_24MkPair = heff_take_reuse_n(v_x21_2421, 3ULL, 2);
          if ((heff_dup(v_x212_2423) == NTAG(TAG_True))) {
            heff_drop(v_x212_2423);
            v_t_2424 = heff_tag_at_n(v_ru_24x21_2421_24MkPair, TAG_Cons, 2, (V[]){v_r_2422, heff_dup(v_env_242)});
          } else {
            heff_drop(v_r_2422);
            heff_drop(v_x212_2423);
            heff_drop_cell(v_ru_24x21_2421_24MkPair, 2);
            v_t_2424 = heff_dup(v_env_242);
          }
          break;
        }
        default: heff_nomatch(v_x21_2421);
        }
      } else {
        heff_drop(v_field_2419);
        v_t_2424 = heff_dup(v_env_242);
      }
    }
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_t_2424, v_a_2413}));
    HeffT2 v_t_2426 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_241, v_c_2412));
    V v_t_2433;
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_x21_2430 = v_field_2428;
        switch (heff_tag_of(v_x21_2430)) {
        case TAG_MkPair: {
          V v_r_2431 = heff_field(v_x21_2430, 0);
          V v_x212_2432 = heff_field(v_x21_2430, 1);
          V v_ru_24x21_2430_24MkPair = heff_take_reuse_n(v_x21_2430, 3ULL, 2);
          if ((heff_dup(v_x212_2432) == NTAG(TAG_True))) {
            heff_drop(v_r_2431);
            heff_drop(v_x212_2432);
            heff_drop_cell(v_ru_24x21_2430_24MkPair, 2);
            v_t_2433 = v_env_242;
          } else {
            heff_drop(v_x212_2432);
            v_t_2433 = heff_tag_at_n(v_ru_24x21_2430_24MkPair, TAG_Cons, 2, (V[]){v_r_2431, v_env_242});
          }
          break;
        }
        default: heff_nomatch(v_x21_2430);
        }
      } else {
        heff_drop(v_field_2428);
        v_t_2433 = v_env_242;
      }
    }
    V v_t_2434 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2433, v_b_2414}));
    return heff_tag_at_n(v_ru_24s_243_24CIf, TAG_CIf, 3, (V[]){v_t_2416, v_t_2425, v_t_2434});
  }
  case TAG_CSwitch: {
    V v_e_2435 = heff_field(v_s_243, 0);
    V v_arms_2436 = heff_field(v_s_243, 1);
    V v_r_2437 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CSwitch = heff_take_reuse_n(v_s_243, 7ULL, 3);
    V v_t_2438 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, heff_dup(v_env_242), v_e_2435));
    V v_go_2439 = heff_tr(heff_call(v_go_240, 1, (V[]){v_env_242}));
    V v_t_2450 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2efixSt_lam0, 1, 1, (V[]){v_go_2439}), v_arms_2436));
    return heff_tag_at_n(v_ru_24s_243_24CSwitch, TAG_CSwitch, 3, (V[]){v_t_2438, v_t_2450, v_r_2437});
  }
  case TAG_CReturn: {
    V v_e_2451 = heff_field(v_s_243, 0);
    V v_ru_24s_243_24CReturn = heff_take_reuse_n(v_s_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_2452 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_info_241, v_env_242, v_e_2451));
    return heff_tag_at_n(v_ru_24s_243_24CReturn, TAG_CReturn, 1, (V[]){v_t_2452});
  }
  case TAG_CInPlace: {
    V v_f_2453 = heff_field(v_s_243, 0);
    V v_es_2454 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CInPlace = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2455 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2453));
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2457 = (g_list_2emap(v_t_2456, v_es_2454));
    return heff_tag_at_n(v_ru_24s_243_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2455, v_t_2457});
  }
  case TAG_CRoomed: {
    V v_f_2458 = heff_field(v_s_243, 0);
    V v_es_2459 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CRoomed = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2460 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2458));
    V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2462 = (g_list_2emap(v_t_2461, v_es_2459));
    return heff_tag_at_n(v_ru_24s_243_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2460, v_t_2462});
  }
  case TAG_CTail: {
    V v_f_2463 = heff_field(v_s_243, 0);
    V v_es_2464 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CTail = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2465 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_info_241), heff_dup(v_env_242), v_f_2463));
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2467 = (g_list_2emap(v_t_2466, v_es_2464));
    return heff_tag_at_n(v_ru_24s_243_24CTail, TAG_CTail, 2, (V[]){v_t_2465, v_t_2467});
  }
  case TAG_CLoop: {
    V v_ps_2468 = heff_field(v_s_243, 0);
    V v_es_2469 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2471 = (g_list_2emap(v_t_2470, v_es_2469));
    return heff_tag_n(TAG_CLoopTo, 3, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get()), v_ps_2468, v_t_2471});
  }
  case TAG_CLoopTo: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return v_s_243;
  }
  case TAG_CJump: {
    V v_g_2476 = heff_field(v_s_243, 0);
    V v_w_2477 = heff_field(v_s_243, 1);
    V v_es_2478 = heff_field(v_s_243, 2);
    V v_ru_24s_243_24CJump = heff_take_reuse_n(v_s_243, 7ULL, 3);
    heff_drop(v_go_240);
    V v_t_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){v_info_241, v_env_242}));
    V v_t_2480 = (g_list_2emap(v_t_2479, v_es_2478));
    return heff_tag_at_n(v_ru_24s_243_24CJump, TAG_CJump, 3, (V[]){v_g_2476, v_w_2477, v_t_2480});
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2efixSt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_go_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkCArm: {
    V v_t_2441 = heff_field(v_x2_2440, 0);
    V v_fs_2442 = heff_field(v_x2_2440, 1);
    V v_fl_2443 = heff_field(v_x2_2440, 2);
    V v_su_2444 = heff_field(v_x2_2440, 3);
    V v_pl_2445 = heff_field(v_x2_2440, 4);
    V v_tk_2446 = heff_field(v_x2_2440, 5);
    V v_body_2447 = heff_field(v_x2_2440, 6);
    V v_lv_2448 = heff_field(v_x2_2440, 7);
    V v_ru_24x2_2440_24MkCArm = heff_take_reuse_n(v_x2_2440, 255ULL, 8);
    V v_t_2449 = heff_tr(heff_call(v_go_2439, 1, (V[]){v_body_2447}));
    return heff_tag_at_n(v_ru_24x2_2440_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2441, v_fs_2442, v_fl_2443, v_su_2444, v_pl_2445, v_tk_2446, v_t_2449, v_lv_2448});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
Clo g_heff_2ecompile_2ebounds_2eallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eallOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eallOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_CondTrue);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_c_241);
    }
    case TAG_Cons: {
      V v_t_245 = (g_heff_2ecompile_2ebounds_2eallOf(v_x12_242));
      return heff_tag_n(TAG_CondIf, 3, (V[]){heff_dup(v_c_241), v_t_245, NTAG(TAG_CondFalse)});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2eallOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eboundsWith_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eboundsWith(V v_f_240, V v_ds_241, V v_ags_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2ebounds_2eindices(heff_dup(v_f_240), heff_dup(v_ds_241), v_ags_242));
  V v_t_244 = (g_heff_2ecompile_2ebounds_2ekept(v_f_240, heff_dup(v_ds_241), v_ags_242));
  V v_info_245 = heff_rec_n(3, shape_indices__arrays__defs, (V[]){v_t_243, v_t_244, v_ds_241});
  V v_t_246 = heff_dup(heff_rfield(v_info_245, 0));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_info_245, 3);
    return v_f_240;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_xs_249 = (g_heff_2ecompile_2ebounds_2escoped(heff_dup(v_info_245), NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_240, 4))));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam0, 2, 1, (V[]){heff_dup(v_info_245)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    HEFF_LAST return g_heff_2ecompile_2ebounds_2echeckedWith(v_f_240, v_info_245, v_t_2420);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2eboundsWith(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_info_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_x_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2419 = (g_heff_2ecompile_2ebounds_2eneedsIn(v_info_245, v_t_2415, v_t_2418));
  return (g_prelude_2e_2b_2b(v_t_2419, v_acc_2411));
}